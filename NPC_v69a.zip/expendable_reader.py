from message_window import Make_Message_Window
from re import split
from wb import wb

expendable_list = []
expendable_names = []
implement_types = []
expendable_titles = [ 'Feat Name', 'Damage Factor', 'Attack Seconds', 'Stamina Cost', 'Power Cost', 'Level', 'End of Combat Cooldown', 'Range', 'Standard Effects', 'Restriction Effects', 'Conditional Effects', 'Weapon Category', 'Keywords', 'Last Updated' ]
expendable_keywords = [] #is this even used?
expendable_effects_list = []

implement_roles = [['Cleric','Holy Symbol'],['Fighter','Trophy Charm'],['Rogue','Rogue Kit'],['Wizard','Spellbook']]

class Expendable:
	def __init__(self,parsed):
		self.name = parsed[1]
		self.factor = float(parsed[2])
		self.stamina = int(parsed[4])
		self.power = int(parsed[5])
		self.level = int(parsed[6])
		self.attributes = parsed
		self.keywords = []
		self.implement = ''
		self.role = None
		self.effects = []
		self.damage_type = 'Not Found'
		self.penetrating = False #standard effects
		self.extra_base = 0
		self.precise = 0
		self.afflicted = 0
		self.bleeding = 0
		self.burning = 0
		self.conditional_penetrating = False #conditional effects
		self.conditional_extra_base = 0
		self.conditional_precise = 0
		self.conditional_afflicted = 0
		self.conditional_bleeding = 0
		self.conditional_burning = 0
	def set_keywords(self, keyword_list):
		self.keywords = keyword_list
	def set_implement(self, implement):
		self.implement = implement
	def set_role(self, role):
		self.role = role
	def add_effect(self,effect):
		self.effects.append(effect)
	def set_defense(self):
		self.defense = 'Reflex'
		defenses = ['Fortitude','Reflex','Will']
		for effect in self.effects:
			for i, x in enumerate(['Targets Fortitude','Targets Reflex', 'Targets Will']):
				if(effect==x):
					self.defense = defenses[i]
					return
		return
	def find_damage_type(self):
		for effect in self.effects:
			if 'Damage' in effect and 'Base' not in effect: #eliminate 'Base Damage +x'
				self.damage_type = effect.split()[0]
		if(self.damage_type=='Not Found' and 'Beneficial' in self.effects):
			self.damage_type = 'None (Beneficial)'
		#if(self.damage_type=='None' and self.weapon not in ['Focus','Mage Staff','Mage Wand']):
		#	self.damage_type = 'Physical'
	def printout(self):
		mw = Make_Message_Window()
		title = 'Expendable: %s' %self.name
		column_names = [ 'Attribute', 'Details' ]
		column_entries = [ ]
		width = 10
		for i in range(1,len(self.attributes)):
			column_entries.append([expendable_titles[i-1],self.attributes[i]])
			width = max(width,len(self.attributes[i])+5)
		widths = [ 20, width ]
		mw.update_columns(title, column_names, column_entries, widths)
		mw.new_window()

def find_keywords(entry):
	result = []
	if('/' in entry):
		result = entry.split('/')
	else:
		result = [entry]
	for x in result:
		if(x not in expendable_keywords):
			expendable_keywords.append(x)
	return result

def expendable_read():
	for sheet_name in ['Consumables','Trophy Charm','Holy Symbol','Rogue Kit','Spellbook']:
		#note the column copying!
		sheet = wb.sheet_by_name(sheet_name)
		for rownum in range(sheet.nrows):
			row = sheet.row_values(rownum)[-1].split('|')
			if(row[0]=='Template' or len(row)<2):
				continue
			""" can't remember why this was here. legacy formats?
			for entry_num in range(len(row)):
				row[entry_num] = row[entry_num].replace('{{','')
				row[entry_num] = row[entry_num].replace('}}','')
				row[entry_num] = row[entry_num].replace('"','')
				parsed.append(row[entry_num])
			"""
			e = Expendable(row)
			e.set_keywords(find_keywords(row[len(row)-2]))
			expendable_list.append(e)
			expendable_names.append(e.name)
			e.set_implement(row[12])
			for match in implement_roles:
				if(e.implement==match[1]):
					e.set_role(match[0])
			if(row[12] not in implement_types):
				implement_types.append(row[12])
			for r in [9,10,11]:
				effects = row[r].split(',')
				for i in range(len(effects)):
					if(')' in effects[i] and '(' not in effects[i]):
						continue
					effect = effects[i].lstrip().rstrip()
					if(effect==''):
						continue
					if('(' in effects[i] and ')' not in effects[i] and i+1<len(effects)):
						if(')' in effects[i+1]):
							effect = ', '.join([effect, effects[i+1].lstrip().rstrip()])
					if(r==5):
						if(effect=='Penetrating'):
							e.penetrating = True
						if('Precise' in effect):
							e.precise = int(effect.split('+')[1])
						if('Base Damage' in effect):
							e.extra_base = int(effect.split('+')[1].split()[0])
						if('Afflicted' in effect):
							e.afflicted = int(effect.split()[1])
						if('Bleeding' in effect):
							e.bleeding = int(effect.split()[1])
						if('Burning' in effect):
							e.burning = int(effect.split()[1])
					if(r==7):
						if('Penetrating' in effect):
							e.conditional_penetrating = True
						if('Precise' in effect):
							e.conditional_precise = int(effect.split('+')[1].split()[0])
						if('Base Damage' in effect):
							e.conditional_extra_base = int(effect.split('+')[1].split()[0])
						if('Afflicted' in effect):
							e.conditional_afflicted = int(effect.split()[1])
						if('Bleeding' in effect):
							e.conditional_bleeding = int(effect.split()[1])
						if('Burning' in effect):
							e.conditional_burning = int(effect.split()[1])
					if(effect not in expendable_effects_list):# and effect != ''):
						expendable_effects_list.append(effect)
					e.add_effect(effect)
			e.find_damage_type()
			e.set_defense()

expendable_read()

implement_types = sorted(implement_types)
if('' in expendable_keywords):
	expendable_keywords.remove('')
expendable_keywords = sorted(expendable_keywords)
expendable_effects_list = sorted(expendable_effects_list)
