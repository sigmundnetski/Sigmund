from xlrd import open_workbook

wb = open_workbook('PFO Wiki - Official Data.xlsx')
