ab_names = ['Strength','Dexterity','Constitution','Intelligence','Wisdom','Personality']
from re import split #crafting/rotation shouldn't need to import later

def find_abilities(a,names=False): 
	ab = []
	for i in range(len(ab_names)):
		if(ab_names[i] in a or ab_names[i].lower() in a):
			if(names):
				ab.append(ab_names[i])
			else:
				ab.append(i)
	return ab

def is_in(string,lookat): #string should already be split by ',' and lstrip/rstrip
	#http://stackoverflow.com/questions/7128153/multiple-in-operators-in-python for example using all
	to_look = [ x.lstrip().rstrip() for x in string.split() ]
	current_logic, index = '+', 0
	while(index<len(to_look)):
		if(to_look[index] in ['+', '-']):
			current_logic = to_look[index]
			index += 1
		if(current_logic=='+'):
			if(to_look[index] not in lookat):
				return False
			index += 1
		else: #'exclude'
			if(to_look[index] in lookat):
				return False
			index += 1
	return True

allowed_searches = 'The allowed search types are: \n'
allowed_searches += 'a, b, c, ... will return everything with a OR b OR c etc. \n'
allowed_searches += 'For each item in the above list [a,b,c, ...] you can have it in the form: \n'
allowed_searches += 'u + v - w which will return everything which has both u and v and does not have w. \n'
allowed_searches += 'More +/- are allowed, but you must have the spaces as above! \n'
allowed_searches += '---------------------- \n'
allowed_searches += 'Examples: \n'
allowed_searches += '1) opportunity - provokes, flat => will return everything with opportunity without provokes AND also everything with flat \n'
allowed_searches += '2) opportunity + provokes, dazed => will return everything with both opportunity and provokes AND also everything with dazed \n'
allowed_searches += '---------------------- \n'
allowed_searches += 'Searches only look at ONE effect (standard, conditional, restriction) at a time when deciding on whether or not something qualifies.\n'

"""
from time import sleep
print(is_in('x + y - z', ['x'])) #False
print(is_in('x + y - z', ['x','y'])) #True
print(is_in('x + y - z', ['x','y', 'z'])) #False
print(is_in('x + y + z - u - v', ['x', 'y', 'z'])) #True
print(is_in('x + y + z - u - v', ['x', 'y', 'z', 'u'])) #False
print(is_in('x + y + z - u - v', ['x', 'y', 'z', 'v'])) #False
print(is_in('x + y + z - u - v', ['x', 'y', 'z', 'u', 'v'])) #False
print(is_in('x + y + z - u - v', ['x', 'y', 'u'])) #False
sleep(200)
"""
