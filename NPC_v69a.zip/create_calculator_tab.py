import tkinter as tk
import tkinter.ttk as ttk
from math import sqrt
from webbrowser import open_new

class Create_Calculator_Tab:
	def __init__(self, tab):
		c = tab
		self.calculator_display = tk.StringVar()
		e = tk.Entry(c, textvariable=self.calculator_display, relief='sunken')
		e.grid(row=0,column=0,columnspan=5, padx=10, pady=10, ipadx=50,sticky="NEWS")
		keys = ['123+', '456-', '789*', '-0./', '()']
		for i in range(len(keys)):
			for j, x in enumerate(keys[i]):
				self.Create_Calculator_Button(c, x).grid(row=i+1,column=j,sticky="NEWS")
		self.Clear_Calculator()
		tk.Button(c, text='', padx=10, pady=10).grid(row=5,column=2,sticky="NEWS") #placeholder
		tk.Button(c, text='sqrt', command=self.Square_Root, padx=10, pady=10).grid(row=5,column=3,sticky="NEWS")
		self.calculator_memory = tk.StringVar()
		self.Create_Calculator_Button(c, 'Store', True).grid(row=6,column=0,sticky="NEWS")
		self.Create_Calculator_Button(c, 'Recall', True, True).grid(row=6,column=1,sticky="NEWS")
		tk.Button(c, text='Clear', command=self.Clear_Calculator, padx=10, pady=10).grid(row=6,column=2,sticky="NEWS")
		tk.Button(c, text='=', command=self.Evaluate_Calculator, padx=10, pady=10).grid(row=6,column=3,sticky="NEWS")
		e.bind('<Key>',self.key)
		e.focus_set()
		self.insert_text(c)

	def key(self,event):
		if(event.keysym=='Return'):
			self.Evaluate_Calculator()

	def Create_Calculator_Button(self,tab,x,store=False,recall=False):
		cmd = lambda x=x, y=self.calculator_display: y.set('%s%s' %(y.get(),x))
		if(store):
			cmd = lambda y=self.calculator_display, z=self.calculator_memory: z.set(y.get())
		if(recall):
			cmd = lambda y=self.calculator_display, z=self.calculator_memory: y.set(z.get())
		but = tk.Button(tab, text='%s' %x, command=cmd, padx=10, pady=10)
		return but

	def Invalid_Entry(self):
		self.calculator_display.set('Error')

	def Square_Root(self):
		try:
			self.calculator_display.set(sqrt(eval(self.calculator_display.get())))
		except:
			self.Invalid_Entry()

	def Evaluate_Calculator(self):
		try:
			self.calculator_display.set(eval(self.calculator_display.get()))
		except:
			self.Invalid_Entry()

	def Clear_Calculator(self):
		self.calculator_display.set('')

	def insert_text(self,c):
		quote = """Welcome to NPC, Pathfinder Online's first app!\n
USER INPUT:\n
*birthdays.txt: Creation times for characters. Format is character name day/month/year hour:minute:second.\n
*ignored_feats.txt: A list of feats not to be read in by the training calculator. There are many feats that appear trainable but do not yet exist in game.\n
*local_prices folder: Contains spreadsheets of local market prices of refined and finished goods for the crafting tab.\n
*saved_files folder: Contains saved text and csv files from printout windows. The csv files can be opened with a spreadsheet program.\n
*threadings folder: Contains saved text files used in the threading tab.\n
*training_plans folder: Training plans on the training tab can be read in from here and will be saved here. Each is a list of feats to be trained in order.\n"""
		quote += """
TABS:\n
*Calculator: A basic calculator.\n
*Convert Stats: Compute average damaneg and compare the value of combat stats.\n
*Rotation (work in progress): What attacks work together well.\n
*Crafting: Details of recipes and optimizing your crafting.\n
*Loot: How knowledge skills and group size affects loot.\n
*Reputation: How long to gain reputation. Out of date.\n
*Threading: Minimize losses by threading right.\n
*Training: Plan out your training.\n
*Travel: How long it takes to get places.\n
*Wiki: Look up feat details and do keyword matching.\n
*Advanced: Change default values of other tabs."""
		ttk.Label(c, text=quote, wraplength='12i', anchor=tk.NW, relief='sunken').grid(row=0,column=5,rowspan=7,sticky="NEWS")
		quote = """Contact me by clicking here."""
		link0 = ttk.Label(c, text=quote, wraplength='4i', anchor=tk.NW, relief='sunken', foreground='blue')
		link0.grid(row=0,column=6,sticky="NEWS")
		link0.bind("<Button-1>", self.pm)
		quote = """Click here for the NPC paizo thread."""
		link1 = ttk.Label(c, text=quote, wraplength='4i', anchor=tk.NW, relief='sunken', foreground='blue')
		link1.grid(row=1,column=6,sticky="NEWS")
		link1.bind("<Button-1>", self.paizo)
		quote = """Click here for the NPC goblinworks thread."""
		link2 = ttk.Label(c, text=quote, wraplength='4i', anchor=tk.NW, relief='sunken', foreground='blue')
		link2.grid(row=2,column=6,sticky="NEWS")
		link2.bind("<Button-1>", self.goblinworks)
		quote = """Click here for my seldom updated theorycrafting blog."""
		link3 = ttk.Label(c, text=quote, wraplength='4i', anchor=tk.NW, relief='sunken', foreground='blue')
		link3.grid(row=3,column=6,sticky="NEWS")
		link3.bind("<Button-1>", self.blog)

	def blog(self,event):
		open_new(r"http://pfotheorycrafting.wordpress.com/")

	def pm(self,event):
		open_new(r"http://paizo.com/people/Nightdrifter")

	def paizo(self,event):
		open_new(r"http://paizo.com/threads/rzs2r5r5?Simple-PFO-Calculators")

	def goblinworks(self,event):
		open_new(r"https://goblinworks.com/forum/topic/420/")
