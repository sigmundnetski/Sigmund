from feat import Feat
from re import findall, split
from csv_parser import *
from utilities import *
from role_reader import role_list
from wb import wb

feat_list = []
ignore_list = []
fin = open('ignored_feats.txt','r')
ignore_list = [ x.replace('\n','') for x in fin ]

def hack_ability(ab):
	for ar in ab:
		if(len(ar)==0):
			continue
		x = find_abilities(ar)
		if(len(x)>0):
			return x
	return [ 0 ]	

feat_types = ['Armor','Attacks','Bonuses','Cantrips','Defensive','Expendables','Feature','Orisons','Points','Proficiencies','Reactive','Skills','Utility']
sheet_names = ['Armor Advancement','Attack Advancement','Bonuses Advancement','Cantrip Advancement','Defensive Advancement','Expendables Advancement','Feature Advancement','Orison Advancement','Points Advancement','Proficiencies','Reactive Advancement','Skills Advancement','Utility Advancement']

def feat_read():
	for sn, sheet_name in enumerate(sheet_names):
		feat_type = feat_types[sn]
		sheet = wb.sheet_by_name(sheet_name)
		name_row_number, found_name_row, labels = 0, False, []
		for rownum in range(sheet.nrows):
			row = sheet.row_values(rownum)
			xp, ability_req, ability_bonus, prerequisites, achievements, roles = [], [], [], [], [], []
			if(not found_name_row):
				for entry_num in range(len(row)):
					labels.append(row[entry_num]) 
					if('SlotName' in row[entry_num]):
						name_row_number, found_name_row = entry_num, True
				if(not found_name_row):
					labels = [] #reset the labels as we'd be getting the wrong row in this case
				continue
			if(row[name_row_number]=='' and found_name_row):
				continue
			if(row[name_row_number] in ignore_list):
				continue
			for entry_num in range(len(row)): #need a way of stopping for those feats which are limited in level
				if('Exp' in labels[entry_num]):
					if(row[entry_num]==''):
						if(len(xp)>0): #get rid of extraneous levels, such as hp going to 40
							break
						xp.append(0)#HACK!
						continue
					xp.append(int(row[entry_num]))
				if('AbilityReq' in labels[entry_num]):
					if(row[entry_num]==''):
						ability_req.append('Any=10')#HACK!
						continue
					ability_req.append(row[entry_num])
				if('AbilityBonus' in labels[entry_num]):
					if(row[entry_num]==''):
						ability_bonus.append('Any=.0')#HACK!
						continue
					ability_bonus.append(row[entry_num])
				if('Feat' in labels[entry_num]):
					if(row[entry_num]==''):
						prerequisites.append('')
						continue
					prerequisites.append(parse(row[entry_num],0)) #default is 'and'
				if('Category' in labels[entry_num]):
					if(row[entry_num]==''):
						achievements.append('')
						continue
					achievements.append(parse(row[entry_num],0)) #0 to fix a bug with eg. Heavy Melee Bonus showing Martial as or.
				if('Achievement' in labels[entry_num]): #Note: Category seems to always come first. Not guaranteed?
					info = parse(row[entry_num], 0)
					r = []
					for inf in info:
						for role in role_list:
							if(role.name==inf[0]):
								r.append(inf)
								info.remove(inf)
					roles.append(r)
					if(achievements[len(achievements)-1]==''):
						achievements[len(achievements)-1] = []
					achievements[len(achievements)-1] += info #is it adding to the right one?
			prereq_abilities = hack_ability(ability_req)
			increased_abilities = hack_ability(ability_bonus)
			ability_req = [ int(findall("\d+", ab)[0]) for ab in ability_req ] #array of scores
			ability_bonus = [ float(findall("\d?\.\d+", ab)[0]) for ab in ability_bonus ]
			feat_list.append(Feat(feat_type,row[name_row_number],xp,ability_req,prereq_abilities,ability_bonus,increased_abilities,prerequisites,achievements,roles))

feat_read()
