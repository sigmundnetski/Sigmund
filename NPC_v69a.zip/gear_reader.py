from message_window import Make_Message_Window
from re import split
from wb import wb
from datetime import datetime

gear_list = []
gear_names = []
gear_types = ['Head','Neck','Back','Waist','Finger','Hand','Feet']
gear_titles = ['Name','Slot','Tier','+0 Quality','Encumbrance','Description','Utility Keyword','Item Category','Last Updated']
all_gear_keywords = []

class Gear:
	def __init__(self,parsed):
		self.attributes = parsed
		self.name = parsed[0]
		self.type = parsed[7]
		self.tier = int(parsed[2])
		self.quality = int(parsed[3])
		self.attributes[-1] = str(datetime.utcfromtimestamp( (self.attributes[-1]-25569)*86400.0 )).split()[0] #hack
		self.keywords = [ x.lstrip().rstrip() for x in parsed[6].split(',') ]
	def printout(self):
		mw = Make_Message_Window()
		title = 'Gear: %s' %self.name
		column_names = [ 'Attribute', 'Details' ]
		column_entries = [ ]
		width = 10
		for i in range(len(self.attributes)):
			column_entries.append([gear_titles[i],self.attributes[i]])
			width = max(width,len(str(self.attributes[i]))+5)
		widths = [ 20, width ]
		mw.update_columns(title, column_names, column_entries, widths)
		mw.new_window()

def gear_read():
	sheet = wb.sheet_by_name('Misc Gear')
	for rownum in range(1,sheet.nrows):
		row = sheet.row_values(rownum)
		if(row[7] in gear_types):
			g = Gear(row)
			gear_list.append(g)
			gear_names.append(g.name)
			for kw in g.keywords:
				if kw not in all_gear_keywords:
					all_gear_keywords.append(kw)

gear_read()
gear_names = sorted(gear_names)
all_gear_keywords = sorted(all_gear_keywords)
