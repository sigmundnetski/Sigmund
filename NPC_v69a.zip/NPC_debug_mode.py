from main_window import *

if __name__ == '__main__':
	root = tk.Tk()
	root.title("NPC: Nightdrifter's PFO Calculators")
	root.iconbitmap(r'%s' %os.path.join(os.getcwd(),'NPC.ico'))
	main_window = Main_Window(root)
	main_window.pack(side='top', fill='both', expand=True)
	root.mainloop()
