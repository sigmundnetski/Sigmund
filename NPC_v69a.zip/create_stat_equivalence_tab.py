import tkinter as tk
#from attack_reader import attack_list #for later
#from expendable_reader import expendable_list
from message_window import Make_Message_Window, damage, likelihood, onemp
from math import sqrt

def estimate_resistance(dmg, f, b):
	if(f==0.0):
		return -99
	#f(b-r)=d, b-r=d/f, r=b-d/f
	r1 = b-round(dmg/f)
	r2, r3, r4, r5 = r1-1, r1+1, r1-2, r1+2
	for r in [r1,r2,r3,r4,r5]:
		if(round(f*(b-r))==dmg):
			return r
	return r1

class Create_Stat_Equivalence_Tab:
	def __init__(self, tab):
		self.atier = tk.IntVar()
		self.atier.set(1)
		self.dtier = tk.IntVar() 
		self.dtier.set(1)
		self.f = tk.DoubleVar()
		self.f.set(1.4)
		self.b = tk.IntVar()
		self.b.set(45)
		self.r = tk.IntVar()
		self.r.set(0)
		self.bmr = tk.DoubleVar()
		self.a = tk.IntVar() 
		self.a.set(0)
		self.d = tk.IntVar()
		self.d.set(50)
		self.amd = tk.IntVar()
		self.delta_f = tk.DoubleVar()
		self.delta_f.set(0.0)
		self.delta_bmr = tk.IntVar()
		self.delta_amd = tk.IntVar()
		self.hp = tk.IntVar()
		self.hp.set(400)
		self.delta_hp = tk.IntVar()
		self.delta_hp.set(0)
		self.crit_rating = tk.IntVar()
		self.crit_rating.set(0)
		self.crit_resistance = tk.IntVar()
		self.crit_resistance.set(0)
		self.cramcre = tk.IntVar() #crit rating - crit resistance
		self.delta_crit = tk.IntVar() #change in rating
		self.delta_crit.set(0)
		self.full_hit = tk.DoubleVar()
		self.full_hit.set(0.0)
		self.crit_odds = tk.DoubleVar()
		self.crit_odds.set(0.0)
		self.dmg = tk.DoubleVar()
		self.dmg.set(0.0)
		self.htk = tk.DoubleVar()
		self.htk.set(0)
		self.time = tk.DoubleVar()
		self.time.set(1.5)
		self.delta_t = tk.DoubleVar()
		self.delta_t.set(0.0)
		self.ttk = tk.DoubleVar()
		self.ttk.set(0.0)
		self.conversion_result = tk.DoubleVar()
		self.crit_conversion_result = tk.DoubleVar()
		self.is_penetrating = tk.IntVar()
		self.is_penetrating.set(0)
		self.stack = tk.IntVar()
		self.stack.set(10)
		#tk.Label(t, text='Target Recovery').grid(row=21, column=4, sticky="NEWS")
		self.recovery = tk.IntVar()
		self.recovery.set(10)
		#tk.Entry(t, textvariable=self.recovery).grid(row=21,column=5, sticky="NEWS")
		self.Calculate_Relative_Stats()
		t = tab
		labels = ['Attack Tier','Damage Factor (f)','Base Damage (b)','Enemy Resistance (r)','Attack Bonus (a)','Enemy Defense Bonus (d)', 'Attack time (t)', 'Enemy Hit Points (h)', 'Crit Rating (cra)', 'Enemy Crit Resistance (cre)', 'Enemy Recovery']#,'Defense Tier']
		#maybe add keywords instead? issue with fighter class features which increase base damage
		variables = [self.atier, self.f, self.b, self.r, self.a, self.d, self.time, self.hp, self.crit_rating, self.crit_resistance, self.recovery ]
		for i in range(len(labels)):
			tk.Label(t, text='%s' %labels[i]).grid(row=i,column=0,sticky="NEWS")
			if(i>0):
				tk.Entry(t, textvariable=variables[i]).grid(row=i,column=1,sticky="NEWS")
		tk.OptionMenu(t, self.atier, *[1,2,3]).grid(row=0,column=1,sticky="NEWS")
		#tk.OptionMenu(t, self.dtier, *[1,2,3]).grid(row=len(labels)-1,column=1,sticky="NEWS") #dtier is set to 1 always as can just adjust d
		tk.Checkbutton(t, text='Attack is penetrating', variable=self.is_penetrating).grid(row=12,column=0,sticky="NEWS")
		
		dlabels = ['change in f', 'change in b-r', 'change in a-d', 'change in t', 'change in hp', 'dot size']
		dvariables = [self.delta_f, self.delta_bmr, self.delta_amd, self.delta_t, self.delta_hp, self.stack]
		for i in range(len(dlabels)):
			tk.Label(t, text=dlabels[i]).grid(row=0,column=i+3,sticky="NEWS")
			tk.Entry(t, textvariable=dvariables[i]).grid(row=1,column=i+3,sticky="NEWS")
		self.old_stat = tk.IntVar()
		self.old_stat.set(0)
		self.new_stat = tk.IntVar()
		self.new_stat.set(0)
		stat_names = ['Damage Factor', 'Base Damage-Resistance', 'Attack Bonus - Defense Bonus', 'Attack Time', 'Extra hp', 'Dot size']
		tk.Label(t, text='Convert from').grid(row=2,column=2,sticky="NEWS")
		tk.Label(t, text='Convert to').grid(row=3,column=2,sticky="NEWS")
		for i in range(len(stat_names)):
			tk.Radiobutton(t, text=stat_names[i], variable=self.old_stat, value=i).grid(row=2,column=i+3,sticky="NEWS")
			tk.Radiobutton(t, text=stat_names[i], variable=self.new_stat, value=i).grid(row=3,column=i+3,sticky="NEWS")
		tk.Button(t, text='Convert', command=self.Convert).grid(row=4,column=5,sticky="NEWS")
		tk.Label(t, text='Closest equivalent change').grid(row=4,column=3,sticky="NEWS")
		tk.Entry(t, textvariable=self.conversion_result).grid(row=4,column=4,sticky="NEWS")

		dcritlabels = ['change in cra-cre', 'change in a-d', 'change in t']
		dcritvariables = [self.delta_crit, self.delta_amd, self.delta_t]
		for i in range(len(dcritlabels)):
			tk.Label(t, text=dcritlabels[i]).grid(row=5,column=i+4,sticky="NEWS")
			tk.Entry(t, textvariable=dcritvariables[i]).grid(row=6,column=i+4,sticky="NEWS")
		self.old_crit_stat = tk.IntVar()
		self.old_crit_stat.set(0)
		self.new_crit_stat = tk.IntVar()
		self.new_crit_stat.set(0)
		crit_stat_names = ['Crit Rating - Crit Resistance', 'Attack Bonus - Defense Bonus', 'Attack Time']
		tk.Label(t, text='Convert from').grid(row=7,column=3,sticky="NEWS")
		tk.Label(t, text='Convert to').grid(row=8,column=3,sticky="NEWS")
		for i in range(len(crit_stat_names)):
			tk.Radiobutton(t, text=crit_stat_names[i], variable=self.old_crit_stat, value=i).grid(row=7,column=i+4,sticky="NEWS")
			tk.Radiobutton(t, text=crit_stat_names[i], variable=self.new_crit_stat, value=i).grid(row=8,column=i+4,sticky="NEWS")	
		tk.Button(t, text='Convert', command=self.Convert_Crit).grid(row=9,column=5,sticky="NEWS")
		tk.Label(t, text='Closest equivalent change').grid(row=9,column=3,sticky="NEWS")
		tk.Entry(t, textvariable=self.crit_conversion_result).grid(row=9,column=4,sticky="NEWS")		

		tk.Label(t, text='Chance of crit (%)').grid(row=14, column=0, sticky="NEWS")
		tk.Entry(t, textvariable=self.crit_odds).grid(row=14, column=1, sticky="NEWS")
		tk.Button(t, text='Distribution of crits', command=self.Crit_Print).grid(row=14, column=3, sticky="NEWS")
		tk.Label(t, text='Chance of full hit (%)').grid(row=13, column=0, sticky="NEWS") 
		tk.Entry(t, textvariable=self.full_hit).grid(row=13, column=1, sticky="NEWS")
		tk.Button(t, text='Distribution of full hits', command=self.Hit_Print).grid(row=13, column=3, sticky="NEWS")
		tk.Label(t, text='Average damage per hit').grid(row=15, column=0, sticky="NEWS")
		tk.Entry(t, textvariable=self.dmg).grid(row=15, column=1, sticky="NEWS")
		tk.Label(t, text='Number of hits to kill').grid(row=16, column=0,sticky="NEWS")
		tk.Entry(t, textvariable=self.htk).grid(row=16, column=1,sticky="NEWS")
		tk.Label(t, text='Time to kill (s)').grid(row=17, column=0,sticky="NEWS")
		tk.Entry(t, textvariable=self.ttk).grid(row=17, column=1, sticky="NEWS")
		tk.Button(t, text='Calculate', command=self.Hits_To_Kill).grid(row=13, column=2, rowspan=5, sticky="NEWS")

		tk.Label(t, text='Stamina Cost').grid(row=18,column=0,sticky="NEWS")
		self.stamina_cost = tk.IntVar()
		self.stamina_cost.set(15)
		tk.Entry(t, textvariable=self.stamina_cost).grid(row=18,column=1,sticky="NEWS")
		tk.Label(t, text='Time between attacks (s)').grid(row=19,column=0,sticky="NEWS")
		self.time_per_attack = tk.DoubleVar()
		self.time_per_attack.set(max(self.stamina_cost.get()/10,self.time.get()))
		tk.Entry(t, textvariable=self.time_per_attack).grid(row=19,column=1,sticky="NEWS")
		tk.Label(t, text='Threat Ratio').grid(row=20,column=0,sticky="NEWS")
		self.threat_ratio = tk.DoubleVar()
		self.threat_ratio.set(1.0) #doubled from 0.5
		tk.Entry(t, textvariable=self.threat_ratio).grid(row=20,column=1,sticky="NEWS")
		tk.Label(t, text='Threat per round').grid(row=21,column=0,sticky="NEWS")
		self.threat_per_round = tk.DoubleVar()
		self.threat_per_round.set(0.0)
		tk.Entry(t, textvariable=self.threat_per_round).grid(row=21,column=1,sticky="NEWS")
		tk.Label(t, text='Threat loss per round').grid(row=22,column=0,sticky="NEWS")
		self.threat_loss = tk.IntVar()
		self.threat_loss.set(12) #reduced by 20% from 15
		#also lowered initial threat from 50 by 20% to 40
		tk.Entry(t, textvariable=self.threat_loss).grid(row=22,column=1,sticky="NEWS")
		tk.Label(t, text='Hold Threat Indefinitely?').grid(row=23,column=0,sticky="NEWS")
		self.hold_threat = tk.StringVar()
		self.hold_threat.set('Maybe')
		tk.Entry(t, textvariable=self.hold_threat).grid(row=23,column=1,sticky="NEWS")

		tk.Label(t, text='Max damage seen').grid(row=14, column=4, sticky="NEWS")
		self.max_seen = tk.IntVar()
		self.max_seen.set(60)
		tk.Entry(t, textvariable=self.max_seen).grid(row=14, column=5, sticky="NEWS")
		tk.Label(t, text='Damage Factor').grid(row=15, column=4, sticky="NEWS")
		tk.Entry(t, textvariable=self.f).grid(row=15, column=5, sticky="NEWS")
		tk.Label(t, text='Base Damage').grid(row=16, column=4, sticky="NEWS")
		tk.Entry(t, textvariable=self.b).grid(row=16, column=5, sticky="NEWS")
		tk.Button(t, text='Estimate Resistance', command=self.Estimate).grid(row=17, column=4, columnspan=2,sticky="NEWS")
		tk.Label(t, text='Estimated Resistance').grid(row=18, column=4, sticky="NEWS")
		self.resistance_estimate = tk.IntVar()
		self.resistance_estimate.set(0)
		tk.Entry(t, textvariable=self.resistance_estimate).grid(row=18, column=5, sticky="NEWS")

		tk.Label(t, text='Secondary Effect duration (s)').grid(row=14, column=6, sticky="NEWS")
		self.secondary_duration = tk.DoubleVar()
		self.secondary_duration.set(4.0)
		tk.Entry(t, textvariable=self.secondary_duration).grid(row=14, column=7, sticky="NEWS")
		tk.Label(t, text='Matched attack keywords (major x4)').grid(row=15, column=6, sticky="NEWS")
		self.matched_attack = tk.IntVar()
		self.matched_attack.set(1)
		tk.Entry(t, textvariable=self.matched_attack).grid(row=15, column=7, sticky="NEWS")
		self.expendable_check = tk.IntVar()
		self.expendable_check.set(0)
		tk.Checkbutton(t, text='expendable', variable=self.expendable_check).grid(row=15, column=8, sticky="NEWS")
		tk.Label(t, text='Matched defense keywords (major x4)').grid(row=16, column=6, sticky="NEWS")
		self.matched_defense = tk.IntVar()
		self.matched_defense.set(1)
		tk.Entry(t, textvariable=self.matched_defense).grid(row=16, column=7, sticky="NEWS")
		tk.Button(t, text='Average Duration', command=self.Duration).grid(row=17, column=6, columnspan=2,sticky="NEWS")
		self.final_duration = tk.DoubleVar()
		self.final_duration.set(self.secondary_duration.get())
		tk.Label(t, text='Average duration pre-diminishing returns (s)').grid(row=18, column=6, sticky="NEWS")
		tk.Entry(t, textvariable=self.final_duration).grid(row=18, column=7, sticky="NEWS")
		self.odds_of_application = tk.DoubleVar()
		self.odds_of_application.set(100.0)
		tk.Label(t, text='Odds of non-zero secondary effect (%)').grid(row=19, column=6, sticky="NEWS")
		tk.Entry(t, textvariable=self.odds_of_application).grid(row=19, column=7, sticky="NEWS")
		self.avg_when_applied = tk.DoubleVar()
		self.avg_when_applied.set(self.final_duration.get())
		tk.Label(t, text='Average of non-zero durations (s)').grid(row=20, column=6, sticky="NEWS")
		tk.Entry(t, textvariable=self.avg_when_applied).grid(row=20, column=7, sticky="NEWS")

		tk.Label(t, text='One time dot stack size').grid(row=20, column=4, sticky="NEWS")
		self.one_time_dot = tk.IntVar()
		self.one_time_dot.set(50)
		tk.Entry(t, textvariable=self.one_time_dot).grid(row=20, column=5, sticky="NEWS")
		tk.Button(t, text='dot profile', command=self.One_Dot_Profile).grid(row=21, column=4, columnspan=2, sticky="NEWS")

	def One_Dot_Profile(self):
		self.Calculate_Relative_Stats()
		self.one_time_dot.set(min(100, self.one_time_dot.get())) #can't go above 100 stacks
		avg_dot = round( self.one_time_dot.get()*damage(self.atier.get(), 1.0, 1, self.amd.get()-self.r.get(), self.dtier.get()) )
		rec = self.recovery.get()
		hp = self.hp.get()
		if(avg_dot<=0 or rec<=0 or hp<=0):
			return
		max_rounds = int(avg_dot/rec)+2
		profile = [round(avg_dot*0.001*hp)]
		for rd in range(max_rounds):
			avg_dot -= rec
			profile.append(round(avg_dot*0.001*hp))
		profile = sorted([ x for x in profile if x>0],reverse=True)
		mw = Make_Message_Window()
		title = 'Dot Profile'
		column_names = [ 'Round', 'Average Cumulative Damage' ]
		column_entries = [[rd+1, sum(profile[:rd+1])] for rd in range(len(profile))]
		widths = [10, 10]
		mw.update_columns(title, column_names, column_entries, widths)
		mw.new_window()

	def Duration(self):
		self.Calculate_Relative_Stats()
		if(self.expendable_check.get()==1):
			effect_power = int(1.4*self.matched_attack.get())
		else:
			effect_power = self.matched_attack.get()
		scale = max(1.0+0.1*(effect_power-self.matched_defense.get()),0.0)
		result = 0.0
		odds = 0.0
		applied = 0.0
		n = 0
		dur = self.secondary_duration.get()
		for roll in range(1,201):
			new = onemp(self.amd.get()+roll-50*self.dtier.get())[0]*scale
			if(new<0.7):
				continue
			else:
				like = likelihood[self.atier.get()-1][roll-1]
				odds += 100*like
				result += new*like*dur
				applied += new*dur
				n += 1
		if(n>0):
			applied = applied/n
		self.odds_of_application.set(round(1000*odds)/1000)
		self.avg_when_applied.set(round(1000*applied)/1000)
		self.final_duration.set(round(1000*result)/1000)

	def Estimate(self):
		self.resistance_estimate.set(estimate_resistance(self.max_seen.get(), self.f.get(), self.b.get()))

	def Calculate_Relative_Stats(self):
		self.bmr.set(max(self.b.get()-self.r.get(),0))
		if(self.is_penetrating.get()==1):
			self.bmr.set(self.bmr.get()+0.1*self.r.get()) #is pre-change to penetrating!!!!!!!!!!!!
		self.amd.set(self.a.get()-self.d.get()+50*self.dtier.get())
		self.cramcre.set(self.crit_rating.get()-self.crit_resistance.get())

	def Hits_To_Kill(self):
		self.Calculate_Relative_Stats()
		full_hit = 0.0
		crit_odds = 0.0
		for roll in range(1,201):
			full_hit += 100*likelihood[self.atier.get()-1][roll-1]*onemp(self.amd.get()+roll-50*self.dtier.get())[1]
			odds = onemp(self.amd.get()+roll-50*self.dtier.get(),self.cramcre.get())[2]
			if(odds>0):
				crit_odds += likelihood[self.atier.get()-1][roll-1]*min(odds*self.time.get(),100.0) #likelihood times percent chance
		self.full_hit.set(full_hit)
		self.full_hit.set(round(100000*self.full_hit.get())/100000)
		self.crit_odds.set(crit_odds)
		self.crit_odds.set(round(100000*self.crit_odds.get())/100000)
		avg = damage(self.atier.get(), self.f.get(), self.bmr.get(), self.amd.get(), self.dtier.get())
		self.dmg.set(avg)
		self.dmg.set(round(1000*self.dmg.get())/1000)
		if(self.bmr.get()>0):
			self.htk.set(self.hp.get()/avg)
			self.htk.set(round(1000*self.htk.get())/1000)
			self.ttk.set(self.htk.get()*self.time.get())
			self.ttk.set(round(1000*self.ttk.get())/1000)
			if(self.stamina_cost.get()>0 or self.time.get()>0.0):
				time_per_attack = max(self.time.get(), self.stamina_cost.get()/10)
				self.time_per_attack.set(time_per_attack)
				self.threat_per_round.set(self.threat_ratio.get()*self.dmg.get()/time_per_attack)
				self.threat_per_round.set(round(1000*self.threat_per_round.get())/1000)
				if(self.threat_per_round.get()>self.threat_loss.get()):
					self.hold_threat.set('Yes')
				else:
					self.hold_threat.set('No')
		if(self.bmr.get()==0.0):
			self.htk.set(float('inf'))
			self.ttk.set(float('inf'))

	def Convert_Crit(self): 
		given = self.old_crit_stat.get()
		equivalent = self.new_crit_stat.get()
		self.Calculate_Relative_Stats()
		start = 0.0
		for roll in range(1,201):
			odds = onemp(self.amd.get()+roll-50*self.dtier.get(),self.cramcre.get())[2]
			if(odds>0):
				start += likelihood[self.atier.get()-1][roll-1]*min(odds*self.time.get(),100.0) #should put this in a fcn as doing lots
		if(given==0):#crit
			goal = 0.0
			for roll in range(1,201):
				odds = onemp(self.amd.get()+roll-50*self.dtier.get(),self.cramcre.get()+self.delta_crit.get())[2]
				if(odds>0):
					goal += likelihood[self.atier.get()-1][roll-1]*min(odds*self.time.get(),100.0)
		if(given==1):
			goal = 0.0
			for roll in range(1,201):
				odds = onemp(self.amd.get()+self.delta_amd.get()+roll-50*self.dtier.get(),self.cramcre.get())[2]
				if(odds>0):
					goal += likelihood[self.atier.get()-1][roll-1]*min(odds*self.time.get(),100.0)
		if(given==2):
			goal = 0.0
			for roll in range(1,201):
				odds = onemp(self.amd.get()+self.delta_amd.get()+roll-50*self.dtier.get(),self.cramcre.get())[2]
				if(odds>0):
					goal += likelihood[self.atier.get()-1][roll-1]*min(odds*(self.time.get()+self.delta_t.get()),100.0)
		best_diff = 1000.0
		best = 0
		if(equivalent==0):
			for delta in range(-100,101):
				new = 0.0
				for roll in range(1,201):
					odds = onemp(self.amd.get()+roll-50*self.dtier.get(),self.cramcre.get()+delta)[2]
					if(odds>0):
						new += likelihood[self.atier.get()-1][roll-1]*min(odds*self.time.get(),100.0)
				diff = abs(new-goal)
				if(diff<best_diff):
					best_diff = diff
					best = delta
			self.crit_conversion_result.set(best)	
			return 1
		if(equivalent==1):
			for delta in range(-100,101):
				new = 0.0
				for roll in range(1,201):
					odds = onemp(self.amd.get()+delta+roll-50*self.dtier.get(),self.cramcre.get())[2]
					if(odds>0):
						new += likelihood[self.atier.get()-1][roll-1]*min(odds*self.time.get(),100.0)
				diff = abs(new-goal)
				if(diff<best_diff):
					best_diff = diff
					best = delta
			self.crit_conversion_result.set(best)
			return 1
		if(equivalent==2):
			if(start==0.0):
				self.crit_conversion_result.set(0.0)			
				return 0
			#(t+dt)*start = t*goal, so t+dt =t*goal/start, dt =t*goal/start-t
			self.crit_conversion_result.set(self.time.get()*((goal/start)-1.0))
			self.crit_conversion_result.set( round(100000*self.crit_conversion_result.get())/100000 ) 
			return 1

	def Convert(self): #needs to deal with penetrating! b-0.9r changes differently depending on b or r changing
		if(self.time.get()==0.0):
			return 0
		given = self.old_stat.get()
		equivalent = self.new_stat.get()
		self.Calculate_Relative_Stats()
		start = damage(self.atier.get(), self.f.get(), self.bmr.get(), self.amd.get(), self.dtier.get())/self.time.get() #unmodified damage before deltas
		if(given==0):#f
			goal = damage(self.atier.get(), self.f.get()+self.delta_f.get(), self.bmr.get(), self.amd.get(), self.dtier.get())/self.time.get()
		if(given==1):#bmr
			goal = damage(self.atier.get(), self.f.get(), self.bmr.get()+self.delta_bmr.get(), self.amd.get(), self.dtier.get())/self.time.get()
		if(given==2):#amd
			goal = damage(self.atier.get(), self.f.get(), self.bmr.get(), self.amd.get()+self.delta_amd.get(), self.dtier.get())/self.time.get()
		if(given==3):#t
			if(self.time.get()+self.delta_t.get()==0.0):
				return 0
			goal = damage(self.atier.get(), self.f.get(), self.bmr.get(), self.amd.get(), self.dtier.get())/(self.time.get()+self.delta_t.get())
		if(given==4):#hp
			if(self.hp.get()==0):
				return 0
			goal = (1.0+self.delta_hp.get()/self.hp.get())*start #dps scaled by the new hp
		if(given==5):#dot
			goal = start #DIVIDE THE DOT DAMAGE BY TIME!!
			self.stack.set(min(100, self.stack.get())) #can't go above 100 stacks
			avg_dot = round( self.stack.get()*damage(self.atier.get(), 1.0, 1, self.amd.get()-self.r.get(), self.dtier.get()) ) 
			rec = self.recovery.get()
			hp = self.hp.get()
			if(avg_dot<=0 or rec<=0 or hp<=0):
				return 0
			max_rounds = int(avg_dot/rec)+2
			profile = [round(avg_dot*0.001*hp)]
			for rd in range(max_rounds):
				avg_dot -= rec
				profile.append(round(avg_dot*0.001*hp))
			profile = [x for x in profile if x>0]
			goal += sum(profile)/self.time.get()
		if(goal==0.0):
			return 0
		best_diff = 1000.0
		best = 0
		if(equivalent==0 and start!=0.0):
			self.conversion_result.set((goal*self.f.get()/start)-self.f.get()) 
			self.conversion_result.set(round(1000*self.conversion_result.get())/1000)
			return 1
		if(equivalent==0 and start==0.0 and given==5):#pure dot
			x = damage(self.atier.get(), 1.0, self.bmr.get(), self.amd.get()-self.r.get(), self.dtier.get()) #1.0 f
			self.conversion_result.set(goal/x)
			self.conversion_result.set(round(1000*self.conversion_result.get())/1000)
		if(equivalent==1):
			#(q+b)/b~goal, so q~b*(goal-1)
			#min_b = int(self.bmr.get()*(goal-1)-5)
			#max_b = int(self.bmr.get()*(goal-1)+5)
			for delta in range(-100,101):#(min_b,max_b+1): #why am i not using this?
				if(self.bmr.get()>0):
					new = start*(delta+self.bmr.get())/self.bmr.get()
				else:
					new = damage(self.atier.get(), self.f.get(), self.bmr.get()+delta, self.amd.get(), self.dtier.get())/self.time.get()
				diff = abs(new-goal)
				if(diff<best_diff):
					best_diff = diff
					best = delta
			self.conversion_result.set(best)
			return 1
		if(equivalent==2):
			min_a = -150 #need something more clever
			max_a = 150
			for delta in range(min_a,max_a+1):
				new = damage(self.atier.get(), self.f.get(), self.bmr.get(), self.amd.get()+delta, self.dtier.get())/self.time.get()
				diff = abs(new-goal)
				if(diff<best_diff):
					best_diff = diff
					best = delta
			self.conversion_result.set(best)
			return 1
		if(equivalent==3):
			#start/(t+dt)=goal/t, so start/goal=1+dt/t, so dt=(start/goal-1.0)*t
			self.conversion_result.set( self.time.get()*((start/goal)-1.0) )
			self.conversion_result.set(round(1000*self.conversion_result.get())/1000)
			return 1
		if(equivalent==4):
			#scale to new hp h1/d1=h2/d2, h2=(d2/d1)*h1 
			self.conversion_result.set(self.hp.get()*goal/start-self.hp.get())
			self.conversion_result.set( int(round(self.conversion_result.get())) )
		if(equivalent==5):
			for stack in range(100):
				avg_dot = round( stack*damage(self.atier.get(), 1.0, 1, self.amd.get()-self.r.get(), self.dtier.get()) ) 
				rec = self.recovery.get()
				hp = self.hp.get()
				if(avg_dot<=0 or rec<=0 or hp<=0):
					continue
				max_rounds = int(avg_dot/rec)+2
				profile = [round(avg_dot*0.001*hp)]
				for rd in range(max_rounds):
					avg_dot -= rec
					profile.append(round(avg_dot*0.001*hp))
				profile = [ x for x in profile if x>0]
				new = start+(sum(profile)/self.time.get())
				diff = abs(new-goal)
				if(diff<=best_diff):
					best_diff = diff
					best = stack
			self.conversion_result.set(best)
			return 1

	def Success_Distribution(self,odds):
		#expectation of binomial distribution successes is E[X] = np
		#variance is np(1-p)
		return [ [n, round(10000*n*odds)/10000, round(10000*sqrt(n*odds*(1.0-odds)))/10000] for n in range(1,51) ]

	def Hit_Print(self):
		mw = Make_Message_Window()
		title = 'Average Number of Full Hits'
		column_names = [ 'Attacks', 'Average', 'Sqrt(Variance)' ]
		column_entries = self.Success_Distribution(self.full_hit.get()/100)#convert from % to decimal
		widths = [ 10, 10, 10 ]
		mw.update_columns(title, column_names, column_entries, widths)
		mw.new_window()

	def Crit_Print(self):
		mw = Make_Message_Window()
		title = 'Average Number of Crits'
		column_names = [ 'Attacks', 'Average', 'Sqrt(Variance)' ]
		column_entries = self.Success_Distribution(self.crit_odds.get()/100)#convert from % to decimal
		widths = [ 10, 10, 10 ]
		mw.update_columns(title, column_names, column_entries, widths)
		mw.new_window()
