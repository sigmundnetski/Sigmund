import tkinter as tk
from tkinter.ttk import Notebook #for tabs
import time #for time calculations
from math import sqrt #for calculator and travel
from utilities import * #for find_abilities
from feat_reader import * # for feat_list
from player import Player
from message_window import Make_Message_Window
from role_reader import *
from logic_handler import Logic_Handler
from os import path, getcwd
from attack_reader import *
from expendable_reader import *
from passive_reader import *
from keyword_reader import *
from weapon_reader import *
from armor_reader import *
from gear_reader import *
from create_stat_equivalence_tab import Create_Stat_Equivalence_Tab
from create_loot_tab import Create_Loot_Tab
from create_calculator_tab import Create_Calculator_Tab
from create_threading_tab import Create_Threading_Tab
from create_crafting_tab import Create_Crafting_Tab, Print_Trained_Recipes, profession_list
from create_rotation_tab import Create_Rotation_Tab
from linked_feat import *
from training_calendar import test_calendar
from datetime import datetime #already in gear_reader

class Main_Window(Notebook):
	def __init__(self, *args, **kwargs):
		Notebook.__init__(self, *args, **kwargs)
		tab_names = [ 'Calculator', 'Convert Stats', 'Rotation', 'Crafting', 'Loot', 'Reputation', 'Threading', 'Training', 'Gear', 'Travel', 'Wiki', 'Advanced Options' ]
		#here import the private versions
		self.tabs = [ tk.Frame(self) for i in range(len(tab_names)) ]
		for i in range(len(self.tabs)):
			self.add(self.tabs[i], text = '%s' %tab_names[i])
		self.have_stored_threading_info=False
		self.have_stored_reputation_settings=False
		self.have_stored_travel_settings=False
		self.have_stored_xp_settings=False
		self.have_stored_training_settings=False 
		Create_Calculator_Tab(self.tabs[0])
		Create_Stat_Equivalence_Tab(self.tabs[1])
		Create_Rotation_Tab(self.tabs[2])
		self.crafting = Create_Crafting_Tab(self.tabs[3])
		Create_Loot_Tab(self.tabs[4])
		self.Create_Reputation_Tab(self.tabs[5])
		Create_Threading_Tab(self.tabs[6])
		self.Create_Training_Tab(self.tabs[7])
		self.Create_Gear_Tab(self.tabs[8])
		self.Create_Travel_Tab(self.tabs[9])
		self.Create_Wiki_Tab(self.tabs[10])
		self.Create_Advanced_Tab(self.tabs[11])
		self.logic_handler = Logic_Handler()

#Common Tools
	
	def Get_Future_Time(self,seconds,start=0):
		if(start==0):
			start = time.time() #hack so it actually calls time.time() when asked instead of taking startup time
		return time.ctime(start+seconds)

#Reputation Tab

	def Create_Reputation_Tab(self,tab):
		r = tab
		tk.Label(r,text='Starting Reputation').grid(row=0,column=0,sticky="NEWS")
		tk.Label(r,text='Desired Reputation').grid(row=1,column=0,sticky="NEWS")
		self.starting_rep = tk.DoubleVar()
		self.starting_rep.set(5000.0)
		self.desired_rep = tk.DoubleVar()
		self.desired_rep.set(7500.0)
		tk.Entry(r,textvariable=self.starting_rep).grid(row=0,column=1,sticky="NEWS")
		tk.Entry(r,textvariable=self.desired_rep).grid(row=1,column=1,sticky="NEWS")
		tk.Label(r,text='Hours been gaining rep').grid(row=0,column=2,sticky="NEWS")
		self.hours_been_gaining = tk.IntVar()
		self.hours_been_gaining.set(0)
		tk.Entry(r,textvariable=self.hours_been_gaining).grid(row=0,column=3,sticky="NEWS")
		tk.Label(r,text='Current rep/hour').grid(row=1,column=2,sticky="NEWS")
		self.current_rep_gain = tk.DoubleVar()
		self.current_rep_gain.set(1.0)
		tk.Entry(r,textvariable=self.current_rep_gain).grid(row=1,column=3,sticky="NEWS")
		tk.Label(r,text='Minutes played per day').grid(row=0,column=4,sticky="NEWS")
		self.minutes_played_per_day = tk.IntVar()
		self.minutes_played_per_day.set(60)
		tk.Entry(r,textvariable=self.minutes_played_per_day).grid(row=1,column=4,sticky="NEWS")
		tk.Button(r, text='Calculate Time Required', fg='red', command=self.Calculate_Reputation_Time).grid(row=2,column=0,columnspan=2,sticky="NEWS")
		self.rep_time_required = tk.IntVar()
		tk.Label(r,text='Required time (hours)').grid(row=3,column=0,sticky="NEWS")
		tk.Entry(r,textvariable=self.rep_time_required).grid(row=4,column=0,sticky="NEWS")
		self.rep_completion_date = tk.StringVar()
		tk.Label(r,text='Completion Date').grid(row=3,column=1,sticky="NEWS")
		tk.Entry(r,textvariable=self.rep_completion_date).grid(row=4,column=1,ipadx=10,sticky="NEWS")
		self.starting_rep_gain = tk.DoubleVar()
		self.rep_gain_increase = tk.DoubleVar()
		self.hours_per_rep_gain_increase = tk.IntVar()	
		self.max_rep_gain = tk.DoubleVar()
		self.below_this_rep_is_penalty = tk.DoubleVar()
		self.rep_penalty_scale = tk.DoubleVar()
		self.Set_Reputation_Settings()

	def Set_Default_Reputation_Settings(self):
		self.starting_rep_gain.set(100)#(1.0) 
		self.rep_gain_increase.set(25)#(0.25)
		self.hours_per_rep_gain_increase.set(1)#(4)
		self.max_rep_gain.set(300)#(10.0)
		self.below_this_rep_is_penalty.set(0.0)
		self.rep_penalty_scale.set(0.0001)

	def Set_Reputation_Settings(self):
		if(self.have_stored_reputation_settings==False):
			self.Set_Default_Reputation_Settings()
		if(self.have_stored_reputation_settings==True):
			self.starting_rep_gain.set(self.stored_starting_rep_gain.get())
			self.rep_gain_increase.set(self.stored_rep_gain_increase.get())
			self.hours_per_rep_gain_increase.set(self.stored_hours_per_rep_gain_increase.get())
			self.max_rep_gain.set(self.stored_max_rep_gain.get())
			self.below_this_rep_is_penalty.set(self.stored_below_this_rep_is_penalty.get())
			self.rep_penalty_scale.set(self.stored_rep_penalty_scale.get())

	def Rep_Penalty(self,current):
		if(current < self.below_this_rep_is_penalty.get()):
			penalty = self.rep_penalty_scale.get()*current # minus .25 for every 2500 below 0; current <0, so penalty is negative
			return penalty
		else:
			return 0.0

	def Calculate_Reputation_Time(self):
		current = self.starting_rep.get()
		desired = self.desired_rep.get()
		if(desired<current):
			self.rep_time_required.set(0)
			return 0
		time = 0
		time_gain = 0.0-self.starting_rep_gain.get()+self.current_rep_gain.get()
		while(current<desired): 
			base_gain = self.starting_rep_gain.get()+self.Rep_Penalty(current)
			gain = base_gain+time_gain
			if(gain>self.max_rep_gain.get()):
				gain = self.max_rep_gain.get()
			current += gain 
			time += 1
			if((time+self.hours_been_gaining.get())%self.hours_per_rep_gain_increase.get()==0):
				time_gain += self.rep_gain_increase.get()
		self.rep_time_required.set(time)
		if(self.minutes_played_per_day.get()==0):
			self.rep_completion_date.set('Never')
			return time
		hours_per_day = self.minutes_played_per_day.get()/60
		days_needed = time/hours_per_day
		self.rep_completion_date.set(self.Get_Future_Time(days_needed*86400))
		return time

#Travel Tab

	def Create_Travel_Tab(self,tab):
		tt = tab
		
		tk.Label(tt, text='km W of Thornkeep').grid(row=0, column=1,sticky="NEWS")
		tk.Label(tt, text='km N of Thornkeep').grid(row=0, column=2,sticky="NEWS")
		tk.Label(tt, text='Start Coordinates').grid(row=1, column=0,sticky="NEWS")
		tk.Label(tt, text='Destination Coordinates').grid(row=2, column=0,sticky="NEWS")
		self.old_coords = [ tk.DoubleVar(), tk.DoubleVar() ]
		self.new_coords = [ tk.DoubleVar(), tk.DoubleVar() ]
		tk.Entry(tt, textvariable=self.old_coords[0]).grid(row=1, column=1,sticky="NEWS")
		tk.Entry(tt, textvariable=self.old_coords[1]).grid(row=1, column=2,sticky="NEWS")
		tk.Entry(tt, textvariable=self.new_coords[0]).grid(row=2, column=1,sticky="NEWS")
		tk.Entry(tt, textvariable=self.new_coords[1]).grid(row=2, column=2,sticky="NEWS")
		tk.Button(tt, text='Distance (m)', command=self.Find_Thornkeep_Distance).grid(row=3, column=1, columnspan=2,sticky="NEWS")

		tk.Label(tt, text='Hex Number (W)').grid(row=0, column=4,sticky="NEWS")
		tk.Label(tt, text='Hex Number (N)').grid(row=0, column=5,sticky="NEWS")
		tk.Label(tt, text='Start Hex').grid(row=1, column=3,sticky="NEWS")
		tk.Label(tt, text='Destination Hex').grid(row=2, column=3,sticky="NEWS")
		self.old_hex = [ tk.IntVar(), tk.IntVar() ]
		self.new_hex = [ tk.IntVar(), tk.IntVar() ]
		tk.Entry(tt, textvariable=self.old_hex[0]).grid(row=1, column=4,sticky="NEWS")
		tk.Entry(tt, textvariable=self.old_hex[1]).grid(row=1, column=5,sticky="NEWS")
		tk.Entry(tt, textvariable=self.new_hex[0]).grid(row=2, column=4,sticky="NEWS")
		tk.Entry(tt, textvariable=self.new_hex[1]).grid(row=2, column=5,sticky="NEWS")
		tk.Button(tt, text='Center to center distance (m)', command=self.Find_Hex_Distance).grid(row=3, column=4, columnspan=2,sticky="NEWS")
		tk.Label(tt, text="Use Harad Navar's map for hex numbers").grid(row=4, column=4, columnspan=2,sticky="NEWS")
		#self.n_hexes = tk.IntVar() 
		#tk.Label(tt, text='Number of hexes').grid(row=4,column=3,sticky="NEWS")
		#tk.Entry(tt, textvariable=self.n_hexes).grid(row=4,column=4,sticky="NEWS")

		tk.Label(tt, text='Distance (m)').grid(row=4,column=0,sticky="NEWS")
		self.travel_distance = tk.DoubleVar()
		tk.Entry(tt,textvariable=self.travel_distance).grid(row=4,column=1,sticky="NEWS")
		tk.Label(tt, text='Encumbrance penalty').grid(row=5,column=0,sticky="NEWS")
		self.encumbrance_penalty = tk.DoubleVar()
		self.encumbrance_penalty.set(0.0)
		tk.Entry(tt,textvariable=self.encumbrance_penalty).grid(row=5,column=1,sticky="NEWS")
		weights = [0.0, 0.0, 1/6, 1/3]
		for i in range(len(armor_types)):
			tk.Radiobutton(tt, text=armor_types[i], variable=self.encumbrance_penalty, value=weights[i]).grid(row=6,column=i,sticky="NEWS")
		self.sprinting = tk.IntVar()
		self.sprinting.set(1)
		tk.Checkbutton(tt, text='Sprinting', variable=self.sprinting).grid(row=7,column=0,sticky="NEWS")
		tk.Button(tt, text='Calculate Travel Time', fg='red', command=self.Calculate_Travel_Time).grid(row=8,column=0,columnspan=2,sticky="NEWS")
		tk.Label(tt, text='Travel Time').grid(row=9,column=0,sticky="NEWS")
		self.travel_time = tk.StringVar()
		tk.Entry(tt,textvariable=self.travel_time).grid(row=10,column=0,sticky="NEWS")
		tk.Label(tt, text='Arrival Time').grid(row=9,column=1,sticky="NEWS")
		self.arrival_time = tk.StringVar()
		tk.Entry(tt,textvariable=self.arrival_time).grid(row=10,column=1,sticky="NEWS")
		self.base_travel_speed = tk.DoubleVar()
		self.Set_Travel_Settings()

	def Find_Thornkeep_Distance(self):
		self.travel_distance.set(1000*sqrt( pow(self.new_coords[0].get()-self.old_coords[0].get(),2)+pow(self.new_coords[1].get()-self.old_coords[1].get(),2) ))
		self.travel_distance.set(round(self.travel_distance.get()*100)/100)
		self.Calculate_Travel_Time()

	def Find_Hex_Distance(self): #~680m flat to flat, ~780m corner to corner, see http://www.drking.org.uk/hexagons/misc/dims.html
		delx = self.new_hex[0].get()-self.old_hex[0].get()
		x1 = self.old_hex[0].get()
		dx = 0.75*680*2*(1/sqrt(3))*delx #if delx==1, dx=0.5*780+0.25*780=0.75*780; if delx==2, dx=3s=1.5*780; repeat
		dely = self.new_hex[1].get()-self.old_hex[1].get()
		if(delx%2==0):
			dy = 680*dely
		else: 
			if(x1%2==0): #even
				dy = 680*max(abs(dely)-1,0)+340
			else: #odd
				dy = 680*max(abs(dely),0)+340
		#self.n_hexes.set(0) #TEMP
		self.travel_distance.set( sqrt(pow(dx,2)+pow(dy,2)) )
		self.travel_distance.set(round(self.travel_distance.get()*100)/100)
		self.Calculate_Travel_Time()

	def Calculate_Travel_Time(self):
		if(self.sprinting.get()==1):
			time_in_seconds = float(self.travel_distance.get())/(5/3*self.base_travel_speed.get()*(1.0-self.encumbrance_penalty.get()))
		else:
			time_in_seconds = float(self.travel_distance.get())/(self.base_travel_speed.get()*(1.0-self.encumbrance_penalty.get()))
		hours = int(time_in_seconds/3600) 
		minutes = int((time_in_seconds/60)%60)
		seconds = int(time_in_seconds%60)
		self.travel_time.set('%s h/%s m/%s s' %(hours, minutes, seconds) )
		if(self.travel_distance.get()==0):
			self.arrival_time.set('Now')
			return
		self.arrival_time.set(time.strftime("%H:%M:%S",time.localtime(time.time()+time_in_seconds)))
		return

	def Set_Default_Travel_Settings(self):
		self.base_travel_speed.set(4.44)

	def Set_Travel_Settings(self):
		if(self.have_stored_travel_settings==False):
			self.Set_Default_Travel_Settings()
		if(self.have_stored_travel_settings==True):
			self.base_travel_speed.set(self.stored_base_travel_speed.get())

#Training Tab

	def Convert_Hours_To_XP(self):
		self.hours_xp.set(self.hours_input.get()*self.hourly_xp_gain.get())
		
	def Convert_Days_To_XP(self):
		self.days_xp.set(self.days_input.get()*self.hourly_xp_gain.get()*24)

	def Convert_XP_To_Time(self):
		days = int(self.xp_input.get()/(24*self.hourly_xp_gain.get())) #full days
		hours = int((self.xp_input.get()/self.hourly_xp_gain.get())%24) #full hours mod 24
		minutes = int((60*self.xp_input.get()/self.hourly_xp_gain.get())%60)
		total_seconds = int(3600*self.xp_input.get()/self.hourly_xp_gain.get())
		seconds = int((3600*self.xp_input.get()/self.hourly_xp_gain.get())%60)
		self.xp_tuple.set('%s d/%s h/%s m/%s s' %(days, hours, minutes, seconds) )
		if(self.birthtime!=0):
			self.future_xp_time.set(self.Get_Future_Time(total_seconds,self.birthtime))
		else:
			self.future_xp_time.set(self.Get_Future_Time(total_seconds))

	def Time_From_Scratch(self):
		self.xp_input.set(max(self.xp_trained.get()-1000,0))
		self.Convert_XP_To_Time()

	def Time_Not_From_Scratch(self):
		self.xp_input.set(self.xp_difference.get())
		self.Convert_XP_To_Time()

	def Set_Default_XP_Settings(self):
		self.hourly_xp_gain.set(100)
		for feat in feat_list:
			feat.set_hourly_xp(self.hourly_xp_gain.get())

	def Set_XP_Settings(self):
		if(self.have_stored_xp_settings==False):
			self.Set_Default_XP_Settings()
		if(self.have_stored_xp_settings==True):
			self.hourly_xp_gain.set(self.stored_hourly_xp_gain.get())

	def Find_Feats(self,string):
		result = []
		for feat in feat_list:
			if string in feat.feat_type:
				result.append(feat)
		return result

	def Find_Feat(self,string):
		for feat in feat_list:
			if(string==feat.name):
				return feat 
		return 'None'

	def Find_Role(self,string):
		for role in role_list:
			if(string==role.name):
				return role
		return 'None'
	
	def Set_Training_Info(self, update_windows=True):
		for i in range(6):
			self.ability_scores[i].set(self.p.abilities[i])
		self.xp_trained.set(self.p.xp)
		self.xp_difference.set(self.xp_trained.get()-self.imported_xp_cost.get())
		self.message.set(self.p.message)
		if(update_windows):
			for i, role in enumerate(role_list):
				lvl1 = role.current_level
				role.check_level(self.p.trained, self.p.abilities)
				lvl2 = role.current_level
				if(lvl2>lvl1):
					last = self.completion_times[len(self.completion_times)-1]
					self.completion_times.append([last[0], '<'+role.name+' '+str(lvl2)+' @ '+last[1].split()[-1]])
				self.levels[i].set(role.current_level)
			self.Check_Suggestions_Existence()

	def Search_Trained_Feats(self,string):
		for trained in self.p.trained:
			if(string==trained[1]): # entry 1 is feat name
				return trained[2] # entry 2 is the level it is trained to
		return 0

	def Search_Roles(self,string):
		for role in role_list:
			if(string==role.name):
				#print(role.name, role.current_level)
				return role.current_level
		return 0

	def Check_Prerequisites(self,prerequisites): # a list of feats, each entry is a list of name and level
		if(len(prerequisites)==0):
			return True
		return self.logic_handler.handle(prerequisites,self.p.trained)

	def Check_Roles(self,roles):
		if(len(roles)==0):
			return True
		if(self.Search_Roles(roles[0][0])>=roles[0][1]):
			return True
		return False

	def Train_Feat(self,feat_name,sti=True,free=False):
		for feat in feat_list:
			if(feat.name==feat_name):
				if(feat.current_level==len(feat.xp_scaling)):
					self.p.message = '%s at max level' %feat.name
					break
				elif(self.Check_Prerequisites(feat.prerequisites[feat.current_level])):
					if(self.Check_Roles(feat.roles[feat.current_level])):
						lvl1 = feat.current_level
						self.p.Train(feat,free)
						lvl2 = feat.current_level
						if(lvl2==lvl1+1):
							if(self.p.xp<=1000):
								if(self.birthtime==0):
									birth = self.Get_Future_Time(0).split()
									year = str(birth[4])
									month = str('%02d' %time.strptime(birth[1],"%b")[1])
									day = str('%02d' %int(birth[2]))
									clock = str(birth[3])
									self.completion_times.append(['/'.join([year,month,day]),' @ '.join([feat.name+' '+str(lvl2),clock])])
									continue
								else:
									x = self.birthday.get().split()
									year = x[-2].split('/')[2]
									month = x[-2].split('/')[1]
									day = x[-2].split('/')[0]
									clock = x[-1]
									self.completion_times.append(['/'.join([year,month,day]),' @ '.join([feat.name+' '+str(lvl2),clock])])
									continue
							if(self.birthtime==0):
								self.birthtime = time.time() #default to now and only set once
							future = self.Get_Future_Time(3600*(self.p.xp-1000)/self.hourly_xp_gain.get(), self.birthtime).split()
							year = str(future[4])
							month = str('%02d' %time.strptime(future[1],"%b")[1])
							day = str('%02d' %int(future[2]))
							clock = str(future[3])
							self.completion_times.append(['/'.join([year,month,day]),' @ '.join([feat.name+' '+str(lvl2),clock])])
					else:
						self.p.message = 'Missing role. Press Info for details.'
				else:
					self.p.message = 'Missing prerequisites. Press Info for details.'
				break
		if(sti):
			self.Set_Training_Info()

	def Create_Feat_Printout_Button(self,tab,variable):
		cmd = lambda z=variable: Find_Linked_Feat(z.get()).printout()#self.Find_Feat(z.get()).printout() #linked feat
		but = tk.Button(tab, text='Info', command=cmd)
		return but

	def Create_Role_Printout_Button(self,tab,string):
		cmd = lambda z=string: self.Find_Role(z).printout()
		but = tk.Button(tab, text='Info', command=cmd)
		return but

	def Create_Training_Button(self,tab,feat_type,variable):
		cmd = lambda z=variable : self.Train_Feat(z.get())
		but = tk.Button(tab, text='Train %s' %feat_type, command=cmd)
		return but

	def Train_All(self):
		new_list = list(feat_list)
		race_list = ['Dwarven','Elven','Human']
		my_race = None
		for trained in self.p.trained:
			for race in race_list:
				if(race in trained[1]):
					my_race = race
					break
		for i in range(48): #max is Power at 40, then add 8 for safety
			for feat in new_list:
				n = feat.name.split()[0]
				if(n in race_list and my_race==None):
					my_race = n
				if(n in race_list and n!=my_race):
					new_list.remove(feat)
					continue
				if(feat.current_level==len(feat.xp_scaling)):
					new_list.remove(feat)
					continue #NEW
				self.Train_Feat(feat.name, False)
				for i, role in enumerate(role_list):
					role.check_level(self.p.trained, self.p.abilities)
			self.Set_Training_Info(False) #needs to be here or causes issues with roles
		self.Set_Training_Info()

	def Print_Training(self):
		self.p.Print_Training()

	def Print_Achievements(self):
		self.p.Print_Achievements()

	def Print_Untrained(self): #debug only
		results = []
		for feat in feat_list:
			if(feat.current_level<len(feat.xp_scaling)):
				#print(feat.feat_type, feat.name, feat.current_level, len(feat.xp_scaling))
				results.append([feat.feat_type, feat.name, feat.current_level, sum(feat.xp_scaling[:feat.current_level]), feat.xp_scaling[min(feat.current_level,len(feat.xp_scaling)-1)]])
		mw = Make_Message_Window()
		title = 'Untrained Feats'
		widths = [15,30,10,10,10]
		column_names = [ 'Feat Type', 'Feat Name', 'Level', 'XP spent' , 'XP next level' ]
		self.trained = sorted(results, key=lambda entry: entry[0])
		column_entries = [ trained for trained in results ]
		if(len(self.trained)==0):
			column_entries = [ ['none', 'none', 0, 0, 0] ]
		mw.update_columns(title, column_names, column_entries, widths)
		mw.new_window()

	def Reset_Training(self):
		for feat in feat_list:
			feat.reset()
		for role in role_list:
			role.reset()
		for i in range(len(role_list)):
			self.levels[i].set(0)
		self.p.Reset()
		self.imported_xp_cost.set(0)
		self.completion_times = []
		self.Set_Training_Info(False)

	#def Set_Default_Training_Settings(self):
	#	self.sorting_priority.set(0)
	#	self.p.sorting_priority = 0

	#def Set_Training_Settings(self):
	#	if(self.have_stored_training_settings==False):
	#		self.Set_Default_Training_Settings()
	#	if(self.have_stored_training_settings==True):
	#		self.sorting_priority.set(self.stored_sorting_priority.get())
	#		self.p.sorting_priority = self.sorting_priority.get() #perhaps a little redundant here with the variables

	def Next_Increase(self, feat):
		if(feat.xp_scaling[feat.current_level]==0 and feat.increase[feat.current_level]>0.0):
			return 0, float('inf'), feat.current_level+1
		if(feat.xp_scaling[feat.current_level]>0 and feat.increase[feat.current_level]>0.0):
			return feat.xp_scaling[feat.current_level], feat.increase[feat.current_level]/feat.xp_scaling[feat.current_level], feat.current_level+1
		if(feat.increase[feat.current_level]==0.0): #feats passed here are always below max level
			increase, xp = 0.0, 0
			for lvl in range(feat.current_level, len(feat.xp_scaling)):
				increase += feat.increase[lvl]
				xp += feat.xp_scaling[lvl]
				if(feat.increase[lvl]>0.0):
					break
			if(xp>0):
				return xp, increase/xp, lvl+1
			if(xp==0 and increase==0.0):
				return 0, 0, feat.current_level+1
			if(xp==0 and increase>0.0):
				return 0, float('inf'), lvl+1

	def Suggestions(self):
		ab = self.favorite_stat.get()
		score = find_abilities(ab) 
		new_list = []
		for feat in feat_list:
			if(score[0] in feat.increase_type):
				if(feat.current_level < len(feat.xp_scaling)):
					new_list.append(feat)
		priority_list = []
		width = 10
		for feat in new_list:
			if(self.include_expendables.get()==0 and (feat.feat_type=='Expendable' or feat.feat_type=='Expendables')):
				continue
			printout_string = ''
			for y in feat.prerequisites[feat.current_level]:
				printout_string += '%s=%s, ' %(y[0],y[1]) 
			printout_string = printout_string[:-2] #cut off last comma and space
			if(len(printout_string)>75):
				printout_string = '*** List too long. Use Info button. ***'
			width = max(width,len(printout_string)+5)
			ni = self.Next_Increase(feat)
			priority_list.append([feat.feat_type, feat.name, ni[0], ni[1], ni[2], printout_string])
		priority_list = sorted(priority_list, key=lambda entry: entry[3], reverse=True)
		mw = Make_Message_Window()
		title = 'Suggestions to increase %s' %ab
		widths = [15,35,20,30,10,width]
		column_names = [ 'Feat Type', 'Feat Name', 'XP cost (next level)', 'Increase per XP (next level only)', 'Next level which increases', 'Prerequisites' ] #XXXX
		column_entries = [ priority for priority in priority_list ]
		if(len(priority_list)==0):
			column_entries = [ ['none', 'none', 0, 0, 0, ''] ]
		mw.update_columns(title, column_names, column_entries, widths)
		self.suggestion_windows.append(mw)
		mw.new_window()

	def Find_Training_Plans(self):
		planning_directory = os.path.join(os.getcwd(),'training_plans')
		plan_list = []
		for x in os.listdir(planning_directory):
			plan_list.append(x)
		if(len(plan_list)==0):
			plan_list.append('None')
		return plan_list

	def Import_Training_Plan(self):
		self.Reset_Training()
		try: 
			file_name = os.path.join(os.path.join(os.getcwd(),'training_plans'), self.import_training_plan_name.get())
			fin = open(file_name,'r')
			training_plan = [ x.replace('\n','') for x in fin ]	
		except:
			self.message.set('Could not import %s' %self.import_training_plan_name.get())
			return
		racial_plan = self.Find_Race(training_plan)
		for i in range(len(training_plan)):
			if(training_plan[i] in racial_plan and self.Search_Trained_Feats(training_plan[i])==0): #here is the free level 2 clothing/armor bug
				try:
					self.Train_Feat(training_plan[i],True,True)
				except:
					self.message.set('Could not train %s' %feat_name)
					break
			else:
				try:
					self.Train_Feat(training_plan[i])
				except:
					self.message.set('Could not train %s' %feat_name)
					break
		self.imported_xp_cost.set(self.p.xp)
		self.Set_Training_Info()
		self.message.set('Finished training from %s' %self.import_training_plan_name.get())
		return

	def Find_Race(self, training_plan):
		racial_plans = []
		for file_name in os.listdir(os.path.join(os.getcwd(),'racial_feats')):
			fin = open(os.path.join(os.getcwd(),'racial_feats',file_name),'r')
			racial_plans.append([ x.replace('\n','') for x in fin ])
		for racial_plan in racial_plans:
			this_race = True
			for feat_name in racial_plan:
				if(feat_name not in training_plan):
					this_race = False
					break
			if(this_race):
				return racial_plan
		return []

	def Choose_Race(self):
		race_string = self.races[self.race_choice.get()]
		self.Reset_Training()
		try: 
			file_name = os.path.join(os.path.join(os.getcwd(),'racial_feats'), '%s.txt' %race_string)
			fin = open(file_name,'r')
			training_plan = [ x.replace('\n','') for x in fin ]	
		except:
			self.message.set('Could not import %s.txt' %race_string)
			return
		for i in range(len(training_plan)):
			try:
				self.Train_Feat(training_plan[i],True,True)
			except:
				self.message.set('Could not train %s' %feat_name)
				break
		self.imported_xp_cost.set(self.p.xp)
		self.Set_Training_Info()
		self.message.set('Finished training from %s.txt' %race_string)
		return

	def Set_Default_Training_Plan_Name(self):
		self.export_training_plan_name.set('training_plan')

	def Export_Training_Plan(self):
		x = self.export_training_plan_name.get()
		if(x==''):
			self.Set_Default_Training_Plan_Name()
			x = self.export_training_plan_name.get()
		fout = open(path.join(getcwd(), path.join('training_plans', '%s.txt' %x)),'w')
		for feat_name in self.p.training_plan:
			fout.write('%s\n' %feat_name)

	def Undo_Last_Trained_Feat(self):
		plan = [ feat_name for feat_name in self.p.training_plan ]
		self.Reset_Training()
		racial_plan = self.Find_Race(plan)
		for i in range(len(plan)-1):
			if(plan[i] in racial_plan):
				self.Train_Feat(plan[i],True,True)
			else:
				self.Train_Feat(plan[i])
		self.Set_Training_Info()
		self.message.set('Retrained all but last')

	def Check_Suggestions_Existence(self):#debugging
		for x in self.suggestion_windows:
			try:
				#print(x.root.state())
				if(x.root.state()=='normal'):
					#print(x.title)
					#print(find_abilities(x.title,True)[0])
					self.favorite_stat.set(find_abilities(x.title,True)[0])
					self.suggestion_windows.remove(x)
					try:
						x.root.destroy()
						del x
					except:					
						del x
					self.Suggestions()
			except:
				self.suggestion_windows.remove(x)
				del x

	def Common_Recipes(self):
		Print_Trained_Recipes(self.p.trained,'Common')

	def Uncommon_Recipes(self):
		Print_Trained_Recipes(self.p.trained,'Uncommon')

	def Pass_To_Crafting(self):
		have = [ trained for trained in self.p.trained if trained[0]=='Skills' ]
		names = [ trained[1] for trained in have ]
		for profession in profession_list:
			if profession not in names:
				index = profession_list.index(profession)
				self.crafting.include_professions[index].set(0)
				self.crafting.profession_levels[index].set(0)
		for trained in have:
			if(trained[1] in profession_list):
				index = profession_list.index(trained[1])
				self.crafting.include_professions[index].set(1)
				self.crafting.profession_levels[index].set(trained[2])
				self.crafting.skill_levels[index].set(max(10*trained[2],10))
		for name in names:#XXXX
			if 'Racial Benefit' in name:
				try:
					feat = Find_Linked_Feat(name)
					x = feat.wiki.effects[0].split(',')
					for y in x:
						y = y.split('+')
						number = int(y[1].lstrip().rstrip())
						skill = y[0].lstrip().rstrip()
						if skill in profession_list:
							index = profession_list.index(skill)
							z = (self.crafting.profession_levels[index].get()*10)+number
							z = max(z,10)
							self.crafting.skill_levels[index].set(z)
				except:
					pass
		self.crafting.pare_down()

	def Refresh_Training_Plans(self):
		new_plans = sorted(self.Find_Training_Plans())
		self.import_training_plan_name.set(new_plans[0])
		self.import_training_option_menu['menu'].delete(0, 'end')
		for name in new_plans:
			self.import_training_option_menu['menu'].add_command(label=name, command=tk._setit(self.import_training_plan_name, name))

	def calendar(self):
		w = test_calendar('XP Calendar')
		w.make(self.completion_times)

	def Find_Input_Birthdays(self):
		return([f.replace('\n','') for f in open(path.join(os.getcwd(),'birthdays.txt'),'r')])

	def Set_Birthday(self):
		x = self.birthday.get().split()
		y = datetime.strptime(x[-2]+':'+x[-1],"%d/%m/%Y:%H:%M:%S")
		self.birthtime = time.mktime(y.timetuple())
		training_plan = [x for x in self.p.training_plan]
		self.Reset_Training()
		racial_plan = self.Find_Race(training_plan)
		for i in range(len(training_plan)):
			if(training_plan[i] in racial_plan and self.Search_Trained_Feats(training_plan[i])==0):
				try:
					self.Train_Feat(training_plan[i],True,True)
				except:
					self.message.set('Could not train %s' %feat_name)
					break
			else:
				try:
					self.Train_Feat(training_plan[i])
				except:
					self.message.set('Could not train %s' %feat_name)
					break
		self.imported_xp_cost.set(self.p.xp)
		self.Set_Training_Info()

	def Find_Birthday(self):
		dt = max(self.xp_trained.get()+self.available_xp.get()-1000,0)/self.hourly_xp_gain.get() #in hours
		birth = self.Get_Future_Time(-dt*3600).split()
		year = str(birth[4])
		month = str('%02d' %time.strptime(birth[1],"%b")[1])
		day = str('%02d' %int(birth[2]))
		clock = str(birth[3])
		btuple = ' '.join([self.pc_name.get(), '/'.join([day,month,year]), clock])
		birthdays = self.Find_Input_Birthdays()
		birthdays.append(btuple)
		outfile = path.join(getcwd(), 'birthdays.txt')
		fout = open(outfile,'w')
		self.birth_option_menu['menu'].delete(0, 'end')
		for tup in birthdays:
			fout.write(tup)
			fout.write('\n')
			self.birth_option_menu['menu'].add_command(label=tup, command=tk._setit(self.birthday, tup))
		self.birthday.set(birthdays[-1]) #to set to the most recent one

	def Create_Training_Tab(self,tab):
		tt = tab
		self.p = Player()
		self.p.feat_types = feat_types

		self.list_of_feats = [ sorted([feat.name for feat in self.Find_Feats(feat_type)]) for feat_type in self.p.feat_types ]
		self.feat_variables = [ tk.StringVar() for i in range(len(self.p.feat_types)) ]
		for ft in range(len(self.p.feat_types)):
			self.feat_variables[ft].set(self.list_of_feats[ft][0])
			tk.OptionMenu(tt, self.feat_variables[ft], *self.list_of_feats[ft]).grid(row=ft,column=0,sticky="NEWS")
			self.Create_Feat_Printout_Button(tt,self.feat_variables[ft]).grid(row=ft,column=2,sticky="NEWS")
			self.Create_Training_Button(tt,self.p.feat_types[ft],self.feat_variables[ft]).grid(row=ft,column=1,sticky="NEWS")
		tk.Label(tt, text='Training note: ').grid(row=ft+1,column=0,sticky="NEWS")
		self.message = tk.StringVar()
		tk.Entry(tt, textvariable=self.message).grid(row=ft+1,column=1,ipadx=62,sticky="NEWS")

		tk.Label(tt,text='Time -> XP').grid(row=ft+3,column=0,sticky="NEWS")
		tk.Label(tt,text='XP').grid(row=0,column=3,sticky="NEWS")
		tk.Label(tt,text='Time (hours)').grid(row=ft+4,column=0,sticky="NEWS")
		self.hours_input = tk.IntVar()
		tk.Entry(tt,textvariable=self.hours_input).grid(row=ft+4,column=1,sticky="NEWS")
		tk.Button(tt, text='Convert', command=self.Convert_Hours_To_XP).grid(row=ft+4,column=2,sticky="NEWS")
		self.hours_xp = tk.IntVar()

		tk.Entry(tt,textvariable=self.hours_xp).grid(row=ft+4,column=3,sticky="NEWS")
		tk.Label(tt,text='Time (days)').grid(row=ft+5,column=0,sticky="NEWS")
		self.days_input = tk.IntVar()
		tk.Entry(tt,textvariable=self.days_input).grid(row=ft+5,column=1,sticky="NEWS")
		tk.Button(tt, text='Convert', command=self.Convert_Days_To_XP).grid(row=ft+5,column=2,sticky="NEWS")
		self.days_xp = tk.IntVar()
		tk.Entry(tt,textvariable=self.days_xp).grid(row=ft+5,column=3,sticky="NEWS")
		tk.Label(tt,text='XP -> Time').grid(row=ft+6,column=0,sticky="NEWS")
		tk.Label(tt,text='Time').grid(row=ft+6,column=3,sticky="NEWS")
		tk.Label(tt,text='XP').grid(row=ft+7,column=0,sticky="NEWS")
		self.xp_input = tk.IntVar()
		tk.Entry(tt,textvariable=self.xp_input).grid(row=ft+7,column=1,sticky="NEWS")
		tk.Button(tt, text='Convert', command=self.Convert_XP_To_Time).grid(row=ft+7,column=2,sticky="NEWS")
		self.xp_tuple = tk.StringVar()
		self.xp_tuple.set('')
		tk.Entry(tt,textvariable=self.xp_tuple).grid(row=ft+7,column=3,sticky="NEWS")
		tk.Label(tt,text='Date').grid(row=ft+6,column=4,sticky="NEWS")
		self.future_xp_time = tk.StringVar()
		tk.Entry(tt,textvariable=self.future_xp_time).grid(row=ft+7,column=4,ipadx=10,sticky="NEWS")
		self.hourly_xp_gain = tk.IntVar()
		tk.Button(tt, text='Time (from scratch)', command=self.Time_From_Scratch).grid(row=ft+8,column=1,sticky="NEWS")
		tk.Button(tt, text='Time (above training plan)', command=self.Time_Not_From_Scratch).grid(row=ft+9,column=1,sticky="NEWS")
		self.Set_XP_Settings()

		tk.Label(tt, text='Birth Time').grid(row=ft+3,column=3,sticky="NEWS")
		self.birthday = tk.StringVar()
		birthdays = self.Find_Input_Birthdays()
		self.birthday.set(birthdays[0])
		self.birthtime = 0 #unix time of birth
		self.birth_option_menu = tk.OptionMenu(tt, self.birthday, *birthdays)
		self.birth_option_menu.grid(row=ft+3,column=4,sticky="NEWS")
		tk.Button(tt, text='Set Birthday', command=self.Set_Birthday).grid(row=ft+3,column=5,sticky="NEWS")
		self.completion_times = []
		tk.Button(tt, text='Completion Calendar', command=self.calendar).grid(row=ft+4,column=4,rowspan=2,columnspan=2,sticky="NEWS")

		tk.Button(tt, text='Print Trained Feats', command=self.Print_Training).grid(row=0,column=5,sticky="NEWS")
		tk.Button(tt, text='Print Needed Achievements', command=self.Print_Achievements).grid(row=1,column=5,sticky="NEWS")
		tk.Button(tt, text='Train All Feats to Max', command=self.Train_All).grid(row=2,column=5,sticky="NEWS")
		tk.Button(tt, text='Reset', command=self.Reset_Training).grid(row=3,column=5,sticky="NEWS")
		tk.Label(tt, text='Total XP').grid(row=4,column=5,sticky="NEWS")
		self.xp_trained = tk.IntVar()
		tk.Entry(tt, textvariable=self.xp_trained).grid(row=5,column=5,sticky="NEWS")

		tk.Label(tt, text='Total XP').grid(row=ft+3,column=6,sticky="NEWS")
		tk.Label(tt, text='Available XP').grid(row=ft+4,column=6,sticky="NEWS")
		tk.Entry(tt, textvariable=self.xp_trained).grid(row=ft+3,column=7,sticky="NEWS")
		self.available_xp = tk.IntVar()
		self.available_xp.set(0)
		tk.Entry(tt, textvariable=self.available_xp).grid(row=ft+4,column=7,sticky="NEWS")
		tk.Label(tt, text='PC name').grid(row=ft+5,column=6,sticky="NEWS")
		self.pc_name = tk.StringVar()
		self.pc_name.set('PC name')
		tk.Entry(tt, textvariable=self.pc_name).grid(row=ft+5,column=7,sticky="NEWS")
		tk.Button(tt, text='Find Creation Time', command=self.Find_Birthday).grid(row=ft+6,column=6,columnspan=2,sticky="NEWS")

		tk.Button(tt, text='Free Recipes', command=self.Common_Recipes).grid(row=0,column=6,sticky="NEWS")
		tk.Button(tt, text='Trainable Recipes', command=self.Uncommon_Recipes).grid(row=1,column=6,sticky="NEWS")
		tk.Button(tt, text='Pass to Crafting tab', command=self.Pass_To_Crafting).grid(row=2,column=6,sticky="NEWS")
		tk.Button(tt, text='Print Untrained Feats', command=self.Print_Untrained).grid(row=3,column=6,sticky="NEWS")

		tk.Label(tt, text='Choose Race First', bg='red').grid(row=0,column=7,sticky="NEWS")
		self.races = ['Dwarf', 'Elf', 'Human']
		self.race_choice = tk.IntVar()
		self.race_choice.set(2)
		for i in range(len(self.races)):
			tk.Radiobutton(tt, text=self.races[i], variable=self.race_choice, value=i).grid(row=i+1,column=7,sticky="NEWS")
		tk.Button(tt, text='Choose', command=self.Choose_Race).grid(row=len(self.races)+1,column=7,sticky="NEWS")

		self.abilities = ['Strength','Dexterity','Constitution','Intelligence','Wisdom','Personality']
		self.ability_scores = [ tk.DoubleVar() for i in range(6) ]
		l = [ tk.Label(tt, text='%s' %self.abilities[i]).grid(row=i,column=3,sticky="NEWS") for i in range(6) ]  
		e = [ tk.Entry(tt, textvariable=self.ability_scores[i]).grid(row=i,column=4,sticky="NEWS") for i in range(6) ]
		tk.Label(tt, text='Stat to raise').grid(row=6,column=3,sticky="NEWS")
		self.favorite_stat = tk.StringVar()
		self.favorite_stat.set(self.abilities[0])
		tk.OptionMenu(tt, self.favorite_stat, *self.abilities).grid(row=6,column=4,sticky="NEWS")
		tk.Button(tt, text='Suggestions', command=self.Suggestions).grid(row=6,column=5,sticky="NEWS")
		self.include_expendables = tk.IntVar()
		self.include_expendables.set(1)
		tk.Checkbutton(tt, text='Include Expendables', variable=self.include_expendables).grid(row=6,column=6,sticky="NEWS")

		rn = [ tk.Label(tt, text='%s' %role_list[i].name).grid(row=i+7,column=3,sticky="NEWS") for i in range(len(role_list)) ]
		self.levels = [ tk.IntVar() for i in range(len(role_list)) ]
		re = [ tk.Entry(tt, textvariable=self.levels[i]).grid(row=i+7,column=4,sticky="NEWS") for i in range(len(role_list)) ]
		rb = [ self.Create_Role_Printout_Button(tt,role_list[i].name).grid(row=i+7,column=5,sticky="NEWS") for i in range(len(role_list)) ]

		tk.Label(tt, text='Input Training Plan').grid(row=len(role_list)+7,column=3,sticky="NEWS")
		self.import_training_plan_name = tk.StringVar()
		self.import_training_plan_name.set(sorted(self.Find_Training_Plans())[0])
		self.import_training_option_menu = tk.OptionMenu(tt, self.import_training_plan_name, *self.Find_Training_Plans())
		self.import_training_option_menu.grid(row=len(role_list)+7,column=4,sticky="NEWS")
		tk.Button(tt, text='Import', command=self.Import_Training_Plan).grid(row=len(role_list)+7,column=5,sticky="NEWS")
		tk.Button(tt, text='Refresh list', command=self.Refresh_Training_Plans).grid(row=len(role_list)+7,column=6,sticky="NEWS")

		tk.Label(tt, text='Input XP Cost/Difference').grid(row=len(role_list)+8,column=3,sticky="NEWS")
		self.imported_xp_cost = tk.IntVar()
		self.imported_xp_cost.set(0)
		tk.Entry(tt, textvariable=self.imported_xp_cost).grid(row=len(role_list)+8,column=4,sticky="NEWS")
		self.xp_difference = tk.IntVar()
		self.xp_difference.set(0)
		tk.Entry(tt, textvariable=self.xp_difference).grid(row=len(role_list)+8,column=5,sticky="NEWS")

		tk.Label(tt, text='Output Training Plan').grid(row=len(role_list)+9,column=3,sticky="NEWS")
		self.export_training_plan_name = tk.StringVar()
		self.Set_Default_Training_Plan_Name()
		tk.Entry(tt, textvariable=self.export_training_plan_name).grid(row=len(role_list)+9,column=4,sticky="NEWS")
		tk.Button(tt, text='Export', command=self.Export_Training_Plan).grid(row=len(role_list)+9,column=5,sticky="NEWS")
		tk.Button(tt, text='Undo Last Trained', command=self.Undo_Last_Trained_Feat).grid(row=len(role_list)+10,column=1,sticky="NEWS")
		
		#self.Set_Training_Settings()
		self.suggestion_windows = []
		self.Set_Training_Info(False)
		for role in role_list:
			for level in range(len(role.prerequisites)):
				for prerequisite in role.prerequisites[level]:
					feat = self.Find_Feat(prerequisite[0])
					to_break, previous = False, -1
					if(level>0):
						reverse_previous = [ level - lvl for lvl in range(1,level+1) ]#search lower level roles
						for rp in reverse_previous:
							for rp_prerequisite in role.prerequisites[rp]:
								if(feat.name==rp_prerequisite[0]):
									to_break, previous = True, rp_prerequisite[1]
									break
							if(to_break):
								break
					#print(role.name, level, feat.name, prerequisite[1], previous)
					if(previous==-1 or previous>prerequisite[1]-1): #covers the rogue screwup
						xp = 0
						for lvl in range(0,prerequisite[1]):
							xp += feat.xp_scaling[lvl]
					else:
						xp = 0
						for lvl in range(previous,prerequisite[1]):
							xp += feat.xp_scaling[lvl]
					role.add_xp(level+1,xp)

#Wiki Tab

	def Find_Attacks(self,string):
		result = []
		for attack in attack_list:
			if string in attack.attributes[11]:
				result.append(attack)
		return result

	def Find_Attack(self,attack_name):
		for attack in attack_list:
			if(attack.name==attack_name):
				return attack
		return None

	def Create_Attack_Printout_Button(self,tab,variable):
		cmd = lambda z=variable: self.Find_Attack(z.get()).printout()
		but = tk.Button(tab, text='Info', command=cmd)
		return but

	def Find_Expendables(self,string):
		result = []
		for expendable in expendable_list:
			if string in expendable.attributes[12]:
				result.append(expendable)
		return result

	def Find_Expendable(self,expendable_name):
		for expendable in expendable_list:
			if(expendable.name==expendable_name):
				return expendable
		return None

	def Create_Expendable_Printout_Button(self,tab,variable):
		cmd = lambda z=variable: self.Find_Expendable(z.get()).printout()
		but = tk.Button(tab, text='Info', command=cmd)
		return but

	def Find_Expendables_With_Keywords(self): 
		result = []
		for expendable in expendable_list:
			if(expendable.level>self.max_expendable_level.get()):
				continue
			matches = 0
			for keyword in self.expendables_keyword_list.get().split():
				if(keyword in expendable.keywords):
					matches += 1
			if(expendable.role==self.Find_Passive(self.feature_for_keywords.get()).role and matches>=self.minimum_matches.get()):
				result.append([expendable.name, expendable.implement, expendable.level, matches, expendable.damage_type, expendable.defense, expendable.factor, expendable.stamina, expendable.power])
		return result

	def Find_Attacks_With_Keywords(self):
		result = []
		for attack in attack_list:
			matches = 0
			tier = 1
			for keyword in self.attack_keywords_list:
				if(keyword[0] in attack.keywords[:self.max_attack_level.get()]):
					if(keyword[1]==0):
						matches += 1
					if(keyword[1]==1):
						matches += 4
						tier += 1
			if('Basic' in attack.name):
				matches = min(matches,1) #hack
				tier = 1
			if(attack.weapon in self.Find_Weapon(self.weapon_for_keywords.get()).weapon_types and matches>=self.minimum_matches.get()):
				result.append([attack.name, attack.form, attack.weapon, tier, matches, attack.damage_type, attack.defense, attack.factor, attack.stamina])
		return result

	def Find_Armor_Feats_With_Keywords(self):
		result = []
		for armor in self.armor_feat_list:
			for level in range(1,15):
				matches = 0
				for keyword in self.armor_gear_keywords_list:
					if(keyword[0] in armor.keywords[level-1]):
						if(keyword[1]==0):
							matches += 1
						if(keyword[1]==1):
							matches += 4
				if(matches>=self.minimum_matches.get()):
					hp = armor.hp_per_keyword*min(matches,12) #according to Stephen
					fort = armor.fort_per_keyword*min(matches,12)
					ref = armor.ref_per_keyword*min(matches,12)
					will = armor.will_per_keyword*min(matches,12)
					power = armor.power_per_keyword*min(matches,12)
					armor_gear = self.Find_Armor(self.armor_gear_for_keywords.get())
					physical = armor_gear.base_physical+min(matches,12)*armor_gear.physical_per_keyword
					energy = armor_gear.base_energy+min(matches,12)*armor_gear.energy_per_keyword
					afflicted = armor.afflicted_recovery_per_keyword*min(matches,12)
					bleeding = armor.bleeding_recovery_per_keyword*min(matches,12)
					burning = armor.burning_recovery_per_keyword*min(matches,12)
					drained = armor.drained_recovery_per_keyword*min(matches,12)
					exhausted = armor.exhausted_recovery_per_keyword*min(matches,12)
					frightened = armor.frightened_recovery_per_keyword*min(matches,12)
					oblivious = armor.oblivious_recovery_per_keyword*min(matches,12)
					razed = armor.razed_recovery_per_keyword*min(matches,12)
					slowed = armor.slowed_recovery_per_keyword*min(matches,12)
					if(self.include_passive_armor.get()==1):
						armor.get_armor_effect(level)
						fort += armor.extra_defense
						ref += armor.extra_defense
						will += armor.extra_defense
						physical += armor.extra_physical
						energy += armor.extra_energy
					if(self.include_recovery.get()==1):
						result.append([armor.name, level, matches, hp, fort, ref, will, power, physical, energy, afflicted, bleeding, burning, drained, exhausted, frightened, oblivious, razed, slowed])
					else:
						result.append([armor.name, level, matches, hp, fort, ref, will, power, physical, energy])
		return result

	def Find_Armor_Gear_With_Keywords(self):
		result = []
		for armor in armor_list:
			if(self.include_armor_tiers[armor.tier-1].get()==0):
				continue
			for bonus in range(4):
				matches = 0
				keywords = armor.inherent_keywords+armor.upgrade_keywords[:bonus+1]
				new_keywords = [ keyword.lstrip().rstrip() for keyword in keywords ]
				for kw in self.armor_feat_keywords_list:
					if(kw[0] in new_keywords and kw[1]==0):
						matches += 1
					if(kw[0] in new_keywords and kw[1]==1):
						matches += 4
				if(matches>=self.minimum_matches.get()):
					armor_feat = self.Find_Passive(self.armor_feat_for_keywords.get())
					hp = armor_feat.hp_per_keyword*min(matches,12) #according to Stephen
					fort = armor_feat.fort_per_keyword*min(matches,12)
					ref = armor_feat.ref_per_keyword*min(matches,12)
					will = armor_feat.will_per_keyword*min(matches,12)
					power = armor_feat.power_per_keyword*min(matches,12)
					physical = armor.base_physical+min(matches,12)*armor.physical_per_keyword
					energy = armor.base_energy+min(matches,12)*armor.energy_per_keyword
					afflicted = armor_feat.afflicted_recovery_per_keyword*min(matches,12)
					bleeding = armor_feat.bleeding_recovery_per_keyword*min(matches,12)
					burning = armor_feat.burning_recovery_per_keyword*min(matches,12)
					drained = armor_feat.drained_recovery_per_keyword*min(matches,12)
					exhausted = armor_feat.exhausted_recovery_per_keyword*min(matches,12)
					frightened = armor_feat.frightened_recovery_per_keyword*min(matches,12)
					oblivious = armor_feat.oblivious_recovery_per_keyword*min(matches,12)
					razed = armor_feat.razed_recovery_per_keyword*min(matches,12)
					slowed = armor_feat.slowed_recovery_per_keyword*min(matches,12)
					if(self.include_passive_armor.get()==1):
						armor_feat.get_armor_effect(self.armor_feat_level.get())
						fort += armor_feat.extra_defense
						ref += armor_feat.extra_defense
						will += armor_feat.extra_defense
						physical += armor_feat.extra_physical
						energy += armor_feat.extra_energy
					if(self.include_recovery.get()==1):
						result.append([armor.name, armor.type, armor.tier, bonus, matches, hp, fort, ref, will, power, physical, energy, afflicted, bleeding, burning, drained, exhausted, frightened, oblivious, razed, slowed])
					else:
						result.append([armor.name, armor.type, armor.tier, bonus, matches, hp, fort, ref, will, power, physical, energy])
		return result

	def Create_Expendables_With_Keywords_Message_Window(self):
		mw = Make_Message_Window()
		title = '%s %s keywords: ' %(self.feature_for_keywords.get(), self.feature_level.get())
		for keyword in self.expendables_keyword_list.get().split():
			title += '%s, ' %keyword
		title = title[:-2] #cut off comma and space
		column_names = [ 'Expendable', 'Implement', 'Level', 'Number of Matched Keywords', 'Relevant Resistance', 'Target Defense', 'Damage Factor', 'Stamina Cost', 'Power Cost' ]
		column_entries = sorted(self.Find_Expendables_With_Keywords(), key=lambda entry: entry[2], reverse=True)
		if(column_entries==[]):
			column_entries = [ ['None', 'None', 0, 0, 'N/A', 'N/A', 0.0, 0, 0] ]
		widths = [ 20, 15, 10, 10, 10, 10, 10, 10, 10 ]
		mw.update_columns(title, column_names, column_entries, widths)
		mw.add_library(expendable_list)
		mw.new_window('Expendable')

	def Create_Attacks_With_Keywords_Message_Window(self):
		mw = Make_Message_Window()
		title = '%s +%s keywords: ' %(self.weapon_for_keywords.get(), self.weapon_level.get())
		#sorted_list =  sorted([kw[0] for kw in self.attack_keywords_list])
		for kw in self.attack_keywords_list:
			if(kw[1]==0):
				title += '%s, ' %kw[0]
			if(kw[1]==1):
				title += '%s (major), ' %kw[0]
		title = title[:-2]
		column_names = [ 'Attack', 'Form', 'Weapon Category', 'Roll Tier', 'Number of Matched Keywords (major x4)', 'Relevant Resistance', 'Target Defense', 'Damage Factor', 'Stamina Cost' ]
		column_entries = sorted(self.Find_Attacks_With_Keywords(), key=lambda entry: entry[4], reverse=True)
		if(column_entries==[]):
			column_entries = [ ['None', 'None', 'None', 0, 0, 'N/A', 'N/A', 0.0, 0] ]
		widths = [ 20, 10, 25, 10, 10, 10, 10, 10, 10 ]
		mw.update_columns(title, column_names, column_entries, widths)
		mw.add_library(attack_list)
		mw.new_window('Attack')
		if(self.loop_all):
			mw.mw.save_as_csv()
			mw.root.destroy()

	def Create_Armor_Feats_With_Keywords_Message_Window(self):
		mw = Make_Message_Window()
		title = '%s +%s keywords: ' %(self.armor_gear_for_keywords.get(), self.armor_level.get())
		for kw in self.armor_gear_keywords_list:
			if(kw[1]==0):
				title += '%s, ' %kw[0]
			if(kw[1]==1):
				title += '%s (major), ' %kw[0]
		title = title[:-2]
		column_names = [ 'Armor Feat', 'Level', 'Number of Matched Keywords (major x4)', 'Extra hp', 'Extra Fort', 'Extra Ref', 'Extra Will', 'Extra Power', 'Physical Resistance', 'Energy Resistance']
		if(self.include_recovery.get()==1):
			column_names += ['Afflicted Rec.', 'Bleeding Rec.', 'Burning Rec.', 'Drained Rec.', 'Exhausted Rec.', 'Frightened Rec.', 'Oblivious Rec.', 'Razed Rec.', 'Slowed Rec.' ]
		column_entries = sorted(self.Find_Armor_Feats_With_Keywords(), key=lambda entry: entry[2], reverse=True)
		if(column_entries==[]):
			if(self.include_recovery.get()==1):
				column_entries = [ ['None',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0] ]
			else:
				column_entries = [ ['None',0,0,0,0,0,0,0,0,0] ]
		if(self.include_recovery.get()==1):
			widths = [20, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10]
		else:
			widths = [20, 10, 10, 10, 10, 10, 10, 10, 10, 10]
		mw.update_columns(title, column_names, column_entries, widths)
		if(self.include_passive_armor.get()==1):
			if(self.include_recovery.get()==1):
				mw.new_window('Armor Rec')
			else:
				mw.new_window('Armor')
		else:
			mw.new_window()#would be wrong if didn't include

	def Create_Armor_Gear_With_Keywords_Message_Window(self):
		mw = Make_Message_Window()
		title = '%s %s keywords: ' %(self.armor_feat_for_keywords.get(), self.armor_feat_level.get())
		for kw in self.armor_feat_keywords_list:
			if(kw[1]==0):
				title += '%s, ' %kw[0]
			if(kw[1]==1):
				title += '%s (major), ' %kw[0]
		title = title[:-2]
		column_names = [ 'Armor Gear', 'Type', 'Tier', 'Bonus', 'Number of Matched Keywords (major x4)', 'Extra hp', 'Extra Fort', 'Extra Ref', 'Extra Will', 'Extra Power', 'Physical Resistance', 'Energy Resistance']
		if(self.include_recovery.get()==1):
			column_names += ['Afflicted Rec.', 'Bleeding Rec.', 'Burning Rec.', 'Drained Rec.', 'Exhausted Rec.', 'Frightened Rec.', 'Oblivious Rec.', 'Razed Rec.', 'Slowed Rec.' ]
		column_entries = sorted(self.Find_Armor_Gear_With_Keywords(), key=lambda entry: entry[4], reverse=True)
		if(column_entries==[]):
			if(self.include_recovery.get()==1):
				column_entries = [ ['None','None',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0] ]
			else:
				column_entries = [ ['None','None',0,0,0,0,0,0,0,0,0,0] ]
		if(self.include_recovery.get()==1):
			widths = [25, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10]
		else:
			widths = [25, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10]
		mw.update_columns(title, column_names, column_entries, widths)
		if(self.include_passive_armor.get()==1):
			if(self.include_recovery.get()==1):
				mw.new_window('Armor Rec')
			else:
				mw.new_window('Armor')
		else:
			mw.new_window()#would be wrong if didn't include

	def Add_Keywords_From_Feature(self):
		self.expendables_keyword_list.set('')
		keywords = self.Find_Passive(self.feature_for_keywords.get()).keywords[self.feature_level.get()-1].split(',')
		stripped_keywords = [ kw.lstrip().rstrip() for kw in keywords ]
		stripped_keywords = sorted(list(set(stripped_keywords))) #make unique, just in case
		for kw in stripped_keywords:
			if('N/A' in kw):
				continue
			self.expendables_keyword_list.set('%s %s' %(self.expendables_keyword_list.get(), kw))
		self.Create_Expendables_With_Keywords_Message_Window()

	def Add_Keywords_From_Weapon(self):
		self.attack_keywords_list = [] #reset it
		weapon = self.Find_Weapon(self.weapon_for_keywords.get())
		inherent_keywords = weapon.inherent_keywords #material and majors
		if(len(inherent_keywords)>0):
			for kw in inherent_keywords:
				if(kw==''):
					continue
				KW = self.Find_Weapon_Keyword(kw.lstrip().rstrip())
				if(KW.value=='Advanced'):
					self.attack_keywords_list.append([KW.name,1])
		upgrade_keywords = weapon.upgrade_keywords #all minors
		upgrade_keywords = upgrade_keywords[:self.weapon_level.get()+1]
		for kw in upgrade_keywords:
			self.attack_keywords_list.append([kw.lstrip().rstrip(),0])
		self.Create_Attacks_With_Keywords_Message_Window() 

	def Find_Weapon_Keyword(self, name):
		for keyword in keyword_as_class_list:
			if(keyword.name==name and keyword.gear=='Weapon'):
				return keyword
		return None

	def Add_Keywords_From_Armor_Gear(self):
		self.armor_gear_keywords_list = []
		armor_gear = self.Find_Armor(self.armor_gear_for_keywords.get())
		inherent_keywords = armor_gear.inherent_keywords
		if(len(inherent_keywords)>0):
			for kw in inherent_keywords:
				if(kw==''):
					continue
				KW = self.Find_Armor_Keyword(kw.lstrip().rstrip())
				if(KW.value=='Basic'):
					self.armor_gear_keywords_list.append([KW.name,0])
				if(KW.value=='Advanced'):
					self.armor_gear_keywords_list.append([KW.name,1])
		upgrade_keywords = armor_gear.upgrade_keywords
		upgrade_keywords = upgrade_keywords[:self.armor_level.get()+1]
		for kw in upgrade_keywords:
			self.armor_gear_keywords_list.append([kw.lstrip().rstrip(),0])
		self.Create_Armor_Feats_With_Keywords_Message_Window()

	def Add_Keywords_From_Armor_Feat(self):
		self.armor_feat_keywords_list = []
		armor_feat = self.Find_Passive(self.armor_feat_for_keywords.get())
		level = self.armor_feat_level.get()
		keywords = armor_feat.keywords[level-1].split(',') #string
		if(len(keywords)>0):
			for kw in keywords:
				if(kw==''):
					continue
				KW = self.Find_Armor_Keyword(kw.lstrip().rstrip())

				if(KW.value=='Advanced'):
					self.armor_feat_keywords_list.append([KW.name,1])
				if(KW.value=='Basic'):
					self.armor_feat_keywords_list.append([KW.name,0])
		self.Create_Armor_Gear_With_Keywords_Message_Window()

	def Find_Armor_Keyword(self,name):
		for keyword in keyword_as_class_list:
			if(keyword.name==name and keyword.gear=='Armor'):
				return keyword
		return None

	def Add_Expendable(self):
		u = ( self.current_expendable.get().replace(' ','_')+' '+self.expendables_list.get() ).split()
		self.expendables_list.set( ' '.join(sorted(list(set(u)))).lstrip() ) 

	def Add_Weapon(self):
		u = ( self.current_attack.get().replace(' ','_')+' '+self.attacks_list.get() ).split()
		self.attacks_list.set( ' '.join(sorted(list(set(u)))).lstrip() ) 

	def Reset_Expendables(self):
		self.expendables_list.set('') 

	def Reset_Attacks(self):
		self.attacks_list.set('')

	def Appropriate_Features(self):
		if(self.expendables_list.get()==''):
			return
		e_keywords , e_names, p_keywords, p_levels, p_names = [], [], [], [], []
		title = 'Matching Keywords for: '
		widths = [30,10]
		column_names = ['Passive','Level']
		column_entries = []
		for expendable_name in self.expendables_list.get().split():
			name = expendable_name.replace('_',' ')
			exp = self.Find_Expendable(name)#.replace('_',' ')) #undo the above
			if(exp==None):
				continue
			title += name+' '
			widths.append(10)
			e_keywords.append(exp.keywords)
			column_names.append('%s (%s)' %(name,exp.level))
			e_names.append(exp.name)
		column_names.append('Total Matched')
		widths.append(10)
		if(len(e_names)==0):
			return
		for passive_name in self.feature_list: #perhaps redundant finding twice!
			passive = self.Find_Passive(passive_name)
			for level in range(len(passive.keywords)):	
				p_keywords.append([kw.lstrip().rstrip() for kw in passive.keywords[level].split(',')]) #(convert string to list)
				p_levels.append(level+1)
				p_names.append(passive.name)
		for j in range(len(p_keywords)): #rows	
			y = [p_names[j],p_levels[j]]
			for i in range(len(e_keywords)): #columns
				x = [val for val in p_keywords[j] if val in e_keywords[i]]
				y.append(len(x))
			if(sum(y[2:])>=self.minimum_matches.get()):
				y.append(sum(y[2:]))
				column_entries.append(y)
		if(len(column_entries)==0):
			y = [ 'No matches', '0']
			for n in range(len(e_names)):
				y.append(0)
			column_entries.append(y)
		mw = Make_Message_Window()
		mw.update_columns(title, column_names, sorted(column_entries, key=lambda entry: entry[-1], reverse=True), widths)
		mw.new_window()

	def Appropriate_Weapons(self):
		if(self.attacks_list.get()==''):
			return
		a_keywords , a_names, w_keywords, w_levels, w_names, w_tiers = [], [], [], [], [], []
		title = 'Matching Keywords for: '
		widths = [30,10,10]
		column_names = ['Weapon','Bonus','Tier']
		column_entries = []
		for attack_name in self.attacks_list.get().split():
			name = attack_name.replace('_',' ').lstrip().rstrip()
			att = self.Find_Attack(name) 
			if(att==None):
				continue
			title += name+' '
			widths.append(10)
			if('Basic' in attack_name):
				a_keywords.append(att.keywords[:1])
			else:
				a_keywords.append(att.keywords[:self.max_attack_level.get()])
			column_names.append(name)
			a_names.append(att.name)
		column_names.append('Total Matched')
		widths.append(10)
		if(len(a_names)==0):
			return
		for weapon_name in weapon_names:
			weapon = self.Find_Weapon(weapon_name)
			for level in range(4):	
				w_keywords.append([kw.lstrip().rstrip() for kw in weapon.inherent_keywords+weapon.upgrade_keywords[:level+1]])
				w_levels.append(level)
				w_names.append(weapon.name)
				w_tiers.append(weapon.tier)
		for j in range(len(w_keywords)): #rows
			y = [w_names[j], w_levels[j], w_tiers[j]]
			for i in range(len(a_keywords)): #columns
				x = [val for val in w_keywords[j] if val in a_keywords[i]]
				value = 0
				for kw in x:
					if(kw==''):
						continue
					KW = self.Find_Weapon_Keyword(kw)
					if(KW.value=='Advanced'):
						value += 4
					if(KW.value=='Basic' and KW.notes!='Material'):
						value += 1
				y.append(value)
			if(sum(y[3:])>=self.minimum_matches.get()): 
				y.append(sum(y[3:]))
				column_entries.append(y)
		if(len(column_entries)==0):
			y = [ 'No matches', '0', '0']
			for n in range(len(a_names)):
				y.append(0)
			column_entries.append(y)
		mw = Make_Message_Window()
		mw.update_columns(title, column_names, sorted(column_entries, key=lambda entry: entry[-1], reverse=True), widths)
		mw.new_window()

	def Find_Passives(self,string):
		result = []
		for passive in passive_list:
			if string in passive.attributes[1]:
				result.append(passive)
		return result

	def Find_Passive(self,passive_name):
		for passive in passive_list:
			if(passive.name==passive_name):
				return passive
		return None

	def Create_Passive_Printout_Button(self,tab,variable):
		cmd = lambda z=variable: self.Find_Passive(z.get()).printout()
		but = tk.Button(tab, text='Info', command=cmd)
		return but

	def Find_Keyword_As_Class(self, keyword_name): #get passed name (gear)
		name = ' '.join(keyword_name.split()[:-1])
		gear = str(keyword_name.split()[-1]).replace('(','').replace(')','')
		for keyword in keyword_as_class_list:
			if(keyword.name==name and keyword.gear==gear):
				return keyword
		return None

	def Print_Keyword_Info(self):
		self.Find_Keyword_As_Class(self.keyword_variable.get()).printout()

	def Find_Weapon(self,weapon_name):
		for weapon in weapon_list:
			if(weapon.name==weapon_name):
				return weapon
		return None

	def Print_Weapon_Info(self):
		self.Find_Weapon(self.weapon_variable.get()).printout()

	def Find_Armors(self,string):
		result = []
		for armor in armor_list:
			if string==armor.type:
				result.append(armor)
		return result

	def Find_Armor(self,armor_name):
		for armor in armor_list:
			if(armor.name==armor_name):
				return armor
		return None

	def Create_Armor_Printout_Button(self,tab,variable):
		cmd = lambda z=variable: self.Find_Armor(z.get()).printout()
		but = tk.Button(tab, text='Info', command=cmd)
		return but

	def Refresh_Attacks(self):
		weapon = self.chosen_weapon.get()
		new_attack_names = []
		for name in attack_names:
			attack = self.Find_Attack(name)
			if attack.weapon==weapon:
				new_attack_names.append(name)
		new_attack_names = sorted(new_attack_names)
		self.current_attack.set(new_attack_names[0])
		self.attack_option_menu['menu'].delete(0, 'end')
		for name in new_attack_names:
			self.attack_option_menu['menu'].add_command(label=name, command=tk._setit(self.current_attack, name))

	def Refresh_Expendables(self):
		max_level = self.max_expendable_level.get()
		implement = self.chosen_implement.get()
		new_expendable_names = []	
		for name in expendable_names:
			expendable = self.Find_Expendable(name)
			if expendable.implement not in ['Grenade','Potion','Misc Alchemy','Token' ]:
				if expendable.level <= max_level and expendable.implement==implement:
					new_expendable_names.append(name)
		new_expendable_names = sorted(new_expendable_names)
		self.current_expendable.set(new_expendable_names[0])
		self.expendable_option_menu['menu'].delete(0, 'end')
		for exp in new_expendable_names:
			self.expendable_option_menu['menu'].add_command(label=exp, command=tk._setit(self.current_expendable, exp))

	def Create_Wiki_Tab(self,tab):
		self.loop_all = False
		t = tab
		self.list_of_attacks = [ sorted([attack.name for attack in self.Find_Attacks(weapon_type)]) for weapon_type in weapon_types ]
		self.attack_variables = [ tk.StringVar() for i in range(len(weapon_types)) ]
		for at in range(len(weapon_types)):
			self.attack_variables[at].set(self.list_of_attacks[at][0])
			tk.OptionMenu(t, self.attack_variables[at], *self.list_of_attacks[at]).grid(row=at,column=0,sticky="NEWS")
			tk.Label(t, text=weapon_types[at], relief='sunken').grid(row=at,column=1,sticky="NEWS")
			self.Create_Attack_Printout_Button(t,self.attack_variables[at]).grid(row=at,column=2,sticky="NEWS")
		self.list_of_expendables = [ sorted([expendable.name for expendable in self.Find_Expendables(implement_type)]) for implement_type in implement_types ]
		self.expendable_variables = [ tk.StringVar() for i in range(len(implement_types)) ]
		for et in range(len(implement_types)):
			self.expendable_variables[et].set(self.list_of_expendables[et][0])
			tk.OptionMenu(t, self.expendable_variables[et], *self.list_of_expendables[et]).grid(row=et,column=3,sticky="NEWS")
			tk.Label(t, text=implement_types[et], relief='sunken').grid(row=et,column=4,sticky="NEWS")
			self.Create_Expendable_Printout_Button(t,self.expendable_variables[et]).grid(row=et,column=5,sticky="NEWS")
		self.list_of_passives = [ sorted([passive.name for passive in self.Find_Passives(passive_type)]) for passive_type in passive_types ]
		self.passive_variables = [ tk.StringVar() for i in range(len(passive_types)) ]
		for pt in range(len(passive_types)):
			self.passive_variables[pt].set(self.list_of_passives[pt][0])
			tk.OptionMenu(t, self.passive_variables[pt], *self.list_of_passives[pt]).grid(row=pt,column=6,sticky="NEWS")
			tk.Label(t, text=passive_types[pt], relief='sunken').grid(row=pt,column=7,sticky="NEWS")
			self.Create_Passive_Printout_Button(t,self.passive_variables[pt]).grid(row=pt,column=8,sticky="NEWS")
		self.keyword_variable = tk.StringVar()
		self.keyword_variable.set(keyword_as_class_names[0])
		tk.OptionMenu(t, self.keyword_variable, *keyword_as_class_names).grid(row=len(passive_types)+1,column=6,sticky="NEWS")
		tk.Label(t, text='Keywords', relief='sunken').grid(row=len(passive_types)+1,column=7,sticky="NEWS")
		tk.Button(t, text='Info', command=self.Print_Keyword_Info).grid(row=len(passive_types)+1,column=8,sticky="NEWS")
		self.weapon_variable = tk.StringVar()
		self.weapon_variable.set(weapon_names[0])
		tk.OptionMenu(t, self.weapon_variable, *weapon_names).grid(row=len(passive_types)+3,column=6,sticky="NEWS")
		tk.Label(t, text='Weapons', relief='sunken').grid(row=len(passive_types)+3,column=7,sticky="NEWS")
		tk.Button(t, text='Info', command=self.Print_Weapon_Info).grid(row=len(passive_types)+3,column=8,sticky="NEWS")
		self.armor_variables = [ tk.StringVar() for i in range(len(armor_types)) ]
		self.list_of_armors = [ sorted([armor.name for armor in self.Find_Armors(armor_type)]) for armor_type in armor_types ]
		for at in range(len(armor_types)):
			self.armor_variables[at].set(self.list_of_armors[at][0])
			tk.OptionMenu(t, self.armor_variables[at], *self.list_of_armors[at]).grid(row=len(passive_types)+5+at,column=6,sticky="NEWS")
			tk.Label(t, text=armor_types[at], relief='sunken').grid(row=len(passive_types)+5+at,column=7,sticky="NEWS")
			self.Create_Armor_Printout_Button(t,self.armor_variables[at]).grid(row=len(passive_types)+5+at,column=8,sticky="NEWS")

		tk.Label(t, text='Expendable <-> Feature keyword matching', relief='sunken').grid(row=8,column=3,columnspan=3,sticky="NEWS")
		self.expendables_keyword_list = tk.StringVar()
		self.expendables_keyword_list.set('')
		self.feature_list = sorted([ passive.name for passive in self.Find_Passives('Feature') ])
		self.feature_for_keywords = tk.StringVar()
		self.feature_for_keywords.set(self.feature_list[0])
		tk.OptionMenu(t, self.feature_for_keywords, *self.feature_list).grid(row=9,column=3,sticky="NEWS")
		self.feature_level = tk.IntVar()
		self.feature_level.set(1)
		tk.OptionMenu(t, self.feature_level, *[i for i in range(1,12)]).grid(row=9,column=4,sticky="NEWS")
		tk.Button(t, text='Find Expendables with Keywords', fg='blue', command=self.Add_Keywords_From_Feature).grid(row=9,column=5,sticky="NEWS")

		tk.Label(t, text='Attack <-> Weapon keyword matching', relief='sunken').grid(row=14,column=3,columnspan=3,sticky="NEWS")
		self.attack_keywords_list = [] #list with [name, type (major, minor, material)]
		self.weapon_for_keywords = tk.StringVar()
		self.weapon_for_keywords.set(weapon_names[0])
		tk.OptionMenu(t, self.weapon_for_keywords, *weapon_names).grid(row=15,column=3,sticky="NEWS")
		self.weapon_level = tk.IntVar()
		self.weapon_level.set(0)
		tk.OptionMenu(t, self.weapon_level, *[i for i in range(4)]).grid(row=15,column=4,sticky="NEWS")
		tk.Button(t, text='Find Attacks with Keywords', fg='blue', command=self.Add_Keywords_From_Weapon).grid(row=15,column=5,sticky="NEWS")

		self.armor_feat_list = [ passive for passive in self.Find_Passives('Armor') ]
		tk.Label(t, text='Armor keyword matching', relief='sunken').grid(row=len(passive_types)+9,column=6,columnspan=3,sticky="NEWS")
		self.armor_gear_keywords_list = []
		self.armor_gear_for_keywords = tk.StringVar()
		self.armor_gear_for_keywords.set(armor_names[0])
		tk.OptionMenu(t, self.armor_gear_for_keywords, *armor_names).grid(row=len(passive_types)+10,column=6,sticky="NEWS")
		self.armor_level = tk.IntVar()
		self.armor_level.set(0)
		tk.OptionMenu(t, self.armor_level, *[i for i in range(4)]).grid(row=len(passive_types)+10,column=7,sticky="NEWS")
		self.include_armor_tiers = [tk.IntVar() for i in range(3)]
		self.include_armor_tiers[0].set(1)
		self.include_armor_tiers[1].set(0)
		self.include_armor_tiers[2].set(0)
		for i in range(3):
			tk.Checkbutton(t, text='Tier %s' %(i+1), variable=self.include_armor_tiers[i]).grid(row=len(passive_types)+11,column=6+i,sticky="NEWS")
		tk.Button(t, text='Find Armor Feats with Keywords', fg='blue', command=self.Add_Keywords_From_Armor_Gear).grid(row=len(passive_types)+10,column=8,sticky="NEWS")

		self.armor_feat_names = sorted([ passive.name for passive in self.Find_Passives('Armor') ])
		self.armor_feat_keywords_list = []
		self.armor_feat_for_keywords = tk.StringVar()
		self.armor_feat_for_keywords.set(self.armor_feat_names[0])
		tk.OptionMenu(t, self.armor_feat_for_keywords, *self.armor_feat_names).grid(row=len(passive_types)+12,column=6,sticky="NEWS")
		self.armor_feat_level = tk.IntVar()
		self.armor_feat_level.set(1)
		tk.OptionMenu(t, self.armor_feat_level, *[i for i in range(1,15)]).grid(row=len(passive_types)+12,column=7,sticky="NEWS")
		tk.Button(t, text='Find Appropriate Armor Gear', fg='blue', command=self.Add_Keywords_From_Armor_Feat).grid(row=len(passive_types)+12,column=8,sticky="NEWS")
		self.include_passive_armor = tk.IntVar()
		self.include_passive_armor.set(1)
		tk.Checkbutton(t, text='Include Passive Armor Effects', variable=self.include_passive_armor).grid(row=len(passive_types)+13,column=8,sticky="NEWS")
		self.include_recovery = tk.IntVar()
		self.include_recovery.set(0)
		tk.Checkbutton(t, text='Show Recovery Bonuses', variable=self.include_recovery).grid(row=len(passive_types)+13,column=6,sticky="NEWS")

		self.expendables_list = tk.StringVar()
		self.expendables_list.set('')
		self.current_expendable = tk.StringVar()
		new_expendable_names = [ ]	
		for name in expendable_names:
			if self.Find_Expendable(name).implement not in ['Grenade','Potion','Misc Alchemy','Token' ]:
				new_expendable_names.append(name)
		self.current_expendable.set(sorted(new_expendable_names)[0])
		self.expendable_option_menu = tk.OptionMenu(t, self.current_expendable, *sorted(new_expendable_names))
		self.expendable_option_menu.grid(row=10,column=3,sticky="NEWS") #XXXXXX
		tk.Button(t, text='Add', command=self.Add_Expendable).grid(row=10,column=4,sticky="NEWS")
		tk.Button(t, text='Reset', command=self.Reset_Expendables).grid(row=10,column=5,sticky="NEWS")
		tk.Entry(t, textvariable=self.expendables_list).grid(row=13,column=3,columnspan=3,sticky="NEWS")
		tk.Button(t, text='Appropriate features for following expendables', fg='blue', command=self.Appropriate_Features).grid(row=12,column=5,sticky="NEWS")
		self.max_expendable_level = tk.IntVar()
		self.max_expendable_level.set(9)
		tk.Label(t, text='Max Expendable Level in Searches', relief='sunken').grid(row=11,column=3,sticky="NEWS")
		tk.OptionMenu(t, self.max_expendable_level, *[i for i in range(1,10)]).grid(row=11,column=4,sticky="NEWS")
		tk.Button(t, text='Refresh Expendable List', command=self.Refresh_Expendables).grid(row=11,column=5,sticky="NEWS")
		consume = ['Grenade','Potion','Misc Alchemy','Token']
		new_implement_types = sorted([ imp for imp in implement_types if imp not in consume ])
		self.chosen_implement = tk.StringVar()
		self.chosen_implement.set(new_implement_types[0])
		tk.Label(t, text='Implement', relief='sunken').grid(row=12,column=3,sticky="NEWS")
		tk.OptionMenu(t, self.chosen_implement, *new_implement_types).grid(row=12,column=4,sticky="NEWS")

		self.attacks_list = tk.StringVar()
		self.attacks_list.set('')
		self.current_attack = tk.StringVar()
		self.current_attack.set(attack_names[0])
		self.attack_option_menu = tk.OptionMenu(t, self.current_attack, *attack_names)
		self.attack_option_menu.grid(row=16,column=3,sticky="NEWS")
		tk.Button(t, text='Add', command=self.Add_Weapon).grid(row=16,column=4,sticky="NEWS")
		tk.Button(t, text='Reset', command=self.Reset_Attacks).grid(row=16,column=5,sticky="NEWS")
		tk.Entry(t, textvariable=self.attacks_list).grid(row=19,column=3,columnspan=3,sticky="NEWS")
		tk.Button(t, text='Appropriate weapons for following attacks', fg='blue', command=self.Appropriate_Weapons).grid(row=18,column=5,sticky="NEWS")
		tk.Label(t, text='Weapon Type', relief='sunken').grid(row=18, column=3, sticky="NEWS")
		weapons = sorted([weapon for weapon in weapon_types if 'Utility' not in weapon])
		self.chosen_weapon = tk.StringVar()
		self.chosen_weapon.set(weapons[0])
		tk.OptionMenu(t, self.chosen_weapon, *weapons).grid(row=18,column=4,sticky="NEWS")
		tk.Button(t, text='Refresh Attack List', command=self.Refresh_Attacks).grid(row=17,column=5,sticky="NEWS")
		self.max_attack_level = tk.IntVar()
		self.max_attack_level.set(6)
		tk.Label(t, text='Max Attack Level in Searches',relief='sunken').grid(row=17,column=3,sticky="NEWS")
		tk.OptionMenu(t, self.max_attack_level, *[i for i in range(1,7)]).grid(row=17,column=4,sticky="NEWS")

		tk.Label(t,text='Minimum number of matches for all searches',relief='sunken').grid(row=20,column=6,columnspan=2,sticky="NEWS")
		self.minimum_matches = tk.IntVar()
		self.minimum_matches.set(1)
		tk.Entry(t,textvariable=self.minimum_matches).grid(row=20,column=8,sticky="NEWS")

		#tk.Button(t, text='Toy!', command=self.All_Weapons).grid(row=18,column=5,sticky="NEWS")
		#tk.Button(t, text='Efficient Attacks', command=self.EA).grid(row=18,column=3,sticky="NEWS")
		#tk.Button(t, text='FE', command=self.FE).grid(row=21,column=8,sticky="NEWS")

	def FE(self):
		fout = open('fe.txt','w')
		for feature_name in self.feature_list:
			gg = [ [0 for match in range(10)] for lvl in range(9) ]
			fout.write(feature_name)
			fout.write('\n')
			feature = self.Find_Passive(feature_name)
			keywords = feature.keywords[10].split(',')
			stripped_keywords = sorted(list(set([ kw.lstrip().rstrip() for kw in keywords ])))
			for expendable in expendable_list:
				matches = 0
				for keyword in stripped_keywords:
					if(keyword in expendable.keywords):
						matches += 1
				if(expendable.role==feature.role):
					gg[expendable.level-1][matches] += 1
			for lvl in range(9):
				for match in range(10):
					fout.write(str(gg[lvl][match]))
				fout.write('\n')

	def All_Weapons(self):
		self.weapon_level.set(3)
		self.loop_all = True
		for weapon in weapon_list:
			self.weapon_for_keywords.set(weapon.name)
			self.Add_Keywords_From_Weapon()
		self.loop_all = False

	def EA(self):
		#fout = open('tempa.txt','w')
		x = [ [a.name, float(a.attributes[2])/max(float(a.attributes[3]),float(a.attributes[4])/10)] for a in attack_list]
		x = sorted(x, key=lambda entry: entry[1])#, reverse=True)
		for y in x:
			print(y)

#Gear Tab

	def Find_Gear_Type(self,string):
		result = []
		for gear in gear_list:
			if string in gear.attributes[7]:
				result.append(gear)
		return result

	def Find_Gear(self,gear_name):
		for gear in gear_list:
			if(gear.name==gear_name):
				return gear
		return None

	def Create_Gear_Printout_Button(self,tab,variable):
		cmd = lambda z=variable: self.Find_Gear(z.get()).printout()
		but = tk.Button(tab, text='Info', command=cmd)
		return but

	def Equip_Gear(self,gear_type,gear_name):
		if(gear_type=='Finger'):
			var = self.equipped_gear_variables[gear_types.index(gear_type)]
			length = len(var.get().split(','))
			if(length==0 or length==2):
				var.set(gear_name)
			if(length==1):
				if(var.get().lstrip().rstrip()==''):
					var.set(gear_name)
				else:
					var.set('%s, %s' %(var.get(),gear_name))
		else:
			self.equipped_gear_variables[gear_types.index(gear_type)].set(gear_name)

	def Create_Equip_Gear_Button(self,tab,gear_type,variable):
		cmd = lambda z=variable : self.Equip_Gear(gear_type,z.get())
		but = tk.Button(tab, text='Equip %s' %gear_type, command=cmd)
		return but

	def Equipped_Gear_Keywords(self):
		hand_keywords = []
		feet_keywords = []
		for gt in gear_types:
			index = gear_types.index(gt)
			var = self.equipped_gear_variables[index].get()
			for x in var.split(','):
				try:
					keywords = self.Find_Gear(x.lstrip().rstrip()).keywords #array
				except:
					continue
				for kw in keywords:
					if(gt!='Feet' and kw not in hand_keywords):
						hand_keywords.append(kw)
					if(gt!='Hand' and kw not in feet_keywords):
						feet_keywords.append(kw)
		self.hand_keywords.set(', '.join(hand_keywords))
		self.feet_keywords.set(', '.join(feet_keywords))

	def Find_Gear_With_Keyword(self):
		kw = self.chosen_gear_keyword.get()
		column_entries = []
		width = 10
		for gear in gear_list:
			if kw in gear.keywords:
				column_entries.append([gear.name,gear.type,gear.tier])
				width = max(width,len(gear.name)+5)
		mw = Make_Message_Window()
		title = 'Gear with Keyword: %s' %kw
		column_names = [ 'Gear', 'Slot', 'Tier' ]
		widths = [ 20, width, 10 ]
		mw.update_columns(title, column_names, column_entries, widths)
		mw.new_window()

	def Create_Gear_Tab(self,tab):
		t = tab
		self.gear_variables = [ tk.StringVar() for i in range(len(gear_types)) ]
		self.list_of_gear = [ sorted([gear.name for gear in self.Find_Gear_Type(gear_type)]) for gear_type in gear_types ]
		self.equipped_gear_variables = [ tk.StringVar() for i in range(len(gear_types)) ]
		for i, gt in enumerate(gear_types):
			self.equipped_gear_variables[i].set('')
			self.gear_variables[i].set(self.list_of_gear[i][0])
			tk.OptionMenu(t, self.gear_variables[i], *self.list_of_gear[i]).grid(row=i,column=0,sticky="NEWS")
			self.Create_Equip_Gear_Button(t, gt, self.gear_variables[i]).grid(row=i,column=1,sticky="NEWS")
			self.Create_Gear_Printout_Button(t,self.gear_variables[i]).grid(row=i,column=2,sticky="NEWS")
			tk.Entry(t, textvariable=self.equipped_gear_variables[i], relief='sunken').grid(row=i,column=3,sticky="NEWS")
		tk.Button(t, text='Equipped Keywords', command=self.Equipped_Gear_Keywords).grid(row=len(gear_types),column=0,columnspan=4,sticky="NEWS")
		tk.Label(t, text='Hand Keywords', relief='sunken').grid(row=len(gear_types)+1,column=0,sticky="NEWS")
		self.hand_keywords = tk.StringVar()
		tk.Entry(t, textvariable=self.hand_keywords).grid(row=len(gear_types)+1,column=1,columnspan=4,sticky="NEWS")
		tk.Label(t, text='Feet Keywords', relief='sunken').grid(row=len(gear_types)+2,column=0,sticky="NEWS")
		self.feet_keywords = tk.StringVar()
		tk.Entry(t, textvariable=self.feet_keywords).grid(row=len(gear_types)+2,column=1,columnspan=4,sticky="NEWS")
		self.chosen_gear_keyword = tk.StringVar()
		self.chosen_gear_keyword.set(all_gear_keywords[0])
		tk.OptionMenu(t, self.chosen_gear_keyword, *all_gear_keywords).grid(row=len(gear_types)+3,column=0,sticky="NEWS")
		tk.Button(t, text='Find Gear with Keyword', command=self.Find_Gear_With_Keyword).grid(row=len(gear_types)+3,column=1,sticky="NEWS")

#Advanced Tab

	def Create_Advanced_Tab(self,tab):
		at = tab
		#rep
		tk.Label(at,text='Starting rep gain').grid(row=0,column=0,sticky="NEWS")
		tk.Label(at,text='Rep gain increase').grid(row=1,column=0,sticky="NEWS")
		tk.Label(at,text='Hours per rep gain increase').grid(row=2,column=0,sticky="NEWS")
		tk.Label(at,text='Max rep gain').grid(row=3,column=0,sticky="NEWS")
		tk.Label(at,text='Below this rep is a penalty (do not set above 0)').grid(row=4,column=0,sticky="NEWS")
		tk.Label(at,text='Low reputation penalty scale').grid(row=5,column=0,sticky="NEWS")
		tk.Entry(at,textvariable=self.starting_rep_gain).grid(row=0,column=1,sticky="NEWS")
		tk.Entry(at,textvariable=self.rep_gain_increase).grid(row=1,column=1,sticky="NEWS")
		tk.Entry(at,textvariable=self.hours_per_rep_gain_increase).grid(row=2,column=1,sticky="NEWS")
		tk.Entry(at,textvariable=self.max_rep_gain).grid(row=3,column=1,sticky="NEWS")
		tk.Entry(at,textvariable=self.below_this_rep_is_penalty).grid(row=4,column=1,sticky="NEWS")
		tk.Entry(at,textvariable=self.rep_penalty_scale).grid(row=5,column=1,sticky="NEWS")
		tk.Button(at,text='Store Reputation Settings', command=self.Store_Reputation_Settings).grid(row=6,column=0,sticky="NEWS")
		tk.Button(at,text='Restore Reputation Defaults', command=self.Set_Default_Reputation_Settings).grid(row=6,column=1,sticky="NEWS")
		#travel
		tk.Label(at,text='Base travel speed (m/s)').grid(row=9,column=0,sticky="NEWS")
		tk.Entry(at,textvariable=self.base_travel_speed).grid(row=9,column=1,sticky="NEWS")
		tk.Button(at,text='Store Travel Settings', command=self.Store_Travel_Settings).grid(row=10,column=0,sticky="NEWS")
		tk.Button(at,text='Restore Travel Defaults', command=self.Set_Default_Travel_Settings).grid(row=10,column=1,sticky="NEWS")
		#xp
		tk.Label(at,text='Hourly XP gain').grid(row=11,column=0,sticky="NEWS")
		tk.Entry(at,textvariable=self.hourly_xp_gain).grid(row=11,column=1,sticky="NEWS")
		tk.Button(at,text='Store XP Settings', command=self.Store_XP_Settings).grid(row=12,column=0,sticky="NEWS")
		tk.Button(at,text='Restore XP Defaults', command=self.Set_Default_XP_Settings).grid(row=12,column=1,sticky="NEWS")

	def Store_Reputation_Settings(self):
		if(self.have_stored_reputation_settings==False):
			self.stored_starting_rep_gain = tk.DoubleVar()
			self.stored_rep_gain_increase = tk.DoubleVar()
			self.stored_hours_per_rep_gain_increase = tk.IntVar()	
			self.stored_max_rep_gain = tk.DoubleVar()
			self.stored_below_this_rep_is_penalty = tk.DoubleVar()
			self.stored_rep_penalty_scale = tk.DoubleVar()
			self.have_stored_reputation_settings = True
		self.stored_starting_rep_gain.set(self.starting_rep_gain.get())
		self.stored_rep_gain_increase.set(self.rep_gain_increase.get())
		self.stored_hours_per_rep_gain_increase.set(self.hours_per_rep_gain_increase.get())
		self.stored_max_rep_gain.set(self.max_rep_gain.get())
		self.stored_below_this_rep_is_penalty.set(self.below_this_rep_is_penalty.get())
		self.stored_rep_penalty_scale.set(self.rep_penalty_scale.get())

	def Store_Travel_Settings(self):
		if(self.have_stored_travel_settings==False):
			self.stored_base_travel_speed = tk.DoubleVar()
			self.have_stored_travel_settings = True
		self.stored_base_travel_speed.set(self.base_travel_speed.get())

	def Store_XP_Settings(self):
		if(self.have_stored_xp_settings==False):
			self.stored_hourly_xp_gain = tk.IntVar()
			self.have_stored_xp_settings = True
		self.stored_hourly_xp_gain.set(self.hourly_xp_gain.get())
		for feat in feat_list:
			feat.set_hourly_xp(self.stored_hourly_xp_gain.get())
