from message_window import Make_Message_Window
from re import split
from wb import wb

attack_list = []
attack_names = []
weapon_types = []
attack_titles = [ 'Feat Name', 'Damage Factor', 'Attack Seconds', 'Stamina Cost', 'Standard Effects', 'Restriction Effects', 'Conditional Effects', 'Range', 'Form', 'Cooldown Seconds', 'Weapon Category', 'Role', 'Keyword Progression', 'Last Updated' ]
effects_list = []

class Attack:
	def __init__(self,parsed):
		self.name = parsed[1]
		self.factor = float(parsed[2])
		self.time = float(parsed[3])
		self.stamina = int(parsed[4])
		self.attributes = parsed
		self.cooldown = float(parsed[10])
		self.weapon = parsed[11]
		self.form = parsed[9]
		self.keywords = []
		self.effects = []
		self.damage_type = 'Not Found'
		self.penetrating = False #standard effects
		self.extra_base = 0
		self.precise = 0
		self.afflicted = 0
		self.bleeding = 0
		self.burning = 0
		self.conditional_penetrating = False #conditional effects
		self.conditional_extra_base = 0
		self.conditional_precise = 0
		self.conditional_afflicted = 0
		self.conditional_bleeding = 0
		self.conditional_burning = 0
	def set_keywords(self,keyword_list):
		self.keywords = keyword_list
	def add_effect(self,effect):
		self.effects.append(effect)
	def set_defense(self):
		self.defense = 'Reflex'
		defenses = ['Fortitude','Reflex','Will']
		for effect in self.effects:
			for i, x in enumerate(['Targets Fortitude','Targets Reflex', 'Targets Will']):
				if(effect==x):
					self.defense = defenses[i]
					return
		return				 
	def find_damage_type(self):
		for effect in self.effects:
			if 'Damage' in effect and 'Base' not in effect: #eliminate 'Base Damage +x'
				self.damage_type = effect.split()[0]
		if(self.damage_type=='Not Found' and 'Beneficial' in self.effects):
			self.damage_type = 'None (Beneficial)'
		if(self.damage_type=='Not Found' and self.weapon not in ['Focus','Mage Staff','Mage Wand']):
			self.damage_type = 'Physical'
	def printout(self):
		mw = Make_Message_Window()
		title = 'Attack: %s' %self.name
		column_names = [ 'Attribute', 'Details' ]
		column_entries = [ ]
		width = 10
		for i in range(1,len(self.attributes)):
			column_entries.append([attack_titles[i-1],self.attributes[i]])
			width = max(width,len(self.attributes[i])+5)
		widths = [ 18, width ]
		mw.update_columns(title, column_names, column_entries, widths)
		mw.new_window()

def find_keywords(entry, splitter):
	result = []
	if(splitter in entry):
		result = entry.split(splitter)
	else:
		result = [entry]
	return result

def attack_read():
	for sheet_name in ['Physical Attacks','Cantrips','Orisons','Utilities']:
		sheet = wb.sheet_by_name(sheet_name)
		for rownum in range(sheet.nrows):
			row = sheet.row_values(rownum)[-1].split('|')
			if(row[0]=='Template' or len(row)<2):
				continue
			a = Attack(row)
			attack_list.append(a)
			attack_names.append(a.name)
			kw = [kw.lstrip().rstrip() for kw in find_keywords(row[13],',')]
			keywords = [kw for kw in find_keywords(kw[0],'/')]
			if(len(kw)>1):
				keywords.append(kw[1])
			a.set_keywords(keywords)
			if(row[11] not in weapon_types):
				weapon_types.append(row[11])
			for r in [5,6,7]:
				effects = row[r].split(',')
				for i in range(len(effects)):
					if(')' in effects[i] and '(' not in effects[i]):
						continue
					effect = effects[i].lstrip().rstrip()
					if(effect==''):
						continue
					if('(' in effects[i] and ')' not in effects[i] and i+1<len(effects)):
						if(')' in effects[i+1]):
							effect = ', '.join([effect, effects[i+1].lstrip().rstrip()])
					if(r==5):
						if(effect=='Penetrating'):
							a.penetrating = True
						if('Precise' in effect):
							a.precise = int(effect.split('+')[1])
						if('Base Damage' in effect):
							a.extra_base = int(effect.split('+')[1].split()[0])
						if('Afflicted' in effect):
							a.afflicted = int(effect.split()[1])
						if('Bleeding' in effect):
							a.bleeding = int(effect.split()[1])
						if('Burning' in effect):
							a.burning = int(effect.split()[1])
					if(r==7):
						if('Penetrating' in effect):
							a.conditional_penetrating = True
						if('Precise' in effect):
							a.conditional_precise = int(effect.split('+')[1].split()[0])
						if('Base Damage' in effect):
							a.conditional_extra_base = int(effect.split('+')[1].split()[0])
						if('Afflicted' in effect):
							a.conditional_afflicted = int(effect.split()[1])
						if('Bleeding' in effect):
							a.conditional_bleeding = int(effect.split()[1])
						if('Burning' in effect):
							a.conditional_burning = int(effect.split()[1])
					if(effect not in effects_list):# and effect != ''):
						effects_list.append(effect)
					a.add_effect(effect)
			a.find_damage_type()
			a.set_defense()

attack_read()
weapon_types = sorted(weapon_types)
attack_names = sorted(attack_names)
effects_list = sorted(effects_list)
