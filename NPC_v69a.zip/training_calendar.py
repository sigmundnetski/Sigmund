import calendar
import datetime as dt
import tkinter as tk
from re import split
from os import path, getcwd
import time

#http://stackoverflow.com/questions/7545315/tkinter-menu-for-chosing-a-date
#http://jakirkpatrick.wordpress.com/2012/02/01/making-a-hovering-box-in-tkinter/

class HoverInfo(tk.Menu): #move to utilities?
	def __init__(self, parent, text, title):
		tk.Menu.__init__(self, parent, tearoff=0)
		toktext=split('\n', text)
		self.add_command(label = title, font=("Times", 10, "bold")) #how to center??
		for t in toktext:
			if('<' in t):
				self.add_command(label = t.replace('<', ''), font=("Times", 10, "bold"))
			else:
				self.add_command(label = t)
		self._displayed=False
		self.master.bind("<Enter>",self.Display )
		self.master.bind("<Leave>",self.Remove )
	def __del__(self):
		try: #crashes for some reason here without the try
			self.master.unbind("<Enter>")
			self.master.unbind("<Leave>")
		except:
			pass
	def Display(self,event):
		if not self._displayed:
			self._displayed=True
			self.post(event.x_root, event.y_root)
	def Remove(self, event):
		if self._displayed:
			self._displayed=False
			self.unpost()

class training_calendar(tk.Frame): #should only need to import this
	def __init__(self,root,date=None,dateformat='%d/%m/%Y',mylist=[]):
		self.mylist = mylist
		tk.Frame.__init__(self, root)
		self.canvas = tk.Canvas(root, borderwidth=0)
		self.canvas.grid(row=0,column=0,sticky="NEWS")
		self.dt=dt.datetime.now() if date is None else dt.datetime.strptime(date, dateformat) 
		self.showmonth()
		self.dateformat=dateformat
	def showmonth(self):
		cal = calendar
		cal.setfirstweekday(6)
		sc = cal.month(self.dt.year, self.dt.month).split('\n')
		for t,c in [('<<',0),('<',1),('>',5),('>>',6)]:
			tk.Button(self.canvas,text=t,relief='flat',command=lambda i=t:self.callback(i)).grid(row=0,column=c,sticky="NEWS")
		tk.Label(self.canvas,text=sc[0].lstrip().rstrip()).grid(row=0,column=2,columnspan=3,sticky="NEWS")
		for col, wd in enumerate(sc[1].split()):
			tk.Label(self.canvas,text=wd).grid(row=1, column=col, sticky="NEWS")
		for line,lineT in [(i,sc[i+1]) for i in range(1,len(sc)-1)]: #-2 as bottom column always seems to be empty
			for col,colT in [(i,lineT[i*3:(i+1)*3-1]) for i in range(7)]:
				colT = colT.lstrip().rstrip()
				fg='red' if (col==0 or col==6) else 'SystemButtonText'
				obj = tk.Label(self.canvas,text="%s"% colT,relief='flat',bg='SystemButtonFace',fg=fg,width=4) #sunken or flat
				obj.grid(row=line+1, column=col, sticky="NEWS")
				if(colT.isdigit()):
					daylist = self.is_in_list(self.dt.year,self.dt.month,colT)
					if(daylist==[]):
						continue
					obj.config(bg='blue')
					month = dt.datetime.strptime(str(self.dt.month),"%m").strftime("%b")
					OBJ = HoverInfo(obj, '\n'.join(daylist), ' '.join([month,colT,str(self.dt.year)]))
	def callback(self,but):
		if but.strip().isdigit(): self.dt=self.dt.replace(day=int(but))
		elif but in ['<','>','<<','>>']:
			day=self.dt.day
			ndays1 = calendar.monthrange(self.dt.year,self.dt.month)[1] #in case day=1
			if(self.dt.month!=1):
				ndays2 = calendar.monthrange(self.dt.year,self.dt.month-1)[1] #in case day=1 and previous month is shorter
			else:
				ndays2 = calendar.monthrange(self.dt.year-1,12)[1]
			if but in['<','>']: self.dt=self.dt+dt.timedelta(days=ndays1 if but=='>' else -ndays2)
			if but in['<<','>>']: self.dt=self.dt+dt.timedelta(days=365 if but=='>>' else -365)
			try: self.dt=self.dt.replace(day=day)
			except: pass
		self.showmonth()
	def is_in_list(self,year,month,day): #smarter: use dateformat to be consistent
		if(int(month)<10):
			month = '0%s' %month
		if(int(day)<10):
			day = '0%s' %day
		date = '/'.join([str(year),str(month),str(day)])
		result = []
		for item in self.mylist:
			if(str(item[0])==date):
				result.append(item[1])
		return result

class test_calendar:
	def __init__(self,title):
		self.title = title
	def make(self,mylist=[]):
		current = time.ctime().split()
		x = time.strptime('/'.join([current[2],current[1],current[4]]),"%d/%b/%Y")
		y = '/'.join([str(x[2]),str(x[1]),str(x[0])])
		root = tk.Toplevel()
		root.title(self.title)
		root.iconbitmap(r'%s' %path.join(getcwd(),'NPC.ico'))
		self.calendar = training_calendar(root,date=y,dateformat="%d/%m/%Y",mylist=mylist)
		self.calendar.grid(row=0,column=0,sticky="NEWS")
		tk.Grid.rowconfigure(root,0,weight=1)
		tk.Grid.columnconfigure(root,0,weight=1)
		tk.Grid.columnconfigure(root,1,weight=1)
