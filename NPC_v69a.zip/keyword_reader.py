from message_window import Make_Message_Window
from re import split
from wb import wb

keyword_as_class_list = []
keyword_as_class_names = []
keyword_titles = [ 'Name', 'Value', 'Gear', 'Notes' ]
major_keywords = []
minor_keywords = []

class Keyword:
	def __init__(self,parsed):
		self.name = parsed[0]
		self.value = parsed[1]
		self.gear = parsed[2]
		self.notes = parsed[3]
		self.attributes = parsed
	def printout(self):
		mw = Make_Message_Window()
		title = 'Keyword: %s' %self.name
		column_names = [ 'Attribute', 'Details' ]
		column_entries = [ ]
		width = 10
		for i in range(len(self.attributes)):
			column_entries.append([keyword_titles[i],self.attributes[i]])
			width = max(width,len(self.attributes[i])+5)
		widths = [ 20, width ]
		mw.update_columns(title, column_names, column_entries, widths)
		mw.new_window()

def keyword_read():
	sheet = wb.sheet_by_name('Keywords')
	for rownum in range(sheet.nrows):
		row = sheet.row_values(rownum)
		if(len(row)<2 or 'Keyword' in row[0]):
			continue
		parsed = []
		for entry_num in range(len(row)):
			parsed.append(row[entry_num])
		k = Keyword(parsed)
		keyword_as_class_list.append(k)
		keyword_as_class_names.append(k.name+' ('+k.gear+')')
		if(k.value=='Advanced'):
			major_keywords.append(k)
		if(k.value=='Basic'):
			minor_keywords.append(k)

keyword_read()

keyword_as_class_names = sorted(keyword_as_class_names)
