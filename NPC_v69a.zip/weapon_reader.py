from message_window import Make_Message_Window
from re import split
from wb import wb

weapon_list = []
weapon_names = []
weapon_titles = ['Name','Tier','+0 Quality','Encumbrance','Description','Inherent Keywords','Upgrade Keywords','Last Updated']

def Find_Weapon_Type(wtype):
	matches = []
	matches.append(['Battleaxe',['One-Handed Axe']])
	matches.append(['Buckler',['Shield']])
	matches.append(['Club',['One-Handed Blunt (Club)','One-Handed Blunt']])
	matches.append(['Dagger',['Light Knife']])
	matches.append(['Focus',['Focus']])
	matches.append(['Greatclub',['Two-Handed Blunt']])
	matches.append(['Greatsword',['Two-Handed Sword']])
	matches.append(['Hammer',['One-Handed Blunt (Hammer)','One-Handed Blunt']])
	matches.append(['Longbow',['Longbow']])
	matches.append(['Longsword',['One-Handed Sword']])
	matches.append(['Mace',['One-Handed Blunt (Mace)','One-Handed Blunt']])
	matches.append(['Rapier',['One-Handed Fencing']])
	matches.append(['Shield',['Shield']])
	matches.append(['Shortbow',['Shortbow']])
	matches.append(['Spear',['Piercing Polearm']])
	matches.append(['Staff',['Mage Staff']])
	matches.append(['Sword',['One-Handed Fencing']])
	matches.append(['Trident',['Piercing Polearm']])
	matches.append(['Wand',['Mage Wand']])
	for match in matches:
		if(match[0]==wtype):
			return match[1]
	print('Weapon type not found for %s' %wtype)
	return 'None'

class Weapon:
	def __init__(self,parsed):
		self.name = parsed[1]
		self.tier = int(parsed[2])
		self.quality = int(parsed[3])
		self.attributes = parsed
		self.inherent_keyword = []
		self.upgrade_keywords = []
		self.weapon_types = [] #multiple possibilites
	def set_inherent_keywords(self, keyword_list):
		self.inherent_keywords = keyword_list
	def set_upgrade_keywords(self, keyword_list):
		self.upgrade_keywords = keyword_list
	def set_weapon_types(self, weapon_types):
		self.weapon_types = weapon_types
	def printout(self):
		mw = Make_Message_Window()
		title = 'Weapon: %s' %self.name
		column_names = [ 'Attribute', 'Details' ]
		column_entries = [ ]
		width = 10
		for i in range(1,len(self.attributes)):
			column_entries.append([weapon_titles[i-1],self.attributes[i]])
			width = max(width,len(self.attributes[i])+5)
		widths = [ 20, width ]
		mw.update_columns(title, column_names, column_entries, widths)
		mw.new_window()

def find_keywords(entry, splitter):
	result = []
	if(splitter in entry):
		result = entry.split(splitter)
	else:
		result = [entry]
	for j in range(len(result)):
		result[j] = result[j].lstrip().rstrip()
	for i in range(4):
		x = ' (+%i)' %i
		for j in range(len(result)):
			if x in result[j]:
				result[j] = result[j].replace(x,'').rstrip()
	return result

def weapon_read():
	for sheet_name in ['Weapons (Standard)','Weapons (Caster)']:
		sheet = wb.sheet_by_name(sheet_name)
		for rownum in range(sheet.nrows):
			#row = ''.join(sheet.row_values(rownum)).split('|')
			row = sheet.row_values(rownum)[-1].split('|')
			if(row[0]=='Template' or len(row)<2):
				continue
			w = Weapon(row)
			w.set_inherent_keywords(find_keywords(row[6],','))
			w.set_upgrade_keywords(find_keywords(row[7],','))
			weapon_list.append(w)
			weapon_names.append(w.name)
			wtype = ' '.join(row[5].split(';')[0].split()[-1:])
			w.set_weapon_types(Find_Weapon_Type(wtype))

weapon_read()
weapon_names = sorted(weapon_names)

wtypes = sorted(list(set(' '.join(weapon.attributes[5].split(';')[0].split()[2:][-1:]) for weapon in weapon_list)))
#print(wtypes) #leave for future weapon debugging
