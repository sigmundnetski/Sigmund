from message_window import Make_Message_Window
from re import split
from wb import wb

armor_list = []
armor_names = []
armor_types = ['Clothing','Light','Medium','Heavy']
armor_titles = ['Name','Weight','Tier','+0 Quality','Encumbrance','Description','Inherent Keywords','Upgrade Keywords','Last Updated']

base_physical = [0,5,15,25]
base_energy = [0,0,0,0]#6]
physical_per_keyword = [0,2,2,2]
energy_per_keyword = [2,0,0,0]#1]

class Armor:
	def __init__(self,parsed):
		self.name = parsed[1]
		self.type = parsed[2]
		self.tier = int(parsed[3])
		self.quality = int(parsed[4])
		self.attributes = parsed
		self.inherent_keyword = []
		self.upgrade_keywords = []
	def set_inherent_keywords(self, keyword_list):
		self.inherent_keywords = keyword_list
	def set_upgrade_keywords(self, keyword_list):
		self.upgrade_keywords = keyword_list
	def set_resistances(self):
		index = armor_types.index(self.type)
		self.base_physical = base_physical[index]
		self.base_energy = base_energy[index]
		self.physical_per_keyword = physical_per_keyword[index]
		self.energy_per_keyword = energy_per_keyword[index]
	def printout(self):
		mw = Make_Message_Window()
		title = 'Armor: %s' %self.name
		column_names = [ 'Attribute', 'Details' ]
		column_entries = [ ]
		width = 10
		for i in range(1,len(self.attributes)):
			column_entries.append([armor_titles[i-1],self.attributes[i]])
			width = max(width,len(self.attributes[i])+5)
		widths = [ 20, width ]
		mw.update_columns(title, column_names, column_entries, widths)
		mw.new_window()

def find_keywords(entry, splitter):
	result = []
	if(splitter in entry):
		result = entry.split(splitter)
	else:
		result = [entry]
	for j in range(len(result)):
		result[j] = result[j].lstrip().rstrip()
	for i in range(4):
		x = ' (+%i)' %i
		for j in range(len(result)):
			if x in result[j]:
				result[j] = result[j].replace(x,'').rstrip()
	return result

def armor_read():
	sheet = wb.sheet_by_name('Armor')
	for rownum in range(sheet.nrows):
		row = sheet.row_values(rownum)[-1].split('|')
		if(row[0]=='Template' or len(row)<2):
			continue
		a = Armor(row)
		a.set_inherent_keywords(find_keywords(row[7],','))
		a.set_upgrade_keywords(find_keywords(row[8],','))
		armor_list.append(a)
		armor_names.append(a.name)
		armor_type = row[2] #why is this here????

armor_read()
armor_names = sorted(armor_names)
for armor in armor_list:
	armor.set_resistances()
