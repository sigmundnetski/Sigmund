import tkinter as tk
from attack_reader import *
from expendable_reader import *
from message_window import Make_Message_Window
from re import split
from utilities import is_in, allowed_searches
from training_calendar import HoverInfo

def Find_Attacks_With_Effect(effect):
	result = []
	for attack in attack_list:
		if(effect in attack.effects):
			result.append([attack.name, attack.weapon])
	for expendable in expendable_list:
		if(effect in expendable.effects):
			result.append([expendable.name, expendable.implement])
	return result

class Create_Rotation_Tab:
	def __init__(self, tab):
		t = tab
		self.effect_variable = tk.StringVar()
		self.my_list = sorted(set(effects_list+expendable_effects_list))
		self.effect_variable.set(self.my_list[0])
		tk.OptionMenu(t, self.effect_variable, *self.my_list).grid(row=0,column=0,sticky="NEWS")
		tk.Button(t, text='Attacks with specific effect', command=self.Find).grid(row=0,column=1,sticky="NEWS")
		tk.Label(t, text='Weapon Choice').grid(row=2,column=0,sticky="NEWS")
		self.weapon_choice = tk.StringVar()
		self.weapon_choice.set(weapon_types[0])
		tk.OptionMenu(t, self.weapon_choice, *weapon_types).grid(row=2,column=1,sticky="NEWS")
		tk.Button(t, text='Choose', command=self.Choose_Weapon).grid(row=2,column=2,sticky="NEWS")

		self.search_string = tk.StringVar()
		self.search_string.set('Search effects here. Commas treated as OR')
		e = tk.Entry(t, textvariable=self.search_string)
		e.grid(row=1,column=0,columnspan=3,sticky="NEWS")
		e.bind('<Key>',self.key)
		search_button = tk.Button(t, text='Find General Effect', command=self.Search)
		search_button.grid(row=1,column=3,sticky="NEWS")
		HoverInfo(search_button, allowed_searches, 'Search Guidelines') #is putting it everywhere...

		self.attack_list = [ attack for attack in attack_names ]
		self.attack_choices = [ tk.StringVar() for i in range(6) ]
		self.attack_menu = []
		for i in range(6):
			self.attack_choices[i].set(self.attack_list[0])
			self.attack_menu.append(tk.OptionMenu(t, self.attack_choices[i], *self.attack_list))
			self.attack_menu[i].grid(row=i+3,column=1,sticky="NEWS")
			self.Create_Attack_Printout_Button(tab,self.attack_choices[i]).grid(row=i+3,column=2)
		for i in range(3):
			tk.Label(t, text='Primary #%s' %(i+1)).grid(row=i+3,column=0,sticky="NEWS")
		for i in range(3,6):
			tk.Label(t, text='Secondary #%s' %(i-2)).grid(row=i+3,column=0,sticky="NEWS")
		tk.Button(t, text='State Matching', command=self.State_Matching).grid(row=9,column=0,columnspan=3,sticky="NEWS")

	def State_Matching(self): #dispelling->disrupted
		details = [[] for i in range(6)]
		for i in range(6):
			attack = self.Find_Attack(self.attack_choices[i].get())
			if(attack==None):
				continue
			for effect in attack.effects:
				for state in ['Dazed', 'Dispelling', 'Disrupted', 'Distressed', 'Flat-Footed', 'Opportunity', 'Unbalanced']:
					if state in effect:
						if(state=='Opportunity' and effect=='Provokes Opportunity'):
							continue
						details[i].append(state)
		mw = Make_Message_Window()
		title = 'State Matching'
		column_names = [ 'Attack', 'Causes', 'Triggers On' ]
		column_entries = [ [self.attack_choices[i].get(),', '.join(set(details[i])), ''] for i in range(3)]
		column_entries += [ [self.attack_choices[i].get(), '',  ', '.join(set(details[i]))] for i in range(3,6)]
		widths = [ 25, 25, 25 ]
		mw.update_columns(title, column_names, column_entries, widths)
		mw.new_window()

	def Find_Attack(self, string):
		for attack in attack_list:
			if(string==attack.name):
				return attack
		return None

	def Safe_Printing(self,attack):
		if(attack==None):
			return
		else:
			attack.printout()

	def Create_Attack_Printout_Button(self,tab,variable):
		cmd = lambda z=variable: self.Safe_Printing(self.Find_Attack(z.get()))
		but = tk.Button(tab, text='Info', command=cmd)
		return but

	def key(self,event):
		if(event.keysym=='Return'):
			self.Search()

	def Choose_Weapon(self):
		weapon_type = self.weapon_choice.get()
		primaries = sorted([ attack.name for attack in attack_list if (attack.weapon==weapon_type and attack.form=='Primary') ])
		secondaries = sorted([ attack.name for attack in attack_list if (attack.weapon==weapon_type and attack.form=='Secondary') ])
		for i in range(3):
			if(len(primaries)>0):
				self.attack_choices[i].set(primaries[0])
			else:
				self.attack_choices[i].set('None')
			self.attack_menu[i]['menu'].delete(0, 'end')
			for attack in primaries:
				self.attack_menu[i]['menu'].add_command(label=attack, command=tk._setit(self.attack_choices[i], attack))
		for i in range(3,6):
			if(len(secondaries)>0):
				self.attack_choices[i].set(secondaries[0])
			else:
				self.attack_choices[i].set('None')
			self.attack_menu[i]['menu'].delete(0, 'end')
			for attack in secondaries:
				self.attack_menu[i]['menu'].add_command(label=attack, command=tk._setit(self.attack_choices[i], attack))

	def Find(self): #better name
		title = 'Effect: %s' %self.effect_variable.get()
		column_names = [ 'Attack', 'Weapon Type' ]
		column_entries = Find_Attacks_With_Effect(self.effect_variable.get())
		if(len(column_entries)==1):
			for attack in attack_list:
				if(attack.name==column_entries[0][0]):
					attack.printout()
					return
			for expendable in expendable_list:
				if(expendable.name==column_entries[0][0]):
					expendable.printout()
					return
		column_entries = sorted(column_entries, key=lambda entry: entry[1])
		widths = [ 25, 20 ]
		mw = Make_Message_Window()
		mw.update_columns(title, column_names, column_entries, widths)
		mw.new_window()

	def Search(self):
		searches = [s.lstrip().rstrip().lower() for s in self.search_string.get().split(',')]
		lower_effect_names = [ effect.lower() for effect in self.my_list ]
		effect_names = [ effect for effect in self.my_list ]
		effect_result = []
		for search in searches:
			for name in lower_effect_names:
				if is_in(search, name):
					index = lower_effect_names.index(name) 
					effect_result.append(effect_names[index])
		result = []
		for effect in effect_result: 
			result += [ [eff[0],eff[1],effect ] for eff in Find_Attacks_With_Effect(effect) ]
		if(len(result)==1):
			for attack in attack_list:
				if(result[0][0]==attack.name):
					attack.printout()
					return
			for expendable in expendable_list:
				if(result[0][0]==expendable.name):
					expendable.printout()
					return
		mw = Make_Message_Window()
		title = 'Search Results: %s' %self.search_string.get()
		column_names = [ 'Attack/Expendable', 'Weapon Type/Implement', 'Effect' ]
		column_entries = [ ]
		widtha, widthb = 10, 10
		for r in result:
			column_entries.append([r[0], r[1], r[2]])
			widtha = max(widtha,len(r[0]))
			widthb = max(widthb,len(r[2]))
		if(len(result)==0):
			column_entries = [['None','None','None']]
		column_entries = sorted(column_entries, key=lambda entry: entry[1])
		widths = [ widtha, 25, widthb ]
		mw.update_columns(title, column_names, column_entries, widths)
		mw.new_window()
