from re import split

def parse(string, comma_default=1, want_float=False): #0 is and, 1 is or
	result = []
	try:	
		for i in string.split(','):
			i = i.lstrip().rstrip()
			try:
				a,b = split(r'\s*=\s*',i)
				if(not want_float):
					result.append([a,int(b),comma_default])
				else:
					result.append([a,float(b),comma_default])
			except:
				for k, x in enumerate([' and ', ' or ']):
					if(x in i):
						for j in i.split(x):
							j = j.lstrip().rstrip()
							a,b = split(r'\s*=\s*',j)
							if(not want_float):
								result.append([a,int(b),k])
							else:
								result.append([a,float(b),k])
	except:		
		print('Bad input: %s' %string)
	return result

