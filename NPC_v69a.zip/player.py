from feat import Feat
from message_window import Make_Message_Window
from logic_handler import Logic_Handler
from role import Role #do we need to import role_reader?

class Player:
	def __init__(self):
		self.abilities = [ 10.0 for i in range(6) ]
		self.ability_names = [ 'Strength', 'Dexterity', 'Constitution', 'Intelligence', 'Wisdom', 'Personality' ]
		self.xp = 0
		self.trained = [] # a list of feat name and current level
		self.achievements = [] #changed to a list of possible achievements
		self.message = ''
		self.feat_types = []
		self.sorting_priority = 0
		self.training_plan = [] #ordered list of feats trained in order
		self.logic_handler = Logic_Handler()
	def Train(self,f,free=False):#,logic='or'):
		level = f.current_level+1
		can_train = False
		if(level>len(f.xp_scaling)): #have max training
			self.message = '%s at max level' %f.name
			return can_train
		#if(logic=='or'): #need an 'and' option in case they genuinely require all the scores
		for ab in f.min_score_type:
			if(f.min_score[level-1]<=self.abilities[ab]): #at least one of the ability scores is high enough
				can_train = True
		if(can_train==False):
			self.message = '%s too low' %f.shorten(f.min_score_type_names)
			return can_train
		self.training_plan.append(f.name)
		for ab in f.increase_type:
			rnd = len(str(f.increase[level-1]).split('.')[1])
			self.abilities[ab] += round(f.increase[level-1],rnd)
			self.abilities[ab] = round(self.abilities[ab],5)
		if(not free):
			self.xp += f.xp_scaling[level-1]
		found = False
		for trained in self.trained:
			if(trained[1]==f.name):
				trained[2] = level
				if(not free):
					trained[3] += f.xp_scaling[level-1]
				trained[4] = f.next_xp
				found = True
				break
		if(not found):
			if(not free):
				self.trained.append([f.feat_type,f.name,1,f.xp_scaling[0],f.next_xp])
			if(free):
				self.trained.append([f.feat_type,f.name,1,0,f.next_xp])
		optionals = []
		for x in f.achievements[f.current_level]: 
			if(x[2]==0):#AND
				for i, achievement_list in enumerate(self.achievements):
					found = False
					for j, achievement in enumerate(achievement_list):
						if(x[0].lower()==achievement[0].lower()):
							found = True
							self.achievements[i][j] = [ achievement[0], max(x[1], achievement[1]) ]
							break 
					if(not found):
						achievement_list.append([x[0],x[1]])
				if(len(self.achievements)==0):
					self.achievements.append([[x[0],x[1]]])
			if(x[2]==1):#OR
				optionals.append(x)
		passed_lists = []
		new_achievement_lists = []
		if(len(optionals)>0):
			for achievement_list in self.achievements:
				passed = False
				for x in optionals:
					for achievement in achievement_list:
						if(x[0].lower()==achievement[0].lower() and x[1]<=achievement[1]):
							passed = True
							passed_lists.append(achievement_list)
							break
				if(passed):
					continue
				else:
					for x in optionals: 
						found, index = False, -1
						for i, a in enumerate(achievement_list):
							if(x[0].lower()==a[0].lower()):
								found, index = True, i
								break
						if(found):  #1 increase if x in list. change to new list 
							new_list = [ a for a in achievement_list ]
							new_list[i] = [ new_list[i][0], max(x[1], new_list[i][1]) ]
							new_achievement_lists.append(new_list)
						if(not found): #2 add to list if not there
							new_list = [ achievement for achievement in achievement_list ]
							new_list.append([x[0],x[1]])
							new_achievement_lists.append(new_list)
			if(len(self.achievements)==0):
				for x in optionals:
					new_achievement_lists.append([[x[0],x[1]]])
			new_ach = [ sorted(a) for a in passed_lists+new_achievement_lists ]  #sort the lists so that they look the same
		else:
			new_ach = [ a for a in self.achievements ]
		self.achievements = []
		new_ach2 = []
		to_remove = []
		for x in new_ach:
			if x not in new_ach2:
				new_ach2.append(x)
		for l1 in new_ach2: #remove those that have other options as a subset
			for l2 in new_ach2:
				if(l1==l2):
					continue
				l3 = [ a for a in l2 if a in l1 ] #common
				if(l3==l1 and l1!=l2):
					to_remove.append(l2)
				all_same = True
				if(len(l1)!=len(l2)):
					all_same = False
				if(all_same):
					l4 = [ b[0].lower() for b in l2]
					for a in l1:
						if a[0].lower() not in l4:
							all_same = False
							break
				if(all_same):#all the same requirements, just different numbers
					h, g = [a[1] for a in l1], [b[1] for b in l2]
					remove = True
					for i in range(len(h)):
						if(h[i]>g[i]):
							remove = False
					if(remove): #all l1 are lower or equal to l2
						to_remove.append(l2)
		self.achievements = [ a for a in new_ach2 if a not in to_remove ]
		f.levelup()
		self.message = 'Trained %s %s' %(f.name,f.current_level)
		return can_train
	def Print_Training(self):
		mw = Make_Message_Window()
		title = 'Trained Feats'
		widths = [15,30,10,10,10]
		column_names = [ 'Feat Type', 'Feat Name', 'Level', 'XP spent' , 'XP next level' ]
		self.trained = sorted(self.trained, key=lambda entry: entry[self.sorting_priority])
		column_entries = [ trained for trained in self.trained ]
		if(len(self.trained)==0):
			column_entries = [ ['none', 'none', 0, 0, 0] ]
		mw.update_columns(title, column_names, column_entries, widths)
		mw.new_window()
	def Find_Achievement_Level(self, name, i):
		for achievement in self.achievements[i]:
			if(name==achievement[0]):
				return achievement[1]
		return 0 #not needed for that list
	def Print_Achievements(self):
		mw = Make_Message_Window()
		title = 'Needed Achievements'
		widths = [20]
		column_names = [ 'Achievement' ]
		names = []
		for l in self.achievements:
			for a in l:
				if(a[0] not in names):
					names.append(a[0])
		names = sorted(names)
		column_entries = [ [name] for name in names ]
		for i, achievement_list in enumerate(self.achievements): #i is the column
			column_names.append('Option %s level' %(i+1))
			widths.append(12)
			for j, name in enumerate(names):
				column_entries[j].append(self.Find_Achievement_Level(name,i))
		if(len(self.achievements)==0):
			column_names = [ 'Achievement' ]
			column_entries = [ ['None'] ]
		mw.update_columns(title, column_names, column_entries, widths)
		mw.new_window()
	def Reset_Training_Plan(self):
		self.training_plan = []
	def Reset(self):
		self.abilities = [ 10.0 for i in range(6) ]
		self.xp = 0
		self.trained = [] 
		self.achievements = []
		self.message = ''
		self.Reset_Training_Plan()
