from message_window import Make_Message_Window
from utilities import *
from logic_handler import Logic_Handler

class Role:
	def __init__(self, name):
		self.name = name
		self.min_scores = []
		self.prerequisites = []
		self.current_level = 0
		self.logic_handler = Logic_Handler()
		self.xp = []
	def add_scores(self, min_scores):
		self.min_scores.append(min_scores)
	def add_prerequisites(self, prerequisites):
		self.prerequisites.append(prerequisites)
	def levelup(self):
		self.current_level += 1
	def reset(self):
		self.current_level = 0
	def add_xp(self,level,xp): #level is the actual level, 1-20
		if(len(self.xp)<level):
			self.xp.append(xp)
		else:
			self.xp[level-1] += xp
	def check_level(self,trained,abilities): 
		#print('checking %s' %self.name)
		#print('current level %s' %self.current_level)
		for level in range(self.current_level, len(self.min_scores)):
			#print('looking at level %s' %level)
			if(self.logic_handler.handle(self.prerequisites[level],trained)):
				#print('level up')			
				if(len(self.min_scores[level])==1): #have only 1 required
					if(abilities[self.min_scores[level][0][0]]<self.min_scores[level][0][1]):
						break
				if(len(self.min_scores[level])==2): #have 2 required
					if(abilities[self.min_scores[level][0][0]]<self.min_scores[level][0][1]):
						break
					if(abilities[self.min_scores[level][1][0]]<self.min_scores[level][1][1]):
						break
				if(len(self.min_scores[level])==3): #have 3 required, last 2 is one or other
					if(abilities[self.min_scores[level][0][0]]<self.min_scores[level][0][1]):
						break
					if(abilities[self.min_scores[level][1][0]]<self.min_scores[level][1][1] and abilities[self.min_scores[level][2][0]]<self.min_scores[level][2][1]):
						break
				self.current_level = level+1
			else:
				break
	def sep(self,a,b):
		if(a>0 and b>0):
			return ' or'
		else:
			return ','
	def separator(self,reqlist,i):
		if(len(reqlist)==0):
			return ''
		try:
			return self.sep(reqlist[i][2],reqlist[i+1][2])
		except:
			return ','
	def printout(self):
		mw = Make_Message_Window()
		title = '%s' %self.name
		self.score_names = [ ab_names[self.min_scores[19][i][0]] for i in range(len(self.min_scores[19])) ]
		if(len(self.score_names)==2):
			column_names = [ 'Level', 'Minimum %s' %self.score_names[0], 'Minimum %s' %self.score_names[1], 'Requirements', 'Requirement XP', 'Cumulative XP' ] 
		if(len(self.score_names)==3):
			column_names = [ 'Level', 'Minimum %s' %self.score_names[0], 'Minimum %s or %s' %(self.score_names[1],self.score_names[2]), 'Requirements', 'Requirement XP', 'Cumulative XP' ]
		column_entries = []
		width = 10
		xp = 0
		for level in range(len(self.prerequisites)):
			xp += self.xp[level]
			printout_string = ''
			for i, x in enumerate(self.prerequisites[level]):
				s = self.separator(self.prerequisites[level],i)
				printout_string += '%s=%s%s ' %(x[0],x[1],s)
			printout_string = printout_string[:-2] #cut off last comma and space
			try:
				column_entries.append([level+1, self.min_scores[level][0][1], self.min_scores[level][1][1], printout_string, self.xp[level], xp]) #2 numbers
			except:
				try:
					column_entries.append([level+1, self.min_scores[level][0][1], 10, printout_string, self.xp[level], xp]) #1 number
				except:
					column_entries.append([level+1, 10, 10, printout_string, self.xp[level], xp]) #no numbers
			width = max(width,int(0.9*len(printout_string)),len(printout_string)-20)
		widths = [10, 10, 10, width,10,10]
		mw.update_columns(title, column_names, column_entries, widths)
		mw.new_window()
