﻿using GNGUI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using UnityEngine;

public class AchievementsWindowGui : WindowGui
{
    private List<AchievementItem> achievementItems = new List<AchievementItem>();
    private GameObject achievementPrefab = null;
    private UIGrid achievementUiGrid;
    private Tabs activeTab = Tabs.NONE;
    private const string ANY_CATEGORY = "Any Category";
    private UIImageButton categoryButton;
    public int categoryIdFilter = 0;
    private UIPopupList categoryList;
    private Dictionary<string, int> categoryNameToId = new Dictionary<string, int>();
    private _GetFilteredAchievements GetFilteredAchievements = null;
    private UIScrollBar scrollBar;
    public static AchievementsWindowGui singleton;
    private UISprite tabSprite;
    private string[] tabSpriteNames = new string[] { "panel_achievements_header_inprogress", "panel_achievements_header_other", "panel_achievements_header_completed" };

    public void Awake()
    {
        singleton = this;
    }

    public void CategoryHover(GameObject go, bool isOver)
    {
        this.categoryButton.SendMessage("OnHover", isOver, SendMessageOptions.DontRequireReceiver);
    }

    public void CategoryPress(GameObject go, bool isDown)
    {
        this.categoryButton.SendMessage("OnPress", isDown, SendMessageOptions.DontRequireReceiver);
    }

    public void CompletedTabSelected(GameObject go)
    {
        Tabs activeTab = this.activeTab;
        this.activeTab = Tabs.COMPLETED;
        if (this.activeTab != activeTab)
        {
            this.tabSprite.spriteName = this.tabSpriteNames[(int) this.activeTab];
            this.GetFilteredAchievements = new _GetFilteredAchievements(AdvancementClient.GetFinishedAchievements);
            this.Repopulate();
            this.scrollBar.scrollValue = 0f;
        }
    }

    public void InProgressTabSelected(GameObject go)
    {
        Tabs activeTab = this.activeTab;
        this.activeTab = Tabs.IN_PROGRESS;
        if (this.activeTab != activeTab)
        {
            this.tabSprite.spriteName = this.tabSpriteNames[(int) this.activeTab];
            this.GetFilteredAchievements = new _GetFilteredAchievements(AdvancementClient.GetActiveAchievements);
            this.Repopulate();
            this.scrollBar.scrollValue = 0f;
        }
    }

    private bool IsValidForFilter(GenericAchievementData achievementData)
    {
        bool flag = false;
        int categoryIdFilter = this.categoryIdFilter;
        if (categoryIdFilter == 0)
        {
            return true;
        }
        if ((achievementData != null) && achievementData.categoryIds.Contains<int>(categoryIdFilter))
        {
            flag = true;
        }
        return flag;
    }

    public bool LoadingTickFinished()
    {
        this.achievementPrefab = UIClient.guiPrefabs["AchievementItem"];
        List<string> list = new List<string> { "Any Category" };
        foreach (CategoryData data in StaticDataService.GetValues<CategoryData>())
        {
            list.Add(data.displayName);
            this.categoryNameToId[data.displayName] = data.id;
        }
        this.categoryNameToId["Any Category"] = 0;
        this.categoryList.items = list;
        this.categoryList.selection = "Any Category";
        this.categoryList.onSelectionChange = new GNGUI.UIPopupList.OnSelectionChange(this.OnSelectionChange);
        this.InProgressTabSelected(null);
        return true;
    }

    public override void OnDestroy()
    {
        base.OnDestroy();
        singleton = null;
    }

    public void OnSelectionChange(string newSelection)
    {
        this.categoryIdFilter = this.categoryNameToId[newSelection];
        this.Repopulate();
        this.scrollBar.scrollValue = 0f;
    }

    public void OtherTabSelected(GameObject go)
    {
        Tabs activeTab = this.activeTab;
        this.activeTab = Tabs.OTHER;
        if (this.activeTab != activeTab)
        {
            this.tabSprite.spriteName = this.tabSpriteNames[(int) this.activeTab];
            this.GetFilteredAchievements = new _GetFilteredAchievements(AdvancementClient.GetNewAchievements);
            this.Repopulate();
            this.scrollBar.scrollValue = 0f;
        }
    }

    public void Repopulate()
    {
        if (EntityDataClient.owner != null)
        {
            GenericAchievementData[] dataArray = this.GetFilteredAchievements();
            int num = 0;
            for (int i = 0; i < dataArray.Length; i++)
            {
                if ((dataArray[i] != null) && this.IsValidForFilter(dataArray[i]))
                {
                    if (num >= this.achievementItems.Count)
                    {
                        AchievementItem component = NGUITools.AddChild(this.achievementUiGrid.gameObject, this.achievementPrefab).GetComponent<AchievementItem>();
                        this.achievementItems.Add(component);
                    }
                    this.achievementItems[num].SetAchievement(this, dataArray[i]);
                    num++;
                }
            }
            while (this.achievementItems.Count > num)
            {
                AchievementItem item2 = this.achievementItems[this.achievementItems.Count - 1];
                this.achievementItems.RemoveAt(this.achievementItems.Count - 1);
                item2.gameObject.SetActive(false);
                item2.transform.parent = DragDropRoot.root;
                UnityEngine.Object.Destroy(item2.gameObject);
            }
            this.achievementUiGrid.repositionNow = true;
        }
    }

    public void Start()
    {
        ClientTick.achieveGuiLoadFinish = new GUtil.BoolFilterDelegate(this.LoadingTickFinished);
        foreach (Collider collider in base.GetComponentsInChildren<Collider>())
        {
            if (collider.name == "CompletedButton")
            {
                UIEventListener listener1 = UIEventListener.Get(collider.gameObject);
                listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.CompletedTabSelected));
            }
            else if (collider.name == "InProgressButton")
            {
                UIEventListener listener2 = UIEventListener.Get(collider.gameObject);
                listener2.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener2.onClick, new UIEventListener.VoidDelegate(this.InProgressTabSelected));
            }
            else if (collider.name == "OtherButton")
            {
                UIEventListener listener3 = UIEventListener.Get(collider.gameObject);
                listener3.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener3.onClick, new UIEventListener.VoidDelegate(this.OtherTabSelected));
            }
        }
        this.achievementUiGrid = base.GetComponentInChildren<UIGrid>();
        this.scrollBar = base.GetComponentInChildren<UIScrollBar>();
        foreach (UISprite sprite in base.GetComponentsInChildren<UISprite>())
        {
            if (sprite.name == "BackgroundTabs")
            {
                this.tabSprite = sprite;
            }
        }
        GuiHelper.GuiAssertNotNull("Could not find needed child objects.", new object[] { this.achievementUiGrid, this.scrollBar, this.tabSprite });
        this.categoryList = base.GetComponentInChildren<UIPopupList>();
        foreach (UIImageButton button in base.GetComponentsInChildren<UIImageButton>())
        {
            if (button.name == "FilterButton")
            {
                this.categoryButton = button;
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find popup list!", new object[] { this.categoryList, this.categoryButton });
        UIEventListener listener4 = UIEventListener.Get(this.categoryList.gameObject);
        listener4.onPress = (UIEventListener.BoolDelegate) Delegate.Combine(listener4.onPress, new UIEventListener.BoolDelegate(this.CategoryPress));
        UIEventListener listener5 = UIEventListener.Get(this.categoryList.gameObject);
        listener5.onHover = (UIEventListener.BoolDelegate) Delegate.Combine(listener5.onHover, new UIEventListener.BoolDelegate(this.CategoryHover));
        base.Init(2, true);
    }

    public void ToggleHideCommand(string[] args, EntityId playerEntityId)
    {
        this.Repopulate();
        this.scrollBar.scrollValue = 0f;
        if (!base.IsShowing())
        {
            this.achievementUiGrid.repositionNow = true;
        }
        this.ToggleWindowVisibility();
    }

    public override void ToggleWindowVisibility()
    {
        if (!base.IsShowing())
        {
            this.Repopulate();
            this.scrollBar.scrollValue = 0f;
            this.ShowWindow();
        }
        else
        {
            this.HideWindow();
        }
    }

    private delegate GenericAchievementData[] _GetFilteredAchievements();

    private enum Tabs
    {
        IN_PROGRESS,
        OTHER,
        COMPLETED,
        NUM_TABS,
        NONE
    }
}

