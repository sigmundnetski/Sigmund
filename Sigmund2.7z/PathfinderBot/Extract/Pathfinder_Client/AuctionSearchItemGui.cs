﻿using System;

public class AuctionSearchItemGui : AuctionItemGui
{
    public void OnClick()
    {
        if (base.selected)
        {
            AuctionHouseGui.singleton.OnSearchItemSelected(InventoryItem.EMPTY);
        }
        else
        {
            base.nameLabel.color = AuctionHouseGui.SELECTED_TEXT;
            AuctionHouseGui.singleton.OnSearchItemSelected(base.item);
        }
        base.prevColor = base.nameLabel.color;
    }

    public override void SetData(InventoryItem item_)
    {
        if (base.nameLabel == null)
        {
            base.nameLabel = base.transform.FindChild("HPO/Label").GetComponent<UILabel>();
        }
        if (base.icon == null)
        {
            base.icon = base.transform.FindChild("BackgroundIcon").GetComponent<UISprite>();
        }
        base.SetData(item_);
        base.UpdateSelected(AuctionHouseGui.singleton.currentItem);
    }
}

