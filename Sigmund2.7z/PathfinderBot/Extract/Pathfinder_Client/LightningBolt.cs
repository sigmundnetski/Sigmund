﻿using System;
using UnityEngine;

public class LightningBolt : MonoBehaviour
{
    public const float k_timeToLive = 1f;
    private Vector3 m_lastTargetPosition;
    private Perlin m_noise;
    private float m_oneOverZigs;
    private UnityEngine.Particle[] m_particles;
    private const float m_scale = 1f;
    private const float m_speed = 1f;
    private Transform m_target;
    public float m_timeAlive = 0f;
    private const int m_zigs = 100;

    private void Start()
    {
        GameObject obj2 = GameObject.Find("/Effects");
        if (obj2 == null)
        {
            obj2 = new GameObject("Effects");
        }
        base.transform.parent = obj2.transform;
        this.m_target = Targeting.selectedTarget.transform;
        this.m_lastTargetPosition = this.m_target.position;
        this.m_oneOverZigs = 0.01f;
        base.particleEmitter.emit = false;
        base.particleEmitter.Emit(100);
        this.m_particles = base.particleEmitter.particles;
    }

    private void Update()
    {
        this.m_timeAlive += Time.deltaTime;
        if (this.m_timeAlive > 1f)
        {
            UnityEngine.Object.Destroy(base.gameObject);
        }
        base.transform.position = PlayerEntityClient.GetPlayer().transform.position + Vector3.up;
        if (this.m_target != null)
        {
            this.m_lastTargetPosition = this.m_target.position + ((Vector3) (0.8f * Vector3.up));
        }
        Vector3 vector4 = this.m_lastTargetPosition - base.transform.position;
        Vector3 normalized = vector4.normalized;
        this.m_lastTargetPosition = base.transform.position + ((Vector3) (normalized * OffensiveFeatData.GetAttackByName("Levin Brand").range));
        if (this.m_noise == null)
        {
            this.m_noise = new Perlin();
        }
        float num = (Time.time * 1f) * 0.1365143f;
        float num2 = (Time.time * 1f) * 1.21688f;
        float num3 = (Time.time * 1f) * 2.5564f;
        for (int i = 0; i < this.m_particles.Length; i++)
        {
            Vector3 vector2 = Vector3.Lerp(base.transform.position, this.m_lastTargetPosition, this.m_oneOverZigs * i);
            Vector3 vector3 = new Vector3(this.m_noise.Noise(num + vector2.x, num + vector2.y, num + vector2.z), this.m_noise.Noise(num2 + vector2.x, num2 + vector2.y, num2 + vector2.z), this.m_noise.Noise(num3 + vector2.x, num3 + vector2.y, num3 + vector2.z));
            vector2 += (Vector3) ((vector3 * 1f) * (i * this.m_oneOverZigs));
            this.m_particles[i].position = vector2;
            this.m_particles[i].color = Color.white;
            this.m_particles[i].energy = 1f;
        }
        base.particleEmitter.particles = this.m_particles;
    }
}

