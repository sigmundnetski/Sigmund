﻿using GNGUI;
using System;
using UnityEngine;

public class CharacterListItem : MonoBehaviour
{
    private UILabel charName;
    private Color charNameColor = Color.white;
    private DisabledButton createButton;
    private DisabledButton deleteButton;
    private UILabel deletedLabel;
    private bool displayTraining = false;
    private bool isDeleted = false;
    public bool loaded = false;
    public uint playerId = 0;
    private UIImageButton trainButton;
    private UILabel trainButtonLabel;
    private UILabel trainLabel;
    private DisabledButton undeleteButton;

    public void Assign(PlayerInfo character, bool showCreateButton)
    {
        this.playerId = (character == null) ? 0 : character.playerId;
        NGUITools.SetActive(this.trainButton.gameObject, false);
        NGUITools.SetActive(this.trainLabel.gameObject, (character != null) && character.isTraining);
        this.trainButtonLabel.text = PlayerLoginClient.WillBeTraining(this.playerId) ? "Training" : "Not Training";
        if (character == null)
        {
            if (showCreateButton)
            {
                NGUITools.SetActive(this.createButton.gameObject, true);
            }
            else
            {
                NGUITools.SetActive(this.createButton.gameObject, false);
            }
            NGUITools.SetActive(this.charName.gameObject, false);
            NGUITools.SetActive(this.deleteButton.gameObject, false);
            NGUITools.SetActive(this.undeleteButton.gameObject, false);
            NGUITools.SetActive(this.deletedLabel.gameObject, false);
        }
        else
        {
            this.playerId = character.playerId;
            NGUITools.SetActive(this.createButton.gameObject, false);
            switch (character.permissions)
            {
                case CommandCore.PermissionLevel.GM:
                    this.charName.text = "[GM] " + character.playerName;
                    break;

                case CommandCore.PermissionLevel.TESTING:
                    this.charName.text = "{TESTING} " + character.playerName;
                    break;

                case CommandCore.PermissionLevel.DEBUG:
                    this.charName.text = "{DEBUG} " + character.playerName;
                    break;

                default:
                    this.charName.text = character.playerName;
                    break;
            }
            NGUITools.SetActive(this.charName.gameObject, true);
            this.Delete(this.playerId, character.isDeleted);
        }
    }

    public void Awake()
    {
        this.charName = base.GetComponentInChildren<UILabel>();
        foreach (DisabledButton button in base.GetComponentsInChildren<DisabledButton>())
        {
            if (button.name == "CreateButton")
            {
                this.createButton = button;
            }
            else if (button.name == "DeleteButton")
            {
                this.deleteButton = button;
            }
            else if (button.name == "UndeleteButton")
            {
                this.undeleteButton = button;
            }
        }
        foreach (UIImageButton button2 in base.GetComponentsInChildren<UIImageButton>())
        {
            if (button2.name == "TrainButton")
            {
                this.trainButton = button2;
                this.trainButtonLabel = button2.GetComponentInChildren<UILabel>();
            }
        }
        foreach (UILabel label in base.GetComponentsInChildren<UILabel>())
        {
            if (label.name == "TrainingLabel")
            {
                this.trainLabel = label;
            }
            if (label.name == "DeletedWarning")
            {
                this.deletedLabel = label;
                this.deletedLabel.text = "Will be deleted at 9 AM PST.";
            }
        }
        GuiHelper.GuiAssertNotNull(base.name + " could not find needed children.", new object[] { this.charName, this.createButton, this.deleteButton, this.undeleteButton, this.trainButton, this.trainLabel, this.deletedLabel });
        this.createButton.Awake();
        this.deleteButton.Awake();
        this.undeleteButton.Awake();
        UIEventListener listener1 = UIEventListener.Get(this.createButton.gameObject);
        listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(CharacterSelectionGui.CreateCharacter));
        UIEventListener listener2 = UIEventListener.Get(this.deleteButton.gameObject);
        listener2.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener2.onClick, new UIEventListener.VoidDelegate(this.DeleteCharacter));
        UIEventListener listener3 = UIEventListener.Get(this.undeleteButton.gameObject);
        listener3.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener3.onClick, new UIEventListener.VoidDelegate(this.UndeleteCharacter));
        UIEventListener listener4 = UIEventListener.Get(this.trainButton.gameObject);
        listener4.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener4.onClick, new UIEventListener.VoidDelegate(this.ToggleTraining));
        UIEventListener listener5 = UIEventListener.Get(this.charName.gameObject);
        listener5.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener5.onClick, new UIEventListener.VoidDelegate(this.SelectCharacter));
        UIEventListener listener6 = UIEventListener.Get(this.charName.gameObject);
        listener6.onHover = (UIEventListener.BoolDelegate) Delegate.Combine(listener6.onHover, new UIEventListener.BoolDelegate(this.OnHover));
        NGUITools.SetActive(this.createButton.gameObject, false);
        NGUITools.SetActive(this.deleteButton.gameObject, false);
        NGUITools.SetActive(this.undeleteButton.gameObject, false);
        NGUITools.SetActive(this.trainButton.gameObject, false);
        NGUITools.SetActive(this.charName.gameObject, false);
        NGUITools.SetActive(this.deletedLabel.gameObject, false);
    }

    public void Delete(uint playerId_, bool delete)
    {
        if (this.playerId == playerId_)
        {
            this.isDeleted = delete;
            this.deleteButton.IsDisabled(delete);
            NGUITools.SetActive(this.deleteButton.gameObject, !delete);
            NGUITools.SetActive(this.undeleteButton.gameObject, delete);
            NGUITools.SetActive(this.trainButton.gameObject, false);
            NGUITools.SetActive(this.deletedLabel.gameObject, delete);
            this.deletedLabel.text = "Will be deleted at " + CharacterManagementGui.singleton.localDeletionTime.ToShortTimeString() + " local time.";
        }
    }

    public void DeleteCharacter(GameObject go)
    {
        CharacterSelectionGui.singleton.DeleteCharacter(this.playerId);
    }

    public bool IsDeleted()
    {
        return this.isDeleted;
    }

    public void OnHover(GameObject go, bool isHovered)
    {
        Color color = isHovered ? CharacterSelectionGui.COLOR_CHAR_HOVERED : this.charNameColor;
        this.charName.color = color;
    }

    public void ResetColors()
    {
        this.Select(false);
        this.UpdateButtons(this.displayTraining);
        NGUITools.SetActive(this.trainLabel.gameObject, false);
    }

    public uint Select(bool isSelected)
    {
        this.charNameColor = isSelected ? CharacterSelectionGui.COLOR_CHAR_SELECTED : CharacterSelectionGui.COLOR_CHAR_UNSELECTED;
        this.charName.color = this.charNameColor;
        return this.playerId;
    }

    public void SelectCharacter(GameObject go)
    {
        if (!this.isDeleted)
        {
            CharacterSelectionGui.singleton.SelectCharacter(this.playerId);
            RedeemWindowGui.singleton.OnSelectCharacter();
        }
    }

    public void Start()
    {
        this.deleteButton.Assign(new string[] { "button_back_small_wide_di", "button_back_small_wide_di", "button_back_small_wide_di" }, new string[] { "button_back_small_wide_bad_de", "button_back_small_wide_bad_mo", "button_back_small_wide_bad_cl" }, CharacterSelectionGui.COLOR_TEXT_DISABLED, CharacterSelectionGui.COLOR_TEXT_NEGATIVE);
        this.undeleteButton.Assign(new string[] { "button_back_small_wide_di", "button_back_small_wide_di", "button_back_small_wide_di" }, new string[] { "button_back_small_wide_good_de", "button_back_small_wide_good_mo", "button_back_small_wide_good_cl" }, CharacterSelectionGui.COLOR_TEXT_DISABLED, CharacterSelectionGui.COLOR_TEXT_POSITIVE);
        this.createButton.Assign(new string[] { "button_back_small_wide_di", "button_back_small_wide_di", "button_back_small_wide_di" }, new string[] { "button_back_small_wide_good_de", "button_back_small_wide_good_mo", "button_back_small_wide_good_cl" }, CharacterSelectionGui.COLOR_TEXT_DISABLED, CharacterSelectionGui.COLOR_TEXT_POSITIVE);
        NGUITools.SetActive(this.trainLabel.gameObject, false);
        NGUITools.SetActive(this.trainButton.gameObject, false);
        this.deleteButton.IsDisabled(false);
        this.undeleteButton.IsDisabled(false);
        this.createButton.IsDisabled(false);
        this.trainButton.gameObject.SetActive(false);
        this.loaded = true;
    }

    public void ToggleTraining(GameObject go)
    {
        TwinWarningPopup.Hide();
        PlayerLoginClient.ToggleTraining(this.playerId);
        this.trainButtonLabel.text = PlayerLoginClient.WillBeTraining(this.playerId) ? "Training" : "Not Training";
        CharacterSelectionGui.singleton.OnTrainingToggle();
    }

    public void UndeleteCharacter(GameObject go)
    {
        CharacterSelectionGui.singleton.UndeleteCharacter(this.playerId);
    }

    public void UpdateButtons(bool displayTrainingButtons)
    {
        this.displayTraining = displayTrainingButtons;
        NGUITools.SetActive(this.deleteButton.gameObject, !this.displayTraining && !this.isDeleted);
        NGUITools.SetActive(this.undeleteButton.gameObject, !this.displayTraining && this.isDeleted);
        NGUITools.SetActive(this.deletedLabel.gameObject, !this.displayTraining && this.isDeleted);
        NGUITools.SetActive(this.trainButton.gameObject, (this.displayTraining && !this.isDeleted) && (this.playerId != 0));
    }
}

