﻿using GNGUI;
using System;
using System.Collections.Generic;
using UnityEngine;

public abstract class WindowTabGui : MonoBehaviour
{
    public ToggleText activeFilter;
    public List<ToggleText> allFilters = new List<ToggleText>();
    protected List<TabListItem> displayedItems = new List<TabListItem>();
    protected UIGrid gridList;
    protected GameObject listItemPrefab;
    protected string prefabName;
    protected UIScrollBar scrollBar;
    protected UIDraggablePanel scrollPanel;
    protected UISprite tabSprite;
    protected string tabSpriteName;

    protected WindowTabGui()
    {
    }

    public virtual void Awake()
    {
        this.gridList = base.GetComponentInChildren<UIGrid>();
        this.scrollBar = base.transform.parent.GetComponentInChildren<UIScrollBar>();
        this.scrollPanel = base.GetComponentInChildren<UIDraggablePanel>();
        foreach (UISprite sprite in base.transform.parent.GetComponentsInChildren<UISprite>())
        {
            if (sprite.name == "BackgroundTabs")
            {
                this.tabSprite = sprite;
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find needed children.", new object[] { this.gridList, this.scrollBar, this.scrollPanel, this.tabSprite });
    }

    protected void ClearListItems()
    {
        foreach (TabListItem item in this.displayedItems)
        {
            item.gameObject.SetActive(false);
            item.transform.parent = DragDropRoot.root;
            UnityEngine.Object.Destroy(item.gameObject);
        }
        this.displayedItems.Clear();
    }

    public virtual void ContentsChanged()
    {
        this.MakeListItems();
    }

    public virtual void FilterClicked(GameObject filterGO)
    {
        this.ResetScroll();
    }

    public virtual void HideTab()
    {
        NGUITools.SetActive(base.gameObject, false);
    }

    public bool IsShowing()
    {
        return NGUITools.GetActive(base.gameObject);
    }

    public virtual void LoadingTickFinished()
    {
        GuiHelper.GuiAssertNotNull("Need tabSpriteName and prefabName.", new object[] { this.tabSpriteName, this.prefabName });
        this.listItemPrefab = UIClient.guiPrefabs[this.prefabName];
        GuiHelper.GuiAssertNotNull("Couldn't find needed prefab.", new object[] { this.listItemPrefab });
    }

    protected abstract void MakeListItems();
    protected void ReduceListItemsToSize(int size)
    {
        if (size == 0)
        {
            this.ClearListItems();
        }
        else
        {
            while (size < this.displayedItems.Count)
            {
                TabListItem item = this.displayedItems[this.displayedItems.Count - 1];
                item.gameObject.SetActive(false);
                item.transform.parent = DragDropRoot.root;
                UnityEngine.Object.Destroy(item.gameObject);
                this.displayedItems.RemoveAt(this.displayedItems.Count - 1);
            }
        }
    }

    public virtual void RepositionListItems()
    {
        this.gridList.repositionNow = true;
    }

    public void ResetScroll()
    {
        this.scrollBar.scrollValue = 0f;
    }

    public virtual void ShowTab()
    {
        this.scrollPanel.verticalScrollBar = this.scrollBar;
        this.scrollBar.scrollValue = 0f;
        this.tabSprite.spriteName = this.tabSpriteName;
        NGUITools.SetActive(base.gameObject, true);
    }

    protected enum UpdateType
    {
        ADD,
        REMOVE
    }
}

