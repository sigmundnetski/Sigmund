﻿using GNGUI;
using System;
using UnityEngine;

public class CompanyApplicantsTabGui : CompanyAlliancesTabGui
{
    private UIImageButton confirmButton;
    private UIImageButton rejectButton;

    public override void AllianceSelected(ulong companyId_, uint settlementId_)
    {
        bool flag2;
        base.AllianceSelected(companyId_, settlementId_);
        VentureCompanyRecord settlementCompany = GroupClient.GetSettlementCompany();
        bool flag = GroupClient.InOwnerCompany(settlementCompany);
        if (companyId_ == 0L)
        {
            NGUITools.SetActive(this.confirmButton.gameObject, false);
            NGUITools.SetActive(this.rejectButton.gameObject, false);
        }
        else if (!flag)
        {
            NGUITools.SetActive(this.confirmButton.gameObject, false);
            NGUITools.SetActive(this.rejectButton.gameObject, false);
        }
        else
        {
            flag2 = settlementCompany.FindMember(EntityDataClient.owner.playerId).HasPermission(VentureCompanyMember.MemberPermission.ALLY_INVITE);
            NGUITools.SetActive(this.confirmButton.gameObject, flag2);
            NGUITools.SetActive(this.rejectButton.gameObject, flag2);
        }
        if (flag && (base.settlementId != 0))
        {
            flag2 = settlementCompany.FindMember(EntityDataClient.owner.playerId).HasPermission(VentureCompanyMember.MemberPermission.ALLY_INVITE);
            NGUITools.SetActive(this.confirmButton.gameObject, flag2);
            NGUITools.SetActive(this.rejectButton.gameObject, flag2);
        }
    }

    public override void Awake()
    {
        base.Awake();
        base.tabSpriteName = "frame_company_header_tab_right";
        foreach (UIImageButton button in base.GetComponentsInChildren<UIImageButton>())
        {
            if (button.name == "ButtonConfirm")
            {
                this.confirmButton = button;
            }
            else if (button.name == "ButtonReject")
            {
                this.rejectButton = button;
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find buttons.", new object[] { this.confirmButton, this.rejectButton });
        UIEventListener listener1 = UIEventListener.Get(this.confirmButton.gameObject);
        listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.ConfirmClicked));
        UIEventListener listener2 = UIEventListener.Get(this.rejectButton.gameObject);
        listener2.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener2.onClick, new UIEventListener.VoidDelegate(this.RejectClicked));
        NGUITools.SetActive(this.confirmButton.gameObject, false);
        NGUITools.SetActive(this.rejectButton.gameObject, false);
    }

    public void ConfirmClicked(GameObject go)
    {
        GroupClient.InviteAlliance(base.companyId, base.settlementId, true);
    }

    protected override void MakeListItems()
    {
        VentureCompanyRecord company = GroupClient.GetCompany(CompanyWindowGui.companyId);
        SettlementRecord settlement = null;
        int count = 0;
        if (company != null)
        {
            settlement = GroupClient.GetSettlement(company.settlementId);
        }
        if (settlement != null)
        {
            count = SparseArray.Count<uint>(settlement.invitedSettlementIds, GroupConst.EMPTY_SETTLEMENT) + SparseArray.Count<ulong>(settlement.invitedCompanyIds, GroupConst.EMPTY_COMPANY);
        }
        UIGrid.SetElementCount<TabListItem>(DragDropRoot.root, base.gridList, base.listItemPrefab, base.displayedItems, count);
        int index = 0;
        int num3 = 0;
        bool flag = false;
        bool flag2 = false;
        if ((settlement != null) && (settlement.invitedSettlementIds != null))
        {
            while (index < settlement.invitedSettlementIds.Length)
            {
                if (settlement.invitedSettlementIds[index] != 0)
                {
                    ((CompanyAllyInfo) base.displayedItems[num3]).Assign(settlement.invitedSettlementIds[index], this, num3, false);
                    num3++;
                    flag2 = flag2 || (settlement.invitedSettlementIds[index] == base.settlementId);
                }
                index++;
            }
        }
        index = 0;
        if ((settlement != null) && (settlement.invitedCompanyIds != null))
        {
            while (index < settlement.invitedCompanyIds.Length)
            {
                if (settlement.invitedCompanyIds[index] != 0L)
                {
                    ((CompanyAllyInfo) base.displayedItems[num3]).Assign(settlement.invitedCompanyIds[index], settlement, this, num3, false);
                    num3++;
                    flag = flag || (settlement.invitedCompanyIds[index] == base.companyId);
                }
                index++;
            }
        }
        if (!(flag && flag2))
        {
            base.settlementId = 0;
            base.companyId = 0L;
        }
        this.AllianceSelected(base.companyId, base.settlementId);
    }

    public void RejectClicked(GameObject go)
    {
        GroupClient.InviteAlliance(base.companyId, base.settlementId, false);
    }
}

