﻿using GNGUI;
using System;
using UnityEngine;

public class GamingTableDiceGUI : MonoBehaviour
{
    private GameObject diePrefab;
    private Transform gameButtons;
    private UILabel myGameName;
    private UILabel myGameScore;
    private UIGrid myGrid;
    private int myNextDieName = 0;
    private UILabel myRoundName;
    private UILabel myRoundScore;
    private UILabel opponentGameName;
    private UILabel opponentGameScore;
    private int opponentNextDieName = 0;
    private UILabel opponentRoundName;
    private UILabel opponentRoundScore;
    private UIGrid opponentsGrid;
    private UILabel roundNumber;
    private Transform roundOver;
    public static GamingTableDiceGUI singleton;
    private Transform waitingForPlayers;
    private Transform welcome;

    public void AddDieToGrid(int whichGrid, int dieValue)
    {
        GameObject obj2 = (GameObject) UnityEngine.Object.Instantiate(this.diePrefab, Vector3.zero, Quaternion.identity);
        switch (whichGrid)
        {
            case 0:
                obj2.name = "Die" + ((this.myNextDieName < 10) ? "0" : "") + this.myNextDieName;
                this.myNextDieName++;
                obj2.transform.parent = this.myGrid.transform;
                break;

            case 1:
                obj2.name = "Die" + ((this.opponentNextDieName < 10) ? "0" : "") + this.opponentNextDieName;
                this.opponentNextDieName++;
                obj2.transform.parent = this.opponentsGrid.transform;
                break;
        }
        obj2.transform.localRotation = Quaternion.identity;
        obj2.transform.localScale = Vector3.one;
        obj2.transform.localPosition = Vector3.zero;
        UISprite component = obj2.GetComponent<UISprite>();
        component.spriteName = "six_sided_" + dieValue;
        component.MakePixelPerfect();
        switch (whichGrid)
        {
            case 0:
                this.myGrid.Reposition();
                break;

            case 1:
                this.opponentsGrid.Reposition();
                break;
        }
    }

    public void AddOpponent(string opponentName)
    {
        this.myGameScore.text = string.Empty;
        this.myRoundScore.text = string.Empty;
        this.opponentGameName.text = opponentName;
        this.opponentRoundName.text = opponentName;
        this.opponentGameScore.text = string.Empty;
        this.opponentRoundScore.text = string.Empty;
    }

    public void Awake()
    {
        singleton = this;
        this.OnAwake();
    }

    public void ClearGrids()
    {
        int num;
        Transform child;
        for (num = this.myGrid.transform.childCount - 1; num >= 0; num--)
        {
            child = this.myGrid.transform.GetChild(num);
            child.gameObject.SetActive(false);
            child.parent = DragDropRoot.root;
            UnityEngine.Object.Destroy(child.gameObject);
        }
        for (num = this.opponentsGrid.transform.childCount - 1; num >= 0; num--)
        {
            child = this.opponentsGrid.transform.GetChild(num);
            child.gameObject.SetActive(false);
            child.parent = DragDropRoot.root;
            UnityEngine.Object.Destroy(child.gameObject);
        }
        this.myNextDieName = 0;
        this.opponentNextDieName = 0;
    }

    public void ContinueGame(GameObject go)
    {
        GamingTableClient.Continue();
        this.HideRoundOver();
    }

    public void FinishGameProcessing(int myPoints, int opponentPoints)
    {
        this.ClearGrids();
        this.ResetRoundScore();
        this.UpdateGamePoints(myPoints, opponentPoints);
        this.ShowWelcomeMessage();
    }

    public void HideAllChildren()
    {
        this.HideButtons();
        this.HideMessages();
        this.HideRoundOver();
        this.HideWelcomeMessage();
    }

    public void HideButtons()
    {
        NGUITools.SetActive(this.gameButtons.gameObject, false);
    }

    public void HideMessages()
    {
        NGUITools.SetActive(this.waitingForPlayers.gameObject, false);
    }

    public void HideRoundOver()
    {
        NGUITools.SetActive(this.roundOver.gameObject, false);
    }

    public void HideWelcomeMessage()
    {
        NGUITools.SetActive(this.welcome.gameObject, false);
    }

    public void HideWindow()
    {
        NGUITools.SetActive(base.gameObject, false);
    }

    private void Hold(GameObject go)
    {
        GamingTableClient.Roll(0);
        this.HideButtons();
        this.ShowWaitingMessage();
    }

    public bool IsShowing()
    {
        return NGUITools.GetActive(base.gameObject);
    }

    public void LeaveGame(GameObject go)
    {
        GamingTableClient.LeaveTable();
        this.HideWelcomeMessage();
    }

    public void LeftGamingTable()
    {
        this.HideWindow();
        this.ClearGrids();
        this.ResetRoundScore();
        this.ResetGameScore();
        this.RemoveOpponent();
    }

    public bool LoadingTickFinished()
    {
        this.ProcessGameScoreboard();
        this.ProcessGameButtons();
        this.ProcessWelcomeWindow();
        this.ProcessRoundOverWindow();
        UIPanel[] componentsInChildren = base.GetComponentsInChildren<UIPanel>();
        foreach (UIPanel panel in componentsInChildren)
        {
            if (panel.name == "MyDiceRolls")
            {
                this.myGrid = panel.GetComponentInChildren<UIGrid>();
            }
            if (panel.name == "OpponentDiceRolls")
            {
                this.opponentsGrid = panel.GetComponentInChildren<UIGrid>();
            }
        }
        if ((this.myGrid == null) || (this.opponentsGrid == null))
        {
            throw new Exception(string.Concat(new object[] { "Could not find needed child objects - mine: ", this.myGrid == null, ", others: ", this.opponentsGrid == null }));
        }
        this.diePrefab = UIClient.guiPrefabs["GamingTableDie"];
        this.HideWindow();
        return true;
    }

    private void OnAwake()
    {
        ClientTick.diceGuiLoadFinish = new GUtil.BoolFilterDelegate(this.LoadingTickFinished);
    }

    public void OnDestroy()
    {
        singleton = null;
    }

    public void PlayGame(GameObject go)
    {
        GamingTableClient.PlayGame();
        this.HideWelcomeMessage();
    }

    private void ProcessGameButtons()
    {
        this.gameButtons = base.transform.Find("GameplayButtons");
        UIButton[] componentsInChildren = this.gameButtons.GetComponentsInChildren<UIButton>();
        foreach (UIButton button in componentsInChildren)
        {
            UIEventListener listener4;
            UIEventListener listener3;
            UIEventListener listener2;
            string name = button.name;
            if (name != null)
            {
                if (!(name == "Button1d6"))
                {
                    if (name == "Button2d6")
                    {
                        goto Label_00B2;
                    }
                    if (name == "Button3d6")
                    {
                        goto Label_00E0;
                    }
                    if (name == "ButtonHold")
                    {
                        goto Label_010E;
                    }
                }
                else
                {
                    UIEventListener listener1 = UIEventListener.Get(button.gameObject);
                    listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.Roll1d6));
                }
            }
            continue;
        Label_00B2:
            listener2 = UIEventListener.Get(button.gameObject);
            listener2.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener2.onClick, new UIEventListener.VoidDelegate(this.Roll2d6));
            continue;
        Label_00E0:
            listener3 = UIEventListener.Get(button.gameObject);
            listener3.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener3.onClick, new UIEventListener.VoidDelegate(this.Roll3d6));
            continue;
        Label_010E:
            listener4 = UIEventListener.Get(button.gameObject);
            listener4.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener4.onClick, new UIEventListener.VoidDelegate(this.Hold));
        }
    }

    private void ProcessGameScoreboard()
    {
        UILabel[] componentsInChildren = base.transform.Find("GamingScoreboard").GetComponentsInChildren<UILabel>();
        foreach (UILabel label in componentsInChildren)
        {
            switch (label.name)
            {
                case "CurrentRoundNumber":
                    this.roundNumber = label;
                    break;

                case "MyGameName":
                    this.myGameName = label;
                    break;

                case "MyGameScore":
                    this.myGameScore = label;
                    break;

                case "MyRoundName":
                    this.myRoundName = label;
                    break;

                case "MyRoundScore":
                    this.myRoundScore = label;
                    break;

                case "OpponentGameName":
                    this.opponentGameName = label;
                    break;

                case "OpponentGameScore":
                    this.opponentGameScore = label;
                    break;

                case "OpponentRoundName":
                    this.opponentRoundName = label;
                    break;

                case "OpponentRoundScore":
                    this.opponentRoundScore = label;
                    break;
            }
        }
    }

    private void ProcessRoundOverWindow()
    {
        this.roundOver = base.transform.Find("StatusMessages/RoundOver");
        UIEventListener listener1 = UIEventListener.Get(this.roundOver.GetComponentInChildren<UIButton>().gameObject);
        listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.ContinueGame));
        this.waitingForPlayers = base.transform.Find("StatusMessages/WaitingForPlayers");
    }

    private void ProcessWelcomeWindow()
    {
        this.welcome = base.transform.Find("StatusMessages/Welcome");
        UIButton[] componentsInChildren = this.welcome.GetComponentsInChildren<UIButton>();
        foreach (UIButton button in componentsInChildren)
        {
            UIEventListener listener2;
            string name = button.name;
            if (name != null)
            {
                if (!(name == "ButtonPlay"))
                {
                    if (name == "ButtonLeave")
                    {
                        goto Label_008A;
                    }
                }
                else
                {
                    UIEventListener listener1 = UIEventListener.Get(button.gameObject);
                    listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.PlayGame));
                }
            }
            continue;
        Label_008A:
            listener2 = UIEventListener.Get(button.gameObject);
            listener2.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener2.onClick, new UIEventListener.VoidDelegate(this.LeaveGame));
        }
    }

    public void RemoveOpponent()
    {
        this.myGameScore.text = string.Empty;
        this.myRoundScore.text = string.Empty;
        this.opponentGameName.text = string.Empty;
        this.opponentRoundName.text = string.Empty;
        this.opponentGameScore.text = string.Empty;
        this.opponentRoundScore.text = string.Empty;
    }

    public void ResetGameScore()
    {
        this.myGameScore.text = string.Empty;
        this.opponentGameScore.text = string.Empty;
    }

    public void ResetRoundScore()
    {
        this.myRoundScore.text = string.Empty;
        this.opponentRoundScore.text = string.Empty;
    }

    private void Roll1d6(GameObject go)
    {
        GamingTableClient.Roll(1);
        this.HideButtons();
        this.ShowWaitingMessage();
    }

    private void Roll2d6(GameObject go)
    {
        GamingTableClient.Roll(2);
        this.HideButtons();
        this.ShowWaitingMessage();
    }

    private void Roll3d6(GameObject go)
    {
        GamingTableClient.Roll(3);
        this.HideButtons();
        this.ShowWaitingMessage();
    }

    public void ShowButtons()
    {
        NGUITools.SetActive(this.gameButtons.gameObject, true);
        this.HideMessages();
    }

    public void ShowRoundOver()
    {
        NGUITools.SetActive(this.roundOver.gameObject, true);
    }

    public void ShowWaitingMessage()
    {
        NGUITools.SetActive(this.waitingForPlayers.gameObject, true);
        this.HideButtons();
    }

    public void ShowWelcomeMessage()
    {
        NGUITools.SetActive(this.welcome.gameObject, true);
    }

    public void ShowWindow()
    {
        NGUITools.SetActive(base.gameObject, true);
        this.HideAllChildren();
    }

    public void UpdateGamePoints(int myPoints, int opponentPoints)
    {
        this.myGameScore.text = string.Concat(new object[] { string.Empty, myPoints, " point", ((myPoints == 1) || (myPoints == -1)) ? "" : "s" });
        this.opponentGameScore.text = string.Concat(new object[] { string.Empty, opponentPoints, " point", ((opponentPoints == 1) || (opponentPoints == -1)) ? "" : "s" });
    }

    public void UpdateName(string myName)
    {
        this.myGameName.text = myName;
        this.myRoundName.text = myName;
    }

    public void UpdateRoundScore(int whichPlayer, int count, int total)
    {
        string str = string.Concat(new object[] { string.Empty, total, " - ", count, (count == 1) ? " die" : " dice" });
        switch (whichPlayer)
        {
            case 0:
                this.myRoundScore.text = str;
                break;

            case 1:
                this.opponentRoundScore.text = str;
                break;
        }
    }
}

