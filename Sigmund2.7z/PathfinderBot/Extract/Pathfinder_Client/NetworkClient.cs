﻿using DiffieHellman;
using GNetwork;
using System;
using System.IO;
using System.Net;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;

public static class NetworkClient
{
    private static byte[] encpass;
    public static string errorMessage = null;
    public static IPAddress loginServerIP;
    private static string password;
    public static uint playerId;
    private static RSAPKCS1SignatureDeformatter RSADeformatter = null;
    public static GNetworkConnection serverConnection;
    private static string username;

    static NetworkClient()
    {
        string s = "-----BEGIN CERTIFICATE-----\r\nMIIEJDCCAwygAwIBAgIJAMbFTKLoqccyMA0GCSqGSIb3DQEBBQUAMGkxCzAJBgNV\r\nBAYTAlVTMQswCQYDVQQIEwJXQTEQMA4GA1UEBxMHUmVkbW9uZDEUMBIGA1UEChML\r\nR29ibGlud29ya3MxFDASBgNVBAsTC1Byb2dyYW1taW5nMQ8wDQYDVQQDEwZDb25u\r\nb3IwHhcNMTQwNjEzMTg1MDQwWhcNMTUwNjEzMTg1MDQwWjBpMQswCQYDVQQGEwJV\r\nUzELMAkGA1UECBMCV0ExEDAOBgNVBAcTB1JlZG1vbmQxFDASBgNVBAoTC0dvYmxp\r\nbndvcmtzMRQwEgYDVQQLEwtQcm9ncmFtbWluZzEPMA0GA1UEAxMGQ29ubm9yMIIB\r\nIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA1zGrVHSNtthA2ieKeM/XeEcE\r\nyYnJvHNQ3F4ff40s6A7TMD+QZ02yQPkqcRmi4dyfvFpX87pSiMLavMN8bcs3Edq6\r\nDxCG+ccyVJ9Bf9HNOPomwo9omQMd/BYU6fmRwuQ/1RbIjUCeXfwSKLk1C6Mhs8kW\r\nPeViYV/jljuV71tJ/dVJtrk4PhzJ1J2hCSakaFONo8TSyyvIc/u4l2ltdkGWvwIg\r\nmg6TebEiI8c6u7lgA/CLuhzyiUTL7HK4J/1YPfxwDIBjPS+069dd+1YlqeLaGH5v\r\n56gFmEGt3QXrkEzzls4TObX5rbGvStdbgplZmIvy0vgDgwmWj+3QC2dUAJEdEQID\r\nAQABo4HOMIHLMB0GA1UdDgQWBBTbAd+QhVgp2O/XgXESXhQwxqcD8zCBmwYDVR0j\r\nBIGTMIGQgBTbAd+QhVgp2O/XgXESXhQwxqcD86FtpGswaTELMAkGA1UEBhMCVVMx\r\nCzAJBgNVBAgTAldBMRAwDgYDVQQHEwdSZWRtb25kMRQwEgYDVQQKEwtHb2JsaW53\r\nb3JrczEUMBIGA1UECxMLUHJvZ3JhbW1pbmcxDzANBgNVBAMTBkNvbm5vcoIJAMbF\r\nTKLoqccyMAwGA1UdEwQFMAMBAf8wDQYJKoZIhvcNAQEFBQADggEBAJe8WOTlnsDo\r\ngFV/yu6e5SOrWmr8YhwwB9RmiIBgsfOGQ/ey8dguwyPzkxkaZxmdNaRhsCqUbs4x\r\nA6oK78Rvpl+fM7Rl1EuoTUW/1rflTki0ldwJeEmywpl0bqtK+MGl2sFcaaDqKIf3\r\n4MgSscWeZ32LRlal5c7VWAFVj7+itZ6OM4KnhKqtRsktg2zjernWaqyFTnPUgp5K\r\nF/fAXI5PYNCk1Uwoq3SCHc7ezgxvn8vLwYtpQ+wFnjQe3l9ey+J+OeCezWZCbpZw\r\nvWD9skI/9xURsyjIha0vL/79WE/Yqv3PAuIbzW+qmRvNDiI+TIALJyfN8fuupGUM\r\n8aTzwj68tGY=\r\n-----END CERTIFICATE-----";
        X509Certificate2 certificate = new X509Certificate2(new X509Certificate(Encoding.UTF8.GetBytes(s)));
        RSACryptoServiceProvider key = certificate.PublicKey.Key as RSACryptoServiceProvider;
        RSADeformatter = new RSAPKCS1SignatureDeformatter(key);
        RSADeformatter.SetHashAlgorithm("SHA1");
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void DHFinish(IBitBufferRead bytesIn)
    {
        if ((serverConnection != null) && (serverConnection.diffiehellman != null))
        {
            int num = bytesIn.PopInt();
            byte[] output = new byte[num];
            bytesIn.PopRawBuffer(ref output, num * 8, GConst.BufferErrorCode.ERROR_RAW_BITS);
            byte[] rgbHash = new SHA1CryptoServiceProvider().ComputeHash(output);
            int num2 = bytesIn.PopInt();
            byte[] buffer3 = new byte[num2];
            if (num2 > 0)
            {
                bytesIn.PopRawBuffer(ref buffer3, num2 * 8, GConst.BufferErrorCode.ERROR_RAW_BITS);
            }
            if (!GUtil.internalMode)
            {
                try
                {
                    if (!((num2 != 0) && RSADeformatter.VerifySignature(rgbHash, buffer3)))
                    {
                        GLog.LogError(new object[] { "Failed to verify server signature!", num2 });
                        PlayerLoginClient.LoginResult(false, true, 0L);
                        serverConnection.Disconnect("Login failure");
                        return;
                    }
                }
                catch (Exception)
                {
                    GLog.LogError(new object[] { "Exception while testing server signature!" });
                    PlayerLoginClient.LoginResult(false, true, 0L);
                    serverConnection.Disconnect("Login failure");
                    return;
                }
            }
            serverConnection.diffiehellman.HandleResponse(Encoding.UTF8.GetString(output));
            serverConnection.sharedKey = serverConnection.diffiehellman.Key;
            if ((serverConnection == null) || (serverConnection.sharedKey.Length == 0))
            {
                GLog.LogError(new object[] { "Invalid shared key!" });
                PlayerLoginClient.LoginResult(false, true, 0L);
                serverConnection.Disconnect("Login failure");
            }
            else
            {
                RijndaelManaged managed = new RijndaelManaged();
                managed.GenerateIV();
                if (serverConnection.sharedKey.Length < 0x20)
                {
                    GLog.LogWarning(new object[] { "Key generation failed, try again" });
                    DHStart();
                }
                else
                {
                    managed.Key = serverConnection.sharedKey;
                    ICryptoTransform transform = managed.CreateEncryptor();
                    encpass = null;
                    using (MemoryStream stream = new MemoryStream())
                    {
                        using (CryptoStream stream2 = new CryptoStream(stream, transform, CryptoStreamMode.Write))
                        {
                            using (StreamWriter writer = new StreamWriter(stream2))
                            {
                                writer.Write(password);
                            }
                            encpass = stream.ToArray();
                        }
                    }
                    GRouting.SetDefaultRoute(serverConnection);
                    BitBuffer quickBuffer = GUtil.GetQuickBuffer();
                    quickBuffer.PushString(GUtil.GetVersionId());
                    quickBuffer.PushUInt(playerId);
                    quickBuffer.PushString(username);
                    quickBuffer.PushInt(encpass.Length);
                    quickBuffer.PushRawBuffer(encpass, encpass.Length * 8);
                    quickBuffer.PushInt(managed.IV.Length);
                    quickBuffer.PushRawBuffer(managed.IV, managed.IV.Length * 8);
                    serverConnection.SendRpc(GRpcID.CredentialsServer_DHFinish, new object[] { quickBuffer });
                    serverConnection.NetLog1(new object[] { "Logging into LoginServer as:", username });
                }
            }
        }
    }

    public static void DHStart()
    {
        serverConnection.diffiehellman = new DiffieHellman.DiffieHellman(0x100).GenerateRequest();
        byte[] bytes = Encoding.UTF8.GetBytes(serverConnection.diffiehellman.ToString());
        BitBuffer quickBuffer = GUtil.GetQuickBuffer();
        quickBuffer.PushInt(bytes.Length);
        quickBuffer.PushRawBuffer(bytes, bytes.Length * 8);
        serverConnection.SendRpc(GRpcID.CredentialsServer_DHStart, new object[] { quickBuffer });
    }

    public static void SaveCredentials(IPAddress address, string usernameIn, string passwordIn)
    {
        loginServerIP = address;
        username = usernameIn;
        password = passwordIn;
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void UpdateQueuedStatus(bool isQueued)
    {
        LoadingMessageGUI.UpdateQueuedStatus(isQueued);
    }
}

