﻿using System;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using UnityEngine;

public abstract class BaseMotion : MonoBehaviour
{
    protected AnimController anim;
    protected AnimCue[] animsToDo = new AnimCue[5];
    protected AnimationData attackAnim = null;
    protected float attackAnimEnd = 0f;
    protected float attackAnimStart = 0f;
    private bool attackInProgress = false;
    protected bool attackInterrupted = false;
    protected bool attackIsOffhand = false;
    protected bool attackIsRooted = false;
    protected const float CLOSE_TO_GROUND = 0.25f;
    protected float colliderRadius;
    protected int crowdControlAnim = 0;
    protected float crowdControlAnimEnd = 0f;
    protected float crowdControlAnimStart = 0f;
    protected bool crowdControlInitialized = false;
    protected bool crowdControlIsRooted = false;
    private StreamWriter csvFile;
    protected JumpState currentJumpState = JumpState.NONE;
    public object[,] debugAnimInput = null;
    public object[,] debugAnimOutput = null;
    public bool debugInCombat = false;
    public bool debugManualLayers = false;
    public bool debugMode = false;
    public object[,] debugUserInput = null;
    protected const string DEFAULT_EXTERNAL_LOCK_REASON = "Cannot move until interaction window is closed.";
    protected float gatherAnimEnd = 0f;
    protected float gatherAnimStart = 0f;
    protected bool gathering = false;
    protected float jumpStartTime = 0f;
    public MovementChanged movementChanged = null;
    protected PositionLock positionLocked = PositionLock.None;
    private bool prevAttackInProgress = false;
    protected float prevHeight = 0f;
    public bool prevInCombat = false;
    private bool prevShowAsStealthed = false;
    private bool stealthed = false;
    private SwapState swapState = SwapState.Done;

    protected BaseMotion()
    {
    }

    private void AssignWeaponsToController(CombatVars combat)
    {
        int weaponCategoryId = combat.GetWeaponCategoryId(CombatClassVars.LogicalHand.MAIN_HAND);
        int num2 = combat.GetWeaponCategoryId(CombatClassVars.LogicalHand.OFF_HAND);
        this.anim.SetWeapon(weaponCategoryId, num2);
    }

    public void AttackInterrupted()
    {
        if (this.attackAnim != null)
        {
            this.attackInterrupted = true;
        }
    }

    public virtual void Awake()
    {
        this.anim = new GrannyController(base.gameObject);
        this.debugAnimOutput = this.anim.debugAnimOutput;
        this.debugAnimInput = this.anim.debugAnimInput;
    }

    public void ChangeDebugLevel(DebugLevel newLevel)
    {
        if (newLevel != this.debugLevel)
        {
            if ((this.debugLevel == DebugLevel.CsvFile) && (this.csvFile != null))
            {
                this.csvFile.Close();
                this.csvFile = null;
            }
            DebugLevel debugLevel = this.debugLevel;
            this.debugLevel = newLevel;
            if (this.debugLevel == DebugLevel.CsvFile)
            {
                int num;
                string path = GUtil.PathCombine(new object[] { Application.dataPath, "AnimDebug_" + base.gameObject.name + ".csv" });
                try
                {
                    this.csvFile = new StreamWriter(path);
                }
                catch
                {
                    this.debugLevel = debugLevel;
                    throw;
                }
                StringBuilder builder = new StringBuilder();
                builder.Append("Time,");
                if (this.debugUserInput != null)
                {
                    for (num = this.debugUserInput.GetLowerBound(0); num <= this.debugUserInput.GetUpperBound(0); num++)
                    {
                        builder.Append(this.debugUserInput[num, 0]).Append(",");
                    }
                }
                builder.Append(",");
                if (this.debugAnimInput != null)
                {
                    for (num = this.debugAnimInput.GetLowerBound(0); num <= this.debugAnimInput.GetUpperBound(0); num++)
                    {
                        builder.Append(this.debugAnimInput[num, 0]).Append(",");
                    }
                }
                builder.Append(",");
                if (this.debugAnimOutput != null)
                {
                    for (num = this.debugAnimOutput.GetLowerBound(0); num <= this.debugAnimOutput.GetUpperBound(0); num++)
                    {
                        builder.Append(this.debugAnimOutput[num, 0]).Append(",");
                    }
                }
                try
                {
                    this.csvFile.WriteLine(builder.ToString());
                }
                catch
                {
                    this.csvFile.Close();
                    this.csvFile = null;
                }
            }
            this.anim.debugLevel = this.debugLevel;
        }
    }

    public void ChangeWeapons(CombatVars combat)
    {
        this.swapState = SwapState.Stow;
        int weaponCategoryId = combat.GetWeaponCategoryId(CombatClassVars.LogicalHand.MAIN_HAND);
        int num2 = combat.GetWeaponCategoryId(CombatClassVars.LogicalHand.OFF_HAND);
        this.anim.SetWeapon(weaponCategoryId, num2);
    }

    public void ChangeWeapons(int mainhandCategoryId, int offhandCategoryId)
    {
        this.swapState = SwapState.Stow;
        this.anim.SetWeapon(mainhandCategoryId, offhandCategoryId);
    }

    public void DebugLoopAttack(int attackLoop, string animSet)
    {
        this.anim.DebugLoopAttack(attackLoop, animSet);
    }

    public void DoAttackAnim(AnimationData anim, float time, bool useOffhand, bool isRooted)
    {
        if (this.attackAnim != null)
        {
            this.ResetAttack();
        }
        this.attackAnim = anim;
        this.attackAnimEnd = Time.time + time;
        this.attackAnimStart = Time.time;
        this.attackIsOffhand = useOffhand;
        this.attackIsRooted = isRooted;
    }

    public virtual void DoCrowdControlAnim(int anim, float time, float amount, bool isRooted)
    {
        this.crowdControlAnim = anim;
        this.crowdControlAnimEnd = time + amount;
        this.crowdControlAnimStart = time;
        this.crowdControlIsRooted = isRooted;
    }

    public virtual void DoGatherAnim(float time, float duration)
    {
        this.gatherAnimStart = time;
        this.gatherAnimEnd = time + duration;
    }

    public void DoStealthAnim(bool enable)
    {
        if (enable != this.stealthed)
        {
            this.stealthed = enable;
            this.anim.SetStealth(this.stealthed);
        }
    }

    public virtual void DoUnconsciousAnim(bool isUnconscious)
    {
        this.anim.SetUnconscious(isUnconscious);
        if (isUnconscious)
        {
            this.ResetJump();
            this.ResetAttack();
            this.ResetCrowdControl();
        }
    }

    protected float HeightAboveGroundCollider()
    {
        RaycastHit hitInfo = new RaycastHit();
        if (Physics.SphereCast(base.transform.position + Vector3.up, this.colliderRadius, -Vector3.up, out hitInfo))
        {
            return (hitInfo.distance - 1f);
        }
        return float.NegativeInfinity;
    }

    public virtual void Initialize(Entity entity)
    {
        this.anim.Initialize(entity);
        if (entity.combat != null)
        {
            this.DoStealthAnim(entity.combat.stealthMode);
            this.DoUnconsciousAnim(entity.combat.deathState != CombatVars.DeathState.Alive);
        }
    }

    public virtual void OnAnimatorMove()
    {
        Entity entity = EntityCore.GetEntity(base.gameObject);
        bool inCombat = false;
        CombatVars.DeathState alive = CombatVars.DeathState.Alive;
        bool validEntity = false;
        if ((entity != null) && (entity.combat != null))
        {
            inCombat = entity.combat.inCombat;
            alive = entity.combat.deathState;
            validEntity = true;
        }
        if (this.debugInCombat)
        {
            inCombat = true;
        }
        this.anim.Update(validEntity, inCombat, this.prevInCombat, this.attackInProgress, this.prevAttackInProgress, this.attackIsRooted, alive, this.attackAnim, this.debugManualLayers);
        this.OutputDebugInfo();
        this.prevInCombat = inCombat;
        this.prevAttackInProgress = this.attackInProgress;
    }

    public virtual void OnDestroy()
    {
        if (this.csvFile != null)
        {
            this.csvFile.Close();
            this.csvFile = null;
        }
    }

    private void OutputDebugInfo()
    {
        if (this.debugLevel != DebugLevel.None)
        {
            if (this.debugLevel == DebugLevel.DebugConsole)
            {
                GLog.Log(new object[] { "Debug Input:", this.debugAnimInput, "\nDebugOutput:", this.debugAnimOutput });
            }
            else if (this.debugLevel == DebugLevel.CsvFile)
            {
                int num;
                StringBuilder builder = new StringBuilder();
                builder.Append(Time.time).Append(",");
                if (this.debugUserInput != null)
                {
                    for (num = this.debugUserInput.GetLowerBound(0); num <= this.debugUserInput.GetUpperBound(0); num++)
                    {
                        builder.Append(this.debugUserInput[num, 1]).Append(",");
                    }
                }
                builder.Append(",");
                if (this.debugAnimInput != null)
                {
                    for (num = this.debugAnimInput.GetLowerBound(0); num <= this.debugAnimInput.GetUpperBound(0); num++)
                    {
                        builder.Append(this.debugAnimInput[num, 1]).Append(",");
                    }
                }
                builder.Append(",");
                if (this.debugAnimOutput != null)
                {
                    for (num = this.debugAnimOutput.GetLowerBound(0); num <= this.debugAnimOutput.GetUpperBound(0); num++)
                    {
                        builder.Append(this.debugAnimOutput[num, 1]).Append(",");
                    }
                }
                try
                {
                    this.csvFile.WriteLine(builder.ToString());
                }
                catch
                {
                    this.csvFile.Close();
                    this.csvFile = null;
                }
            }
        }
    }

    protected virtual void ProcessAnimCues(float time)
    {
        for (int i = 0; i < this.animsToDo.Length; i++)
        {
            if ((this.animsToDo[i] != null) && (this.animsToDo[i].startTime <= time))
            {
                AnimCue cue = this.animsToDo[i];
                if (cue.type == Combat.AnimType.Gather)
                {
                    if (!(this.gathering || (cue.amount <= 0f)))
                    {
                        this.gathering = true;
                        this.DoGatherAnim(time, cue.amount);
                    }
                    else
                    {
                        this.gathering = false;
                        this.ResetGather();
                    }
                }
                this.animsToDo[i] = null;
            }
        }
    }

    protected void ProcessAttack(float currentTime, float attackStartTime, ref float attackEndTime)
    {
        if (((MovementClient.DRAW.id == this.attackAnim.id) && !EntityLoadClient.GetWeaponVis(base.gameObject)) && (currentTime > (attackStartTime + 0.15f)))
        {
            EntityLoadClient.SetWeaponVis(base.gameObject, true);
        }
        else if (MovementClient.SWAP.id == this.attackAnim.id)
        {
            float num = ((attackEndTime - attackStartTime) / 2f) + attackStartTime;
            if ((this.swapState == SwapState.Stow) && (currentTime > (num - 0.15f)))
            {
                EntityLoadClient.SetWeaponVis(base.gameObject, false);
                Entity entity = EntityCore.GetEntity(base.gameObject);
                this.AssignWeaponsToController(entity.combat);
                EntityLoadClient.UpdateWeaponTypes(entity);
                this.swapState = SwapState.Draw;
            }
            else if ((this.swapState == SwapState.Draw) && (currentTime > (num + 0.15f)))
            {
                EntityLoadClient.SetWeaponVis(base.gameObject, true);
                this.swapState = SwapState.Done;
            }
        }
        else if (((MovementClient.STOW.id == this.attackAnim.id) && EntityLoadClient.GetWeaponVis(base.gameObject)) && (currentTime > (attackEndTime - 0.15f)))
        {
            EntityLoadClient.SetWeaponVis(base.gameObject, false);
        }
        if (currentTime < (attackStartTime + 0.4f))
        {
            this.attackInProgress = true;
            if (this.attackIsRooted)
            {
                this.positionLocked |= PositionLock.RootedAttack;
            }
            this.anim.ProcessAttack(this.attackAnim, this.attackIsOffhand, this.attackIsRooted, this.attackInterrupted, currentTime, ref attackEndTime);
        }
        else if (currentTime < attackEndTime)
        {
            this.anim.ProcessAttack(this.attackAnim, this.attackIsOffhand, this.attackIsRooted, this.attackInterrupted, currentTime, ref attackEndTime);
            if (this.attackInterrupted)
            {
                this.attackInterrupted = false;
            }
        }
        else
        {
            this.ResetAttack();
        }
    }

    protected void ProcessCrowdControl(float currentTime, float crowdControlStartTime, float crowdControlEndTime)
    {
        bool initialize = false;
        if (((this.crowdControlAnim > 0) && !this.crowdControlInitialized) && (currentTime < (crowdControlStartTime + 0.04f)))
        {
            this.crowdControlInitialized = true;
            initialize = true;
            if (this.crowdControlIsRooted)
            {
                this.positionLocked |= PositionLock.CrowdControl;
            }
            this.anim.ProcessCrowdControl(initialize, (float) this.crowdControlAnim, crowdControlEndTime - crowdControlStartTime);
        }
        else if (currentTime >= this.crowdControlAnimEnd)
        {
            this.ResetCrowdControl();
        }
    }

    protected void ProcessGather(float currentTime, float gatherStartTime, float gatherEndTime)
    {
        if (currentTime < (this.gatherAnimStart + 0.04f))
        {
            this.anim.ProcessGather();
        }
        else if (currentTime >= this.gatherAnimEnd)
        {
            this.ResetGather();
        }
    }

    public void ProcessStealth(bool forceChange = false)
    {
        Entity entity = EntityCore.GetEntity(base.gameObject);
        if ((entity != null) && (EntityDataClient.owner != null))
        {
            bool stealthed;
            if (entity.entityId == EntityDataClient.owner.entityId)
            {
                stealthed = this.stealthed;
            }
            else
            {
                float num = CombatCore.StealthVisibilityPercentage(entity.combat, CombatClient.playerCombatVars);
                float num2 = Vector3.Distance(base.transform.position, PlayerEntityClient.GetPlayer().transform.position);
                stealthed = ((entity.combat != null) && entity.combat.stealthMode) && (num2 > (40f * num));
            }
            if ((stealthed != this.prevShowAsStealthed) || forceChange)
            {
                if (stealthed)
                {
                    EntityLoadClient.ChangeCharacterShader(base.gameObject, EntityLoadClient.ShaderType.STEALTH);
                }
                else
                {
                    EntityLoadClient.ChangeCharacterShader(base.gameObject, EntityLoadClient.ShaderType.DEFAULT);
                }
                this.prevShowAsStealthed = stealthed;
            }
        }
    }

    protected void ResetAttack()
    {
        if (this.attackIsRooted)
        {
            this.positionLocked &= ~PositionLock.RootedAttack;
        }
        int prevAttack = (this.attackAnim == null) ? 0 : this.attackAnim.id;
        if ((prevAttack == MovementClient.DRAW.id) || (prevAttack == MovementClient.SWAP.id))
        {
            if (!EntityLoadClient.GetWeaponVis(base.gameObject))
            {
                EntityLoadClient.SetWeaponVis(base.gameObject, true);
            }
        }
        else if ((prevAttack == MovementClient.STOW.id) && EntityLoadClient.GetWeaponVis(base.gameObject))
        {
            EntityLoadClient.SetWeaponVis(base.gameObject, false);
        }
        this.attackIsOffhand = false;
        this.attackIsRooted = false;
        this.attackAnim = null;
        this.attackInterrupted = false;
        this.attackInProgress = false;
        this.anim.ResetAttack(prevAttack);
    }

    protected void ResetCrowdControl()
    {
        if (this.crowdControlIsRooted)
        {
            this.positionLocked &= ~PositionLock.CrowdControl;
        }
        this.crowdControlAnim = 0;
        this.crowdControlInitialized = false;
        this.crowdControlIsRooted = false;
        this.anim.ResetCrowdControl();
    }

    protected void ResetGather()
    {
        this.gatherAnimStart = 0f;
        this.gatherAnimEnd = 0f;
        this.anim.ResetGather();
    }

    protected void ResetJump()
    {
        this.currentJumpState = JumpState.NONE;
        this.anim.ResetJump();
    }

    protected float SmoothInput(float smoothedInput, float rawInput, float maxDelta)
    {
        if (smoothedInput < rawInput)
        {
            smoothedInput = Mathf.Min(smoothedInput + maxDelta, rawInput);
            return smoothedInput;
        }
        if (smoothedInput > rawInput)
        {
            smoothedInput = Mathf.Max(smoothedInput - maxDelta, rawInput);
        }
        return smoothedInput;
    }

    public virtual void Start()
    {
        this.anim.Start();
        CharacterController component = base.GetComponent<CharacterController>();
        CapsuleCollider collider = base.GetComponent<CapsuleCollider>();
        if (component != null)
        {
            this.colliderRadius = component.radius;
        }
        else if (collider != null)
        {
            this.colliderRadius = collider.radius;
        }
        else
        {
            Debug.LogError("Cannot find collider on " + base.gameObject.name);
        }
    }

    protected void UpdateJump()
    {
        float num = 0f;
        bool flag = false;
        if (this.currentJumpState != JumpState.NONE)
        {
            num = this.HeightAboveGroundCollider();
            flag = num <= this.prevHeight;
        }
        switch (this.currentJumpState)
        {
            case JumpState.NONE:
                return;

            case JumpState.LIFT_OFF:
                this.anim.UpdateJump(this.currentJumpState);
                this.currentJumpState = JumpState.FLY;
                if (this.movementChanged != null)
                {
                    this.movementChanged(base.gameObject, Movement.MovementType.JumpStart);
                }
                break;

            case JumpState.FLY:
                if (flag && (num < MovementData.singleton.jumpToLandTransition))
                {
                    this.currentJumpState = JumpState.HIT_GROUND;
                }
                if ((Time.time - this.jumpStartTime) > MovementData.singleton.jumpToFallTime)
                {
                    this.currentJumpState = JumpState.FALL;
                }
                break;

            case JumpState.FALL:
                if (flag && (num < MovementData.singleton.jumpToLandTransition))
                {
                    this.currentJumpState = JumpState.HIT_GROUND;
                }
                if ((Time.time - this.jumpStartTime) > MovementData.singleton.jumpToSuperFallTime)
                {
                    this.currentJumpState = JumpState.SUPER_FALL;
                }
                break;

            case JumpState.SUPER_FALL:
                if (flag && (num < MovementData.singleton.jumpToLandTransition))
                {
                    this.currentJumpState = JumpState.HIT_GROUND;
                }
                break;

            case JumpState.HIT_GROUND:
                if (num < 0.25f)
                {
                    this.currentJumpState = JumpState.END;
                }
                break;

            case JumpState.END:
                if (!this.anim.InJumpStates())
                {
                    this.ResetJump();
                    if (this.movementChanged != null)
                    {
                        this.movementChanged(base.gameObject, Movement.MovementType.JumpEnd);
                    }
                }
                break;
        }
        this.anim.UpdateJump(this.currentJumpState);
        this.prevHeight = num;
    }

    public DebugLevel debugLevel { get; protected set; }

    protected class AnimCue
    {
        public readonly float amount;
        public readonly bool enable;
        public readonly Vector3 originPosition;
        public readonly float startTime;
        public readonly Combat.AnimType type;

        public AnimCue(Combat.AnimType type_, float startTime_, bool enable_)
        {
            this.type = type_;
            this.startTime = startTime_;
            this.enable = enable_;
            this.amount = 0f;
            this.originPosition = GConst.VECTOR3_INVALID;
        }

        public AnimCue(Combat.AnimType type_, float startTime_, float amount_, Vector3 originPosition_)
        {
            this.type = type_;
            this.startTime = startTime_;
            this.amount = amount_;
            this.originPosition = originPosition_;
            this.enable = false;
        }
    }

    public enum DebugLevel
    {
        None,
        InspectorOnly,
        DebugConsole,
        CsvFile
    }

    public enum JumpState
    {
        NONE,
        LIFT_OFF,
        FLY,
        FALL,
        SUPER_FALL,
        HIT_GROUND,
        END
    }

    public delegate void MovementChanged(GameObject entityGO, Movement.MovementType moveType);

    [Flags]
    public enum PositionLock
    {
        CrowdControl = 2,
        External = 0x100,
        EXTERNAL_LOCKS_BEGIN = 0x100,
        None = 0,
        RootedAttack = 4,
        RootedGuiInteract = 0x200,
        Unconscious = 1
    }

    private enum SwapState
    {
        Stow,
        Draw,
        Done
    }
}

