﻿using GNetwork;
using GNGUI;
using System;
using System.Net;
using System.Net.Sockets;
using UnityEngine;

public class ClientLoginGui : MonoBehaviour
{
    private Color disabledButtonText = new Color(0.5019608f, 0.5019608f, 0.5019608f);
    private Color enabledButtonText = new Color(0.9411765f, 0.8901961f, 0.6588235f);
    private UILabel errorLabel = null;
    private UIInput ipInput = null;
    private DisabledButton loginButton = null;
    private UIInput passwordInput = null;
    private const int PERMABAN_YEARS = 5;
    private bool prevButtonDisabled = true;
    private string serverName = "";
    private static string serverParameter = null;
    public static ClientLoginGui singleton;
    private bool tryConnecting = false;
    private string username = "";
    private UIInput usernameInput = null;
    private static string usernameParameter = null;

    static ClientLoginGui()
    {
        serverParameter = StartupParameters.RemoveParameterToProcess("server");
        usernameParameter = StartupParameters.RemoveParameterToProcess("username");
    }

    public void Awake()
    {
        singleton = this;
    }

    public void ClientConnect(GameObject go)
    {
        if (!this.loginButton.disabled)
        {
            this.tryConnecting = true;
            this.errorLabel.text = string.Empty;
        }
    }

    private void ConnectToServer()
    {
        IPAddress[] hostAddresses;
        if (GUtil.internalMode)
        {
            this.serverName = this.ipInput.text;
        }
        try
        {
            hostAddresses = Dns.GetHostAddresses(this.serverName);
        }
        catch (SocketException)
        {
            hostAddresses = new IPAddress[0];
        }
        bool flag = (GNetworkService.GetNetworkState() == GNetworkService.NetworkState.NOT_CONNECTED) || (GNetworkService.GetNetworkState() == GNetworkService.NetworkState.CLIENT_DISCONNECTED);
        bool flag2 = (this.usernameInput.text.IndexOf('<') == -1) && (this.usernameInput.text.Length > 2);
        bool flag3 = hostAddresses.Length == 1;
        if ((!flag || !flag2) || !flag3)
        {
            Debug.LogError(string.Concat(new object[] { "Could not connect", flag, flag2, flag3 }));
            string str = string.Empty;
            if (!flag)
            {
                str = "invalid network state";
            }
            else
            {
                if (!flag2)
                {
                    str = "invalid username";
                }
                if (!flag3)
                {
                    str = str + ((str != string.Empty) ? ", " : "") + "invalid IP/server name";
                }
            }
            this.errorLabel.text = "Could not connect: " + str;
        }
        else
        {
            NGUITools.SetActive(base.gameObject, false);
            LoadingMessageGUI.UpdateLoadingStatus(true, "Connecting to Server...");
            if (!this.username.Equals(this.usernameInput.text, StringComparison.OrdinalIgnoreCase))
            {
                PlayerPrefs.SetString("username", this.usernameInput.text);
            }
            if (GUtil.internalMode)
            {
                PlayerPrefs.SetString("server", this.serverName);
            }
            NetworkClient.SaveCredentials(hostAddresses[0], this.usernameInput.text, this.passwordInput.text);
            if (!PlayerLoginClient.ConnectToLoginServer())
            {
                NGUITools.SetActive(base.gameObject, true);
                LoadingMessageGUI.UpdateLoadingStatus(false, "Could not connect to: " + this.serverName);
                this.errorLabel.text = "Could not connect to: " + this.serverName;
            }
        }
    }

    public void FixedUpdate()
    {
        if (this.tryConnecting)
        {
            this.ConnectToServer();
            this.tryConnecting = false;
        }
    }

    public void FocusPassword(GameObject go)
    {
        UICamera.selectedObject = this.passwordInput.gameObject;
        this.passwordInput.selected = true;
    }

    public bool LoadingTickFinished()
    {
        GNetworkService.SetNetworkState(GNetworkService.NetworkState.NOT_CONNECTED);
        LoadingMessageGUI.UpdateLoadingStatus(false, "Client loading complete.");
        this.username = PlayerPrefs.GetString("username");
        if (!string.IsNullOrEmpty(this.username))
        {
            this.usernameInput.text = this.username;
        }
        this.serverName = "pfo.goblinworks.com";
        if (GUtil.internalMode)
        {
            string str = PlayerPrefs.GetString("server");
            if ((str != null) && (str.Length > 0))
            {
                this.serverName = str;
            }
        }
        if (!string.IsNullOrEmpty(serverParameter))
        {
            this.serverName = serverParameter;
        }
        this.ipInput.text = this.serverName;
        if (!string.IsNullOrEmpty(NetworkClient.errorMessage))
        {
            this.errorLabel.text = NetworkClient.errorMessage;
        }
        if (!string.IsNullOrEmpty(usernameParameter))
        {
            this.usernameInput.text = usernameParameter;
            usernameParameter = string.Empty;
            if (GUtil.internalMode)
            {
                this.tryConnecting = true;
            }
        }
        StaticSplashGui.singleton.Hide();
        return true;
    }

    public void LoginFailure(bool matchingVersions, long banTimeout)
    {
        if (!matchingVersions)
        {
            this.errorLabel.text = "Your client is not the same version as the current server.";
        }
        else if (banTimeout != 0L)
        {
            DateTime time = DateTime.FromBinary(banTimeout);
            TimeSpan span = (TimeSpan) (time - GNetworkService.ServerUtc);
            DateTime time2 = DateTime.Now + span;
            if (time > GNetworkService.ServerUtc.AddYears(5))
            {
                this.errorLabel.text = "Your account is permanently banned.";
            }
            else
            {
                this.errorLabel.text = "Your account is banned until " + time2 + " local time.";
            }
        }
        else
        {
            this.errorLabel.text = "Login failed";
        }
        NGUITools.SetActive(base.gameObject, true);
        LoadingMessageGUI.UpdateLoadingStatus(false, "Client loading complete.");
    }

    public void OnDestroy()
    {
        singleton = null;
    }

    public void Start()
    {
        ClientLoginTick.loginGuiLoadFinished = new GUtil.BoolFilterDelegate(this.LoadingTickFinished);
        UIInput[] componentsInChildren = base.GetComponentsInChildren<UIInput>();
        foreach (UIInput input in componentsInChildren)
        {
            if (input.name == "PasswordInput")
            {
                this.passwordInput = input;
            }
            else if (input.name == "UsernameInput")
            {
                this.usernameInput = input;
            }
            else if (input.name == "IPInput")
            {
                this.ipInput = input;
            }
        }
        this.loginButton = base.GetComponentInChildren<DisabledButton>();
        foreach (UILabel label in base.GetComponentsInChildren<UILabel>())
        {
            if (label.name == "ErrorLabel")
            {
                this.errorLabel = label;
            }
        }
        GuiHelper.GuiAssertNotNull("Error starting ClientLoginGui:", new object[] { this.loginButton, this.passwordInput, this.usernameInput, this.ipInput, this.errorLabel });
        UIEventListener listener1 = UIEventListener.Get(this.loginButton.gameObject);
        listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.ClientConnect));
        UIEventListener listener2 = UIEventListener.Get(this.usernameInput.gameObject);
        listener2.onSubmit = (UIEventListener.VoidDelegate) Delegate.Combine(listener2.onSubmit, new UIEventListener.VoidDelegate(this.FocusPassword));
        UIEventListener listener3 = UIEventListener.Get(this.passwordInput.gameObject);
        listener3.onSubmit = (UIEventListener.VoidDelegate) Delegate.Combine(listener3.onSubmit, new UIEventListener.VoidDelegate(this.ClientConnect));
        this.loginButton.Assign(new string[] { "button_crafting_disabled_de", "button_crafting_disabled_de", "button_crafting_disabled_de" }, new string[] { "button_crafting_general_de", "button_crafting_general_mo", "button_crafting_general_cl" }, this.disabledButtonText, this.enabledButtonText);
        this.loginButton.IsDisabled(true);
        if (!GUtil.internalMode)
        {
            this.ipInput.gameObject.SetActive(false);
        }
    }

    public void Update()
    {
        bool flag = false;
        if (this.usernameInput != null)
        {
            flag = (this.usernameInput.text.IndexOf('<') == -1) && (this.usernameInput.text.Length > 2);
        }
        bool flag2 = (GNetworkService.GetNetworkState() == GNetworkService.NetworkState.NOT_CONNECTED) || (GNetworkService.GetNetworkState() == GNetworkService.NetworkState.CLIENT_DISCONNECTED);
        bool isDisabled = (!flag || !flag2) || this.tryConnecting;
        if (isDisabled != this.prevButtonDisabled)
        {
            this.loginButton.IsDisabled(isDisabled);
        }
        this.prevButtonDisabled = isDisabled;
    }
}

