﻿using GNGUI;
using System;
using System.Text;

internal class TextBlobGui : WindowGui
{
    private static UILabel blobLabel;
    private static UIScrollBar blobScroll;
    private static int[] curBlobIds = new int[4];
    private static UIDraggablePanel dragPanel;
    public static TextBlobGui singleton;

    public void Awake()
    {
        singleton = this;
    }

    public static void Display(params int[] blobIds)
    {
        if ((singleton != null) && (!singleton.IsShowing() || !SparseArray.DeepEqualsWithIndex<int>(curBlobIds, blobIds)))
        {
            DataSerializerUtils.DataCopyField<int>(blobIds, ref curBlobIds);
            blobScroll.scrollValue = 0f;
            StringBuilder quickText = GUtil.GetQuickText();
            for (int i = 0; i < blobIds.Length; i++)
            {
                TextBlobData data;
                if ((blobIds[i] != 0) && TextBlobData.blobById.TryGetValue(blobIds[i], out data))
                {
                    if (quickText.Length > 0)
                    {
                        quickText.Append("\n\n");
                    }
                    quickText.Append(data.blobText);
                }
            }
            if (quickText.Length > 0)
            {
                blobLabel.text = quickText.ToString();
                dragPanel.repositionNow = true;
                singleton.ShowWindow();
            }
            else
            {
                singleton.HideWindow();
            }
        }
    }

    public override void HideWindow()
    {
        SparseArray.Clear<int>(ref QuestClient.curBlobQuestIds, 0);
        base.HideWindow();
    }

    public override void OnDestroy()
    {
        base.OnDestroy();
        singleton = null;
    }

    public void Start()
    {
        foreach (UILabel label in base.transform.GetComponentsInChildren<UILabel>(true))
        {
            if (label.gameObject.name == "QuestBodyText")
            {
                blobLabel = label;
            }
        }
        blobScroll = base.transform.FindChild("TextScrollBar").GetComponent<UIScrollBar>();
        dragPanel = base.GetComponentInChildren<UIDraggablePanel>();
        GuiHelper.GuiAssertNotNull("Couldn't load prefabs.", new object[] { blobLabel, blobScroll, dragPanel });
        base.Init(2, true);
    }
}

