﻿using System;

public static class CapturePointClient
{
    private static int lastCaptureHash = 0;

    public static void OnClientEntityUpdate(Entity entity)
    {
        int num = ((entity.entityId == EntityDataClient.owner.entityId) && (entity.capturePointVars != null)) ? entity.capturePointVars.GetCaptureHash() : 0;
        if (num != lastCaptureHash)
        {
            HexConflictHover.Refresh();
        }
        lastCaptureHash = num;
    }

    public static void PrintCPV(string[] args, EntityId playerEntityId)
    {
        if (EntityDataClient.owner.capturePointVars != null)
        {
            DebugClient.GenericDebugMessage(EntityDataClient.owner.capturePointVars.ToString());
        }
        else
        {
            DebugClient.GenericDebugMessage("Null CPV");
        }
    }
}

