﻿using GNetwork;
using GNGUI;
using System;
using System.Collections.Generic;
using UnityEngine;

public class TreasureBoxSelectorGui : WindowGui
{
    private static bool isLoaded = false;
    private GameObject lootOptionPrefab;
    private static List<TreasureBoxGridItem> lootTableElements = new List<TreasureBoxGridItem>();
    private UIGrid lootTableGrid;
    private UIScrollBar mainScroll;
    private UIImageButton openButton;
    public static int selectedTableId = 0;
    public static TreasureBoxSelectorGui singleton;
    public static TreasureBoxItemData tboxItem;

    public void Awake()
    {
        singleton = this;
    }

    public override void OnDestroy()
    {
        base.OnDestroy();
        singleton = null;
    }

    public void OnOpenClicked(GameObject go)
    {
        if (selectedTableId != 0)
        {
            GRouting.SendMyMapRpc(GRpcID.InventoryServer_OpenTreasureBox, new object[] { tboxItem.id, selectedTableId });
            this.HideWindow();
        }
    }

    public static void OpenTreasureBox(int newItemId)
    {
        tboxItem = ItemDatabase.GetItem(newItemId) as TreasureBoxItemData;
        if (((tboxItem != null) && (tboxItem.lootTableIdOptions != null)) && (tboxItem.lootTableIdOptions.Length != 0))
        {
            if (tboxItem.lootTableIdOptions.Length == 1)
            {
                GRouting.SendMyMapRpc(GRpcID.InventoryServer_OpenTreasureBox, new object[] { newItemId, tboxItem.lootTableIdOptions[0] });
            }
            else
            {
                singleton.Refresh();
                singleton.mainScroll.scrollValue = 0f;
            }
        }
    }

    public void Refresh()
    {
        if (isLoaded)
        {
            GLog.Log(new object[] { "TreasureBoxSelectorGui.Refresh", tboxItem.lootTableIdOptions.Length });
            UIGrid.SetElementCount<TreasureBoxGridItem>(DragDropRoot.root, this.lootTableGrid, this.lootOptionPrefab, lootTableElements, tboxItem.lootTableIdOptions.Length);
            for (int i = 0; i < tboxItem.lootTableIdOptions.Length; i++)
            {
                lootTableElements[i].SetItem(tboxItem.lootTableIdOptions[i], tboxItem.lootTableIdOptions[i] == selectedTableId);
            }
            this.ShowWindow();
        }
    }

    public void Start()
    {
        this.lootOptionPrefab = UIClient.guiPrefabs["TreasureBoxGridItem"];
        this.lootTableGrid = base.GetComponentInChildren<UIGrid>();
        this.mainScroll = base.GetComponentInChildren<UIScrollBar>();
        foreach (UIImageButton button in base.GetComponentsInChildren<UIImageButton>())
        {
            if (button.name == "OpenButton")
            {
                this.openButton = button;
            }
        }
        GuiHelper.GuiAssertNotNull("Error starting TreasureBoxSelectorGui:", new object[] { this.lootOptionPrefab, this.lootTableGrid, this.mainScroll, this.openButton });
        UIEventListener listener1 = UIEventListener.Get(this.openButton.gameObject);
        listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.OnOpenClicked));
        base.Init(3, true);
        isLoaded = true;
    }
}

