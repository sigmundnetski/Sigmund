﻿using GNGUI;
using System;
using UnityEngine;

public class CraftingOutputDescription : MonoBehaviour
{
    public UILabel fullDescription;
    private const float HIGH_WASTE_THRESHOLD = 0.7f;
    private Color highWasteColor = new Color(0.9607843f, 0.3058824f, 0.2196078f);
    public UISprite icon;
    private Color lowWasteColor = new Color(0.9411765f, 0.8901961f, 0.6588235f);
    private const float MID_WASTE_THRESHOLD = 0.4f;
    private Color midWasteColor = new Color(0.8588235f, 0.6392157f, 0.2980392f);
    public UILabel nameLabel;
    private int prevRecipeId = 0;
    private float prevUpgrade = 0f;
    public UIFilledSprite slider;
    public UILabel upgrade;

    private void CheckWidgets()
    {
        if (this.fullDescription == null)
        {
            this.fullDescription = base.transform.FindChild("FullDescription").GetComponent<UILabel>();
        }
        if (this.nameLabel == null)
        {
            this.nameLabel = base.transform.FindChild("Name").GetComponent<UILabel>();
        }
        if (this.upgrade == null)
        {
            this.upgrade = base.transform.FindChild("Upgrade").GetComponent<UILabel>();
        }
        if (this.slider == null)
        {
            this.slider = base.transform.parent.GetComponentsInChildren<UIFilledSprite>(true)[0];
        }
        if (this.icon == null)
        {
            foreach (UISprite sprite in base.transform.parent.GetComponentsInChildren<UISprite>())
            {
                if (sprite.name == "ItemIcon")
                {
                    this.icon = sprite;
                    break;
                }
            }
        }
    }

    public void Update()
    {
        this.CheckWidgets();
        BaseRecipeData recipe = CraftingClient.activeRequest.GetRecipe();
        int num = (recipe != null) ? recipe.id : 0;
        float avgInputUpgrade = CraftingClient.activeRequest.GetAvgInputUpgrade();
        if ((num != this.prevRecipeId) || (avgInputUpgrade != this.prevUpgrade))
        {
            InventoryItem eMPTY = InventoryItem.EMPTY;
            double skillUpgradeAdjustment = 0.0;
            if (recipe != null)
            {
                eMPTY = recipe.GenerateOutput(EntityDataClient.owner, avgInputUpgrade, true);
                skillUpgradeAdjustment = recipe.GetSkillUpgradeAdjustment(EntityDataClient.owner);
            }
            Color qualityColor = InventoryClient.GetQualityColor(eMPTY.GetQuality());
            this.fullDescription.text = eMPTY.GetDescription();
            this.upgrade.text = "+" + eMPTY.upgrade;
            this.nameLabel.text = InventoryClient.GetColoredItemDisplayName(eMPTY);
            float num4 = (float) ((avgInputUpgrade + skillUpgradeAdjustment) % 1.0);
            this.slider.fillAmount = num4;
            if (num4 > 0.7f)
            {
                this.slider.color = this.highWasteColor;
            }
            else if (num4 > 0.4f)
            {
                this.slider.color = this.midWasteColor;
            }
            else
            {
                this.slider.color = this.lowWasteColor;
            }
            this.prevRecipeId = num;
            this.prevUpgrade = avgInputUpgrade;
        }
    }
}

