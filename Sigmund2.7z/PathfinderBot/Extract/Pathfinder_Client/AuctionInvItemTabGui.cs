﻿using GNGUI;
using System;
using System.Collections.Generic;
using UnityEngine;

public abstract class AuctionInvItemTabGui : AuctionHouseTabGui
{
    public ToggleText activeFilter;
    public InventoryItem currentItem = InventoryItem.EMPTY;
    private List<ToggleText> filterMajor = new List<ToggleText>();
    protected GameObject invItemPrefab;
    private List<AuctionInvItemGui> invItems = new List<AuctionInvItemGui>();
    protected Item.Container itemSource;
    private UIImageButton sellButton;
    private List<InventoryItem> visibleItems = new List<InventoryItem>();

    protected AuctionInvItemTabGui()
    {
    }

    public virtual void Awake()
    {
        foreach (UIImageButton button in base.GetComponentsInChildren<UIImageButton>())
        {
            if (button.name == "ButtonSell")
            {
                this.sellButton = button;
                UIEventListener listener1 = UIEventListener.Get(this.sellButton.gameObject);
                listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.OnSellClick));
            }
        }
        foreach (ToggleText text in base.GetComponentsInChildren<ToggleText>())
        {
            this.filterMajor.Add(text);
            UIEventListener listener2 = UIEventListener.Get(text.gameObject);
            listener2.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener2.onClick, new UIEventListener.VoidDelegate(this.OnMajorFilterClick));
        }
        GuiHelper.GuiAssertNotNull("Couldn't find needed children.", new object[] { this.sellButton });
        base.Init("InventoryItemsGrid");
    }

    public override void ContentsChanged()
    {
        if (base.IsShowing())
        {
            this.Repopulate();
        }
    }

    protected abstract InventoryItem[] GetReadonlyItems();
    public static AuctionInvItemTabGui GetSingleton(Item.Container itemSource)
    {
        if (itemSource == Item.Container.INVENTORY)
        {
            return AuctionInventoryTabGui.singleton;
        }
        if (itemSource == Item.Container.BANK)
        {
            return AuctionBankTabGui.singleton;
        }
        return null;
    }

    public override void HideTab()
    {
        base.HideTab();
    }

    public override void ItemInterest(InventoryItem item)
    {
        int num;
        for (num = 0; num < this.invItems.Count; num++)
        {
            this.invItems[num].UpdateSelected(item, this.currentItem);
        }
        if (!this.currentItem.DataEquals(item, 0xff))
        {
            InventoryItem[] readonlyItems = this.GetReadonlyItems();
            bool flag = false;
            if (readonlyItems != null)
            {
                for (num = 0; num < readonlyItems.Length; num++)
                {
                    bool flag2 = readonlyItems[num].staticItemId == item.staticItemId;
                    flag = flag || flag2;
                    if (flag2 && (readonlyItems[num].upgrade == item.upgrade))
                    {
                        this.currentItem = readonlyItems[num];
                        break;
                    }
                    if (flag2 && (this.currentItem.staticItemId != item.staticItemId))
                    {
                        this.currentItem = readonlyItems[num];
                    }
                }
            }
            if (!flag)
            {
                this.currentItem = InventoryItem.EMPTY;
            }
        }
    }

    public override void LoadingTickFinished()
    {
        this.invItemPrefab = UIClient.guiPrefabs["ShortInventoryItem"];
        int num = 0;
        foreach (KeyValuePair<string, List<ItemCategoryData>> pair in ItemCategoryData.majorCategories)
        {
            if (num < this.filterMajor.Count)
            {
                this.filterMajor[num].Init(pair.Key, ItemCategoryData.GetCategoryIds(pair.Key));
            }
            num++;
        }
        while (num < this.filterMajor.Count)
        {
            this.filterMajor[num].Init(string.Empty, new int[0]);
            num++;
        }
    }

    public override void OnItemSelected(InventoryItem item, AuctionHouseGui.Tabs itemSource)
    {
        this.currentItem = item;
        base.OnItemSelected(item, itemSource);
    }

    public void OnMajorFilterClick(GameObject filterGO)
    {
        foreach (ToggleText text in this.filterMajor)
        {
            if (filterGO == text.gameObject)
            {
                text.ToggleActive();
                this.activeFilter = text.isActive ? text : null;
            }
            else
            {
                text.SetActive(false);
            }
        }
        base.ResetScroll();
        this.ContentsChanged();
    }

    public void OnSellClick(GameObject go)
    {
        if (!InventoryItem.EMPTY_MATCH(this.currentItem))
        {
            AuctionItemPopupGui.singleton.Repopulate(this.currentItem, AuctionItemPopupGui.InputType.SELL, this.itemSource);
        }
    }

    private void Repopulate()
    {
        this.visibleItems.Clear();
        InventoryItem[] readonlyItems = this.GetReadonlyItems();
        if (readonlyItems != null)
        {
            foreach (InventoryItem item in readonlyItems)
            {
                if (this.ValidItem(item))
                {
                    this.visibleItems.Add(item);
                }
            }
        }
        UIGrid.SetElementCount<AuctionInvItemGui>(DragDropRoot.root, base.gridList, this.invItemPrefab, this.invItems, this.visibleItems.Count);
        for (int i = 0; i < this.visibleItems.Count; i++)
        {
            this.invItems[i].SetData(this.visibleItems[i], this.itemSource, this.currentItem);
        }
        if (this.visibleItems.Count == 0)
        {
            AuctionHouseGui.singleton.ShowTabItemInfo("No items.");
        }
        else
        {
            AuctionHouseGui.singleton.ShowTabItemInfo(string.Empty);
        }
    }

    public override void ShowTab()
    {
        base.ResetScroll();
        base.ShowTab();
        this.Repopulate();
    }

    private bool ValidItem(InventoryItem item)
    {
        if (InventoryItem.EMPTY_MATCH(item))
        {
            return false;
        }
        BasicItemData data = ItemDatabase.GetItem(item.staticItemId);
        if (data == null)
        {
            return false;
        }
        return ((this.activeFilter == null) || (Array.IndexOf<int>(this.activeFilter.filterIds, data.categoryId) != -1));
    }
}

