﻿using GNGUI;
using System;

public class TradeItemGui : ItemGui
{
    private UILabel durability;
    private UILabel encumbrance;
    public TradeWindowGui.TradePanel owner;
    public byte sortDurability;
    public float sortEncumbrance;
    public string sortName;

    public void Assign(InventoryItem setItem, TradeWindowGui.TradePanel setOwner, ItemWindowGui parent)
    {
        if (!setItem.DataEquals(base.item, 0xff) || (setOwner != this.owner))
        {
            base.Assign(setItem, parent);
            this.owner = setOwner;
        }
    }

    public override void Awake()
    {
        base.Awake();
        foreach (UILabel label in base.GetComponentsInChildren<UILabel>())
        {
            if (label.name == "Name")
            {
                base.nameLabel = label;
            }
            else if (label.name == "Encumbrance")
            {
                this.encumbrance = label;
            }
            else if (label.name == "Durability")
            {
                this.durability = label;
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find all labels.", new object[] { base.nameLabel, this.encumbrance, this.durability });
    }

    protected override void SetInfo(InventoryItem item, BasicItemData itemData)
    {
        this.sortDurability = item.durability;
        this.sortEncumbrance = item.GetEncumbrance();
        this.sortName = item.GetDisplayName(true);
        this.encumbrance.text = this.sortEncumbrance.ToString("f1");
        this.durability.text = this.sortDurability.ToString();
    }

    protected override void SetLabel(BasicItemData itemData)
    {
        if (itemData == null)
        {
            base.nameLabel.text = "<NOT FOUND>";
        }
        else
        {
            base.nameLabel.text = this.item.GetDisplayName(true);
        }
        base.nameLabel.color = InventoryClient.GetQualityColor(this.item.GetQuality());
    }
}

