﻿using GNGUI;
using System;
using UnityEngine;

public class WindowBackgroundParent : MonoBehaviour
{
    public static bool LoadWindowBg(string prefabName, FullscreenWindowGui window, Vector3 setPos)
    {
        Transform transform = FullscreenWindowGui.windowBgParent.transform.FindChild(prefabName);
        if (null != transform)
        {
            if (window != null)
            {
                window.background = transform.GetComponent<FullscreenWindowBackgroundGui>();
                return true;
            }
            return false;
        }
        if (setPos == GConst.VECTOR3_INVALID)
        {
            setPos = Vector3.zero;
        }
        GameObject obj2 = NGUITools.AddChild(FullscreenWindowGui.windowBgParent, UIClient.guiPrefabs[prefabName]);
        obj2.transform.localPosition = setPos;
        obj2.name = prefabName;
        return false;
    }

    private void Start()
    {
        FullscreenWindowGui.windowBgParent = base.gameObject;
    }
}

