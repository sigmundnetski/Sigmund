﻿using GNGUI;
using System;
using System.Collections.Generic;
using UnityEngine;

internal class UIAtlasManager : MonoBehaviour
{
    public UIAtlas[] atlases = new UIAtlas[0];
    private Dictionary<string, int> atlasIndexByName = new Dictionary<string, int>();
    public static UIAtlasManager singleton;

    public void Awake()
    {
        singleton = this;
    }

    public UIAtlas GetAtlas(string name)
    {
        int num = -1;
        if (!this.atlasIndexByName.TryGetValue(name.ToLower(), out num))
        {
            return null;
        }
        return this.atlases[num];
    }

    public void OnDestroy()
    {
        singleton = null;
    }

    public void Start()
    {
        for (int i = 0; i < this.atlases.Length; i++)
        {
            this.atlasIndexByName.Add(this.atlases[i].name.ToLower(), i);
        }
    }
}

