﻿using GNGUI;
using System;
using System.Collections.Generic;
using UnityEngine;

public abstract class CompanyDetailsTabGui : WindowTabGui
{
    protected List<SortButton> allSorts = new List<SortButton>();
    protected ulong companyId;
    protected SortButton currentSort = null;

    protected CompanyDetailsTabGui()
    {
    }

    public override void Awake()
    {
        base.Awake();
        base.prefabName = "CompanyDetailsPlayerInfo";
        foreach (SortButton button in base.GetComponentsInChildren<SortButton>())
        {
            this.allSorts.Add(button);
            UIEventListener listener1 = UIEventListener.Get(button.gameObject);
            listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.SortClicked));
            if (button.name == "Sort0Name")
            {
                button.Init(0, SortButton.SortType.ASCENDING);
            }
            else if (button.name == "Sort1Status")
            {
                button.Init(1, SortButton.SortType.INACTIVE);
            }
            else
            {
                GLog.LogError(new object[] { "Unknown sort!", button.name });
            }
            if ((button.sort != SortButton.SortType.INACTIVE) && (this.currentSort == null))
            {
                this.currentSort = button;
            }
            else if ((button.sort != SortButton.SortType.INACTIVE) && (this.currentSort != null))
            {
                GLog.LogError(new object[] { "Should only have one non-inactive sort! You have", this.currentSort.name, "and", button.name });
            }
        }
    }

    public override void ContentsChanged()
    {
        this.MakeListItems();
        this.ResortContents((CompanyWindowDetailsTabGui.Sort) this.currentSort.sortId, this.currentSort.sort);
    }

    public void DisplayCompany(ulong companyId_)
    {
        this.companyId = companyId_;
        this.ContentsChanged();
    }

    public override void FilterClicked(GameObject filterGO)
    {
    }

    public void PlayerSelected(string playerName)
    {
        for (int i = 0; i < base.displayedItems.Count; i++)
        {
            ((CompanyMemberInfoGui) base.displayedItems[i]).PlayerSelected(playerName);
        }
    }

    protected void ResortContents(CompanyWindowDetailsTabGui.Sort sortField, SortButton.SortType sortType)
    {
        IEnumerable<CompanyMemberInfoGui> enumerable = null;
        if (sortField == CompanyWindowDetailsTabGui.Sort.NAME)
        {
            if (sortType == SortButton.SortType.DESCENDING)
            {
                enumerable = from each in base.displayedItems
                    orderby ((CompanyMemberInfoGui) each).sortName descending
                    select (CompanyMemberInfoGui) each;
            }
            else if (sortType == SortButton.SortType.ASCENDING)
            {
                enumerable = from each in base.displayedItems
                    orderby ((CompanyMemberInfoGui) each).sortName
                    select (CompanyMemberInfoGui) each;
            }
            else
            {
                GLog.LogError(new object[] { "Don't know how to sort", sortField, "by", sortType });
            }
        }
        else if (sortField == CompanyWindowDetailsTabGui.Sort.STATUS)
        {
            if (sortType == SortButton.SortType.DESCENDING)
            {
                enumerable = from each in base.displayedItems
                    orderby ((CompanyMemberInfoGui) each).sortStatus descending
                    select (CompanyMemberInfoGui) each;
            }
            else if (sortType == SortButton.SortType.ASCENDING)
            {
                enumerable = from each in base.displayedItems
                    orderby ((CompanyMemberInfoGui) each).sortStatus
                    select (CompanyMemberInfoGui) each;
            }
            else
            {
                GLog.LogError(new object[] { "Don't know how to sort", sortField, "by", sortType });
            }
        }
        if (enumerable != null)
        {
            int num = 0;
            foreach (CompanyMemberInfoGui gui in enumerable)
            {
                gui.name = num.ToString("d3") + "_" + gui.sortName;
                num++;
            }
        }
        else
        {
            GLog.LogError(new object[] { "Failed to sort", sortField, sortType });
        }
        this.RepositionListItems();
    }

    public override void ShowTab()
    {
        this.ContentsChanged();
        base.ShowTab();
    }

    public void SortClicked(GameObject sortGO)
    {
        SortButton button = null;
        for (int i = 0; i < this.allSorts.Count; i++)
        {
            if (sortGO == this.allSorts[i].gameObject)
            {
                this.allSorts[i].ToggleSort(true);
                button = this.allSorts[i];
            }
            else
            {
                this.allSorts[i].ToggleSort(false);
            }
        }
        this.currentSort = button;
        this.ResortContents((CompanyWindowDetailsTabGui.Sort) this.currentSort.sortId, this.currentSort.sort);
    }
}

