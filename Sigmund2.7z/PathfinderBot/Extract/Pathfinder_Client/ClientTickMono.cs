﻿using System;
using UnityEngine;

public class ClientTickMono : MonoBehaviour
{
    public string curState;
    public Ticker.TickBase myTick;
    public static ClientTickMono singleton;

    public void Awake()
    {
        singleton = this;
    }

    public void FixedUpdate()
    {
        this.myTick.FixedUpdate();
        this.curState = this.myTick.curState;
    }

    public void LoadEnvironmentScene(string sceneName, ushort mapId)
    {
        if (!string.IsNullOrEmpty(sceneName))
        {
            SceneService.LoadSceneByName(sceneName);
        }
        else if (TerrainUtils.IsValidHex(mapId))
        {
            TerrainService.LoadHex(mapId, false);
        }
        if (this.myTick is ClientTick)
        {
            ((ClientTick) this.myTick).serverSceneReceived = true;
        }
    }

    public void OnDestroy()
    {
        this.myTick.StopTicking();
        singleton = null;
    }

    public void Start()
    {
        if (this.myTick == null)
        {
            this.myTick = new ClientTick();
        }
    }

    public void Update()
    {
        this.myTick.Update();
    }
}

