﻿using GNetwork;
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;
using UnityEngine;

public static class CommandClient
{
    public static CommandCore.AutoCompleteNotifier autoCompleteNotifier = null;
    public static CommandCore.PermissionLevel permissionLevel = CommandCore.PermissionLevel.USER;

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void AutoCompleteReply(string autoCompleteOptions)
    {
        string[] strArray = autoCompleteOptions.Split(CommandCore.SPACE_SPLIT, StringSplitOptions.RemoveEmptyEntries);
        if (autoCompleteNotifier != null)
        {
            autoCompleteNotifier(strArray);
        }
    }

    public static List<string> AutoCompleteRequest(string autoCompleteBase)
    {
        GRouting.SendMyMapRpc(GRpcID.CommandServer_ProcessCommand, new object[] { "autocomplete " + autoCompleteBase });
        return CommandCore.GetAutoComplete(autoCompleteBase, CommandCore.getPlayerPermission(EntityDataClient.owner.entityId));
    }

    public static void DelayedRegisterCommand(string commandName, CommandCore.CommandDelegate callback, CommandCore.PermissionLevel minPermission, CommandCore.Options options, string[] subCommands = null)
    {
        CommandCore.RegisterCommand(commandName, callback, minPermission, options, subCommands);
    }

    public static CommandCore.PermissionLevel FakePermissions(EntityId playerEntityId)
    {
        return permissionLevel;
    }

    public static bool LoadingTickFinished()
    {
        CommandCore.Reset();
        CommandCore.initialized = true;
        RegisterReservedCommands();
        RegisterPlayerCommands();
        RegisterGameMasterCommands();
        RegisterTestingCommands();
        RegisterDebugCommands();
        return true;
    }

    public static void PrintAllCommands(string[] args, EntityId playerEntityId)
    {
        autoCompleteNotifier = (CommandCore.AutoCompleteNotifier) Delegate.Combine(autoCompleteNotifier, new CommandCore.AutoCompleteNotifier(CommandClient.PrintServerCommands));
        autoCompleteNotifier = (CommandCore.AutoCompleteNotifier) Delegate.Remove(autoCompleteNotifier, new CommandCore.AutoCompleteNotifier(DebugGui.AutoCompleteNotifier));
        DebugClient.DisplayDebugMessage("Client commands: " + string.Join(", ", AutoCompleteRequest("").ToArray()));
    }

    private static void PrintAllInv(string[] args, EntityId playerEntityId)
    {
        StringBuilder builder = new StringBuilder();
        foreach (Entity entity in EntityCore.GetAllPlayerEntities(true))
        {
            builder.Remove(0, builder.Length);
            builder.Append("Player: ").Append(entity.EntityName);
            if (entity.gear != null)
            {
                if (entity.gear.bodySlots != null)
                {
                    builder.Append("\nBody: ").Append(GUtil.PrettyPrint(SparseArray.Iterate<InventoryItem>(entity.gear.bodySlots, InventoryItem.EMPTY_MATCH), "\n", null));
                }
                if ((entity.playerRecord != null) && (entity.playerRecord.inventory != null))
                {
                    builder.Append("\nInv: ").Append(GUtil.PrettyPrint(SparseArray.Iterate<InventoryItem>(entity.playerRecord.inventory, InventoryItem.EMPTY_MATCH), "\n", null));
                }
            }
            GLog.LogWarning(new object[] { builder.ToString() });
        }
    }

    private static void PrintAllMaterials(string[] args, EntityId playerEntityId)
    {
        Material[] materialArray = Resources.FindObjectsOfTypeAll<Material>();
        Dictionary<string, int> dictionary = new Dictionary<string, int>();
        for (int i = 0; i < materialArray.Length; i++)
        {
            if (!dictionary.ContainsKey(materialArray[i].name))
            {
                dictionary[materialArray[i].name] = 1;
            }
            else
            {
                Dictionary<string, int> dictionary2;
                string str2;
                (dictionary2 = dictionary)[str2 = materialArray[i].name] = dictionary2[str2] + 1;
            }
        }
        IEnumerable<string> enumerable = from kvp in dictionary
            orderby kvp.Value descending
            select kvp.Key;
        StringBuilder builder = new StringBuilder();
        builder.Append("All Materials: " + materialArray.Length);
        foreach (string str in enumerable)
        {
            builder.Append("\n");
            if (dictionary[str] < 0x3e8)
            {
                builder.Append(" ");
            }
            if (dictionary[str] < 100)
            {
                builder.Append(" ");
            }
            if (dictionary[str] < 10)
            {
                builder.Append(" ");
            }
            builder.Append(dictionary[str]).Append(" - ").Append(str);
        }
        GLog.LogWarning(new object[] { builder.ToString() });
    }

    private static void PrintInv(string[] args, EntityId playerEntityId)
    {
        GLog.LogError(new object[] { "Body:", SparseArray.Iterate<InventoryItem>(EntityDataClient.owner.playerRecord.bodySlots, InventoryItem.EMPTY_MATCH) });
        GLog.LogError(new object[] { "Inv:", SparseArray.Iterate<InventoryItem>(EntityDataClient.owner.playerRecord.inventory, InventoryItem.EMPTY_MATCH) });
    }

    public static void PrintServerCommands(string[] args)
    {
        autoCompleteNotifier = (CommandCore.AutoCompleteNotifier) Delegate.Remove(autoCompleteNotifier, new CommandCore.AutoCompleteNotifier(CommandClient.PrintServerCommands));
        autoCompleteNotifier = (CommandCore.AutoCompleteNotifier) Delegate.Combine(autoCompleteNotifier, new CommandCore.AutoCompleteNotifier(DebugGui.AutoCompleteNotifier));
        DebugClient.DisplayDebugMessage("Server commands: " + string.Join(", ", args));
    }

    private static void RegisterDebugCommands()
    {
        CommandCore.PermissionLevel dEBUG = CommandCore.PermissionLevel.DEBUG;
        CommandCore.RegisterCommand("SettlementCreate", new CommandCore.CommandDelegate(GroupClient.SettlementCreate), dEBUG, CommandCore.Options.NONE | CommandCore.Options.RAW_COMMAND_STRING, null);
    }

    private static void RegisterGameMasterCommands()
    {
        CommandCore.PermissionLevel gM = CommandCore.PermissionLevel.GM;
        CommandCore.RegisterCommand("DataSyncDebug", new CommandCore.CommandDelegate(DebugClient.DataSyncDebug), gM, CommandCore.Options.AUTO_COMPLETE, null);
    }

    private static void RegisterPlayerCommands()
    {
        CommandCore.PermissionLevel uSER = CommandCore.PermissionLevel.USER;
        CommandCore.Options nONE = CommandCore.Options.NONE;
        CommandCore.Options options = CommandCore.Options.AUTO_COMPLETE | CommandCore.Options.PRESERVE_ARG_CASE;
        CommandCore.Options options3 = CommandCore.Options.AUTO_COMPLETE | CommandCore.Options.RAW_COMMAND_STRING;
        CommandCore.RegisterCommand("ExportKeybinds", new CommandCore.CommandDelegate(ClientInputManager.ExportKeybinds), uSER, options3, null);
        CommandCore.RegisterCommand("ImportKeybinds", new CommandCore.CommandDelegate(ClientInputManager.ImportKeybinds), uSER, options3, null);
        CommandCore.RegisterCommand("roshambo", new CommandCore.CommandDelegate(RoshamboClient.NewGame), uSER, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("rockpaperscissors", new CommandCore.CommandDelegate(RoshamboClient.NewGame), uSER, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("rps", new CommandCore.CommandDelegate(RoshamboClient.NewGame), uSER, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("rpsaccept", new CommandCore.CommandDelegate(RoshamboClient.AcceptGame), uSER, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("rock", new CommandCore.CommandDelegate(RoshamboClient.Throw), uSER, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("paper", new CommandCore.CommandDelegate(RoshamboClient.Throw), uSER, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("scissors", new CommandCore.CommandDelegate(RoshamboClient.Throw), uSER, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("walk", new CommandCore.CommandDelegate(CombatClient.CommandEvent), uSER, nONE, null);
        CommandCore.RegisterCommand("run", new CommandCore.CommandDelegate(CombatClient.CommandEvent), uSER, nONE, null);
        CommandCore.RegisterCommand("autorun", new CommandCore.CommandDelegate(ClientInputManager.singleton.CommandEvent), uSER, nONE, null);
        CommandCore.RegisterCommand("StealthMode", new CommandCore.CommandDelegate(CombatClient.CommandEvent), uSER, nONE, null);
        if (ButtonBarGui.singleton != null)
        {
            CommandCore.RegisterCommand("weaponswap", new CommandCore.CommandDelegate(ButtonBarGui.singleton.CommandEvent), uSER, nONE, null);
            CommandCore.RegisterCommand("attack1", new CommandCore.CommandDelegate(ButtonBarGui.singleton.CommandEvent), uSER, nONE, null);
            CommandCore.RegisterCommand("attack2", new CommandCore.CommandDelegate(ButtonBarGui.singleton.CommandEvent), uSER, nONE, null);
            CommandCore.RegisterCommand("attack3", new CommandCore.CommandDelegate(ButtonBarGui.singleton.CommandEvent), uSER, nONE, null);
            CommandCore.RegisterCommand("attack4", new CommandCore.CommandDelegate(ButtonBarGui.singleton.CommandEvent), uSER, nONE, null);
            CommandCore.RegisterCommand("attack5", new CommandCore.CommandDelegate(ButtonBarGui.singleton.CommandEvent), uSER, nONE, null);
            CommandCore.RegisterCommand("attack6", new CommandCore.CommandDelegate(ButtonBarGui.singleton.CommandEvent), uSER, nONE, null);
            CommandCore.RegisterCommand("refresh1", new CommandCore.CommandDelegate(ButtonBarGui.singleton.CommandEvent), uSER, nONE, null);
            CommandCore.RegisterCommand("refresh2", new CommandCore.CommandDelegate(ButtonBarGui.singleton.CommandEvent), uSER, nONE, null);
            CommandCore.RegisterCommand("refresh3", new CommandCore.CommandDelegate(ButtonBarGui.singleton.CommandEvent), uSER, nONE, null);
            CommandCore.RegisterCommand("refresh4", new CommandCore.CommandDelegate(ButtonBarGui.singleton.CommandEvent), uSER, nONE, null);
            CommandCore.RegisterCommand("utility1", new CommandCore.CommandDelegate(ButtonBarGui.singleton.CommandEvent), uSER, nONE, null);
            CommandCore.RegisterCommand("utility2", new CommandCore.CommandDelegate(ButtonBarGui.singleton.CommandEvent), uSER, nONE, null);
            CommandCore.RegisterCommand("consumable1", new CommandCore.CommandDelegate(ButtonBarGui.singleton.CommandEvent), uSER, nONE, null);
            CommandCore.RegisterCommand("consumable2", new CommandCore.CommandDelegate(ButtonBarGui.singleton.CommandEvent), uSER, nONE, null);
        }
        CommandCore.RegisterCommand("tabtarget", new CommandCore.CommandDelegate(Targeting.CommandEvent), uSER, nONE, null);
        CommandCore.RegisterCommand("mousetarget", new CommandCore.CommandDelegate(Targeting.CommandEvent), uSER, nONE, null);
        CommandCore.RegisterCommand("selectparty", new CommandCore.CommandDelegate(Targeting.CommandEvent), uSER, nONE, null);
        CommandCore.RegisterCommand("interacttarget", new CommandCore.CommandDelegate(EntityClient.InteractCommand), uSER, nONE, null);
        CommandCore.RegisterCommand("AddPin", new CommandCore.CommandDelegate(MapClient.AddPinCommand), uSER, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("trade", new CommandCore.CommandDelegate(InventoryClient.TradeCommand), uSER, CommandCore.Options.AUTO_COMPLETE, null);
        if (InventoryWindowGui.singleton != null)
        {
            CommandCore.RegisterCommand("inventory", new CommandCore.CommandDelegate(InventoryWindowGui.singleton.ToggleInventoryWindow), uSER, nONE, null);
        }
        if (FeatsWindowGui.singleton != null)
        {
            CommandCore.RegisterCommand("feats", new CommandCore.CommandDelegate(FeatsWindowGui.singleton.ToggleFeatsWindow), uSER, nONE, null);
        }
        if (PaperdollWindowGui.singleton != null)
        {
            CommandCore.RegisterCommand("paperdoll", new CommandCore.CommandDelegate(PaperdollWindowGui.singleton.CommandEvent), uSER, nONE, null);
        }
        if (MapWindowGui.singleton != null)
        {
            CommandCore.RegisterCommand("worldmap", new CommandCore.CommandDelegate(MapWindowGui.singleton.CommandEvent), uSER, nONE, null);
        }
        if (EventBarGui.singleton != null)
        {
            CommandCore.RegisterCommand("events", new CommandCore.CommandDelegate(EventBarGui.singleton.CommandEvent), uSER, nONE, null);
        }
        if (AchievementsWindowGui.singleton != null)
        {
            CommandCore.RegisterCommand("achieve", new CommandCore.CommandDelegate(AchievementsWindowGui.singleton.ToggleHideCommand), uSER, nONE, null);
        }
        if (TerrainService.InUse)
        {
            CommandCore.RegisterCommand("ToggleHexBoundaries", new CommandCore.CommandDelegate(TerrainClient.ToggleHexBoundaries), uSER, CommandCore.Options.AUTO_COMPLETE, null);
        }
        if (CharacterWindowGui.singleton != null)
        {
            CommandCore.RegisterCommand("character", new CommandCore.CommandDelegate(CharacterWindowGui.singleton.ToggleCharacterWindow), uSER, nONE, null);
        }
        CommandCore.RegisterCommand("ToggleFps", new CommandCore.CommandDelegate(DebugClient.ToggleFps), uSER, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("FPS", new CommandCore.CommandDelegate(DebugClient.ToggleFps), uSER, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("ToggleGui", new CommandCore.CommandDelegate(DebugClient.ToggleAllUi), uSER, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("ScaleGui", new CommandCore.CommandDelegate(UIClient.ScaleGui), uSER, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("ToggleQuestLog", new CommandCore.CommandDelegate(QuestClient.ToggleQuestLog), uSER, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("ClearChat", new CommandCore.CommandDelegate(DebugClient.ChatCommand), uSER, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("Channel", new CommandCore.CommandDelegate(ChatClient.ChangeChannel), uSER, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("JoinChannel", new CommandCore.CommandDelegate(ChatClient.JoinChannel), uSER, options, null);
        CommandCore.RegisterCommand("AddChannel", new CommandCore.CommandDelegate(ChatClient.JoinChannel), uSER, options, null);
        CommandCore.RegisterCommand("LeaveChannel", new CommandCore.CommandDelegate(ChatClient.LeaveChannel), uSER, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("RemoveChannel", new CommandCore.CommandDelegate(ChatClient.RemoveChannel), uSER, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("CurrentChannels", new CommandCore.CommandDelegate(ChatClient.GetCurrentChannels), uSER, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("Whisper", new CommandCore.CommandDelegate(ChatClient.WhisperCommand), uSER, options3, null);
        CommandCore.RegisterCommand("w", new CommandCore.CommandDelegate(ChatClient.WhisperCommand), uSER, CommandCore.Options.NONE | CommandCore.Options.RAW_COMMAND_STRING, null);
        CommandCore.RegisterCommand("Reply", new CommandCore.CommandDelegate(ChatClient.ReplyCommand), uSER, options3, null);
        CommandCore.RegisterCommand("r", new CommandCore.CommandDelegate(ChatClient.ReplyCommand), uSER, CommandCore.Options.NONE | CommandCore.Options.RAW_COMMAND_STRING, null);
        CommandCore.RegisterCommand("Party", new CommandCore.CommandDelegate(ChatClient.PartyChatCommand), uSER, options3, null);
        CommandCore.RegisterCommand("p", new CommandCore.CommandDelegate(ChatClient.PartyChatCommand), uSER, CommandCore.Options.NONE | CommandCore.Options.RAW_COMMAND_STRING, null);
        CommandCore.RegisterCommand("Local", new CommandCore.CommandDelegate(ChatClient.LocalChatCommand), uSER, options3, null);
        CommandCore.RegisterCommand("l", new CommandCore.CommandDelegate(ChatClient.LocalChatCommand), uSER, CommandCore.Options.NONE | CommandCore.Options.RAW_COMMAND_STRING, null);
        CommandCore.RegisterCommand("ResetChatSettings", new CommandCore.CommandDelegate(ChatClient.ResetChatSettings), uSER, CommandCore.Options.AUTO_COMPLETE, null);
        foreach (KeyValuePair<string, EmoteData> pair in EmoteData.emoteByCommand)
        {
            CommandCore.RegisterCommand(pair.Key, new CommandCore.CommandDelegate(ChatClient.SendEmote), uSER, nONE, null);
        }
        if (CompanySearchWindowGui.singleton != null)
        {
            CommandCore.RegisterCommand("CompanySearch", new CommandCore.CommandDelegate(CompanySearchWindowGui.singleton.ToggleWindowVis), uSER, nONE, null);
        }
        if (CompanyWindowGui.singleton != null)
        {
            CommandCore.RegisterCommand("CompanyWindow", new CommandCore.CommandDelegate(CompanyWindowGui.singleton.ToggleWindowVis), uSER, nONE, null);
        }
        CommandCore.RegisterCommand("VcCreate", new CommandCore.CommandDelegate(GroupClient.VcCreate), uSER, CommandCore.Options.NONE | CommandCore.Options.RAW_COMMAND_STRING, null);
        CommandCore.RegisterCommand("VcInvite", new CommandCore.CommandDelegate(GroupClient.VcInvite), uSER, CommandCore.Options.NONE | CommandCore.Options.RAW_COMMAND_STRING, null);
        CommandCore.RegisterCommand("VcKick", new CommandCore.CommandDelegate(GroupClient.VcKick), uSER, CommandCore.Options.NONE | CommandCore.Options.RAW_COMMAND_STRING, null);
        CommandCore.RegisterCommand("VcLeave", new CommandCore.CommandDelegate(GroupClient.VcLeave), uSER, CommandCore.Options.NONE | CommandCore.Options.RAW_COMMAND_STRING, null);
        CommandCore.RegisterCommand("VcApply", new CommandCore.CommandDelegate(GroupClient.VcApply), uSER, CommandCore.Options.NONE | CommandCore.Options.RAW_COMMAND_STRING, null);
        CommandCore.RegisterCommand("VcAccept", new CommandCore.CommandDelegate(GroupClient.VcAccept), uSER, nONE, null);
        CommandCore.RegisterCommand("VcDecline", new CommandCore.CommandDelegate(GroupClient.VcDecline), uSER, nONE, null);
        CommandCore.RegisterCommand("VcIgnore", new CommandCore.CommandDelegate(GroupClient.VcIgnore), uSER, nONE, null);
        CommandCore.RegisterCommand("VcGoals", new CommandCore.CommandDelegate(GroupClient.VcGoals), uSER, CommandCore.Options.NONE | CommandCore.Options.RAW_COMMAND_STRING, null);
        CommandCore.RegisterCommand("VcStatement", new CommandCore.CommandDelegate(GroupClient.VcStatement), uSER, CommandCore.Options.NONE | CommandCore.Options.RAW_COMMAND_STRING, null);
        CommandCore.RegisterCommand("VcRecruitMessage", new CommandCore.CommandDelegate(GroupClient.VcRecruitMessage), uSER, CommandCore.Options.NONE | CommandCore.Options.RAW_COMMAND_STRING, null);
        CommandCore.RegisterCommand("SettlementApply", new CommandCore.CommandDelegate(GroupClient.SettlementApply), uSER, options3, null);
        CommandCore.RegisterCommand("SettlementLeave", new CommandCore.CommandDelegate(GroupClient.SettlementLeave), uSER, options3, null);
        CommandCore.RegisterCommand("AllyApply", new CommandCore.CommandDelegate(GroupClient.AllyApply), uSER, options3, null);
        CommandCore.RegisterCommand("AllyLeave", new CommandCore.CommandDelegate(GroupClient.AllyLeave), uSER, options3, null);
        CommandCore.RegisterCommand("Invite", new CommandCore.CommandDelegate(GroupClient.Invite), uSER, options3, null);
        CommandCore.RegisterCommand("Kick", new CommandCore.CommandDelegate(GroupClient.Kick), uSER, options3, null);
        CommandCore.RegisterCommand("Promote", new CommandCore.CommandDelegate(GroupClient.Promote), uSER, options3, null);
        CommandCore.RegisterCommand("Leave", new CommandCore.CommandDelegate(GroupClient.Leave), uSER, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("Volume", new CommandCore.CommandDelegate(GraphicsClient.SetVolume), uSER, CommandCore.Options.AUTO_COMPLETE, null);
    }

    private static void RegisterReservedCommands()
    {
        CommandCore.RegisterCommand("escape", new CommandCore.CommandDelegate(ClientInputManager.singleton.EscapeCommandEvent), CommandCore.PermissionLevel.USER, CommandCore.Options.NONE, null);
        CommandCore.RegisterCommand("?", new CommandCore.CommandDelegate(CommandClient.PrintAllCommands), CommandCore.PermissionLevel.USER, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("help", new CommandCore.CommandDelegate(CommandClient.PrintAllCommands), CommandCore.PermissionLevel.USER, CommandCore.Options.AUTO_COMPLETE, null);
    }

    private static void RegisterTestingCommands()
    {
        CommandCore.PermissionLevel tESTING = CommandCore.PermissionLevel.TESTING;
        CommandCore.RegisterCommand("CombatModifier", new CommandCore.CommandDelegate(DebugClient.TestCombatModifiers), tESTING, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("MakeTargetOlder", new CommandCore.CommandDelegate(AdvancementClient.MakeTargetOlder), tESTING, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("PrintStats", new CommandCore.CommandDelegate(DebugClient.PrintStats), tESTING, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("AnimProxy", new CommandCore.CommandDelegate(AnimDebug.ManageAnimProxies), tESTING, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("BulletTime", new CommandCore.CommandDelegate(AnimDebug.ChangeUnityTimescale), tESTING, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("AnimSwapWeapon", new CommandCore.CommandDelegate(AnimDebug.AnimSwapWeapon), tESTING, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("AnimCombat", new CommandCore.CommandDelegate(AnimDebug.ToggleAnimDebugCombat), tESTING, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("AnimMovement", new CommandCore.CommandDelegate(AnimDebug.AnimMovement), tESTING, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("AnimOffset", new CommandCore.CommandDelegate(AnimDebug.AnimOffset), tESTING, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("AnimSpeed", new CommandCore.CommandDelegate(AnimDebug.AnimSpeed), tESTING, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("LoadLightSetting", new CommandCore.CommandDelegate(GraphicsClient.LoadLightSetting), tESTING, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("LightDuration", new CommandCore.CommandDelegate(GraphicsClient.SetLightDuration), tESTING, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("LightTime", new CommandCore.CommandDelegate(GraphicsClient.SetLightTime), tESTING, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("LogPlayerPosition", new CommandCore.CommandDelegate(DebugClient.LogPlayerPosition), tESTING, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("LogPlayerFacing", new CommandCore.CommandDelegate(DebugClient.LogPlayerFacing), tESTING, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("SetPlayerFacing", new CommandCore.CommandDelegate(DebugClient.SetPlayerFacing), tESTING, CommandCore.Options.AUTO_COMPLETE, null);
        if (CameraToggle.singleton != null)
        {
            CommandCore.RegisterCommand("ToggleCamera", new CommandCore.CommandDelegate(CameraToggle.singleton.ToggleCamera), tESTING, CommandCore.Options.AUTO_COMPLETE | CommandCore.Options.OVERWRITE, null);
        }
        CommandCore.RegisterCommand("MergeMeshes", new CommandCore.CommandDelegate(EntityLoadClient.ToggleMeshMerge), tESTING, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("FixedAtlasLayout", new CommandCore.CommandDelegate(MergeJobService.ToggleFixedLayout), tESTING, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("ReskinCharacter", new CommandCore.CommandDelegate(EntityLoadClient.ReskinCharacter), tESTING, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("PrintInv", new CommandCore.CommandDelegate(CommandClient.PrintInv), tESTING, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("PrintAllInv", new CommandCore.CommandDelegate(CommandClient.PrintAllInv), tESTING, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("TextureStatistics", new CommandCore.CommandDelegate(ResourceManager.TextureStatistics), tESTING, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("AuctionHouse", new CommandCore.CommandDelegate(AuctionHouseGui.ShowAH), tESTING, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("MarketItems", new CommandCore.CommandDelegate(AuctionHouseGui.FakeMarket), tESTING, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("OrderItems", new CommandCore.CommandDelegate(AuctionHouseGui.FakeOrders), tESTING, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("BidItems", new CommandCore.CommandDelegate(AuctionHouseGui.FakeBids), tESTING, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("ahitem", new CommandCore.CommandDelegate(AuctionHouseGui.FakeStats), tESTING, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("ClientCPV", new CommandCore.CommandDelegate(CapturePointClient.PrintCPV), tESTING, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("ClientEscVars", new CommandCore.CommandDelegate(EncounterClient.PrintEscVars), tESTING, CommandCore.Options.AUTO_COMPLETE, null);
        CommandCore.RegisterCommand("ClientMapPins", new CommandCore.CommandDelegate(MapClient.PrintPins), tESTING, CommandCore.Options.AUTO_COMPLETE, null);
    }

    public static void SendCommandToServer(string command, EntityId playerEntityId)
    {
        GRouting.SendMyMapRpc(GRpcID.CommandServer_ProcessCommand, new object[] { command });
    }

    public static void SyncStart()
    {
        InputManager.commandCallback = new InputManager.ExecuteCommand(CommandCore.ExecuteAllCommands);
        InputManager.getPlayerEntityId = new InputManager.GetEntityId(PlayerEntityClient.GetPlayerEntityId);
        CommandCore.commandFallback = new CommandCore.FallbackDelegate(CommandClient.SendCommandToServer);
        CommandCore.getPlayerPermission = new CommandCore.PermissionLevelDelegate(CommandClient.FakePermissions);
        DebugGui.getAutoComplete = new CommandCore.AutoCompleteDelegate(CommandClient.AutoCompleteRequest);
        autoCompleteNotifier = new CommandCore.AutoCompleteNotifier(DebugGui.AutoCompleteNotifier);
    }
}

