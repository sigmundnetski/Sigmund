﻿using GNGUI;
using System;
using System.Collections.Generic;
using UnityEngine;

public class RedeemWindowGui : MonoBehaviour
{
    private bool isLoaded = false;
    private UIGrid itemRedeemGrid;
    private UIScrollBar mainScroll;
    private List<RedeemGridItem> redeemList = new List<RedeemGridItem>();
    private GameObject redeemPrefab;
    private UIImageButton selectAllBtn;
    public static RedeemWindowGui singleton;

    public void Awake()
    {
        singleton = this;
        this.OnAwake();
    }

    public bool LoadingTickFinished()
    {
        this.itemRedeemGrid = base.gameObject.GetComponentInChildren<UIGrid>();
        this.selectAllBtn = base.gameObject.GetComponentInChildren<UIImageButton>();
        this.mainScroll = base.gameObject.GetComponentInChildren<UIScrollBar>();
        this.redeemPrefab = UIClient.guiPrefabs["RedeemGridItem"];
        GuiHelper.GuiAssertNotNull("Error starting RedeemWindowGui:", new object[] { this.itemRedeemGrid, this.selectAllBtn, this.mainScroll, this.redeemPrefab });
        UIEventListener listener1 = UIEventListener.Get(this.selectAllBtn.gameObject);
        listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.SelectAllClicked));
        this.mainScroll.scrollValue = 0f;
        base.gameObject.SetActive(false);
        this.isLoaded = true;
        this.Populate();
        return true;
    }

    private void OnAwake()
    {
        CharacterSelectTick.redeemLoadFinish = new GUtil.BoolFilterDelegate(this.LoadingTickFinished);
    }

    public void OnDestroy()
    {
        singleton = null;
    }

    public void OnSelectCharacter()
    {
        this.mainScroll.scrollValue = 0f;
    }

    public void Populate()
    {
        if (this.isLoaded)
        {
            int count = 0;
            foreach (KeyValuePair<int, int> pair in PlayerLoginClient.redeemableItems)
            {
                count += Math.Max(0, pair.Value);
            }
            base.gameObject.SetActive(count > 0);
            UIGrid.SetElementCount<RedeemGridItem>(DragDropRoot.root, this.itemRedeemGrid, this.redeemPrefab, this.redeemList, count);
            int num2 = 0;
            foreach (KeyValuePair<int, int> pair in PlayerLoginClient.redeemableItems)
            {
                int num3;
                PlayerLoginClient.redeemItemIds.TryGetValue(pair.Key, out num3);
                for (int i = 0; i < pair.Value; i++)
                {
                    this.redeemList[num2 + i].SetItem(num2 + i, pair.Key, i < num3);
                }
                num2 += pair.Value;
            }
        }
    }

    private void SelectAllClicked(GameObject go)
    {
        PlayerLoginClient.redeemItemIds.Clear();
        foreach (KeyValuePair<int, int> pair in PlayerLoginClient.redeemableItems)
        {
            PlayerLoginClient.redeemItemIds[pair.Key] = pair.Value;
        }
        this.Populate();
    }
}

