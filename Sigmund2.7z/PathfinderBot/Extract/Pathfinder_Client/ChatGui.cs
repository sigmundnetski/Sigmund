﻿using GNetwork;
using GNGUI;
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;

public class ChatGui : HidablePanelGui
{
    private int activeTabIndex = 0;
    private static Dictionary<int, Color> channelIdToColor = new Dictionary<int, Color>();
    private static Dictionary<int, string> channelIdToName = new Dictionary<int, string>();
    public static ChatEnteredCallback chatEnteredCallback;
    private const string chatFormat = "{0}{1}[-]{2}{3}:[-] {0}{4}[-]";
    private UIInput chatInput;
    public const string colorFormat = "{0}{1}[-]";
    private static readonly string[][] DEFAULT_CHANNELS = new string[][] { new string[] { "local", "hex", "Party", "whisper" }, new string[] { "Party", "whisper" }, new string[] { "hex", "whisper" }, new string[] { "local", "whisper" }, new string[] { "Help" } };
    private static readonly string[] DEFAULT_TAB_NAMES = new string[] { "Chat", "Party", "Hex", "Local", "Help" };
    public static readonly string[] DELAYED_JOIN = new string[] { "Help" };
    public IgnoreEnterCallback ignoreEnterCallback = null;
    private const int NUM_TABS = 5;
    public static ChatGui singleton;
    private ChatTabGui[] tabs = new ChatTabGui[5];
    private static HashSet<int> unreadChannelIds = new HashSet<int>();

    public void AddChannelToTab(int channelId)
    {
        string str;
        channelIdToName.TryGetValue(channelId, out str);
        this.tabs[this.activeTabIndex].JoinChannel(channelId, str);
    }

    public static string AddColorCode(Color color, string text)
    {
        return string.Format("{0}{1}[-]", NguiColorFormatter.ToNguiString(color, NguiColorFormatter.StringType.DEFAULT), text);
    }

    public void Awake()
    {
        singleton = this;
        this.OnAwake();
    }

    public bool ChangeTab(string tabName)
    {
        tabName = tabName.ToLower();
        bool flag = false;
        for (int i = 0; i < DEFAULT_TAB_NAMES.Length; i++)
        {
            if (DEFAULT_TAB_NAMES[i].ToLower() == tabName)
            {
                flag = true;
                this.TabSelected(i);
                break;
            }
        }
        flag = flag && flag;
        return true;
    }

    public void ChannelJoined(int channelId, string channelName)
    {
        Color colorByName = ColorData.GetColorByName("chat_channel_" + channelName.ToLower(), false);
        if (colorByName == ColorData.UNKNOWN_COLOR.color)
        {
            colorByName = ChatClient.DEFAULT_COLOR;
        }
        channelIdToColor[channelId] = colorByName;
        channelIdToName[channelId] = channelName;
        bool flag = false;
        for (int i = 0; i < this.tabs.Length; i++)
        {
            if (this.tabs[i].DesireChannel(channelName))
            {
                this.tabs[i].JoinChannel(channelId, channelName);
                flag = true;
            }
        }
        if (!flag)
        {
            this.AddChannelToTab(channelId);
        }
    }

    public void ChannelLeft(int channelId, string channelName)
    {
        channelIdToColor.Remove(channelId);
        channelIdToName.Remove(channelId);
        for (int i = 0; i < this.tabs.Length; i++)
        {
            this.tabs[i].LeaveChannel(channelId);
        }
    }

    public bool ChannelViewed(int channelId)
    {
        return this.tabs[this.activeTabIndex].InChannel(channelId);
    }

    public void ClearChat()
    {
        for (int i = 0; i < this.tabs.Length; i++)
        {
            this.tabs[i].Clear();
        }
    }

    public void DisplayEmote(int channelId, string message, Color color)
    {
        this.DisplayMessage(channelId, AddColorCode(color, message.Trim()));
    }

    private void DisplayMessage(int channelId, string message)
    {
        for (int i = 0; i < this.tabs.Length; i++)
        {
            this.tabs[i].AddMessage(channelId, message);
        }
    }

    public void DisplayMessage(string message, Color color)
    {
        string str = string.Format("{0}{1}[-]", NguiColorFormatter.ToNguiString(color, NguiColorFormatter.StringType.DEFAULT), message);
        for (int i = 0; i < this.tabs.Length; i++)
        {
            this.tabs[i].AddMessage(str);
        }
    }

    public void DisplayMessage(int channelId, string characterName, string message)
    {
        string str;
        if (channelIdToName.TryGetValue(channelId, out str))
        {
            str = "[" + str + "] ";
        }
        else
        {
            str = string.Empty;
        }
        if (channelId == -3)
        {
            characterName = "From " + characterName;
        }
        if (channelId == -2)
        {
            characterName = "To " + characterName;
        }
        Color channelColor = GetChannelColor(channelId);
        string str2 = string.Format("{0}{1}[-]{2}{3}:[-] {0}{4}[-]", new object[] { NguiColorFormatter.ToNguiString(channelColor, NguiColorFormatter.StringType.DEFAULT), str, NguiColorFormatter.ToNguiString(channelColor, NguiColorFormatter.StringType.USERNAME), characterName, message });
        this.DisplayMessage(channelId, str2);
    }

    public ChatTabGui GetActiveTab()
    {
        return this.tabs[this.activeTabIndex];
    }

    private static Color GetChannelColor(int channelId)
    {
        Color color;
        if (!channelIdToColor.TryGetValue(channelId, out color))
        {
            color = ChatClient.DEFAULT_COLOR;
        }
        return color;
    }

    public string GetDisplayName(int channelId)
    {
        string str;
        if (channelIdToName.TryGetValue(channelId, out str))
        {
            return str;
        }
        if (ChatHelper.IsWhisperChannel(channelId))
        {
            return "Whisper";
        }
        return "UNKNOWN";
    }

    public ChatTabGui GetTab(int tabIndex)
    {
        return this.tabs[tabIndex];
    }

    public void GiveInputFocus()
    {
        this.chatInput.selected = true;
    }

    public void JoinChannels()
    {
        for (int i = 0; i < this.tabs.Length; i++)
        {
            this.tabs[i].JoinChannels();
        }
    }

    public bool LoadingTickFinished()
    {
        channelIdToColor[-2] = ChatClient.WHISPER_COLOR;
        channelIdToColor[-3] = ChatClient.WHISPER_COLOR;
        this.chatInput = base.GetComponentInChildren<UIInput>();
        GuiHelper.GuiAssertNotNull("Could not find needed child objects.", new object[] { this.chatInput });
        for (int i = 0; i < 5; i++)
        {
            this.tabs[i] = new ChatTabGui("Tab" + i.ToString("D2"), base.gameObject, i, DEFAULT_CHANNELS[i], DEFAULT_TAB_NAMES[i]);
        }
        UIEventListener listener1 = UIEventListener.Get(this.chatInput.gameObject);
        listener1.onSubmit = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onSubmit, new UIEventListener.VoidDelegate(this.PostMessage));
        HidablePanelGui.ImageButtonSprites hidePanel = new HidablePanelGui.ImageButtonSprites("panel_button_minleft_de", "panel_button_minleft_mo", "panel_button_minleft_cl");
        HidablePanelGui.ImageButtonSprites showPanel = new HidablePanelGui.ImageButtonSprites("panel_button_minright_de", "panel_button_minright_mo", "panel_button_minright_cl");
        base.ButtonImageSets(showPanel, hidePanel);
        base.AlwaysShow(base.closeButton.gameObject);
        this.JoinChannels();
        this.tabs[this.activeTabIndex].SetActive(true);
        return true;
    }

    private void OnAwake()
    {
        ClientTick.chatGuiLoadFinish = new GUtil.BoolFilterDelegate(this.LoadingTickFinished);
    }

    public void OnDestroy()
    {
        singleton = null;
    }

    public void PostMessage(GameObject go)
    {
        string message = NGUITools.StripSymbols(this.chatInput.text).Trim();
        GNetworkService.NetworkState networkState = GNetworkService.GetNetworkState();
        if (((networkState == GNetworkService.NetworkState.CLIENT_CONNECTED) || (networkState == GNetworkService.NetworkState.SERVER_HOSTING)) || (chatEnteredCallback != null))
        {
            if (message != string.Empty)
            {
                chatEnteredCallback(message);
            }
        }
        else
        {
            this.tabs[this.activeTabIndex].AddMessage(AddColorCode(ChatClient.ERROR_COLOR, "Not connected to server!"));
        }
        if (this.ignoreEnterCallback != null)
        {
            this.ignoreEnterCallback();
        }
    }

    public void ReadChannels(int[] readChannels)
    {
        int num;
        for (num = 0; num < readChannels.Length; num++)
        {
            unreadChannelIds.Remove(readChannels[num]);
        }
        for (num = 0; num < this.tabs.Length; num++)
        {
            this.tabs[num].UnreadChannels(unreadChannelIds);
        }
    }

    public bool RemoveChannelFromTab(int channelId)
    {
        this.tabs[this.activeTabIndex].LeaveChannel(channelId);
        for (int i = 0; i < this.tabs.Length; i++)
        {
            if (this.tabs[i].InChannel(channelId))
            {
                return true;
            }
        }
        return false;
    }

    public void SetChannel(int channelId, string name, ChatClient.ChannelType type)
    {
        string activeChannel;
        bool flag = string.IsNullOrEmpty(name);
        if (!(channelIdToName.TryGetValue(channelId, out activeChannel) || flag))
        {
            activeChannel = name;
        }
        else if (flag)
        {
            activeChannel = this.GetActiveTab().ActiveChannel;
        }
        this.chatInput.defaultText = activeChannel + " >";
        Color channelColor = GetChannelColor(channelId);
        this.chatInput.activeColor = channelColor;
        this.chatInput.inactiveColor = channelColor;
        this.tabs[this.activeTabIndex].SetChannel(name, channelId);
    }

    public void TabSelected(int tabIndex)
    {
        if (tabIndex != this.activeTabIndex)
        {
            this.tabs[this.activeTabIndex].SetActive(false);
            this.activeTabIndex = tabIndex;
            this.tabs[tabIndex].SetActive(true);
        }
    }

    public void UnreadChannel(int channelId)
    {
        unreadChannelIds.Add(channelId);
        for (int i = 0; i < this.tabs.Length; i++)
        {
            this.tabs[i].UnreadChannels(unreadChannelIds);
        }
    }

    public delegate void ChatEnteredCallback(string message);

    public delegate void IgnoreEnterCallback();
}

