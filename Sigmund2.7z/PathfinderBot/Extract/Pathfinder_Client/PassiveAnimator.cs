﻿using System;
using System.Runtime.InteropServices;
using UnityEngine;

public class PassiveAnimator : BaseMotion
{
    private float anim_forward = 0f;
    private const float ANIM_MAX_FORWARD_DELTA = 0.1f;
    private const float ANIM_MAX_ROTATE_DELTA = 0.1f;
    private const float ANIM_MAX_SPEED_DELTA = 0.1f;
    private const float ANIM_MAX_STRAFE_DELTA = 0.1f;
    private float anim_rotate = 0f;
    private float anim_speed_forward = 0f;
    private float anim_speed_strafe = 0f;
    private float anim_strafe = 0f;
    private float attackAnimServerEnd = 0f;
    private float attackAnimServerStart = 0f;
    private float crowdControlAnimServerEnd = 0f;
    private float crowdControlAnimServerStart = 0f;
    private Movement movement;
    public const float PROXY_MOVE_DELAY = 0.35f;

    private void CalculateAnimForwardMotion(Movement.TimeVelNode to, Movement.TimeVelNode from, out float animForward, out float animSpeed)
    {
        float num = Vector3.Magnitude(to.position - from.position) / (to.timestamp - from.timestamp);
        Vector3 lhs = (Vector3) (base.transform.rotation * Vector3.forward);
        animForward = Vector3.Dot(lhs, to.position - from.position);
        if (Mathf.Abs(animForward) < 0.175f)
        {
            animForward = 0f;
        }
        if (animForward > 0f)
        {
            animForward = 1f;
        }
        else if (animForward < 0f)
        {
            animForward = -1f;
        }
        animSpeed = num;
        base.debugUserInput[0, 1] = (float) animSpeed;
        base.debugUserInput[1, 1] = (float) animForward;
    }

    private float CalculateAnimRotation(Movement.TimeVelNode to, Movement.TimeVelNode from)
    {
        float num = from.rotation.eulerAngles[1];
        float num2 = to.rotation.eulerAngles[1];
        float num3 = (num2 - num) / (to.timestamp - from.timestamp);
        float num4 = num3 / MovementData.singleton.rotateSpeed;
        if ((num4 > -0.1f) && (num4 < 0.1f))
        {
            num4 = 0f;
        }
        num4 = Mathf.Clamp(num4, -1f, 1f);
        if (Mathf.Abs(num4) < 0.175f)
        {
            num4 = 0f;
        }
        base.debugUserInput[2, 1] = num4;
        return num4;
    }

    private void CalculateAnimStrafe(Movement.TimeVelNode to, Movement.TimeVelNode from, out float animStrafeDir, out float animStrafeSpeed)
    {
        float num = Vector3.Magnitude(to.position - from.position) / (to.timestamp - from.timestamp);
        Vector3 lhs = (Vector3) (base.transform.rotation * Vector3.right);
        animStrafeDir = Vector3.Dot(lhs, to.position - from.position);
        if (Mathf.Abs(animStrafeDir) < 0.175f)
        {
            animStrafeDir = 0f;
        }
        if (animStrafeDir > 0f)
        {
            animStrafeDir = 1f;
        }
        else if (animStrafeDir < 0f)
        {
            animStrafeDir = -1f;
        }
        animStrafeSpeed = num;
        base.debugUserInput[3, 1] = (float) animStrafeSpeed;
        base.debugUserInput[4, 1] = (float) animStrafeDir;
    }

    public void DoAttackAnim(AnimationData anim, float time, float serverTime, bool useOffhand, bool isRooted)
    {
        base.DoAttackAnim(anim, time, useOffhand, isRooted);
        this.attackAnimServerStart = serverTime;
        this.attackAnimServerEnd = serverTime + time;
    }

    public override void DoCrowdControlAnim(int anim, float serverTime, float amount, bool isRooted)
    {
        base.DoCrowdControlAnim(anim, serverTime, amount, isRooted);
        this.crowdControlAnimServerStart = serverTime;
        this.crowdControlAnimServerEnd = serverTime + amount;
    }

    public void DoStealthAnim(bool enable, float serverTime)
    {
        SparseArray.Add<BaseMotion.AnimCue>(ref this.animsToDo, new BaseMotion.AnimCue(Combat.AnimType.Stealth, serverTime, enable));
    }

    public void Emote(string animName, float time)
    {
    }

    public void FixedUpdate()
    {
        base.UpdateJump();
        float time = (Time.time - this.movement.averageServerTimeDelta) - 0.35f;
        this.ProcessAnimCues(time);
        base.ProcessStealth(false);
    }

    public override void OnAnimatorMove()
    {
        base.OnAnimatorMove();
        float currentTime = (Time.time - this.movement.averageServerTimeDelta) - 0.35f;
        Movement.TimeVelNode from = null;
        Movement.TimeVelNode to = null;
        if (base.crowdControlAnim > 0)
        {
            base.ProcessCrowdControl(currentTime, this.crowdControlAnimServerStart, this.crowdControlAnimServerEnd);
        }
        if (base.gatherAnimEnd > 0f)
        {
            base.ProcessGather(currentTime, base.gatherAnimStart, base.gatherAnimEnd);
        }
        if ((base.attackAnim != null) && (currentTime >= this.attackAnimServerStart))
        {
            base.ProcessAttack(currentTime, this.attackAnimServerStart, ref this.attackAnimServerEnd);
        }
        foreach (Movement.TimeVelNode node3 in this.movement.deltaQueue)
        {
            if (node3.timestamp <= currentTime)
            {
                if ((from == null) || (from.timestamp < node3.timestamp))
                {
                    from = node3;
                }
            }
            else if ((to == null) || (to.timestamp > node3.timestamp))
            {
                to = node3;
            }
        }
        if ((from == null) || (to == null))
        {
            base.anim.SetMovement(0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f);
            if (from != null)
            {
                base.transform.position = from.position;
                base.transform.rotation = from.rotation;
            }
            else if (to != null)
            {
                base.transform.position = to.position;
                base.transform.rotation = to.rotation;
            }
        }
        else
        {
            float num3;
            float num4;
            float num6;
            float num7;
            float t = (currentTime - from.timestamp) / (to.timestamp - from.timestamp);
            base.transform.rotation = Quaternion.Lerp(from.rotation, to.rotation, t);
            base.transform.position = Vector3.Lerp(from.position, to.position, t);
            this.CalculateAnimForwardMotion(to, from, out num3, out num4);
            float rawInput = this.CalculateAnimRotation(to, from);
            this.CalculateAnimStrafe(to, from, out num6, out num7);
            float rawForward = 0f;
            if ((num3 * num4) > 0.1)
            {
                rawForward = 1f;
            }
            else if ((num3 * num4) < -0.1)
            {
                rawForward = -1f;
            }
            float rawStrafe = 0f;
            if ((num6 * num4) > 0.1)
            {
                rawStrafe = 1f;
            }
            else if ((num6 * num4) < -0.1)
            {
                rawStrafe = -1f;
            }
            float rawRotate = 0f;
            if ((rawInput * num4) > 0.1)
            {
                rawRotate = 1f;
            }
            else if ((rawInput * num4) < -0.1)
            {
                rawRotate = -1f;
            }
            this.anim_speed_forward = base.SmoothInput(this.anim_speed_forward, num3 * num4, 0.1f);
            this.anim_speed_strafe = base.SmoothInput(this.anim_speed_strafe, num6 * num7, 0.1f);
            this.anim_forward = base.SmoothInput(this.anim_forward, num3, 0.1f);
            this.anim_strafe = base.SmoothInput(this.anim_strafe, num6, 0.1f);
            this.anim_rotate = base.SmoothInput(this.anim_rotate, rawInput, 0.1f);
            float f = num3 * num4;
            float num12 = num6 * num7;
            float rawTotalSpeed = Mathf.Max(Mathf.Abs(f), Mathf.Abs(num12));
            base.anim.SetMovement(rawTotalSpeed, f, num12, rawForward, rawStrafe, rawRotate, this.anim_forward, this.anim_strafe, this.anim_rotate);
            if ((from.type == Movement.MovementType.JumpStart) && (base.currentJumpState == BaseMotion.JumpState.NONE))
            {
                base.currentJumpState = BaseMotion.JumpState.LIFT_OFF;
                base.jumpStartTime = Time.time;
            }
            this.movement.ClearOldNodes(from.timestamp);
        }
    }

    protected override void ProcessAnimCues(float time)
    {
        for (int i = 0; i < base.animsToDo.Length; i++)
        {
            if ((base.animsToDo[i] != null) && (base.animsToDo[i].startTime <= time))
            {
                BaseMotion.AnimCue cue = base.animsToDo[i];
                if (cue.type == Combat.AnimType.Stealth)
                {
                    base.DoStealthAnim(cue.enable);
                }
            }
        }
        base.ProcessAnimCues(time);
    }

    public void QueueAnim(float serverTime, Combat.AnimType type, float amount, Vector3 originPosition)
    {
        SparseArray.Add<BaseMotion.AnimCue>(ref this.animsToDo, new BaseMotion.AnimCue(type, serverTime, amount, originPosition));
    }

    public override void Start()
    {
        base.Start();
        this.movement = base.GetComponent<Movement>();
        base.debugUserInput = new object[5, 2];
        base.debugUserInput[0, 0] = " MPS Forward Speed:";
        base.debugUserInput[1, 0] = " Forward:";
        base.debugUserInput[2, 0] = " Rotate:";
        base.debugUserInput[3, 0] = " MPS Strafe Speed:";
        base.debugUserInput[4, 0] = " Strafe:";
    }
}

