﻿using GNetwork;
using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

public class InventoryClient
{
    public static Color blueColor = new Color(0.04705882f, 0.07058824f, 0.7607843f);
    private static string boot;
    public static readonly BasicItemData.ItemSlot[] COLORABLE_SLOTS;
    private static string currentAsset;
    private static PlayerTrade currentTrade;
    private static string glove;
    public static Color goldColor = new Color(1f, 0.8431373f, 0f);
    public static Color grayColor = new Color(0.7450981f, 0.7450981f, 0.7450981f);
    public static Color greenColor = new Color(0f, 0.5450981f, 0.06666667f);
    public static Color orangeColor = new Color(1f, 0.4980392f, 0f);
    public static InventoryItem[] playerBank;
    private static int prevBodyHash = 0;
    private static int prevInvHash = 0;
    public static int prevMaxEncumbrance = 0;
    private static int prevPassiveHash = 0;
    private static int prevTrashHash = 0;
    public static Color purpleColor = new Color(0.5333334f, 0f, 0.7843137f);
    public static Color redColor = new Color(0.5882353f, 0.08235294f, 0.08235294f);
    private static string suit;
    private static InventoryItem[] tempItems;
    private static InventoryItem[] tempTakeStack;
    private static int tempUpgradeLevel;
    public static float totalEncumbrance = 0f;
    private static uint tradeAlertId;
    private static uint tradeId;
    private static bool waitingOnAlert;
    public static Color whiteColor = new Color(1f, 1f, 1f);

    static InventoryClient()
    {
        BasicItemData.ItemSlot[] slotArray = new BasicItemData.ItemSlot[5];
        slotArray[1] = BasicItemData.ItemSlot.FEET;
        slotArray[2] = BasicItemData.ItemSlot.HANDS;
        slotArray[3] = BasicItemData.ItemSlot.HEAD;
        slotArray[4] = BasicItemData.ItemSlot.BACK;
        COLORABLE_SLOTS = slotArray;
        suit = BasicItemData.SlotToString(BasicItemData.ItemSlot.ARMOR);
        glove = BasicItemData.SlotToString(BasicItemData.ItemSlot.HANDS);
        boot = BasicItemData.SlotToString(BasicItemData.ItemSlot.FEET);
        currentAsset = null;
        tempUpgradeLevel = 0;
        tempTakeStack = new InventoryItem[1];
        tradeId = uint.MaxValue;
        waitingOnAlert = false;
        tradeAlertId = uint.MaxValue;
        playerBank = new InventoryItem[0];
    }

    public static void AcceptTrade()
    {
        if (tradeId != uint.MaxValue)
        {
            GRouting.SendMyMapRpc(GRpcID.TradeServer_AcceptTrade, new object[] { tradeId });
        }
    }

    public static void AddTradeItem(InventoryItem item)
    {
        if (tradeId != uint.MaxValue)
        {
            GRouting.SendMyMapRpc(GRpcID.TradeServer_AddItem, new object[] { tradeId, item.staticItemId, item.quantity, item.upgrade, item.durability });
        }
    }

    public static void ApproveTrade()
    {
        if (tradeId != uint.MaxValue)
        {
            GRouting.SendMyMapRpc(GRpcID.TradeServer_ApproveTrade, new object[] { tradeId });
        }
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void BankUpdate(IBitBufferRead buffer)
    {
        playerBank = InventoryItemUtils.PopArrayFromBuffer(buffer);
        if (BankWindowGui.singleton != null)
        {
            BankWindowGui.singleton.ContentsChanged();
        }
        if (AuctionHouseGui.singleton != null)
        {
            AuctionHouseGui.singleton.OnOwnerBankUpdate();
        }
    }

    public static void CancelTrade()
    {
        if (tradeId != uint.MaxValue)
        {
            GRouting.SendMyMapRpc(GRpcID.TradeServer_CancelTrade, new object[] { tradeId });
        }
    }

    public static void Deposit(ulong copper)
    {
    }

    public static void EquipItem(BasicItemData.ItemSlot fromSlot, BasicItemData.ItemSlot toSlot, InventoryItem item)
    {
        BasicItemData data;
        if ((toSlot != BasicItemData.ItemSlot.NONE) && ItemDatabase.itemById.TryGetValue(item.staticItemId, out data))
        {
            int index = SparseArray.IndexOf<InventoryItem>(EntityDataClient.owner.playerRecord.inventory, item);
            int itemIndex = SparseArray.IndexOf<InventoryItem>(EntityDataClient.owner.playerRecord.bodySlots, item);
            if (index != -1)
            {
                MoveItem(index, fromSlot, toSlot);
            }
            else if (itemIndex != -1)
            {
                MoveItem(itemIndex, fromSlot, toSlot);
            }
            if ((index == -1) && (itemIndex == -1))
            {
                string displayName = "<NOT FOUND>";
                if (data != null)
                {
                    displayName = item.GetDisplayName(true);
                }
                Debug.LogError(string.Concat(new object[] { "Could not find item ", displayName, " (id: ", item.staticItemId, ") in inventory or on body." }));
            }
        }
    }

    public static void EquipmentSlotChange(BasicItemData.ItemSlot fromSlot, BasicItemData.ItemSlot toSlot, InventoryItem oldItem, InventoryItem newItem)
    {
        if ((oldItem.staticItemId == 0) && (newItem.staticItemId != 0))
        {
            EquipItem(fromSlot, toSlot, newItem);
        }
        else if ((oldItem.staticItemId != 0) && (newItem.staticItemId == 0))
        {
            UnequipItem(fromSlot, oldItem);
        }
        else if ((oldItem.staticItemId != 0) && (newItem.staticItemId != 0))
        {
            EquipItem(fromSlot, toSlot, newItem);
        }
    }

    public static IEnumerable<EquipmentAsset> GetAllEquippedAssets(InventoryItem[] equippedGear, int entityDefnId)
    {
        EntityDefnData data = EntityDefnData.defnById[entityDefnId];
        int raceId = data.raceId;
        string name = RaceData.raceById[raceId].name;
        char gender = (char) data.gender;
        Dictionary<string, EquipmentAsset> equippedAssets = new Dictionary<string, EquipmentAsset>();
        for (int i = 0; i < 7; i++)
        {
            GetAssetFromInventoryItem(equippedGear[i], name, gender, (BasicItemData.ItemSlot) ((byte) i), ref equippedAssets);
        }
        return equippedAssets.Values;
    }

    public static void GetAssetFromBasicItem(BasicItemData item, byte upgrade, string race, char gender, BasicItemData.ItemSlot slot, ref Dictionary<string, EquipmentAsset> equippedAssets, Color mat, Color user1, Color user2)
    {
        if (((item != null) && (item.id != 0)) && ((slot != BasicItemData.ItemSlot.FEET) && (slot != BasicItemData.ItemSlot.HANDS)))
        {
            string str = BasicItemData.SlotToString(slot);
            if (!string.IsNullOrEmpty(str))
            {
                string format = !string.IsNullOrEmpty(item.model) ? item.model.ToLower() : string.Empty;
                tempUpgradeLevel = upgrade;
                currentAsset = string.Format(format, new object[] { "1", race, gender, tempUpgradeLevel, str });
                while ((tempUpgradeLevel > 0) && !EntityLoadClient.characterPrefabs.ContainsKey(currentAsset))
                {
                    tempUpgradeLevel--;
                    currentAsset = string.Format(format, new object[] { "1", race, gender, tempUpgradeLevel, str });
                }
                if (EntityLoadClient.characterPrefabs.ContainsKey(currentAsset))
                {
                    equippedAssets[str] = new EquipmentAsset(currentAsset, mat, user1, user2);
                }
                if (slot == BasicItemData.ItemSlot.ARMOR)
                {
                    tempUpgradeLevel = upgrade;
                    currentAsset = string.Format(format, new object[] { "1", race, gender, tempUpgradeLevel, glove });
                    while ((tempUpgradeLevel > 0) && !EntityLoadClient.characterPrefabs.ContainsKey(currentAsset))
                    {
                        tempUpgradeLevel--;
                        currentAsset = string.Format(format, new object[] { "1", race, gender, tempUpgradeLevel, glove });
                    }
                    if (EntityLoadClient.characterPrefabs.ContainsKey(currentAsset))
                    {
                        equippedAssets[glove] = new EquipmentAsset(currentAsset, mat, user1, user2);
                    }
                    tempUpgradeLevel = upgrade;
                    currentAsset = string.Format(format, new object[] { "1", race, gender, tempUpgradeLevel, boot });
                    while ((tempUpgradeLevel > 0) && !EntityLoadClient.characterPrefabs.ContainsKey(currentAsset))
                    {
                        tempUpgradeLevel--;
                        currentAsset = string.Format(format, new object[] { "1", race, gender, tempUpgradeLevel, boot });
                    }
                    if (EntityLoadClient.characterPrefabs.ContainsKey(currentAsset))
                    {
                        equippedAssets[boot] = new EquipmentAsset(currentAsset, mat, user1, user2);
                    }
                }
            }
        }
    }

    public static void GetAssetFromInventoryItem(InventoryItem item, string race, char gender, BasicItemData.ItemSlot slot, ref Dictionary<string, EquipmentAsset> equippedAssets)
    {
        if (!InventoryItem.EMPTY_MATCH(item))
        {
            BasicItemData data = ItemDatabase.GetItem(item.staticItemId);
            if (data != null)
            {
                GetAssetFromBasicItem(data, item.upgrade, race, gender, slot, ref equippedAssets, ColorData.GetColorById(item.materialColorId), ColorData.GetColorById(item.userColorId1), ColorData.GetColorById(item.userColorId2));
            }
        }
    }

    public static string GetColoredItemDisplayName(InventoryItem item)
    {
        return (NguiColorFormatter.ToNguiString(GetQualityColor(item.GetQuality()), NguiColorFormatter.StringType.DEFAULT) + item.GetDisplayName(true) + "[-]");
    }

    public static void GetColoredItemDisplayName(ref StringBuilder quickText, InventoryItem item)
    {
        Color qualityColor = GetQualityColor(item.GetQuality());
        quickText.Append(NguiColorFormatter.ToNguiString(qualityColor, NguiColorFormatter.StringType.DEFAULT));
        quickText.Append(item.GetDisplayName(true));
        quickText.Append("[-]");
    }

    public static ulong GetInventoryCoinTotal()
    {
        if ((EntityDataClient.owner == null) || (EntityDataClient.owner.playerRecord.inventory == null))
        {
            return 0L;
        }
        ulong num = 0L;
        Entity owner = EntityDataClient.owner;
        for (int i = 0; i < owner.playerRecord.inventory.Length; i++)
        {
            if (!InventoryItem.EMPTY_MATCH(owner.playerRecord.inventory[i]) && (Array.IndexOf<int>(CurrencyItemData.allCurrencyDataIds, owner.playerRecord.inventory[i].staticItemId) != -1))
            {
                CurrencyItemData item = ItemDatabase.GetItem(owner.playerRecord.inventory[i].staticItemId) as CurrencyItemData;
                if (item != null)
                {
                    num += item.value * owner.playerRecord.inventory[i].quantity;
                }
            }
        }
        return num;
    }

    public static Color GetQualityColor(ushort itemQuality)
    {
        Color black = Color.black;
        if (itemQuality <= 40)
        {
            return grayColor;
        }
        if (itemQuality <= 80)
        {
            return whiteColor;
        }
        if (itemQuality <= 120)
        {
            return greenColor;
        }
        if (itemQuality <= 160)
        {
            return blueColor;
        }
        if (itemQuality <= 200)
        {
            return purpleColor;
        }
        if (itemQuality <= 240)
        {
            return redColor;
        }
        if (itemQuality <= 280)
        {
            return orangeColor;
        }
        if (itemQuality <= 300)
        {
            black = goldColor;
        }
        return black;
    }

    public static void InitiateTrade(EntityId targetId)
    {
        GRouting.SendMyMapRpc(GRpcID.TradeServer_RequestTrade, new object[] { targetId });
    }

    public static void MoveItem(int itemIndex, BasicItemData.ItemSlot fromSlot, BasicItemData.ItemSlot toSlot)
    {
        GRouting.SendMyMapRpc(GRpcID.InventoryServer_MoveItem, new object[] { itemIndex, (byte) fromSlot, (byte) toSlot });
    }

    public static void MoveItemBank(InventoryItem item, Item.Container source)
    {
        BitBuffer quickBuffer = GUtil.GetQuickBuffer();
        quickBuffer.PushByte((byte) source);
        item.Write(quickBuffer, InventoryItem.EMPTY);
        GRouting.SendMyMapRpc(GRpcID.PlayerBankServer_MoveItem, new object[] { quickBuffer });
    }

    public static void OfferTrade()
    {
        if (tradeId != uint.MaxValue)
        {
            GRouting.SendMyMapRpc(GRpcID.TradeServer_OfferTrade, new object[] { tradeId });
        }
    }

    public static void OnAlertInteraction(uint alertId, AlertsManagerGui.AlertAction action)
    {
        if (action != AlertsManagerGui.AlertAction.CANCEL)
        {
            if (action == AlertsManagerGui.AlertAction.ACCEPTED)
            {
                TradeWindowGui.singleton.ContentsChanged(currentTrade);
                ApproveTrade();
            }
            else
            {
                CancelTrade();
            }
            tradeAlertId = uint.MaxValue;
            waitingOnAlert = false;
        }
    }

    public static void OnClientEntityUpdate(Entity entity)
    {
        if (((((entity == EntityDataClient.owner) && (entity.gear != null)) && ((entity.combat != null) && (AuctionHouseGui.singleton != null))) && (((BankWindowGui.singleton != null) && (InventoryTrashCanGui.singleton != null)) && (InventoryWindowGui.singleton != null))) && (PaperdollWindowGui.singleton != null))
        {
            int num = InventoryItemUtils.InventoryHash(entity.playerRecord.bodySlots);
            int num2 = InventoryItemUtils.InventoryHash(entity.playerRecord.inventory);
            int num3 = InventoryItemUtils.InventoryHash(entity.playerRecord.trashContainer);
            int maxEncumbrance = entity.combat.GetMaxEncumbrance();
            int num5 = SparseArray.Hash(entity.combat.combatClass.passiveFeatIds);
            if ((prevBodyHash != num) || (prevPassiveHash != num5))
            {
                PaperdollWindowGui.singleton.ContentsChanged();
            }
            if (prevInvHash != num2)
            {
                InventoryWindowGui.singleton.ContentsChanged();
                AuctionHouseGui.singleton.OnOwnerInvUpdate();
            }
            if (prevTrashHash != num3)
            {
                InventoryTrashCanGui.singleton.Refresh();
            }
            if (((prevBodyHash != num) || (prevInvHash != num2)) || (prevMaxEncumbrance != maxEncumbrance))
            {
                UpdateEncumbrance(maxEncumbrance);
            }
            BankWindowGui.singleton.CoinChanged();
            prevBodyHash = num;
            prevInvHash = num2;
            prevTrashHash = num3;
            prevMaxEncumbrance = maxEncumbrance;
            prevPassiveHash = num5;
        }
    }

    public static void OnItemRClick(GameObject clickedGO, InventoryItem item)
    {
        BasicItemData itemData = ItemDatabase.GetItem(item.staticItemId);
        if (SparseArray.IndexOf<BasicItemData.ItemSlot>(COLORABLE_SLOTS, x => x == itemData.slot) != -1)
        {
            InventoryItemRClick.singleton.ShowRecolorWindow(clickedGO.transform.position, item, BasicItemData.ItemSlot.NONE);
        }
        else if (itemData is CraftRecipeItemData)
        {
            GRouting.SendMyMapRpc(GRpcID.CraftingServer_LearnCraftRecipe, new object[] { item.staticItemId });
        }
        else if (itemData is ExpendableRecipeItemData)
        {
            GRouting.SendMyMapRpc(GRpcID.AdvancementServer_LearnExpendableRecipe, new object[] { item.staticItemId });
        }
        else if (itemData is TreasureBoxItemData)
        {
            TreasureBoxSelectorGui.OpenTreasureBox(item.staticItemId);
        }
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void OpenBank(IBitBufferRead buffer)
    {
        BankUpdate(buffer);
        if (BankWindowGui.singleton != null)
        {
            BankWindowGui.singleton.ShowWindow();
        }
    }

    public static void RecolorItem(InventoryItem item, int newColorId, bool isPrimary, BasicItemData.ItemSlot slot)
    {
        Predicate<InventoryItem> match = null;
        int index = -1;
        if (slot == BasicItemData.ItemSlot.NONE)
        {
            if (match == null)
            {
                match = x => x.DataEquals(item, 0xff);
            }
            index = SparseArray.IndexOf<InventoryItem>(EntityDataClient.owner.playerRecord.inventory, match);
            if (index != -1)
            {
                GRouting.SendMyMapRpc(GRpcID.InventoryServer_RecolorItem, new object[] { index, item.staticItemId, newColorId, isPrimary, (byte) slot });
            }
        }
        else if (EntityDataClient.owner.playerRecord.bodySlots[(int) slot].DataEquals(item, 0xff))
        {
            GRouting.SendMyMapRpc(GRpcID.InventoryServer_RecolorItem, new object[] { index, item.staticItemId, newColorId, isPrimary, (byte) slot });
        }
    }

    public static void RemoveTradeItem(InventoryItem item)
    {
        if (tradeId != uint.MaxValue)
        {
            GRouting.SendMyMapRpc(GRpcID.TradeServer_RemoveItem, new object[] { tradeId, item.staticItemId, item.quantity, item.upgrade, item.durability });
        }
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void ShowLootWindow(IBitBufferRead buffer)
    {
        EntityId id = buffer.PopEntityId();
        bool showLootAll = buffer.PopBool();
        InventoryItemUtils.PopArrayFromBuffer(buffer, ref tempItems);
        if (SparseArray.Count<InventoryItem>(tempItems, InventoryItem.EMPTY_MATCH) > 0)
        {
            LootWindowGui.singleton.ShowLoot(id, showLootAll, tempItems);
        }
        else
        {
            LootWindowGui.singleton.HideWindow();
        }
    }

    private static void SyncStart()
    {
        StaticDataService.RegisterCallback<ColorData>(new StaticDataService.StaticDataServiceCallback(InventoryClient.UpdateColors));
    }

    public static void TakeAll(EntityId targetId)
    {
        GRouting.SendMyMapRpc(GRpcID.InventoryServer_TakeAll, new object[] { targetId });
    }

    public static void TakeStack(EntityId targetId, InventoryItem item)
    {
        tempTakeStack[0] = item;
        BitBuffer quickBuffer = GUtil.GetQuickBuffer();
        quickBuffer.PushEntityId(targetId);
        InventoryItemUtils.PushToBuffer(quickBuffer, tempTakeStack);
        GRouting.SendMyMapRpc(GRpcID.InventoryServer_TakeStack, new object[] { quickBuffer });
    }

    public static void TradeCommand(string[] args, EntityId playerEntityId)
    {
        Entity entity = EntityCore.GetEntity(Targeting.selectedEntityId);
        if (entity == null)
        {
            ChatGui.singleton.DisplayMessage("Must target someone to trade with.", ChatClient.ERROR_COLOR);
        }
        else if (entity.pvp == null)
        {
            ChatGui.singleton.DisplayMessage("Can only trade with players.", ChatClient.ERROR_COLOR);
        }
        else if (EntityCore.Match(entity.entityId, PlayerEntityClient.GetPlayerEntityId()))
        {
            ChatGui.singleton.DisplayMessage("Cannot trade with yourself.", ChatClient.ERROR_COLOR);
        }
        else
        {
            InitiateTrade(Targeting.selectedEntityId);
        }
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void TradeFinished(byte reasonByte)
    {
        if (waitingOnAlert)
        {
            AlertsManagerGui.singleton.CancelAlert(tradeAlertId);
        }
        PlayerTrade.TradeFailure reason = (PlayerTrade.TradeFailure) reasonByte;
        tradeId = uint.MaxValue;
        tradeAlertId = uint.MaxValue;
        currentTrade = null;
        waitingOnAlert = false;
        TradeWindowGui.singleton.TradeFinished(reason);
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void TradeSync(IBitBufferRead buffer)
    {
        currentTrade = PlayerTrade.PopFromBuffer(buffer);
        if ((tradeId == uint.MaxValue) && EntityCore.Match(EntityDataClient.owner.entityId, currentTrade.targetEntityId))
        {
            Entity entity = EntityCore.GetEntity(currentTrade.initiatorEntityId);
            if (entity == null)
            {
                CancelTrade();
                return;
            }
            tradeAlertId = AlertsManagerGui.singleton.NewAlert(AlertsManagerGui.AlertType.TRADE, entity.EntityName + " wants to trade.", new AlertsManagerGui.OnAlertInteraction(InventoryClient.OnAlertInteraction));
            waitingOnAlert = true;
        }
        tradeId = currentTrade.tradeId;
        if (!waitingOnAlert && (currentTrade.initiatorStatus > PlayerTrade.Status.TRADE_REQUEST))
        {
            TradeWindowGui.singleton.ContentsChanged(currentTrade);
        }
    }

    public static void TrashItem(InventoryItem item)
    {
        InventoryItem[] testItems = new InventoryItem[] { item };
        if (!InventoryItemUtils.InventoryContains(EntityDataClient.owner.playerRecord.inventory, testItems))
        {
            DebugClient.GenericDebugMessage("Failed to trash item");
        }
        else
        {
            BitBuffer quickBuffer = GUtil.GetQuickBuffer();
            item.Write(quickBuffer, InventoryItem.EMPTY);
            GRouting.SendMyMapRpc(GRpcID.InventoryServer_TrashItem, new object[] { quickBuffer });
        }
    }

    public static void UndoTrash()
    {
        InventoryItem[] trashContainer = EntityDataClient.owner.playerRecord.trashContainer;
        for (int i = trashContainer.Length - 1; i >= 0; i--)
        {
            if (!InventoryItem.EMPTY_MATCH(trashContainer[i]))
            {
                BitBuffer quickBuffer = GUtil.GetQuickBuffer();
                trashContainer[i].Write(quickBuffer, InventoryItem.EMPTY);
                GRouting.SendMyMapRpc(GRpcID.InventoryServer_UndoTrash, new object[] { quickBuffer });
                break;
            }
        }
    }

    public static void UnequipItem(BasicItemData.ItemSlot slot, InventoryItem item)
    {
        MoveItem((int) slot, slot, BasicItemData.ItemSlot.NONE);
    }

    public static void UpdateColors(List<DataClass> ignored)
    {
        grayColor = ColorData.GetColorByName("item_quality_gray", true);
        whiteColor = ColorData.GetColorByName("item_quality_white", true);
        greenColor = ColorData.GetColorByName("item_quality_green", true);
        blueColor = ColorData.GetColorByName("item_quality_blue", true);
        purpleColor = ColorData.GetColorByName("item_quality_purple", true);
        redColor = ColorData.GetColorByName("item_quality_red", true);
        orangeColor = ColorData.GetColorByName("item_quality_orange", true);
        goldColor = ColorData.GetColorByName("item_quality_gold", true);
    }

    private static void UpdateEncumbrance(int newMaxEncumbrance)
    {
        totalEncumbrance = InventoryItemUtils.CalclulateEncumbrance(EntityDataClient.owner.playerRecord.bodySlots) + InventoryItemUtils.CalclulateEncumbrance(EntityDataClient.owner.playerRecord.inventory);
        InventoryWindowGui.singleton.UpdateEncumbrance(totalEncumbrance / ((float) newMaxEncumbrance));
        WindowBarGui.singleton.UpdateInventory();
    }

    public static void Withdrawal(ulong copper)
    {
        GRouting.SendMyMapRpc(GRpcID.PlayerBankServer_BankCoin, new object[] { (byte) 0, copper });
    }

    public enum ItemQualityLevel
    {
        BLUE = 160,
        GOLD = 300,
        GRAY = 40,
        GREEN = 120,
        ORANGE = 280,
        PURPLE = 200,
        RED = 240,
        WHITE = 80
    }
}

