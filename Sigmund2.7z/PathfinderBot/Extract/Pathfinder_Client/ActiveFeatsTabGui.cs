﻿using GNGUI;
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class ActiveFeatsTabGui : WindowTabGui
{
    public override void Awake()
    {
        base.Awake();
        base.tabSpriteName = "panel_feats_tab_right_activefeats";
        base.prefabName = "FeatGridItem";
        foreach (ToggleText text in base.GetComponentsInChildren<ToggleText>())
        {
            base.allFilters.Add(text);
            UIEventListener listener1 = UIEventListener.Get(text.gameObject);
            listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.FilterClicked));
            if (text.name == "F0_Attack")
            {
                text.Init(new int[] { 3 });
            }
            else if (text.name == "F1_Expendable")
            {
                text.Init(new int[] { 4 });
            }
            else if (text.name == "F3_Refresh")
            {
                text.Init(new int[] { 8 });
            }
            else if (text.name == "F2_Utility")
            {
                text.Init(new int[] { 5 });
            }
            else
            {
                GLog.LogError(new object[] { "Unknown filter!", text.name });
            }
        }
    }

    private void ClearFeatList()
    {
        foreach (TabListItem item in base.displayedItems)
        {
            item.gameObject.SetActive(false);
            item.transform.parent = DragDropRoot.root;
            UnityEngine.Object.Destroy(item.gameObject);
        }
        base.displayedItems.Clear();
    }

    public override void ContentsChanged()
    {
        this.NonAttacksChanged();
        this.OffensivesChanged();
    }

    private FeatGridItem CreateFeatGridItem(NonAttackFeatData feat)
    {
        FeatGridItem component = NGUITools.AddChild(base.gridList.gameObject, base.listItemPrefab).GetComponent<FeatGridItem>();
        component.Assign(feat.id, feat.type, Combat.FeatType.NonAttack, feat.icon, feat.displayName, EntityDataClient.owner.advancementVars.GetFeatLevelByFeatId(feat.id));
        return component;
    }

    private FeatGridItem CreateFeatGridItem(OffensiveFeatData feat)
    {
        FeatGridItem component = NGUITools.AddChild(base.gridList.gameObject, base.listItemPrefab).GetComponent<FeatGridItem>();
        component.Assign(feat.id, feat.type, Combat.FeatType.Offensive, feat.icon, feat.displayName, EntityDataClient.owner.advancementVars.GetFeatLevelByFeatId(feat.id));
        return component;
    }

    public override void FilterClicked(GameObject filterGO)
    {
        foreach (ToggleText text in base.allFilters)
        {
            if (filterGO == text.gameObject)
            {
                text.ToggleActive();
                base.activeFilter = text.isActive ? text : null;
            }
            else
            {
                text.SetActive(false);
            }
        }
        this.ContentsChanged();
        PaperdollWindowGui.singleton.SetValidityByFilter(PaperdollWindowGui.FilterType.FEATS, base.activeFilter);
        ButtonBarGui.singleton.SetDragTargetValidity();
        base.FilterClicked(filterGO);
    }

    public override void HideTab()
    {
        base.HideTab();
        this.ClearFeatList();
        ButtonBarGui.singleton.ResetDragTargetValidity();
    }

    private bool IsValidForFilter(NonAttackFeatData naFeat, OffensiveFeatData oFeat)
    {
        Combat.FeatType none = Combat.FeatType.None;
        if (naFeat != null)
        {
            none = naFeat.type;
        }
        if (oFeat != null)
        {
            none = oFeat.type;
        }
        bool flag = (naFeat != null) ? (naFeat.generalType == Combat.FeatType.Active) : true;
        bool flag2 = false;
        if ((base.activeFilter != null) && base.activeFilter.filterIds.Contains<int>(((int) none)))
        {
            flag2 = true;
        }
        else if ((base.activeFilter == null) && flag)
        {
            flag2 = true;
        }
        bool flag3 = false;
        int roleIdFilter = FeatsWindowGui.singleton.roleIdFilter;
        if (roleIdFilter == 0)
        {
            flag3 = true;
        }
        else if ((naFeat != null) && (roleIdFilter == naFeat.roleId))
        {
            flag3 = true;
        }
        else if ((oFeat != null) && (roleIdFilter == oFeat.roleId))
        {
            flag3 = true;
        }
        return (flag2 && flag3);
    }

    protected override void MakeListItems()
    {
        if (base.displayedItems.Count<TabListItem>() > 0)
        {
            this.ClearFeatList();
        }
        foreach (OffensiveFeatData data in OffensiveFeatData.GetAvailableFeats(EntityDataClient.owner, EntityDataClient.owner.advancementVars))
        {
            if (this.IsValidForFilter(null, data))
            {
                base.displayedItems.Add(this.CreateFeatGridItem(data));
            }
        }
        foreach (NonAttackFeatData data2 in NonAttackFeatData.GetAvailableFeats(EntityDataClient.owner, EntityDataClient.owner.advancementVars))
        {
            if (this.IsValidForFilter(data2, null))
            {
                base.displayedItems.Add(this.CreateFeatGridItem(data2));
            }
        }
        this.RepositionListItems();
    }

    public void NonAttacksChanged()
    {
        IEnumerable<NonAttackFeatData> enumerable;
        IEnumerable<NonAttackFeatData> enumerable2;
        IEnumerable<NonAttackFeatData> newItems = from each in NonAttackFeatData.GetAvailableFeats(EntityDataClient.owner, EntityDataClient.owner.advancementVars)
            where (each != null) && this.IsValidForFilter(each, null)
            select each;
        IEnumerable<NonAttackFeatData> oldItems = from each in base.displayedItems
            where ((FeatGridItem) each).featBaseType == Combat.FeatType.NonAttack
            select NonAttackFeatData.GetFeatById(((FeatGridItem) each).featId);
        GUtil.GetDeltasWithDuplicates<NonAttackFeatData>(newItems, oldItems, out enumerable, out enumerable2);
        foreach (NonAttackFeatData data in enumerable)
        {
            this.UpdateFeatList(data, WindowTabGui.UpdateType.REMOVE);
        }
        foreach (NonAttackFeatData data in enumerable2)
        {
            this.UpdateFeatList(data, WindowTabGui.UpdateType.ADD);
        }
    }

    public void OffensivesChanged()
    {
        IEnumerable<OffensiveFeatData> enumerable;
        IEnumerable<OffensiveFeatData> enumerable2;
        IEnumerable<OffensiveFeatData> newItems = from each in OffensiveFeatData.GetAvailableFeats(EntityDataClient.owner, EntityDataClient.owner.advancementVars)
            where (each != null) && this.IsValidForFilter(null, each)
            select each;
        IEnumerable<OffensiveFeatData> oldItems = from each in base.displayedItems
            where ((FeatGridItem) each).featBaseType == Combat.FeatType.Offensive
            select OffensiveFeatData.GetAttackById(((FeatGridItem) each).featId);
        GUtil.GetDeltasWithDuplicates<OffensiveFeatData>(newItems, oldItems, out enumerable, out enumerable2);
        foreach (OffensiveFeatData data in enumerable)
        {
            this.UpdateFeatList(data, WindowTabGui.UpdateType.REMOVE);
        }
        foreach (OffensiveFeatData data in enumerable2)
        {
            this.UpdateFeatList(data, WindowTabGui.UpdateType.ADD);
        }
    }

    public override void ShowTab()
    {
        this.MakeListItems();
        base.ShowTab();
    }

    private void UpdateFeatList(NonAttackFeatData item, WindowTabGui.UpdateType updateType)
    {
        Predicate<TabListItem> match = null;
        if (updateType == WindowTabGui.UpdateType.REMOVE)
        {
            if (match == null)
            {
                match = i => (((FeatGridItem) i).featId == item.id) && (((FeatGridItem) i).featType == item.type);
            }
            TabListItem item2 = base.displayedItems.Find(match);
            if (item2 == null)
            {
                return;
            }
            item2.gameObject.SetActive(false);
            item2.transform.parent = DragDropRoot.root;
            UnityEngine.Object.Destroy(item2.gameObject);
            base.displayedItems.Remove(item2);
        }
        else
        {
            FeatGridItem item3 = this.CreateFeatGridItem(item);
            base.displayedItems.Add(item3);
        }
        this.RepositionListItems();
    }

    private void UpdateFeatList(OffensiveFeatData item, WindowTabGui.UpdateType updateType)
    {
        Predicate<TabListItem> match = null;
        if (updateType == WindowTabGui.UpdateType.REMOVE)
        {
            if (match == null)
            {
                match = i => (((FeatGridItem) i).featId == item.id) && (((FeatGridItem) i).featType == item.type);
            }
            TabListItem item2 = base.displayedItems.Find(match);
            if (item2 == null)
            {
                return;
            }
            item2.gameObject.SetActive(false);
            item2.transform.parent = DragDropRoot.root;
            UnityEngine.Object.Destroy(item2.gameObject);
            base.displayedItems.Remove(item2);
        }
        else
        {
            FeatGridItem item3 = this.CreateFeatGridItem(item);
            base.displayedItems.Add(item3);
        }
        this.RepositionListItems();
    }
}

