﻿using GNetwork;
using GNGUI;
using System;
using UnityEngine;

public class TrainerWindowGui : WindowGui
{
    private Tabs activeTab = Tabs.AVAILABLE;
    private WindowTabGui[] allTabs = new WindowTabGui[2];
    private const int FREQUENCY_REDUCTION = 120;
    private int frequencyTick = 0;
    private const string LOCK_REASON = "Cannot move until trainer window is closed.";
    public static TrainerWindowGui singleton;
    public const float TRAINER_RANGE_SQ = 100f;
    [NonSerialized, HideInInspector]
    public EntityId trainerEntityId;
    public int trainerId;
    private UILabel trainerLabel;
    public byte trainerLevel;
    private UILabel xpLabel;

    public void AvailableTabSelected(GameObject button)
    {
        Tabs activeTab = this.activeTab;
        this.activeTab = Tabs.AVAILABLE;
        if (this.activeTab != activeTab)
        {
            this.ShowTab();
        }
    }

    public void Awake()
    {
        singleton = this;
        ClientTick.trainerGuiLoadFinish = new GUtil.BoolFilterDelegate(this.LoadingTickFinished);
        ClientTick.trainerGuiTick = new GUtil.BoolFilterDelegate(this.SyncFixedUpdate);
        foreach (UILabel label in base.GetComponentsInChildren<UILabel>())
        {
            if (label.name == "XpLabel")
            {
                this.xpLabel = label;
            }
            else if (label.name == "TrainerLabel")
            {
                this.trainerLabel = label;
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find needed children.", new object[] { this.xpLabel, this.trainerLabel });
        this.GetAllTabs();
    }

    public void BuyClicked(TrainerListItem featToBuy)
    {
        if (featToBuy.featAdvId != 0)
        {
            FeatAdvancementData featExpData = FeatAdvancementData.dataByFeatAdvancementId[featToBuy.featAdvId];
            AdvancementVars.FeatAvailability availability = EntityDataClient.owner.advancementVars.CanBuyFeatAtLevel(featExpData, featToBuy.featAdvLevel, GNetworkService.ServerUtc);
            if (AdvancementVars.FeatAvailability.AVAILABLE == availability)
            {
                CommandCore.ExecuteCommand(string.Concat(new object[] { "BuyFeat ", this.trainerEntityId, " ", featToBuy.featAdvId, " ", featToBuy.featAdvLevel }), EntityDataClient.owner.entityId);
            }
            else
            {
                GLog.LogError(new object[] { "Unable to purchase feat", availability });
                this.OnTrainerInteract(this.trainerEntityId, this.trainerId, this.trainerLevel);
            }
        }
    }

    private bool CheckRange()
    {
        Entity entity = EntityCore.GetEntity(ref this.trainerEntityId);
        Entity owner = EntityDataClient.owner;
        if ((entity == null) || (owner == null))
        {
            this.HideWindow();
        }
        else
        {
            Vector3 vector = entity.GetLocalPosition() - owner.GetLocalPosition();
            float num = (vector.x * vector.x) + (vector.z * vector.z);
            if (num > 100f)
            {
                this.HideWindow();
            }
        }
        return base.IsShowing();
    }

    public void ContentsChanged()
    {
        if ((base.IsShowing() && (this.trainerEntityId != EntityId.INVALID_ID)) && (this.trainerId != 0))
        {
            this.GetActiveTab().ContentsChanged();
            this.xpLabel.text = "Current Exp: " + EntityDataClient.owner.advancementVars.PredictAvailableExpAtTime(GNetworkService.ServerUtc);
        }
    }

    public WindowTabGui GetActiveTab()
    {
        return this.allTabs[(int) this.activeTab];
    }

    private void GetAllTabs()
    {
        foreach (WindowTabGui gui in base.GetComponentsInChildren<WindowTabGui>())
        {
            string name = gui.name;
            if (name == null)
            {
                goto Label_0052;
            }
            if (!(name == "TabAvailableFeats"))
            {
                if (name == "TabUnavailableFeats")
                {
                    goto Label_0047;
                }
                goto Label_0052;
            }
            this.allTabs[0] = gui;
            continue;
        Label_0047:
            this.allTabs[1] = gui;
            continue;
        Label_0052:;
            GLog.LogWarning(new object[] { "Unknown tab '" + gui.name + "'." });
        }
        GuiHelper.GuiAssertNotNull("Couldn't find needed tabs.", this.allTabs);
        foreach (Collider collider in base.GetComponentsInChildren<Collider>())
        {
            if (collider.name == "AvailableFeatsButton")
            {
                UIEventListener listener1 = UIEventListener.Get(collider.gameObject);
                listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.AvailableTabSelected));
            }
            else if (collider.name == "UnavailableFeatsButton")
            {
                UIEventListener listener2 = UIEventListener.Get(collider.gameObject);
                listener2.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener2.onClick, new UIEventListener.VoidDelegate(this.UnavailableTabSelected));
            }
        }
    }

    public override void HideWindow()
    {
        if (CombatClient.entityMotion != null)
        {
            CombatClient.entityMotion.UnlockPosition(BaseMotion.PositionLock.RootedGuiInteract);
        }
        base.HideWindow();
        this.GetActiveTab().HideTab();
        this.trainerEntityId = EntityId.INVALID_ID;
        this.trainerId = 0;
    }

    public bool LoadingTickFinished()
    {
        foreach (WindowTabGui gui in this.allTabs)
        {
            gui.LoadingTickFinished();
        }
        return true;
    }

    public static void OnClientEntityUpdate(Entity entity)
    {
        if (((singleton != null) && (entity == EntityDataClient.owner)) && (entity.advancementVars != null))
        {
            singleton.ContentsChanged();
        }
    }

    public override void OnDestroy()
    {
        base.OnDestroy();
        singleton = null;
    }

    public void OnTrainerInteract(EntityId trainerEntityId_, int trainerId_, byte trainerLevel_)
    {
        this.trainerEntityId = trainerEntityId_;
        this.trainerId = trainerId_;
        this.trainerLevel = trainerLevel_;
        Entity entity = EntityCore.GetEntity(ref this.trainerEntityId);
        if (entity != null)
        {
            this.trainerLabel.text = entity.EntityName;
        }
        else
        {
            this.trainerLabel.text = string.Empty;
        }
        this.AvailableTabSelected(null);
        this.ShowWindow();
    }

    public void ShowTab()
    {
        for (int i = 0; i < this.allTabs.Length; i++)
        {
            if (i == this.activeTab)
            {
                this.allTabs[i].ShowTab();
            }
            else
            {
                this.allTabs[i].HideTab();
            }
        }
    }

    public override void ShowWindow()
    {
        if (CombatClient.entityMotion != null)
        {
            CombatClient.entityMotion.LockPosition(BaseMotion.PositionLock.RootedGuiInteract, "Cannot move until trainer window is closed.");
        }
        base.ShowWindow();
        this.ShowTab();
    }

    public void Start()
    {
        foreach (WindowTabGui gui in this.allTabs)
        {
            gui.HideTab();
        }
        base.Init(3, true);
    }

    public bool SyncFixedUpdate()
    {
        this.frequencyTick = (this.frequencyTick + 1) % 120;
        if (((this.frequencyTick == 0) && base.IsShowing()) && this.CheckRange())
        {
            this.xpLabel.text = "Current Exp: " + EntityDataClient.owner.advancementVars.PredictAvailableExpAtTime(GNetworkService.ServerUtc);
        }
        return true;
    }

    public void UnavailableTabSelected(GameObject button)
    {
        Tabs activeTab = this.activeTab;
        this.activeTab = Tabs.UNAVAILABLE;
        if (this.activeTab != activeTab)
        {
            this.ShowTab();
        }
    }

    private enum Tabs
    {
        AVAILABLE,
        UNAVAILABLE,
        NUM_TABS
    }
}

