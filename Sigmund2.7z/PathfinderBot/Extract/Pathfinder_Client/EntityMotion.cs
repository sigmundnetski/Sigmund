﻿using System;
using System.Runtime.InteropServices;
using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class EntityMotion : BaseMotion
{
    private const float ANIM_FORWARD_BLEND_TIME = 0.25f;
    private const float ANIM_ROTATE_BLEND_TIME = 0.25f;
    private float anim_speed = 0f;
    private const float ANIM_SPEED_BLEND_TIME = 0.5f;
    private const float ANIM_STRAFE_BLEND_TIME = 0.25f;
    private float cameraYaw = 0f;
    private float chargeDistanceRemaining = 0f;
    private GameObject chargeTarget;
    private bool commandInit = false;
    private CharacterController controller;
    public static bool debugNoMovement = false;
    public static bool debugSpeed = false;
    private const float FAST_SLIDE_BEGIN = 0.3f;
    private Quaternion fixedRotation;
    private float fixedTime;
    private float forcedMoveEndTime = 0f;
    private Movement.MovementType forcedMoveEndType = Movement.MovementType.None;
    private Vector3 forcedMoveOrigin = GConst.VECTOR3_INVALID;
    private float forcedMoveSpeed = 0f;
    public float forward = 0f;
    private SimpleMovingAverage forwardSMA;
    private Vector3 groundNormal;
    private bool hasMoveInput = false;
    private bool jump = false;
    private const float JUMP_REQUEST_TIMEOUT_DELTA = 0.5f;
    private float jumpRequestTimeout = float.PositiveInfinity;
    private float jumpStartY = 0f;
    private const float KEYBOARD_ROTATE_SPEED = 3f;
    private float keyboardForward = 0f;
    private float keyboardRotate = 0f;
    private float keyboardStrafe = 0f;
    private float lastLockNotifyTime = 0f;
    private const float LOCK_RENOTIFY_DELAY = 2.5f;
    private string lockReason;
    private const float MIN_YAW_DEGREES = 1f;
    private float mouseForward = 0f;
    private bool mouseForwardValid = false;
    private Combat.AnimType preemptMovement = Combat.AnimType.None;
    private CombatVars.MovementType prevMoveType = CombatVars.MovementType.IDLE;
    private Vector3 prevPosition = GConst.VECTOR3_INVALID;
    private Quaternion prevRotation;
    private float prevTime;
    public float rotate = 0f;
    private SimpleMovingAverage rotateSMA;
    public static EntityMotion singleton;
    private const float SLIDE_GRAVITY = 12f;
    private float slideDuration = 0f;
    private SimpleMovingAverage speedSMA;
    public CombatVars.MovementType speedToggle = CombatVars.MovementType.HUSTLE;
    private SteeringMode steeringMode = SteeringMode.KEYBOARD;
    public float strafe = 0f;
    private SimpleMovingAverage strafeSMA;
    private float verticalSpeed = 0f;
    public float yawTarget = 0f;

    public override void Awake()
    {
        base.Awake();
        singleton = this;
        ClientTick.entityMotionTick = new GUtil.BoolFilterDelegate(this.SyncFixedUpdate);
        Vector3 center = GConst.VECTOR3_INVALID;
        float radius = 0f;
        float height = 0f;
        CapsuleCollider component = base.gameObject.GetComponent<CapsuleCollider>();
        if (component != null)
        {
            center = component.center;
            radius = component.radius;
            height = component.height;
        }
        else
        {
            center = new Vector3(0f, 1f, 0f);
            radius = 0.3f;
            height = 2f;
        }
        UnityEngine.Object.Destroy(base.gameObject.GetComponent<Rigidbody>());
        UnityEngine.Object.Destroy(component);
        this.controller = base.gameObject.GetComponent<CharacterController>();
        this.controller.center = center;
        this.controller.radius = radius;
        this.controller.height = height - 0.16f;
        this.controller.slopeLimit = MovementData.singleton.slopeLimit;
        this.controller.stepOffset = 0.3f;
    }

    private void CalculateForwardAndClamp(float movementSpeed, ref Vector3 movementDelta)
    {
        if (!(this.forwardSMA.Average == 0f))
        {
            Vector3 vector = (Vector3) (this.fixedRotation * Vector3.forward);
            movementDelta = (Vector3) (movementDelta + (((vector * movementSpeed) * this.forwardSMA.Average) * Time.fixedDeltaTime));
            movementDelta = Vector3.ClampMagnitude(movementDelta, movementSpeed * Time.fixedDeltaTime);
        }
    }

    private void CalculateRotation(float rotateSpeed)
    {
        float y = this.fixedRotation.eulerAngles.y;
        float naN = float.NaN;
        bool turning = false;
        float f = Mathf.DeltaAngle(y, this.yawTarget);
        float num4 = Mathf.Abs(f);
        if (num4 >= 1f)
        {
            naN = (rotateSpeed * Time.fixedDeltaTime) * Mathf.Sign(f);
            if ((Mathf.Abs(naN) > num4) || ((this.steeringMode == SteeringMode.MOUSELOOK) && this.hasMoveInput))
            {
                naN = f;
            }
            turning = true;
        }
        if (!(!turning || debugNoMovement))
        {
            this.fixedRotation.eulerAngles = new Vector3(0f, y + naN, 0f);
        }
        if (!turning)
        {
            this.rotate = 0f;
        }
        base.anim.ProcessTurn(turning, base.transform, this.rotate, this.yawTarget, Mathf.Abs(naN));
    }

    private void CalculateSlide(ref Vector3 movementDelta)
    {
        if (((base.currentJumpState == BaseMotion.JumpState.NONE) && this.TooSteep()) && this.controller.isGrounded)
        {
            this.slideDuration += Time.fixedDeltaTime;
            Vector3 vector3 = new Vector3(this.groundNormal.x, 0f, this.groundNormal.z);
            Vector3 normalized = vector3.normalized;
            Vector3 vector2 = Vector3.Project(movementDelta, normalized);
            if (this.slideDuration > 0.3f)
            {
                normalized = (Vector3) ((normalized * Time.fixedDeltaTime) * MovementData.singleton.slideSpeed);
            }
            else
            {
                normalized = (Vector3) (normalized * Time.fixedDeltaTime);
            }
            movementDelta = (normalized + vector2) + (movementDelta - vector2);
            movementDelta.y -= 12f * Time.fixedDeltaTime;
        }
        else
        {
            this.slideDuration = 0f;
        }
    }

    private void CalculateStrafe(float movementSpeed, ref Vector3 movementDelta)
    {
        if (!(this.strafeSMA.Average == 0f))
        {
            Vector3 vector = (Vector3) (this.fixedRotation * Vector3.right);
            movementDelta = (Vector3) (movementDelta + (((vector * this.strafeSMA.Average) * movementSpeed) * Time.fixedDeltaTime));
        }
    }

    public void CommandEvent(string[] command, EntityId playerEntityId)
    {
        this.jump = true;
        base.debugUserInput[3, 1] = this.jump;
    }

    public void DoChargeAnim(EntityId entityId, float speed, float maxDistace, float duration)
    {
        this.preemptMovement = Combat.AnimType.Charge;
        this.chargeTarget = EntityCore.GetGameObjectByEntityId(ref entityId);
        this.forcedMoveSpeed = speed;
        this.chargeDistanceRemaining = maxDistace;
        this.prevPosition = base.transform.position;
        this.forcedMoveEndTime = Time.time + duration;
        if (base.movementChanged != null)
        {
            base.movementChanged(base.gameObject, Movement.MovementType.ChargeStart);
        }
        this.forcedMoveEndType = Movement.MovementType.ChargeEnd;
    }

    private void DoForcedMovementAnim(BaseMotion.AnimCue animCue)
    {
        this.preemptMovement = animCue.type;
        float time = Time.time;
        float num2 = 0f;
        if (animCue.type == Combat.AnimType.Knockback)
        {
            num2 = 0.25f;
            this.forcedMoveOrigin = animCue.originPosition;
            if (base.movementChanged != null)
            {
                base.movementChanged(base.gameObject, Movement.MovementType.KnockbackStart);
            }
            this.forcedMoveEndType = Movement.MovementType.KnockbackEnd;
        }
        else if (animCue.type == Combat.AnimType.Evade)
        {
            num2 = 0.25f;
            GameObject selectedTarget = Targeting.selectedTarget;
            this.forcedMoveOrigin = (selectedTarget == null) ? GConst.VECTOR3_INVALID : selectedTarget.transform.position;
            if (base.movementChanged != null)
            {
                base.movementChanged(base.gameObject, Movement.MovementType.EvadeStart);
            }
            this.forcedMoveEndType = Movement.MovementType.EvadeEnd;
        }
        else
        {
            GLog.Log(new object[] { animCue.type + " not yet supported." });
            return;
        }
        this.forcedMoveEndTime = time + num2;
        this.forcedMoveSpeed = animCue.amount / num2;
    }

    public override void DoUnconsciousAnim(bool isUnconscious)
    {
        base.DoUnconsciousAnim(isUnconscious);
        if (isUnconscious)
        {
            base.positionLocked |= BaseMotion.PositionLock.Unconscious;
        }
        else
        {
            base.positionLocked &= ~BaseMotion.PositionLock.Unconscious;
        }
    }

    private void ForceSteering(float forward_, float rotate_, float strafe_, bool jump_)
    {
        this.keyboardForward = forward_;
        this.keyboardRotate = rotate_;
        this.keyboardStrafe = strafe_;
        this.steeringMode = SteeringMode.KEYBOARD;
        this.mouseForwardValid = false;
        this.jump = jump_;
        this.yawTarget = this.fixedRotation.eulerAngles.y;
    }

    private float GetDeltaY()
    {
        float a = 0f;
        bool flag = true;
        if (base.currentJumpState != BaseMotion.JumpState.NONE)
        {
            if (((base.jumpStartTime + 0.25f) > Time.time) || (base.transform.position.y > this.jumpStartY))
            {
                a = this.verticalSpeed;
                this.verticalSpeed += MovementData.singleton.jumpGravity;
                flag = false;
            }
        }
        else if (this.controller.isGrounded)
        {
            this.verticalSpeed = 0f;
        }
        if (flag)
        {
            this.verticalSpeed += MovementData.singleton.normalGravity;
            a = this.verticalSpeed;
        }
        return (Mathf.Max(a, MovementData.singleton.terminalVelocity) * Time.fixedDeltaTime);
    }

    public bool IsMoving(bool ignoreLock = false)
    {
        if (!(ignoreLock || (base.positionLocked == BaseMotion.PositionLock.None)))
        {
            return false;
        }
        return (((((this.keyboardForward != 0f) || (this.keyboardRotate != 0f)) || ((this.keyboardStrafe != 0f) || this.jump)) || (this.mouseForwardValid && (this.mouseForward != 0f))) || (this.steeringMode == SteeringMode.MOUSELOOK));
    }

    public void LockAtPosition(Vector3 position, Vector3 lookAtTarget, BaseMotion.PositionLock posLock = 0x100)
    {
        Debug.Log("locking position at: " + position);
        base.transform.position = position;
        base.transform.LookAt(lookAtTarget);
        this.fixedRotation = base.transform.rotation;
        base.positionLocked |= posLock;
    }

    public void LockPosition(BaseMotion.PositionLock posLock = 0x100, string reason = "Cannot move until interaction window is closed.")
    {
        base.positionLocked |= posLock;
        this.lockReason = reason;
        this.lastLockNotifyTime = Time.time;
    }

    private void NotifyPlayerLock(bool isMoving)
    {
        if (isMoving && (Time.time > (this.lastLockNotifyTime + 2.5f)))
        {
            this.lastLockNotifyTime = Time.time;
            UIClient.DisplayOverheadOrChat(ChatClient.ERROR_COLOR, this.lockReason);
        }
    }

    public override void OnAnimatorMove()
    {
        float time = Time.time;
        if (base.attackAnim != null)
        {
            base.ProcessAttack(time, base.attackAnimStart, ref this.attackAnimEnd);
        }
        float t = (time - this.prevTime) / (this.fixedTime - this.prevTime);
        base.transform.rotation = Quaternion.Lerp(this.prevRotation, this.fixedRotation, t);
        base.OnAnimatorMove();
        CombatVars playerCombatVars = CombatClient.playerCombatVars;
        if (playerCombatVars != null)
        {
            if (base.currentJumpState == BaseMotion.JumpState.NONE)
            {
                playerCombatVars.jumpType = CombatVars.JumpType.NONE;
            }
            else
            {
                playerCombatVars.jumpType = CombatVars.JumpType.JUMPING;
            }
        }
    }

    private void OnControllerColliderHit(ControllerColliderHit hit)
    {
        this.groundNormal = hit.normal;
    }

    public override void OnDestroy()
    {
        base.OnDestroy();
        if (singleton == this)
        {
            singleton = null;
        }
    }

    protected override void ProcessAnimCues(float time)
    {
        for (int i = 0; i < base.animsToDo.Length; i++)
        {
            if ((base.animsToDo[i] != null) && (base.animsToDo[i].startTime <= time))
            {
                BaseMotion.AnimCue animCue = base.animsToDo[i];
                if ((animCue.type == Combat.AnimType.Knockback) || (animCue.type == Combat.AnimType.Evade))
                {
                    this.DoForcedMovementAnim(animCue);
                }
                else if (animCue.type == Combat.AnimType.Charge)
                {
                    this.DoChargeAnim(CombatClient.currentFeat.targetEntityId, animCue.amount, animCue.amount, 1f);
                }
            }
        }
        base.ProcessAnimCues(time);
    }

    private void ProcessCharge()
    {
        Vector3 zero = Vector3.zero;
        this.chargeDistanceRemaining -= Vector3.Distance(base.transform.position, this.prevPosition);
        this.prevPosition = base.transform.position;
        if (((this.forcedMoveEndTime <= Time.time) || (this.chargeDistanceRemaining <= 0f)) || ((this.chargeTarget != null) && (Vector3.Distance(base.transform.position, this.chargeTarget.transform.position) <= CombatData.singleton.closeRange)))
        {
            this.ResetCharge();
        }
        else
        {
            if (this.chargeTarget != null)
            {
                base.transform.LookAt(this.chargeTarget.transform);
                this.prevRotation = base.transform.rotation;
                this.fixedRotation = base.transform.rotation;
            }
            this.anim_speed = this.forcedMoveSpeed;
            this.CalculateForwardAndClamp(this.forcedMoveSpeed, ref zero);
            this.CalculateSlide(ref zero);
            zero.y = this.GetDeltaY();
            this.controller.Move(zero);
        }
    }

    private void ProcessForcedMovement()
    {
        if (this.forcedMoveEndTime <= Time.time)
        {
            this.ResetForcedMovement();
        }
        else
        {
            Vector3 zero = Vector3.zero;
            if (this.forcedMoveOrigin != GConst.VECTOR3_INVALID)
            {
                base.transform.LookAt(this.forcedMoveOrigin);
                this.prevRotation = base.transform.rotation;
                this.fixedRotation = base.transform.rotation;
            }
            this.anim_speed = this.forcedMoveSpeed;
            this.CalculateForwardAndClamp(this.forcedMoveSpeed, ref zero);
            this.CalculateSlide(ref zero);
            zero.y = this.GetDeltaY();
            this.controller.Move(zero);
        }
    }

    private void ProcessGather()
    {
        if (base.gathering)
        {
            if ((this.forward != 0f) && (this.strafe != 0f))
            {
                base.ResetGather();
            }
            if (CombatClient.currentFeat.featId != 0)
            {
                base.ResetGather();
            }
        }
    }

    private void ProcessInput()
    {
        if (this.mouseForwardValid && (this.keyboardForward > -0.1f))
        {
            this.forward = this.mouseForward;
        }
        else
        {
            this.forward = this.keyboardForward;
        }
        this.hasMoveInput = ((this.forward != 0f) || (this.keyboardRotate != 0f)) || !(this.keyboardStrafe == 0f);
        switch (this.steeringMode)
        {
            case SteeringMode.KEYBOARD:
                this.yawTarget += this.keyboardRotate * 3f;
                break;

            case SteeringMode.MOUSELOOK:
                this.yawTarget = this.cameraYaw;
                break;

            case SteeringMode.FREELOOK:
                this.yawTarget += this.keyboardRotate * 3f;
                break;
        }
        if ((this.steeringMode == SteeringMode.MOUSELOOK) || this.hasMoveInput)
        {
            float f = Mathf.DeltaAngle(this.fixedRotation.eulerAngles.y, this.yawTarget);
            if (Mathf.Abs(f) < 1f)
            {
                this.rotate = 0f;
            }
            else
            {
                this.rotate = Mathf.Sign(f);
            }
        }
        this.strafe = this.keyboardStrafe;
        this.forwardSMA.Update(this.forward);
        this.rotateSMA.Update(this.rotate);
        this.strafeSMA.Update(this.strafe);
    }

    private void ProcessMovement()
    {
        Vector3 zero = Vector3.zero;
        this.fixedTime = Time.fixedTime + Time.fixedDeltaTime;
        CombatVars.MovementType speedToggle = this.speedToggle;
        if (this.forward < -0.1f)
        {
            speedToggle = CombatVars.MovementType.WALKBACK;
        }
        else if ((this.forward == 0f) && (this.strafe == 0f))
        {
            speedToggle = CombatVars.MovementType.IDLE;
        }
        if (speedToggle != this.prevMoveType)
        {
            if (base.movementChanged != null)
            {
                base.movementChanged(base.gameObject, Movement.MovementType.MoveChanged);
            }
            this.prevMoveType = speedToggle;
        }
        float walkSpeed = 1f;
        float rotateSpeed = 0f;
        switch (speedToggle)
        {
            case CombatVars.MovementType.IDLE:
            case CombatVars.MovementType.WALK:
                walkSpeed = CombatData.singleton.walkSpeed;
                rotateSpeed = MovementData.singleton.rotateSpeed;
                break;

            case CombatVars.MovementType.WALKBACK:
                walkSpeed = CombatData.singleton.walkBackSpeed;
                rotateSpeed = MovementData.singleton.rotateSpeed;
                break;

            case CombatVars.MovementType.HUSTLE:
                walkSpeed = CombatData.singleton.hustleSpeed;
                rotateSpeed = MovementData.singleton.runRotateSpeed;
                break;

            case CombatVars.MovementType.RUN:
                walkSpeed = CombatData.singleton.runSpeed;
                rotateSpeed = MovementData.singleton.runRotateSpeed;
                break;
        }
        float newValue = CombatData.singleton.baseMoveSpeed * walkSpeed;
        CombatVars playerCombatVars = CombatClient.playerCombatVars;
        if (!(debugSpeed || (playerCombatVars == null)))
        {
            newValue = playerCombatVars.GetMovementSpeed(speedToggle);
        }
        this.speedSMA.Update(newValue);
        this.anim_speed = newValue;
        this.CalculateRotation(rotateSpeed);
        this.CalculateStrafe(this.speedSMA.Average, ref zero);
        this.CalculateForwardAndClamp(this.speedSMA.Average, ref zero);
        this.StartJumpCheck();
        zero.y = this.GetDeltaY();
        this.CalculateSlide(ref zero);
        if (!debugNoMovement)
        {
            this.controller.Move(zero);
        }
    }

    public void QueueAnim(Combat.AnimType type, float amount, Vector3 originPosition)
    {
        SparseArray.Add<BaseMotion.AnimCue>(ref this.animsToDo, new BaseMotion.AnimCue(type, Time.time, amount, originPosition));
    }

    private void ResetCharge()
    {
        this.preemptMovement = Combat.AnimType.None;
        this.chargeTarget = null;
        this.forcedMoveSpeed = 0f;
        this.chargeDistanceRemaining = 0f;
        this.prevPosition = GConst.VECTOR3_INVALID;
        this.forcedMoveEndTime = 0f;
        if (base.movementChanged != null)
        {
            base.movementChanged(base.gameObject, this.forcedMoveEndType);
        }
        this.forcedMoveEndType = Movement.MovementType.None;
    }

    private void ResetForcedMovement()
    {
        this.preemptMovement = Combat.AnimType.None;
        this.forcedMoveEndTime = 0f;
        this.forcedMoveOrigin = GConst.VECTOR3_INVALID;
        this.forcedMoveSpeed = 0f;
        if (base.movementChanged != null)
        {
            base.movementChanged(base.gameObject, this.forcedMoveEndType);
        }
        this.forcedMoveEndType = Movement.MovementType.None;
    }

    public void SetMouseSteering(bool mouselooking_, bool freelooking_, float cameraYaw_, bool mouseForwardValid_, float mouseForward_)
    {
        this.steeringMode = mouselooking_ ? SteeringMode.MOUSELOOK : (freelooking_ ? SteeringMode.FREELOOK : SteeringMode.KEYBOARD);
        this.cameraYaw = cameraYaw_;
        this.mouseForwardValid = mouseForwardValid_;
        this.mouseForward = mouseForward_;
    }

    public void SetSteering(float forward_, float rotate_)
    {
        this.keyboardForward = forward_;
        this.keyboardRotate = rotate_;
    }

    public void SetStrafe(float strafe_)
    {
        this.keyboardStrafe = strafe_;
    }

    public override void Start()
    {
        base.Start();
        this.fixedRotation = base.transform.rotation;
        this.prevRotation = base.transform.rotation;
        this.fixedTime = Time.time;
        this.TryInitCommand();
        this.forwardSMA = new SimpleMovingAverage(Mathf.RoundToInt(0.25f / Time.fixedDeltaTime));
        this.rotateSMA = new SimpleMovingAverage(Mathf.RoundToInt(0.25f / Time.fixedDeltaTime));
        this.strafeSMA = new SimpleMovingAverage(Mathf.RoundToInt(0.25f / Time.fixedDeltaTime));
        this.speedSMA = new SimpleMovingAverage(Mathf.RoundToInt(0.5f / Time.fixedDeltaTime));
        base.debugUserInput = new object[4, 2];
        base.debugUserInput[0, 0] = " Forward:";
        base.debugUserInput[1, 0] = " Rotate:";
        base.debugUserInput[2, 0] = " Strafe:";
        base.debugUserInput[3, 0] = " Jump:";
    }

    private void StartJumpCheck()
    {
        if (this.jump)
        {
            if (this.jumpRequestTimeout == float.PositiveInfinity)
            {
                this.jumpRequestTimeout = Time.time + 0.5f;
            }
            if (!((((base.HeightAboveGroundCollider() >= 0.25f) || (base.currentJumpState != BaseMotion.JumpState.NONE)) || !base.anim.AbleToJump()) || this.TooSteep()))
            {
                base.currentJumpState = BaseMotion.JumpState.LIFT_OFF;
                base.jumpStartTime = Time.time;
                this.jumpStartY = base.transform.position.y;
                this.verticalSpeed = MovementData.singleton.jumpImpulse;
                this.jump = false;
                this.jumpRequestTimeout = float.PositiveInfinity;
            }
            else if (Time.time > this.jumpRequestTimeout)
            {
                this.jump = false;
                this.jumpRequestTimeout = float.PositiveInfinity;
            }
        }
    }

    public bool SyncFixedUpdate()
    {
        if (this.TryInitCommand())
        {
            this.prevRotation = this.fixedRotation;
            this.prevTime = this.fixedTime;
            this.ProcessAnimCues(Time.time);
            if (base.crowdControlAnim > 0)
            {
                base.ProcessCrowdControl(Time.time, base.crowdControlAnimStart, base.crowdControlAnimEnd);
            }
            if (base.gatherAnimEnd > 0f)
            {
                base.ProcessGather(Time.time, base.gatherAnimStart, base.gatherAnimEnd);
            }
            if (base.positionLocked != BaseMotion.PositionLock.None)
            {
                bool isMoving = this.IsMoving(true);
                this.ForceSteering(0f, 0f, 0f, false);
                this.ProcessInput();
                this.ProcessMovement();
                if (base.positionLocked >= BaseMotion.PositionLock.External)
                {
                    this.NotifyPlayerLock(isMoving);
                }
            }
            else if (this.preemptMovement == Combat.AnimType.Charge)
            {
                this.ForceSteering(1f, 0f, 0f, false);
                this.ProcessInput();
                this.ProcessCharge();
            }
            else if ((this.preemptMovement == Combat.AnimType.Knockback) || (this.preemptMovement == Combat.AnimType.Evade))
            {
                this.ForceSteering(-1f, 0f, 0f, false);
                this.ProcessInput();
                this.ProcessForcedMovement();
            }
            else
            {
                this.ProcessInput();
                this.ProcessMovement();
            }
            base.UpdateJump();
            base.ProcessStealth(false);
            base.debugUserInput[0, 1] = this.forward;
            base.debugUserInput[1, 1] = this.rotate;
            base.debugUserInput[2, 1] = this.strafe;
            base.debugUserInput[3, 1] = this.jump;
            base.anim.SetMovement(Mathf.Max(Mathf.Abs(this.forward), Mathf.Abs(this.strafe)) * this.anim_speed, this.forward * this.anim_speed, this.strafe * this.anim_speed, this.forward, this.strafe, this.rotate, this.forwardSMA.Average, this.strafeSMA.Average, this.rotateSMA.Average);
        }
        return true;
    }

    public void Teleport(Vector3 position, Quaternion rotation)
    {
        base.transform.position = position;
        base.transform.rotation = rotation;
        this.fixedRotation = rotation;
        this.fixedTime = Time.time;
        Targeting.Untarget();
        CustomCamera.singleton.OnTeleport();
    }

    private bool TooSteep()
    {
        return (this.groundNormal.y < Mathf.Cos(this.controller.slopeLimit * 0.01745329f));
    }

    private bool TryInitCommand()
    {
        if (!(this.commandInit || (ClientInputManager.singleton == null)))
        {
            CommandClient.DelayedRegisterCommand("jump", new CommandCore.CommandDelegate(singleton.CommandEvent), CommandCore.PermissionLevel.USER, CommandCore.Options.NONE | CommandCore.Options.OVERWRITE, null);
            this.commandInit = true;
        }
        return this.commandInit;
    }

    public void UnlockPosition(BaseMotion.PositionLock posLock = 0x100)
    {
        base.positionLocked &= ~posLock;
    }

    private enum SteeringMode
    {
        KEYBOARD,
        MOUSELOOK,
        FREELOOK
    }
}

