﻿using GNGUI;
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;

public class CharacterSelectionGui : MonoBehaviour
{
    private Dictionary<uint, PlayerInfo> availableCharacters = new Dictionary<uint, PlayerInfo>();
    private DisabledButton changeTrainingButton;
    private UILabel changeTrainingButtonLabel;
    private Dictionary<uint, CharacterListItem> characterRows = new Dictionary<uint, CharacterListItem>();
    private Dictionary<uint, GameObject> characters = new Dictionary<uint, GameObject>();
    public static Color COLOR_CHAR_DISABLED = new Color(0.5019608f, 0.5019608f, 0.5019608f);
    public static Color COLOR_CHAR_HOVERED = new Color(0.9294118f, 0.9176471f, 0.8627451f);
    public static Color COLOR_CHAR_SELECTED = new Color(0.9411765f, 0.8901961f, 0.6588235f);
    public static Color COLOR_CHAR_UNSELECTED = new Color(0.5019608f, 0.5019608f, 0.5019608f);
    public static Color COLOR_TEXT_DISABLED = new Color(0.5019608f, 0.5019608f, 0.5019608f);
    public static Color COLOR_TEXT_NEGATIVE = new Color(0.9607843f, 0.4f, 0.2078431f);
    public static Color COLOR_TEXT_POSITIVE = new Color(0.9411765f, 0.8901961f, 0.6588235f);
    private GameObject currentCharacter = null;
    private PlayerInfo[] delayedConfigureChars = null;
    private bool displayTrainingButtons;
    private DisabledButton extraCreateButton;
    private bool finalizedLoading = false;
    private UILabel infoLabel;
    private bool loaded = false;
    private Transform parentTransform;
    private DisabledButton playButton;
    private uint selectedPlayerId = 0;
    public static CharacterSelectionGui singleton;
    private GameObject spawnPoint;
    private const string TRAIN_BUTTON_TEXT_CANCEL = "Cancel";
    private const string TRAIN_BUTTON_TEXT_NORMAL = "Set Training";
    private Queue<CharacterListItem> unusedRows;

    public void AcceptTraining(GameObject go)
    {
        string errorText = null;
        string str2;
        this.changeTrainingButtonLabel.text = "Set Training";
        PlayerLoginClient.CheckTrainingPlayers(out errorText, out str2);
        this.displayTrainingButtons = false;
        foreach (KeyValuePair<uint, CharacterListItem> pair in this.characterRows)
        {
            pair.Value.UpdateButtons(this.displayTrainingButtons);
        }
        if (string.IsNullOrEmpty(errorText))
        {
            PlayerLoginClient.UpdateTrainingPlayers();
        }
        TwinWarningPopup.Hide();
        this.UpdatePlayButton();
    }

    public void AssignObjects(Transform inParent, GameObject inSpawn)
    {
        this.parentTransform = inParent;
        this.spawnPoint = inSpawn;
    }

    public void Awake()
    {
        singleton = this;
    }

    private void ChangeSelection()
    {
        this.SetError(null);
        if (this.currentCharacter != null)
        {
            this.currentCharacter.SetActive(false);
        }
        PlayerInfo info = null;
        if (this.availableCharacters.TryGetValue(this.selectedPlayerId, out info) && !info.isDeleted)
        {
            foreach (KeyValuePair<uint, CharacterListItem> pair in this.characterRows)
            {
                bool isSelected = this.selectedPlayerId == pair.Value.playerId;
                pair.Value.Select(isSelected);
            }
            GameObject obj2 = null;
            if (this.characters.TryGetValue(this.selectedPlayerId, out obj2))
            {
                this.currentCharacter = obj2;
                this.currentCharacter.SetActive(true);
            }
            else
            {
                IEnumerable<EquipmentAsset> equipment = null;
                if (info.bodySlots != null)
                {
                    equipment = InventoryClient.GetAllEquippedAssets(info.bodySlots, info.playerDefnId);
                }
                this.currentCharacter = EntityLoadClient.CreateCompleteCharacter(info.playerDefnId, ((byte) (info.flags & EntityFlags.GmSuit)) == 2, info.physique, equipment, GConst.CreateType.TEST_EMPTY_ENTITY, this.parentTransform, this.spawnPoint.transform.position, this.spawnPoint.transform.rotation, info.playerName);
                this.currentCharacter.AddComponent<IdleAnimator>();
                this.characters[this.selectedPlayerId] = this.currentCharacter;
            }
        }
        this.UpdatePlayButton();
    }

    public void ConfigureFields(PlayerInfo[] inAvailableCharacters)
    {
        if (!this.loaded)
        {
            this.delayedConfigureChars = inAvailableCharacters;
        }
        else
        {
            CharacterListItem item;
            uint @int = (uint) PlayerPrefs.GetInt("player");
            if (this.availableCharacters.Count > 0)
            {
                @int = this.selectedPlayerId;
                this.availableCharacters.Clear();
            }
            foreach (KeyValuePair<uint, CharacterListItem> pair in this.characterRows)
            {
                pair.Value.ResetColors();
            }
            foreach (PlayerInfo info in inAvailableCharacters)
            {
                if (this.characterRows.TryGetValue(info.playerId, out item))
                {
                    item.Assign(info, false);
                    this.availableCharacters.Add(info.playerId, info);
                }
                else if (this.unusedRows.Count > 0)
                {
                    item = this.unusedRows.Dequeue();
                    item.Assign(info, false);
                    this.characterRows.Add(info.playerId, item);
                    this.availableCharacters.Add(info.playerId, info);
                }
                else
                {
                    GLog.LogError(new object[] { "Insufficient rows, unable to display player: ", info.playerName });
                }
            }
            bool showCreateButton = true;
            foreach (CharacterListItem item2 in this.unusedRows)
            {
                item2.Assign(null, showCreateButton);
                showCreateButton = false;
            }
            if (!this.availableCharacters.ContainsKey(@int) || !this.characterRows.TryGetValue(@int, out item))
            {
                foreach (KeyValuePair<uint, PlayerInfo> pair2 in this.availableCharacters)
                {
                    if (!pair2.Value.isDeleted)
                    {
                        @int = this.characterRows[pair2.Key].Select(true);
                        break;
                    }
                }
            }
            foreach (KeyValuePair<uint, CharacterListItem> pair in this.characterRows)
            {
                pair.Value.Select(!pair.Value.IsDeleted() && (pair.Value.playerId == @int));
            }
            this.selectedPlayerId = @int;
            this.ChangeSelection();
        }
    }

    public static void CreateCharacter(GameObject go)
    {
        CharacterManagementGui.singleton.TryCharacterCreation();
    }

    public void DeleteCharacter(uint playerId)
    {
        if (this.availableCharacters.ContainsKey(playerId))
        {
            CharacterListItem item;
            bool flag = this.selectedPlayerId == playerId;
            bool flag2 = false;
            if (this.characterRows.TryGetValue(playerId, out item))
            {
                item.Delete(playerId, true);
            }
            foreach (KeyValuePair<uint, CharacterListItem> pair in this.characterRows)
            {
                item = pair.Value;
                if (flag)
                {
                    if (!(item.IsDeleted() || flag2))
                    {
                        this.selectedPlayerId = item.Select(true);
                        flag2 = true;
                        this.ChangeSelection();
                    }
                    else
                    {
                        item.Select(false);
                    }
                }
            }
            if (!(!flag || flag2))
            {
                this.selectedPlayerId = 0;
            }
            PlayerLoginClient.CharacterDeleted(playerId);
            if (this.characterRows.Count == 0)
            {
                CharacterManagementGui.singleton.TryCharacterCreation();
            }
        }
        this.UpdatePlayButton();
    }

    public void DisableCharacterModel()
    {
        if (this.currentCharacter != null)
        {
            this.currentCharacter.SetActive(false);
        }
    }

    public void EnableGui()
    {
        LoadingMessageGUI.UpdateLoadingStatus(false, "Client loading complete.");
        NGUITools.SetActive(base.gameObject, true);
        this.ChangeSelection();
        UIEventListener listener1 = UIEventListener.Get(this.playButton.gameObject);
        listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.PlayGame));
    }

    public void FixedUpdate()
    {
        if ((!this.finalizedLoading && this.loaded) && (this.unusedRows.Count == 3))
        {
            foreach (CharacterListItem item in this.unusedRows)
            {
                if (!item.loaded)
                {
                    return;
                }
            }
            if (this.delayedConfigureChars != null)
            {
                this.ConfigureFields(this.delayedConfigureChars);
                this.delayedConfigureChars = null;
                this.ChangeSelection();
                this.finalizedLoading = true;
            }
        }
    }

    public bool LoadingTickFinished()
    {
        COLOR_TEXT_POSITIVE = ColorData.GetColorByName("button_text_positive", true);
        COLOR_TEXT_NEGATIVE = ColorData.GetColorByName("button_text_negative", true);
        COLOR_TEXT_DISABLED = ColorData.GetColorByName("button_text_disabled", true);
        COLOR_CHAR_SELECTED = ColorData.GetColorByName("charSelect_char_selected", true);
        COLOR_CHAR_UNSELECTED = ColorData.GetColorByName("charSelect_char_unselected", true);
        COLOR_CHAR_DISABLED = ColorData.GetColorByName("charSelect_char_disabled", true);
        COLOR_CHAR_HOVERED = ColorData.GetColorByName("charSelect_char_hovered", true);
        this.loaded = true;
        return true;
    }

    public int NumCharacters(bool includeDeleted)
    {
        int num = 0;
        foreach (KeyValuePair<uint, CharacterListItem> pair in this.characterRows)
        {
            if ((pair.Value.playerId != 0) && (includeDeleted || !pair.Value.IsDeleted()))
            {
                num++;
            }
        }
        return num;
    }

    public void OnDestroy()
    {
        singleton = null;
    }

    public void OnTrainingToggle()
    {
        this.changeTrainingButtonLabel.text = "Set Training";
        this.UpdatePlayButton();
    }

    public void PlayGame(bool forceStart)
    {
        if (forceStart || (this.availableCharacters.ContainsKey(this.selectedPlayerId) && !this.playButton.disabled))
        {
            this.SetError(null);
            NGUITools.SetActive(base.gameObject, false);
            LoadingMessageGUI.UpdateLoadingStatus(true, "Connecting to Server...");
            PlayerLoginClient.ClientSelectCharacter(this.selectedPlayerId);
        }
    }

    private void PlayGame(GameObject go)
    {
        this.PlayGame(false);
    }

    public void SelectCharacter(uint playerId)
    {
        this.SetError(null);
        this.selectedPlayerId = playerId;
        this.ChangeSelection();
    }

    public void SetError(string message = null)
    {
        bool flag = false;
        if (message != null)
        {
            this.infoLabel.text = message;
        }
        else
        {
            this.infoLabel.text = string.Empty;
            foreach (KeyValuePair<uint, PlayerInfo> pair in this.availableCharacters)
            {
                flag |= pair.Value.isTraining;
            }
            if (!(flag || (this.availableCharacters.Count <= 0)))
            {
                this.infoLabel.text = "Not training!";
            }
        }
    }

    public void Start()
    {
        CharacterSelectTick.charSelectLoadFinish = new GUtil.BoolFilterDelegate(this.LoadingTickFinished);
        this.unusedRows = new Queue<CharacterListItem>(base.GetComponentsInChildren<CharacterListItem>());
        if (this.unusedRows.Count != 3)
        {
            GLog.LogError(new object[] { "Character list", "(" + this.unusedRows.Count + ")", "must be same as ACCOUNT_CHARACTER_LIMIT(" + ((ushort) 3) + ")!" });
        }
        foreach (UILabel label in base.GetComponentsInChildren<UILabel>())
        {
            if (label.name == "InfoLabel")
            {
                this.infoLabel = label;
            }
        }
        foreach (DisabledButton button in base.GetComponentsInChildren<DisabledButton>())
        {
            if (button.name == "PlayButton")
            {
                this.playButton = button;
            }
            else if (button.name == "ExtraCreateButton")
            {
                this.extraCreateButton = button;
            }
            else if (button.name == "ChangeTrainingButton")
            {
                this.changeTrainingButton = button;
                this.changeTrainingButtonLabel = this.changeTrainingButton.GetComponentInChildren<UILabel>();
                this.changeTrainingButtonLabel.text = "Set Training";
            }
        }
        GuiHelper.GuiAssertNotNull("Could not find needed children.", new object[] { this.infoLabel, this.playButton, this.extraCreateButton, this.changeTrainingButton, this.changeTrainingButtonLabel });
        NGUITools.SetActive(this.infoLabel.gameObject, true);
        this.infoLabel.color = Color.red;
        this.playButton.Assign(new string[] { "button_charselect_enterworld_di", "button_charselect_enterworld_di", "button_charselect_enterworld_di" }, new string[] { "button_charselect_enterworld_de", "button_charselect_enterworld_mo", "button_charselect_enterworld_cl" }, COLOR_TEXT_DISABLED, COLOR_TEXT_POSITIVE);
        this.changeTrainingButton.Assign(new string[] { "button_back_small_wide_di", "button_back_small_wide_di", "button_back_small_wide_di" }, new string[] { "button_back_small_wide_good_de", "button_back_small_wide_good_mo", "button_back_small_wide_good_cl" }, COLOR_TEXT_DISABLED, COLOR_TEXT_POSITIVE);
        this.extraCreateButton.Assign(new string[] { "button_back_small_wide_di", "button_back_small_wide_di", "button_back_small_wide_di" }, new string[] { "button_back_small_wide_good_de", "button_back_small_wide_good_mo", "button_back_small_wide_good_cl" }, COLOR_TEXT_DISABLED, COLOR_TEXT_POSITIVE);
        this.extraCreateButton.IsDisabled(false);
        NGUITools.SetActive(this.extraCreateButton.gameObject, false);
        UIEventListener listener1 = UIEventListener.Get(this.extraCreateButton.gameObject);
        listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(CharacterSelectionGui.CreateCharacter));
        UIEventListener listener2 = UIEventListener.Get(this.changeTrainingButton.gameObject);
        listener2.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener2.onClick, new UIEventListener.VoidDelegate(this.ToggleTrainingButtons));
        NGUITools.SetActive(base.gameObject, false);
    }

    private void ToggleTrainingButtons(GameObject go)
    {
        if ((!this.changeTrainingButton.disabled && (this.availableCharacters.Count > 0)) && (this.NumCharacters(false) > 0))
        {
            string errorText = null;
            string twinWarning = null;
            TwinWarningPopup.Hide();
            if (this.displayTrainingButtons)
            {
                PlayerLoginClient.CheckTrainingPlayers(out errorText, out twinWarning);
                if (!(string.IsNullOrEmpty(errorText) || !(this.changeTrainingButtonLabel.text == "Set Training")))
                {
                    this.SetError(errorText);
                    this.changeTrainingButtonLabel.text = "Cancel";
                    return;
                }
                if (!(string.IsNullOrEmpty(errorText) || !(this.changeTrainingButtonLabel.text == "Cancel")))
                {
                    this.changeTrainingButtonLabel.text = "Set Training";
                }
                else if (!string.IsNullOrEmpty(twinWarning))
                {
                    TwinWarningPopup.Show(twinWarning);
                    return;
                }
            }
            this.SetError(errorText);
            this.displayTrainingButtons = !this.displayTrainingButtons;
            foreach (KeyValuePair<uint, CharacterListItem> pair in this.characterRows)
            {
                pair.Value.UpdateButtons(this.displayTrainingButtons);
            }
            if (!(this.displayTrainingButtons || !string.IsNullOrEmpty(errorText)))
            {
                PlayerLoginClient.UpdateTrainingPlayers();
            }
        }
        this.UpdatePlayButton();
    }

    public void TwinCancel(GameObject go)
    {
        this.changeTrainingButtonLabel.text = "Set Training";
        this.displayTrainingButtons = false;
        foreach (KeyValuePair<uint, CharacterListItem> pair in this.characterRows)
        {
            pair.Value.UpdateButtons(this.displayTrainingButtons);
        }
        TwinWarningPopup.Hide();
        this.UpdatePlayButton();
    }

    public void UndeleteCharacter(uint playerId)
    {
        CharacterListItem item;
        bool flag = false;
        if (this.characterRows.TryGetValue(playerId, out item))
        {
            item.Delete(playerId, false);
            flag = item.IsDeleted() || flag;
        }
        NGUITools.SetActive(this.extraCreateButton.gameObject, flag && (this.unusedRows.Count == 0));
        PlayerLoginClient.CharacterUndeleted(playerId);
        this.UpdatePlayButton();
    }

    public void UpdatePlayButton()
    {
        bool flag = false;
        foreach (KeyValuePair<uint, PlayerInfo> pair in this.availableCharacters)
        {
            if (pair.Value.playerId == this.selectedPlayerId)
            {
                flag = true;
            }
        }
        this.playButton.IsDisabled(((this.displayTrainingButtons || !flag) || (this.availableCharacters.Count == 0)) || (this.NumCharacters(false) == 0));
        this.changeTrainingButton.IsDisabled((this.availableCharacters.Count == 0) || (this.NumCharacters(false) == 0));
    }
}

