﻿using GNetwork;
using GNGUI;
using System;
using UnityEngine;

public class TrainerUnavailableTabGui : WindowTabGui
{
    private bool needsRepositioning = false;

    public override void Awake()
    {
        base.Awake();
        base.tabSpriteName = "panel_trainer_header_unavailablefeats";
        base.prefabName = "TrainerListItem";
    }

    private TrainerListItem CreateTrainerListItem(FeatAdvancementData featAdvancement, byte featLevel)
    {
        TrainerListItem component = NGUITools.AddChild(base.gridList.gameObject, base.listItemPrefab).GetComponent<TrainerListItem>();
        component.Assign(featAdvancement, featLevel);
        return component;
    }

    public override void FilterClicked(GameObject filterGO)
    {
    }

    public override void HideTab()
    {
        base.HideTab();
        base.ClearListItems();
    }

    protected override void MakeListItems()
    {
        this.needsRepositioning = true;
        TrainerData2 trainer = TrainerData2.GetTrainer(TrainerWindowGui.singleton.trainerId);
        TrainerLevel[] levelArray = null;
        if (trainer != null)
        {
            levelArray = trainer.CompleteTrainerLevels(TrainerWindowGui.singleton.trainerLevel).ToArray();
        }
        if (levelArray == null)
        {
            base.ClearListItems();
        }
        else
        {
            int size = 0;
            foreach (TrainerLevel level in levelArray)
            {
                for (int i = 0; i < level.featAdvancementIds.Length; i++)
                {
                    TrainerListItem item = (base.displayedItems.Count > size) ? (base.displayedItems[size] as TrainerListItem) : null;
                    FeatAdvancementData featExpData = FeatAdvancementData.dataByFeatAdvancementId[level.featAdvancementIds[i]];
                    for (byte j = 1; j <= level.featLevels[i]; j = (byte) (j + 1))
                    {
                        AdvancementVars.FeatAvailability availability = EntityDataClient.owner.advancementVars.CanBuyFeatAtLevel(featExpData, j, GNetworkService.ServerUtc);
                        AdvancementVars.FeatAvailability availability2 = 0xfffd;
                        if ((((ushort) (availability & AdvancementVars.FeatAvailability.ALREADY_TRAINED)) == 0) && (((ushort) (availability & availability2)) != 0))
                        {
                            if (item != null)
                            {
                                item.Assign(featExpData, j);
                            }
                            else
                            {
                                base.displayedItems.Add(this.CreateTrainerListItem(featExpData, j));
                            }
                            size++;
                            break;
                        }
                    }
                }
            }
            base.ReduceListItemsToSize(size);
        }
    }

    public override void ShowTab()
    {
        this.MakeListItems();
        base.ShowTab();
    }

    public void Update()
    {
        if (this.needsRepositioning)
        {
            base.gridList.Reposition();
            for (int i = 0; i < base.displayedItems.Count; i++)
            {
                ((TrainerListItem) base.displayedItems[i]).Display();
            }
            this.needsRepositioning = false;
        }
    }
}

