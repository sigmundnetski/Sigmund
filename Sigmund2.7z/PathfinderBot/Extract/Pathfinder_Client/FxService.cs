﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public static class FxService
{
    private static ActiveFx[] active = new ActiveFx[100];
    public const float DEFAULT_RAY_LENGTH = 50f;
    private static Dictionary<string, UnityEngine.Object> fxPrefabs = new Dictionary<string, UnityEngine.Object>();
    private static Dictionary<string, Queue<GameObject>> pooledFxObjects = new Dictionary<string, Queue<GameObject>>();
    private static Transform pooledParent = null;

    private static void _InternalDoFx(List<AttackFxData> fxs, float _startTime, float validation, float interruption, float followThrough, Transform player, Transform target)
    {
        BipedMap playerMap = null;
        if (player != null)
        {
            playerMap = player.GetComponent<BipedMap>();
        }
        BipedMap targetMap = null;
        if (target != null)
        {
            targetMap = target.GetComponent<BipedMap>();
        }
        for (int i = 0; i < fxs.Count; i++)
        {
            Queue<GameObject> queue;
            AttackFxData data = fxs[i];
            GameObject obj2 = null;
            if (pooledFxObjects.TryGetValue(data.prefabName, out queue) && (queue.Count > 0))
            {
                obj2 = queue.Dequeue();
            }
            else if (fxPrefabs.ContainsKey(data.prefabName))
            {
                obj2 = (GameObject) UnityEngine.Object.Instantiate(fxPrefabs[data.prefabName]);
                obj2.name = data.prefabName;
                obj2.transform.parent = pooledParent;
                obj2.transform.localPosition = Vector3.zero;
            }
            else
            {
                GLog.LogError(new object[] { "Cannot load FX Prefab:", data.prefabName });
            }
            if (obj2 != null)
            {
                Transform objA = GetTransformFromData(data, player, playerMap, target, targetMap, data.startLocation, data.startOffset);
                Transform transform2 = GetTransformFromData(data, player, playerMap, target, targetMap, data.endLocation, data.endOffset);
                float num2 = 5f;
                if (!(object.ReferenceEquals(objA, null) || object.ReferenceEquals(transform2, null)))
                {
                    num2 = Vector3.Distance(objA.position, transform2.position);
                }
                float num3 = _startTime + data.stageDelay;
                if (data.stage > AttackFxData.FxAttackStage.VALIDATION)
                {
                    num3 += validation;
                }
                if (data.stage > AttackFxData.FxAttackStage.INTERRUPTION)
                {
                    num3 += interruption;
                }
                if (data.stage > AttackFxData.FxAttackStage.FOLLOWTHROUGH)
                {
                    num3 += followThrough;
                }
                float duration = 0f;
                if (data.speed > 0f)
                {
                    duration = num2 / data.speed;
                }
                else
                {
                    duration = data.duration;
                }
                float num5 = num3 + duration;
                if ((objA != null) && (transform2 != null))
                {
                    SparseArray.Add<ActiveFx>(ref active, new ActiveFx(data.id, data.fxStyle, num3, num5, objA, transform2, data.preserveOrientation, obj2));
                }
            }
        }
    }

    public static void ClearInstances()
    {
        foreach (KeyValuePair<string, Queue<GameObject>> pair in pooledFxObjects)
        {
            pair.Value.Clear();
        }
        pooledParent = null;
    }

    public static void DoFx(NonAttackFeatData feat, float startTime, Transform player, Transform target)
    {
        List<AttackFxData> list;
        if ((pooledParent != null) && (AttackFxData.fxByFeatId.TryGetValue(feat.id, out list) && (list.Count > 0)))
        {
            _InternalDoFx(list, startTime, 0f, 0f, feat.durationSec, player, target);
        }
    }

    public static void DoFx(OffensiveFeatData attack, float startTime, Transform player, Transform target)
    {
        if (pooledParent != null)
        {
            List<AttackFxData> list2;
            List<AttackFxData> second = new List<AttackFxData>();
            if (AttackFxData.fxByFeatId.TryGetValue(attack.id, out list2) && (list2.Count > 0))
            {
                second.AddRange(list2);
            }
            if (AttackFxData.fxByWeaponCategoryId.TryGetValue(attack.weaponCategoryId, out list2) && (list2.Count > 0))
            {
                second.AddRange(list2.Except<AttackFxData>(second));
            }
            if (second.Count > 0)
            {
                _InternalDoFx(second, startTime, attack.durationValidation, attack.durationInterruption, attack.durationFollowThrough, player, target);
            }
        }
    }

    public static bool ExtractBundles()
    {
        foreach (GameObject obj2 in BundleService.LoadAll<GameObject>(BundleConsts.FX_BUNDLE))
        {
            fxPrefabs[obj2.name.ToLower()] = obj2;
        }
        foreach (GameObject obj2 in BundleService.LoadAll<GameObject>(BundleConsts.AUDIO_BUNDLE))
        {
            fxPrefabs[obj2.name.ToLower()] = obj2;
        }
        return true;
    }

    private static Transform GetTransformFromData(AttackFxData data, Transform player, BipedMap playerMap, Transform target, BipedMap targetMap, AttackFxData.FxLocation loc, AttackFxData.FxSubLocation subLoc)
    {
        Transform transform = null;
        Transform transform2 = null;
        BipedMap map = null;
        switch (loc)
        {
            case AttackFxData.FxLocation.POSITION:
                transform2 = null;
                map = null;
                break;

            case AttackFxData.FxLocation.PLAYER:
                transform2 = player;
                map = playerMap;
                break;

            case AttackFxData.FxLocation.TARGET:
                transform2 = target;
                map = targetMap;
                break;

            default:
                transform2 = null;
                map = null;
                break;
        }
        switch (subLoc)
        {
            case AttackFxData.FxSubLocation.NONE:
                return transform2;

            case AttackFxData.FxSubLocation.BODY:
                if (map != null)
                {
                    map.TryGetValue("biped spine", out transform);
                }
                return transform;

            case AttackFxData.FxSubLocation.RIGHTHAND:
                if (map != null)
                {
                    map.TryGetValue("biped r hand", out transform);
                }
                return transform;

            case AttackFxData.FxSubLocation.LEFTHAND:
                if (map != null)
                {
                    map.TryGetValue("biped l hand", out transform);
                }
                return transform;

            case AttackFxData.FxSubLocation.MAINHAND:
            case AttackFxData.FxSubLocation.OFFHAND:
                return transform;

            case AttackFxData.FxSubLocation.HEAD:
                if (map != null)
                {
                    map.TryGetValue("biped head", out transform);
                }
                return transform;
        }
        return transform;
    }

    public static void RegisterPool(FxPool pool)
    {
        pooledParent = pool.transform;
        pooledParent.position = new Vector3(0f, -1000f, 0f);
    }

    private static void SyncStart()
    {
        BundleService.StartLoadingBundle(BundleConsts.FX_BUNDLE, false);
        BundleService.StartLoadingBundle(BundleConsts.AUDIO_BUNDLE, false);
    }

    public static bool SyncUpdate()
    {
        float time = Time.time;
        for (int i = 0; i < active.Length; i++)
        {
            if (active[i] != null)
            {
                active[i].UpdatePosition(time);
                if (!(active[i].enabled || (active[i].startTime > time)))
                {
                    active[i].enabled = true;
                    active[i].SetInitiation();
                    active[i].PlayParticles();
                }
                else if (active[i].endTime <= time)
                {
                    if (!pooledFxObjects.ContainsKey(active[i].gameObject.name))
                    {
                        pooledFxObjects.Add(active[i].gameObject.name, new Queue<GameObject>());
                    }
                    active[i].transform.localPosition = Vector3.zero;
                    active[i].StopParticles();
                    pooledFxObjects[active[i].gameObject.name].Enqueue(active[i].gameObject);
                    active[i] = null;
                }
            }
        }
        return true;
    }

    private class ActiveFx
    {
        public readonly int attackFxId;
        public readonly float duration;
        public bool enabled = false;
        public readonly Transform endLocation;
        public readonly float endTime;
        public readonly AttackFxData.FxStyle fxStyle;
        public readonly GameObject gameObject;
        public Vector3 initiationLocation;
        private ParticleSystem[] particles;
        public readonly bool preserveOrientation;
        private AudioSource[] sounds;
        public readonly Transform startLocation;
        public readonly float startTime;
        public readonly Transform transform;

        public ActiveFx(int _attackFxId, AttackFxData.FxStyle style, float _startTime, float _endTime, Transform _startLocation, Transform _endLocation, bool _preserveOrientation, GameObject _obj)
        {
            this.attackFxId = _attackFxId;
            this.fxStyle = style;
            this.startTime = _startTime;
            this.endTime = _endTime;
            this.duration = _endTime - _startTime;
            this.preserveOrientation = _preserveOrientation;
            this.startLocation = _startLocation;
            this.endLocation = _endLocation;
            this.gameObject = _obj;
            this.transform = _obj.transform;
            this.sounds = this.gameObject.GetComponentsInChildren<AudioSource>(true);
            this.particles = this.gameObject.GetComponentsInChildren<ParticleSystem>(true);
            for (int i = 0; i < this.sounds.Length; i++)
            {
                this.sounds[i].loop = this.fxStyle == AttackFxData.FxStyle.LOOPSOUND;
            }
        }

        public void PlayParticles()
        {
            int num;
            for (num = 0; num < this.particles.Length; num++)
            {
                this.particles[num].Play();
            }
            for (num = 0; num < this.sounds.Length; num++)
            {
                this.sounds[num].Play();
            }
        }

        public void SetInitiation()
        {
            if (this.startLocation != null)
            {
                this.initiationLocation = this.startLocation.position;
                this.transform.position = this.initiationLocation;
            }
            if (!((this.endLocation == null) || this.preserveOrientation))
            {
                this.transform.LookAt(this.endLocation);
            }
        }

        public void StopParticles()
        {
            int num;
            for (num = 0; num < this.particles.Length; num++)
            {
                this.particles[num].Stop();
                if (this.fxStyle == AttackFxData.FxStyle.RAY)
                {
                    this.particles[num].Clear(true);
                    this.enabled = false;
                }
            }
            for (num = 0; num < this.sounds.Length; num++)
            {
                this.sounds[num].Stop();
            }
        }

        public void UpdatePosition(float curTime)
        {
            switch (this.fxStyle)
            {
                case AttackFxData.FxStyle.SELF:
                    if (this.startLocation != null)
                    {
                        this.transform.position = this.startLocation.position;
                        this.transform.rotation = this.startLocation.rotation;
                    }
                    break;

                case AttackFxData.FxStyle.PROJECTILE:
                case AttackFxData.FxStyle.SOUND:
                    this.transform.position = Vector3.Lerp(this.initiationLocation, this.finalLocation, (curTime - this.startTime) / this.duration);
                    break;

                case AttackFxData.FxStyle.DIRECTIONAL:
                    if (this.startLocation != null)
                    {
                        this.transform.position = this.startLocation.position;
                        this.transform.LookAt(this.finalLocation);
                    }
                    break;

                case AttackFxData.FxStyle.TARGET:
                    if (this.endLocation != null)
                    {
                        this.transform.position = this.endLocation.position;
                        this.transform.rotation = this.endLocation.rotation;
                    }
                    break;

                case AttackFxData.FxStyle.RAY:
                    this.UpdateRayPosition(curTime);
                    break;
            }
        }

        private void UpdateRayPosition(float curTime)
        {
            if ((this.startLocation != null) && (this.endLocation != null))
            {
                float parameter = Vector3.Distance(this.startLocation.position, this.endLocation.position);
                this.transform.position = this.startLocation.position;
                this.transform.LookAt(this.endLocation.position);
                this.transform.localScale = new Vector3(1f, 1f, parameter / 50f);
                this.gameObject.BroadcastMessage("ScaleFx", parameter);
            }
        }

        public Vector3 finalLocation
        {
            get
            {
                if (this.endLocation != null)
                {
                    return this.endLocation.position;
                }
                if (this.startLocation != null)
                {
                    return this.startLocation.position;
                }
                return this.initiationLocation;
            }
        }
    }
}

