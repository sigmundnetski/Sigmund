﻿using GNGUI;
using System;
using UnityEngine;

public abstract class BuffRibbon : MonoBehaviour
{
    private RibbonType ribbonType = RibbonType.NONE;
    protected int[] ribbonValues = new int[RibbonBuffChannelVars.RIBBON_CHANNELS.Length];

    protected BuffRibbon()
    {
    }

    private RibbonBuffChannelVars[] GetRibbonInfo(CombatVars cv)
    {
        switch (this.ribbonType)
        {
            case RibbonType.ATTACK:
                return cv.attackRBCV;

            case RibbonType.DEFENSE:
                return cv.defenseRBCV;

            case RibbonType.RESISTANCE:
                return cv.resistanceRBCV;

            case RibbonType.SPEED:
                return cv.speedRBCV;
        }
        return new RibbonBuffChannelVars[0];
    }

    public void Hide()
    {
        NGUITools.SetActive(base.gameObject, false);
    }

    public void Init(RibbonType ribbonType_)
    {
        this.ribbonType = ribbonType_;
    }

    public bool InternalSyncUpdate(CombatVars cv)
    {
        bool flag = this.IsShowing();
        if (cv == null)
        {
            if (flag)
            {
                this.Hide();
            }
            return false;
        }
        int index = 0;
        while (index < this.ribbonValues.Length)
        {
            this.ribbonValues[index] = 0;
            index++;
        }
        RibbonBuffChannelVars[] ribbonInfo = this.GetRibbonInfo(cv);
        for (index = 0; index < ribbonInfo.Length; index++)
        {
            this.ribbonValues[0] = Math.Max(this.ribbonValues[0], ribbonInfo[index].buffAlchemical);
            this.ribbonValues[1] = Math.Max(this.ribbonValues[1], ribbonInfo[index].buffExtraordinary);
            this.ribbonValues[2] = Math.Max(this.ribbonValues[2], ribbonInfo[index].buffSupernatural);
            this.ribbonValues[3] = Math.Max(this.ribbonValues[3], ribbonInfo[index].debuffSubmission);
            this.ribbonValues[4] = Math.Max(this.ribbonValues[4], ribbonInfo[index].debuffTorment);
            this.ribbonValues[5] = Math.Max(this.ribbonValues[5], ribbonInfo[index].debuffWeakness);
        }
        bool flag2 = false;
        for (index = 0; index < this.ribbonValues.Length; index++)
        {
            if (this.ribbonValues[index] != 0)
            {
                flag2 = true;
                break;
            }
        }
        if (!(!flag2 || flag))
        {
            this.Show();
        }
        else if (!(flag2 || !flag))
        {
            this.Hide();
        }
        if (!flag2)
        {
            return false;
        }
        return true;
    }

    public bool IsShowing()
    {
        return NGUITools.GetActive(base.gameObject);
    }

    public void Show()
    {
        NGUITools.SetActive(base.gameObject, true);
    }

    public void Start()
    {
        this.Hide();
    }

    public abstract void SyncUpdate(CombatVars cv);

    public enum RibbonType
    {
        NONE,
        ATTACK,
        DEFENSE,
        RESISTANCE,
        SPEED
    }
}

