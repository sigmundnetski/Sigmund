﻿using GNGUI;
using System;
using UnityEngine;

public class SimpleBuffRibbon : BuffRibbon
{
    private UISprite[] buffChevrons = new UISprite[2];
    private UISprite[] debuffChevrons = new UISprite[2];
    private const float MIN_SHOW_MAJOR_VALUE = 50f;
    private const float MIN_SHOW_MINOR_VALUE = 10f;
    private SeverityIndex prevBuffSeverity = SeverityIndex.NONE;
    private SeverityIndex prevDebuffSeverity = SeverityIndex.NONE;

    public void Awake()
    {
        int num;
        foreach (UISprite sprite in base.GetComponentsInChildren<UISprite>())
        {
            if (sprite.name == "ChevronBuffMinor")
            {
                this.buffChevrons[0] = sprite;
            }
            else if (sprite.name == "ChevronBuffMajor")
            {
                this.buffChevrons[1] = sprite;
            }
            if (sprite.name == "ChevronDebuffMinor")
            {
                this.debuffChevrons[0] = sprite;
            }
            else if (sprite.name == "ChevronDebuffMajor")
            {
                this.debuffChevrons[1] = sprite;
            }
        }
        GuiHelper.GuiAssertNotNull("Could not find needed buff sprites.", this.buffChevrons);
        GuiHelper.GuiAssertNotNull("Could not find needed debuff sprites.", this.debuffChevrons);
        for (num = 0; num < this.buffChevrons.Length; num++)
        {
            NGUITools.SetActive(this.buffChevrons[num].gameObject, false);
        }
        for (num = 0; num < this.debuffChevrons.Length; num++)
        {
            NGUITools.SetActive(this.debuffChevrons[num].gameObject, false);
        }
    }

    public override void SyncUpdate(CombatVars cv)
    {
        if (base.InternalSyncUpdate(cv))
        {
            int num3;
            float a = 0f;
            float num2 = 0f;
            for (num3 = 0; num3 < (base.ribbonValues.Length / 2); num3++)
            {
                a = Mathf.Max(a, (float) base.ribbonValues[num3]);
            }
            SeverityIndex nONE = SeverityIndex.NONE;
            if (a >= 50f)
            {
                nONE = SeverityIndex.MAJOR;
            }
            else if (a >= 10f)
            {
                nONE = SeverityIndex.MINOR;
            }
            if (nONE != this.prevBuffSeverity)
            {
                if (nONE == SeverityIndex.NONE)
                {
                    for (num3 = 0; num3 < this.buffChevrons.Length; num3++)
                    {
                        NGUITools.SetActive(this.buffChevrons[num3].gameObject, false);
                    }
                }
                else
                {
                    num3 = 0;
                    while (num3 <= nONE)
                    {
                        NGUITools.SetActive(this.buffChevrons[num3].gameObject, true);
                        num3++;
                    }
                    for (num3 = ((int) nONE) + 1; num3 < this.buffChevrons.Length; num3++)
                    {
                        NGUITools.SetActive(this.buffChevrons[num3].gameObject, false);
                    }
                }
            }
            this.prevBuffSeverity = nONE;
            for (num3 = base.ribbonValues.Length / 2; num3 < base.ribbonValues.Length; num3++)
            {
                num2 = Mathf.Max(num2, (float) base.ribbonValues[num3]);
            }
            SeverityIndex mAJOR = SeverityIndex.NONE;
            if (num2 >= 50f)
            {
                mAJOR = SeverityIndex.MAJOR;
            }
            else if (num2 >= 10f)
            {
                mAJOR = SeverityIndex.MINOR;
            }
            if (mAJOR != this.prevDebuffSeverity)
            {
                if (mAJOR == SeverityIndex.NONE)
                {
                    for (num3 = 0; num3 < this.debuffChevrons.Length; num3++)
                    {
                        NGUITools.SetActive(this.debuffChevrons[num3].gameObject, false);
                    }
                }
                else
                {
                    num3 = 0;
                    while (num3 <= mAJOR)
                    {
                        NGUITools.SetActive(this.debuffChevrons[num3].gameObject, true);
                        num3++;
                    }
                    for (num3 = ((int) mAJOR) + 1; num3 < this.debuffChevrons.Length; num3++)
                    {
                        NGUITools.SetActive(this.debuffChevrons[num3].gameObject, false);
                    }
                }
            }
            this.prevDebuffSeverity = mAJOR;
        }
    }

    private enum SeverityIndex
    {
        MINOR,
        MAJOR,
        NUM_SEVERITIES,
        NONE
    }
}

