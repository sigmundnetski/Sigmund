﻿using System;
using UnityEngine;

public class UnityEditorTickMono : MonoBehaviour
{
    public UnityEditorTick.SpawnPlayerCallback callback = null;
    public string curState;
    public UnityEditorTick myTick;
    public GameObject root = null;
    public static UnityEditorTickMono singleton;

    public void Awake()
    {
        singleton = this;
    }

    public void FixedUpdate()
    {
        if (((this.myTick == null) && (this.root != null)) && (this.callback != null))
        {
            this.myTick = new UnityEditorTick(this.root, this.callback);
        }
        this.myTick.FixedUpdate();
        this.curState = this.myTick.curState;
    }

    public void OnDestroy()
    {
        this.myTick.StopTicking();
        singleton = null;
    }

    public void Update()
    {
        this.myTick.Update();
    }
}

