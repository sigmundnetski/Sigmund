﻿using GNGUI;
using System;
using UnityEngine;

public class FlagDetailsGui : MonoBehaviour
{
    private UISprite background;
    private UILabel durationLabel;
    private UISprite icon;
    private UILabel nameLabel;
    private UILabel sourceLabel;

    public void Awake()
    {
        foreach (UISprite sprite in base.GetComponentsInChildren<UISprite>())
        {
            if (sprite.name == "Background")
            {
                this.background = sprite;
            }
            else if (sprite.name == "Icon")
            {
                this.icon = sprite;
            }
        }
        foreach (UILabel label in base.GetComponentsInChildren<UILabel>())
        {
            if (label.name == "Name")
            {
                this.nameLabel = label;
            }
            else if (label.name == "Source")
            {
                this.sourceLabel = label;
            }
            else if (label.name == "Duration")
            {
                this.durationLabel = label;
            }
        }
        GuiHelper.GuiAssertNotNull("Something's null...", new object[] { this.background, this.icon, this.nameLabel, this.sourceLabel, this.durationLabel });
    }

    public void SyncFixedUpdate(string iconName, string name, string source, string duration)
    {
        this.icon.spriteName = iconName;
        this.nameLabel.text = name;
        this.sourceLabel.text = source;
        this.durationLabel.text = duration;
    }
}

