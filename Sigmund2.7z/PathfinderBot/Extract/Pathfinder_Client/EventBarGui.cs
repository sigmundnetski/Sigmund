﻿using GNGUI;
using System;
using System.Collections.Generic;
using UnityEngine;

public class EventBarGui : HidablePanelGui
{
    private List<EventBarItem> eventItems = new List<EventBarItem>();
    private GameObject eventPrefab;
    private UIGrid eventUiGrid;
    private bool needsRepopulate = true;
    public static EventBarGui singleton;

    private void _Repopulate()
    {
        int index = 0;
        this.RepopulateHelper(EncounterClient.GetDisplayedEvents(), ref index);
        this.RepopulateHelper(AdvancementClient.GetAchievementsToDisplay(), ref index);
        this.RepopulateHelper(QuestClient.GetQuestsToDisplay(), ref index);
        UIGrid.SetElementCount<EventBarItem>(DragDropRoot.root, this.eventUiGrid, this.eventPrefab, this.eventItems, index);
        this.needsRepopulate = false;
    }

    public void Awake()
    {
        singleton = this;
        this.OnAwake();
    }

    public bool LoadingTickFinished()
    {
        this.eventUiGrid = base.GetComponentInChildren<UIGrid>();
        GuiHelper.GuiAssertNotNull("Could not find needed child objects.", new object[] { this.eventUiGrid });
        this.eventPrefab = UIClient.guiPrefabs["EventBarItem"];
        HidablePanelGui.ImageButtonSprites hidePanel = new HidablePanelGui.ImageButtonSprites("panel_button_minright_de", "panel_button_minright_mo", "panel_button_minright_cl");
        HidablePanelGui.ImageButtonSprites showPanel = new HidablePanelGui.ImageButtonSprites("panel_button_minleft_de", "panel_button_minleft_mo", "panel_button_minleft_cl");
        base.ButtonImageSets(showPanel, hidePanel);
        base.AlwaysShow(base.closeButton.gameObject);
        this.ShowPanel();
        return true;
    }

    private void OnAwake()
    {
        ClientTick.eventGuiLoadFinish = new GUtil.BoolFilterDelegate(this.LoadingTickFinished);
    }

    public void OnDestroy()
    {
        singleton = null;
    }

    public static void Repopulate()
    {
        if (singleton != null)
        {
            singleton.needsRepopulate = true;
        }
    }

    private void RepopulateHelper(IEnumerable<ITrackerElement> displayItems, ref int index)
    {
        foreach (ITrackerElement element in displayItems)
        {
            if (index >= this.eventItems.Count)
            {
                EventBarItem component = NGUITools.AddChild(this.eventUiGrid.gameObject, this.eventPrefab).GetComponent<EventBarItem>();
                this.eventItems.Add(component);
            }
            this.eventItems[index].UpdateText(element);
            index++;
        }
    }

    public static bool SyncFixedUpdate()
    {
        if (((singleton != null) && singleton.needsRepopulate) && singleton.IsShowing())
        {
            singleton._Repopulate();
        }
        return true;
    }
}

