﻿using System;
using UnityEngine;

public abstract class ItemWindowGui : WindowGui
{
    protected ItemWindowGui()
    {
    }

    protected InventoryItem AdjustItemOnInteract(InventoryItem item, Interaction interaction)
    {
        uint quantity = item.quantity;
        switch (interaction)
        {
            case Interaction.SINGLE_CLICK:
                quantity = 1;
                break;

            case Interaction.DOUBLE_CLICK:
            case Interaction.DROP:
                quantity = item.quantity;
                break;
        }
        return InventoryItem.ChangeQuantity(item, quantity);
    }

    public abstract void DragEnd(InventoryItem item, BasicItemData.ItemSlot slot);
    public abstract void DragStart(InventoryItem item);
    public abstract void ItemInteract(ItemGui item, Interaction interaction);
    public void OnDrop(GameObject droppedGo)
    {
        ItemGui component = droppedGo.GetComponent<ItemGui>();
        if (component != null)
        {
            this.ItemInteract(component, Interaction.DROP);
        }
    }

    public enum Interaction
    {
        SINGLE_CLICK,
        DOUBLE_CLICK,
        DROP
    }
}

