﻿using GNetwork;
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public static class EncounterClient
{
    private static Dictionary<EncounterInstanceId, GameObject> activeEncounters = new Dictionary<EncounterInstanceId, GameObject>();
    private static List<ITrackerElement> displayedEvents = new List<ITrackerElement>();
    private static GameObject encounterParent = null;
    private static Dictionary<string, GameObject> encounterPrefabs = new Dictionary<string, GameObject>();
    private static DateTime lastUpdate;
    private static int prevHash = 0;
    private static readonly TimeSpan SYNC_DELTA = TimeSpan.FromSeconds(15.0);

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void DespawnProxy(EncounterInstanceId encounterInstanceID)
    {
        if (!activeEncounters.ContainsKey(encounterInstanceID))
        {
            GLog.LogError(new object[] { "Encounter doesn't exist:", encounterInstanceID });
        }
        else
        {
            UnityEngine.Object.Destroy(activeEncounters[encounterInstanceID]);
            activeEncounters.Remove(encounterInstanceID);
        }
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void EndEventNotification(int eventId, byte resultByte)
    {
        EventData data;
        if (EventData.eventsById.TryGetValue(eventId, out data))
        {
            switch (((EscalationConst.Flow) resultByte))
            {
                case (EscalationConst.Flow.INCOMPLETE | EscalationConst.Flow.SUCCESS):
                    DebugClient.GenericDebugMessage(data.successHudText);
                    break;

                case EscalationConst.Flow.FAILURE:
                    DebugClient.GenericDebugMessage(data.failureHudText);
                    break;
            }
        }
    }

    public static bool ExtractBundles()
    {
        if (encounterPrefabs.Count <= 0)
        {
            foreach (GameObject obj2 in BundleService.LoadAll<GameObject>(BundleConsts.ENCOUNTER_BUNDLE))
            {
                encounterPrefabs[obj2.name.ToLower()] = obj2;
            }
        }
        return true;
    }

    public static IEnumerable<ITrackerElement> GetDisplayedEvents()
    {
        displayedEvents.Clear();
        foreach (ActiveEventInfo info in EntityDataClient.owner.escalationVars.events)
        {
            if (info != null)
            {
                displayedEvents.Add(new TrackedEvent(info.eventId));
            }
        }
        return displayedEvents;
    }

    public static bool LoadingTick()
    {
        encounterParent = GameObject.Find("/Programming/EncounterParent");
        return (encounterParent != null);
    }

    public static void OnClientEntityUpdate(Entity entity)
    {
        DateTime utcNow = DateTime.UtcNow;
        if (object.ReferenceEquals(entity, EntityDataClient.owner) && (MiniMapGui.singleton != null))
        {
            int num = entity.escalationVars.GetQuestHashCode() + entity.playerRecord.GetQuestHashCode();
            if ((prevHash != num) || (utcNow > (lastUpdate + SYNC_DELTA)))
            {
                EventBarGui.Repopulate();
                MiniMapGui.singleton.EscalationChange();
                prevHash = num;
                lastUpdate = utcNow;
            }
        }
    }

    public static void OnDisconnectedFromServer()
    {
        foreach (KeyValuePair<EncounterInstanceId, GameObject> pair in activeEncounters)
        {
            UnityEngine.Object.Destroy(pair.Value);
        }
        activeEncounters.Clear();
    }

    public static void OnSayonara(ushort mapId)
    {
        EncounterInstanceId[] idArray = activeEncounters.Keys.ToArray<EncounterInstanceId>();
        for (int i = 0; i < idArray.Length; i++)
        {
            if (EscalationUtils.GetMapId(idArray[i]) == mapId)
            {
                UnityEngine.Object.Destroy(activeEncounters[idArray[i]]);
                activeEncounters.Remove(idArray[i]);
            }
        }
    }

    public static void PrintEscVars(string[] args, EntityId playerEntityId)
    {
        GLog.Log(new object[] { "EscVars:", EntityDataClient.owner.escalationVars });
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void SpawnProxy(ushort mapId, EncounterInstanceId encounterInstanceID, string prefabName, Vector3 position, Quaternion rotation)
    {
        GameObject obj3;
        position = TerrainService.TranslateServerToLocal(mapId, position);
        if (!encounterPrefabs.TryGetValue(prefabName, out obj3))
        {
            GLog.LogError(new object[] { "Cannot spawn prefab:", prefabName, encounterPrefabs.Count });
        }
        else
        {
            GameObject obj2;
            if (activeEncounters.TryGetValue(encounterInstanceID, out obj2))
            {
                if ((obj2.name == prefabName) && ((obj2.transform.position - position).sqrMagnitude < 1f))
                {
                    return;
                }
                GLog.LogError(new object[] { "Overwriting an already spawned encounter proxy", encounterInstanceID, "-", obj2.name, "at", obj2.transform.position, "replaced by", prefabName, "at", position });
            }
            obj2 = (GameObject) UnityEngine.Object.Instantiate(obj3, position, rotation);
            obj2.name = prefabName;
            ResourceManager.RegisterForDynamicTextures(obj2);
            obj2.transform.parent = encounterParent.transform;
            activeEncounters[encounterInstanceID] = obj2;
        }
    }

    private static void SyncStart()
    {
        BundleService.StartLoadingBundle(BundleConsts.ENCOUNTER_BUNDLE, false);
        lastUpdate = DateTime.UtcNow;
    }
}

