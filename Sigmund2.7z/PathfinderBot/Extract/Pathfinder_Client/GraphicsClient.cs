﻿using GNetwork;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using UnityEngine;

public static class GraphicsClient
{
    private static DynamicLightSettingData curLightSettings;
    private static TimeSpan cycleTime = TimeSpan.FromHours(4.0);
    public static GameObject goblinCamera = null;
    private const string HACK_LIGHT_SETTING_NAME = "testcycle";
    private static float hackTimeOfDay = float.NaN;
    private static Dictionary<string, DynamicLightCollection> lightCollections = new Dictionary<string, DynamicLightCollection>();
    private static Skybox skybox = null;
    private static Dictionary<string, AudioSource[]> soundChannels = new Dictionary<string, AudioSource[]>();
    private static GameObject theSun = null;

    public static void ChangeLightCycleDuration(float minutes)
    {
        cycleTime = TimeSpan.FromMinutes((double) minutes);
    }

    public static void ChangeLightCycleTime(float setTime)
    {
        hackTimeOfDay = setTime;
    }

    public static float GetVolume(string channel)
    {
        AudioSource[] sourceArray;
        if (soundChannels.TryGetValue(channel, out sourceArray) && (sourceArray.Length > 0))
        {
            return sourceArray[0].volume;
        }
        return 0f;
    }

    public static bool LoadingTickFinished()
    {
        StaticDataService.RegisterCallback<DynamicLightSettingData>(new StaticDataService.StaticDataServiceCallback(GraphicsClient.OnDataUpdate));
        goblinCamera = (GameObject) UnityEngine.Object.Instantiate(UIClient.guiPrefabs["GoblinCamera"], Vector3.zero, Quaternion.identity);
        GameObject obj2 = (GameObject) UnityEngine.Object.Instantiate(UIClient.guiPrefabs["GoblinAudio"], Vector3.zero, Quaternion.identity);
        foreach (Transform transform in obj2.transform)
        {
            AudioSource[] components = transform.GetComponents<AudioSource>();
            if ((components != null) && (components.Length > 0))
            {
                soundChannels[transform.gameObject.name.ToLower()] = components;
            }
        }
        if (theSun != null)
        {
            SetSun(theSun);
        }
        QualitySettings.lodBias = 2f;
        LoadSettings("testcycle");
        return true;
    }

    public static void LoadLightSetting(string[] args, EntityId playerEntityId)
    {
        string str = null;
        if (args.Length > 1)
        {
            str = string.Join(" ", args, 1, args.Length - 1);
        }
        if (!(string.IsNullOrEmpty(str) || !LoadSettings(str.ToLower())))
        {
            DebugClient.DisplayDebugMessage("Color setting changed to: " + str);
        }
        else
        {
            DebugClient.DisplayDebugMessage("Change color setting failed.");
        }
    }

    public static bool LoadSettings(string name)
    {
        DynamicLightSettingData data;
        bool flag = DynamicLightSettingData.settingByName.TryGetValue(name, out data);
        if (flag)
        {
            curLightSettings = data;
            return flag;
        }
        GLog.LogError(new object[] { "Unable to load light settings:", name, DynamicLightSettingData.settingByName.Keys });
        return flag;
    }

    private static void OnDataUpdate(List<DataClass> newData)
    {
        if (curLightSettings != null)
        {
            LoadSettings(curLightSettings.name);
        }
    }

    private static void RecalculateColor(DynamicLightData[] colorValuesAtTimes, float timeOfDay, out Color curColor, out float curIntensity, out float curShadowStrength, out float curRange, out Quaternion curRotation)
    {
        float num;
        float num2;
        IOrderedEnumerable<DynamicLightData> source = from each in colorValuesAtTimes
            where each.timeOfDay <= timeOfDay
            orderby each.timeOfDay descending
            select each;
        IOrderedEnumerable<DynamicLightData> enumerable2 = from each in colorValuesAtTimes
            where each.timeOfDay >= timeOfDay
            orderby each.timeOfDay
            select each;
        DynamicLightData data = source.FirstOrDefault<DynamicLightData>();
        if (data == null)
        {
            data = enumerable2.LastOrDefault<DynamicLightData>();
            num = data.timeOfDay - 1f;
        }
        else
        {
            num = data.timeOfDay;
        }
        DynamicLightData data2 = enumerable2.FirstOrDefault<DynamicLightData>();
        if (data2 == null)
        {
            data2 = source.LastOrDefault<DynamicLightData>();
            num2 = data2.timeOfDay + 1f;
        }
        else
        {
            num2 = data2.timeOfDay;
        }
        float t = ((num2 - num) > 0f) ? ((timeOfDay - num) / (num2 - num)) : 1f;
        if ((data.smoothing == DynamicLightData.Smoothing.Cubic) && (data2.smoothing == DynamicLightData.Smoothing.Cubic))
        {
            t = ((3f * t) * t) - (((2f * t) * t) * t);
        }
        curColor = Color.Lerp(data.color, data2.color, t);
        curIntensity = Mathf.Lerp(data.intensity, data2.intensity, t);
        curShadowStrength = Mathf.Lerp(data.shadowStrength, data2.shadowStrength, t);
        curRange = Mathf.Lerp(data.range, data2.range, t);
        curRotation = Quaternion.Lerp(Quaternion.Euler(data.eulerRotation), Quaternion.Euler(data2.eulerRotation), t);
    }

    public static void RegisterDynamicLight(Light light)
    {
        DynamicLightCollection lights;
        if (!lightCollections.TryGetValue(light.gameObject.name, out lights))
        {
            lights = new DynamicLightCollection(light.gameObject.name);
            lightCollections[light.gameObject.name] = lights;
        }
        lights.dynamicLights.Add(light);
    }

    public static void RemoveDynamicLight(Light light)
    {
        DynamicLightCollection lights;
        if (lightCollections.TryGetValue(light.gameObject.name, out lights))
        {
            lights.dynamicLights.Remove(light);
        }
    }

    public static void SetLightDuration(string[] args, EntityId playerEntityId)
    {
        float num;
        if ((args.Length == 2) && float.TryParse(args[1], out num))
        {
            ChangeLightCycleDuration(num);
            ChangeLightCycleTime(float.NaN);
        }
        else
        {
            DebugClient.DisplayDebugMessage("Failed");
        }
    }

    public static void SetLightTime(string[] args, EntityId playerEntityId)
    {
        float num;
        float naN = float.NaN;
        if ((args.Length == 2) && float.TryParse(args[1], out num))
        {
            naN = (num % 24f) / 24f;
        }
        else
        {
            float num2;
            if (((args.Length == 3) && float.TryParse(args[1], out num)) && float.TryParse(args[2], out num2))
            {
                naN = ((num % 24f) / 24f) + (num2 / 1440f);
            }
        }
        ChangeLightCycleTime(naN);
    }

    public static void SetSun(GameObject newSun)
    {
        if (((theSun != null) && (newSun != null)) && (theSun != newSun))
        {
            GLog.LogWarning(new object[] { "Sun is being replaced while another sun already exists" });
        }
        theSun = newSun;
    }

    public static void SetVolume(string[] args, EntityId playerEntityId)
    {
        float num;
        AudioSource[] sourceArray;
        if (!(((args.Length == 3) && soundChannels.TryGetValue(args[1].ToLower(), out sourceArray)) && float.TryParse(args[2], out num)))
        {
            DebugClient.DisplayDebugMessage("Format: Volume " + GUtil.PrettyPrint(soundChannels.Keys, " or ", "<>") + " <amount>");
        }
        else
        {
            for (int i = 0; i < sourceArray.Length; i++)
            {
                sourceArray[i].volume = num;
            }
        }
    }

    public static void SetVolume(string channel, float amount)
    {
        AudioSource[] sourceArray;
        if (soundChannels.TryGetValue(channel, out sourceArray))
        {
            for (int i = 0; i < sourceArray.Length; i++)
            {
                sourceArray[i].volume = amount;
            }
        }
    }

    public static bool SyncFixedUpdate()
    {
        TimeSpan span = (TimeSpan) (GNetworkService.ServerUtc - DateTime.Today);
        float timeOfDay = (float) ((span.TotalMilliseconds % cycleTime.TotalMilliseconds) / cycleTime.TotalMilliseconds);
        timeOfDay = ((0f <= hackTimeOfDay) && (hackTimeOfDay <= 1f)) ? hackTimeOfDay : timeOfDay;
        SyncFixedUpdate_RecalculateLightVars(timeOfDay);
        SyncFixedUpdate_UpdateLights();
        SyncFixedUpdate_UpdateNonLights(timeOfDay);
        return true;
    }

    private static void SyncFixedUpdate_RecalculateLightVars(float timeOfDay)
    {
        foreach (KeyValuePair<string, DynamicLightCollection> pair in lightCollections)
        {
            DynamicLightData[] dataArray;
            DynamicLightCollection lights = pair.Value;
            if (curLightSettings.lightDataByTarget.TryGetValue(lights.lightName, out dataArray))
            {
                RecalculateColor(dataArray, timeOfDay, out lights.curColor, out lights.curIntensity, out lights.curShadowStrength, out lights.curRange, out lights.curRotation);
                lights.valid = true;
            }
        }
    }

    private static void SyncFixedUpdate_UpdateLights()
    {
        foreach (KeyValuePair<string, DynamicLightCollection> pair in lightCollections)
        {
            DynamicLightCollection lights = pair.Value;
            if (lights.valid)
            {
                foreach (Light light in lights.dynamicLights)
                {
                    light.color = lights.curColor;
                    light.intensity = lights.curIntensity;
                    light.shadowStrength = lights.curShadowStrength;
                    if ((lights.curRange >= 0f) && (light.type != LightType.Directional))
                    {
                        light.range = lights.curRange;
                    }
                    light.transform.localRotation = lights.curRotation;
                }
            }
        }
    }

    private static void SyncFixedUpdate_UpdateNonLights(float timeOfDay)
    {
        float num;
        float num2;
        Quaternion quaternion;
        Color color;
        DynamicLightData[] dataArray;
        if (curLightSettings.lightDataByTarget.TryGetValue("reserved_ambient", out dataArray))
        {
            RecalculateColor(dataArray, timeOfDay, out color, out num, out num, out num, out quaternion);
            RenderSettings.ambientLight = color;
        }
        if (curLightSettings.lightDataByTarget.TryGetValue("reserved_fog", out dataArray))
        {
            RecalculateColor(dataArray, timeOfDay, out color, out num2, out num, out num, out quaternion);
            RenderSettings.fogColor = color;
            RenderSettings.fogDensity = num2;
        }
        if (skybox == null)
        {
            skybox = goblinCamera.GetComponent<Skybox>();
        }
        if ((skybox != null) && curLightSettings.lightDataByTarget.TryGetValue("reserved_sky", out dataArray))
        {
            RecalculateColor(dataArray, timeOfDay, out color, out num2, out num, out num, out quaternion);
            Material material = skybox.material;
            material.SetColor("_Tint", color);
            material.SetFloat("_Lerp", num2);
            skybox.material = material;
        }
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void UpdateRenderSettings(float fogEndDistance)
    {
        if ((goblinCamera != null) && (goblinCamera.camera != null))
        {
            Camera camera = goblinCamera.camera;
            camera.cullingMask &= ~(((int) 1) << LayerMask.NameToLayer("Water"));
        }
        RenderSettings.fog = true;
        RenderSettings.fogMode = FogMode.Linear;
        RenderSettings.fogDensity = 1f;
        RenderSettings.fogStartDistance = 20f;
        RenderSettings.fogEndDistance = fogEndDistance;
        RenderSettings.haloStrength = 0.5f;
        RenderSettings.flareStrength = 1f;
    }
}

