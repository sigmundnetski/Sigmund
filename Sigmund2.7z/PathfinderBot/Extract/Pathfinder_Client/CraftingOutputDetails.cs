﻿using GNGUI;
using System;
using System.Text;
using UnityEngine;

public class CraftingOutputDetails : MonoBehaviour
{
    public UILabel myLabel;
    private int prevRecipeId = 0;

    public void Start()
    {
        this.myLabel = base.GetComponent<UILabel>();
        GuiHelper.GuiAssertNotNull("Couldn't find required children.", new object[] { this.myLabel });
    }

    public void Update()
    {
        BaseRecipeData recipe = CraftingClient.activeRequest.GetRecipe();
        int num = (recipe != null) ? recipe.id : 0;
        if (num != this.prevRecipeId)
        {
            StringBuilder quickText = GUtil.GetQuickText();
            quickText.Append("Primary Queue:\n");
            if (recipe != null)
            {
                int skillTotalBySkillId = EntityDataClient.owner.combat.GetSkillTotalBySkillId(recipe.skillId);
                InventoryItem item = recipe.GenerateOutput(EntityDataClient.owner, CraftingClient.activeRequest.GetAvgInputUpgrade(), true);
                double num3 = CraftingClient.activeRequest.GetRecipeTime(EntityDataClient.owner, 1, CraftingClient.facilityRating);
                quickText.Append(item.GetQuality());
                quickText.Append("\n");
                double num4 = recipe.baseCraftDuration / 60.0;
                quickText.Append(num4.ToString("F1"));
                quickText.Append(" mins\n");
                quickText.Append(skillTotalBySkillId);
                quickText.Append("\n");
                quickText.Append(CraftingClient.facilityRating);
                quickText.Append("\n");
                quickText.Append((num3 / 60.0).ToString("F1"));
                quickText.Append(" mins\n");
            }
            this.myLabel.text = quickText.ToString();
            this.prevRecipeId = num;
        }
    }
}

