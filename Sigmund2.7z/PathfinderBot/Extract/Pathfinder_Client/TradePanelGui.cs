﻿using GNGUI;
using System;
using System.Collections.Generic;
using UnityEngine;

public class TradePanelGui : MonoBehaviour
{
    protected List<SortButton> allSorts = new List<SortButton>();
    protected SortButton currentSort = null;
    private List<TradeItemGui> displayedItems = new List<TradeItemGui>();
    public TradeWindowGui.TradePanel panelType;
    private UIScrollBar scrollBar;
    public UIGrid tradeGrid;
    private GameObject tradeItemPrefab = null;

    public void Awake()
    {
        this.scrollBar = base.GetComponentInChildren<UIScrollBar>();
        this.tradeGrid = base.GetComponentInChildren<UIGrid>();
        GuiHelper.GuiAssertNotNull("Couldn't find children.", new object[] { this.tradeGrid, this.scrollBar });
        foreach (SortButton button in base.GetComponentsInChildren<SortButton>())
        {
            this.allSorts.Add(button);
            UIEventListener listener1 = UIEventListener.Get(button.gameObject);
            listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.SortClicked));
            if (button.name == "S0_Name")
            {
                button.Init(0, SortButton.SortType.ASCENDING);
            }
            else if (button.name == "S1_Encumbrance")
            {
                button.Init(1, SortButton.SortType.INACTIVE);
            }
            else if (button.name == "S2_Durability")
            {
                button.Init(2, SortButton.SortType.INACTIVE);
            }
            else
            {
                GLog.LogError(new object[] { "Unknown sort!", button.name });
            }
            if ((button.sort != SortButton.SortType.INACTIVE) && (this.currentSort == null))
            {
                this.currentSort = button;
            }
            else if ((button.sort != SortButton.SortType.INACTIVE) && (this.currentSort != null))
            {
                GLog.LogError(new object[] { "Should only have one non-inactive sort! You have", this.currentSort.name, "and", button.name });
            }
        }
    }

    public void ClearItems()
    {
        foreach (TradeItemGui gui in this.displayedItems)
        {
            gui.gameObject.SetActive(false);
            gui.transform.parent = DragDropRoot.root;
            UnityEngine.Object.Destroy(gui.gameObject);
        }
        this.displayedItems.Clear();
    }

    public void ContentsChanged(InventoryItem[] tradeContainer)
    {
        int num = 0;
        for (int i = 0; i < tradeContainer.Length; i++)
        {
            if (!InventoryItem.EMPTY_MATCH(tradeContainer[i]))
            {
                if (num >= this.displayedItems.Count)
                {
                    TradeItemGui component = NGUITools.AddChild(this.tradeGrid.gameObject, this.tradeItemPrefab).GetComponent<TradeItemGui>();
                    this.displayedItems.Add(component);
                    if (this.panelType == TradeWindowGui.TradePanel.TARGET)
                    {
                        component.GetComponent<UIDragObject>().enabled = false;
                    }
                }
                this.displayedItems[num].Assign(tradeContainer[i], TradeWindowGui.singleton);
                num++;
            }
        }
        while (this.displayedItems.Count > num)
        {
            TradeItemGui gui2 = this.displayedItems[this.displayedItems.Count - 1];
            this.displayedItems.RemoveAt(this.displayedItems.Count - 1);
            gui2.gameObject.SetActive(false);
            gui2.transform.parent = DragDropRoot.root;
            UnityEngine.Object.Destroy(gui2.gameObject);
        }
        this.ResortContents((Sort) this.currentSort.sortId, this.currentSort.sort);
    }

    public void DragEnd()
    {
        this.tradeGrid.repositionNow = true;
    }

    public void LoadingTickFinished()
    {
        this.tradeItemPrefab = UIClient.guiPrefabs["TradeItem"];
        GuiHelper.GuiAssertNotNull("Couldn't load prefab.", new object[] { this.tradeItemPrefab });
    }

    public void ResetScroll()
    {
        this.scrollBar.scrollValue = 0f;
    }

    private void ResortContents(Sort sortField, SortButton.SortType sortType)
    {
        IEnumerable<TradeItemGui> enumerable = null;
        if (sortField == Sort.NAME)
        {
            if (sortType == SortButton.SortType.DESCENDING)
            {
                enumerable = from each in this.displayedItems
                    orderby each.sortName descending
                    select each;
            }
            else if (sortType == SortButton.SortType.ASCENDING)
            {
                enumerable = from each in this.displayedItems
                    orderby each.sortName
                    select each;
            }
            else
            {
                GLog.LogError(new object[] { "Don't know how to sort", sortField, "by", sortType });
            }
        }
        else if (sortField == Sort.ENCUMBRANCE)
        {
            if (sortType == SortButton.SortType.DESCENDING)
            {
                enumerable = from each in this.displayedItems
                    orderby each.sortEncumbrance descending
                    select each;
            }
            else if (sortType == SortButton.SortType.ASCENDING)
            {
                enumerable = from each in this.displayedItems
                    orderby each.sortEncumbrance
                    select each;
            }
            else
            {
                GLog.LogError(new object[] { "Don't know how to sort", sortField, "by", sortType });
            }
        }
        else if (sortField == Sort.DURABILITY)
        {
            if (sortType == SortButton.SortType.DESCENDING)
            {
                enumerable = from each in this.displayedItems
                    orderby each.sortDurability descending
                    select each;
            }
            else if (sortType == SortButton.SortType.ASCENDING)
            {
                enumerable = from each in this.displayedItems
                    orderby each.sortDurability
                    select each;
            }
            else
            {
                GLog.LogError(new object[] { "Don't know how to sort", sortField, "by", sortType });
            }
        }
        if (enumerable != null)
        {
            int num = 0;
            foreach (TradeItemGui gui in enumerable)
            {
                gui.name = num + "_" + gui.sortName;
                num++;
            }
        }
        else
        {
            GLog.LogError(new object[] { "Failed to sort", sortField, sortType });
        }
        this.tradeGrid.repositionNow = true;
    }

    public virtual void SortClicked(GameObject sortGO)
    {
        SortButton button = null;
        for (int i = 0; i < this.allSorts.Count; i++)
        {
            if (sortGO == this.allSorts[i].gameObject)
            {
                this.allSorts[i].ToggleSort(true);
                button = this.allSorts[i];
            }
            else
            {
                this.allSorts[i].ToggleSort(false);
            }
        }
        this.currentSort = button;
        this.ResortContents((Sort) this.currentSort.sortId, this.currentSort.sort);
        this.ResetScroll();
    }

    private enum Sort
    {
        NAME,
        ENCUMBRANCE,
        DURABILITY
    }
}

