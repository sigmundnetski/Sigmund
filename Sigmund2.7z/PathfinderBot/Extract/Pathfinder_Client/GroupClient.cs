﻿using GNetwork;
using System;
using System.Collections.Generic;

public static class GroupClient
{
    public static Party activeParty = null;
    public static Dictionary<ulong, VentureCompanyRecord> companiesById = new Dictionary<ulong, VentureCompanyRecord>();
    public static ClientCompany companyInvite = null;
    public static bool inviteFlag = false;
    public static string inviterName = null;
    public static VentureCompanyRecord[] lastSearchResult = new VentureCompanyRecord[0];
    public static uint ownerPartyId = 0;
    public static uint partyAlertId = uint.MaxValue;
    public static uint partyInviteId = 0;
    private static Dictionary<uint, Party> partySync = new Dictionary<uint, Party>();
    public static HashSet<ulong> playerCompanyIds = new HashSet<ulong>();
    public static uint playerSettlementId = 0;
    private static VentureCompanyRecord[] relatedSearchCompanies = new VentureCompanyRecord[0];
    private static bool searchUpdated = false;
    public static Dictionary<uint, SettlementRecord> settlementsById = new Dictionary<uint, SettlementRecord>();
    public static Dictionary<uint, List<TerritoryClientVars>> settlementTerritories = new Dictionary<uint, List<TerritoryClientVars>>();
    private static bool territoriesUpdated = false;

    public static void AllyApply(string[] args, EntityId playerEntityId)
    {
        string usage = "Usage: AllyApply <Settlement Name>";
        AllyApplyLeave(args, true, usage);
    }

    public static void AllyApplyLeave(string[] args, bool isApply, string usage)
    {
        string str = null;
        if (!CommandCore.RemoveCommandFromString(ref args[0]))
        {
            ChatGui.singleton.DisplayMessage(usage, ChatClient.ERROR_COLOR);
        }
        else
        {
            str = args[0];
            if (string.IsNullOrEmpty(str))
            {
                ChatGui.singleton.DisplayMessage(usage, ChatClient.ERROR_COLOR);
            }
            else
            {
                GRouting.SendAuthorityRpc(4, GRpcID.GroupAuthority_AllyApplyLeave, new object[] { str, isApply });
            }
        }
    }

    public static void AllyLeave(string[] args, EntityId playerEntityId)
    {
        string usage = "Usage: AllyLeave <Settlement Name>";
        AllyApplyLeave(args, false, usage);
    }

    public static void BreakAlliance(ulong allyCompanyId, uint allySettlementId)
    {
        GRouting.SendAuthorityRpc(4, GRpcID.GroupAuthority_AllyUpdate, new object[] { playerSettlementId, allyCompanyId, allySettlementId, (byte) 1 });
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void ClearParty()
    {
        ownerPartyId = 0;
        activeParty = null;
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void CommandStatus(byte status)
    {
        GroupConst.CommandStatus status2 = (GroupConst.CommandStatus) status;
        switch (status2)
        {
            case GroupConst.CommandStatus.PVP_START_INVALID:
            case GroupConst.CommandStatus.PVP_START_VALID:
                CompanyWindowHoldingsTabGui.singleton.PvpWindowResponse(status2);
                break;
        }
    }

    public static void CompaniesUpdated(HashSet<ulong> myCompanies)
    {
        playerCompanyIds = myCompanies;
        CompanyWindowGui.singleton.UpdateCompany();
    }

    private static ulong CompanyIdFromName(string vcName)
    {
        VentureCompanyRecord record = null;
        foreach (ulong num in playerCompanyIds)
        {
            if (companiesById.TryGetValue(num, out record) && (record.vcName.ToLower() == vcName.ToLower()))
            {
                return record.companyId;
            }
        }
        return 0L;
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void CompanySearchResult(IBitBufferRead buffer)
    {
        lastSearchResult = VentureCompanyRecord.PopArrayFromBuffer(buffer);
        int num = buffer.PopInt();
        for (int i = 0; i < num; i++)
        {
            if (buffer.PopBool())
            {
                SettlementRecord record = SettlementRecord.PopFromBuffer(buffer);
                if (record.settlementId != playerSettlementId)
                {
                    settlementsById[record.settlementId] = record;
                }
            }
        }
        relatedSearchCompanies = VentureCompanyRecord.PopArrayFromBuffer(buffer);
        searchUpdated = true;
        if (searchUpdated && territoriesUpdated)
        {
            CompanySearchWindowGui.singleton.SearchResult(lastSearchResult);
        }
    }

    public static VentureCompanyRecord GetCompany(ulong companyId)
    {
        int num;
        if (playerCompanyIds.Contains(companyId))
        {
            return companiesById[companyId];
        }
        VentureCompanyRecord record = null;
        for (num = 0; num < lastSearchResult.Length; num++)
        {
            if ((lastSearchResult[num] != null) && (lastSearchResult[num].companyId == companyId))
            {
                record = lastSearchResult[num];
                break;
            }
        }
        if (record == null)
        {
            for (num = 0; num < relatedSearchCompanies.Length; num++)
            {
                if ((relatedSearchCompanies[num] != null) && (relatedSearchCompanies[num].companyId == companyId))
                {
                    return relatedSearchCompanies[num];
                }
            }
        }
        return record;
    }

    public static SettlementRecord GetPlayerSettlement()
    {
        SettlementRecord record;
        if (!settlementsById.TryGetValue(playerSettlementId, out record))
        {
            record = SocietySync.DEFAULT_SETTLEMENT;
        }
        return record;
    }

    public static ulong GetPrimaryCompanyId()
    {
        VentureCompanyRecord record = null;
        ulong companyId = 0L;
        byte priority = 0xff;
        foreach (ulong num3 in playerCompanyIds)
        {
            if (companiesById.TryGetValue(num3, out record))
            {
                VentureCompanyMember member = record.FindMember(EntityDataClient.owner.playerId);
                if ((member != null) && (member.priority < priority))
                {
                    priority = member.priority;
                    companyId = record.companyId;
                }
            }
        }
        return companyId;
    }

    public static SettlementRecord GetSettlement(uint settlementId)
    {
        SettlementRecord record;
        settlementsById.TryGetValue(settlementId, out record);
        return record;
    }

    public static VentureCompanyRecord GetSettlementCompany()
    {
        foreach (VentureCompanyRecord record in companiesById.Values)
        {
            if (record.settlementId != 0)
            {
                return record;
            }
        }
        return null;
    }

    public static bool InOwnerCompany(uint settlementId)
    {
        SettlementRecord settlement = GetSettlement(settlementId);
        if (settlement != null)
        {
            foreach (VentureCompanyRecord record2 in companiesById.Values)
            {
                if (record2.companyId == settlement.ownerCompanyId)
                {
                    return true;
                }
            }
        }
        return false;
    }

    public static bool InOwnerCompany(VentureCompanyRecord company)
    {
        if (company == null)
        {
            return false;
        }
        SettlementRecord settlement = GetSettlement(company.settlementId);
        if (settlement == null)
        {
            return false;
        }
        return playerCompanyIds.Contains(settlement.ownerCompanyId);
    }

    public static void Invite(string[] args, EntityId playerEntityId)
    {
        string str = args[0];
        if (!(CommandCore.RemoveCommandFromString(ref str) && !string.IsNullOrEmpty(str)))
        {
            ChatGui.singleton.DisplayMessage("Usage: Invite <Player>", ChatClient.ERROR_COLOR);
        }
        else
        {
            GRouting.SendAuthorityRpc(4, GRpcID.GroupAuthority_PartyInvite, new object[] { str });
        }
    }

    public static void InviteAlliance(ulong allyCompanyId, uint allySettlementId, bool approve)
    {
        GRouting.SendAuthorityRpc(4, GRpcID.GroupAuthority_AllyUpdate, new object[] { playerSettlementId, allyCompanyId, allySettlementId, approve ? ((byte) 2) : ((byte) 3) });
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void InviteToCompany(ulong companyId, string vcName)
    {
        companyInvite = new ClientCompany(companyId);
        companyInvite.name = vcName;
        DebugClient.DisplayDebugMessage("You have been invited to " + vcName);
    }

    public static void Kick(string[] args, EntityId playerEntityId)
    {
        string str = args[0];
        if (!(CommandCore.RemoveCommandFromString(ref str) && !string.IsNullOrEmpty(str)))
        {
            ChatGui.singleton.DisplayMessage("Usage: Kick <Player>", ChatClient.ERROR_COLOR);
        }
        else
        {
            GRouting.SendAuthorityRpc(4, GRpcID.GroupAuthority_PartyKick, new object[] { str });
        }
    }

    public static void Leave(string[] args, EntityId playerEntityId)
    {
        if (args.Length != 1)
        {
            ChatGui.singleton.DisplayMessage("Usage: Leave", ChatClient.ERROR_COLOR);
        }
        else
        {
            GRouting.SendAuthorityRpc(4, GRpcID.GroupAuthority_PartyLeave, new object[0]);
        }
    }

    public static bool LoadingTickFinished()
    {
        SocietySync.LoadingTickFinished();
        settlementsById[0] = SocietySync.DEFAULT_SETTLEMENT;
        RequestTerritories();
        return true;
    }

    public static void OnAlertInteraction(uint alertId, AlertsManagerGui.AlertAction action)
    {
        if (alertId == partyAlertId)
        {
            if (action == AlertsManagerGui.AlertAction.ACCEPTED)
            {
                GRouting.SendAuthorityRpc(4, GRpcID.GroupAuthority_PartyInviteResponse, new object[] { (byte) 2 });
            }
            else
            {
                GRouting.SendAuthorityRpc(4, GRpcID.GroupAuthority_PartyInviteResponse, new object[] { (byte) 1 });
            }
            partyAlertId = uint.MaxValue;
        }
    }

    public static bool OwnsSettlement(VentureCompanyRecord company)
    {
        if (company == null)
        {
            return false;
        }
        SettlementRecord settlement = GetSettlement(company.settlementId);
        if (settlement == null)
        {
            return false;
        }
        return (settlement.ownerCompanyId == company.companyId);
    }

    public static void Promote(string[] args, EntityId playerEntityId)
    {
        string str = args[0];
        if (!(CommandCore.RemoveCommandFromString(ref str) && !string.IsNullOrEmpty(str)))
        {
            ChatGui.singleton.DisplayMessage("Usage: Promote <Player>", ChatClient.ERROR_COLOR);
        }
        else
        {
            GRouting.SendAuthorityRpc(4, GRpcID.GroupAuthority_PartyPromote, new object[] { str });
        }
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void ReceivePartyDataUpdate(IBitBufferRead buffer)
    {
        NetworkSync<uint, Party>.ReceiveData(buffer, partySync);
        ownerPartyId = 0;
        activeParty = null;
        foreach (KeyValuePair<uint, Party> pair in partySync)
        {
            ownerPartyId = pair.Value.partyId;
            activeParty = pair.Value;
        }
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void ReceiveTerritories(IBitBufferRead buffer)
    {
        int num = buffer.PopInt();
        for (int i = 0; i < num; i++)
        {
            List<TerritoryClientVars> list;
            uint key = buffer.PopUInt();
            int num4 = buffer.PopInt();
            if (!settlementTerritories.TryGetValue(key, out list))
            {
                list = new List<TerritoryClientVars>();
                settlementTerritories[key] = list;
            }
            list.Clear();
            for (int j = 0; j < num4; j++)
            {
                ushort num6 = buffer.PopUShort();
                ulong num7 = buffer.PopULong();
                uint num8 = buffer.PopUInt();
                string str = buffer.PopString();
                list.Add(new TerritoryClientVars(num6, num7, num8, str));
            }
        }
        territoriesUpdated = true;
        if (searchUpdated && territoriesUpdated)
        {
            CompanySearchWindowGui.singleton.SearchResult(lastSearchResult);
        }
        CompanyWindowGui.singleton.UpdateCompany();
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void RemoveFromCompany(string name)
    {
        DebugClient.DisplayDebugMessage("Removed from company: " + name);
    }

    public static void RequestCompanySearch(string search, VentureCompanyRecord.Goal goals, PvpConst.Reputation reputation)
    {
        searchUpdated = false;
        territoriesUpdated = false;
        GRouting.SendAuthorityRpc(4, GRpcID.GroupAuthority_CompanySearch, new object[] { search, (ushort) goals, (byte) reputation });
    }

    public static void RequestNewPvpWindow(TimeSpan newStartTime)
    {
        GRouting.SendAuthorityRpc(4, GRpcID.GroupAuthority_NewPvpStart, new object[] { playerSettlementId, newStartTime.Hours, newStartTime.Minutes });
    }

    private static void RequestTerritories()
    {
        GRouting.SendAuthorityRpc(6, GRpcID.TerritoryAuthority_GetTowerInfo, new object[0]);
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void RetractCompanyInvite(ulong companyId)
    {
        if ((companyInvite != null) && (companyInvite.companyId == companyId))
        {
            companyInvite = null;
        }
        DebugClient.DisplayDebugMessage("Your company invite has been retracted.");
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void SetInviteFlag(uint partyId, string _inviterName)
    {
        inviteFlag = true;
        partyInviteId = partyId;
        inviterName = _inviterName;
    }

    public static void SettlementApply(string[] args, EntityId playerEntityId)
    {
        string usage = "Usage: SettlementApply <Settlement Name>, <Company Name>";
        SettlementApplyLeave(args, true, usage);
    }

    public static void SettlementApplyLeave(string[] args, bool isApply, string usage)
    {
        string param = null;
        string str2 = null;
        if (!CommandCore.RemoveCommandFromString(ref args[0]))
        {
            ChatGui.singleton.DisplayMessage(usage, ChatClient.ERROR_COLOR);
        }
        else if (!(CommandCore.ExtractLongParam(ref args[0], out param) && !string.IsNullOrEmpty(args[0])))
        {
            ChatGui.singleton.DisplayMessage(usage, ChatClient.ERROR_COLOR);
        }
        else
        {
            str2 = args[0];
            if (string.IsNullOrEmpty(str2))
            {
                ChatGui.singleton.DisplayMessage(usage, ChatClient.ERROR_COLOR);
            }
            else
            {
                GRouting.SendAuthorityRpc(4, GRpcID.GroupAuthority_SettlementApplyLeave, new object[] { param, str2, isApply });
            }
        }
    }

    public static void SettlementCreate(string[] args, EntityId playerEntityId)
    {
        string str = args[0];
        if (!(CommandCore.RemoveCommandFromString(ref str) && !string.IsNullOrEmpty(str)))
        {
            ChatGui.singleton.DisplayMessage("Usage: SettlementCreate <Settlement Name>", ChatClient.ERROR_COLOR);
        }
        else
        {
            GRouting.SendAuthorityRpc(4, GRpcID.GroupAuthority_SettlementCreate, new object[] { str });
        }
    }

    public static void SettlementLeave(string[] args, EntityId playerEntityId)
    {
        string usage = "Usage: SettlementLeave <Settlement Name>, <Company Name>";
        SettlementApplyLeave(args, false, usage);
    }

    public static void SettlementsUpdated(uint mySettlementId)
    {
        playerSettlementId = mySettlementId;
        CompanyWindowGui.singleton.UpdateCompany();
    }

    public static bool SyncFixedUpdate()
    {
        if ((EntityDataClient.owner != null) && ((inviteFlag && (partyAlertId == uint.MaxValue)) && (partyInviteId != 0)))
        {
            partyAlertId = AlertsManagerGui.singleton.NewAlert(AlertsManagerGui.AlertType.PARTY, inviterName + " has invited you to join their party.", new AlertsManagerGui.OnAlertInteraction(GroupClient.OnAlertInteraction));
            inviteFlag = false;
        }
        return true;
    }

    public static void SyncStart()
    {
        SocietySync.SetUp(settlementsById, new SocietySync.SettlementsUpdateDelegate(GroupClient.SettlementsUpdated), companiesById, new SocietySync.CompaniesUpdateDelegate(GroupClient.CompaniesUpdated));
    }

    public static void VcAccept(string[] args, EntityId playerEntityId)
    {
        if (args.Length != 1)
        {
            ChatGui.singleton.DisplayMessage("Usage: VcAccept", ChatClient.ERROR_COLOR);
        }
        else if (companyInvite == null)
        {
            ChatGui.singleton.DisplayMessage("You do not have a pending company invite.", ChatClient.ERROR_COLOR);
        }
        else
        {
            GRouting.SendAuthorityRpc(4, GRpcID.GroupAuthority_CompanyInviteResponse, new object[] { companyInvite.companyId, (byte) 2 });
            companyInvite = null;
        }
    }

    public static void VcApply(string[] args, EntityId playerEntityId)
    {
        string str2;
        string str = args[0];
        if ((!CommandCore.RemoveCommandFromString(ref str) || !CommandCore.ExtractLongParam(ref str, out str2)) || string.IsNullOrEmpty(str))
        {
            ChatGui.singleton.DisplayMessage("Usage: VcApply <VC Name>, <Player>", ChatClient.ERROR_COLOR);
        }
        else
        {
            GRouting.SendAuthorityRpc(4, GRpcID.GroupAuthority_CompanyApply, new object[] { str2, str });
        }
    }

    public static void VcCreate(string[] args, EntityId playerEntityId)
    {
        string str = args[0];
        if (!(CommandCore.RemoveCommandFromString(ref str) && !string.IsNullOrEmpty(str)))
        {
            ChatGui.singleton.DisplayMessage("Usage: VcCreate <VC Name>", ChatClient.ERROR_COLOR);
        }
        else
        {
            GRouting.SendAuthorityRpc(4, GRpcID.GroupAuthority_CompanyCreate, new object[] { str });
            ChatGui.singleton.DisplayMessage("Creating VcCompany with name " + str + "...", ChatClient.DEFAULT_COLOR);
        }
    }

    public static void VcDecline(string[] args, EntityId playerEntityId)
    {
        if (args.Length != 1)
        {
            ChatGui.singleton.DisplayMessage("Usage: VcDecline", ChatClient.ERROR_COLOR);
        }
        else if (companyInvite == null)
        {
            ChatGui.singleton.DisplayMessage("You do not have a pending company invite.", ChatClient.ERROR_COLOR);
        }
        else
        {
            GRouting.SendAuthorityRpc(4, GRpcID.GroupAuthority_CompanyInviteResponse, new object[] { companyInvite.companyId, (byte) 1 });
            companyInvite = null;
        }
    }

    public static void VcGoals(string[] args, EntityId playerEntityId)
    {
        if (args.Length < 3)
        {
            ChatGui.singleton.DisplayMessage("Usage: VcGoals <vc name>, <goal> [goal goal...]", ChatClient.ERROR_COLOR);
        }
        else if (!CommandCore.RemoveCommandFromString(ref args[0]))
        {
            ChatGui.singleton.DisplayMessage("Usage: VcGoals <vc name>, <goal> [goal goal...]", ChatClient.ERROR_COLOR);
        }
        else
        {
            string param = null;
            if (!(CommandCore.ExtractLongParam(ref args[0], out param) && !string.IsNullOrEmpty(args[0])))
            {
                ChatGui.singleton.DisplayMessage("Usage: VcGoals <vc name>, <goal> [goal goal...]", ChatClient.ERROR_COLOR);
            }
            else
            {
                ulong num = CompanyIdFromName(param);
                if (num == 0L)
                {
                    ChatGui.singleton.DisplayMessage("You are not in company '" + param + "'.", ChatClient.ERROR_COLOR);
                }
                else
                {
                    string[] strArray = args[0].Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                    VentureCompanyRecord.Goal nONE = VentureCompanyRecord.Goal.NONE;
                    for (int i = 0; i < strArray.Length; i++)
                    {
                        if (i >= 2)
                        {
                            try
                            {
                                nONE = (VentureCompanyRecord.Goal) ((byte) (nONE | ((VentureCompanyRecord.Goal) Enum.Parse(typeof(VentureCompanyRecord.Goal), strArray[i], true))));
                            }
                            catch (ArgumentException)
                            {
                                ChatGui.singleton.DisplayMessage("Unknown goal: \"" + strArray[i] + "\", must be one of: " + GUtil.PrettyPrint(Enum.GetValues(typeof(VentureCompanyRecord.Goal)), ", ", ""), ChatClient.ERROR_COLOR);
                            }
                        }
                    }
                    GRouting.SendAuthorityRpc(4, GRpcID.GroupAuthority_CompanyGoalsToggle, new object[] { num, (byte) nONE });
                }
            }
        }
    }

    public static void VcIgnore(string[] args, EntityId playerEntityId)
    {
        if (args.Length != 1)
        {
            ChatGui.singleton.DisplayMessage("Usage: VcDecline", ChatClient.ERROR_COLOR);
        }
        else if (companyInvite == null)
        {
            ChatGui.singleton.DisplayMessage("You do not have a pending company invite.", ChatClient.ERROR_COLOR);
        }
        else
        {
            GRouting.SendAuthorityRpc(4, GRpcID.GroupAuthority_CompanyInviteResponse, new object[] { companyInvite.companyId, (byte) 0 });
            companyInvite = null;
        }
    }

    public static void VcInvite(string[] args, EntityId playerEntityId)
    {
        string str2;
        string str = args[0];
        if ((!CommandCore.RemoveCommandFromString(ref str) || !CommandCore.ExtractLongParam(ref str, out str2)) || string.IsNullOrEmpty(str))
        {
            ChatGui.singleton.DisplayMessage("Usage: VcInvite <VC Name>, <Player>", ChatClient.ERROR_COLOR);
        }
        else
        {
            ulong num = CompanyIdFromName(str2);
            if (num == 0L)
            {
                ChatGui.singleton.DisplayMessage("You are not in company '" + str2 + "'.", ChatClient.ERROR_COLOR);
            }
            else
            {
                GRouting.SendAuthorityRpc(4, GRpcID.GroupAuthority_CompanyInvite, new object[] { num, str });
            }
        }
    }

    public static void VcKick(string[] args, EntityId playerEntityId)
    {
        string str2;
        string str = args[0];
        if ((!CommandCore.RemoveCommandFromString(ref str) || !CommandCore.ExtractLongParam(ref str, out str2)) || string.IsNullOrEmpty(str))
        {
            ChatGui.singleton.DisplayMessage("Usage: VcKick <VC Name>, <Player>", ChatClient.ERROR_COLOR);
        }
        else
        {
            ulong num = CompanyIdFromName(str2);
            if (num == 0L)
            {
                ChatGui.singleton.DisplayMessage("You are not in company '" + str2 + "'.", ChatClient.ERROR_COLOR);
            }
            else
            {
                GRouting.SendAuthorityRpc(4, GRpcID.GroupAuthority_CompanyKick, new object[] { num, str });
            }
        }
    }

    public static void VcLeave(string[] args, EntityId playerEntityId)
    {
        string str = args[0];
        if (!(CommandCore.RemoveCommandFromString(ref str) && !string.IsNullOrEmpty(str)))
        {
            ChatGui.singleton.DisplayMessage("Usage: VcLeave <VC Name>", ChatClient.ERROR_COLOR);
        }
        else
        {
            ulong num = CompanyIdFromName(str);
            if (num == 0L)
            {
                ChatGui.singleton.DisplayMessage("You are not in company '" + str + "'.", ChatClient.ERROR_COLOR);
            }
            else
            {
                GRouting.SendAuthorityRpc(4, GRpcID.GroupAuthority_CompanyLeave, new object[] { num });
            }
        }
    }

    public static void VcRecruitMessage(string[] args, EntityId playerEntityId)
    {
        string param = null;
        string str2 = null;
        if (!CommandCore.RemoveCommandFromString(ref args[0]))
        {
            ChatGui.singleton.DisplayMessage("Usage: VcRecruitMessage <vc name>, <recruit message>", ChatClient.ERROR_COLOR);
        }
        else if (!(CommandCore.ExtractLongParam(ref args[0], out param) && !string.IsNullOrEmpty(args[0])))
        {
            ChatGui.singleton.DisplayMessage("Usage: VcRecruitMessage <vc name>, <recruit message>", ChatClient.ERROR_COLOR);
        }
        else
        {
            str2 = args[0];
            if (string.IsNullOrEmpty(str2))
            {
                ChatGui.singleton.DisplayMessage("Usage: VcRecruitMessage <vc name>, <recruit message>", ChatClient.ERROR_COLOR);
            }
            else
            {
                ulong num = CompanyIdFromName(param);
                if (num == 0L)
                {
                    ChatGui.singleton.DisplayMessage("You are not in company '" + param + "'.", ChatClient.ERROR_COLOR);
                }
                else if (str2.Length > 140)
                {
                    ChatGui.singleton.DisplayMessage(string.Concat(new object[] { "New Company Recruitment Message too long. Length: ", str2.Length, ", Max: ", 140 }), ChatClient.ERROR_COLOR);
                }
                else
                {
                    GRouting.SendAuthorityRpc(4, GRpcID.GroupAuthority_CompanyRecruitMessage, new object[] { num, str2 });
                }
            }
        }
    }

    public static void VcStatement(string[] args, EntityId playerEntityId)
    {
        string param = null;
        string str2 = null;
        if (!CommandCore.RemoveCommandFromString(ref args[0]))
        {
            ChatGui.singleton.DisplayMessage("Usage: VcStatement <vc name>, <statement>", ChatClient.ERROR_COLOR);
        }
        else if (!(CommandCore.ExtractLongParam(ref args[0], out param) && !string.IsNullOrEmpty(args[0])))
        {
            ChatGui.singleton.DisplayMessage("Usage: VcStatement <vc name>, <statement>", ChatClient.ERROR_COLOR);
        }
        else
        {
            ulong num = CompanyIdFromName(param);
            if (num == 0L)
            {
                ChatGui.singleton.DisplayMessage("You are not in company '" + param + "'.", ChatClient.ERROR_COLOR);
            }
            else
            {
                str2 = args[0];
                if (string.IsNullOrEmpty(str2))
                {
                    ChatGui.singleton.DisplayMessage("Usage: VcStatement <vc name>, <statement>", ChatClient.ERROR_COLOR);
                }
                else if (str2.Length > 400)
                {
                    ChatGui.singleton.DisplayMessage(string.Concat(new object[] { "New Company Statement too long. Length: ", str2.Length, ", Max: ", 400 }), ChatClient.ERROR_COLOR);
                }
                else
                {
                    GRouting.SendAuthorityRpc(4, GRpcID.GroupAuthority_CompanyStatement, new object[] { num, str2 });
                }
            }
        }
    }

    public class TerritoryClientVars
    {
        public ulong companyId;
        public string companyName;
        public ushort mapId;
        public uint settlementId;

        public TerritoryClientVars(ushort mapId_, ulong companyId_, uint settlementId_, string companyName_)
        {
            this.mapId = mapId_;
            this.companyId = companyId_;
            this.settlementId = settlementId_;
            this.companyName = companyName_;
        }
    }
}

