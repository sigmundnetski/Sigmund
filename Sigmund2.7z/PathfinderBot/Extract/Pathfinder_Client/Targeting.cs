﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using UnityEngine;

public static class Targeting
{
    private static EntityId _selectedEntityId;
    private static GameObject _selectedTarget;
    private static float _selectedTargetDistance = 0f;
    private static TargetBarGui targetBar;

    public static void CommandEvent(string[] args, EntityId playerEntityId)
    {
        string str = args[0];
        if (str != null)
        {
            if (!(str == "tabtarget"))
            {
                if (str == "escape")
                {
                    DeselectTarget();
                    goto Label_01CD;
                }
                if (str == "mousetarget")
                {
                    GameObject obj2;
                    Entity entity;
                    GetRaycastTarget(false, PlayerEntityClient.GetPlayer(), out obj2, out entity);
                    if (!((entity == null) || entity.dead))
                    {
                        DeselectTarget();
                        SelectTarget(obj2);
                    }
                    goto Label_01CD;
                }
                if (str == "selectparty")
                {
                    int result = 0;
                    if ((EntityDataClient.owner != null) && ((args.Length >= 2) && int.TryParse(args[1], out result)))
                    {
                        List<uint> list = new List<uint> {
                            EntityDataClient.owner.playerId
                        };
                        if (GroupClient.activeParty != null)
                        {
                            foreach (Party.PartyMember member in GroupClient.activeParty.GetMembers())
                            {
                                if (member.playerId != list[0])
                                {
                                    list.Add(member.playerId);
                                }
                            }
                        }
                        if ((result >= 0) && (result < list.Count))
                        {
                            Entity entityByPlayerId = EntityCore.GetEntityByPlayerId(list[result]);
                            if (entityByPlayerId != null)
                            {
                                DeselectTarget();
                                SelectTarget(entityByPlayerId.gameObject);
                            }
                        }
                    }
                    goto Label_01CD;
                }
            }
            else
            {
                ToggleEnemy();
                goto Label_01CD;
            }
        }
        GLog.LogWarning(new object[] { "unknown command: ", args });
    Label_01CD:
        FinalizeTargetBar();
    }

    private static void DeselectTarget()
    {
        if (_selectedTarget != null)
        {
            _selectedEntityId = EntityId.INVALID_ID;
            _selectedTarget = null;
            DebugClient.UpdateTarget(_selectedEntityId);
        }
    }

    private static void FinalizeTargetBar()
    {
        if (((_selectedTarget == null) && (targetBar != null)) && targetBar.IsShowing())
        {
            targetBar.Reset();
        }
    }

    public static void GetRaycastTarget(bool combatOnly, GameObject ignore, out GameObject clickedGO, out Entity entityVars)
    {
        RaycastHit hit;
        if (Physics.Raycast(Camera.main.ScreenPointToRay(InputManager.mousePosition), out hit, float.PositiveInfinity))
        {
            if (GetTargetEntity(combatOnly, hit.transform.gameObject, out clickedGO, out entityVars))
            {
                if (clickedGO == ignore)
                {
                    clickedGO = null;
                    entityVars = null;
                }
                if (CombatCore.OutsideStealthRange(entityVars.combat, CombatClient.playerCombatVars))
                {
                    clickedGO = null;
                    entityVars = null;
                }
            }
            else
            {
                clickedGO = hit.transform.gameObject;
                entityVars = null;
            }
        }
        else
        {
            clickedGO = null;
            entityVars = null;
        }
    }

    private static bool GetTargetEntity(bool combatOnly, GameObject gameObject, out GameObject entityGO, out Entity entityVars)
    {
        entityVars = null;
        for (int i = 0; (i < 3) && (gameObject != null); i++)
        {
            entityVars = EntityCore.GetEntity(gameObject);
            if (entityVars != null)
            {
                break;
            }
            gameObject = (gameObject.transform.parent != null) ? gameObject.transform.parent.gameObject : null;
        }
        entityGO = gameObject;
        bool flag = false;
        if ((gameObject != null) && (entityVars != null))
        {
            flag = GuiHelper.InViewFrustrum(CustomCamera.singleton.camera, EntityLoadClient.GetOverheadTrans(gameObject).position);
        }
        return ((entityVars != null) && flag);
    }

    public static void Init(Transform xform)
    {
        targetBar.Init(xform);
    }

    public static bool LoadingTickFinished()
    {
        _selectedTarget = null;
        targetBar = GameObject.Find("TargetBar").GetComponent<TargetBarGui>();
        GuiHelper.GuiAssertNotNull("Couldn't find target bar.", new object[] { targetBar });
        return true;
    }

    public static void SelectTarget(GameObject newTarget)
    {
        Entity entity = EntityCore.GetEntity(newTarget);
        _selectedTarget = newTarget;
        string name = "UNKNOWN";
        if (entity != null)
        {
            name = entity.EntityName;
            _selectedEntityId = entity.entityId;
            DebugClient.UpdateTarget(_selectedEntityId);
        }
        if (targetBar != null)
        {
            Transform overheadTrans = EntityLoadClient.GetOverheadTrans(_selectedTarget);
            targetBar.SetName(name, Conning.GetRelativeStrength(_selectedEntityId));
            targetBar.TargetSelected(overheadTrans, _selectedEntityId);
        }
    }

    private static GameObject[] SortTargetsByDistance()
    {
        int layerMask = 0xa00;
        layerMask |= 0x400;
        Collider[] colliderArray = Physics.OverlapSphere(EntityDataClient.owner.gameObject.transform.position, 40f, layerMask);
        Dictionary<GameObject, float> dictionary = new Dictionary<GameObject, float>();
        foreach (Collider collider in colliderArray)
        {
            GameObject obj2;
            Entity entity;
            if (GetTargetEntity(true, collider.gameObject, out obj2, out entity))
            {
                RaceData data;
                float num2 = CombatCore.StealthVisibilityPercentage(entity.combat, EntityDataClient.owner.combat);
                float num3 = Vector3.Distance(obj2.transform.position, EntityDataClient.owner.gameObject.transform.position);
                bool flag = num3 <= (40f * num2);
                bool tabTargetable = false;
                if ((entity.entityDefn != null) && RaceData.raceById.TryGetValue(entity.entityDefn.raceId, out data))
                {
                    tabTargetable = data.tabTargetable;
                }
                if (((flag && !entity.dead) && tabTargetable) && (!Conning.IsPlayer(entity.entityId) || Conning.IsHostilePlayer(entity.entityId)))
                {
                    dictionary[obj2] = num3;
                }
            }
        }
        return (from kvp in dictionary
            orderby kvp.Value
            select kvp.Key).ToArray<GameObject>();
    }

    public static bool SyncUpdate()
    {
        if (_selectedTarget == null)
        {
            _selectedEntityId = EntityId.INVALID_ID;
            _selectedTargetDistance = 0f;
            if (targetBar.IsShowing())
            {
                targetBar.Reset();
            }
        }
        else
        {
            _selectedTargetDistance = Vector3.Distance(_selectedTarget.transform.position, PlayerEntityClient.GetPlayer().transform.position);
        }
        targetBar.SyncUpdate(CombatCore.GetCombatVarsFromId(ref _selectedEntityId));
        return true;
    }

    private static void ToggleEnemy()
    {
        GameObject newTarget = null;
        GameObject[] array = SortTargetsByDistance();
        if (array.Length < 1)
        {
            DeselectTarget();
        }
        else
        {
            if (_selectedTarget == null)
            {
                newTarget = array[0];
            }
            else
            {
                int index = Array.IndexOf<GameObject>(array, _selectedTarget);
                if (index < (array.Length - 1))
                {
                    index++;
                }
                else
                {
                    index = 0;
                }
                DeselectTarget();
                newTarget = array[index];
            }
            SelectTarget(newTarget);
        }
    }

    public static void Untarget()
    {
        DeselectTarget();
        FinalizeTargetBar();
    }

    public static EntityId selectedEntityId
    {
        get
        {
            return _selectedEntityId;
        }
    }

    public static GameObject selectedTarget
    {
        get
        {
            return _selectedTarget;
        }
    }

    public static float selectedTargetDistance
    {
        get
        {
            return _selectedTargetDistance;
        }
    }
}

