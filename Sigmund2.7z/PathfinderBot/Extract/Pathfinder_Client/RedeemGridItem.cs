﻿using GNGUI;
using System;
using UnityEngine;

public class RedeemGridItem : MonoBehaviour
{
    private BasicItemData itemData;
    private UILabel itemLabel;
    private bool selected = false;
    private UILabel selectedLabel;

    public void OnClick()
    {
        int num;
        int num2;
        if (this.selected)
        {
            num = -1;
        }
        else
        {
            num = 1;
        }
        PlayerLoginClient.redeemItemIds.TryGetValue(this.itemData.id, out num2);
        num2 = Math.Max(num2 + num, 0);
        PlayerLoginClient.redeemItemIds[this.itemData.id] = num2;
        RedeemWindowGui.singleton.Populate();
    }

    public void OnTooltip(bool show)
    {
        if (!show)
        {
            UITooltip.ShowText((this.itemData == null) ? "<unknown item>" : this.itemData.description, base.gameObject);
        }
        else
        {
            UITooltip.ShowText(null, null);
        }
    }

    public void SetItem(int index, int staticItemId, bool _selected)
    {
        this.itemData = ItemDatabase.GetItem(staticItemId);
        this.selected = _selected;
        this.UpdateLabels();
        base.gameObject.name = this.itemData.displayName + index.ToString("D4");
    }

    public void SetSelection(bool setSelected)
    {
        this.selected = setSelected;
        this.UpdateLabels();
    }

    public void Start()
    {
        foreach (UILabel label in base.gameObject.GetComponentsInChildren<UILabel>())
        {
            if (label.name == "Item Label")
            {
                this.itemLabel = label;
            }
            else if (label.name == "Selected Label")
            {
                this.selectedLabel = label;
            }
        }
        GuiHelper.GuiAssertNotNull("Error starting RedeemWindowGui:", new object[] { this.itemLabel, this.selectedLabel });
        this.UpdateLabels();
    }

    public void ToggleSelect(GameObject self)
    {
        this.SetSelection(!this.selected);
    }

    private void UpdateLabels()
    {
        if (this.itemLabel != null)
        {
            this.itemLabel.text = (this.itemData == null) ? "<unknown item>" : this.itemData.displayName;
        }
        if (this.selectedLabel != null)
        {
            this.selectedLabel.text = this.selected ? "X" : "";
        }
    }
}

