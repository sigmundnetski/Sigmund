﻿using System;
using UnityEngine;

public class CharacterSelectTickMono : MonoBehaviour
{
    public string curState;
    public CharacterSelectTick myTick;
    public static CharacterSelectTickMono singleton;

    public void Awake()
    {
        singleton = this;
    }

    public void FixedUpdate()
    {
        this.myTick.FixedUpdate();
        this.curState = this.myTick.curState;
    }

    public void OnDestroy()
    {
        this.myTick.StopTicking();
        singleton = null;
    }

    public void Start()
    {
        this.myTick = new CharacterSelectTick();
    }

    public void Update()
    {
        this.myTick.Update();
    }
}

