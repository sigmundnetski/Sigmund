﻿using System;
using UnityEngine;

public class IdleAnimator : MonoBehaviour
{
    protected AnimController anim;

    public virtual void Awake()
    {
        this.anim = new GrannyController(base.gameObject);
    }

    public void Start()
    {
        this.anim.Start();
    }

    public void Update()
    {
        this.anim.ResetAllAnimInputs();
    }
}

