﻿using GNGUI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using UnityEngine;

public class AuctionHouseGui : FullscreenWindowGui
{
    public ToggleText activeFilterMajor;
    public ToggleText activeFilterMinor;
    private Tabs activeTab = Tabs.MARKET;
    private byte activeTier = 0;
    private UILabel bids;
    public List<ItemOffer> currentBidItems = new List<ItemOffer>();
    public InventoryItem currentItem = InventoryItem.EMPTY;
    public ItemOffer[] currentMarketItems = null;
    public List<ItemOffer> currentOrderItems = new List<ItemOffer>();
    private UILabel dayASP;
    private List<ToggleText> filterMajor = new List<ToggleText>();
    private List<ToggleText> filterMinorLess = new List<ToggleText>();
    private List<ToggleText> filterMinorMany = new List<ToggleText>();
    public const ulong G_TO_C = 0x2710L;
    public static Color HOVERED_TEXT = Color.white;
    private bool initialized = false;
    private ItemFullDescription itemDescription;
    private UIGrid itemSearchGrid;
    private bool keepFilters = false;
    private UILabel monthASP;
    private UILabel noItemsLabel;
    public static Color NORMAL_TEXT = new Color(0.94f, 0.89f, 0.66f, 1f);
    public const ulong P_TO_C = 0xf4240L;
    private const string PRICE_FORMAT_COPPER = "{0:d}c";
    private const string PRICE_FORMAT_GOLD = "{0:d}g {1:d2}s {2:d2}c";
    private const string PRICE_FORMAT_PLATINUM = "{0:d}p {1:d2}g {2:d2}s {3:d2}c";
    private const string PRICE_FORMAT_SILVER = "{0:d}s {1:d2}c";
    public const ulong S_TO_C = 100L;
    private string search;
    private UIInput searchInput;
    private GameObject searchItemPrefab;
    private List<AuctionSearchItemGui> searchItems = new List<AuctionSearchItemGui>();
    private UIScrollBar searchScroll;
    public static Color SELECTED_TEXT = new Color(0.29f, 0.55f, 0.39f, 1f);
    private UILabel sellers;
    public static AuctionHouseGui singleton;
    public int slotsMax;
    public int slotsUsed;
    private UIImageButton[] tabButtons = new UIImageButton[5];
    private AuctionHouseTabGui[] tabs = new AuctionHouseTabGui[5];
    private UIImageButton[] tierButtons = new UIImageButton[3];
    private UILabel totalFunds;
    private List<InventoryItem> visibleItems = new List<InventoryItem>();
    private UILabel weekASP;

    public void Awake()
    {
        singleton = this;
        this.OnAwake();
    }

    public void BidItem(ItemOffer item, uint quantity, ulong bidPrice)
    {
        AuctionHouseClient.BidItem(item, quantity, bidPrice);
        AuctionItemPopupGui.singleton.HideWindow();
    }

    public void BuyItem(ItemOffer item, uint quantity)
    {
        AuctionHouseClient.BuyItem(item, quantity);
        AuctionItemPopupGui.singleton.HideWindow();
    }

    public void CancelItem(ItemOffer item, ItemOffer.OfferType offerType)
    {
        AuctionHouseClient.CancelItem(item, offerType);
    }

    private void ChangeMajorFilter(GameObject filterGO)
    {
        if ((this.activeFilterMajor == null) || (filterGO != this.activeFilterMajor.gameObject))
        {
            foreach (ToggleText text in this.filterMajor)
            {
                if (filterGO == text.gameObject)
                {
                    text.SetActive(true);
                    this.activeFilterMajor = text;
                }
                else
                {
                    text.SetActive(false);
                }
            }
            this.activeFilterMinor = null;
            List<ItemCategoryData> list = ItemCategoryData.majorCategories[this.activeFilterMajor.filterName];
            List<ToggleText> filterMinorLess = this.filterMinorLess;
            if (list.Count > filterMinorLess.Count)
            {
                NGUITools.SetActive(this.filterMinorLess[0].transform.parent.gameObject, false);
                NGUITools.SetActive(this.filterMinorMany[0].transform.parent.gameObject, true);
                filterMinorLess = this.filterMinorMany;
            }
            else
            {
                NGUITools.SetActive(this.filterMinorLess[0].transform.parent.gameObject, true);
                NGUITools.SetActive(this.filterMinorMany[0].transform.parent.gameObject, false);
            }
            int num = 0;
            foreach (ItemCategoryData data in list)
            {
                if (num < filterMinorLess.Count)
                {
                    filterMinorLess[num].Init(data.minorDisplay, new int[] { data.id });
                }
                num++;
            }
            while (num < filterMinorLess.Count)
            {
                filterMinorLess[num].Init(string.Empty, new int[0]);
                num++;
            }
        }
    }

    private void ClearItemStats()
    {
        this.weekASP.text = string.Empty;
        this.dayASP.text = string.Empty;
        this.monthASP.text = string.Empty;
        this.sellers.text = string.Empty;
        this.bids.text = string.Empty;
    }

    public static void FakeBids(string[] args, EntityId playerEntityId)
    {
        singleton.currentBidItems.Clear();
        for (int i = 0; i < 15; i++)
        {
            InventoryItem item = new InventoryItem(ItemDatabase.itemById.First<KeyValuePair<int, BasicItemData>>().Value.id, (uint) (i + 1), (byte) (i % 6), 20);
            ItemOffer offer = new ItemOffer(Item.Container.INVALID, 0, ItemOffer.OfferType.BID, item, (ulong) ((0x4c4b40 * i) + 1), (ulong) ((0x3d0900 * i) + 1));
            singleton.currentBidItems.Add(offer);
        }
        GLog.Log(new object[] { from each in singleton.currentBidItems
            where each != null
            select each.item.ToString() + " " + PriceToString(each.curPrice) });
        if (singleton.activeTab == Tabs.BIDS)
        {
            singleton.tabs[(int) singleton.activeTab].ContentsChanged();
        }
    }

    public static void FakeMarket(string[] args, EntityId playerEntityId)
    {
        ItemOffer[] offerArray;
        if (singleton.currentMarketItems != null)
        {
            offerArray = null;
        }
        else
        {
            offerArray = new ItemOffer[15];
            for (int i = 0; i < offerArray.Length; i++)
            {
                InventoryItem item = new InventoryItem(ItemDatabase.itemById.First<KeyValuePair<int, BasicItemData>>().Value.id, (uint) (i + 1), (byte) (i % 6), 20);
                offerArray[i] = new ItemOffer(Item.Container.INVALID, 0, ItemOffer.OfferType.OFFER, item, (ulong) ((0x1388 * i) + 1), (ulong) ((0xfa0 * i) + 1));
            }
        }
        GLog.Log(new object[] { from each in offerArray select each.item.ToString() + " " + PriceToString(each.curPrice) });
        singleton.OnMarketUpdate(ItemDatabase.itemById.First<KeyValuePair<int, BasicItemData>>().Value.id, 1, offerArray);
    }

    public static void FakeOrders(string[] args, EntityId playerEntityId)
    {
        ItemOffer[] ordersAndBids = new ItemOffer[15];
        for (int i = 0; i < ordersAndBids.Length; i++)
        {
            if ((i % 4) == 0)
            {
                ordersAndBids[i] = null;
            }
            else
            {
                InventoryItem item = new InventoryItem(ItemDatabase.itemById.First<KeyValuePair<int, BasicItemData>>().Value.id, (uint) (i + 1), (byte) (i % 6), 20);
                ordersAndBids[i] = new ItemOffer(Item.Container.INVALID, 0, ItemOffer.OfferType.OFFER, item, (ulong) ((0xc350 * i) + 1), (ulong) ((0x9c40 * i) + 1));
            }
        }
        GLog.Log(new object[] { from each in ordersAndBids
            where each != null
            select each.item.ToString() + " " + PriceToString(each.curPrice) });
        singleton.OnOrdersBidsUpdate(ordersAndBids);
    }

    public static void FakeStats(string[] args, EntityId playerEntityId)
    {
        singleton.OnItemStatsUpdate();
    }

    public override void HideWindow()
    {
        if (WindowGuiUtils.escapeEvent && AuctionItemPopupGui.singleton.IsShowing())
        {
            AuctionItemPopupGui.singleton.HideWindow();
        }
        else
        {
            base.HideWindow();
        }
    }

    private void InitItemStats()
    {
        foreach (UILabel label in base.GetComponentsInChildren<UILabel>())
        {
            if (label.name == "AspAmount0Week")
            {
                this.weekASP = label;
            }
            else if (label.name == "AspAmount1Day")
            {
                this.dayASP = label;
            }
            else if (label.name == "AspAmount2Month")
            {
                this.monthASP = label;
            }
            else if (label.name == "AspAmount3Sellers")
            {
                this.sellers = label;
            }
            else if (label.name == "AspAmount4Bids")
            {
                this.bids = label;
            }
            else if (label.name == "NoItemsLabel")
            {
                this.noItemsLabel = label;
            }
            else if (label.name == "FundsAmount")
            {
                this.totalFunds = label;
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find required children.", new object[] { this.weekASP, this.dayASP, this.monthASP, this.sellers, this.bids, this.noItemsLabel, this.totalFunds });
        this.ClearItemStats();
        this.noItemsLabel.text = string.Empty;
        this.totalFunds.text = string.Empty;
    }

    private void InitSearch()
    {
        this.search = null;
        this.searchInput = base.GetComponentInChildren<UIInput>();
        foreach (UIScrollBar bar in base.GetComponentsInChildren<UIScrollBar>())
        {
            if (bar.name == "SearchScroll")
            {
                this.searchScroll = bar;
            }
        }
        foreach (UIImageButton button in base.GetComponentsInChildren<UIImageButton>())
        {
            if (button.name == "ButtonTier1")
            {
                this.tierButtons[0] = button;
                UIEventListener listener1 = UIEventListener.Get(button.gameObject);
                listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.OnTier1Click));
            }
            else if (button.name == "ButtonTier2")
            {
                this.tierButtons[1] = button;
                UIEventListener listener2 = UIEventListener.Get(button.gameObject);
                listener2.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener2.onClick, new UIEventListener.VoidDelegate(this.OnTier2Click));
            }
            else if (button.name == "ButtonTier3")
            {
                this.tierButtons[2] = button;
                UIEventListener listener3 = UIEventListener.Get(button.gameObject);
                listener3.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener3.onClick, new UIEventListener.VoidDelegate(this.OnTier3Click));
            }
        }
        foreach (UIGrid grid in base.GetComponentsInChildren<UIGrid>())
        {
            if (grid.name == "ItemSearchGrid")
            {
                this.itemSearchGrid = grid;
            }
        }
        foreach (ToggleText text in base.GetComponentsInChildren<ToggleText>())
        {
            if (text.transform.parent.name == "FiltersMajor")
            {
                this.filterMajor.Add(text);
                UIEventListener listener4 = UIEventListener.Get(text.gameObject);
                listener4.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener4.onClick, new UIEventListener.VoidDelegate(this.OnMajorFilterClick));
            }
            else if (text.transform.parent.name == "FiltersMinorMany")
            {
                this.filterMinorMany.Add(text);
                UIEventListener listener5 = UIEventListener.Get(text.gameObject);
                listener5.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener5.onClick, new UIEventListener.VoidDelegate(this.OnMinorFilterClick));
            }
            else if (text.transform.parent.name == "FiltersMinorLess")
            {
                this.filterMinorLess.Add(text);
                UIEventListener listener6 = UIEventListener.Get(text.gameObject);
                listener6.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener6.onClick, new UIEventListener.VoidDelegate(this.OnMinorFilterClick));
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find tier buttons.", this.tierButtons);
        GuiHelper.GuiAssertNotNull("Couldn't find required children.", new object[] { this.searchInput, this.itemSearchGrid });
        this.searchInput.onSubmit = (GNGUI.UIInput.OnSubmit) Delegate.Combine(this.searchInput.onSubmit, new GNGUI.UIInput.OnSubmit(this.OnSubmit));
        NGUITools.SetActive(this.filterMinorLess[0].transform.parent.gameObject, false);
        NGUITools.SetActive(this.filterMinorMany[0].transform.parent.gameObject, false);
    }

    private void InitTabs()
    {
        foreach (AuctionHouseTabGui gui in base.GetComponentsInChildren<AuctionHouseTabGui>())
        {
            string name = gui.name;
            if (name == null)
            {
                goto Label_00A0;
            }
            if (!(name == "Tab0Market"))
            {
                if (name == "Tab1Inventory")
                {
                    goto Label_0074;
                }
                if (name == "Tab2Bank")
                {
                    goto Label_007F;
                }
                if (name == "Tab3Orders")
                {
                    goto Label_008A;
                }
                if (name == "Tab4Bids")
                {
                    goto Label_0095;
                }
                goto Label_00A0;
            }
            this.tabs[0] = gui;
            continue;
        Label_0074:
            this.tabs[1] = gui;
            continue;
        Label_007F:
            this.tabs[2] = gui;
            continue;
        Label_008A:
            this.tabs[3] = gui;
            continue;
        Label_0095:
            this.tabs[4] = gui;
            continue;
        Label_00A0:;
            GLog.LogWarning(new object[] { "Unknown tab '" + gui.name + "'." });
        }
        foreach (UIImageButton button in base.GetComponentsInChildren<UIImageButton>())
        {
            if (button.name == "TabButton0Market")
            {
                this.tabButtons[0] = button;
                UIEventListener listener1 = UIEventListener.Get(button.gameObject);
                listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.OnTabMarketClick));
            }
            else if (button.name == "TabButton1Inventory")
            {
                this.tabButtons[1] = button;
                UIEventListener listener2 = UIEventListener.Get(button.gameObject);
                listener2.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener2.onClick, new UIEventListener.VoidDelegate(this.OnTabInventoryClick));
            }
            else if (button.name == "TabButton2Bank")
            {
                this.tabButtons[2] = button;
                UIEventListener listener3 = UIEventListener.Get(button.gameObject);
                listener3.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener3.onClick, new UIEventListener.VoidDelegate(this.OnTabBankClick));
            }
            else if (button.name == "TabButton3Orders")
            {
                this.tabButtons[3] = button;
                UIEventListener listener4 = UIEventListener.Get(button.gameObject);
                listener4.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener4.onClick, new UIEventListener.VoidDelegate(this.OnTabOrdersClick));
            }
            else if (button.name == "TabButton4Bids")
            {
                this.tabButtons[4] = button;
                UIEventListener listener5 = UIEventListener.Get(button.gameObject);
                listener5.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener5.onClick, new UIEventListener.VoidDelegate(this.OnTabBidsClick));
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find any tabs.", this.tabs);
        GuiHelper.GuiAssertNotNull("Couldn't find tab buttons.", this.tabButtons);
        if (!GUtil.internalMode)
        {
            NGUITools.SetActive(this.tabButtons[4].gameObject, false);
        }
    }

    public void ItemInterest(InventoryItem newItem, Tabs interestSource)
    {
        this.currentItem = newItem;
        this.itemDescription.ItemChanged(this.currentItem);
        this.SearchInterest(this.currentItem);
        for (int i = 0; i < this.tabs.Length; i++)
        {
            this.tabs[i].ItemInterest(this.currentItem);
        }
        if (interestSource != Tabs.MARKET)
        {
            this.ClearItemStats();
            AuctionHouseClient.ItemInterest(this.currentItem);
        }
        if (interestSource == Tabs.SEARCH)
        {
            this.OnTabChange(Tabs.MARKET);
        }
    }

    public bool LoadingTickFinished()
    {
        this.searchItemPrefab = UIClient.guiPrefabs["AuctionSearchItem"];
        int num = 0;
        foreach (KeyValuePair<string, List<ItemCategoryData>> pair in ItemCategoryData.majorCategories)
        {
            if (num < this.filterMajor.Count)
            {
                this.filterMajor[num].Init(pair.Key, ItemCategoryData.GetCategoryIds(pair.Key));
            }
            num++;
        }
        while (num < this.filterMajor.Count)
        {
            this.filterMajor[num].Init(string.Empty, new int[0]);
            num++;
        }
        this.OnMajorFilterClick(this.filterMajor[0].gameObject);
        this.OnTierChange(this.activeTier);
        foreach (AuctionHouseTabGui gui in this.tabs)
        {
            gui.LoadingTickFinished();
        }
        return true;
    }

    private void OnAwake()
    {
        ClientTick.auctionGuiLoadFinish = new GUtil.BoolFilterDelegate(this.LoadingTickFinished);
        ClientTick.auctionGuiTick = new GUtil.BoolFilterDelegate(this.SyncFixedUpdate);
    }

    public override void OnDestroy()
    {
        base.OnDestroy();
        singleton = null;
    }

    public void OnItemStatsUpdate()
    {
        this.RepopulateItemStats();
    }

    public void OnMajorFilterClick(GameObject filterGO)
    {
        this.ChangeMajorFilter(filterGO);
        this.searchScroll.scrollValue = 0f;
        this.RepopulateSearch(false);
    }

    public void OnMarketUpdate(int itemId, byte upgrade, ItemOffer[] newOffer)
    {
        if ((this.currentItem.staticItemId == itemId) && (this.currentItem.upgrade == upgrade))
        {
            this.currentMarketItems = newOffer;
            if (this.activeTab == Tabs.MARKET)
            {
                this.tabs[(int) this.activeTab].ContentsChanged();
            }
        }
    }

    public void OnMinorFilterClick(GameObject filterGO)
    {
        this.searchScroll.scrollValue = 0f;
        this.SetMinorFilter(filterGO, true);
    }

    public void OnOrdersBidsUpdate(ItemOffer[] ordersAndBids)
    {
        this.slotsMax = ordersAndBids.Length;
        this.slotsUsed = 0;
        this.currentOrderItems.Clear();
        this.currentBidItems.Clear();
        for (int i = 0; i < ordersAndBids.Length; i++)
        {
            if (ordersAndBids[i] != null)
            {
                this.slotsUsed++;
                if (ordersAndBids[i].offerType == ItemOffer.OfferType.OFFER)
                {
                    this.currentOrderItems.Add(ordersAndBids[i]);
                }
                else
                {
                    this.currentBidItems.Add(ordersAndBids[i]);
                }
            }
        }
        if ((this.activeTab == Tabs.ORDERS) || (this.activeTab == Tabs.BIDS))
        {
            this.tabs[(int) this.activeTab].ContentsChanged();
        }
    }

    public void OnOwnerBankUpdate()
    {
        if (this.activeTab == Tabs.BANK)
        {
            this.tabs[(int) this.activeTab].ContentsChanged();
        }
    }

    public void OnOwnerInvUpdate()
    {
        this.UpdateFunds();
        if (this.activeTab == Tabs.INVENTORY)
        {
            this.tabs[(int) this.activeTab].ContentsChanged();
        }
    }

    public void OnSearchItemSelected(InventoryItem item)
    {
        this.keepFilters = true;
        this.ItemInterest(item, Tabs.SEARCH);
    }

    public void OnSubmit(string input)
    {
        this.search = input.ToLower();
        this.RepopulateSearch(false);
    }

    public void OnTabBankClick(GameObject ignored)
    {
        this.OnTabChange(Tabs.BANK);
    }

    public void OnTabBidsClick(GameObject ignored)
    {
        this.OnTabChange(Tabs.BIDS);
    }

    private void OnTabChange(Tabs newTab)
    {
        if (this.activeTab != newTab)
        {
            this.activeTab = newTab;
            this.ShowTab();
        }
    }

    public void OnTabInventoryClick(GameObject ignored)
    {
        this.OnTabChange(Tabs.INVENTORY);
    }

    public void OnTabMarketClick(GameObject ignored)
    {
        this.OnTabChange(Tabs.MARKET);
    }

    public void OnTabOrdersClick(GameObject ignored)
    {
        this.OnTabChange(Tabs.ORDERS);
    }

    public void OnTier1Click(GameObject go)
    {
        this.OnTierChange(1);
    }

    public void OnTier2Click(GameObject go)
    {
        this.OnTierChange(2);
    }

    public void OnTier3Click(GameObject go)
    {
        this.OnTierChange(3);
    }

    private void OnTierChange(byte newTier)
    {
        if (this.activeTier == newTier)
        {
            this.activeTier = 0;
        }
        else
        {
            this.activeTier = newTier;
            BasicItemData item = ItemDatabase.GetItem(this.currentItem.staticItemId);
            if ((item != null) && (item.tier != this.activeTier))
            {
                this.ItemInterest(InventoryItem.EMPTY, Tabs.SEARCH);
            }
        }
        for (int i = 0; i < 3; i++)
        {
            int num2 = this.activeTier - 1;
            if (i == num2)
            {
                this.tierButtons[i].target.color = Color.white;
            }
            else
            {
                this.tierButtons[i].target.color = new Color(0.5f, 0.5f, 0.5f);
            }
        }
        this.RepopulateSearch(false);
    }

    public static string PriceToString(ulong price)
    {
        uint num = (uint) (price / ((ulong) 0xf4240L));
        price = price % ((ulong) 0xf4240L);
        uint num2 = (uint) (price / ((ulong) 0x2710L));
        price = price % ((ulong) 0x2710L);
        uint num3 = (uint) (price / ((ulong) 100L));
        uint num4 = (uint) (price % ((ulong) 100L));
        if (num > 0)
        {
            return string.Format("{0:d}p {1:d2}g {2:d2}s {3:d2}c", new object[] { num, num2, num3, num4 });
        }
        if (num2 > 0)
        {
            return string.Format("{0:d}g {1:d2}s {2:d2}c", num2, num3, num4);
        }
        if (num3 > 0)
        {
            return string.Format("{0:d}s {1:d2}c", num3, num4);
        }
        return string.Format("{0:d}c", num4);
    }

    private void RepopulateItemStats()
    {
        this.weekASP.text = PriceToString((ulong) GUtil.rng.Generate(5, 0x4c4b40));
        this.dayASP.text = PriceToString((ulong) GUtil.rng.Generate(5, 0x4c4b40));
        this.monthASP.text = PriceToString((ulong) GUtil.rng.Generate(5, 0x4c4b40));
        this.sellers.text = GUtil.rng.Generate(5, 0x1388).ToString();
        this.bids.text = GUtil.rng.Generate(5, 0xc350).ToString();
    }

    private void RepopulateSearch(bool forceRepop = false)
    {
        if (forceRepop || base.IsShowing())
        {
            this.visibleItems.Clear();
            foreach (KeyValuePair<int, BasicItemData> pair in ItemDatabase.itemById)
            {
                if (this.ValidItem(pair.Value))
                {
                    if (pair.Value.upgradable)
                    {
                        for (byte j = 0; j <= 5; j = (byte) (j + 1))
                        {
                            this.visibleItems.Add(new InventoryItem(pair.Value.id, 1, j, 20));
                        }
                    }
                    else
                    {
                        this.visibleItems.Add(new InventoryItem(pair.Value.id, 1, 0, 20));
                    }
                }
            }
            UIGrid.SetElementCount<AuctionSearchItemGui>(DragDropRoot.root, this.itemSearchGrid, this.searchItemPrefab, this.searchItems, this.visibleItems.Count);
            for (int i = 0; i < this.visibleItems.Count; i++)
            {
                this.searchItems[i].SetData(this.visibleItems[i]);
            }
        }
    }

    private void SearchInterest(InventoryItem item)
    {
        BasicItemData data = ItemDatabase.GetItem(item.staticItemId);
        if (data == null)
        {
            this.keepFilters = true;
        }
        if (!this.keepFilters)
        {
            List<ToggleText> filterMinorLess = this.filterMinorLess;
            foreach (ToggleText text in this.filterMajor)
            {
                if (Array.IndexOf<int>(text.filterIds, data.categoryId) != -1)
                {
                    this.ChangeMajorFilter(text.gameObject);
                    if (text.filterIds.Length > filterMinorLess.Count)
                    {
                        filterMinorLess = this.filterMinorMany;
                    }
                }
            }
            foreach (ToggleText text in filterMinorLess)
            {
                if (Array.IndexOf<int>(text.filterIds, data.categoryId) != -1)
                {
                    this.SetMinorFilter(text.gameObject, false);
                }
            }
        }
        this.keepFilters = false;
        for (int i = 0; i < this.searchItems.Count; i++)
        {
            this.searchItems[i].UpdateSelected(item);
        }
    }

    public void SellItem(InventoryItem item, uint quantity, ulong maxPrice, ulong minPrice, Item.Container source)
    {
        ItemOffer offer = new ItemOffer(Item.Container.INVALID, 0, ItemOffer.OfferType.OFFER, InventoryItem.ChangeQuantity(item, quantity), maxPrice, minPrice);
        AuctionHouseClient.SellItem(offer, source);
        AuctionItemPopupGui.singleton.HideWindow();
    }

    public void SetMinorFilter(GameObject filterGO, bool toggle)
    {
        bool flag = false;
        foreach (ToggleText text in this.filterMinorLess)
        {
            if (filterGO == text.gameObject)
            {
                if (toggle)
                {
                    text.ToggleActive();
                }
                else
                {
                    text.SetActive(true);
                }
                this.activeFilterMinor = text.isActive ? text : null;
                flag = true;
            }
            else
            {
                text.SetActive(false);
            }
        }
        if (!flag)
        {
            foreach (ToggleText text in this.filterMinorMany)
            {
                if (filterGO == text.gameObject)
                {
                    text.ToggleActive();
                    this.activeFilterMinor = text.isActive ? text : null;
                }
                else
                {
                    text.SetActive(false);
                }
            }
        }
        this.RepopulateSearch(false);
    }

    public static void ShowAH(string[] args, EntityId playerEntityId)
    {
        if (singleton != null)
        {
            singleton.ToggleWindowVisibility();
        }
    }

    private void ShowTab()
    {
        for (int i = 0; i < this.tabs.Length; i++)
        {
            if (i == this.activeTab)
            {
                this.tabs[i].ShowTab();
                this.tabButtons[i].target.color = Color.white;
            }
            else
            {
                this.tabs[i].HideTab();
                this.tabButtons[i].target.color = new Color(0.5f, 0.5f, 0.5f);
            }
        }
    }

    public void ShowTabItemInfo(string info)
    {
        if (info == null)
        {
            info = string.Empty;
        }
        this.noItemsLabel.text = info;
    }

    public override void ShowWindow()
    {
        this.RepopulateSearch(true);
        this.ShowTab();
        this.UpdateFunds();
        base.ShowWindow();
    }

    public void Start()
    {
        StaticDataService.RegisterCallback<ColorData>(new StaticDataService.StaticDataServiceCallback(AuctionHouseGui.UpdateColors));
        this.InitSearch();
        this.itemDescription = base.GetComponentInChildren<ItemFullDescription>();
        GuiHelper.GuiAssertNotNull("Couldn't find required children.", new object[] { this.itemDescription });
        this.itemDescription.ResetDescription();
        this.InitTabs();
        this.InitItemStats();
        base.Init(3, true);
    }

    public bool SyncFixedUpdate()
    {
        if (!this.initialized)
        {
            this.RepopulateSearch(true);
            this.UpdateFunds();
            this.initialized = true;
        }
        return true;
    }

    public static void UpdateColors(List<DataClass> ignored)
    {
        NORMAL_TEXT = ColorData.GetColorByName("text_auction_default", true);
        SELECTED_TEXT = ColorData.GetColorByName("text_auction_selected", true);
        HOVERED_TEXT = ColorData.GetColorByName("text_auction_hovered", true);
    }

    private void UpdateFunds()
    {
        if ((EntityDataClient.owner == null) || (EntityDataClient.owner.playerRecord == null))
        {
            this.totalFunds.text = "0c";
        }
        else
        {
            this.totalFunds.text = PriceToString(EntityDataClient.owner.playerRecord.bankCopper + InventoryClient.GetInventoryCoinTotal());
        }
    }

    private bool ValidItem(BasicItemData item)
    {
        bool flag = Array.IndexOf<int>(this.activeFilterMajor.filterIds, item.categoryId) != -1;
        bool flag2 = (this.activeFilterMinor == null) || (Array.IndexOf<int>(this.activeFilterMinor.filterIds, item.categoryId) != -1);
        bool flag3 = (this.activeTier == 0) || (this.activeTier == item.tier);
        string str = item.displayName.ToLower();
        bool flag4 = string.IsNullOrEmpty(this.search) || str.Contains(this.search);
        return (((flag && flag2) && flag3) && flag4);
    }

    public enum Tabs
    {
        MARKET,
        INVENTORY,
        BANK,
        ORDERS,
        BIDS,
        NUM_TABS,
        SEARCH
    }
}

