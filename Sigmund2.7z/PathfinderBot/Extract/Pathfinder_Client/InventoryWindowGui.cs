﻿using GNGUI;
using System;
using System.Collections.Generic;
using UnityEngine;

public class InventoryWindowGui : ItemWindowGui
{
    private Tabs activeTab = Tabs.EQUIPMENT;
    private InventoryTabGui[] allTabs = new InventoryTabGui[3];
    private UILabel coinAmount;
    private UIFilledSprite encumbrance100;
    private UIFilledSprite encumbrance200;
    public static InventoryWindowGui singleton;

    public void AllTabSelected(GameObject button)
    {
        Tabs activeTab = this.activeTab;
        this.activeTab = Tabs.ALL;
        if (this.activeTab != activeTab)
        {
            this.ShowTab();
            PaperdollWindowGui.singleton.ResetValidity(PaperdollWindowGui.FilterType.EQUIPMENT);
        }
    }

    public void Awake()
    {
        singleton = this;
        this.OnAwake();
    }

    public void ContentsChanged()
    {
        if (base.IsShowing())
        {
            this.GetActiveTab().ContentsChanged();
            this.UpdateCoin();
        }
    }

    public void CraftingTabSelected(GameObject button)
    {
        Tabs activeTab = this.activeTab;
        this.activeTab = Tabs.CRAFTING;
        if (this.activeTab != activeTab)
        {
            this.ShowTab();
            PaperdollWindowGui.singleton.ResetValidity(PaperdollWindowGui.FilterType.EQUIPMENT);
        }
    }

    public override void DragEnd(InventoryItem item, BasicItemData.ItemSlot slot)
    {
        PaperdollWindowGui.singleton.DragEnd(item, slot);
        this.GetActiveTab().RepositionListItems();
    }

    public override void DragStart(InventoryItem item)
    {
        PaperdollWindowGui.singleton.DragStart(item);
    }

    public void EquipmentSlotClicked(EquipmentSlotGui slotGui)
    {
        if (this.activeTab != Tabs.EQUIPMENT)
        {
            this.activeTab = Tabs.EQUIPMENT;
            this.ShowTab();
        }
        if (!base.IsShowing())
        {
            this.ShowWindow();
        }
        InventoryTabGui activeTab = this.GetActiveTab();
        List<ToggleText> allFilters = activeTab.allFilters;
        foreach (ToggleText text in allFilters)
        {
            if (slotGui.IsValid(text.filterIds))
            {
                activeTab.FilterClicked(text.gameObject);
                break;
            }
        }
    }

    public void EquipmentTabSelected(GameObject button)
    {
        Tabs activeTab = this.activeTab;
        this.activeTab = Tabs.EQUIPMENT;
        if (this.activeTab != activeTab)
        {
            this.ShowTab();
            PaperdollWindowGui.singleton.SetValidityByFilter(PaperdollWindowGui.FilterType.EQUIPMENT, this.GetActiveTab().activeFilter);
        }
    }

    public InventoryTabGui GetActiveTab()
    {
        return this.allTabs[(int) this.activeTab];
    }

    public override void HideWindow()
    {
        base.HideWindow();
        this.GetActiveTab().HideTab();
        PaperdollWindowGui.singleton.ResetValidity(PaperdollWindowGui.FilterType.EQUIPMENT);
    }

    public override void ItemInteract(ItemGui item, ItemWindowGui.Interaction interaction)
    {
        if (interaction == ItemWindowGui.Interaction.DROP)
        {
            if (item is LootItemGui)
            {
                InventoryItem item2 = base.AdjustItemOnInteract(item.item, interaction);
                LootWindowGui.singleton.TakeItem(item2);
            }
            if ((item is InventoryItemGui) && BankWindowGui.singleton.IsShowing())
            {
                BankWindowGui.singleton.RemoveItem(item, interaction);
            }
        }
        else if (!TradeWindowGui.singleton.IsShowing() || !BankWindowGui.singleton.IsShowing())
        {
            if (TradeWindowGui.singleton.IsShowing())
            {
                TradeWindowGui.singleton.AddItem(item, interaction);
            }
            else if (BankWindowGui.singleton.IsShowing())
            {
                BankWindowGui.singleton.AddItem(item, interaction);
            }
        }
    }

    public bool LoadingTickFinished()
    {
        foreach (InventoryTabGui gui in this.allTabs)
        {
            gui.LoadingTickFinished();
        }
        return true;
    }

    private void OnAwake()
    {
        ClientTick.invGuiLoadFinish = new GUtil.BoolFilterDelegate(this.LoadingTickFinished);
        foreach (Collider collider in base.GetComponentsInChildren<Collider>())
        {
            if (collider.name == "CoinParent")
            {
                UIEventListener listener1 = UIEventListener.Get(collider.gameObject);
                listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.OnCoinClick));
            }
        }
        foreach (UILabel label in base.GetComponentsInChildren<UILabel>())
        {
            if (label.name == "CoinAmount")
            {
                this.coinAmount = label;
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find needed children.", new object[] { this.coinAmount });
        this.coinAmount.text = AuctionHouseGui.PriceToString(0L);
        foreach (InventoryTabGui gui in base.GetComponentsInChildren<InventoryTabGui>())
        {
            string name = gui.name;
            if (name == null)
            {
                goto Label_016E;
            }
            if (!(name == "TabEquipment"))
            {
                if (name == "TabCrafting")
                {
                    goto Label_0158;
                }
                if (name == "TabAll")
                {
                    goto Label_0163;
                }
                goto Label_016E;
            }
            this.allTabs[0] = gui;
            continue;
        Label_0158:
            this.allTabs[1] = gui;
            continue;
        Label_0163:
            this.allTabs[2] = gui;
            continue;
        Label_016E:;
            GLog.LogWarning(new object[] { "Unknown tab '" + gui.name + "'." });
        }
        GuiHelper.GuiAssertNotNull("Couldn't find needed tabs.", this.allTabs);
        foreach (UIFilledSprite sprite in base.GetComponentsInChildren<UIFilledSprite>())
        {
            if (sprite.name == "EncumbranceSlider100")
            {
                this.encumbrance100 = sprite;
            }
            else if (sprite.name == "EncumbranceSlider200")
            {
                this.encumbrance200 = sprite;
            }
            sprite.fillAmount = 0f;
        }
        GuiHelper.GuiAssertNotNull("Encumbrance meters", new object[] { this.encumbrance100, this.encumbrance200 });
        foreach (Collider collider in base.GetComponentsInChildren<Collider>())
        {
            if (collider.name == "ButtonAll")
            {
                UIEventListener listener2 = UIEventListener.Get(collider.gameObject);
                listener2.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener2.onClick, new UIEventListener.VoidDelegate(this.AllTabSelected));
            }
            else if (collider.name == "ButtonEquipment")
            {
                UIEventListener listener3 = UIEventListener.Get(collider.gameObject);
                listener3.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener3.onClick, new UIEventListener.VoidDelegate(this.EquipmentTabSelected));
            }
            else if (collider.name == "ButtonCrafting")
            {
                UIEventListener listener4 = UIEventListener.Get(collider.gameObject);
                listener4.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener4.onClick, new UIEventListener.VoidDelegate(this.CraftingTabSelected));
            }
        }
    }

    public void OnCoinClick(GameObject ignored)
    {
    }

    public override void OnDestroy()
    {
        base.OnDestroy();
        singleton = null;
    }

    public void ShowTab()
    {
        for (int i = 0; i < this.allTabs.Length; i++)
        {
            if (i == this.activeTab)
            {
                this.allTabs[i].ShowTab();
            }
            else
            {
                this.allTabs[i].HideTab();
            }
        }
    }

    public override void ShowWindow()
    {
        base.ShowWindow();
        this.ShowTab();
    }

    public void Start()
    {
        foreach (InventoryTabGui gui in this.allTabs)
        {
            gui.Init(this);
            gui.HideTab();
        }
        base.Init(3, true);
    }

    public void ToggleInventoryWindow(string[] args, EntityId playerEntityId)
    {
        this.ToggleWindowVisibility();
        if (base.IsShowing() && (this.activeTab == Tabs.EQUIPMENT))
        {
            PaperdollWindowGui.singleton.SetValidityByFilter(PaperdollWindowGui.FilterType.EQUIPMENT, this.GetActiveTab().activeFilter);
        }
    }

    public void UpdateCoin()
    {
        this.coinAmount.text = AuctionHouseGui.PriceToString(InventoryClient.GetInventoryCoinTotal());
    }

    public void UpdateEncumbrance(float percent)
    {
        this.encumbrance100.fillAmount = percent;
        this.encumbrance200.fillAmount = percent - 1f;
    }

    public enum Tabs
    {
        EQUIPMENT,
        CRAFTING,
        ALL,
        NUM_TABS
    }
}

