﻿using GNetwork;
using System;
using UnityEngine;

public static class TerrainClient
{
    private static ushort[] mapIds;
    private static bool[] neighborStatuses;
    private static GameObject[] neighborWalls;
    private static bool renderWalls;

    static TerrainClient()
    {
        int num;
        renderWalls = true;
        mapIds = new ushort[3];
        neighborStatuses = new bool[6 * mapIds.Length];
        neighborWalls = new GameObject[6 * mapIds.Length];
        for (num = 0; num < mapIds.Length; num++)
        {
            mapIds[num] = 0;
        }
        for (num = 0; num < neighborStatuses.Length; num++)
        {
            neighborStatuses[num] = false;
            neighborWalls[num] = null;
        }
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void NeighborHexStatus(ushort mapId, bool N, bool NE, bool SE, bool S, bool SW, bool NW)
    {
        if (TerrainService.InUse)
        {
            int num3;
            int index = -1;
            int num2 = -1;
            for (num3 = 0; num3 < mapIds.Length; num3++)
            {
                if (mapIds[num3] == mapId)
                {
                    index = num3;
                    break;
                }
                if (mapIds[num3] == 0)
                {
                    num2 = num3;
                }
            }
            if (index == -1)
            {
                index = num2;
            }
            if (index != -1)
            {
                if (mapIds[index] != mapId)
                {
                    mapIds[index] = mapId;
                    PopulateWallsForHex(mapId, index);
                }
                int num4 = index * 6;
                neighborStatuses[num4] = N;
                neighborStatuses[num4 + 1] = NE;
                neighborStatuses[num4 + 2] = SE;
                neighborStatuses[num4 + 3] = S;
                neighborStatuses[num4 + 4] = SW;
                neighborStatuses[num4 + 5] = NW;
                for (num3 = num4; num3 < (num4 + 6); num3++)
                {
                    if (neighborWalls[num3] != null)
                    {
                        neighborWalls[num3].SetActive(!neighborStatuses[num3]);
                    }
                }
            }
        }
    }

    public static void OnSayonara(ushort mapId)
    {
        for (int i = 0; i < mapIds.Length; i++)
        {
            if (mapIds[i] == mapId)
            {
                int num2 = i * 6;
                for (int j = num2; j < (num2 + 6); j++)
                {
                    neighborStatuses[j] = false;
                    neighborWalls[j].SetActive(false);
                }
                mapIds[i] = 0;
                break;
            }
        }
    }

    private static void PopulateWallsForHex(ushort mapId, int index)
    {
        Vector3 worldPosition = TerrainService.TranslateServerToLocal(mapId, Vector3.zero);
        int num = index * 6;
        for (int i = num; i < (num + 6); i++)
        {
            Vector3 vector2 = TerrainService.TranslateServerToLocal(mapId, TerrainUtils.GetBorderCenter((HexAdjacentDirection) ((byte) (i - num))));
            if (neighborWalls[i] == null)
            {
                neighborWalls[i] = UnityEngine.Object.Instantiate(UIClient.guiPrefabs["HexBoundaryWall"]) as GameObject;
                neighborWalls[i].name = string.Concat(new object[] { "wall_", index, "_", (HexAdjacentDirection) ((byte) (i - num)) });
                neighborWalls[i].transform.parent = TerrainService.TerrainParent;
            }
            neighborWalls[i].SetActive(false);
            neighborWalls[i].transform.position = vector2;
            neighborWalls[i].transform.LookAt(worldPosition);
        }
    }

    public static bool Shutdown()
    {
        int num;
        for (num = 0; num < mapIds.Length; num++)
        {
            mapIds[num] = 0;
        }
        for (num = 0; num < neighborStatuses.Length; num++)
        {
            neighborStatuses[num] = false;
            if (neighborWalls[num] != null)
            {
                UnityEngine.Object.Destroy(neighborWalls[num]);
                neighborWalls[num] = null;
            }
        }
        TerrainService.ResetService();
        return true;
    }

    public static bool SyncFixedUpdate()
    {
        if (TerrainService.InUse)
        {
            Entity owner = EntityDataClient.owner;
            if (owner == null)
            {
                return true;
            }
            float tileOffsetX = TerrainService.GetTileOffsetX(TerrainService.CurrentTile.x);
            float tileOffsetZ = TerrainService.GetTileOffsetZ(TerrainService.CurrentTile.z);
            Vector3 localPosition = owner.GetLocalPosition();
            if ((((localPosition.x < (tileOffsetX - 80f)) || (localPosition.x > ((tileOffsetX + 1024f) + 80f))) || (localPosition.z < (tileOffsetZ - 80f))) || (localPosition.z > ((tileOffsetZ + 1024f) + 80f)))
            {
                IntVec2 tile = TerrainUtils.GetTileForPosition(TerrainService.InitialHex, TerrainService.CurrentTile, localPosition);
                if (TerrainService.IsTileLoaded(tile))
                {
                    TerrainService.UnloadOldTiles(tile);
                    TerrainService.LoadMissingTiles(tile, false);
                }
                else
                {
                    EntityMotion component = PlayerEntityClient.GetPlayer().GetComponent<EntityMotion>();
                    component.LockPosition(BaseMotion.PositionLock.External, "Cannot move until interaction window is closed.");
                    TerrainService.ForceLoadTiles(tile);
                    component.UnlockPosition(BaseMotion.PositionLock.External);
                }
            }
        }
        return true;
    }

    public static void ToggleHexBoundaries(string[] args, EntityId playerEntityId)
    {
        int num;
        if (args.Length == 1)
        {
            renderWalls = !renderWalls;
        }
        else if (args.Length > 1)
        {
            string str = args[1].ToLower();
            switch (str)
            {
                case "on":
                case "true":
                case "enable":
                case "1":
                    renderWalls = true;
                    goto Label_0106;
            }
            if ((((str == "off") || (str == "false")) || (str == "disable")) || (str == "0"))
            {
                renderWalls = false;
            }
            else if (str == "down_edge")
            {
                renderWalls = !renderWalls;
            }
            else
            {
                DebugClient.DisplayDebugMessage("ToggleHexBoundaries: invalid parameter - " + args[1] + ".  Use on/off, true/false, enable/disable.");
                return;
            }
        }
    Label_0106:
        num = 0;
        while (num < neighborWalls.Length)
        {
            if (neighborWalls[num] != null)
            {
                neighborWalls[num].renderer.enabled = renderWalls;
            }
            num++;
        }
    }

    public static void UpdateCurrentMap(ushort mapId)
    {
        if (TerrainService.InUse)
        {
            int num2;
            TerrainService.OnMapTransfer(mapId);
            int index = -1;
            for (num2 = 0; num2 < mapIds.Length; num2++)
            {
                if (mapIds[num2] == mapId)
                {
                    index = num2;
                    mapIds[index] = 0;
                    break;
                }
            }
            mapIds[0] = mapId;
            PopulateWallsForHex(mapId, 0);
            if (index != -1)
            {
                int num3 = index * 6;
                for (num2 = 0; num2 < 6; num2++)
                {
                    neighborStatuses[num2] = neighborStatuses[num2 + num3];
                    neighborWalls[num2].SetActive(!neighborStatuses[num2]);
                    if (neighborWalls[num2 + num3] != null)
                    {
                        neighborWalls[num2 + num3].SetActive(false);
                    }
                }
            }
        }
    }
}

