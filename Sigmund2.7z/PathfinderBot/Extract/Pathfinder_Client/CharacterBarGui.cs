﻿using GNGUI;
using System;
using UnityEngine;

public abstract class CharacterBarGui : MonoBehaviour
{
    private static readonly Color[] aliveColors;
    protected BuffRibbon[] buffRibbons;
    private static readonly Color[] deadColors;
    private static readonly Combat.Channel[] HIT_POINT_CHANNELS = new Combat.Channel[] { Combat.Channel.Submission, Combat.Channel.Torment, Combat.Channel.Weakness, Combat.Channel.None };
    protected UIFilledSprite[] hitPointBars = new UIFilledSprite[4];

    static CharacterBarGui()
    {
        Color[] colorArray = new Color[] { new Color(1f, 0.9529412f, 0.6509804f), new Color(1f, 0.7333333f, 0.1647059f), new Color(0.6392157f, 0.1607843f, 0.03137255f), new Color(1f, 1f, 1f) };
        aliveColors = colorArray;
        colorArray = new Color[] { new Color(0.5f, 0.4764706f, 0.3254902f), new Color(0.5f, 0.3666667f, 0.08235294f), new Color(0.3196079f, 0.08039216f, 0.01568628f), new Color(0.5f, 0.5f, 0.5f) };
        deadColors = colorArray;
    }

    protected CharacterBarGui()
    {
    }

    public virtual void Awake()
    {
        this.buffRibbons = base.GetComponentsInChildren<BuffRibbon>();
        foreach (BuffRibbon ribbon in this.buffRibbons)
        {
            if (ribbon.name == "RibbonAttack")
            {
                ribbon.Init(BuffRibbon.RibbonType.ATTACK);
            }
            else if (ribbon.name == "RibbonDefense")
            {
                ribbon.Init(BuffRibbon.RibbonType.DEFENSE);
            }
            else if (ribbon.name == "RibbonResistance")
            {
                ribbon.Init(BuffRibbon.RibbonType.RESISTANCE);
            }
            else if (ribbon.name == "RibbonSpeed")
            {
                ribbon.Init(BuffRibbon.RibbonType.SPEED);
            }
        }
        foreach (UIFilledSprite sprite in base.GetComponentsInChildren<UIFilledSprite>())
        {
            if (sprite.name == "HealthPredicted2")
            {
                this.hitPointBars[0] = sprite;
            }
            else if (sprite.name == "HealthPredicted1")
            {
                this.hitPointBars[1] = sprite;
            }
            else if (sprite.name == "HealthPredicted0")
            {
                this.hitPointBars[2] = sprite;
            }
            else if (sprite.name == "HealthCurrent")
            {
                this.hitPointBars[3] = sprite;
            }
        }
        GuiHelper.GuiAssertNotNull("Could not find all hit point bars!", this.hitPointBars);
    }

    protected float GetHitPointPercentage(int hitPoints, CombatVars cv, Combat.Channel channel)
    {
        if (cv.hitPoints > 0)
        {
            return Mathf.Max((float) (((float) hitPoints) / ((float) cv.GetMaxHitPoints())), (float) 0f);
        }
        int num2 = -CombatData.singleton.deathHitpointThreshold;
        return (((float) (num2 + hitPoints)) / ((float) num2));
    }

    public virtual void Hide()
    {
        NGUITools.SetActive(base.gameObject, false);
    }

    public bool IsShowing()
    {
        return NGUITools.GetActive(base.gameObject);
    }

    protected void SetHitPoints(CombatVars cv)
    {
        Color[] aliveColors = CharacterBarGui.aliveColors;
        if (cv.deathState != CombatVars.DeathState.Alive)
        {
            aliveColors = deadColors;
        }
        int num = 0;
        for (int i = 0; i < HIT_POINT_CHANNELS.Length; i++)
        {
            Combat.Channel channel = HIT_POINT_CHANNELS[i];
            float num3 = 0f;
            if ((cv.hitPointRBCV.GetBonus(channel) != 0) || (channel == Combat.Channel.None))
            {
                num3 = this.GetHitPointPercentage(cv.hitPoints - num, cv, channel);
                num += CombatStackBuff.GetDotDamage(cv.hitPointRBCV.GetBonus(channel), cv);
            }
            this.hitPointBars[i].fillAmount = num3;
            this.hitPointBars[i].color = aliveColors[i];
        }
    }

    public abstract void SetName(string name, Conning.Strength strength);
    public abstract void SetPower(float powerPercentage, int power);
    public abstract void SetStamina(float staminaPercentage, int stamina);
    public virtual void Show()
    {
        NGUITools.SetActive(base.gameObject, true);
    }

    public virtual void SyncUpdateCv(CombatVars cv)
    {
        this.UpdateBuffRibbons(cv);
        if (cv != null)
        {
            this.SetHitPoints(cv);
            float staminaPercentage = ((float) cv.stamina) / ((float) CombatData.singleton.staminaLimit);
            float powerPercentage = ((float) cv.power) / ((float) cv.GetMaxPower());
            this.SetStamina(staminaPercentage, cv.stamina);
            this.SetPower(powerPercentage, cv.power);
        }
    }

    private void UpdateBuffRibbons(CombatVars cv)
    {
        for (int i = 0; i < this.buffRibbons.Length; i++)
        {
            this.buffRibbons[i].SyncUpdate(cv);
        }
    }
}

