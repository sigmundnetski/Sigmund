﻿using System;
using UnityEngine;

public class FxPool : MonoBehaviour
{
    private void Awake()
    {
        FxService.RegisterPool(this);
    }

    private void OnDestroy()
    {
        FxService.ClearInstances();
    }
}

