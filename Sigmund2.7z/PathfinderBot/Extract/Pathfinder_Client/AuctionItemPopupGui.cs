﻿using GNGUI;
using System;
using System.Runtime.InteropServices;
using UnityEngine;

public class AuctionItemPopupGui : WindowGui
{
    private UIImageButton bidButton;
    private GameObject bidParent;
    private UIInput bidPriceInput;
    private UIInput bidQuantityInput;
    private UILabel bidTotalPriceLabel;
    private UIImageButton buyButton;
    private GameObject buyParent;
    private UILabel buyPriceLabel;
    private UIInput buyQuantityInput;
    private UILabel buyTotalPriceLabel;
    private ItemOffer currentItem;
    public InputType currentType = InputType.NONE;
    private UILabel errorLabel;
    private ItemFullDescription itemDescription;
    private Item.Container itemSource;
    private UIInput maxPriceInput;
    private UIInput minPriceInput;
    private const string POSTFIX_COPPER = "c";
    private const string POSTFIX_GOLD = "g";
    private const string POSTFIX_PLATINUM = "p";
    private const string POSTFIX_SILVER = "s";
    private UIImageButton sellButton;
    private GameObject sellParent;
    private UIInput sellQuantityInput;
    public static AuctionItemPopupGui singleton;

    public void Awake()
    {
        singleton = this;
        this.OnAwake();
    }

    public void FocusNext(UIInput nextInput)
    {
        UICamera.selectedObject = nextInput.gameObject;
        nextInput.selected = true;
    }

    private uint GetQuantity(string input, bool maxStack)
    {
        uint quantity;
        if (!(uint.TryParse(input, out quantity) && (!maxStack || (quantity <= this.currentItem.item.quantity))))
        {
            this.sellQuantityInput.text = this.currentItem.item.quantity.ToString();
            quantity = this.currentItem.item.quantity;
        }
        if (quantity == 0)
        {
            this.sellQuantityInput.text = "1";
            quantity = 1;
        }
        return quantity;
    }

    public override void HideWindow()
    {
        this.currentItem = null;
        this.errorLabel.text = string.Empty;
        this.InputVisible(InputType.NONE);
        base.HideWindow();
    }

    private void InputVisible(InputType type)
    {
        switch (type)
        {
            case InputType.NONE:
                NGUITools.SetActive(this.sellParent, false);
                NGUITools.SetActive(this.buyParent, false);
                NGUITools.SetActive(this.bidParent, false);
                break;

            case InputType.SELL:
                NGUITools.SetActive(this.sellParent, true);
                NGUITools.SetActive(this.buyParent, false);
                NGUITools.SetActive(this.bidParent, false);
                break;

            case InputType.BUY:
                NGUITools.SetActive(this.sellParent, false);
                NGUITools.SetActive(this.buyParent, true);
                NGUITools.SetActive(this.bidParent, false);
                break;

            case InputType.BID:
                NGUITools.SetActive(this.sellParent, false);
                NGUITools.SetActive(this.buyParent, false);
                NGUITools.SetActive(this.bidParent, true);
                break;
        }
    }

    private void OnAwake()
    {
        base.disableAutoZ = true;
        foreach (UILabel label in base.GetComponentsInChildren<UILabel>())
        {
            if (label.name == "ErrorLabel")
            {
                this.errorLabel = label;
            }
            else if (label.name == "BuyPriceAmount")
            {
                this.buyPriceLabel = label;
            }
            else if (label.name == "TotalBuyPriceAmount")
            {
                this.buyTotalPriceLabel = label;
            }
            else if (label.name == "TotalBidPriceAmount")
            {
                this.bidTotalPriceLabel = label;
            }
        }
        foreach (UIInput input in base.GetComponentsInChildren<UIInput>())
        {
            if (input.name == "SellQuantityInput")
            {
                this.sellQuantityInput = input;
                this.sellQuantityInput.onSubmit = (UIInput.OnSubmit) Delegate.Combine(this.sellQuantityInput.onSubmit, new UIInput.OnSubmit(this.OnSellQuantitySubmit));
                UIEventListener listener1 = UIEventListener.Get(this.sellQuantityInput.gameObject);
                listener1.onSelect = (UIEventListener.BoolDelegate) Delegate.Combine(listener1.onSelect, new UIEventListener.BoolDelegate(this.OnSellQuantitySelect));
                this.sellParent = this.sellQuantityInput.transform.parent.gameObject;
            }
            else if (input.name == "BuyQuantityInput")
            {
                this.buyQuantityInput = input;
                this.buyQuantityInput.onSubmit = (UIInput.OnSubmit) Delegate.Combine(this.buyQuantityInput.onSubmit, new UIInput.OnSubmit(this.OnBuyQuantitySubmit));
                UIEventListener listener2 = UIEventListener.Get(this.buyQuantityInput.gameObject);
                listener2.onSelect = (UIEventListener.BoolDelegate) Delegate.Combine(listener2.onSelect, new UIEventListener.BoolDelegate(this.OnBuyQuantitySelect));
                this.buyParent = this.buyQuantityInput.transform.parent.gameObject;
            }
            else if (input.name == "BidQuantityInput")
            {
                this.bidQuantityInput = input;
                this.bidQuantityInput.onSubmit = (UIInput.OnSubmit) Delegate.Combine(this.bidQuantityInput.onSubmit, new UIInput.OnSubmit(this.OnBidQuantitySubmit));
                UIEventListener listener3 = UIEventListener.Get(this.bidQuantityInput.gameObject);
                listener3.onSelect = (UIEventListener.BoolDelegate) Delegate.Combine(listener3.onSelect, new UIEventListener.BoolDelegate(this.OnBidQuantitySelect));
                this.bidParent = this.bidQuantityInput.transform.parent.gameObject;
            }
            else if (input.name == "MaxPriceInput")
            {
                this.maxPriceInput = input;
                this.maxPriceInput.onSubmit = (UIInput.OnSubmit) Delegate.Combine(this.maxPriceInput.onSubmit, new UIInput.OnSubmit(this.OnMaxPriceSubmit));
                UIEventListener listener4 = UIEventListener.Get(this.maxPriceInput.gameObject);
                listener4.onSelect = (UIEventListener.BoolDelegate) Delegate.Combine(listener4.onSelect, new UIEventListener.BoolDelegate(this.OnMaxPriceSelect));
            }
            else if (input.name == "MinPriceInput")
            {
                this.minPriceInput = input;
                this.minPriceInput.onSubmit = (UIInput.OnSubmit) Delegate.Combine(this.minPriceInput.onSubmit, new UIInput.OnSubmit(this.OnMinPriceSubmit));
                UIEventListener listener5 = UIEventListener.Get(this.minPriceInput.gameObject);
                listener5.onSelect = (UIEventListener.BoolDelegate) Delegate.Combine(listener5.onSelect, new UIEventListener.BoolDelegate(this.OnMinPriceSelect));
            }
            else if (input.name == "BidPriceInput")
            {
                this.bidPriceInput = input;
                this.bidPriceInput.onSubmit = (UIInput.OnSubmit) Delegate.Combine(this.bidPriceInput.onSubmit, new UIInput.OnSubmit(this.OnBidPriceSubmit));
                UIEventListener listener6 = UIEventListener.Get(this.bidPriceInput.gameObject);
                listener6.onSelect = (UIEventListener.BoolDelegate) Delegate.Combine(listener6.onSelect, new UIEventListener.BoolDelegate(this.OnBidPriceSelect));
            }
        }
        foreach (UIImageButton button in base.GetComponentsInChildren<UIImageButton>())
        {
            if (button.name == "ButtonSell")
            {
                this.sellButton = button;
                UIEventListener listener7 = UIEventListener.Get(this.sellButton.gameObject);
                listener7.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener7.onClick, new UIEventListener.VoidDelegate(this.OnSellClick));
            }
            else if (button.name == "ButtonBuy")
            {
                this.buyButton = button;
                UIEventListener listener8 = UIEventListener.Get(this.buyButton.gameObject);
                listener8.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener8.onClick, new UIEventListener.VoidDelegate(this.OnBuyClick));
            }
            else if (button.name == "ButtonBid")
            {
                this.bidButton = button;
                UIEventListener listener9 = UIEventListener.Get(this.bidButton.gameObject);
                listener9.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener9.onClick, new UIEventListener.VoidDelegate(this.OnBidClick));
            }
        }
        this.itemDescription = base.GetComponentInChildren<ItemFullDescription>();
        GuiHelper.GuiAssertNotNull("Couldn't find required children.", new object[] { 
            this.itemDescription, this.sellParent, this.buyParent, this.bidParent, this.errorLabel, this.buyPriceLabel, this.sellQuantityInput, this.buyQuantityInput, this.bidQuantityInput, this.maxPriceInput, this.minPriceInput, this.bidPriceInput, this.sellButton, this.buyButton, this.bidButton, this.bidTotalPriceLabel, 
            this.buyTotalPriceLabel
         });
        this.itemDescription.ResetDescription();
        this.maxPriceInput.ClearText();
        this.minPriceInput.ClearText();
        this.bidPriceInput.ClearText();
        this.InputVisible(InputType.NONE);
        base.Init(3, true);
    }

    public void OnBidClick(GameObject filterGO)
    {
        this.errorLabel.text = string.Empty;
        uint quantity = this.GetQuantity(this.bidQuantityInput.text, false);
        ulong price = 0L;
        if (!this.TryGetPrice(this.bidPriceInput.text, out price))
        {
            this.errorLabel.text = "Don't understand: '" + this.bidPriceInput.text + "'";
        }
        if (price != 0L)
        {
            AuctionHouseGui.singleton.BidItem(this.currentItem, quantity, price);
        }
    }

    public void OnBidPriceSelect(GameObject go, bool selected)
    {
        ulong num;
        this.errorLabel.text = string.Empty;
        if (!this.TryGetPrice(this.bidPriceInput.text, out num))
        {
            this.errorLabel.text = "Don't understand: '" + this.bidPriceInput.text + "'";
        }
        else
        {
            if (num < 1L)
            {
                num = 1L;
                this.maxPriceInput.text = AuctionHouseGui.PriceToString(num);
            }
            uint quantity = this.GetQuantity(this.bidQuantityInput.text, false);
            this.bidTotalPriceLabel.text = AuctionHouseGui.PriceToString(num * quantity);
        }
    }

    public void OnBidPriceSubmit(string input)
    {
    }

    public void OnBidQuantitySelect(GameObject go, bool selected)
    {
        ulong num2;
        this.errorLabel.text = string.Empty;
        uint quantity = this.GetQuantity(this.bidQuantityInput.text, false);
        if (this.TryGetPrice(this.bidPriceInput.text, out num2))
        {
            this.bidTotalPriceLabel.text = AuctionHouseGui.PriceToString(num2 * quantity);
        }
    }

    public void OnBidQuantitySubmit(string input)
    {
        this.FocusNext(this.bidPriceInput);
    }

    public void OnBuyClick(GameObject filterGO)
    {
        this.errorLabel.text = string.Empty;
        uint quantity = this.GetQuantity(this.buyQuantityInput.text, true);
        AuctionHouseGui.singleton.BuyItem(this.currentItem, quantity);
    }

    public void OnBuyQuantitySelect(GameObject go, bool selected)
    {
        this.errorLabel.text = string.Empty;
        uint quantity = this.GetQuantity(this.buyQuantityInput.text, true);
        this.buyTotalPriceLabel.text = AuctionHouseGui.PriceToString(this.currentItem.curPrice * quantity);
    }

    public void OnBuyQuantitySubmit(string input)
    {
    }

    public override void OnDestroy()
    {
        base.OnDestroy();
        singleton = null;
    }

    public void OnMaxPriceSelect(GameObject go, bool selected)
    {
        ulong num;
        this.errorLabel.text = string.Empty;
        if (!this.TryGetPrice(this.maxPriceInput.text, out num))
        {
            this.errorLabel.text = "Don't understand: '" + this.maxPriceInput.text + "'";
        }
        else
        {
            ulong num2;
            if (num < 1L)
            {
                num = 1L;
                this.maxPriceInput.text = AuctionHouseGui.PriceToString(num);
            }
            if (this.TryGetPrice(this.minPriceInput.text, out num2) && (num2 > num))
            {
                this.minPriceInput.text = AuctionHouseGui.PriceToString(num);
            }
        }
    }

    public void OnMaxPriceSubmit(string input)
    {
        this.FocusNext(this.minPriceInput);
    }

    public void OnMinPriceSelect(GameObject go, bool selected)
    {
        ulong num;
        this.errorLabel.text = string.Empty;
        if (!this.TryGetPrice(this.minPriceInput.text, out num))
        {
            this.errorLabel.text = "Don't understand: '" + this.minPriceInput.text + "'";
        }
        else
        {
            ulong num2;
            if (num < 1L)
            {
                num = 1L;
                this.minPriceInput.text = AuctionHouseGui.PriceToString(num);
            }
            if (this.TryGetPrice(this.maxPriceInput.text, out num2) && (num2 < num))
            {
                this.maxPriceInput.text = AuctionHouseGui.PriceToString(num);
            }
        }
    }

    public void OnMinPriceSubmit(string input)
    {
    }

    public void OnSellClick(GameObject filterGO)
    {
        this.errorLabel.text = string.Empty;
        uint quantity = this.GetQuantity(this.sellQuantityInput.text, true);
        ulong price = 0L;
        ulong num3 = 0L;
        if (!this.TryGetPrice(this.maxPriceInput.text, out price))
        {
            this.errorLabel.text = "Don't understand: '" + this.maxPriceInput.text + "'";
        }
        else if (!this.TryGetPrice(this.minPriceInput.text, out num3))
        {
            this.errorLabel.text = "Don't understand: '" + this.minPriceInput.text + "'";
        }
        if ((price != 0L) && (num3 != 0L))
        {
            AuctionHouseGui.singleton.SellItem(this.currentItem.item, quantity, price, num3, this.itemSource);
        }
    }

    public void OnSellQuantitySelect(GameObject go, bool selected)
    {
        if (!selected)
        {
            this.errorLabel.text = string.Empty;
            this.GetQuantity(this.sellQuantityInput.text, true);
        }
    }

    public void OnSellQuantitySubmit(string input)
    {
        this.FocusNext(this.maxPriceInput);
    }

    private void Repopulate(InputType type)
    {
        this.currentType = type;
        this.errorLabel.text = string.Empty;
        this.itemDescription.ItemChanged(this.currentItem.item);
        switch (type)
        {
            case InputType.SELL:
                this.sellQuantityInput.text = this.currentItem.item.quantity.ToString();
                this.maxPriceInput.text = AuctionHouseGui.PriceToString(1L);
                this.minPriceInput.text = AuctionHouseGui.PriceToString(1L);
                break;

            case InputType.BUY:
                this.buyQuantityInput.text = this.currentItem.item.quantity.ToString();
                this.buyPriceLabel.text = AuctionHouseGui.PriceToString(this.currentItem.curPrice);
                this.buyTotalPriceLabel.text = AuctionHouseGui.PriceToString(this.currentItem.curPrice * this.currentItem.item.quantity);
                break;

            case InputType.BID:
                this.bidQuantityInput.text = this.currentItem.item.quantity.ToString();
                this.bidPriceInput.text = AuctionHouseGui.PriceToString(1L);
                this.bidTotalPriceLabel.text = AuctionHouseGui.PriceToString(1L);
                break;
        }
    }

    public void Repopulate(ItemOffer item, InputType type)
    {
        this.currentItem = item;
        if (!base.IsShowing())
        {
            this.ShowWindow();
        }
        this.InputVisible(type);
        this.Repopulate(type);
    }

    public void Repopulate(InventoryItem item, InputType type, Item.Container source)
    {
        this.currentItem = new ItemOffer(Item.Container.INVALID, 0, ItemOffer.OfferType.OFFER, item, 0L, 0L);
        this.itemSource = source;
        if (!base.IsShowing())
        {
            this.ShowWindow();
        }
        this.InputVisible(type);
        this.Repopulate(type);
    }

    private bool TryGetPrice(string input, out ulong price)
    {
        price = 0L;
        ulong num = 0L;
        ulong num2 = 0L;
        ulong num3 = 0L;
        ulong num4 = 0L;
        string[] strArray = input.ToLower().Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
        if (strArray.Length == 0)
        {
            return false;
        }
        bool flag = true;
        for (int i = 0; i < strArray.Length; i++)
        {
            ulong num6;
            if (this.TryGetPriceDenomination(strArray[i], "p", out num6))
            {
                num += num6;
            }
            else if (this.TryGetPriceDenomination(strArray[i], "g", out num6))
            {
                num2 += num6;
            }
            else if (this.TryGetPriceDenomination(strArray[i], "s", out num6))
            {
                num3 += num6;
            }
            else if (this.TryGetPriceDenomination(strArray[i], "c", out num6))
            {
                num4 += num6;
            }
            else if (ulong.TryParse(strArray[i], out num6))
            {
                num4 += num6;
            }
            else
            {
                flag = false;
            }
        }
        price = (((num * ((ulong) 0xf4240L)) + (num2 * ((ulong) 0x2710L))) + (num3 * ((ulong) 100L))) + num4;
        return flag;
    }

    private bool TryGetPriceDenomination(string input, string denomination, out ulong price)
    {
        price = 0L;
        if (!input.EndsWith(denomination))
        {
            return false;
        }
        return ulong.TryParse(input.Substring(0, input.LastIndexOf(denomination)), out price);
    }

    public enum InputType
    {
        NONE,
        SELL,
        BUY,
        BID
    }
}

