﻿using GNGUI;
using System;
using UnityEngine;

public class DragDropRoot : MonoBehaviour
{
    public static Transform root;

    private void Awake()
    {
        root = base.transform;
        UIPanel componentInChildren = base.GetComponentInChildren<UIPanel>();
        GuiHelper.GuiAssertNotNull("DragDropRoot needs a panel.", new object[] { componentInChildren });
        Vector3 localPosition = root.localPosition;
        localPosition.z = -210f;
        root.localPosition = localPosition;
    }
}

