﻿using GNGUI;
using System;
using UnityEngine;

public class InventoryAllTabGui : InventoryTabGui
{
    public override void Awake()
    {
        base.Awake();
        base.tabSpriteName = "panel_inventory_tab_right_all";
        base.tabType = InventoryTabGui.Tabs.ALL;
        foreach (ToggleText text in base.GetComponentsInChildren<ToggleText>())
        {
            GLog.LogError(new object[] { "Unknown filter!", text.name });
        }
        foreach (SortButton button in base.GetComponentsInChildren<SortButton>())
        {
            base.allSorts.Add(button);
            UIEventListener listener1 = UIEventListener.Get(button.gameObject);
            listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.SortClicked));
            if (button.name == "S0_Name")
            {
                button.Init(0, SortButton.SortType.ASCENDING);
            }
            else if (button.name == "S1_Encumbrance")
            {
                button.Init(1, SortButton.SortType.INACTIVE);
            }
            else
            {
                GLog.LogError(new object[] { "Unknown sort!", button.name });
            }
            if ((button.sort != SortButton.SortType.INACTIVE) && (base.currentSort == null))
            {
                base.currentSort = button;
            }
            else if ((button.sort != SortButton.SortType.INACTIVE) && (base.currentSort != null))
            {
                GLog.LogError(new object[] { "Should only have one non-inactive sort! You have", base.currentSort.name, "and", button.name });
            }
        }
    }

    public override void FilterClicked(GameObject filterGO)
    {
    }

    protected override bool IsValidForFilter(InventoryItem item)
    {
        return true;
    }
}

