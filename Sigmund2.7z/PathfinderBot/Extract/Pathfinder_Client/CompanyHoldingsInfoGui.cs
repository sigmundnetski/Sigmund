﻿using GNGUI;
using System;
using UnityEngine;

public class CompanyHoldingsInfoGui : MonoBehaviour
{
    private UILabel companyLabel;
    private bool initialized = false;
    private UILabel locationLabel;
    private const string MEMBER_COMPANY = "1_";
    private const string OWNER_COMPANY = "0_";

    public void SetData(GroupClient.TerritoryClientVars territory, uint settlementId)
    {
        if (!this.initialized)
        {
            foreach (UILabel label in base.GetComponentsInChildren<UILabel>(true))
            {
                if (label.name == "LocationLabel")
                {
                    this.locationLabel = label;
                }
                else if (label.name == "OwnerLabel")
                {
                    this.companyLabel = label;
                }
            }
            GuiHelper.GuiAssertNotNull("Couldn't find labels.", new object[] { this.locationLabel, this.companyLabel });
            this.initialized = true;
        }
        if (this.initialized)
        {
            base.name = ((settlementId == territory.settlementId) ? "0_" : "1_") + territory.companyName;
            this.companyLabel.text = territory.companyName;
            this.locationLabel.text = MapClient.GetDisplayPosition("{0:f2}km {1}, {2:f2}km {3}", TerrainService.TranslateServerToWorld(territory.mapId, Vector3.zero));
        }
    }
}

