﻿using GNGUI;
using System;
using UnityEngine;

public class BuffSprite : MonoBehaviour
{
    private UISprite background;
    private CombatBuffVars buff;
    private const string BUFF_COLOR = "[00FF00]";
    public Color color;
    private const string DEBUFF_COLOR = "[FF0000]";
    private UISprite icon;
    private const float SECONDS_ONLY = 2f;
    private bool showingTooltip = false;
    public CombatConstants.State stateType;
    private UIFilledSprite timer;

    public void Awake()
    {
        this.timer = base.GetComponentInChildren<UIFilledSprite>();
        foreach (UISprite sprite in base.GetComponentsInChildren<UISprite>())
        {
            if (sprite.name == "Icon")
            {
                this.icon = sprite;
            }
            if (sprite.name == "Background")
            {
                this.background = sprite;
            }
        }
        GuiHelper.GuiAssertNotNull("Could not find needed children.", new object[] { this.timer, this.icon, this.background });
        this.background.color = this.color;
        this.icon.color = this.color;
        this.timer.color = this.color;
        this.timer.fillAmount = 0f;
    }

    public void Hide()
    {
        NGUITools.SetActive(base.gameObject, false);
        if (this.showingTooltip)
        {
            UITooltip.ShowText(null, null);
        }
    }

    public bool IsShowing()
    {
        return NGUITools.GetActive(base.gameObject);
    }

    public void OnTooltip(bool show)
    {
        this.showingTooltip = show;
        if (!show)
        {
            UITooltip.ShowText(null, null);
        }
        else
        {
            UITooltip.ShowText(this.PopupText(), base.gameObject);
        }
    }

    private string PopupText()
    {
        if (this.buff == null)
        {
            return null;
        }
        string str = string.Empty + ((this.buff.effectType == Combat.EffectType.Beneficial) ? "[00FF00]" : "[FF0000]") + this.buff.name + "[-]\n";
        if (this.buff.combatMod.type == CombatModifierType.STACK)
        {
            str = str + this.buff.stacks + " stacks";
        }
        else if ((this.buff.combatMod.type == CombatModifierType.BUFF) || (this.buff.combatMod.type == CombatModifierType.STATE))
        {
            float num = (float) Math.Round((double) CombatCore.SecondsFromTicks(this.buff.expirationTick - CombatClient.CurrentTick), 1, MidpointRounding.AwayFromZero);
            str = str + ((num > 2f) ? num.ToString("0") : num.ToString("0.#")) + " seconds";
        }
        return str;
    }

    public void Show()
    {
        NGUITools.SetActive(base.gameObject, true);
    }

    public void Start()
    {
        this.Hide();
    }

    public void SyncUpdate(CombatVars cv)
    {
        bool flag = this.IsShowing();
        if (cv == null)
        {
            if (flag)
            {
                this.Hide();
            }
        }
        else
        {
            this.buff = CombatBuff.GetState(cv, this.stateType);
            if (!((this.buff == null) || flag))
            {
                this.Show();
            }
            else if ((this.buff == null) && flag)
            {
                this.Hide();
            }
            if (this.buff != null)
            {
                float num = CombatCore.SecondsFromTicks(this.buff.expirationTick - CombatClient.CurrentTick);
                float num2 = CombatCore.SecondsFromTicks(this.buff.expirationTick - this.buff.startTick);
                this.timer.fillAmount = num / num2;
            }
            else
            {
                this.timer.fillAmount = 0f;
            }
            if (!(this.IsShowing() || !this.showingTooltip))
            {
                this.OnTooltip(false);
            }
            else if (this.showingTooltip)
            {
                UITooltip.ShowText(this.PopupText(), base.gameObject);
            }
        }
    }
}

