﻿using GNGUI;
using System;
using UnityEngine;

public class InventoryRecolorButton : MonoBehaviour
{
    [NonSerialized]
    public Color color;
    [NonSerialized]
    public int colorId;
    public string colorName;
    [NonSerialized]
    public UISprite colorPreview;
    public bool isPrimary;

    public void Awake()
    {
        this.colorPreview = base.GetComponentsInChildren<UISprite>(true)[0];
        GuiHelper.GuiAssertNotNull("Couldn't find children.", new object[] { this.colorPreview });
        if (this.colorPreview != null)
        {
            ColorData colorDataByName = ColorData.GetColorDataByName(this.colorName);
            this.color = colorDataByName.color;
            this.colorId = colorDataByName.id;
            this.colorPreview.color = this.color;
        }
    }
}

