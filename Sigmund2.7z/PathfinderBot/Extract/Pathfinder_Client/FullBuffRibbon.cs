﻿using GNGUI;
using System;
using UnityEngine;

public class FullBuffRibbon : BuffRibbon
{
    private const float MAX_INDIVIDUAL_RIBBON_VALUE = 10f;
    private const float MAX_TOTAL_RIBBON_VALUE = 30f;
    private const int MIN_INDIVIDUAL_RIBBON_VALUE = 4;
    private UISlider[] ribbons;

    public void Awake()
    {
        this.ribbons = new UISlider[RibbonBuffChannelVars.RIBBON_CHANNELS.Length];
        foreach (UISlider slider in base.GetComponentsInChildren<UISlider>())
        {
            if (slider.name == "BuffRibbon0")
            {
                this.ribbons[0] = slider;
            }
            else if (slider.name == "BuffRibbon1")
            {
                this.ribbons[1] = slider;
            }
            else if (slider.name == "BuffRibbon2")
            {
                this.ribbons[2] = slider;
            }
            else if (slider.name == "DebuffRibbon0")
            {
                this.ribbons[3] = slider;
            }
            else if (slider.name == "DebuffRibbon1")
            {
                this.ribbons[4] = slider;
            }
            else if (slider.name == "DebuffRibbon2")
            {
                this.ribbons[5] = slider;
            }
        }
        GuiHelper.GuiAssertNotNull("Could not find needed children.", this.ribbons);
        for (int i = 0; i < this.ribbons.Length; i++)
        {
            this.ribbons[i].sliderValue = 0f;
        }
    }

    public override void SyncUpdate(CombatVars cv)
    {
        if (base.InternalSyncUpdate(cv))
        {
            int num2;
            float num3;
            float num4;
            float num = 0f;
            for (num2 = 0; num2 < (this.ribbons.Length / 2); num2++)
            {
                num3 = 0f;
                if (base.ribbonValues[num2] != 0)
                {
                    num3 = Mathf.Min(Mathf.Sqrt((float) (base.ribbonValues[num2] + 4)), 10f);
                }
                num += num3;
                num4 = num / 30f;
                this.ribbons[num2].sliderValue = (base.ribbonValues[num2] == 0) ? 0f : num4;
            }
            num = 0f;
            for (num2 = this.ribbons.Length / 2; num2 < this.ribbons.Length; num2++)
            {
                num3 = 0f;
                if (base.ribbonValues[num2] != 0)
                {
                    num3 = Mathf.Min(Mathf.Sqrt((float) (base.ribbonValues[num2] + 4)), 10f);
                }
                num += num3;
                num4 = num / 30f;
                this.ribbons[num2].sliderValue = (base.ribbonValues[num2] == 0) ? 0f : num4;
            }
        }
    }
}

