﻿using GNetwork;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;

public class CraftingClientTests : UUnitTestCase
{
    private static string[] CRAFTING_DEFAULTS = new string[] { "alchemist", "armorsmith", "artificer", "bowyer", "engineer", "iconographer", "jeweler", "leatherworker", "tailor", "weaponsmith" };
    private Dictionary<int, BaseRecipeData[]> recipesBySkill = new Dictionary<int, BaseRecipeData[]>();

    private static void Helper(int staticItemId, out InventoryItem availableStack, out InventoryItem allocatedStack)
    {
        InventoryItem[] allAllocatedItems = CraftingClient.GetAllAllocatedItems();
        InventoryItem[] availableItems = CraftingClient.GetAvailableItems();
        allocatedStack = (from each in allAllocatedItems
            where each.staticItemId == staticItemId
            select each).FirstOrDefault<InventoryItem>();
        availableStack = (from each in availableItems
            where each.staticItemId == staticItemId
            select each).FirstOrDefault<InventoryItem>();
    }

    [UUnitSystemTestMethod]
    public void RecipeRequestValidation()
    {
        uint setQuantity = 0x3e8;
        BaseRecipeData data = BaseRecipeData.recipeByName["strong acidic extract +1"];
        CraftingClient.activeRequest.SetRecipe(data.id);
        BasicItemData data2 = ItemDatabase.itemByName["dilute antimony"];
        BasicItemData data3 = ItemDatabase.itemByName["dilute eraser poppy seeds"];
        BasicItemData data4 = ItemDatabase.itemByName["dilute hyssop oil"];
        InventoryItem newItem = new InventoryItem(data2.id, setQuantity, 0, data2.durability);
        InventoryItem item2 = new InventoryItem(data3.id, setQuantity, 0, data3.durability);
        InventoryItem item3 = new InventoryItem(data4.id, setQuantity, 0, data4.durability);
        EntityDataClient.owner.advancementVars = new AdvancementVars();
        EntityDataClient.owner.advancementVars.UpdateToStaticData();
        EntityDataClient.owner.advancementVars.SetFlag(AchievementFlagData.flagsById[data.advFlagId]);
        EntityDataClient.owner.advancementVars.SetFeatLevel(data.featAdvancementId, data.featLevel);
        SparseArray.Clear<InventoryItem>(ref EntityDataClient.owner.playerRecord.inventory, InventoryItem.EMPTY);
        EntityDataClient.owner.playerRecord.AddWithAutoStack(newItem);
        EntityDataClient.owner.playerRecord.AddWithAutoStack(item2);
        EntityDataClient.owner.playerRecord.AddWithAutoStack(item3);
        CraftingClient.ResetAllocations(data.inputQtys);
        CraftingClient.selectedInputIndex = 0;
        CraftingClient.Earmark(item2, setQuantity);
        CraftingClient.selectedInputIndex = 1;
        CraftingClient.Earmark(newItem, setQuantity);
        CraftingClient.selectedInputIndex = 2;
        CraftingClient.Earmark(item3, setQuantity);
        UUnitAssert.True(CraftingClient.RecipeReady(), "Fail");
        BitBuffer quickBuffer = GUtil.GetQuickBuffer();
        DataUtilities.SerializeObjectToNetworkBuffer(quickBuffer, 0, CraftingClient.activeRequest, null);
        ((CraftingRequest) DataUtilities.DeserializeObjectFromNetwork(quickBuffer, typeof(CraftingRequest), 0, null)).Validate(EntityDataClient.owner);
    }

    protected override void SetUp()
    {
        EntityCore.UnitTest_Reinitialize(0x8080);
        UUnitTestCase.LoadRealStaticData();
        CraftingItemData.IndexStocks();
        AchievementCore.SetupPageInfo();
        EntityDataClient.owner = EntityCore.RequestNewEntity();
        EntityDataClient.owner.playerRecord = new PlayerRecord();
        EntityDataClient.owner.advancementVars = new AdvancementVars();
        EntityDataClient.owner.advancementVars.UpdateToStaticData();
        foreach (string str in CRAFTING_DEFAULTS)
        {
            FeatAdvancementData expData = FeatAdvancementData.dataBySlotName[str];
            SkillData skillData = SkillData.skillByName[str];
            EntityDataClient.owner.advancementVars.SetFeatLevel(expData, 20);
            BaseRecipeData[] dataArray = (from recipePair in BaseRecipeData.recipeById
                where (recipePair.Value.advFlagId == 0) && (recipePair.Value.featAdvancementId == expData.id)
                select recipePair.Value).ToArray<BaseRecipeData>();
            BaseRecipeData[] dataArray2 = (from recipePair in BaseRecipeData.recipeById
                where (recipePair.Value.advFlagId == 0) && (recipePair.Value.skillId == skillData.id)
                select recipePair.Value).ToArray<BaseRecipeData>();
            UUnitAssert.Equals(dataArray.Length, dataArray2.Length, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
            UUnitAssert.True(dataArray2.Length > 0, "Fail");
            this.recipesBySkill[skillData.id] = dataArray2;
        }
    }

    protected override void TearDown()
    {
        AchievementCore.TearDownPageInfo();
        EntityCore.UnitTest_Reinitialize(0);
    }

    [UUnitSystemTestMethod]
    private void TestDefaultsBySkill()
    {
        string[] searchArgs = new string[0];
        int[] skillIds = new int[1];
        foreach (KeyValuePair<int, BaseRecipeData[]> pair in this.recipesBySkill)
        {
            skillIds[0] = pair.Key;
            foreach (BaseRecipeData data in pair.Value)
            {
                UUnitAssert.True(CraftingClient.ValidRecipe(data, skillIds, searchArgs), "Fail");
            }
        }
    }

    [UUnitSystemTestMethod]
    private void TestGetAvailableItems_AcidicExtract()
    {
        InventoryItem item;
        InventoryItem item2;
        InventoryItem item4;
        InventoryItem item5;
        uint setQuantity = 100;
        BasicItemData data = ItemDatabase.itemByName["dilute hyssop oil"];
        BasicItemData data2 = ItemDatabase.itemByName["potent hyssop oil"];
        BaseRecipeData data3 = BaseRecipeData.recipeByName["strong acidic extract +0"];
        uint qty = data3.inputQtys[2];
        CraftingClient.activeRequest.SetRecipe(data3.id);
        CraftingClient.selectedInputIndex = 2;
        InventoryItem newItem = new InventoryItem(data.id, setQuantity, 0, data.durability);
        InventoryItem item6 = new InventoryItem(data2.id, setQuantity, 0, data2.durability);
        EntityDataClient.owner.playerRecord.AddWithAutoStack(newItem);
        EntityDataClient.owner.playerRecord.AddWithAutoStack(item6);
        CraftingClient.ResetAllocations(data3.inputQtys);
        Helper(data.id, out item2, out item);
        UUnitAssert.Equals((ulong) item2.quantity, (ulong) setQuantity, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals((ulong) newItem.quantity, (ulong) setQuantity, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        CraftingClient.Earmark(item2, 1);
        Helper(data.id, out item2, out item);
        UUnitAssert.Equals((ulong) item2.quantity, (ulong) (setQuantity - 1), "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals((ulong) item.quantity, 1L, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals((ulong) newItem.quantity, (ulong) setQuantity, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        CraftingClient.Earmark(item2, 1);
        Helper(data.id, out item2, out item);
        UUnitAssert.Equals((ulong) item2.quantity, (ulong) (setQuantity - 2), "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals((ulong) item.quantity, 2L, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals((ulong) newItem.quantity, (ulong) setQuantity, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        CraftingClient.Earmark(item2, qty);
        Helper(data.id, out item2, out item);
        UUnitAssert.Equals((ulong) item2.quantity, (ulong) (setQuantity - qty), "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals((ulong) item.quantity, (ulong) qty, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals((ulong) newItem.quantity, (ulong) setQuantity, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        Helper(data2.id, out item5, out item4);
        CraftingClient.Earmark(item5, 1);
        Helper(data.id, out item2, out item);
        Helper(data2.id, out item5, out item4);
        UUnitAssert.Equals((ulong) item2.quantity, (ulong) ((setQuantity - qty) + 1), "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals((ulong) item.quantity, (ulong) (qty - 1), "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals((ulong) item5.quantity, (ulong) (setQuantity - 1), "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals((ulong) item4.quantity, 1L, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals((ulong) newItem.quantity, (ulong) setQuantity, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals((ulong) item6.quantity, (ulong) setQuantity, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        CraftingClient.Earmark(item2, 1);
        Helper(data.id, out item2, out item);
        Helper(data2.id, out item5, out item4);
        UUnitAssert.Equals((ulong) item2.quantity, (ulong) (setQuantity - qty), "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals((ulong) item.quantity, (ulong) qty, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals((ulong) item5.quantity, (ulong) setQuantity, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(item4, InventoryItem.EMPTY, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals((ulong) newItem.quantity, (ulong) setQuantity, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals((ulong) item6.quantity, (ulong) setQuantity, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
    }

    [UUnitSystemTestMethod]
    private void TestGetAvailableItems_SepiaCrystal()
    {
        InventoryItem item;
        InventoryItem item2;
        InventoryItem item4;
        InventoryItem item5;
        BasicItemData data = ItemDatabase.itemByName["fragment of battle (humanoid)"];
        BasicItemData data2 = ItemDatabase.itemByName["fragment of secrets (humanoid)"];
        BaseRecipeData data3 = BaseRecipeData.recipeByName["sepia crystal +0"];
        CraftingClient.activeRequest.SetRecipe(data3.id);
        InventoryItem newItem = new InventoryItem(data.id, 5, 0, data.durability);
        InventoryItem item6 = new InventoryItem(data2.id, 5, 0, data2.durability);
        EntityDataClient.owner.playerRecord.AddWithAutoStack(newItem);
        EntityDataClient.owner.playerRecord.AddWithAutoStack(item6);
        CraftingClient.ResetAllocations(data3.inputQtys);
        CraftingClient.selectedInputIndex = 1;
        Helper(data.id, out item2, out item);
        UUnitAssert.Equals((ulong) item.quantity, 0L, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals((ulong) item2.quantity, 5L, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        CraftingClient.Earmark(item2, 5);
        Helper(data.id, out item2, out item);
        UUnitAssert.Equals((ulong) item.quantity, 5L, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals((ulong) item2.quantity, 0L, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        CraftingClient.selectedInputIndex = 2;
        Helper(data2.id, out item5, out item4);
        UUnitAssert.Equals((ulong) item4.quantity, 0L, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals((ulong) item5.quantity, 5L, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        CraftingClient.Earmark(item5, 5);
        Helper(data2.id, out item5, out item4);
        UUnitAssert.Equals((ulong) item4.quantity, 5L, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals((ulong) item5.quantity, 0L, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        CraftingClient.selectedInputIndex = 0;
        Helper(data.id, out item2, out item);
        Helper(data2.id, out item5, out item4);
        UUnitAssert.Equals((ulong) item.quantity, 5L, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals((ulong) item2.quantity, 0L, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals((ulong) item4.quantity, 5L, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals((ulong) item5.quantity, 0L, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
    }
}

