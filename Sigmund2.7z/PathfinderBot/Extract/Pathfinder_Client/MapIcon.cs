﻿using GNGUI;
using Map;
using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using UnityEngine;

public class MapIcon : MonoBehaviour
{
    private Transform cachedTransform;
    private TooltipTextDelegate dynamicTooltipCallback = null;
    public UISprite icon;
    public IconUniqueKey info;
    private bool isTooltipShowing = false;
    public string popupText;

    public void Destroy()
    {
        UnityEngine.Object.Destroy(base.gameObject);
    }

    public void DoubleClick(GameObject iconGO)
    {
        if ((this.info.placeType == PlaceType.PLAYER_MAP_PIN) && this.info.Match(EntityDataClient.owner.entityId))
        {
            MapClient.RemovePlayerPin();
            this.Tooltip(base.gameObject, false);
        }
    }

    public void FixedUpdate()
    {
        if (this.isTooltipShowing && (this.dynamicTooltipCallback != null))
        {
            UITooltip.ShowText(this.GetTooltipText(), base.gameObject);
        }
    }

    private string GetTooltipText()
    {
        if (this.dynamicTooltipCallback == null)
        {
            return this.popupText;
        }
        return this.dynamicTooltipCallback(this.info);
    }

    public static MapIcon NewMapIcon(GameObject parent, GameObject mapIconPrefab, IconUniqueKey info_, int iconId, string itemName, int spriteDepth, float colliderZ, string popupText_, TooltipTextDelegate dynamicTooltipCallback_ = null)
    {
        GameObject go = NGUITools.AddChild(parent, mapIconPrefab);
        GuiHelper.GuiAssertNotNull("Couldn't instantiate map icon for " + itemName + ".", new object[] { go });
        go.name = itemName;
        MapIcon component = go.GetComponent<MapIcon>();
        GuiHelper.GuiAssertNotNull("Couldn't find map icon component for " + itemName + ".", new object[] { component });
        component.info = info_;
        component.dynamicTooltipCallback = dynamicTooltipCallback_;
        component.icon = go.GetComponent<UISprite>();
        component.icon.depth = spriteDepth;
        component.icon.spriteName = ImageData.GetMapIconById(iconId);
        component.icon.MakePixelPerfect();
        BoxCollider collider = go.GetComponent<BoxCollider>();
        if (collider != null)
        {
            collider.center = new Vector3(0f, 0f, colliderZ);
            collider.size = new Vector3(1f, 1f, 1f);
            UIEventListener listener1 = UIEventListener.Get(go);
            listener1.onHover = (UIEventListener.BoolDelegate) Delegate.Combine(listener1.onHover, new UIEventListener.BoolDelegate(component.Tooltip));
            UIEventListener listener2 = UIEventListener.Get(go);
            listener2.onDoubleClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener2.onDoubleClick, new UIEventListener.VoidDelegate(component.DoubleClick));
        }
        component.popupText = popupText_;
        component.cachedTransform = go.transform;
        return component;
    }

    public void SetPosition(Vector3 position)
    {
        this.cachedTransform.localPosition = position;
    }

    public void SetRotation(Quaternion rotation)
    {
        this.cachedTransform.rotation = rotation;
    }

    public void Tooltip(GameObject iconGO, bool showTooltip)
    {
        this.isTooltipShowing = showTooltip;
        if (!showTooltip)
        {
            UITooltip.ShowText(null, null);
        }
        else
        {
            UITooltip.ShowText(this.GetTooltipText(), iconGO);
        }
    }

    public delegate string TooltipTextDelegate(IconUniqueKey context);
}

