﻿using GNGUI;
using System;
using System.Collections.Generic;
using UnityEngine;

public abstract class InventoryTabGui : WindowTabGui
{
    protected List<SortButton> allSorts = new List<SortButton>();
    protected SortButton currentSort = null;
    private static List<InventoryItem> newItems = new List<InventoryItem>();
    private static List<InventoryItem> oldItems = new List<InventoryItem>();
    protected ItemWindowGui parentWindow;
    protected Tabs tabType = Tabs.INVALID;

    protected InventoryTabGui()
    {
    }

    public override void Awake()
    {
        base.Awake();
        base.prefabName = "InventoryListItem";
    }

    public override void ContentsChanged()
    {
        int num;
        IEnumerable<InventoryItem> enumerable;
        IEnumerable<InventoryItem> enumerable2;
        InventoryItem[] readonlyItems = this.GetReadonlyItems();
        newItems.Clear();
        oldItems.Clear();
        if (readonlyItems != null)
        {
            for (num = 0; num < readonlyItems.Length; num++)
            {
                if (!(InventoryItem.EMPTY_MATCH(readonlyItems[num]) || !this.IsValidForFilter(readonlyItems[num])))
                {
                    newItems.Add(readonlyItems[num]);
                }
            }
        }
        for (num = 0; num < base.displayedItems.Count; num++)
        {
            oldItems.Add(((InventoryItemGui) base.displayedItems[num]).item);
        }
        GUtil.GetDeltasWithDuplicates<InventoryItem>(newItems, oldItems, out enumerable, out enumerable2);
        bool flag = false;
        foreach (InventoryItem item in enumerable)
        {
            this.UpdateInventoryList(item, WindowTabGui.UpdateType.REMOVE);
            flag = true;
        }
        foreach (InventoryItem item in enumerable2)
        {
            this.UpdateInventoryList(item, WindowTabGui.UpdateType.ADD);
            flag = true;
        }
        if (flag)
        {
            this.ResortContents((InventoryItemGui.Sort) this.currentSort.sortId, this.currentSort.sort);
        }
    }

    private InventoryItemGui CreateInventoryItem(InventoryItem item)
    {
        InventoryItemGui component = NGUITools.AddChild(base.gridList.gameObject, base.listItemPrefab).GetComponent<InventoryItemGui>();
        component.Assign(item, this.tabType, this.parentWindow);
        if (ItemDatabase.GetItem(item.staticItemId) == null)
        {
            component.name = "<NOT FOUND>";
            return component;
        }
        component.name = item.GetDisplayName(true);
        return component;
    }

    public override void FilterClicked(GameObject filterGO)
    {
        foreach (ToggleText text in base.allFilters)
        {
            if (filterGO == text.gameObject)
            {
                text.ToggleActive();
                base.activeFilter = text.isActive ? text : null;
            }
            else
            {
                text.SetActive(false);
            }
        }
        this.ContentsChanged();
        base.FilterClicked(filterGO);
    }

    protected virtual InventoryItem[] GetReadonlyItems()
    {
        return EntityDataClient.owner.playerRecord.inventory;
    }

    public void Init(ItemWindowGui parent)
    {
        this.parentWindow = parent;
    }

    protected abstract bool IsValidForFilter(InventoryItem item);
    protected override void MakeListItems()
    {
        throw new NotImplementedException("Should not call this. Call ContentsChanged instead.");
    }

    protected void ResortContents(InventoryItemGui.Sort sortField, SortButton.SortType sortType)
    {
        IEnumerable<InventoryItemGui> enumerable = null;
        if (sortField == InventoryItemGui.Sort.NAME)
        {
            if (sortType == SortButton.SortType.DESCENDING)
            {
                enumerable = from each in base.displayedItems
                    orderby ((InventoryItemGui) each).sortName descending
                    select (InventoryItemGui) each;
            }
            else if (sortType == SortButton.SortType.ASCENDING)
            {
                enumerable = from each in base.displayedItems
                    orderby ((InventoryItemGui) each).sortName
                    select (InventoryItemGui) each;
            }
            else
            {
                GLog.LogError(new object[] { "Don't know how to sort", sortField, "by", sortType });
            }
        }
        else if (sortField == InventoryItemGui.Sort.ENCUMBRANCE)
        {
            if (sortType == SortButton.SortType.DESCENDING)
            {
                enumerable = from each in base.displayedItems
                    orderby ((InventoryItemGui) each).sortEncumbrance descending
                    select (InventoryItemGui) each;
            }
            else if (sortType == SortButton.SortType.ASCENDING)
            {
                enumerable = from each in base.displayedItems
                    orderby ((InventoryItemGui) each).sortEncumbrance
                    select (InventoryItemGui) each;
            }
            else
            {
                GLog.LogError(new object[] { "Don't know how to sort", sortField, "by", sortType });
            }
        }
        else if (sortField == InventoryItemGui.Sort.DURABILITY)
        {
            if (sortType == SortButton.SortType.DESCENDING)
            {
                enumerable = from each in base.displayedItems
                    orderby ((InventoryItemGui) each).sortDurability descending
                    select (InventoryItemGui) each;
            }
            else if (sortType == SortButton.SortType.ASCENDING)
            {
                enumerable = from each in base.displayedItems
                    orderby ((InventoryItemGui) each).sortDurability
                    select (InventoryItemGui) each;
            }
            else
            {
                GLog.LogError(new object[] { "Don't know how to sort", sortField, "by", sortType });
            }
        }
        else if (sortField == InventoryItemGui.Sort.TIER)
        {
            if (sortType == SortButton.SortType.DESCENDING)
            {
                enumerable = from each in base.displayedItems
                    orderby ((InventoryItemGui) each).sortTier descending
                    select (InventoryItemGui) each;
            }
            else if (sortType == SortButton.SortType.ASCENDING)
            {
                enumerable = from each in base.displayedItems
                    orderby ((InventoryItemGui) each).sortTier
                    select (InventoryItemGui) each;
            }
            else
            {
                GLog.LogError(new object[] { "Don't know how to sort", sortField, "by", sortType });
            }
        }
        else if (sortField == InventoryItemGui.Sort.VARIETY)
        {
            if (sortType == SortButton.SortType.DESCENDING)
            {
                enumerable = from each in base.displayedItems
                    orderby ((InventoryItemGui) each).sortVariety descending
                    select (InventoryItemGui) each;
            }
            else if (sortType == SortButton.SortType.ASCENDING)
            {
                enumerable = from each in base.displayedItems
                    orderby ((InventoryItemGui) each).sortVariety
                    select (InventoryItemGui) each;
            }
            else
            {
                GLog.LogError(new object[] { "Don't know how to sort", sortField, "by", sortType });
            }
        }
        if (enumerable != null)
        {
            int num = 0;
            foreach (InventoryItemGui gui in enumerable)
            {
                gui.name = num.ToString("d3") + "_" + gui.sortName;
                num++;
            }
        }
        else
        {
            GLog.LogError(new object[] { "Failed to sort", sortField, sortType });
        }
        this.RepositionListItems();
    }

    public override void ShowTab()
    {
        this.ContentsChanged();
        base.ShowTab();
    }

    public virtual void SortClicked(GameObject sortGO)
    {
        SortButton button = null;
        for (int i = 0; i < this.allSorts.Count; i++)
        {
            if (sortGO == this.allSorts[i].gameObject)
            {
                this.allSorts[i].ToggleSort(true);
                button = this.allSorts[i];
            }
            else
            {
                this.allSorts[i].ToggleSort(false);
            }
        }
        this.currentSort = button;
        this.ResortContents((InventoryItemGui.Sort) this.currentSort.sortId, this.currentSort.sort);
    }

    private void UpdateInventoryList(InventoryItem item, WindowTabGui.UpdateType updateType)
    {
        Predicate<TabListItem> match = null;
        if (updateType == WindowTabGui.UpdateType.REMOVE)
        {
            if (match == null)
            {
                match = i => item.Equals(((InventoryItemGui) i).item);
            }
            TabListItem item2 = base.displayedItems.Find(match);
            if (item2 == null)
            {
                return;
            }
            item2.gameObject.SetActive(false);
            item2.transform.parent = DragDropRoot.root;
            UnityEngine.Object.Destroy(item2.gameObject);
            base.displayedItems.Remove(item2);
        }
        else
        {
            InventoryItemGui gui = this.CreateInventoryItem(item);
            base.displayedItems.Add(gui);
        }
        this.RepositionListItems();
    }

    public enum Tabs
    {
        EQUIPMENT,
        CRAFTING,
        ALL,
        NUM_TABS,
        INVALID
    }
}

