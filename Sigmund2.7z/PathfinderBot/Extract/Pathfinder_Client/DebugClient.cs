﻿using GNetwork;
using GNGUI;
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public static class DebugClient
{
    private static bool dataSyncDebug = false;
    private static GameObject uiRootGO;

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void AiDebugMessage(uint serverId, string message)
    {
        GLog.Log(new object[] { "AiDebugMessage", message });
        DebugGui.singleton.SetServerDebugString(serverId, message);
        DebugGui.singleton.SetClientDebugString(string.Empty);
    }

    public static void ChatCommand(string[] args, EntityId playerEntityId)
    {
        ChatGui.singleton.ClearChat();
    }

    public static void DataSyncDebug(string[] args, EntityId playerEntityId)
    {
        Entity entity = EntityCore.GetEntity(ref playerEntityId);
        if (args.Length <= 1)
        {
            dataSyncDebug = !dataSyncDebug;
        }
        else
        {
            uint result = 0;
            uint.TryParse(args[1], out result);
            dataSyncDebug = result > 0;
        }
        GenericDebugMessage("Data sync debug turned " + (dataSyncDebug ? "on" : "off"));
    }

    private static void DataSyncTick()
    {
        if (dataSyncDebug)
        {
            for (int i = 0; i < 3; i++)
            {
                if (EntityData.rdsMaps[i] > 0)
                {
                    byte[] buffer = EntityData.rdsSequences[i];
                    DebugGui.singleton.SetServerDebugString(EntityData.rdsMaps[i], string.Format("{0}: [{1}, {2}, {3}, {4}, {5}, {6}, {7}, {8}, {9}, {10}]\n", new object[] { EntityData.rdsMaps[i], buffer[0], buffer[1], buffer[2], buffer[3], buffer[4], buffer[5], buffer[6], buffer[7], buffer[8], buffer[9] }));
                }
            }
            DebugGui.singleton.SetClientDebugString(EntityData.rdsLastError);
        }
    }

    public static void DisplayDebugMessage(string msg)
    {
        ChatGui.singleton.DisplayMessage(msg, ChatClient.DEBUG_COLOR);
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void GenericDebugMessage(string message)
    {
        DisplayDebugMessage(message);
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void GhostDebugMessage(uint serverId, string message)
    {
        GLog.Log(new object[] { "GhostDebugMessage", message });
        DebugGui.singleton.SetServerDebugString(serverId, message);
        List<Entity> entList = EntityCore.GetAllEntities(true).ToList<Entity>();
        GUtil.DistanceSort(ref entList, EntityDataClient.owner.GetLocalPosition());
        DebugGui.singleton.SetClientDebugString("Client:\n" + GhostDebug.GhostDebugString(entList.Take<Entity>(10).ToList<Entity>(), null).ToString());
    }

    public static void LogPlayerFacing(string[] args, EntityId playerEntityId)
    {
        DisplayDebugMessage("Player facing logged.");
        GameObject player = PlayerEntityClient.GetPlayer();
        GLog.Log(new object[] { "Player facing =", player.transform.localEulerAngles.y });
    }

    public static void LogPlayerPosition(string[] args, EntityId playerEntityId)
    {
        GameObject player = PlayerEntityClient.GetPlayer();
        string msg = string.Concat(new object[] { "Player position = ", player.transform.position, " ", EntityDataClient.owner.ownerMapId, ", ", TerrainUtils.GetHexFromMapId(EntityDataClient.owner.ownerMapId) });
        DisplayDebugMessage(msg);
        GLog.Log(new object[] { msg });
    }

    public static void PrintStats(string[] args, EntityId playerEntityId)
    {
        GenericDebugMessage("Stats:" + EntityDataClient.owner.advancementVars.GetDebugAbilityScoreOutput());
    }

    public static void SetPlayerFacing(string[] args, EntityId playerEntityId)
    {
        if ((args.Length != 2) && ((args.Length == 3) && (args[1] != "rel")))
        {
            DisplayDebugMessage("Set Absolute : SetPlayerFacing Y");
            DisplayDebugMessage("Set Relative : SetPlayerFacing rel Y");
        }
        else
        {
            GameObject player = PlayerEntityClient.GetPlayer();
            EntityMotion component = player.GetComponent<EntityMotion>();
            Vector3 localEulerAngles = player.transform.localEulerAngles;
            if (args.Length == 2)
            {
                localEulerAngles.y = float.Parse(args[1]);
            }
            else
            {
                localEulerAngles.y += float.Parse(args[2]);
            }
            component.Teleport(component.transform.position, Quaternion.Euler(localEulerAngles));
        }
    }

    private static void SyncStart()
    {
    }

    public static bool SyncUpdate()
    {
        if (dataSyncDebug)
        {
            DataSyncTick();
        }
        return true;
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void TeleportReply(int valid_, ushort mapId, Vector3 teleportTo, string teleportToLocation)
    {
        GConst.TeleportStatus status = (GConst.TeleportStatus) valid_;
        if (status == GConst.TeleportStatus.InvalidCommand)
        {
            DisplayDebugMessage("Teleport: Unknown teleport place: " + teleportToLocation);
        }
        else if (status == GConst.TeleportStatus.NoPointFound)
        {
            DisplayDebugMessage("Teleport: No '" + teleportToLocation + "' to teleport to currently.");
        }
        else
        {
            teleportTo = TerrainService.TranslateServerToLocal(mapId, teleportTo);
            GameObject player = PlayerEntityClient.GetPlayer();
            player.GetComponent<EntityMotion>().Teleport(teleportTo, player.transform.rotation);
            if (!string.IsNullOrEmpty(teleportToLocation))
            {
                DisplayDebugMessage("Teleported to: " + teleportToLocation);
            }
            teleportToLocation = string.Empty;
        }
    }

    public static void TestCombatModifiers(string[] args, EntityId playerEntityId)
    {
        if (args.Length < 2)
        {
            DisplayDebugMessage("Need a combat modifier to test, like: CombatModifier Slow 50% to Attacker");
        }
        else
        {
            string source = string.Empty;
            for (int i = 1; i < args.Length; i++)
            {
                source = source + args[i] + " ";
            }
            try
            {
                CombatModifier[] modifierArray = CombatModifier.Parse(source);
            }
            catch (ParseException exception)
            {
                DisplayDebugMessage("Parse exception: " + exception.Message);
                return;
            }
            EntityId selectedEntityId = Targeting.selectedEntityId;
            if (selectedEntityId == EntityId.INVALID_ID)
            {
                selectedEntityId = EntityDataClient.owner.entityId;
            }
            GRouting.SendMyMapRpc(GRpcID.CombatDebug_TestCombatModifiers, new object[] { selectedEntityId, source });
        }
    }

    public static void ToggleAllUi(string[] args, EntityId playerEntityId)
    {
        if (uiRootGO == null)
        {
            uiRootGO = GameObject.Find("/UI Root (2D)");
        }
        bool state = !NGUITools.GetActive(uiRootGO);
        if (args.Length >= 2)
        {
            if ((args[1] == "on") || (args[1] == "enabled"))
            {
                state = true;
            }
            else if ((args[1] == "off") || (args[1] == "disabled"))
            {
                state = false;
            }
        }
        NGUITools.SetActive(uiRootGO, state);
    }

    public static void ToggleFps(string[] args, EntityId playerEntityId)
    {
        FpsGui.singleton.TogglePanel();
    }

    public static void UpdateTarget(EntityId newTargetEntityId)
    {
        if ((EntityDataClient.owner != null) && (((byte) (EntityDataClient.owner.flags & EntityFlags.AiDebug)) == 0x10))
        {
            GRouting.SendMyMapRpc(GRpcID.GMCommandServer_UpdateTarget, new object[] { newTargetEntityId });
        }
    }
}

