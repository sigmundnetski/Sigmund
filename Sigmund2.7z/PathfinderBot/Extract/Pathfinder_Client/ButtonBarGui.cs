﻿using GNGUI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using UnityEngine;

public class ButtonBarGui : MonoBehaviour
{
    private bool buttonLoadComplete;
    public Dictionary<string, string> buttonNameToCommand;
    private bool buttonSetupComplete;
    private float cooldownStartTime;
    private UIFilledSprite globalCooldownTimer;
    private const string IMPLEMENT_SET_OFF = "hud_hotbar_button_implementswitch_off";
    private const string IMPLEMENT_SET_ON = "hud_hotbar_button_implementswitch_on";
    private ButtonBarButton[] implementButtons;
    private UISprite implementIcon;
    private UISprite[] implementSetIndicators = new UISprite[2];
    private bool prevInCombat;
    public static ButtonBarGui singleton;
    private const string WEAPON_SET_OFF = "hud_hotbar_button_weaponswitch_off";
    private const string WEAPON_SET_ON = "hud_hotbar_button_weaponswitch_on";
    private bool weaponActive = true;
    private ButtonBarButton[] weaponButtons;
    private UISprite[] weaponIcons = new UISprite[2];
    private UISprite[] weaponSetIndicators = new UISprite[2];

    public ButtonBarGui()
    {
        Dictionary<string, string> dictionary = new Dictionary<string, string>();
        dictionary.Add("AttackButton 01", "attack1");
        dictionary.Add("AttackButton 02", "attack2");
        dictionary.Add("AttackButton 03", "attack3");
        dictionary.Add("AttackButton 04", "attack4");
        dictionary.Add("AttackButton 05", "attack5");
        dictionary.Add("AttackButton 06", "attack6");
        dictionary.Add("UtilityButton 01", "utility1");
        dictionary.Add("UtilityButton 02", "utility2");
        dictionary.Add("ConsumableButton 01", "refresh1");
        dictionary.Add("ConsumableButton 02", "refresh2");
        dictionary.Add("ExpendableButton 01", "attack1");
        dictionary.Add("ExpendableButton 02", "attack2");
        dictionary.Add("ExpendableButton 03", "attack3");
        dictionary.Add("ExpendableButton 04", "attack4");
        dictionary.Add("ExpendableButton 05", "attack5");
        dictionary.Add("ExpendableButton 06", "attack6");
        this.buttonNameToCommand = dictionary;
        this.buttonSetupComplete = false;
        this.buttonLoadComplete = false;
        this.cooldownStartTime = 0f;
        this.prevInCombat = false;
    }

    private void AttackToggle(bool showAttacks)
    {
        foreach (ButtonBarButton button in this.weaponButtons)
        {
            button.AttackToggle(showAttacks);
        }
        foreach (ButtonBarButton button in this.implementButtons)
        {
            button.AttackToggle(!showAttacks);
        }
    }

    public void Awake()
    {
        singleton = this;
        this.OnAwake();
    }

    public void ButtonClick(GameObject go)
    {
        ButtonBarButton component = go.GetComponent<ButtonBarButton>();
        if (component != null)
        {
            if (component.featForm == FeatData.FeatForm.Wondrous)
            {
                CombatClient.ItemQueued(component.bodySlot, component.itemId);
            }
            else if (component.generalType == Combat.FeatType.Offensive)
            {
                CombatClient.AttackInitiated(component.featId);
            }
            else
            {
                CombatClient.FeatQueued(component.featId);
            }
        }
        else
        {
            Debug.Log("Invalid/not-hooked-up attack!");
        }
    }

    public string ButtonNameToCommand(string buttonName)
    {
        string str;
        if (this.buttonNameToCommand.TryGetValue(buttonName, out str))
        {
            return str;
        }
        GLog.LogError(new object[] { "'" + str + "' not found in dictionary.  Num options:", this.buttonNameToCommand.Count });
        return string.Empty;
    }

    public void CommandEvent(string[] command, EntityId playerEntityId)
    {
        if (command[0] == "weaponswap")
        {
            this.SwapWeapons(base.gameObject);
        }
        else
        {
            ButtonBarButton button = null;
            ButtonBarButton[] buttonArray = this.weaponActive ? this.weaponButtons : this.implementButtons;
            foreach (ButtonBarButton button2 in buttonArray)
            {
                if (button2.command == command[0])
                {
                    button = button2;
                    break;
                }
            }
            if (button != null)
            {
                if (button.featForm == FeatData.FeatForm.Wondrous)
                {
                    CombatClient.ItemQueued(button.bodySlot, button.itemId);
                }
                else if (button.generalType == Combat.FeatType.Offensive)
                {
                    CombatClient.AttackInitiated(button.featId);
                }
                else
                {
                    CombatClient.FeatQueued(button.featId);
                }
            }
            else
            {
                GLog.Log(new object[] { "Invalid/not-hooked-up attack on command:", command });
            }
        }
    }

    public void DragEnd(GameObject go, Combat.FeatType featType, int featId)
    {
        if (!EntityDataClient.owner.combat.inCombat)
        {
            ButtonBarButton component = go.GetComponent<ButtonBarButton>();
            ButtonBarButton button2 = UICamera.hoveredObject.GetComponent<ButtonBarButton>();
            if ((component != null) && (button2 == null))
            {
                CommandCore.ExecuteCommand(string.Concat(new object[] { "UnsetAttackFeat ", (byte) component.featType, " ", EntityDataClient.owner.combat.weaponSetNumber, " ", component.hotbarIndex }), EntityDataClient.owner.entityId);
            }
        }
        this.ResetDragTargetValidity();
    }

    public void DragStart(Combat.FeatType featType, int featId)
    {
        if (!EntityDataClient.owner.combat.inCombat)
        {
            this.SetDragTargetValidity(featType, featId);
        }
    }

    private void GetTargetAndDistance(out GameObject target, out float distance)
    {
        GameObject player = PlayerEntityClient.GetPlayer();
        target = Targeting.selectedTarget;
        distance = 0f;
        if (target != null)
        {
            distance = Vector3.Distance(player.transform.position, target.transform.position);
        }
    }

    public void GetWeaponSprites()
    {
        foreach (UISprite sprite in base.GetComponentsInChildren<UISprite>())
        {
            if (sprite.name == "IconWeaponMain")
            {
                this.weaponIcons[0] = sprite;
                UIEventListener listener1 = UIEventListener.Get(sprite.gameObject);
                listener1.onHover = (UIEventListener.BoolDelegate) Delegate.Combine(listener1.onHover, new UIEventListener.BoolDelegate(this.HoverMainHand));
            }
            else if (sprite.name == "IconWeaponOff")
            {
                this.weaponIcons[1] = sprite;
                UIEventListener listener2 = UIEventListener.Get(sprite.gameObject);
                listener2.onHover = (UIEventListener.BoolDelegate) Delegate.Combine(listener2.onHover, new UIEventListener.BoolDelegate(this.HoverOffHand));
            }
            else if (sprite.name == "IconImplement")
            {
                this.implementIcon = sprite;
                UIEventListener listener3 = UIEventListener.Get(sprite.gameObject);
                listener3.onHover = (UIEventListener.BoolDelegate) Delegate.Combine(listener3.onHover, new UIEventListener.BoolDelegate(this.HoverImplement));
            }
        }
        GuiHelper.GuiAssertNotNull("Could not find weapon sprites!", this.weaponIcons);
        GuiHelper.GuiAssertNotNull("Could not ifnd implement sprite!", new object[] { this.implementIcon });
    }

    public void HoverImplement(GameObject go, bool isOver)
    {
        if (CombatClient.playerCombatVars != null)
        {
            this.HoverWeapon(CombatClient.playerCombatVars.GetImplement(), isOver, go);
        }
    }

    public void HoverMainHand(GameObject go, bool isOver)
    {
        if (CombatClient.playerCombatVars != null)
        {
            this.HoverWeapon(CombatClient.playerCombatVars.GetWeapon(CombatClassVars.LogicalHand.MAIN_HAND), isOver, go);
        }
    }

    public void HoverOffHand(GameObject go, bool isOver)
    {
        if (CombatClient.playerCombatVars != null)
        {
            this.HoverWeapon(CombatClient.playerCombatVars.GetWeapon(CombatClassVars.LogicalHand.OFF_HAND), isOver, go);
        }
    }

    public void HoverWeapon(CombatWeapon weapon, bool isOver, GameObject go)
    {
        if (!(isOver && (weapon != null)))
        {
            UITooltip.ShowText(null, null);
        }
        else
        {
            UITooltip.ShowText(weapon.GetDisplayName(0, 1, 0, true), go);
        }
    }

    public bool LoadingTickFinished()
    {
        List<ButtonBarButton> list = new List<ButtonBarButton>();
        List<ButtonBarButton> list2 = new List<ButtonBarButton>();
        foreach (ButtonBarButton button in base.GetComponentsInChildren<ButtonBarButton>())
        {
            if (button.name.StartsWith("Attack"))
            {
                list.Add(button);
                if ((button.name.EndsWith("1") || button.name.EndsWith("2")) || button.name.EndsWith("3"))
                {
                    button.Init(Combat.FeatType.Attack, FeatData.FeatForm.Primary, false, this.buttonNameToCommand[button.name]);
                }
                else
                {
                    button.Init(Combat.FeatType.Attack, FeatData.FeatForm.Secondary, false, this.buttonNameToCommand[button.name]);
                }
            }
            else if (button.name.StartsWith("Utility"))
            {
                list.Add(button);
                button.Init(Combat.FeatType.Utility, FeatData.FeatForm.Utility, false, this.buttonNameToCommand[button.name]);
            }
            else if (button.name.StartsWith("Consumable"))
            {
                list.Add(button);
                button.Init(Combat.FeatType.Expendable, FeatData.FeatForm.Wondrous, false, this.buttonNameToCommand[button.name]);
            }
            else if (button.name.StartsWith("Expendable"))
            {
                list2.Add(button);
                button.Init(Combat.FeatType.Expendable, FeatData.FeatForm.Universal, true, this.buttonNameToCommand[button.name]);
            }
            UIEventListener listener1 = UIEventListener.Get(button.gameObject);
            listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.ButtonClick));
            UIEventListener listener2 = UIEventListener.Get(button.gameObject);
            listener2.onDrop = (UIEventListener.ObjectDelegate) Delegate.Combine(listener2.onDrop, new UIEventListener.ObjectDelegate(this.OnDrop));
        }
        this.weaponButtons = list.ToArray();
        this.implementButtons = list2.ToArray();
        Transform transform = base.transform.Find("FeatPanel/WeaponSwap");
        Transform transform2 = base.transform.Find("FeatPanel/ImplementSwap");
        GuiHelper.GuiAssertNotNull("Couldn't find needed child.", new object[] { transform, transform2 });
        UIEventListener listener3 = UIEventListener.Get(transform.gameObject);
        listener3.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener3.onClick, new UIEventListener.VoidDelegate(this.SwapWeapons));
        UIEventListener listener4 = UIEventListener.Get(transform2.gameObject);
        listener4.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener4.onClick, new UIEventListener.VoidDelegate(this.SwapWeapons));
        foreach (UISprite sprite in transform.gameObject.GetComponentsInChildren<UISprite>())
        {
            if (sprite.name == "WeaponSet1")
            {
                this.weaponSetIndicators[0] = sprite;
            }
            else if (sprite.name == "WeaponSet2")
            {
                this.weaponSetIndicators[1] = sprite;
            }
        }
        foreach (UISprite sprite in transform2.gameObject.GetComponentsInChildren<UISprite>())
        {
            if (sprite.name == "ImplementSet1")
            {
                this.implementSetIndicators[0] = sprite;
            }
            else if (sprite.name == "ImplementSet2")
            {
                this.implementSetIndicators[1] = sprite;
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find weapon set indicators.", new object[] { this.weaponSetIndicators[0], this.weaponSetIndicators[1], this.implementSetIndicators[0], this.implementSetIndicators[1] });
        this.GetWeaponSprites();
        Transform transform3 = base.transform.Find("PixelPanel/GlobalCooldownTimer");
        GuiHelper.GuiAssertNotNull("Couldn't find needed child.", new object[] { transform3 });
        this.globalCooldownTimer = transform3.GetComponent<UIFilledSprite>();
        GuiHelper.GuiAssertNotNull("Couldn't find needed child.", new object[] { this.globalCooldownTimer });
        this.globalCooldownTimer.fillAmount = 0f;
        this.buttonLoadComplete = true;
        return true;
    }

    private void OnAwake()
    {
        ClientTick.buttonGuiLoadFinish = new GUtil.BoolFilterDelegate(this.LoadingTickFinished);
        ClientTick.buttonGuiTick = new GUtil.BoolFilterDelegate(this.SyncUpdate);
    }

    public void OnDestroy()
    {
        singleton = null;
    }

    public void OnDrop(GameObject go, GameObject draggedObject)
    {
        FeatGridItem component = draggedObject.GetComponent<FeatGridItem>();
        ButtonBarButton button = draggedObject.GetComponent<ButtonBarButton>();
        ButtonBarButton button2 = go.GetComponent<ButtonBarButton>();
        if ((EntityDataClient.owner.combat.inCombat || ((component == null) && (button == null))) || (button2 == null))
        {
            if (EntityDataClient.owner.combat.inCombat)
            {
                ChatGui.singleton.DisplayMessage("Cannot change feats in combat.", ChatClient.ERROR_COLOR);
            }
        }
        else
        {
            int id = (button != null) ? button.featId : component.featId;
            Combat.FeatType type = (button != null) ? button.featType : component.featType;
            FeatData featById = FeatDatabase.GetFeatById(id);
            if (((featById == null) || (button2.featType != type)) || (button2.featForm != featById.form))
            {
                ChatGui.singleton.DisplayMessage("Wrong kind of feat for this slot.", ChatClient.ERROR_COLOR);
            }
            else
            {
                string str = null;
                if (button2.featType == type)
                {
                    if ((type == Combat.FeatType.Attack) || (type == Combat.FeatType.Expendable))
                    {
                        str = string.Concat(new object[] { "SetAttackFeat ", id, " ", EntityDataClient.owner.combat.weaponSetNumber, " ", button2.hotbarIndex });
                    }
                    if (type == Combat.FeatType.Utility)
                    {
                        str = string.Concat(new object[] { "SetAttackFeat ", id, " ", 0, " ", button2.hotbarIndex });
                    }
                    else if (type == Combat.FeatType.Refresh)
                    {
                        str = string.Concat(new object[] { "SetNonAttackFeat ", id, " ", button2.hotbarIndex });
                    }
                }
                if (button != null)
                {
                    CommandCore.ExecuteCommand(string.Concat(new object[] { "UnsetAttackFeat ", (byte) button.featType, " ", EntityDataClient.owner.combat.weaponSetNumber, " ", button.hotbarIndex }), EntityDataClient.owner.entityId);
                }
                if (!string.IsNullOrEmpty(str))
                {
                    CommandCore.ExecuteCommand(str, EntityDataClient.owner.entityId);
                }
                else
                {
                    GLog.LogError(new object[] { "Cmd rejected", button2.featType, type });
                }
            }
        }
    }

    public void ResetDragTargetValidity()
    {
        if (this.buttonSetupComplete)
        {
            foreach (ButtonBarButton button in this.weaponButtons)
            {
                button.ResetDragTargetValidity();
            }
            foreach (ButtonBarButton button in this.implementButtons)
            {
                button.ResetDragTargetValidity();
            }
        }
    }

    public void SetAllButtons(CombatVars cv)
    {
        if (this.buttonLoadComplete)
        {
            GameObject obj2;
            float num;
            this.GetTargetAndDistance(out obj2, out num);
            this.SetAttackButtons(cv, obj2, num);
            this.SetExpendableButtons(cv, obj2, num);
            this.SetRefreshButtons(cv, obj2, num);
            this.SetUtilityButtons(cv, obj2, num);
            this.SetWondrousButtons(cv, obj2, num);
            this.SetGearButtons(cv, obj2, num);
            this.SetWeaponSetIndicator(cv);
            this.SetWeaponIcons(cv);
        }
    }

    private void SetAttackButtons(CombatVars cv, GameObject target, float distance)
    {
        AttackFeatVars[] varsArray = (from each in cv.combatClass.attackFeatSets
            where each.weaponSet == cv.weaponSetNumber
            select each).ToArray<AttackFeatVars>();
        foreach (ButtonBarButton button in this.weaponButtons)
        {
            if (button.featType == Combat.FeatType.Attack)
            {
                if (button.hotbarIndex >= varsArray.Length)
                {
                    button.Reset();
                }
                else
                {
                    AttackFeatVars vars = varsArray[button.hotbarIndex];
                    OffensiveFeatData feat = (vars.id == 0) ? null : OffensiveFeatData.GetAttackById(vars.id);
                    if (feat == null)
                    {
                        button.Reset();
                    }
                    else
                    {
                        button.Set(feat, vars.level, cv, target, distance);
                    }
                }
            }
        }
    }

    public void SetDragTargetValidity()
    {
        foreach (ButtonBarButton button in this.weaponButtons)
        {
            button.SetDragTargetValidity();
        }
        foreach (ButtonBarButton button in this.implementButtons)
        {
            button.SetDragTargetValidity();
        }
    }

    public void SetDragTargetValidity(Combat.FeatType featType, int featId)
    {
        FeatData featById = FeatDatabase.GetFeatById(featId);
        if (((featById != null) && (EntityDataClient.owner != null)) && (EntityDataClient.owner.combat != null))
        {
            OffensiveFeatData data2 = featById as OffensiveFeatData;
            if (data2 != null)
            {
                CombatWeapon weapon = EntityDataClient.owner.combat.GetWeapon(CombatClassVars.LogicalHand.MAIN_HAND);
                CombatWeapon weapon2 = EntityDataClient.owner.combat.GetWeapon(CombatClassVars.LogicalHand.OFF_HAND);
                if ((weapon == null) && (data2.form == FeatData.FeatForm.Primary))
                {
                    this.ResetDragTargetValidity();
                    return;
                }
                if (((weapon2 != null) && (data2.form == FeatData.FeatForm.Secondary)) && (data2.weaponCategoryId != weapon2.weaponCategoryId))
                {
                    this.ResetDragTargetValidity();
                    return;
                }
            }
            foreach (ButtonBarButton button in this.weaponButtons)
            {
                button.SetDragTargetValidity(featType, featById.form);
            }
            foreach (ButtonBarButton button in this.implementButtons)
            {
                button.SetDragTargetValidity(featType, featById.form);
            }
        }
    }

    private void SetExpendableButtons(CombatVars cv, GameObject target, float distance)
    {
        AttackFeatVars[] varsArray = (from each in cv.combatClass.expendableFeatSets
            where each.weaponSet == cv.weaponSetNumber
            select each).ToArray<AttackFeatVars>();
        foreach (ButtonBarButton button in this.implementButtons)
        {
            if ((button.featType == Combat.FeatType.Expendable) && (button.featForm != FeatData.FeatForm.Wondrous))
            {
                if (button.hotbarIndex >= varsArray.Length)
                {
                    button.Reset();
                }
                else
                {
                    AttackFeatVars vars = varsArray[button.hotbarIndex];
                    OffensiveFeatData feat = (vars.id == 0) ? null : OffensiveFeatData.GetAttackById(vars.id);
                    if (feat == null)
                    {
                        button.Reset();
                    }
                    else
                    {
                        button.Set(feat, vars.level, cv, target, distance);
                    }
                }
            }
        }
    }

    private void SetGearButtons(CombatVars cv, GameObject target, float distance)
    {
        IEnumerable<ButtonBarButton> enumerable = from button in this.implementButtons
            where button.featType == Combat.FeatType.None
            select button;
        foreach (ButtonBarButton button in enumerable)
        {
            button.Reset();
        }
    }

    private void SetNonAttackButtons(CombatVars cv, Combat.FeatType featType, int[] featIdSet, GameObject target, float distance)
    {
        foreach (ButtonBarButton button in from button in this.weaponButtons
            where button.featType == featType
            orderby button.hotbarIndex
            select button)
        {
            button.Reset();
        }
        IEnumerator<ButtonBarButton> enumerator = (from button in this.weaponButtons
            where button.featType == featType
            orderby button.hotbarIndex
            select button).GetEnumerator();
        enumerator.MoveNext();
        for (int i = 0; i < featIdSet.Length; i++)
        {
            NonAttackFeatData data;
            if ((featIdSet[i] != 0) && NonAttackFeatData.featsById.TryGetValue(featIdSet[i], out data))
            {
                enumerator.Current.Set(data, cv, target, distance);
                enumerator.MoveNext();
            }
        }
    }

    private void SetRefreshButtons(CombatVars cv, GameObject target, float distance)
    {
        this.SetNonAttackButtons(cv, Combat.FeatType.Refresh, cv.combatClass.refreshFeatIds, target, distance);
    }

    private void SetUtilityButtons(CombatVars cv, GameObject target, float distance)
    {
        foreach (ButtonBarButton button in this.weaponButtons)
        {
            if (button.featType == Combat.FeatType.Utility)
            {
                if (button.hotbarIndex >= cv.combatClass.utilityFeats.Length)
                {
                    button.Reset();
                }
                else
                {
                    AttackFeatVars vars = cv.combatClass.utilityFeats[button.hotbarIndex];
                    OffensiveFeatData feat = (vars.id == 0) ? null : OffensiveFeatData.GetAttackById(vars.id);
                    if (feat == null)
                    {
                        button.Reset();
                    }
                    else
                    {
                        button.Set(feat, vars.level, cv, target, distance);
                    }
                }
            }
        }
    }

    private void SetWeaponButtons(CombatVars cv)
    {
        GameObject obj2;
        float num;
        this.GetTargetAndDistance(out obj2, out num);
        this.SetAttackButtons(cv, obj2, num);
        this.SetExpendableButtons(cv, obj2, num);
        this.SetWeaponSetIndicator(cv);
        this.SetWeaponIcons(cv);
    }

    private void SetWeaponIcons(CombatVars cv)
    {
        CombatWeapon implement = cv.GetWeapon(CombatClassVars.LogicalHand.MAIN_HAND);
        UISprite sprite = this.weaponIcons[0];
        if (implement != null)
        {
            sprite.alpha = 1f;
            GuiHelper.SetSpriteWithFallback(sprite, implement.hudIcon, "icon_hud_weapon_unknown", false);
        }
        else
        {
            sprite.alpha = 0f;
        }
        implement = cv.GetWeapon(CombatClassVars.LogicalHand.OFF_HAND);
        sprite = this.weaponIcons[1];
        if (implement != null)
        {
            sprite.alpha = 1f;
            GuiHelper.SetSpriteWithFallback(sprite, implement.hudIcon, "icon_hud_weapon_unknown", false);
        }
        else
        {
            sprite.alpha = 0f;
        }
        implement = cv.GetImplement();
        if (implement != null)
        {
            this.implementIcon.alpha = 1f;
            GuiHelper.SetSpriteWithFallback(this.implementIcon, implement.hudIcon, "icon_hud_implement_unknown", false);
        }
        else
        {
            this.implementIcon.alpha = 0f;
        }
    }

    private void SetWeaponSetIndicator(CombatVars cv)
    {
        for (uint i = 0; i < 2; i++)
        {
            if (i == cv.weaponSetNumber)
            {
                this.weaponSetIndicators[i].spriteName = "hud_hotbar_button_weaponswitch_on";
                this.implementSetIndicators[i].spriteName = "hud_hotbar_button_implementswitch_on";
            }
            else
            {
                this.weaponSetIndicators[i].spriteName = "hud_hotbar_button_weaponswitch_off";
                this.implementSetIndicators[i].spriteName = "hud_hotbar_button_implementswitch_off";
            }
        }
    }

    private void SetWondrousButtons(CombatVars cv, GameObject target, float distance)
    {
        IEnumerable<ButtonBarButton> enumerable = from button in this.weaponButtons
            where button.featForm == FeatData.FeatForm.Wondrous
            select button;
        foreach (ButtonBarButton button in enumerable)
        {
            button.Set(cv, target, distance, FeatData.FeatForm.Wondrous);
        }
    }

    public void SwapWeapons(GameObject go)
    {
        CombatVars playerCombatVars = CombatClient.playerCombatVars;
        if (playerCombatVars != null)
        {
            CombatClient.SwapWeapons();
            if (PaperdollWindowGui.singleton != null)
            {
                PaperdollWindowGui.singleton.ContentsChanged();
            }
            this.SetWeaponButtons(playerCombatVars);
        }
    }

    public bool SyncUpdate()
    {
        CombatVars playerCombatVars = CombatClient.playerCombatVars;
        if ((EntityDataClient.owner != null) && (playerCombatVars != null))
        {
            GameObject obj2;
            float num;
            this.GetTargetAndDistance(out obj2, out num);
            if (!this.buttonSetupComplete)
            {
                this.SetAllButtons(playerCombatVars);
                this.buttonSetupComplete = true;
            }
            if (playerCombatVars.inCombat != this.prevInCombat)
            {
                int num2;
                for (num2 = 0; num2 < this.weaponButtons.Length; num2++)
                {
                    this.weaponButtons[num2].OnInCombat(playerCombatVars.inCombat);
                }
                for (num2 = 0; num2 < this.implementButtons.Length; num2++)
                {
                    this.implementButtons[num2].OnInCombat(playerCombatVars.inCombat);
                }
                this.prevInCombat = playerCombatVars.inCombat;
            }
            this.UpdateWeaponActive();
            foreach (ButtonBarButton button in this.weaponButtons)
            {
                button.UpdateButtonState(playerCombatVars, obj2, num);
            }
            foreach (ButtonBarButton button in this.implementButtons)
            {
                button.UpdateButtonState(playerCombatVars, obj2, num);
            }
            if (playerCombatVars.expendablesCooldownTime > CombatClient.CurrentTick)
            {
                if (this.cooldownStartTime == 0f)
                {
                    this.cooldownStartTime = Time.time;
                }
                float num3 = 1f - ((Time.time - this.cooldownStartTime) / CombatData.singleton.implementCooldownTime);
                this.globalCooldownTimer.fillAmount = num3;
            }
            else
            {
                this.cooldownStartTime = 0f;
                this.globalCooldownTimer.fillAmount = 0f;
            }
        }
        return true;
    }

    private void UpdateWeaponActive()
    {
        bool flag = !InputManager.GetAltModifier(InputManager.ModifierKeys.EITHER, InputManager.InputType.HELD);
        if (flag != this.weaponActive)
        {
            this.weaponActive = flag;
            this.AttackToggle(this.weaponActive);
        }
    }
}

