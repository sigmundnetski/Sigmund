﻿using GNGUI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using UnityEngine;

public static class EntityLoadClient
{
    private static List<AddEntityComponentsDelegate> addCustomCharacterComponents = new List<AddEntityComponentsDelegate>();
    public static bool AtlasTextures = true;
    private static GameObject cacheRoot;
    private static Dictionary<string, SkeletonCache> cacheSkeletonByRace = new Dictionary<string, SkeletonCache>();
    public const string camPosName = "campos";
    public const string CHAR_SHADER_NAME = "Pathfinder/Character_Full";
    public static Dictionary<string, UnityEngine.Object> characterPrefabs = new Dictionary<string, UnityEngine.Object>();
    private static CharacterShaders characterShaders = new CharacterShaders();
    public static bool CombineMeshes = true;
    private const string DEFAULT_FULL_SHADER_MAT = "shader_DefaultFull";
    private const string DEFAULT_HAIR_SHADER_MAT = "shader_DefaultHair";
    private const string DEFAULT_MERGED_SHADER_MAT = "shader_DefaultMerged";
    private static Dictionary<int, List<EquipmentAsset>> defnIdToAssets = new Dictionary<int, List<EquipmentAsset>>();
    private static Dictionary<int, string> defnIdToSkeleton = new Dictionary<int, string>();
    private static bool entitiesReady = false;
    private static string[] hideFlags = new string[0];
    private static string hideFlagString = null;
    private static bool modelsReady = false;
    public const string overheadPosName = "overheadpos";
    public static Dictionary<string, UnityEngine.Object> skeletonPrefabs = new Dictionary<string, UnityEngine.Object>();
    private static HashSet<string> slotsToRemove = new HashSet<string>();
    private static Dictionary<string, UnityEngine.Object> statueEntityPrefabs = new Dictionary<string, UnityEngine.Object>();
    private const string STEALTHED_FULL_SHADER_MAT = "shader_StealthedFull";
    private const string STEALTHED_HAIR_SHADER_MAT = "shader_StealthedHair";
    private const string STEALTHED_MERGED_SHADER_MAT = "shader_StealthedMerged";
    private static Dictionary<string, Color[]> tmpAssetColors = new Dictionary<string, Color[]>();
    private static int trashInt;
    private static string trashStr;
    public static Dictionary<string, UnityEngine.Object> weaponPrefabs = new Dictionary<string, UnityEngine.Object>();

    private static void AddOverheadAnchor(GameObject entityGO, GConst.CreateType flags, ref Transform overheadPosT)
    {
        if ((overheadPosT == null) || (overheadPosT.GetComponentInChildren<HUDText>() == null))
        {
            Vector3 vector = (overheadPosT != null) ? Vector3.zero : GetColliderTopBounds(entityGO);
            string str = (flags == GConst.CreateType.PLAYER) ? "SelfCombatText" : "CombatText";
            GameObject obj2 = (GameObject) UnityEngine.Object.Instantiate(UIClient.guiPrefabs[str], Vector3.zero, Quaternion.identity);
            obj2.name = "overheadpos";
            obj2.transform.parent = (overheadPosT != null) ? overheadPosT : entityGO.transform;
            obj2.transform.localPosition = vector;
            obj2.transform.localRotation = Quaternion.identity;
            overheadPosT = (overheadPosT != null) ? overheadPosT : obj2.transform;
        }
    }

    private static void AddPlayerCamPosAnchor(GameObject entityGO)
    {
        Transform transform = entityGO.transform.Find("campos");
        if (transform == null)
        {
            Vector3 colliderTopBounds = GetColliderTopBounds(entityGO);
            GameObject obj2 = new GameObject {
                name = "campos"
            };
            transform = obj2.transform;
            transform.parent = entityGO.transform;
            transform.localPosition = colliderTopBounds;
            transform.localRotation = Quaternion.identity;
        }
        if (null == transform.GetComponent<CameraGrabber>())
        {
            transform.gameObject.AddComponent<CameraGrabber>();
        }
    }

    private static void AddSharedComponents(GameObject newCharacter, GConst.CreateType flags)
    {
        if (flags != GConst.CreateType.TEST_EMPTY_ENTITY)
        {
            newCharacter.AddComponent<EntityVars>();
            newCharacter.AddComponent<Movement>();
        }
    }

    public static void CacheSmrsOnMerge(GameObject entity)
    {
        for (int i = entity.transform.childCount - 1; i >= 0; i--)
        {
            string str;
            string str2;
            string str3;
            Transform child = entity.transform.GetChild(i);
            if (GetAssetData(child.name, out str2, out str, out str3))
            {
                SkeletonCache assetCache = GetAssetCache(child.name);
                MoveBodyPart(assetCache.cacheTransform, child.gameObject, assetCache.cacheSkeletonBipedMap);
                foreach (SkinnedMeshRenderer renderer in child.GetComponentsInChildren<SkinnedMeshRenderer>())
                {
                    renderer.enabled = false;
                }
            }
        }
    }

    public static void ChangeCharacterShader(IEnumerable<SkinnedMeshRenderer> smrs, ShaderType type)
    {
        Shader defaultShaderMerged;
        Shader defaultShaderFull;
        Shader defaultShaderHair;
        Shader stealthedShaderMerged;
        Shader stealthedShaderFull;
        Shader stealthedShaderHair;
        if (type == ShaderType.DEFAULT)
        {
            stealthedShaderFull = characterShaders.stealthedShaderFull;
            stealthedShaderMerged = characterShaders.stealthedShaderMerged;
            stealthedShaderHair = characterShaders.stealthedShaderHair;
            defaultShaderFull = characterShaders.defaultShaderFull;
            defaultShaderMerged = characterShaders.defaultShaderMerged;
            defaultShaderHair = characterShaders.defaultShaderHair;
        }
        else if (type == ShaderType.STEALTH)
        {
            stealthedShaderFull = characterShaders.defaultShaderFull;
            stealthedShaderMerged = characterShaders.defaultShaderMerged;
            stealthedShaderHair = characterShaders.defaultShaderHair;
            defaultShaderFull = characterShaders.stealthedShaderFull;
            defaultShaderMerged = characterShaders.stealthedShaderMerged;
            defaultShaderHair = characterShaders.stealthedShaderHair;
        }
        else
        {
            GLog.LogError(new object[] { "Unknown shader type:", type });
            return;
        }
        foreach (SkinnedMeshRenderer renderer in smrs)
        {
            foreach (Material material in renderer.sharedMaterials)
            {
                if (material.shader == stealthedShaderFull)
                {
                    material.shader = defaultShaderFull;
                }
                else if (material.shader == stealthedShaderMerged)
                {
                    material.shader = defaultShaderMerged;
                }
                else if (material.shader == stealthedShaderHair)
                {
                    material.shader = defaultShaderHair;
                }
            }
        }
    }

    public static void ChangeCharacterShader(GameObject entity, ShaderType type)
    {
        ChangeCharacterShader(entity.GetComponentsInChildren<SkinnedMeshRenderer>(true), type);
    }

    public static void ClearCharacter(GameObject entity)
    {
        MergeJobService.OnObjectDestroyed(entity, true);
        for (int i = entity.transform.childCount - 1; i >= 0; i--)
        {
            Transform child = entity.transform.GetChild(i);
            if (child.name == "reserved_mergedSMR")
            {
                UnityEngine.Object.Destroy(child.gameObject);
            }
        }
    }

    public static GameObject CreateCharacter(int defnId, string skeletonName, IEnumerable<EquipmentAsset> allSlots, GConst.CreateType flags, Transform parent, Vector3 position, Quaternion rotation, string characterName)
    {
        UnityEngine.Object obj2;
        GameObject obj3;
        Dictionary<string, Transform> bipedMap = null;
        skeletonName = skeletonName.ToLower();
        if (statueEntityPrefabs.TryGetValue(skeletonName, out obj2))
        {
            obj3 = (GameObject) UnityEngine.Object.Instantiate(obj2);
            ResourceManager.RegisterForDynamicTextures(obj3);
        }
        else
        {
            if (!skeletonPrefabs.TryGetValue(skeletonName, out obj2))
            {
                throw new EntityLoadException(skeletonName + " is not a valid skeleton/prefab.\nCharacter options: " + GUtil.PrettyPrint(skeletonPrefabs.Keys, ", ", "[]") + "\nStatue options: " + GUtil.PrettyPrint(statueEntityPrefabs.Keys, ", ", "[]"));
            }
            obj3 = (GameObject) UnityEngine.Object.Instantiate(obj2);
            obj3.AddComponent<EntityCleanup>();
            WeaponComponent component = obj3.AddComponent<WeaponComponent>();
            bipedMap = GetBipedMap(FindRootBone(obj3), null);
            component.Init(bipedMap);
            SkinCharacter(obj3, defnId, allSlots, bipedMap);
        }
        if (flags == GConst.CreateType.PLAYER)
        {
            AddPlayerCamPosAnchor(obj3);
        }
        foreach (AddEntityComponentsDelegate delegate2 in addCustomCharacterComponents)
        {
            delegate2(obj3, flags);
        }
        obj3.AddComponent<BipedMap>().AssignVars(bipedMap);
        if (parent != null)
        {
            obj3.transform.parent = parent;
        }
        obj3.transform.position = position;
        obj3.transform.rotation = rotation;
        obj3.name = characterName;
        return obj3;
    }

    public static GameObject CreateCompleteCharacter(Entity entity, IEnumerable<EquipmentAsset> equipment, GConst.CreateType flags, Transform parent, Vector3 position, Quaternion rotation, string characterName)
    {
        if (!defnIdToSkeleton.ContainsKey(entity.entityDefnId))
        {
            throw new EntityLoadException(entity.entityDefnId + " is not a valid entity.\nSkeleton Options: " + GUtil.PrettyPrint(defnIdToSkeleton.Keys, ", ", "[]"));
        }
        List<EquipmentAsset> assets = new List<EquipmentAsset>(defnIdToAssets[entity.entityDefnId]);
        if (entity.physique != null)
        {
            GetAssetsFromPhysique(entity.physique, ref assets);
        }
        if (((byte) (entity.flags & EntityFlags.GmSuit)) == 2)
        {
            GetGmOverrideGear(entity.physique, ref assets);
        }
        else if (equipment != null)
        {
            assets.AddRange(equipment);
        }
        return CreateCharacter(entity.entityDefnId, defnIdToSkeleton[entity.entityDefnId], assets, flags, parent, position, rotation, characterName);
    }

    public static GameObject CreateCompleteCharacter(int defnId, bool displayGmSuit, PhysiqueRecord physique, IEnumerable<EquipmentAsset> equipment, GConst.CreateType flags, Transform parent, Vector3 position, Quaternion rotation, string characterName)
    {
        List<EquipmentAsset> assets = new List<EquipmentAsset>();
        if (physique != null)
        {
            GetAssetsFromPhysique(physique, ref assets);
        }
        if (displayGmSuit)
        {
            GetGmOverrideGear(physique, ref assets);
        }
        else if (equipment != null)
        {
            assets.AddRange(equipment);
        }
        return CreateCharacter(defnId, defnIdToSkeleton[defnId], assets, flags, parent, position, rotation, characterName);
    }

    public static GameObject CreateDefinedCharacter(int entityDefnId, GConst.CreateType flags, Transform parent, Vector3 position, Quaternion rotation, string characterName)
    {
        if (!(defnIdToSkeleton.ContainsKey(entityDefnId) && defnIdToAssets.ContainsKey(entityDefnId)))
        {
            throw new EntityLoadException(string.Concat(new object[] { entityDefnId, " is not a valid entity.\nSkeleton Options: ", GUtil.PrettyPrint(defnIdToSkeleton.Keys, ", ", "[]"), "\nAsset Options: ", GUtil.PrettyPrint(defnIdToAssets.Keys, ", ", "[]") }));
        }
        return CreateCharacter(entityDefnId, defnIdToSkeleton[entityDefnId], defnIdToAssets[entityDefnId], flags, parent, position, rotation, characterName);
    }

    public static bool ExtractBundles()
    {
        if ((((skeletonPrefabs.Count <= 0) || (characterPrefabs.Count <= 0)) || (weaponPrefabs.Count <= 0)) || (statueEntityPrefabs.Count <= 0))
        {
            foreach (GameObject obj2 in BundleService.LoadAll<GameObject>(BundleConsts.CHARACTER_BUNDLE))
            {
                characterPrefabs[obj2.name.ToLower()] = obj2;
            }
            foreach (GameObject obj2 in BundleService.LoadAll<GameObject>(BundleConsts.WEAPONS_BUNDLE))
            {
                weaponPrefabs[obj2.name.ToLower()] = obj2;
            }
            foreach (GameObject obj2 in BundleService.LoadAll<GameObject>(BundleConsts.Q5_GRANNY_BUNDLE))
            {
                skeletonPrefabs[obj2.name.ToLower()] = obj2;
            }
            foreach (GameObject obj2 in BundleService.LoadAll<GameObject>(BundleConsts.STATIC_ENTITY_BUNDLE))
            {
                statueEntityPrefabs[obj2.name.ToLower()] = obj2;
            }
            foreach (KeyValuePair<string, UnityEngine.Object> pair in skeletonPrefabs)
            {
                GrannyAnimator component = ((GameObject) pair.Value).GetComponent<GrannyAnimator>();
                if (component != null)
                {
                    GrannyHelper.FixAnimPaths(component);
                }
            }
            foreach (Material material in BundleService.LoadAll<Material>(BundleConsts.CHARACTER_BUNDLE))
            {
                if (material.name == "shader_DefaultFull")
                {
                    characterShaders.defaultShaderFull = material.shader;
                }
                else if (material.name == "shader_DefaultMerged")
                {
                    characterShaders.defaultShaderMerged = material.shader;
                }
                else if (material.name == "shader_DefaultHair")
                {
                    characterShaders.defaultShaderHair = material.shader;
                }
                else if (material.name == "shader_StealthedFull")
                {
                    characterShaders.stealthedShaderFull = material.shader;
                }
                else if (material.name == "shader_StealthedMerged")
                {
                    characterShaders.stealthedShaderMerged = material.shader;
                }
                else if (material.name == "shader_StealthedHair")
                {
                    characterShaders.stealthedShaderHair = material.shader;
                }
            }
            if (((((characterShaders.defaultShaderFull == null) || (characterShaders.defaultShaderMerged == null)) || ((characterShaders.stealthedShaderFull == null) || (characterShaders.stealthedShaderMerged == null))) || (characterShaders.defaultShaderHair == null)) || (characterShaders.stealthedShaderHair == null))
            {
                GLog.LogError(new object[] { "Character shader DNE:", "\n  default-full null?", characterShaders.defaultShaderMerged == null, "\n  default-merged null?", characterShaders.defaultShaderMerged == null, "\n  default-hair null?", characterShaders.defaultShaderHair == null, "\n  stealthed-full null?", characterShaders.stealthedShaderFull == null, "\n  stealthed-merged null?", characterShaders.stealthedShaderMerged == null, "\n  stealthed-hair null?", characterShaders.stealthedShaderHair == null });
            }
            else if (characterShaders.defaultShaderFull.name != "Pathfinder/Character_Full")
            {
                GLog.LogError(new object[] { "Incorrect character shader. Expected", "'Pathfinder/Character_Full'", "but got", "'" + characterShaders.defaultShaderFull.name + "'" });
            }
            cacheRoot = new GameObject("cacheRoot");
            cacheRoot.transform.position = Vector3.zero;
            UnityEngine.Object.DontDestroyOnLoad(cacheRoot);
        }
        return true;
    }

    public static Transform FindRootBone(GameObject skeleton)
    {
        if (skeleton == null)
        {
            return null;
        }
        Transform transform = skeleton.transform.FindChild("GrannyRootBone");
        if ((transform != null) && (transform.childCount == 0))
        {
            transform = null;
        }
        if (transform == null)
        {
            transform = skeleton.transform.FindChild("biped");
        }
        return transform;
    }

    public static Transform FindRootBone(Transform skeleton)
    {
        if (skeleton == null)
        {
            return null;
        }
        Transform transform = skeleton.FindChild("GrannyRootBone");
        if ((transform != null) && (transform.childCount == 0))
        {
            transform = null;
        }
        if (transform == null)
        {
            transform = skeleton.FindChild("biped");
        }
        return transform;
    }

    internal static GameObject GetAsset(string assetName)
    {
        if (!(characterPrefabs.ContainsKey(assetName) || weaponPrefabs.ContainsKey(assetName)))
        {
            return null;
        }
        SkeletonCache assetCache = GetAssetCache(assetName);
        GameObject gameObject = null;
        Transform transform = assetCache.cacheSkeleton.transform.FindChild(assetName);
        if (transform != null)
        {
            gameObject = transform.gameObject;
        }
        if ((gameObject == null) && (characterPrefabs.ContainsKey(assetName) || weaponPrefabs.ContainsKey(assetName)))
        {
            gameObject = LoadAsset(assetName, assetCache);
        }
        if (gameObject == null)
        {
            GLog.LogError(new object[] { "Failed to load asset:", assetName, characterPrefabs.Keys, weaponPrefabs.Keys });
        }
        return gameObject;
    }

    internal static SkeletonCache GetAssetCache(string assetName)
    {
        string str;
        SkeletonCache cache;
        if (assetName.ToLower().Contains("_weapon"))
        {
            assetName = str = "_weapon";
        }
        else
        {
            string str2;
            if (!GetAssetData(assetName, out str, out str2, out str2))
            {
                throw new Exception("Can't load cache skeleton for asset:" + assetName);
            }
        }
        if (!cacheSkeletonByRace.TryGetValue(str, out cache))
        {
            cacheSkeletonByRace[str] = cache = new SkeletonCache(assetName);
        }
        return cache;
    }

    public static bool GetAssetData(string assetName, out string race, out string gender, out string slot)
    {
        string str;
        slot = (string) (str = null);
        gender = race = str;
        UnityEngine.Object obj2 = null;
        if (!(characterPrefabs.TryGetValue(assetName, out obj2) && (obj2 != null)))
        {
            return PrebuiltModelData.ExtractFromName(assetName, out trashInt, out race, out gender, out trashInt, out slot);
        }
        AssetMetadata component = ((GameObject) obj2).GetComponent<AssetMetadata>();
        if (component == null)
        {
            return PrebuiltModelData.ExtractFromName(assetName, out trashInt, out race, out gender, out trashInt, out slot);
        }
        if (!component.TryGetData("race", out race))
        {
            return false;
        }
        if (!component.TryGetData("gender", out gender))
        {
            return false;
        }
        if (!component.TryGetData("equipmentType", out slot))
        {
            return false;
        }
        race = race.ToLower();
        gender = gender.Substring(0, 1).ToLower();
        slot = slot.ToLower();
        return true;
    }

    private static void GetAssetsFromPhysique(PhysiqueRecord physique, ref List<EquipmentAsset> assets)
    {
        int num;
        string str2;
        RaceData data = RaceData.raceById[physique.raceId];
        char gender = (char) physique.gender;
        RaceColorData byId = RaceColorData.GetById(physique.skinColorId);
        RaceColorData data3 = RaceColorData.GetById(physique.eyeColorId);
        RaceColorData data4 = RaceColorData.GetById(physique.hairColorId);
        RaceColorData data5 = RaceColorData.GetById(physique.suitColorId);
        if (physique.bodyAssetVariant != -1)
        {
            string str = string.Format("t0_bodycmpnnt_v{0}_{1}_{2}_upg0_body", physique.bodyAssetVariant, data.name, gender);
            assets.Add(new EquipmentAsset(str, byId.colorMat, byId.colorUser1, byId.colorUser2));
        }
        else if (physique.skinColorId != 0)
        {
            for (num = 0; num < assets.Count; num++)
            {
                PrebuiltModelData.ExtractFromName(assets[num].assetName, out trashInt, out trashStr, out trashStr, out trashInt, out str2);
                if (str2 == "body")
                {
                    assets[num] = new EquipmentAsset(assets[num].assetName, byId.colorMat, byId.colorUser1, byId.colorUser2);
                    break;
                }
            }
        }
        if (physique.faceAssetVariant != -1)
        {
            string str3 = string.Format("t0_bodycmpnnt_v{0}_{1}_{2}_upg0_face", physique.faceAssetVariant, data.name, gender);
            assets.Add(new EquipmentAsset(str3, byId.colorMat, byId.colorUser1, data3.colorUser2));
        }
        else if ((physique.skinColorId != 0) || (physique.eyeColorId != 0))
        {
            Color black = Color.black;
            Color color2 = Color.black;
            Color color3 = Color.black;
            if (physique.skinColorId != 0)
            {
                black = byId.colorMat;
                color2 = byId.colorUser1;
            }
            if (physique.eyeColorId != 0)
            {
                color3 = data3.colorUser2;
            }
            for (num = 0; num < assets.Count; num++)
            {
                PrebuiltModelData.ExtractFromName(assets[num].assetName, out trashInt, out trashStr, out trashStr, out trashInt, out str2);
                if (str2 == "face")
                {
                    assets[num] = new EquipmentAsset(assets[num].assetName, black, color2, color3);
                    break;
                }
            }
        }
        if (physique.hairAssetVariant != -1)
        {
            string str4 = string.Empty;
            switch (gender)
            {
                case 'f':
                    str4 = string.Format("t0_bodycmpnnt_v{0}_{1}_{2}_upg0_hair", physique.hairAssetVariant, data.name, gender);
                    break;

                case 'm':
                    str4 = string.Format("t0_bodycomplt_v{0}_{1}_{2}_upg0_hair", physique.hairAssetVariant, data.name, gender);
                    break;
            }
            assets.Add(new EquipmentAsset(str4, data4.colorMat, data4.colorUser1, data4.colorUser2));
        }
        else if (physique.hairColorId != 0)
        {
            for (num = 0; num < assets.Count; num++)
            {
                PrebuiltModelData.ExtractFromName(assets[num].assetName, out trashInt, out trashStr, out trashStr, out trashInt, out str2);
                if (str2 == "hair")
                {
                    assets[num] = new EquipmentAsset(assets[num].assetName, data4.colorMat, data4.colorUser1, data4.colorUser2);
                    break;
                }
            }
        }
        if (physique.suitColorId != 0)
        {
            for (num = 0; num < assets.Count; num++)
            {
                PrebuiltModelData.ExtractFromName(assets[num].assetName, out trashInt, out trashStr, out trashStr, out trashInt, out str2);
                switch (str2)
                {
                    case "suit":
                    case "glove":
                    case "boot":
                    case "back":
                    case "helmet":
                        assets[num] = new EquipmentAsset(assets[num].assetName, data5.colorMat, data5.colorUser1, data5.colorUser2);
                        break;
                }
            }
        }
    }

    public static Dictionary<int, string> GetAvailableAssetsFor(string slotIn, string raceIn, string genderIn)
    {
        Dictionary<int, string> dictionary = new Dictionary<int, string>();
        slotIn = slotIn.ToLower();
        raceIn = raceIn.ToLower();
        genderIn = genderIn.ToLower();
        foreach (KeyValuePair<string, UnityEngine.Object> pair in characterPrefabs)
        {
            AssetMetadata component = ((GameObject) pair.Value).GetComponent<AssetMetadata>();
            if (component != null)
            {
                int num;
                int num2;
                string data = component.GetData("equipmentType");
                string str2 = component.GetData("race");
                string str3 = component.GetData("gender");
                if ((((data == slotIn) && (str2 == raceIn)) && (str3 == genderIn)) && (PrebuiltModelData.ExtractFromName(pair.Key, out num, out trashStr, out trashStr, out num2, out trashStr) && (num2 == 0)))
                {
                    dictionary[num] = pair.Key;
                }
            }
        }
        return dictionary;
    }

    public static Dictionary<string, Transform> GetBipedMap(Transform skeletonBone, Dictionary<string, Transform> bipedMap = null)
    {
        if (skeletonBone == null)
        {
            return null;
        }
        if (bipedMap == null)
        {
            bipedMap = new Dictionary<string, Transform>();
        }
        bipedMap[skeletonBone.name.ToLower()] = skeletonBone;
        foreach (Transform transform in skeletonBone)
        {
            GetBipedMap(transform, bipedMap);
        }
        return bipedMap;
    }

    private static Vector3 GetColliderTopBounds(GameObject entityGO)
    {
        float num;
        Vector3 vector = new Vector3(0f, 1f, 0f);
        Collider[] components = entityGO.GetComponents<Collider>();
        if ((components != null) && (components.Length > 0))
        {
            num = 0f;
            foreach (Collider collider in components)
            {
                num = Mathf.Max(num, collider.bounds.max.y);
            }
            return new Vector3(0f, num, 0f);
        }
        Collider[] componentsInChildren = entityGO.transform.GetComponentsInChildren<Collider>(true);
        if ((componentsInChildren != null) && (componentsInChildren.Length > 0))
        {
            num = 0f;
            foreach (Collider collider in componentsInChildren)
            {
                num = Mathf.Max(num, collider.bounds.max.y - entityGO.transform.position.y);
            }
            return new Vector3(0f, num, 0f);
        }
        GLog.LogWarning(new object[] { "Cannot auto-generate a fallback pos for: ", entityGO.name });
        return vector;
    }

    private static void GetGmOverrideGear(PhysiqueRecord physique, ref List<EquipmentAsset> assets)
    {
        if (PrebuiltModelData.gmOverride != null)
        {
            RaceData data = RaceData.raceById[physique.raceId];
            char gender = (char) physique.gender;
            foreach (string str in PrebuiltModelData.gmOverride.assetList)
            {
                assets.Add(new EquipmentAsset(string.Format(str, data.name, gender).ToLower()));
            }
        }
    }

    public static Transform[] GetNewBones(Transform[] oldBones, Dictionary<string, Transform> bipedMap)
    {
        Transform[] transformArray = new Transform[oldBones.Length];
        bool flag = true;
        for (int i = 0; i < oldBones.Length; i++)
        {
            if (oldBones[i] != null)
            {
                string key = oldBones[i].name.ToLower();
                flag &= bipedMap.TryGetValue(key, out transformArray[i]);
                if (!(flag || bipedMap.ContainsKey(key)))
                {
                    GLog.LogWarning(new object[] { "Missing Bone:", key, ", Bones: ", bipedMap.Count, " ", bipedMap.Keys });
                }
            }
        }
        return (flag ? transformArray : null);
    }

    public static HUDText GetOverheadHudText(GameObject entityGO)
    {
        Transform overheadTrans = GetOverheadTrans(entityGO);
        HUDText componentInChildren = overheadTrans.GetComponentInChildren<HUDText>();
        if (componentInChildren == null)
        {
            AddOverheadAnchor(entityGO, EntityCore.GetEntity(entityGO).createType, ref overheadTrans);
            componentInChildren = overheadTrans.GetComponentInChildren<HUDText>();
        }
        return componentInChildren;
    }

    public static Transform GetOverheadTrans(GameObject entityGO)
    {
        Transform overheadPosT = entityGO.transform.FindChild("overheadpos");
        if (overheadPosT == null)
        {
            AddOverheadAnchor(entityGO, EntityCore.GetEntity(entityGO).createType, ref overheadPosT);
        }
        return overheadPosT;
    }

    public static bool GetWeaponVis(GameObject entity)
    {
        WeaponComponent component = entity.GetComponent<WeaponComponent>();
        return ((component != null) && component.GetWeaponVis());
    }

    public static bool HasMetadata(string assetName)
    {
        UnityEngine.Object obj2 = null;
        if (!characterPrefabs.TryGetValue(assetName, out obj2))
        {
            return false;
        }
        if (obj2 == null)
        {
            return false;
        }
        return (((GameObject) obj2).GetComponent<AssetMetadata>() != null);
    }

    private static GameObject LoadAsset(string assetName, SkeletonCache cache)
    {
        UnityEngine.Object obj2 = null;
        if (!(characterPrefabs.TryGetValue(assetName, out obj2) || weaponPrefabs.TryGetValue(assetName, out obj2)))
        {
            return null;
        }
        GameObject original = (GameObject) obj2;
        GameObject obj4 = (GameObject) UnityEngine.Object.Instantiate(original);
        ResourceManager.RegisterForNondynamicTextures(obj4, false, false);
        obj4.name = assetName;
        if (obj4.GetComponentInChildren<SkinnedMeshRenderer>() != null)
        {
            LoadSkinnedAsset(obj4, assetName, cache);
        }
        else
        {
            obj4.transform.parent = cache.cacheSkeleton.transform;
            obj4.transform.localPosition = original.transform.position;
            obj4.transform.localRotation = original.transform.rotation;
            obj4.transform.localScale = original.transform.localScale;
        }
        return obj4;
    }

    private static void LoadSkinnedAsset(GameObject instance, string assetName, SkeletonCache cache)
    {
        SkinnedMeshRenderer[] componentsInChildren = instance.GetComponentsInChildren<SkinnedMeshRenderer>(true);
        foreach (SkinnedMeshRenderer renderer in componentsInChildren)
        {
            renderer.enabled = false;
            Transform[] newBones = GetNewBones(renderer.bones, cache.cacheSkeletonBipedMap);
            if (null == newBones)
            {
                GLog.LogError(new object[] { "LoadBodyPartToCache, failed to move bodypart:", assetName });
            }
            else
            {
                Transform transform = null;
                if (renderer.rootBone != null)
                {
                    cache.cacheSkeletonBipedMap.TryGetValue(renderer.rootBone.name.ToLower(), out transform);
                }
                renderer.bones = newBones;
                renderer.rootBone = transform;
            }
        }
        Transform transform2 = FindRootBone(instance);
        if (transform2 != null)
        {
            UnityEngine.Object.Destroy(transform2.gameObject);
        }
        instance.transform.parent = cache.cacheSkeleton.transform;
        instance.transform.localPosition = Vector3.zero;
        instance.transform.localRotation = Quaternion.identity;
    }

    public static void ModifyCharacter(GameObject entityObj, int entDefnId, PhysiqueRecord physique, IEnumerable<EquipmentAsset> fixedSlots)
    {
        RemoveSmrsOnCleanup(entityObj, false);
        BipedMap component = entityObj.GetComponent<BipedMap>();
        if (component == null)
        {
            Dictionary<string, Transform> bipedMap = GetBipedMap(FindRootBone(entityObj), null);
            component = entityObj.AddComponent<BipedMap>();
            component.AssignVars(bipedMap);
        }
        List<EquipmentAsset> assets = new List<EquipmentAsset>();
        if (physique != null)
        {
            GetAssetsFromPhysique(physique, ref assets);
        }
        if (((byte) (EntityCore.GetEntity(entityObj).flags & EntityFlags.GmSuit)) == 2)
        {
            GetGmOverrideGear(physique, ref assets);
        }
        else if (assets != null)
        {
            assets.AddRange(fixedSlots);
        }
        SkinCharacter(entityObj, entDefnId, assets, component.GetMap());
    }

    public static void ModifyCharacter(GameObject entityObj, int entDefnId, bool displayGmSuit, PhysiqueRecord physique, Dictionary<string, EquipmentAsset> fixedSlots)
    {
        RemoveSmrsOnCleanup(entityObj, false);
        BipedMap component = entityObj.GetComponent<BipedMap>();
        if (component == null)
        {
            Dictionary<string, Transform> bipedMap = GetBipedMap(FindRootBone(entityObj), null);
            component = entityObj.AddComponent<BipedMap>();
            component.AssignVars(bipedMap);
        }
        List<EquipmentAsset> assets = new List<EquipmentAsset>();
        if (physique != null)
        {
            GetAssetsFromPhysique(physique, ref assets);
        }
        if (displayGmSuit)
        {
            GetGmOverrideGear(physique, ref assets);
        }
        else if (assets != null)
        {
            assets.AddRange(fixedSlots.Values);
        }
        SkinCharacter(entityObj, entDefnId, assets, component.GetMap());
    }

    private static void MoveBodyPart(Transform destination, GameObject bodyPart, Dictionary<string, Transform> bipedMap)
    {
        SkinnedMeshRenderer[] componentsInChildren = bodyPart.GetComponentsInChildren<SkinnedMeshRenderer>(true);
        foreach (SkinnedMeshRenderer renderer in componentsInChildren)
        {
            Transform[] newBones = GetNewBones(renderer.bones, bipedMap);
            if (null != newBones)
            {
                Transform transform = null;
                if (renderer.rootBone != null)
                {
                    bipedMap.TryGetValue(renderer.rootBone.name.ToLower(), out transform);
                }
                renderer.bones = newBones;
                renderer.rootBone = transform;
                renderer.enabled = true;
                ResetShader(renderer);
            }
        }
        if (destination != null)
        {
            bodyPart.transform.parent = destination;
            bodyPart.transform.localPosition = Vector3.zero;
            bodyPart.transform.localRotation = Quaternion.identity;
        }
    }

    internal static void MoveWeapon(Transform destination, GameObject weaponGO, Dictionary<string, Transform> bipedMap, CombatClassVars.LogicalHand hand)
    {
        if (destination == null)
        {
            GLog.LogError(new object[] { "Weapon could not be placed on target", destination, weaponGO, hand, "so it has been destroyed instead." });
            UnityEngine.Object.Destroy(weaponGO);
        }
        else
        {
            Transform transform = weaponGO.transform;
            if (weaponGO.GetComponent<SkinnedMeshRenderer>() != null)
            {
                MoveBodyPart(destination, weaponGO, bipedMap);
            }
            else
            {
                Vector3 localPosition = transform.localPosition;
                Quaternion localRotation = transform.localRotation;
                Vector3 localScale = transform.localScale;
                transform.parent = destination;
                transform.localPosition = localPosition;
                transform.localRotation = localRotation;
                transform.localScale = localScale;
            }
            weaponGO.GetComponentsInChildren<Renderer>(true)[0].enabled = false;
        }
    }

    private static bool RaceIsAtlasable(string race)
    {
        if (string.IsNullOrEmpty(race))
        {
            return false;
        }
        race = race.ToLower();
        RaceData data = null;
        return (RaceData.raceByName.TryGetValue(race, out data) && data.atlasable);
    }

    public static void RegisterAddComponentDelegates(AddEntityComponentsDelegate newDelegate)
    {
        addCustomCharacterComponents.Add(newDelegate);
    }

    public static void RemoveSmrsOnCleanup(GameObject entity, bool isDestroying)
    {
        MergeJobService.OnObjectDestroyed(entity, isDestroying);
        for (int i = entity.transform.childCount - 1; i >= 0; i--)
        {
            string str;
            string str2;
            string str3;
            Transform child = entity.transform.GetChild(i);
            if (GetAssetData(child.name, out str2, out str, out str3))
            {
                SkeletonCache assetCache = GetAssetCache(child.name);
                MoveBodyPart(assetCache.cacheTransform, child.gameObject, assetCache.cacheSkeletonBipedMap);
                foreach (SkinnedMeshRenderer renderer in child.gameObject.GetComponentsInChildren<SkinnedMeshRenderer>())
                {
                    renderer.enabled = false;
                }
            }
            else if (!(CombineMeshes || !(child.name == "reserved_mergedSMR")))
            {
                UnityEngine.Object.Destroy(child.gameObject);
            }
        }
    }

    private static void ResetShader(SkinnedMeshRenderer renderer)
    {
        foreach (Material material in renderer.sharedMaterials)
        {
            if (material.shader == characterShaders.stealthedShaderFull)
            {
                material.shader = characterShaders.defaultShaderFull;
            }
            else if (material.shader == characterShaders.stealthedShaderMerged)
            {
                material.shader = characterShaders.defaultShaderMerged;
            }
            else if (material.shader == characterShaders.stealthedShaderHair)
            {
                material.shader = characterShaders.defaultShaderHair;
            }
        }
    }

    public static void ReskinCharacter(string[] args, EntityId playerEntityId)
    {
        Entity entity = EntityCore.GetEntity(ref playerEntityId);
        if ((entity != null) && (entity.gameObject != null))
        {
            BipedMap component = entity.gameObject.GetComponent<BipedMap>();
            if (component == null)
            {
                Dictionary<string, Transform> bipedMap = GetBipedMap(FindRootBone(entity.gameObject), null);
                component = entity.gameObject.AddComponent<BipedMap>();
                component.AssignVars(bipedMap);
            }
            RemoveSmrsOnCleanup(entity.gameObject, false);
            SkinCharacter(entity.gameObject, entity.entityDefnId, defnIdToAssets[entity.entityDefnId], component.GetMap());
        }
    }

    public static void SetWeaponVis(GameObject entity, bool visible)
    {
        WeaponComponent component = entity.GetComponent<WeaponComponent>();
        if (component != null)
        {
            component.SetWeaponVis(visible);
        }
    }

    private static void SkinCharacter(GameObject entity, int defnId, IEnumerable<EquipmentAsset> assetNames, Dictionary<string, Transform> bipedMap = null)
    {
        string name = null;
        GameObject obj2;
        AssetMetadata[] componentsInChildren;
        int num;
        int num2;
        string str2;
        char gender = '\0';
        bool isUserPlayable = false;
        bool atlasable = true;
        EntityDefnData data = null;
        if (defnId != 0)
        {
            data = EntityDefnData.defnById[defnId];
            RaceData data2 = RaceData.raceById[data.raceId];
            atlasable = data2.atlasable;
            isUserPlayable = data2.IsUserPlayable;
            name = data2.name;
            gender = (char) data.gender;
        }
        slotsToRemove.Clear();
        bool flag3 = true;
        foreach (EquipmentAsset asset in assetNames)
        {
            if (!string.IsNullOrEmpty(asset.assetName))
            {
                obj2 = GetAsset(asset.assetName);
                if (obj2 != null)
                {
                    componentsInChildren = obj2.GetComponentsInChildren<AssetMetadata>();
                    if (componentsInChildren == null)
                    {
                        atlasable = false;
                    }
                    num = 0;
                    while (num < componentsInChildren.Length)
                    {
                        if (componentsInChildren[num].TryGetData("hideFlags", out hideFlagString))
                        {
                            hideFlags = hideFlagString.Split(new char[] { ',' });
                            num2 = 0;
                            while (num2 < hideFlags.Length)
                            {
                                str2 = hideFlags[num2].Trim();
                                if (!string.IsNullOrEmpty(str2))
                                {
                                    slotsToRemove.Add(str2);
                                }
                                num2++;
                            }
                        }
                        if ((isUserPlayable && flag3) && (componentsInChildren[num].TryGetData("slotID", out str2) && (str2 == "suitMain")))
                        {
                            flag3 = false;
                        }
                        if (atlasable)
                        {
                            string result = null;
                            if (!(!componentsInChildren[num].TryGetData("race", out result) || RaceIsAtlasable(result)))
                            {
                                atlasable = false;
                            }
                        }
                        num++;
                    }
                }
            }
        }
        if ((isUserPlayable && flag3) && (gender != '\0'))
        {
            string str4 = string.Format("t1_psnclothes_v1_{0}_{1}_upg0_suit", name, gender);
            List<EquipmentAsset> list = new List<EquipmentAsset> {
                new EquipmentAsset(str4)
            };
            list.AddRange(assetNames);
            assetNames = list;
            slotsToRemove.Clear();
            foreach (EquipmentAsset asset in assetNames)
            {
                if (!string.IsNullOrEmpty(asset.assetName))
                {
                    obj2 = GetAsset(asset.assetName);
                    if (obj2 != null)
                    {
                        componentsInChildren = obj2.GetComponentsInChildren<AssetMetadata>();
                        num = 0;
                        while (num < componentsInChildren.Length)
                        {
                            if (componentsInChildren[num].TryGetData("hideFlags", out hideFlagString))
                            {
                                hideFlags = hideFlagString.Split(new char[] { ',' });
                                for (num2 = 0; num2 < hideFlags.Length; num2++)
                                {
                                    str2 = hideFlags[num2].Trim();
                                    if (!string.IsNullOrEmpty(str2))
                                    {
                                        slotsToRemove.Add(str2);
                                    }
                                }
                            }
                            num++;
                        }
                    }
                }
            }
        }
        Dictionary<string, EquipmentAsset> dictionary = new Dictionary<string, EquipmentAsset>();
        Transform destination = entity.transform;
        foreach (EquipmentAsset asset in assetNames)
        {
            if (!string.IsNullOrEmpty(asset.assetName))
            {
                obj2 = GetAsset(asset.assetName);
                if (obj2 != null)
                {
                    MoveBodyPart(destination, obj2, bipedMap);
                    componentsInChildren = obj2.GetComponentsInChildren<AssetMetadata>();
                    for (num = 0; num < componentsInChildren.Length; num++)
                    {
                        SkinnedMeshRenderer component = componentsInChildren[num].GetComponent<SkinnedMeshRenderer>();
                        if (component != null)
                        {
                            str2 = componentsInChildren[num].GetData("slotID");
                            if (!(string.IsNullOrEmpty(str2) || !slotsToRemove.Contains(str2)))
                            {
                                component.enabled = false;
                            }
                            dictionary[component.name] = asset;
                        }
                    }
                }
                else
                {
                    GLog.LogError(new object[] { "Failed to load asset:", asset.assetName, characterPrefabs.Keys });
                }
            }
        }
        if (CombineMeshes)
        {
            MergeJobService.MergeJob job = MergeJobService.RequestNewJob(entity, dictionary);
            if ((job.PreCombineMeshes() && AtlasTextures) && atlasable)
            {
                MergeJobService.AddJob(job);
            }
        }
    }

    private static void SkinCharacter(GameObject entity, int defnId, IEnumerable<string> assetNames, Dictionary<string, Transform> bipedMap = null)
    {
        List<EquipmentAsset> list = new List<EquipmentAsset>();
        foreach (string str in assetNames)
        {
            list.Add(new EquipmentAsset(str));
        }
        SkinCharacter(entity, defnId, list, bipedMap);
    }

    private static void SyncStart()
    {
        BundleService.StartLoadingBundle(BundleConsts.CHARACTER_BUNDLE, false);
        BundleService.StartLoadingBundle(BundleConsts.WEAPONS_BUNDLE, false);
        BundleService.StartLoadingBundle(BundleConsts.Q5_GRANNY_BUNDLE, false);
        BundleService.StartLoadingBundle(BundleConsts.STATIC_ENTITY_BUNDLE, false);
        StaticDataService.RegisterCallback<EntityDefnData>(new StaticDataService.StaticDataServiceCallback(EntityLoadClient.UpdateEntityData));
        StaticDataService.RegisterCallback<PrebuiltModelData>(new StaticDataService.StaticDataServiceCallback(EntityLoadClient.UpdateModelData));
        RegisterAddComponentDelegates(new AddEntityComponentsDelegate(EntityLoadClient.AddSharedComponents));
    }

    public static void ToggleMeshMerge(string[] args, EntityId playerEntityId)
    {
        if (args.Length == 1)
        {
            CombineMeshes = !CombineMeshes;
        }
        else
        {
            for (int i = 1; i < args.Length; i++)
            {
                if (args[i] == "c")
                {
                    CombineMeshes = !CombineMeshes;
                }
                else if (args[i] == "a")
                {
                    AtlasTextures = !AtlasTextures;
                }
            }
        }
        ChatGui.singleton.DisplayMessage("Mesh Combining: " + (CombineMeshes ? "enabled" : "disabled") + ", Texture Atlasing: " + (AtlasTextures ? "enabled." : "disabled."), ChatClient.DEFAULT_COLOR);
    }

    private static void UpdateDefinitions()
    {
        if (entitiesReady && modelsReady)
        {
            Dictionary<int, PrebuiltModelData> dictionary = new Dictionary<int, PrebuiltModelData>();
            foreach (PrebuiltModelData data in StaticDataService.GetValues<PrebuiltModelData>())
            {
                dictionary[data.id] = data;
            }
            foreach (EntityDefnData data2 in StaticDataService.GetValues<EntityDefnData>())
            {
                PrebuiltModelData data3;
                if (dictionary.TryGetValue(data2.modelId, out data3))
                {
                    defnIdToSkeleton[data2.id] = data3.skeletonName;
                    List<EquipmentAsset> list = new List<EquipmentAsset>();
                    foreach (string str in data3.assetList)
                    {
                        list.Add(new EquipmentAsset(str));
                    }
                    defnIdToAssets[data2.id] = list;
                }
                else
                {
                    Debug.LogError("Entity model not defined: " + data2.modelId);
                }
            }
        }
    }

    private static void UpdateEntityData(List<DataClass> objects)
    {
        entitiesReady = true;
        UpdateDefinitions();
    }

    private static void UpdateModelData(List<DataClass> objects)
    {
        modelsReady = true;
        UpdateDefinitions();
    }

    public static void UpdateWeaponTypes(Entity entity)
    {
        WeaponComponent component = entity.gameObject.GetComponent<WeaponComponent>();
        if ((entity.gear != null) && (entity.gear.equippedGear != null))
        {
            int index = (entity.combat.GetWeaponSet() == 0) ? 9 : 11;
            InventoryItem mainWeapon = entity.gear.equippedGear[index];
            InventoryItem offWeapon = entity.gear.equippedGear[index + 1];
            component.SetWeaponType(mainWeapon, offWeapon);
        }
        else
        {
            string mainhandModelName = entity.combat.combatClass.mainhandModelName;
            string offhandModelName = entity.combat.combatClass.offhandModelName;
            if (!(string.IsNullOrEmpty(mainhandModelName) && string.IsNullOrEmpty(offhandModelName)))
            {
                component.SetWeaponType(mainhandModelName, offhandModelName);
            }
        }
    }

    public delegate void AddEntityComponentsDelegate(GameObject newCharacter, GConst.CreateType flags);

    private class CharacterShaders
    {
        public Shader defaultShaderFull;
        public Shader defaultShaderHair;
        public Shader defaultShaderMerged;
        public Shader stealthedShaderFull;
        public Shader stealthedShaderHair;
        public Shader stealthedShaderMerged;
    }

    public enum ShaderType
    {
        DEFAULT,
        STEALTH
    }

    internal class SkeletonCache
    {
        public GameObject cacheSkeleton;
        public Dictionary<string, Transform> cacheSkeletonBipedMap;
        public Transform cacheTransform;

        public SkeletonCache(string name)
        {
            Func<KeyValuePair<string, UnityEngine.Object>, bool> func = null;
            string trash;
            string assetRace;
            string iterRace;
            string assetGender;
            string iterGender;
            if (name.ToLower().Contains("_weapon"))
            {
                this.cacheSkeleton = new GameObject(name);
                this.cacheTransform = this.cacheSkeleton.transform;
                this.cacheSkeletonBipedMap = null;
                assetRace = name;
            }
            else if (EntityLoadClient.GetAssetData(name, out assetRace, out assetGender, out trash))
            {
                if (func == null)
                {
                    func = each => (EntityLoadClient.GetAssetData(each.Value.name, out iterRace, out iterGender, out trash) && (iterRace == assetRace)) && ((iterGender == assetGender) || (iterGender == "u"));
                }
                GameObject original = (from each in Enumerable.Where<KeyValuePair<string, UnityEngine.Object>>(EntityLoadClient.skeletonPrefabs, func) select (GameObject) each.Value).FirstOrDefault<GameObject>();
                if (original == null)
                {
                    throw new NullReferenceException("Unable to find a skeleton prefab for asset name: " + name + " - " + GUtil.PrettyPrint(EntityLoadClient.skeletonPrefabs, ", ", "[]"));
                }
                this.cacheSkeleton = (GameObject) UnityEngine.Object.Instantiate(original);
                this.cacheTransform = this.cacheSkeleton.transform;
                this.cacheSkeletonBipedMap = EntityLoadClient.GetBipedMap(EntityLoadClient.FindRootBone(this.cacheSkeleton), null);
                Collider component = this.cacheSkeleton.GetComponent<Collider>();
                if (component != 0)
                {
                    component.enabled = false;
                }
            }
            if (this.cacheSkeleton != null)
            {
                UnityEngine.Object.DontDestroyOnLoad(this.cacheSkeleton);
                this.cacheTransform.parent = EntityLoadClient.cacheRoot.transform;
                this.cacheTransform.localPosition = Vector3.zero;
                EntityLoadClient.cacheSkeletonByRace[assetRace] = this;
            }
        }
    }
}

