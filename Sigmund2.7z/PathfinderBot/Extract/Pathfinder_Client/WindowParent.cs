﻿using GNGUI;
using System;
using UnityEngine;

public class WindowParent : MonoBehaviour
{
    public static bool LoadWindow(string prefabName, Vector3 setPos)
    {
        if (null != WindowGui.windowParent.transform.FindChild(prefabName))
        {
            return true;
        }
        if (setPos == GConst.VECTOR3_INVALID)
        {
            setPos = new Vector3(-400f, 225f, 0f);
        }
        GameObject obj2 = NGUITools.AddChild(WindowGui.windowParent, UIClient.guiPrefabs[prefabName]);
        obj2.transform.localPosition = setPos;
        obj2.name = prefabName;
        return false;
    }

    private void Start()
    {
        WindowGui.windowParent = base.gameObject;
    }
}

