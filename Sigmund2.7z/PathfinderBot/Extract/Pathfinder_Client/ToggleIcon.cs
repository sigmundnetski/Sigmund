﻿using GNGUI;
using System;
using System.Runtime.CompilerServices;
using UnityEngine;

public class ToggleIcon : MonoBehaviour
{
    private ToggleIconClicked callback;
    private UISprite icon;
    public int id;
    private string[] spriteNames = new string[2];
    public bool state;

    public void Awake()
    {
        this.icon = base.GetComponentInChildren<UISprite>();
        GuiHelper.GuiAssertNotNull(base.name + " could not find sprite.", new object[] { this.icon });
        UIEventListener listener1 = UIEventListener.Get(base.gameObject);
        listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.ToggleClicked));
    }

    public void Init(int id_, ToggleIconClicked callback_, bool initialState, string onSpriteName, string offSpriteName)
    {
        this.id = id_;
        this.callback = callback_;
        this.state = initialState;
        this.spriteNames[0] = offSpriteName;
        this.spriteNames[1] = onSpriteName;
        this.SetIcon();
    }

    private void SetIcon()
    {
        this.icon.spriteName = this.spriteNames[this.state ? 1 : 0];
    }

    public void ToggleClicked(GameObject go)
    {
        this.state = !this.state;
        this.SetIcon();
        this.callback(this);
    }

    public delegate void ToggleIconClicked(ToggleIcon toggleIcon);
}

