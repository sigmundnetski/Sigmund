﻿using System;
using System.Collections.Generic;
using UnityEngine;

public class WeaponComponent : MonoBehaviour
{
    private Dictionary<string, Transform> bipedMap;
    private int[] equippedWeaponIds = new int[2];
    private GameObject[] equippedWeapons = new GameObject[2];
    private Transform LHand;
    private Renderer[] renderers = new Renderer[2];
    private Transform RHand;
    private bool weaponVisible = false;

    public bool GetWeaponVis()
    {
        return this.weaponVisible;
    }

    public void Init(Dictionary<string, Transform> bipedMap_)
    {
        this.bipedMap = bipedMap_;
        if (!this.bipedMap.TryGetValue("weapon_bone_lt", out this.LHand))
        {
            this.bipedMap.TryGetValue("biped weapon bone_lt", out this.LHand);
        }
        if (!this.bipedMap.TryGetValue("weapon_bone_rt", out this.RHand))
        {
            this.bipedMap.TryGetValue("biped weapon bone_rt", out this.RHand);
        }
    }

    private void LoadWeaponToHand(InventoryItem weapon, CombatClassVars.LogicalHand curHand)
    {
        if (weapon.staticItemId != 0)
        {
            GameObject gameObject = base.gameObject;
            if (gameObject != null)
            {
                EntityVars component = gameObject.GetComponent<EntityVars>();
                EntityDefnData data = EntityDefnData.defnById[component.entityDefnId];
                int raceId = data.raceId;
                string name = RaceData.raceById[raceId].name;
                char gender = (char) data.gender;
                BasicItemData data2 = ItemDatabase.itemById[weapon.staticItemId];
                string model = data2.model;
                if (!string.IsNullOrEmpty(data2.model))
                {
                    model = string.Format(data2.model, new object[] { "1", name, gender, "0", "weapon" });
                    CombatWeapon weapon2 = data2 as CombatWeapon;
                    if (weapon2 != null)
                    {
                        WeaponCategoryData data3 = WeaponCategoryData.categoriesById[weapon2.weaponCategoryId];
                        Transform rHand = this.RHand;
                        if (((curHand == CombatClassVars.LogicalHand.MAIN_HAND) && (data3.mainhand == WeaponCategoryData.AssetHand.LEFT)) || (curHand == CombatClassVars.LogicalHand.OFF_HAND))
                        {
                            rHand = this.LHand;
                        }
                        GameObject asset = EntityLoadClient.GetAsset(model);
                        if (asset == null)
                        {
                            GLog.Log(new object[] { "Unable to find prefab for asset: " + model });
                        }
                        else
                        {
                            EntityLoadClient.MoveWeapon(rHand, asset, this.bipedMap, curHand);
                            this.equippedWeapons[(int) curHand] = asset;
                            this.equippedWeaponIds[(int) curHand] = weapon.staticItemId;
                            this.renderers[(int) curHand] = asset.GetComponentsInChildren<Renderer>(true)[0];
                        }
                    }
                }
            }
        }
    }

    private void LoadWeaponToHand(string modelName, char gender, CombatClassVars.LogicalHand curHand)
    {
        string assetName = string.Format(modelName, gender);
        Transform rHand = this.RHand;
        if (curHand == CombatClassVars.LogicalHand.OFF_HAND)
        {
            rHand = this.LHand;
        }
        GameObject asset = EntityLoadClient.GetAsset(assetName);
        if (asset == null)
        {
            GLog.Log(new object[] { "Unable to find prefab for asset: " + assetName });
        }
        else
        {
            EntityLoadClient.MoveWeapon(rHand, asset, this.bipedMap, curHand);
            this.equippedWeapons[(int) curHand] = asset;
            this.equippedWeaponIds[(int) curHand] = 0;
            this.renderers[(int) curHand] = asset.GetComponentsInChildren<Renderer>(true)[0];
        }
    }

    public void SetWeaponType(InventoryItem weapon, CombatClassVars.LogicalHand hand)
    {
        if (Enum.IsDefined(typeof(CombatClassVars.LogicalHand), hand))
        {
            GameObject weaponGO = this.equippedWeapons[(int) hand];
            if (weaponGO != null)
            {
                EntityLoadClient.SkeletonCache assetCache = EntityLoadClient.GetAssetCache(weaponGO.name);
                EntityLoadClient.MoveWeapon(assetCache.cacheTransform, weaponGO, assetCache.cacheSkeletonBipedMap, (CombatClassVars.LogicalHand) 0xff);
            }
            this.equippedWeapons[(int) hand] = null;
            this.equippedWeaponIds[(int) hand] = 0;
            this.renderers[(int) hand] = null;
            this.LoadWeaponToHand(weapon, hand);
        }
    }

    public void SetWeaponType(InventoryItem mainWeapon, InventoryItem offWeapon)
    {
        for (int i = 0; i < this.equippedWeapons.Length; i++)
        {
            GameObject weaponGO = this.equippedWeapons[i];
            if (weaponGO != null)
            {
                EntityLoadClient.SkeletonCache assetCache = EntityLoadClient.GetAssetCache(weaponGO.name);
                EntityLoadClient.MoveWeapon(assetCache.cacheTransform, weaponGO, assetCache.cacheSkeletonBipedMap, (CombatClassVars.LogicalHand) 0xff);
                this.equippedWeapons[i] = null;
                this.equippedWeaponIds[i] = 0;
                this.renderers[i] = null;
            }
        }
        this.LoadWeaponToHand(mainWeapon, CombatClassVars.LogicalHand.MAIN_HAND);
        this.LoadWeaponToHand(offWeapon, CombatClassVars.LogicalHand.OFF_HAND);
        this.SetWeaponVis(this.weaponVisible);
    }

    public void SetWeaponType(string mainWeaponModel, string offWeaponModel)
    {
        for (int i = 0; i < this.equippedWeapons.Length; i++)
        {
            GameObject weaponGO = this.equippedWeapons[i];
            if (weaponGO != null)
            {
                EntityLoadClient.SkeletonCache assetCache = EntityLoadClient.GetAssetCache(weaponGO.name);
                EntityLoadClient.MoveWeapon(assetCache.cacheTransform, weaponGO, assetCache.cacheSkeletonBipedMap, (CombatClassVars.LogicalHand) 0xff);
                this.equippedWeapons[i] = null;
                this.equippedWeaponIds[i] = 0;
                this.renderers[i] = null;
            }
        }
        GameObject gameObject = base.gameObject;
        if (gameObject != null)
        {
            EntityVars component = gameObject.GetComponent<EntityVars>();
            EntityDefnData data = EntityDefnData.defnById[component.entityDefnId];
            char gender = (char) data.gender;
            if (!string.IsNullOrEmpty(mainWeaponModel))
            {
                this.LoadWeaponToHand(mainWeaponModel, gender, CombatClassVars.LogicalHand.MAIN_HAND);
            }
            if (!string.IsNullOrEmpty(offWeaponModel))
            {
                this.LoadWeaponToHand(offWeaponModel, gender, CombatClassVars.LogicalHand.OFF_HAND);
            }
            this.SetWeaponVis(this.weaponVisible);
        }
    }

    public void SetWeaponVis(bool setVisible)
    {
        for (int i = 0; i < this.renderers.Length; i++)
        {
            if (this.renderers[i] != null)
            {
                this.renderers[i].enabled = setVisible;
            }
        }
        this.weaponVisible = setVisible;
    }
}

