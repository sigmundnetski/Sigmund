﻿using GNGUI;
using System;
using System.Collections.Generic;
using UnityEngine;

public class RecipeNameGui : MonoBehaviour
{
    private UIGrid grid;
    private List<RecipeNameElement> nameElements = new List<RecipeNameElement>();
    private GameObject recipeNamePrefab;
    private List<BaseRecipeData> visibleRecipes = new List<BaseRecipeData>();

    public void Repopulate(int[] skillIds, string[] searchArgs)
    {
        if (this.recipeNamePrefab == null)
        {
            this.recipeNamePrefab = UIClient.guiPrefabs["RecipeNameElement"];
        }
        if (this.grid == null)
        {
            this.grid = base.GetComponent<UIGrid>();
        }
        this.visibleRecipes.Clear();
        foreach (KeyValuePair<int, BaseRecipeData> pair in BaseRecipeData.recipeById)
        {
            if (CraftingClient.ValidRecipe(pair.Value, skillIds, searchArgs))
            {
                this.visibleRecipes.Add(pair.Value);
            }
        }
        UIGrid.SetElementCount<RecipeNameElement>(DragDropRoot.root, this.grid, this.recipeNamePrefab, this.nameElements, this.visibleRecipes.Count);
        for (int i = 0; i < this.visibleRecipes.Count; i++)
        {
            this.nameElements[i].SetData(this.visibleRecipes[i]);
        }
    }
}

