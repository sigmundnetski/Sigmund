﻿using GNetwork;
using System;
using UnityEngine;

public static class EntityDataClient
{
    public static Entity owner;
    private static DateTime problemTime = DateTime.MaxValue;
    private static readonly TimeSpan problemTolerance = TimeSpan.FromSeconds(3.0);

    private static void AddEntity(ushort mapId, Entity entity)
    {
        if (entity.combat != null)
        {
            entity.combat.OnReceiveEntity();
        }
        if ((entity.advancementVars != null) && (entity.playerRecord != null))
        {
            entity.advancementVars.playerRecord = entity.playerRecord;
        }
        if (EntityCore.Match(entity.entityId, EntityData.ownerEntityId) && ((EntityDataClient.owner == null) || (entity.ownerSequence > EntityDataClient.owner.ownerSequence)))
        {
            Entity owner = EntityDataClient.owner;
            EntityDataClient.owner = entity;
            PlayerEntityClient.InitializePlayerEntity(entity);
            if (owner != null)
            {
                EntityClient.DespawnEntity(owner);
            }
        }
        else
        {
            EntityClient.SpawnEntity(entity);
            if (entity.createType == GConst.CreateType.PLAYER)
            {
                EntityLoadClient.UpdateWeaponTypes(entity);
            }
        }
    }

    public static bool CheckLostPlayerIssue()
    {
        DateTime utcNow = DateTime.UtcNow;
        if ((problemTime < utcNow) && ((utcNow - problemTime) > problemTolerance))
        {
            Vector3 zero = Vector3.zero;
            Quaternion identity = Quaternion.identity;
            string str = "Auto-generated bug report from EntityDataClient.CheckLostPlayerIssue(), position/rotation not useful.";
            if (GraphicsClient.goblinCamera != null)
            {
                zero = GraphicsClient.goblinCamera.transform.position;
                identity = GraphicsClient.goblinCamera.transform.rotation;
                str = "Auto-generated bug report from EntityDataClient.CheckLostPlayerIssue(), using camera position/rotation as approximate";
            }
            GRouting.SendMyMapRpc(GRpcID.BugReportServer_SendReport, new object[] { TerrainService.CalculateCurrentMapId, zero, identity, str });
            NetworkClient.serverConnection.Disconnect("Log Out");
        }
        return true;
    }

    private static void DebugOwnerProblems()
    {
        if ((((owner == null) || (owner.gameObject == null)) || (PlayerEntityClient.GetPlayer() == null)) || !EntityCore.Match(owner.entityId, EntityData.ownerEntityId))
        {
            GLog.LogError(new object[] { "After syncing entities, the owner is not defined on the client:", owner, (owner != null) ? owner.gameObject : null, EntityData.ownerEntityId, PlayerEntityClient.GetPlayer(), EntityCore.GetAllEntities(true) });
            if (problemTime == DateTime.MaxValue)
            {
                problemTime = DateTime.UtcNow;
            }
        }
        else
        {
            problemTime = DateTime.MaxValue;
        }
    }

    private static void DoUpdateCallbacks(Entity entity)
    {
        AdvancementClient.OnClientEntityUpdate(entity);
        CapturePointClient.OnClientEntityUpdate(entity);
        CharacterWindowGui.OnClientEntityUpdate(entity);
        CraftingClient.OnClientEntityUpdate(entity);
        EncounterClient.OnClientEntityUpdate(entity);
        FeatsWindowGui.OnClientEntityUpdate(entity);
        InventoryClient.OnClientEntityUpdate(entity);
        PlayerEntityClient.OnClientEntityUpdate(entity);
        QuestClient.OnClientEntityUpdate(entity);
        TrainerWindowGui.OnClientEntityUpdate(entity);
    }

    public static void OnSayonara(ushort mapId)
    {
        foreach (Entity entity in EntityCore.GetAllEntities(true))
        {
            if (entity.ownerMapId == mapId)
            {
                EntityClient.DespawnEntity(entity);
            }
        }
    }

    private static void RemoveEntity(EntityId entityId)
    {
        EntityClient.DespawnEntity(EntityCore.GetEntity(ref entityId));
    }

    public static bool Shutdown()
    {
        owner = null;
        EntityCore.UnitTest_Reinitialize(0);
        return true;
    }

    public static void SyncStart()
    {
        NetworkSync<ForeignEntityId, Entity>.RegisterType(TestForeignEntityIdComparer.Instance);
        EntityData.AddEntity = new EntityData.AddUpdateEntityHandler(EntityDataClient.AddEntity);
        EntityData.UpdateEntity = new EntityData.AddUpdateEntityHandler(EntityDataClient.UpdateEntity);
        EntityData.RemoveEntity = new EntityData.RemoveEntityHandler(EntityDataClient.RemoveEntity);
        EntityData.DoneReceiving = new EntityData.DoneReceivingHandler(EntityDataClient.DebugOwnerProblems);
        EntityData.DoUpdateCallbacks = new EntityData.DoUpdateCallbacksHandler(EntityDataClient.DoUpdateCallbacks);
        problemTime = DateTime.MaxValue;
    }

    private static void UpdateEntity(ushort mapId, Entity entity)
    {
        if ((entity.advancementVars != null) && (entity.playerRecord != null))
        {
            entity.advancementVars.playerRecord = entity.playerRecord;
        }
        EntityClient.UpdateEntity(entity);
    }
}

