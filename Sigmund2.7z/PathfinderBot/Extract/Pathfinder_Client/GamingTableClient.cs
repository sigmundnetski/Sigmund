﻿using GNetwork;
using System;
using UnityEngine;

internal static class GamingTableClient
{
    private static bool atTable = false;
    private static int tableId = -1;

    public static void Continue()
    {
        GRouting.SendMyMapRpc(GRpcID.GamingTableServer_Continue, new object[] { tableId });
        GamingTableDiceGUI.singleton.ClearGrids();
        GamingTableDiceGUI.singleton.ResetRoundScore();
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void CurrentTurn()
    {
        GamingTableDiceGUI.singleton.ShowButtons();
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void GameOverResponse(string msg, int myPoints, int opponentPoints)
    {
        ChatGui.singleton.DisplayMessage(msg, ChatClient.ERROR_COLOR);
        GamingTableDiceGUI.singleton.FinishGameProcessing(myPoints, opponentPoints);
    }

    public static bool IsAtTable()
    {
        return atTable;
    }

    public static void JoinTable()
    {
        if (!atTable)
        {
            GRouting.SendMyMapRpc(GRpcID.GamingTableServer_JoinTable, new object[0]);
        }
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void JoinTableResponse(bool success, int newTableId, Vector3 tablePosition, Vector3 seatPosition)
    {
        atTable = success;
        string message = string.Empty;
        if (atTable)
        {
            tableId = newTableId;
            GameObject player = PlayerEntityClient.GetPlayer();
            player.GetComponent<EntityMotion>().LockAtPosition(seatPosition, tablePosition, BaseMotion.PositionLock.External);
            Vector3 position = tablePosition + new Vector3(0f, 2f, 0f);
            Quaternion rotation = Quaternion.LookRotation(new Vector3(0f, -1f, 0f), new Vector3(tablePosition.x - seatPosition.x, 0f, 0f));
            CustomCamera.singleton.SetCustomPosition(position, rotation);
            GamingTableDiceGUI.singleton.UpdateName(player.name);
            GamingTableDiceGUI.singleton.ShowWindow();
            GamingTableDiceGUI.singleton.ShowWelcomeMessage();
            message = "You have taken a seat at table " + (tableId + 1);
        }
        else
        {
            message = "Sorry, there aren't any available tables within range.";
        }
        ChatGui.singleton.DisplayMessage(message, ChatClient.DEBUG_COLOR);
    }

    public static void LeaveTable()
    {
        if (atTable)
        {
            GRouting.SendMyMapRpc(GRpcID.GamingTableServer_LeaveTable, new object[] { tableId });
        }
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void LeaveTableResponse(bool success)
    {
        string message = string.Empty;
        if (success)
        {
            GamingTableDiceGUI.singleton.LeftGamingTable();
            message = "You've left your seat at table " + (tableId + 1);
        }
        ChatGui.singleton.DisplayMessage(message, ChatClient.DEBUG_COLOR);
        atTable = false;
        tableId = -1;
        PlayerEntityClient.GetPlayer().GetComponent<EntityMotion>().UnlockPosition(BaseMotion.PositionLock.External);
        CustomCamera.singleton.ReleaseCustomPosition();
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void OpponentsRollResponse(int count, int total, int roll1, int roll2, int roll3)
    {
        bool flag = true;
        flag &= roll1 == 0;
        flag &= roll2 == 0;
        if (flag & (roll3 == 0))
        {
            ChatGui.singleton.DisplayMessage("Your opponent is holding with a total of " + total, ChatClient.ERROR_COLOR);
        }
        else
        {
            if (roll1 > 0)
            {
                GamingTableDiceGUI.singleton.AddDieToGrid(1, roll1);
            }
            if (roll2 > 0)
            {
                GamingTableDiceGUI.singleton.AddDieToGrid(1, roll2);
            }
            if (roll3 > 0)
            {
                GamingTableDiceGUI.singleton.AddDieToGrid(1, roll3);
            }
            GamingTableDiceGUI.singleton.UpdateRoundScore(1, count, total);
        }
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void PlayerJoinResponse(string opponentName)
    {
        GamingTableDiceGUI.singleton.AddOpponent(opponentName);
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void PlayerLeaveResponse(string opponentName)
    {
        GamingTableDiceGUI.singleton.RemoveOpponent();
    }

    public static void PlayGame()
    {
        if (atTable)
        {
            GRouting.SendMyMapRpc(GRpcID.GamingTableServer_PlayGame, new object[] { tableId });
        }
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void PlayGameResponse(bool ready)
    {
        if (!ready)
        {
            GamingTableDiceGUI.singleton.ShowWaitingMessage();
        }
        else
        {
            GamingTableDiceGUI.singleton.HideButtons();
        }
    }

    public static void Roll(int i)
    {
        if (atTable)
        {
            GRouting.SendMyMapRpc(GRpcID.GamingTableServer_Roll, new object[] { tableId, i });
        }
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void RollResponse(int count, int total, int roll1, int roll2, int roll3)
    {
        bool flag = true;
        flag &= roll1 == 0;
        flag &= roll2 == 0;
        if (flag & (roll3 == 0))
        {
            ChatGui.singleton.DisplayMessage("You're holding with a total of " + total, ChatClient.DEBUG_COLOR);
        }
        else
        {
            if (roll1 > 0)
            {
                GamingTableDiceGUI.singleton.AddDieToGrid(0, roll1);
            }
            if (roll2 > 0)
            {
                GamingTableDiceGUI.singleton.AddDieToGrid(0, roll2);
            }
            if (roll3 > 0)
            {
                GamingTableDiceGUI.singleton.AddDieToGrid(0, roll3);
            }
            GamingTableDiceGUI.singleton.UpdateRoundScore(0, count, total);
        }
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void RoundOverResponse(string msg, int myPoints, int opponentPoints)
    {
        ChatGui.singleton.DisplayMessage(msg, ChatClient.ERROR_COLOR);
        GamingTableDiceGUI.singleton.UpdateGamePoints(myPoints, opponentPoints);
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void WaitingForResponse()
    {
        GamingTableDiceGUI.singleton.ShowRoundOver();
    }
}

