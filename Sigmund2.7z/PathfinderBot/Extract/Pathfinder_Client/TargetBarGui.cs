﻿using GNGUI;
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class TargetBarGui : FloatingCharacterBarGui
{
    private Color aliveHpColor = new Color(1f, 1f, 1f);
    private Transform cachedTransform;
    private UILabel charName;
    private List<GameObject> combatElements;
    private bool combatEnabled = true;
    private Color deadHpColor = new Color(0.5f, 0.5f, 0.5f);
    private bool frameDelay = false;
    private const float MAX_DISTANCE = 50f;
    private const float MAX_DISTANCE_SCALE = 0.333333f;
    private const float MAX_NAME_SHOWING_DISTANCE = 35f;
    private const float MIN_DISTANCE = 5f;
    private const float MIN_DISTANCE_SCALE = 1f;
    private const float REPUTATION_BADGE_PAD = 0.5f;
    private UISprite reputationBadge;
    private bool reputationBadgeEnabled = true;
    private bool shouldBeShowing = false;
    [NonSerialized, HideInInspector]
    public EntityId targetEntityId;

    private void _InternalShow()
    {
        if (this.frameDelay)
        {
            this.frameDelay = false;
        }
        else
        {
            base.Show();
            this.frameDelay = true;
        }
    }

    public override void Awake()
    {
        base.Awake();
        this.cachedTransform = base.gameObject.transform;
        this.charName = base.GetComponentInChildren<UILabel>();
        Transform transform = base.transform.Find("TrilinearPanel/HealthStaminaBackground");
        foreach (UISprite sprite in base.GetComponentsInChildren<UISprite>())
        {
            if (sprite.name == "ReputationBadge")
            {
                this.reputationBadge = sprite;
            }
        }
        GuiHelper.GuiAssertNotNull("Could not find needed children.", new object[] { this.charName, transform, this.reputationBadge });
        this.combatElements = new List<GameObject>();
        this.combatElements.Add(transform.gameObject);
        this.combatElements.Add(base.staminaBar.gameObject);
        this.combatElements.AddRange(from each in base.hitPointBars select each.gameObject);
    }

    public void EnableCombatUi(bool enable)
    {
        if (enable != this.combatEnabled)
        {
            for (int i = 0; i < this.combatElements.Count<GameObject>(); i++)
            {
                NGUITools.SetActive(this.combatElements[i], enable);
            }
            this.combatEnabled = enable;
        }
    }

    public void EnableReputationBadge(bool enable)
    {
        if (enable != this.reputationBadgeEnabled)
        {
            NGUITools.SetActive(this.reputationBadge.gameObject, enable);
            this.reputationBadgeEnabled = enable;
        }
    }

    public override void Hide()
    {
        this.shouldBeShowing = false;
        base.Hide();
    }

    public override void Init(Transform followTransform)
    {
        base.Init(followTransform);
        base.followTarget.automaticUpdate = false;
    }

    public void Reset()
    {
        this.SetName("", Conning.Strength.NonCombat);
        this.SetStamina(1f, 1);
        this.SetPower(1f, 1);
        this.Hide();
    }

    public override void SetName(string name, Conning.Strength strength)
    {
        this.charName.text = name;
        this.charName.color = Conning.GetRelativeStrengthColor(strength);
        Vector2 vector = this.charName.font.CalculatePrintedSize(name, true, UIFont.SymbolStyle.Colored);
        Vector2 localPosition = this.reputationBadge.transform.localPosition;
        localPosition.x = (vector.x * this.charName.transform.localScale.x) / 2f;
        localPosition.x += 0.5f * this.reputationBadge.transform.localScale.x;
        this.reputationBadge.transform.localPosition = (Vector3) localPosition;
    }

    public override void SetPower(float powerPercentage, int power)
    {
    }

    private void SetScale()
    {
        float num = Mathf.Clamp(Targeting.selectedTargetDistance, 5f, 50f);
        bool active = NGUITools.GetActive(this.charName.gameObject);
        if ((num > 35f) && active)
        {
            NGUITools.SetActive(this.charName.gameObject, false);
        }
        else if (!((num >= 35f) || active))
        {
            NGUITools.SetActive(this.charName.gameObject, true);
        }
        float x = Mathf.Lerp(1f, 0.333333f, (num - 5f) / 45f);
        this.cachedTransform.localScale = new Vector3(x, x, x);
    }

    public override void SetStamina(float staminaPercentage, int stamina)
    {
        base.staminaBar.fillAmount = staminaPercentage;
    }

    public override void Show()
    {
        this.shouldBeShowing = true;
    }

    public void Start()
    {
        this.EnableCombatUi(false);
        this.EnableReputationBadge(false);
    }

    public void SyncUpdate(CombatVars cv)
    {
        if (base.IsShowing())
        {
            Conning.Strength relativeStrength = Conning.GetRelativeStrength(this.targetEntityId);
            this.charName.color = Conning.GetRelativeStrengthColor(relativeStrength);
            string reputationBadge = Conning.GetReputationBadge(this.targetEntityId);
            if (reputationBadge != null)
            {
                this.reputationBadge.spriteName = reputationBadge;
                this.EnableReputationBadge(true);
            }
            else
            {
                this.EnableReputationBadge(false);
            }
        }
        if ((base.followTarget != null) && (base.followTarget.target != null))
        {
            base.followTarget.SyncUpdate();
        }
        base.SyncUpdateCv(cv);
        this.SetScale();
        if (!(base.IsShowing() || !this.shouldBeShowing))
        {
            this._InternalShow();
        }
        this.EnableCombatUi(cv != null);
    }

    public void TargetSelected(Transform followTransform, EntityId targetEntityId)
    {
        this.targetEntityId = targetEntityId;
        bool flag = base.IsShowing();
        if (followTransform == base.followTarget.target)
        {
            if (!flag)
            {
                this.Show();
            }
        }
        else
        {
            if (flag)
            {
                this.Hide();
            }
            base.followTarget.target = followTransform;
            this.Show();
        }
    }
}

