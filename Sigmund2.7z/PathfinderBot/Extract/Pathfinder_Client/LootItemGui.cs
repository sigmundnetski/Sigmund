﻿using GNGUI;
using System;

public class LootItemGui : ItemGui
{
    private UILabel encumbrance;
    public float sortEncumbrance;
    public string sortName;

    public override void Awake()
    {
        base.Awake();
        foreach (UILabel label in base.GetComponentsInChildren<UILabel>())
        {
            if (label.name == "Name")
            {
                base.nameLabel = label;
            }
            else if (label.name == "Encumbrance")
            {
                this.encumbrance = label;
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find all labels.", new object[] { base.nameLabel, this.encumbrance });
    }

    protected override void SetInfo(InventoryItem item, BasicItemData itemData)
    {
        base.collider.enabled = true;
        this.sortName = item.GetDisplayName(true);
        this.sortEncumbrance = item.GetEncumbrance();
        this.encumbrance.text = this.sortEncumbrance.ToString("f1");
    }

    protected override void SetLabel(BasicItemData itemData)
    {
        if (itemData == null)
        {
            base.nameLabel.text = "<NOT FOUND>";
        }
        else
        {
            base.nameLabel.text = this.item.GetDisplayName(true);
        }
        base.nameLabel.color = InventoryClient.GetQualityColor(this.item.GetQuality());
    }
}

