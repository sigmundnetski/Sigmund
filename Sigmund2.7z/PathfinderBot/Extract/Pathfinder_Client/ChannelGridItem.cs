﻿using GNGUI;
using System;
using UnityEngine;

public class ChannelGridItem : MonoBehaviour
{
    private UILabel channelLabel;
    private string channelName;
    private UIImageButton leaveButton;

    public void Awake()
    {
        this.channelLabel = base.GetComponentInChildren<UILabel>();
        this.leaveButton = base.GetComponentInChildren<UIImageButton>();
        GuiHelper.GuiAssertNotNull("Could not find needed childern.", new object[] { this.channelLabel, this.leaveButton });
        UIEventListener listener1 = UIEventListener.Get(this.leaveButton.gameObject);
        listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.LeaveButtonClicked));
        UIEventListener listener2 = UIEventListener.Get(this.channelLabel.gameObject);
        listener2.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener2.onClick, new UIEventListener.VoidDelegate(this.ChannelClicked));
        this.channelLabel.text = this.channelName;
    }

    private void ChannelClicked(GameObject go)
    {
        ChatClient.ChangeChannel(this.channelName);
    }

    public void Init(string channelName_, bool activeChannel)
    {
        this.channelName = channelName_;
        this.channelLabel.text = activeChannel ? ("> " + this.channelName + " <") : this.channelName;
    }

    private void LeaveButtonClicked(GameObject go)
    {
        ChatGui.singleton.GetTab(ChatContextGui.singleton.currentReferenceId).RemoveDesiredChannel(this.channelName);
        CommandCore.ExecuteCommand("RemoveChannel " + this.channelName, PlayerEntityClient.GetPlayerEntityId());
    }
}

