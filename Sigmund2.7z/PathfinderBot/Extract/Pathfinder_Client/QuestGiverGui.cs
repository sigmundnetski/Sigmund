﻿using GNGUI;
using System;
using System.Collections.Generic;
using UnityEngine;

internal class QuestGiverGui : WindowGui
{
    private UIButton acceptButton = null;
    private UILabel bodyText = null;
    private UIButton declineButton = null;
    private List<QuestTab> displayedTabs = new List<QuestTab>();
    private const int FREQUENCY_REDUCTION = 120;
    private static int frequencyTick = 0;
    private GameObject questTabPrefab = null;
    private int selectedQuestId = 0;
    public static QuestGiverGui singleton;
    public UIGrid tabGrid;
    private static HashSet<int> tempQuestIds = new HashSet<int>();
    private UIScrollBar textScroll = null;
    private UILabel titleText = null;

    public void Awake()
    {
        singleton = this;
    }

    private void CheckRange()
    {
        Entity entity = EntityCore.GetEntity(ref QuestClient.questGiverEntityId);
        Entity owner = EntityDataClient.owner;
        if ((entity == null) || (owner == null))
        {
            this.HideWindow();
        }
        else
        {
            Vector3 vector = entity.GetLocalPosition() - owner.gameObject.transform.position;
            float num = (vector.x * vector.x) + (vector.z * vector.z);
            if (num > 100f)
            {
                this.HideWindow();
            }
        }
    }

    private void OnAcceptClicked(GameObject clickedGO)
    {
        if (this.selectedQuestId != 0)
        {
            QuestClient.AcceptQuest(this.selectedQuestId);
        }
    }

    private void OnDeclineClicked(GameObject clickedGO)
    {
        if (this.selectedQuestId != 0)
        {
            QuestClient.DeclineQuest(this.selectedQuestId);
        }
    }

    public override void OnDestroy()
    {
        base.OnDestroy();
        singleton = null;
    }

    internal void OnTabClicked(GameObject clickedGO)
    {
        QuestTab component = clickedGO.GetComponent<QuestTab>();
        this.ShowQuest(component.questId);
    }

    private void RebuildFromData()
    {
        this.selectedQuestId = 0;
        this.titleText.text = "";
        this.bodyText.text = "";
        UIGrid.SetElementCount<QuestTab>(DragDropRoot.root, this.tabGrid, this.questTabPrefab, this.displayedTabs, QuestClient.availableQuestIds.Count);
        tempQuestIds.Clear();
        tempQuestIds.UnionWith(QuestClient.availableQuestIds);
        foreach (QuestTab tab in this.displayedTabs)
        {
            tempQuestIds.Remove(tab.questId);
            if (!((tab.questId == 0) || QuestClient.availableQuestIds.Contains(tab.questId)))
            {
                tab.questId = 0;
            }
        }
        foreach (QuestTab tab in this.displayedTabs)
        {
            if (tab.questId == 0)
            {
                foreach (int num in tempQuestIds)
                {
                    tab.SetQuestId(num);
                    tempQuestIds.Remove(num);
                    break;
                }
            }
        }
        if (QuestClient.availableQuestIds.Count == 1)
        {
            foreach (int num in QuestClient.availableQuestIds)
            {
                this.ShowQuest(num);
            }
            this.ShowWindow();
        }
        else
        {
            UIClient.AlphaLerp(this.acceptButton.gameObject, 1f, 0f, 0.5f, null);
            UIClient.AlphaLerp(this.declineButton.gameObject, 1f, 0f, 0.5f, null);
        }
        if (QuestClient.availableQuestIds.Count > 0)
        {
            this.ShowWindow();
        }
        else
        {
            this.HideWindow();
        }
    }

    public static void Repopulate()
    {
        if (singleton != null)
        {
            singleton.RebuildFromData();
        }
    }

    private void ShowQuest(int questId)
    {
        QuestData data;
        this.textScroll.scrollValue = 0f;
        if (QuestData.questById.TryGetValue(questId, out data))
        {
            this.titleText.text = data.displayName;
            this.bodyText.text = data.longDescription;
            this.selectedQuestId = questId;
            UIClient.AlphaLerp(this.acceptButton.gameObject, 0f, 1f, 0.5f, null);
            UIClient.AlphaLerp(this.declineButton.gameObject, 0f, 1f, 0.5f, null);
        }
        else
        {
            this.titleText.text = "";
            this.bodyText.text = "";
            this.selectedQuestId = 0;
            UIClient.AlphaLerp(this.acceptButton.gameObject, 1f, 0f, 0.5f, null);
            UIClient.AlphaLerp(this.declineButton.gameObject, 1f, 0f, 0.5f, null);
        }
    }

    public void Start()
    {
        this.questTabPrefab = UIClient.guiPrefabs["QuestTab"];
        foreach (UILabel label in base.GetComponentsInChildren<UILabel>(true))
        {
            if (label.name == "QuestBodyText")
            {
                this.bodyText = label;
            }
            if (label.name == "QuestTitleText")
            {
                this.titleText = label;
            }
        }
        foreach (UIScrollBar bar in base.GetComponentsInChildren<UIScrollBar>(true))
        {
            if (bar.name == "TextScrollBar")
            {
                this.textScroll = bar;
            }
        }
        this.tabGrid = base.GetComponentInChildren<UIGrid>();
        this.acceptButton = base.transform.FindChild("AcceptButton").GetComponent<UIButton>();
        this.declineButton = base.transform.FindChild("DeclineButton").GetComponent<UIButton>();
        GuiHelper.GuiAssertNotNull("Couldn't load prefabs.", new object[] { this.tabGrid, this.questTabPrefab, this.titleText, this.bodyText, this.acceptButton, this.declineButton, this.textScroll });
        UIEventListener listener1 = UIEventListener.Get(this.acceptButton.gameObject);
        listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.OnAcceptClicked));
        UIEventListener listener2 = UIEventListener.Get(this.declineButton.gameObject);
        listener2.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener2.onClick, new UIEventListener.VoidDelegate(this.OnDeclineClicked));
        base.Init(2, true);
    }

    public static bool SyncFixedUpdate()
    {
        frequencyTick = (frequencyTick + 1) % 120;
        if (((frequencyTick == 0) && (singleton != null)) && singleton.IsShowing())
        {
            singleton.CheckRange();
        }
        return true;
    }
}

