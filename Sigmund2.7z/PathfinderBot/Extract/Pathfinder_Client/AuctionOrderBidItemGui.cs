﻿using GNGUI;
using System;
using UnityEngine;

public class AuctionOrderBidItemGui : MonoBehaviour
{
    private UIImageButton cancelButton;
    private UILabel descriptionLabel;
    private ItemOffer marketItem;
    private UILabel nameLabel;
    private ItemOffer.OfferType offerType;
    private Color prevColor = AuctionHouseGui.NORMAL_TEXT;
    private UILabel priceLabel;
    private UILabel quantityLabel;
    private bool selected;

    public void OnCancelClick(GameObject filterGO)
    {
        AuctionHouseGui.singleton.CancelItem(this.marketItem, this.offerType);
    }

    public void OnClick()
    {
        if (this.selected)
        {
            AuctionHouseGui.singleton.ItemInterest(InventoryItem.EMPTY, (this.offerType == ItemOffer.OfferType.BID) ? AuctionHouseGui.Tabs.BIDS : AuctionHouseGui.Tabs.ORDERS);
        }
        else
        {
            this.nameLabel.color = AuctionHouseGui.SELECTED_TEXT;
            AuctionHouseGui.singleton.ItemInterest(this.marketItem.item, (this.offerType == ItemOffer.OfferType.BID) ? AuctionHouseGui.Tabs.BIDS : AuctionHouseGui.Tabs.ORDERS);
        }
        this.prevColor = this.nameLabel.color;
    }

    public void OnHover(bool isHovered)
    {
        if (isHovered)
        {
            this.nameLabel.color = AuctionHouseGui.HOVERED_TEXT;
        }
        else
        {
            this.nameLabel.color = this.prevColor;
        }
    }

    public virtual void SetData(ItemOffer marketItem_, ItemOffer.OfferType offerType_)
    {
        if (this.nameLabel == null)
        {
            this.nameLabel = base.transform.FindChild("ItemLabel").GetComponent<UILabel>();
        }
        if (this.descriptionLabel == null)
        {
            this.descriptionLabel = base.transform.FindChild("DescriptionLabel").GetComponent<UILabel>();
        }
        if (this.quantityLabel == null)
        {
            this.quantityLabel = base.transform.FindChild("QuantityLabel").GetComponent<UILabel>();
        }
        if (this.priceLabel == null)
        {
            this.priceLabel = base.transform.FindChild("PriceLabel").GetComponent<UILabel>();
        }
        if (this.cancelButton == null)
        {
            this.cancelButton = base.transform.FindChild("ButtonCancel").GetComponent<UIImageButton>();
            UIEventListener listener1 = UIEventListener.Get(this.cancelButton.gameObject);
            listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.OnCancelClick));
        }
        GuiHelper.GuiAssertNotNull("Couldn't find needed children.", new object[] { this.nameLabel, this.descriptionLabel, this.priceLabel, this.quantityLabel, this.cancelButton });
        this.marketItem = marketItem_;
        this.offerType = offerType_;
        if (ItemDatabase.GetItem(this.marketItem.item.staticItemId) == null)
        {
            base.name = "ZZZ";
            this.nameLabel.text = string.Empty;
        }
        else
        {
            base.name = this.marketItem.curPrice.ToString().PadLeft(20, '0');
            this.nameLabel.text = this.marketItem.item.GetDisplayName(true);
            this.descriptionLabel.text = this.marketItem.item.GetDescription();
            this.quantityLabel.text = this.marketItem.item.quantity.ToString();
            this.priceLabel.text = AuctionHouseGui.PriceToString(this.marketItem.curPrice);
            this.UpdateSelected(AuctionHouseGui.singleton.currentItem.staticItemId, AuctionHouseGui.singleton.currentItem.upgrade);
        }
    }

    public void UpdateSelected(int selectedId, byte upgrade)
    {
        this.selected = (this.marketItem.item.staticItemId == selectedId) && (this.marketItem.item.upgrade == upgrade);
        this.nameLabel.color = this.selected ? AuctionHouseGui.SELECTED_TEXT : AuctionHouseGui.NORMAL_TEXT;
        this.prevColor = this.selected ? AuctionHouseGui.SELECTED_TEXT : AuctionHouseGui.NORMAL_TEXT;
    }
}

