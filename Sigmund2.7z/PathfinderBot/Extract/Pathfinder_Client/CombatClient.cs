﻿using GNetwork;
using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

public static class CombatClient
{
    private static int countTickDelta = 0;
    public static Combat.FeatInfo currentFeat;
    private static float currentFeatEndTime = 0f;
    private static float currentFeatStartTime;
    private static uint currentTickDelta = 0;
    private static Color DAMAGE_COLOR = new Color(0.8078431f, 0.09019608f, 0.09019608f);
    private static Combat.FeatInfo delayedFeat;
    public static EntityMotion entityMotion = null;
    private static Color HEAL_COLOR = new Color(0.09019608f, 0.8078431f, 0.3254902f);
    private static Color NEG_ALERT_COLOR = new Color(0.4039216f, 0.5411765f, 0.9803922f);
    private static Color POS_ALERT_COLOR = new Color(0.9176471f, 0.7294118f, 0.1098039f);
    private static float previousForward = 0f;
    private static CombatVars.MovementType previousMovementType = CombatVars.MovementType.IDLE;
    private static float previousStrafe = 0f;
    public static Combat.FeatInfo queuedFeat;
    private static readonly string[] STEALTH_OFF = new string[] { "stealthmode", "off" };
    private static bool weaponDrawn = false;

    private static void AppendAttackFeatTooltip(StringBuilder quickText, OffensiveFeatData attack, byte featLevel, CombatWeapon weapon)
    {
        quickText.Append("[FF0000]").Append(attack.displayName).Append(" (").Append(featLevel).Append(")[-]\n");
        AppendWeaponCategory(quickText, attack);
        if (weapon != null)
        {
            quickText.Append(weapon.GetDisplayName(0, 1, 0, true)).Append("\n\n");
        }
        if (attack.stamina > 0)
        {
            quickText.Append("[678AFA]Stamina Cost: ").Append(attack.stamina).Append("[-]\n");
        }
        if (attack.power > 0)
        {
            quickText.Append("[FDF188]Power Cost: ").Append(attack.power).Append("[-]\n");
        }
        AppendKeywords(quickText, attack);
        quickText.Append("Cooldown: ").Append(attack.durationCooldown).Append("\n");
        quickText.Append("Damage Factor: ").Append(attack.damageFactor).Append("\n");
        quickText.Append("Range: ").Append((attack.range <= CombatData.singleton.closeRange) ? "Melee" : attack.range.ToString()).Append("\n");
        if (attack.effects != string.Empty)
        {
            quickText.Append("Effects:\n   ").Append(attack.effects).Append("\n");
        }
        if (attack.restrictions != string.Empty)
        {
            quickText.Append("Restrictions:\n   ").Append(attack.restrictions).Append("\n");
        }
        if (attack.other != string.Empty)
        {
            quickText.Append("Other:\n   ").Append(attack.other).Append("\n");
        }
    }

    private static void AppendExpendableFeatTooltip(StringBuilder quickText, OffensiveFeatData expendable, byte featLevel, CombatWeapon implement)
    {
        quickText.Append("[FF0000]").Append(expendable.displayName).Append("[-]\n");
        AppendWeaponCategory(quickText, expendable);
        if (implement != null)
        {
            quickText.Append(implement.GetDisplayName(0, 1, 0, true)).Append("\n\n");
        }
        if (expendable.stamina > 0)
        {
            quickText.Append("[678AFA]Stamina Cost: ").Append(expendable.stamina).Append("[-]\n");
        }
        if (expendable.power > 0)
        {
            quickText.Append("[FDF188]Power Cost: ").Append(expendable.power).Append("[-]\n");
        }
        AppendKeywords(quickText, expendable);
        quickText.Append("Cooldown: ").Append(expendable.durationCooldown).Append("\n");
        quickText.Append("Damage Factor: ").Append(expendable.damageFactor).Append("\n");
        quickText.Append("Range: ").Append((expendable.range <= CombatData.singleton.closeRange) ? "Melee" : expendable.range.ToString()).Append("\n");
        if (expendable.effects != string.Empty)
        {
            quickText.Append("Effects:\n   ").Append(expendable.effects).Append("\n");
        }
        if (expendable.restrictions != string.Empty)
        {
            quickText.Append("Restrictions:\n   ").Append(expendable.restrictions).Append("\n");
        }
        if (expendable.other != string.Empty)
        {
            quickText.Append("Other:\n   ").Append(expendable.other);
        }
    }

    public static void AppendFeatTooltip(StringBuilder quickText, int featId, byte featLevel, bool showEquipment)
    {
        NonAttackFeatData data = null;
        OffensiveFeatData data2 = null;
        if (NonAttackFeatData.featsById.TryGetValue(featId, out data))
        {
            if (data.type == Combat.FeatType.Refresh)
            {
                AppendRefreshFeatTooltip(quickText, data);
            }
            else
            {
                quickText.Append(data.description);
            }
        }
        else if (OffensiveFeatData.featsById.TryGetValue(featId, out data2))
        {
            CombatWeapon implement = null;
            switch (data2.type)
            {
                case Combat.FeatType.Attack:
                    if (showEquipment)
                    {
                        implement = playerCombatVars.GetWeapon(data2);
                    }
                    AppendAttackFeatTooltip(quickText, data2, featLevel, implement);
                    return;

                case Combat.FeatType.Expendable:
                    if (showEquipment)
                    {
                        implement = playerCombatVars.GetImplement();
                    }
                    AppendExpendableFeatTooltip(quickText, data2, featLevel, implement);
                    return;

                case Combat.FeatType.Utility:
                    if (showEquipment)
                    {
                        implement = playerCombatVars.GetWeapon(data2);
                    }
                    AppendUtilityFeatTooltip(quickText, data2, featLevel, implement);
                    return;
            }
            quickText.Append(data2.description);
        }
        else
        {
            quickText.Append("Unknown feat: " + featId);
        }
    }

    private static void AppendKeywords(StringBuilder quickText, OffensiveFeatData feat)
    {
        quickText.Append("All Keywords: ");
        int[] numArray = feat.keywordIds[feat.keywordIds.Length - 1];
        for (int i = 0; i < numArray.Length; i++)
        {
            KeywordData data = KeywordData.Get(feat.keywordType, numArray[i]);
            if (data != null)
            {
                if (i == (numArray.Length - 1))
                {
                    quickText.Append(data.displayName);
                }
                else
                {
                    quickText.Append(data.displayName).Append(", ");
                }
            }
        }
        quickText.Append("\n");
    }

    private static void AppendRefreshFeatTooltip(StringBuilder quickText, NonAttackFeatData refresh)
    {
        quickText.Append("[FF0000]").Append(refresh.displayName).Append("[-]\n");
        quickText.Append("Level: ").Append(refresh.level).Append("\n\n");
        if (refresh.stamina > 0)
        {
            quickText.Append("[678AFA]Stamina Cost: ").Append(refresh.stamina).Append("[-]\n");
        }
        quickText.Append("Cooldown: ").Append(refresh.durationCooldown).Append("\n");
        quickText.Append("Refresh: ").Append(refresh.refreshDescription).Append("\n");
        if (!(refresh.range == 0f))
        {
            quickText.Append("Range: ").Append(refresh.range).Append("\n");
        }
        quickText.Append(refresh.description).Append("\n");
    }

    private static void AppendUtilityFeatTooltip(StringBuilder quickText, OffensiveFeatData utility, byte featLevel, CombatWeapon gear)
    {
        quickText.Append("[FF0000]").Append(utility.displayName).Append(" (").Append(featLevel).Append(")[-]\n");
        AppendWeaponCategory(quickText, utility);
        if (gear != null)
        {
            quickText.Append(gear.GetDisplayName(0, 1, 0, true)).Append("\n");
        }
        quickText.Append("\n");
        if (utility.stamina > 0)
        {
            quickText.Append("[678AFA]Stamina Cost: ").Append(utility.stamina).Append("[-]\n");
        }
        if (utility.power > 0)
        {
            quickText.Append("[FDF188]Power Cost: ").Append(utility.power).Append("[-]\n");
        }
        AppendKeywords(quickText, utility);
        quickText.Append("Cooldown: ").Append(utility.durationCooldown).Append("\n");
        quickText.Append("Damage Factor: ").Append(utility.damageFactor).Append("\n");
        quickText.Append("Range: ").Append((utility.range <= CombatData.singleton.closeRange) ? "Melee" : utility.range.ToString()).Append("\n");
        if (utility.effects != string.Empty)
        {
            quickText.Append("Effects:\n   ").Append(utility.effects).Append("\n");
        }
        if (utility.restrictions != string.Empty)
        {
            quickText.Append("Restrictions:\n   ").Append(utility.restrictions).Append("\n");
        }
        if (utility.other != string.Empty)
        {
            quickText.Append("Other:\n   ").Append(utility.other).Append("\n");
        }
    }

    private static void AppendWeaponCategory(StringBuilder quickText, OffensiveFeatData feat)
    {
        WeaponCategoryData data;
        if (WeaponCategoryData.categoriesById.TryGetValue(feat.weaponCategoryId, out data))
        {
            quickText.Append("Weapon Category: ").Append(data.displayName).Append("\n");
        }
    }

    public static void AttackInitiated(int attackId)
    {
        EntityId selectedEntityId = Targeting.selectedEntityId;
        if (ValidateAttack(attackId, ref selectedEntityId))
        {
            GRouting.SendMyMapRpc(GRpcID.CombatServer_QueueFeat, new object[] { (byte) queuedFeat.featType, queuedFeat.featId, queuedFeat.targetEntityId, (byte) delayedFeat.featType, delayedFeat.featId, delayedFeat.targetEntityId });
        }
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void BroadcastServerTick(uint currentTick)
    {
        CurrentTick = currentTick;
    }

    public static void CommandEvent(string[] command, EntityId playerEntityId)
    {
        if (entityMotion != null)
        {
            string str = command[0];
            if (str != null)
            {
                if (!(str == "walk"))
                {
                    if (str == "run")
                    {
                        SpeedToggle(CombatVars.MovementType.RUN);
                    }
                    else if (str == "stealthmode")
                    {
                        StealthMode(command, playerEntityId);
                    }
                }
                else
                {
                    SpeedToggle(CombatVars.MovementType.WALK);
                }
            }
        }
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void DamageBroadcast(EntityId targetEntityId, int damageDealt)
    {
        GameObject gameObjectByEntityId = EntityCore.GetGameObjectByEntityId(ref targetEntityId);
        if (!object.ReferenceEquals(gameObjectByEntityId, null))
        {
            UIClient.AddOverheadNumber(gameObjectByEntityId, DAMAGE_COLOR, -damageDealt, 3f);
        }
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void DamageInflictedNotification(EntityId targetEntityId, int damageDealt, bool wasCritHit)
    {
        GameObject gameObjectByEntityId = EntityCore.GetGameObjectByEntityId(ref targetEntityId);
        if (wasCritHit)
        {
            UIClient.AddOverheadText(gameObjectByEntityId, DAMAGE_COLOR, "CRITICAL HIT!", 5f);
        }
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void DamageReceivedNotification(EntityId attackerEntityId, int damageDealt, bool wasCritHit)
    {
        GameObject player = PlayerEntityClient.GetPlayer();
        if (wasCritHit)
        {
            UIClient.AddOverheadText(player, DAMAGE_COLOR, "CRITICAL HIT!", 5f);
        }
        if (Targeting.selectedEntityId == EntityId.INVALID_ID)
        {
            Targeting.SelectTarget(EntityCore.GetGameObjectByEntityId(ref attackerEntityId));
        }
    }

    public static float DistanceCheck(EntityId lhsId, EntityId rhsId)
    {
        GameObject gameObjectByEntityId = EntityCore.GetGameObjectByEntityId(ref lhsId);
        GameObject obj3 = EntityCore.GetGameObjectByEntityId(ref rhsId);
        if ((gameObjectByEntityId == null) || (obj3 == null))
        {
            return -1f;
        }
        Transform transform = gameObjectByEntityId.transform;
        Transform transform2 = obj3.transform;
        Vector3 vector = transform.position - transform2.position;
        return vector.magnitude;
    }

    private static void DoAttackFeat(CombatVars playerCV)
    {
        OffensiveFeatData attackById = OffensiveFeatData.GetAttackById(queuedFeat.featId);
        Entity entity = EntityCore.GetEntity(ref queuedFeat.targetEntityId);
        if (((((playerCV != null) && (entity != null)) && (entity.combat != null)) && (playerCV.stamina >= attackById.stamina)) && CombatCore.WithinRange(playerCV, entity.combat, queuedFeat.featId, Combat.FeatType.Offensive, false))
        {
            currentFeat = queuedFeat;
            queuedFeat = delayedFeat;
            delayedFeat = Combat.FEAT_INFO_INVALID;
            float time = (attackById.durationValidation + attackById.durationInterruption) + attackById.durationFollowThrough;
            currentFeatStartTime = Time.time;
            currentFeatEndTime = Time.time + time;
            bool useOffhand = ShouldUseOffhand(attackById, playerCombatVars);
            GameObject player = PlayerEntityClient.GetPlayer();
            FxService.DoFx(attackById, currentFeatStartTime, player.transform, (entity == null) ? null : entity.gameObject.transform);
            if (currentFeat.featId != OffensiveFeatData.AttackIdFromName("Charge"))
            {
                entityMotion.DoAttackAnim(AnimationData.GetById(attackById.animationId), time, useOffhand, attackById.rooted);
            }
        }
    }

    private static void DoNonAttackFeat(CombatVars playerCV)
    {
        NonAttackFeatData featById = NonAttackFeatData.GetFeatById(queuedFeat.featId);
        Entity entity = EntityCore.GetEntity(ref queuedFeat.targetEntityId);
        if ((playerCV != null) && (playerCV.stamina >= featById.stamina))
        {
            currentFeat = queuedFeat;
            queuedFeat = delayedFeat;
            delayedFeat = Combat.FEAT_INFO_INVALID;
            currentFeatStartTime = Time.time;
            currentFeatEndTime = Time.time + featById.durationSec;
            if (currentFeat.featId == FeatDatabase.DRAW.id)
            {
                weaponDrawn = true;
            }
            else if (currentFeat.featId == FeatDatabase.STOW.id)
            {
                weaponDrawn = false;
            }
            if ((currentFeat.featType == Combat.FeatType.NonAttack) && (currentFeat.featId == FeatDatabase.SWAP.id))
            {
                entityMotion.ChangeWeapons(playerCV);
            }
            GameObject player = PlayerEntityClient.GetPlayer();
            FxService.DoFx(featById, currentFeatStartTime, player.transform, (entity == null) ? null : entity.gameObject.transform);
            if (featById.animationId != 0)
            {
                entityMotion.DoAttackAnim(AnimationData.GetById(featById.animationId), featById.durationSec, false, false);
            }
        }
    }

    public static void DrawWeapon()
    {
        queuedFeat = new Combat.FeatInfo(Combat.FeatType.NonAttack, FeatDatabase.DRAW.id, EntityId.INVALID_ID);
        GRouting.SendMyMapRpc(GRpcID.CombatServer_QueueFeat, new object[] { (byte) queuedFeat.featType, queuedFeat.featId, queuedFeat.targetEntityId, (byte) Combat.FEAT_INFO_INVALID.featType, Combat.FEAT_INFO_INVALID.featId, Combat.FEAT_INFO_INVALID.targetEntityId });
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void FeatActivatedBroadcast(EntityId attackerEntityId, EntityId targetEntityId, byte featTypeByte, int featId, float serverTime)
    {
        Combat.FeatType type = (Combat.FeatType) featTypeByte;
        Entity entity = EntityCore.GetEntity(ref attackerEntityId);
        if ((entity != null) && (entity.gameObject != null))
        {
            GameObject gameObject = entity.gameObject;
            GameObject player = PlayerEntityClient.GetPlayer();
            Entity entity2 = EntityCore.GetEntity(ref targetEntityId);
            if (gameObject != player)
            {
                PassiveAnimator component = gameObject.GetComponent<PassiveAnimator>();
                if (component != null)
                {
                    if (type == Combat.FeatType.Offensive)
                    {
                        OffensiveFeatData attackById = OffensiveFeatData.GetAttackById(featId);
                        float time = (attackById.durationValidation + attackById.durationInterruption) + attackById.durationFollowThrough;
                        bool useOffhand = ShouldUseOffhand(attackById, entity.combat);
                        FxService.DoFx(attackById, Time.time, gameObject.transform, (entity2 == null) ? null : entity2.gameObject.transform);
                        component.DoAttackAnim(AnimationData.GetById(attackById.animationId), time, serverTime, useOffhand, attackById.rooted);
                    }
                    else
                    {
                        NonAttackFeatData featById = NonAttackFeatData.GetFeatById(featId);
                        FxService.DoFx(featById, Time.time, gameObject.transform, (entity2 == null) ? null : entity2.gameObject.transform);
                        if (featById.animationId != 0)
                        {
                            component.DoAttackAnim(AnimationData.GetById(featById.animationId), featById.durationSec, serverTime, false, false);
                        }
                        Entity entity3 = EntityCore.GetEntity(ref attackerEntityId);
                        if (featById.id == FeatDatabase.DRAW.id)
                        {
                            EntityLoadClient.UpdateWeaponTypes(entity3);
                            component.ChangeWeapons(entity3.combat);
                        }
                        else if (featById.id == FeatDatabase.SWAP.id)
                        {
                            component.ChangeWeapons(entity3.combat);
                        }
                    }
                }
            }
        }
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void FeatFailedBroadcast(EntityId attackerEntityId, byte reasonByte, byte featType, int featId, EntityId targetEntityId)
    {
        CombatVars.FeatFailure failure = (CombatVars.FeatFailure) reasonByte;
        Combat.FeatType type = (Combat.FeatType) featType;
        if (attackerEntityId == EntityDataClient.owner.entityId)
        {
            entityMotion.AttackInterrupted();
            switch (failure)
            {
                case CombatVars.FeatFailure.OutOfRange:
                    UIClient.AddOverheadText(entityMotion.gameObject, NEG_ALERT_COLOR, "Target out of range!", 5f);
                    break;

                case CombatVars.FeatFailure.Interrupted:
                    UIClient.AddOverheadText(entityMotion.gameObject, NEG_ALERT_COLOR, "Attack interrupted!", 5f);
                    break;
            }
            GameObject gameObjectByEntityId = EntityCore.GetGameObjectByEntityId(ref targetEntityId);
            if ((failure == CombatVars.FeatFailure.Invulnerable) && (gameObjectByEntityId != null))
            {
                UIClient.AddOverheadText(gameObjectByEntityId, NEG_ALERT_COLOR, "Target invulnerable!", 5f);
            }
        }
        else
        {
            GameObject obj3 = EntityCore.GetGameObjectByEntityId(ref attackerEntityId);
            if (obj3 != null)
            {
                PassiveAnimator component = obj3.GetComponent<PassiveAnimator>();
                if (component != null)
                {
                    component.AttackInterrupted();
                }
            }
        }
    }

    public static void FeatQueued(int featId)
    {
        if (featId == 0)
        {
            Debug.Log("Invalid attack!");
        }
        else if ((((((currentFeat.featId != FeatDatabase.DRAW.id) && (queuedFeat.featId != FeatDatabase.DRAW.id)) && ((currentFeat.featId != FeatDatabase.STOW.id) && (queuedFeat.featId != FeatDatabase.STOW.id))) && (((currentFeat.featId != FeatDatabase.SWAP.id) && (queuedFeat.featId != FeatDatabase.SWAP.id)) && (queuedFeat.featId != featId))) && (delayedFeat.featId == 0)) && playerCombatVars.cooldowns.IsFeatUsable(featId))
        {
            GameObject selectedTarget = Targeting.selectedTarget;
            EntityId entityId = EntityId.INVALID_ID;
            CombatVars sneaker = null;
            if (selectedTarget != null)
            {
                entityId = Targeting.selectedEntityId;
                sneaker = CombatCore.GetCombatVarsFromId(ref entityId);
            }
            if (SelfTargetOverride(FeatDatabase.GetFeatById(featId).effectType, entityId))
            {
                entityId = playerCombatVars.entityId;
            }
            else if (CombatCore.OutsideStealthRange(sneaker, playerCombatVars))
            {
                UIClient.AddOverheadText(entityMotion.gameObject, NEG_ALERT_COLOR, "Target out of stealth range!", 5f);
                return;
            }
            queuedFeat = new Combat.FeatInfo(Combat.FeatType.NonAttack, featId, entityId);
            if (!(!playerCombatVars.stealthMode || CombatCore.FeatUsableInStealth(Combat.FeatType.NonAttack, featId)))
            {
                StealthMode(STEALTH_OFF, EntityDataClient.owner.entityId);
            }
            GRouting.SendMyMapRpc(GRpcID.CombatServer_QueueFeat, new object[] { (byte) queuedFeat.featType, featId, entityId, (byte) Combat.FEAT_INFO_INVALID.featType, Combat.FEAT_INFO_INVALID.featId, Combat.FEAT_INFO_INVALID.targetEntityId });
        }
    }

    public static Vector3 GetEntityPosition(EntityId entityId)
    {
        GameObject gameObjectByEntityId = EntityCore.GetGameObjectByEntityId(ref entityId);
        if (gameObjectByEntityId == null)
        {
            return new Vector3(float.NaN, float.NaN, float.NaN);
        }
        return gameObjectByEntityId.transform.position;
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void HealBroadcast(EntityId targetEntityId, int healAmount)
    {
        UIClient.AddOverheadNumber(EntityCore.GetGameObjectByEntityId(ref targetEntityId), HEAL_COLOR, healAmount, 3f);
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void HealNotification(EntityId sourceEntityId, EntityId targetEntityId, int healAmount)
    {
    }

    public static void ItemQueued(BasicItemData.ItemSlot slot, int staticItemId)
    {
        WondrousItemData data = null;
        if (((staticItemId != 0) && BasicItemData.SlotAccepts(slot, BasicItemData.ItemSlot.WONDROUS)) && ((data = ItemDatabase.GetItem(staticItemId) as WondrousItemData) != null))
        {
            EntityId selectedEntityId = Targeting.selectedEntityId;
            if (ValidateAttack(data.featId, ref selectedEntityId))
            {
                GRouting.SendMyMapRpc(GRpcID.CombatServer_QueueItem, new object[] { (byte) slot, staticItemId, selectedEntityId, queuedFeat.featId == FeatDatabase.DRAW.id });
            }
        }
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void MovementRestrictedBroadcast(EntityId entityId, int buffType, int restrictionType, float amount, float serverTime)
    {
        GameObject gameObjectByEntityId = EntityCore.GetGameObjectByEntityId(ref entityId);
        if ((gameObjectByEntityId != null) && (CombatCore.GetCombatVarsFromId(ref entityId) != null))
        {
            CombatConstants.Buff buff = (CombatConstants.Buff) ((byte) buffType);
            CombatVars.RestrictionType type = (CombatVars.RestrictionType) ((byte) restrictionType);
            bool isRooted = ((byte) (type & CombatVars.RestrictionType.NoMovement)) == 1;
            GameObject player = PlayerEntityClient.GetPlayer();
            if (gameObjectByEntityId == player)
            {
                if (type != CombatVars.RestrictionType.NoMovement)
                {
                    if ((buff == CombatConstants.Buff.KNOCKDOWN) || (buff == CombatConstants.Buff.STUN))
                    {
                        entityMotion.DoCrowdControlAnim(1, Time.time, amount, isRooted);
                    }
                    else
                    {
                        Debug.LogError("Unknow crowd control motion restriction on player: " + buff);
                    }
                }
            }
            else
            {
                PassiveAnimator component = gameObjectByEntityId.GetComponent<PassiveAnimator>();
                if ((component != null) && (type != CombatVars.RestrictionType.NoMovement))
                {
                    if ((buff == CombatConstants.Buff.KNOCKDOWN) || (buff == CombatConstants.Buff.STUN))
                    {
                        component.DoCrowdControlAnim(1, serverTime, amount, isRooted);
                    }
                    else
                    {
                        Debug.LogError("Unknow crowd control on proxy: " + buff);
                    }
                }
            }
        }
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void NpcDeathNotification(EntityId deadEntityId)
    {
        GameObject gameObjectByEntityId = EntityCore.GetGameObjectByEntityId(ref deadEntityId);
        if (gameObjectByEntityId != null)
        {
            gameObjectByEntityId.GetComponent<PassiveAnimator>().DoUnconsciousAnim(true);
            foreach (Collider collider in gameObjectByEntityId.GetComponentsInChildren<Collider>(true))
            {
                collider.isTrigger = true;
            }
            if (Targeting.selectedTarget == gameObjectByEntityId)
            {
                Targeting.Untarget();
            }
        }
    }

    public static void OnDisconnectedFromServer()
    {
        currentFeat = Combat.FEAT_INFO_INVALID;
        queuedFeat = Combat.FEAT_INFO_INVALID;
        delayedFeat = Combat.FEAT_INFO_INVALID;
        currentFeatStartTime = 0f;
        currentFeatEndTime = 0f;
        previousForward = 0f;
        previousStrafe = 0f;
        previousMovementType = CombatVars.MovementType.IDLE;
        CombatCore.Shutdown();
    }

    private static bool OwnerCheck(EntityId entityId)
    {
        return EntityCore.Match(entityId, EntityDataClient.owner.entityId);
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void QueueAnim(EntityId entityId, byte type, float amount, Vector3 originPosition, float serverTime)
    {
        GameObject gameObjectByEntityId = EntityCore.GetGameObjectByEntityId(ref entityId);
        if (gameObjectByEntityId != null)
        {
            GameObject player = PlayerEntityClient.GetPlayer();
            if (gameObjectByEntityId == player)
            {
                entityMotion.QueueAnim((Combat.AnimType) type, amount, originPosition);
            }
            else
            {
                PassiveAnimator component = gameObjectByEntityId.GetComponent<PassiveAnimator>();
                if (component != null)
                {
                    component.QueueAnim(serverTime, (Combat.AnimType) type, amount, originPosition);
                }
            }
        }
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void ReconsciousNotification(EntityId entityId)
    {
        Entity entity = EntityCore.GetEntity(ref entityId);
        GameObject gameObject = entity.gameObject;
        if ((entity != null) && (gameObject != null))
        {
            GameObject player = PlayerEntityClient.GetPlayer();
            if (gameObject == player)
            {
                player.GetComponent<EntityMotion>().DoUnconsciousAnim(false);
            }
            else
            {
                gameObject.GetComponent<PassiveAnimator>().DoUnconsciousAnim(false);
                foreach (Collider collider in gameObject.GetComponentsInChildren<Collider>(true))
                {
                    collider.isTrigger = false;
                }
            }
        }
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void RespawnNotification(EntityId deadEntityId, EntityId killerEntityId)
    {
        Entity entity = EntityCore.GetEntity(ref deadEntityId);
        if (entity != null)
        {
            GameObject gameObject = entity.gameObject;
            GameObject player = PlayerEntityClient.GetPlayer();
            if ((gameObject != null) && (player != null))
            {
                if (gameObject == player)
                {
                    ChatGui.singleton.DisplayMessage("You have died... Pharasma has returned you to her shrine.", ChatClient.ERROR_COLOR);
                    player.GetComponent<EntityMotion>().DoUnconsciousAnim(false);
                }
                else
                {
                    gameObject.GetComponent<PassiveAnimator>().DoUnconsciousAnim(false);
                    foreach (Collider collider in gameObject.GetComponentsInChildren<Collider>(true))
                    {
                        collider.isTrigger = false;
                    }
                }
            }
        }
    }

    public static bool SelfTargetOverride(Combat.EffectType effectType, EntityId targetEntityId)
    {
        if (effectType != Combat.EffectType.Beneficial)
        {
            return false;
        }
        Entity entity = EntityCore.GetEntity(ref targetEntityId);
        return (((entity == null) || (entity.combat == null)) || (!Conning.IsPlayer(targetEntityId) || Conning.IsHostilePlayer(targetEntityId)));
    }

    private static bool ShouldUseOffhand(OffensiveFeatData attack, CombatVars cv)
    {
        bool flag = false;
        if (attack.form == FeatData.FeatForm.Secondary)
        {
            CombatWeapon weapon = cv.GetWeapon(CombatClassVars.LogicalHand.OFF_HAND);
            if ((weapon != null) && (attack.weaponCategoryId == weapon.weaponCategoryId))
            {
                flag = true;
            }
        }
        return flag;
    }

    public static void SpeedToggle(CombatVars.MovementType type)
    {
        if ((entityMotion.forward >= -0.1f) && ((entityMotion.forward != 0f) || !(entityMotion.strafe == 0f)))
        {
            switch (type)
            {
                case CombatVars.MovementType.WALK:
                    entityMotion.speedToggle = (entityMotion.speedToggle == CombatVars.MovementType.WALK) ? CombatVars.MovementType.HUSTLE : CombatVars.MovementType.WALK;
                    break;

                case CombatVars.MovementType.RUN:
                    entityMotion.speedToggle = (entityMotion.speedToggle == CombatVars.MovementType.RUN) ? CombatVars.MovementType.HUSTLE : CombatVars.MovementType.RUN;
                    break;
            }
        }
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void StealthBroadcast(EntityId entityId, bool stealthMode, float serverTime)
    {
        GameObject gameObjectByEntityId = EntityCore.GetGameObjectByEntityId(ref entityId);
        if (gameObjectByEntityId != null)
        {
            GameObject player = PlayerEntityClient.GetPlayer();
            if (gameObjectByEntityId == player)
            {
                entityMotion.DoStealthAnim(stealthMode);
            }
            else
            {
                PassiveAnimator component = gameObjectByEntityId.GetComponent<PassiveAnimator>();
                if (component != null)
                {
                    component.DoStealthAnim(stealthMode, serverTime);
                }
            }
        }
    }

    public static void StealthMode(string[] args, EntityId playerEntityId)
    {
        bool enable = !playerCombatVars.stealthMode;
        if (args.Length >= 2)
        {
            if ((args[1] == "on") || (args[1] == "enabled"))
            {
                enable = true;
            }
            else if ((args[1] == "off") || (args[1] == "disabled"))
            {
                enable = false;
            }
        }
        if (!enable || ((entityMotion.speedToggle != CombatVars.MovementType.RUN) && !CombatBuff.HasBuff(playerCombatVars, CombatConstants.Buff.REVEALED)))
        {
            entityMotion.DoStealthAnim(enable);
            CommandClient.SendCommandToServer(args[0] + (enable ? " on" : " off"), playerEntityId);
        }
    }

    public static void StowWeapon()
    {
        queuedFeat = new Combat.FeatInfo(Combat.FeatType.NonAttack, FeatDatabase.STOW.id, EntityId.INVALID_ID);
        GRouting.SendMyMapRpc(GRpcID.CombatServer_QueueFeat, new object[] { (byte) queuedFeat.featType, queuedFeat.featId, queuedFeat.targetEntityId, (byte) Combat.FEAT_INFO_INVALID.featType, Combat.FEAT_INFO_INVALID.featId, Combat.FEAT_INFO_INVALID.targetEntityId });
    }

    public static void SwapWeapons()
    {
        if (((playerCombatVars != null) && (entityMotion != null)) && (((((currentFeat.featId != FeatDatabase.DRAW.id) && (queuedFeat.featId != FeatDatabase.DRAW.id)) && ((currentFeat.featId != FeatDatabase.STOW.id) && (queuedFeat.featId != FeatDatabase.STOW.id))) && (currentFeat.featId != FeatDatabase.SWAP.id)) && (queuedFeat.featId != FeatDatabase.SWAP.id)))
        {
            bool inCombat = playerCombatVars.inCombat;
            if (entityMotion.debugInCombat)
            {
                inCombat = true;
            }
            playerCombatVars.SwapWeapons(true);
            if (inCombat)
            {
                queuedFeat = new Combat.FeatInfo(Combat.FeatType.NonAttack, FeatDatabase.SWAP.id, EntityId.INVALID_ID);
                GRouting.SendMyMapRpc(GRpcID.CombatServer_QueueFeat, new object[] { (byte) queuedFeat.featType, queuedFeat.featId, queuedFeat.targetEntityId, (byte) Combat.FEAT_INFO_INVALID.featType, Combat.FEAT_INFO_INVALID.featId, Combat.FEAT_INFO_INVALID.targetEntityId });
            }
            else
            {
                entityMotion.ChangeWeapons(playerCombatVars);
                EntityLoadClient.UpdateWeaponTypes(EntityDataClient.owner);
            }
            GRouting.SendMyMapRpc(GRpcID.CombatServer_WeaponSetChange, new object[0]);
        }
    }

    public static bool SyncFixedUpdate()
    {
        CombatVars playerCombatVars = CombatClient.playerCombatVars;
        EntityMotion entityMotion = CombatClient.entityMotion;
        if ((playerCombatVars != null) && (entityMotion != null))
        {
            if (((entityMotion.forward != previousForward) || (entityMotion.strafe != previousStrafe)) || (playerCombatVars.movementType != previousMovementType))
            {
                if ((entityMotion.forward < -0.1f) || ((entityMotion.forward == 0f) && (entityMotion.strafe == 0f)))
                {
                    entityMotion.speedToggle = CombatVars.MovementType.HUSTLE;
                }
                if (playerCombatVars.maxMovement != CombatVars.MovementType.RUN)
                {
                    entityMotion.speedToggle = playerCombatVars.maxMovement;
                }
                if (previousMovementType != playerCombatVars.movementType)
                {
                    GRouting.SendMyMapRpc(GRpcID.CombatServer_MovementChanged, new object[] { (int) playerCombatVars.movementType });
                }
                previousForward = entityMotion.forward;
                previousStrafe = entityMotion.strafe;
                previousMovementType = playerCombatVars.movementType;
            }
            if ((entityMotion.speedToggle == CombatVars.MovementType.RUN) && playerCombatVars.stealthMode)
            {
                StealthMode(STEALTH_OFF, EntityDataClient.owner.entityId);
            }
        }
        return true;
    }

    public static void SyncStart()
    {
        CombatCore.distanceCheck = new CombatCore.DistanceCheck(CombatClient.DistanceCheck);
        CombatCore.isOwner = new CombatCore.IsOwnerDelegate(CombatClient.OwnerCheck);
        CombatCore.getPosition = new CombatCore.GetCombatPosition(CombatClient.GetEntityPosition);
        StaticDataService.RegisterCallback<ColorData>(new StaticDataService.StaticDataServiceCallback(CombatClient.UpdateColors));
    }

    public static bool SyncUpdate()
    {
        if ((entityMotion != null) && (CombatClient.playerCombatVars != null))
        {
            bool inCombat = CombatClient.playerCombatVars.inCombat;
            if (entityMotion.debugInCombat)
            {
                inCombat = true;
            }
            if ((entityMotion.prevInCombat && !inCombat) && weaponDrawn)
            {
                StowWeapon();
            }
            if (!((entityMotion.prevInCombat || !inCombat) || weaponDrawn))
            {
                DrawWeapon();
            }
            if ((currentFeat.featId == 0) && (queuedFeat.featId == 0))
            {
                return true;
            }
            if ((currentFeatStartTime != 0f) && (currentFeatEndTime > Time.time))
            {
                return true;
            }
            if ((((queuedFeat.featType == Combat.FeatType.Offensive) && (queuedFeat.featId != 0)) && (queuedFeat.targetEntityId != EntityId.INVALID_ID)) && (EntityCore.GetEntity(ref queuedFeat.targetEntityId) == null))
            {
                queuedFeat = delayedFeat;
                delayedFeat = Combat.FEAT_INFO_INVALID;
                return true;
            }
            currentFeat = Combat.FEAT_INFO_INVALID;
            currentFeatStartTime = 0f;
            currentFeatEndTime = 0f;
            if (queuedFeat.featId == 0)
            {
                return true;
            }
            CombatVars playerCombatVars = CombatClient.playerCombatVars;
            if (queuedFeat.featType == Combat.FeatType.Offensive)
            {
                DoAttackFeat(playerCombatVars);
            }
            else if (queuedFeat.featType == Combat.FeatType.NonAttack)
            {
                DoNonAttackFeat(playerCombatVars);
            }
        }
        return true;
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void UnconsciousNotification(EntityId entityId)
    {
        Entity entity = EntityCore.GetEntity(ref entityId);
        GameObject gameObject = entity.gameObject;
        if ((entity != null) && (gameObject != null))
        {
            GameObject player = PlayerEntityClient.GetPlayer();
            if (gameObject == player)
            {
                ChatGui.singleton.DisplayMessage("You are unconscious and dying... May Pharasma have mercy on you.", ChatClient.ERROR_COLOR);
                player.GetComponent<EntityMotion>().DoUnconsciousAnim(true);
                ClientInputManager.singleton.CancelAutorun();
                queuedFeat = Combat.FEAT_INFO_INVALID;
            }
            else
            {
                gameObject.GetComponent<PassiveAnimator>().DoUnconsciousAnim(true);
                foreach (Collider collider in gameObject.GetComponentsInChildren<Collider>(true))
                {
                    collider.isTrigger = true;
                }
            }
        }
    }

    public static void UpdateColors(List<DataClass> ignored)
    {
        DAMAGE_COLOR = ColorData.GetColorByName("combat_overhead_damage", true);
        HEAL_COLOR = ColorData.GetColorByName("combat_overhead_heal", true);
        POS_ALERT_COLOR = ColorData.GetColorByName("combat_overhead_bad_alert", true);
        NEG_ALERT_COLOR = ColorData.GetColorByName("combat_overhead_good_alert", true);
    }

    public static bool ValidateAttack(int attackId, ref EntityId targetEntityId)
    {
        if (attackId == 0)
        {
            Debug.Log("Invalid attack!");
            return false;
        }
        if (playerCombatVars.hitPoints <= 0)
        {
            ChatGui.singleton.DisplayMessage("You are dead.", ChatClient.ERROR_COLOR);
            return false;
        }
        if (entityMotion.debugMode || entityMotion.debugInCombat)
        {
            OffensiveFeatData attackById = OffensiveFeatData.GetAttackById(attackId);
            float time = (attackById.durationValidation + attackById.durationInterruption) + attackById.durationFollowThrough;
            bool useOffhand = ShouldUseOffhand(attackById, playerCombatVars);
            entityMotion.DoAttackAnim(AnimationData.GetById(attackById.animationId), time, useOffhand, attackById.rooted);
            return false;
        }
        if (!playerCombatVars.cooldowns.IsFeatUsable(attackId))
        {
            return false;
        }
        bool flag2 = SelfTargetOverride(FeatDatabase.GetFeatById(attackId).effectType, targetEntityId);
        if (flag2)
        {
            targetEntityId = playerCombatVars.entityId;
        }
        if (targetEntityId == EntityId.INVALID_ID)
        {
            GLog.LogWarning(new object[] { "Can't attack, no Target" });
            return false;
        }
        CombatVars combatVarsFromId = CombatCore.GetCombatVarsFromId(ref targetEntityId);
        if (combatVarsFromId == null)
        {
            GLog.LogWarning(new object[] { "Cannot attack non-combat target" });
            return false;
        }
        if (!flag2)
        {
            if (CombatCore.OutsideStealthRange(combatVarsFromId, playerCombatVars))
            {
                UIClient.AddOverheadText(entityMotion.gameObject, NEG_ALERT_COLOR, "Target out of stealth range!", 5f);
                return false;
            }
            if (!CombatCore.WithinRange(playerCombatVars, combatVarsFromId, attackId, Combat.FeatType.Offensive, false))
            {
                UIClient.AddOverheadText(entityMotion.gameObject, NEG_ALERT_COLOR, "Target out of range!", 5f);
            }
        }
        bool inCombat = playerCombatVars.inCombat;
        if (entityMotion.debugInCombat)
        {
            inCombat = true;
        }
        if (((((currentFeat.featId == FeatDatabase.DRAW.id) || (queuedFeat.featId == FeatDatabase.DRAW.id)) || ((currentFeat.featId == FeatDatabase.STOW.id) || (queuedFeat.featId == FeatDatabase.STOW.id))) || (((currentFeat.featId == FeatDatabase.SWAP.id) || (queuedFeat.featId == FeatDatabase.SWAP.id)) || (queuedFeat.featId == attackId))) || (delayedFeat.featId != 0))
        {
            return false;
        }
        bool flag4 = true;
        bool flag5 = true;
        if (!(((currentFeat.featId != 0) || (queuedFeat.featId != 0)) || playerCombatVars.inCombat))
        {
            delayedFeat = new Combat.FeatInfo(Combat.FeatType.Offensive, attackId, targetEntityId);
            queuedFeat = new Combat.FeatInfo(Combat.FeatType.NonAttack, FeatDatabase.DRAW.id, EntityId.INVALID_ID);
            flag5 = CombatCore.FeatUsableInStealth(Combat.FeatType.Attack, attackId);
            flag4 = CombatCore.FeatUsableInStealth(Combat.FeatType.NonAttack, FeatDatabase.DRAW.id);
        }
        else
        {
            delayedFeat = Combat.FEAT_INFO_INVALID;
            queuedFeat = new Combat.FeatInfo(Combat.FeatType.Offensive, attackId, targetEntityId);
            flag4 = CombatCore.FeatUsableInStealth(Combat.FeatType.Attack, attackId);
        }
        if (playerCombatVars.stealthMode && (!flag5 || !flag4))
        {
            StealthMode(STEALTH_OFF, EntityDataClient.owner.entityId);
        }
        return true;
    }

    public static uint CurrentTick
    {
        get
        {
            return (CombatCore.CurrentTick + currentTickDelta);
        }
        set
        {
            if (countTickDelta < 10)
            {
                currentTickDelta = value - CombatCore.CurrentTick;
            }
            else
            {
                currentTickDelta = (uint) Mathf.RoundToInt(((9f * currentTickDelta) / 10f) + (((float) (value - CombatCore.CurrentTick)) / 10f));
            }
        }
    }

    public static CombatVars playerCombatVars
    {
        get
        {
            if (EntityDataClient.owner != null)
            {
                return EntityDataClient.owner.combat;
            }
            return null;
        }
    }
}

