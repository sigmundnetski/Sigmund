﻿using GNGUI;
using System;
using UnityEngine;

public class CompanyWindowAlliancesTabGui : CompanyWindowTabGui
{
    private Tabs activeTab = Tabs.BANNERS;
    private CompanyAlliancesTabGui[] allTabs = new CompanyAlliancesTabGui[3];
    private UISprite tabBackground;
    private UILabel tabButtonAllies;
    private UILabel tabButtonApplicants;
    private UILabel tabButtonBanners;

    public void AlliesTabSelected(GameObject go)
    {
        Tabs activeTab = this.activeTab;
        this.activeTab = Tabs.ALLIES;
        if (this.activeTab != activeTab)
        {
            this.ShowSubtab();
        }
    }

    public void ApplicantsTabSelected(GameObject go)
    {
        Tabs activeTab = this.activeTab;
        this.activeTab = Tabs.APPLICANTS;
        if (this.activeTab != activeTab)
        {
            this.ShowSubtab();
        }
    }

    public void Awake()
    {
        foreach (UILabel label in base.GetComponentsInChildren<UILabel>())
        {
            if (label.name == "TabButtonBanners")
            {
                this.tabButtonBanners = label;
            }
            else if (label.name == "TabButtonAllies")
            {
                this.tabButtonAllies = label;
            }
            else if (label.name == "TabButtonApplicants")
            {
                this.tabButtonApplicants = label;
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find labels.", new object[] { this.tabButtonBanners, this.tabButtonAllies, this.tabButtonApplicants });
        foreach (UISprite sprite in base.GetComponentsInChildren<UISprite>())
        {
            if (sprite.name == "BackgroundTabs")
            {
                this.tabBackground = sprite;
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find sprites.", new object[] { this.tabBackground });
        foreach (CompanyAlliancesTabGui gui in base.GetComponentsInChildren<CompanyAlliancesTabGui>())
        {
            if (gui.name == "Tab0Banners")
            {
                this.allTabs[0] = gui;
            }
            else if (gui.name == "Tab1Allies")
            {
                this.allTabs[1] = gui;
            }
            else if (gui.name == "Tab2Applicants")
            {
                this.allTabs[2] = gui;
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find all tabs.", this.allTabs);
        UIEventListener listener1 = UIEventListener.Get(this.tabButtonBanners.gameObject);
        listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.BannersTabSelected));
        UIEventListener listener2 = UIEventListener.Get(this.tabButtonAllies.gameObject);
        listener2.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener2.onClick, new UIEventListener.VoidDelegate(this.AlliesTabSelected));
        UIEventListener listener3 = UIEventListener.Get(this.tabButtonApplicants.gameObject);
        listener3.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener3.onClick, new UIEventListener.VoidDelegate(this.ApplicantsTabSelected));
    }

    public void BannersTabSelected(GameObject go)
    {
        Tabs activeTab = this.activeTab;
        this.activeTab = Tabs.BANNERS;
        if (this.activeTab != activeTab)
        {
            this.ShowSubtab();
        }
    }

    public override void DisplayCompany()
    {
        foreach (CompanyAlliancesTabGui gui in this.allTabs)
        {
            gui.DisplayCompanies();
        }
    }

    public override void HideTab()
    {
        base.HideTab();
        this.allTabs[(int) this.activeTab].HideTab();
    }

    public override void LoadingTickFinished()
    {
        foreach (CompanyAlliancesTabGui gui in this.allTabs)
        {
            gui.LoadingTickFinished();
            gui.HideTab();
        }
    }

    public override void RefreshCompany()
    {
        this.DisplayCompany();
    }

    public void ShowSubtab()
    {
        for (int i = 0; i < this.allTabs.Length; i++)
        {
            if (i == this.activeTab)
            {
                this.allTabs[i].ShowTab();
            }
            else
            {
                this.allTabs[i].HideTab();
            }
        }
    }

    public override void ShowTab()
    {
        base.ShowTab();
        this.ShowSubtab();
    }

    public override void UpdateCompany()
    {
        this.DisplayCompany();
    }

    public enum Tabs
    {
        BANNERS,
        ALLIES,
        APPLICANTS,
        NUM_TABS
    }
}

