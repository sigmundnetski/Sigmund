﻿using GNGUI;
using System;
using UnityEngine;

public class SortButton : MonoBehaviour
{
    public SortType sort = SortType.INACTIVE;
    public int sortId;
    private UISprite sortIndicator;

    public void Init(int id, SortType defaultSort)
    {
        this.sortIndicator = base.GetComponentInChildren<UISprite>();
        GuiHelper.GuiAssertNotNull("Could not find sort sprite.", new object[] { this.sortIndicator });
        this.sortId = id;
        this.sort = defaultSort;
        this.SetSortIndicator();
    }

    private void SetSortIndicator()
    {
        if (this.sort == SortType.INACTIVE)
        {
            NGUITools.SetActive(this.sortIndicator.gameObject, false);
        }
        else
        {
            Vector3 eulerAngles;
            Vector3 vector2;
            if (this.sort == SortType.DESCENDING)
            {
                eulerAngles = this.sortIndicator.transform.eulerAngles;
                vector2 = new Vector3(eulerAngles.x, eulerAngles.y, 0f);
                this.sortIndicator.transform.eulerAngles = vector2;
                NGUITools.SetActive(this.sortIndicator.gameObject, true);
            }
            else if (this.sort == SortType.ASCENDING)
            {
                eulerAngles = this.sortIndicator.transform.eulerAngles;
                vector2 = new Vector3(eulerAngles.x, eulerAngles.y, 180f);
                this.sortIndicator.transform.eulerAngles = vector2;
                NGUITools.SetActive(this.sortIndicator.gameObject, true);
            }
        }
    }

    public SortType ToggleSort(bool active)
    {
        if (active)
        {
            if (this.sort == SortType.INACTIVE)
            {
                this.sort = SortType.DESCENDING;
            }
            else if (this.sort == SortType.DESCENDING)
            {
                this.sort = SortType.ASCENDING;
            }
            else if (this.sort == SortType.ASCENDING)
            {
                this.sort = SortType.DESCENDING;
            }
        }
        else
        {
            this.sort = SortType.INACTIVE;
        }
        this.SetSortIndicator();
        return this.sort;
    }

    public enum SortType
    {
        INACTIVE,
        ASCENDING,
        DESCENDING
    }
}

