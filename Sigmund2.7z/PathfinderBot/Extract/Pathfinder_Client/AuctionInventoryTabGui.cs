﻿using System;

public class AuctionInventoryTabGui : AuctionInvItemTabGui
{
    public static AuctionInventoryTabGui singleton;

    public override void Awake()
    {
        singleton = this;
        this.OnAwake();
    }

    protected override InventoryItem[] GetReadonlyItems()
    {
        return EntityDataClient.owner.playerRecord.inventory;
    }

    private void OnAwake()
    {
        base.Awake();
        base.itemSource = Item.Container.INVENTORY;
    }

    public void OnDestroy()
    {
        singleton = null;
    }
}

