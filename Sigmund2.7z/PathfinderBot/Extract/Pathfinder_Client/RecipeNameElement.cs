﻿using GNGUI;
using System;
using UnityEngine;

public class RecipeNameElement : MonoBehaviour
{
    private static readonly Color BLOCKED = new Color(0.93f, 0.08f, 0.07f, 1f);
    private static readonly Color HOVERED = Color.white;
    private int myRecipeId;
    private UILabel nameLabel;
    private static readonly Color NORMAL = new Color(0.94f, 0.89f, 0.66f, 1f);
    private Color prevColor = NORMAL;
    private static readonly Color SELECTED = new Color(0.29f, 0.55f, 0.39f, 1f);
    public static RecipeNameElement selectedRecipe;

    public void OnClick()
    {
        if (selectedRecipe != null)
        {
            selectedRecipe.nameLabel.color = NORMAL;
            selectedRecipe.prevColor = NORMAL;
        }
        if (selectedRecipe == this)
        {
            selectedRecipe = null;
            CraftingClient.activeRequest.SetRecipe(0);
        }
        else
        {
            selectedRecipe = this;
            CraftingClient.activeRequest.SetRecipe(this.myRecipeId);
            this.nameLabel.color = SELECTED;
        }
        this.prevColor = this.nameLabel.color;
        BaseRecipeData data = BaseRecipeData.recipeById[this.myRecipeId];
        CraftingClient.ResetAllocations(data.inputQtys);
        CraftingClient.selectedInputIndex = -1;
        CraftingWindow.singleton.OnRecipeSelected();
    }

    public void OnHover(bool isHovered)
    {
        if (isHovered)
        {
            this.nameLabel.color = HOVERED;
        }
        else
        {
            this.nameLabel.color = this.prevColor;
        }
    }

    public void SetData(BaseRecipeData recipe)
    {
        if (this.nameLabel == null)
        {
            this.nameLabel = base.transform.FindChild("HPO/Label").GetComponent<UILabel>();
        }
        this.myRecipeId = recipe.id;
        base.gameObject.name = this.nameLabel.text = recipe.displayName;
        this.nameLabel.color = (this.myRecipeId == CraftingClient.activeRequest.GetRecipeId()) ? SELECTED : NORMAL;
        this.prevColor = (this.myRecipeId == CraftingClient.activeRequest.GetRecipeId()) ? SELECTED : NORMAL;
    }
}

