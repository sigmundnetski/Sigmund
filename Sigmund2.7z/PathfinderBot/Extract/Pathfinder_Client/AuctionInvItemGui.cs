﻿using System;
using UnityEngine;

public class AuctionInvItemGui : AuctionItemGui
{
    private Item.Container itemSource;

    public void OnClick()
    {
        if (base.selected)
        {
            AuctionInvItemTabGui.GetSingleton(this.itemSource).OnItemSelected(InventoryItem.EMPTY, (this.itemSource == Item.Container.INVENTORY) ? AuctionHouseGui.Tabs.INVENTORY : AuctionHouseGui.Tabs.BANK);
        }
        else
        {
            base.nameLabel.color = AuctionHouseGui.SELECTED_TEXT;
            AuctionInvItemTabGui.GetSingleton(this.itemSource).OnItemSelected(base.item, (this.itemSource == Item.Container.INVENTORY) ? AuctionHouseGui.Tabs.INVENTORY : AuctionHouseGui.Tabs.BANK);
        }
        base.prevColor = base.nameLabel.color;
    }

    public void SetData(InventoryItem item_, Item.Container itemSource_, InventoryItem selectedItem)
    {
        if (base.nameLabel == null)
        {
            base.nameLabel = base.transform.FindChild("Label").GetComponent<UILabel>();
        }
        if (base.icon == null)
        {
            base.icon = base.transform.FindChild("Icon").GetComponent<UISprite>();
        }
        base.item = item_;
        this.itemSource = itemSource_;
        base.SetData(base.item);
        this.UpdateSelected(AuctionHouseGui.singleton.currentItem, selectedItem);
    }

    public void UpdateSelected(InventoryItem selectedItem, InventoryItem exactItem)
    {
        base.selected = (this.item.staticItemId == selectedItem.staticItemId) && this.item.Stackable(exactItem);
        Color color = base.selected ? AuctionHouseGui.SELECTED_TEXT : AuctionHouseGui.NORMAL_TEXT;
        base.nameLabel.color = color;
        base.prevColor = color;
    }
}

