﻿using System;
using UnityEngine;

public class CameraToggle : MonoBehaviour
{
    public GameObject[] cameras;
    private const string MAIN_CAMERA = "MainCamera";
    private GameObject mainCamera;
    private Skybox mainSkybox;
    private Transform originalParent;
    private Vector3 originalPosition;
    private Quaternion originalRotation;
    private static readonly Vector3 positionOffset = new Vector3(0f, -60f, 30f);
    public static CameraToggle singleton;
    private const string UNTAGGED = "Untagged";

    public void Awake()
    {
        singleton = this;
    }

    private void GetUpdatedPlayerInformation()
    {
        GameObject player = PlayerEntityClient.GetPlayer();
        if (player != null)
        {
            this.originalParent = player.transform.parent;
            this.originalPosition = player.transform.position;
            this.originalRotation = player.transform.rotation;
        }
    }

    public void OnDestroy()
    {
        singleton = null;
    }

    private void RestorePlayerInformation()
    {
        GameObject player = PlayerEntityClient.GetPlayer();
        if (player != null)
        {
            player.SetActive(true);
            player.GetComponent<EntityMotion>().UnlockPosition(BaseMotion.PositionLock.External);
            player.transform.parent = this.originalParent;
            player.transform.position = this.originalPosition;
            player.transform.rotation = this.originalRotation;
        }
    }

    private void SetupCameras()
    {
        this.mainCamera = GameObject.Find("/GoblinCamera(Clone)");
        if (this.mainCamera != null)
        {
            this.mainSkybox = this.mainCamera.GetComponent<Skybox>();
        }
        this.GetUpdatedPlayerInformation();
        for (int i = 0; i < this.cameras.Length; i++)
        {
            if (this.cameras[i] != null)
            {
                this.UpdateSkybox(this.cameras[i]);
                this.cameras[i].SetActive(false);
            }
        }
    }

    private void SetUpdatedPlayerInformation(Transform parent)
    {
        GameObject player = PlayerEntityClient.GetPlayer();
        if (player != null)
        {
            player.SetActive(true);
            player.GetComponent<EntityMotion>().LockPosition(BaseMotion.PositionLock.External, "Cannot move until interaction window is closed.");
            player.transform.parent = parent;
            player.transform.localPosition = positionOffset;
            player.transform.rotation = Quaternion.identity;
        }
    }

    private void Start()
    {
        this.SetupCameras();
        if (EntityCore.IsClient)
        {
            CommandClient.DelayedRegisterCommand("ToggleCamera", new CommandCore.CommandDelegate(singleton.ToggleCamera), CommandCore.PermissionLevel.TESTING, CommandCore.Options.AUTO_COMPLETE | CommandCore.Options.OVERWRITE, null);
        }
    }

    public void ToggleCamera(string[] args, EntityId playerEntityId)
    {
        if (this.mainCamera == null)
        {
            this.SetupCameras();
        }
        if (args.Length >= 2)
        {
            int result = 0;
            int.TryParse(args[1], out result);
            if (this.mainCamera.activeSelf)
            {
                this.GetUpdatedPlayerInformation();
            }
            else
            {
                this.RestorePlayerInformation();
            }
            for (int i = 0; i < this.cameras.Length; i++)
            {
                if (this.cameras[i] != null)
                {
                    this.cameras[i].tag = "Untagged";
                    this.cameras[i].SetActive(false);
                }
            }
            if (result == 0)
            {
                this.mainCamera.tag = "MainCamera";
                this.mainCamera.SetActive(true);
            }
            else if ((result > 0) && (result <= this.cameras.Length))
            {
                this.mainCamera.tag = "Untagged";
                this.mainCamera.SetActive(false);
                if (this.cameras[result - 1] != null)
                {
                    this.SetUpdatedPlayerInformation(this.cameras[result - 1].transform);
                    this.cameras[result - 1].tag = "MainCamera";
                    this.cameras[result - 1].SetActive(true);
                }
                else
                {
                    this.RestorePlayerInformation();
                    this.mainCamera.tag = "MainCamera";
                    this.mainCamera.SetActive(true);
                }
            }
        }
    }

    private void UpdateSkybox(GameObject cam)
    {
        if (this.mainSkybox != null)
        {
            cam.GetComponent<Skybox>().material = this.mainSkybox.material;
        }
    }
}

