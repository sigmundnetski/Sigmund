﻿using System;
using UnityEngine;

public static class AnimDebug
{
    private static float origFixedDeltaTime = Time.fixedDeltaTime;

    public static void AnimMovement(string[] args, EntityId playerEntityId)
    {
        EntityMotion.debugNoMovement = !EntityMotion.debugNoMovement;
        GLog.Log(new object[] { "Movement of player GameObject has been", EntityMotion.debugNoMovement ? "disabled." : "enabled." });
    }

    public static void AnimOffset(string[] args, EntityId playerEntityId)
    {
        GameObject gameObject = EntityDataClient.owner.gameObject;
        if (gameObject == null)
        {
            GLog.LogError(new object[] { "No player found." });
        }
        else
        {
            CharacterController component = gameObject.GetComponent<CharacterController>();
            if (component == null)
            {
                GLog.LogError(new object[] { "No " + component.GetType() + " found." });
            }
            else
            {
                Vector3 position = gameObject.transform.position;
                Vector3 vector2 = new Vector3(position.x, position.y + 1f, position.z);
                gameObject.transform.position = vector2;
                Vector3 center = component.center;
                Vector3 vector4 = new Vector3(center.x, center.y - 1f, center.z);
                component.center = vector4;
            }
        }
    }

    public static void AnimSpeed(string[] args, EntityId playerEntityId)
    {
        EntityMotion.debugSpeed = !EntityMotion.debugSpeed;
        GLog.Log(new object[] { "Debug speed on player", EntityMotion.debugSpeed ? "disabled." : "enabled." });
    }

    public static void AnimSwapWeapon(string[] args, EntityId playerEntityId)
    {
        string str = string.Empty;
        if (args.Length < 2)
        {
            DebugClient.DisplayDebugMessage("Need a weapon name (e.g. AnimSwapWeapon Longsword).");
        }
        else
        {
            WeaponCategoryData data;
            string[] destinationArray = new string[args.Length - 1];
            Array.Copy(args, 1, destinationArray, 0, destinationArray.Length);
            str = string.Join(" ", destinationArray);
            int mainhandCategoryId = 0;
            if (WeaponCategoryData.categoriesByName.TryGetValue(str.ToLower(), out data))
            {
                mainhandCategoryId = data.id;
            }
            int offhandCategoryId = 0;
            if (mainhandCategoryId != 0)
            {
                CombatClient.entityMotion.ChangeWeapons(mainhandCategoryId, offhandCategoryId);
            }
            else
            {
                DebugClient.DisplayDebugMessage("Could not find weapon category for: '" + str + "'.");
            }
        }
    }

    public static void ChangeUnityTimescale(string[] args, EntityId playerEntityId)
    {
        if (Time.timeScale == 1f)
        {
            TimeScale(0.25f);
            DebugClient.DisplayDebugMessage("Time moving at 1/4 scale.");
        }
        else if (Time.timeScale == 0.25f)
        {
            TimeScale(0.1f);
            DebugClient.DisplayDebugMessage("Time moving at 1/10 scale.");
        }
        else
        {
            TimeScale(1f);
            DebugClient.DisplayDebugMessage("Time moving at normal scale.");
        }
    }

    public static void ManageAnimProxies(string[] args, EntityId playerEntityId)
    {
        if (args.Length == 1)
        {
            SlavedProxyClient.SpawnProxySlavedToPlayer();
        }
        else
        {
            if (args.Length != 2)
            {
                DebugClient.DisplayDebugMessage("AnimProxy Usage:\n  Add a proxy: AnimProxy\n  Add a proxy: AnimProxy add\n  Remove all:  AnimProxy remove");
                return;
            }
            string str = args[1].ToLower();
            if (str == null)
            {
                goto Label_006B;
            }
            if (!(str == "add"))
            {
                if ((str == "rem") || (str == "remove"))
                {
                    SlavedProxyClient.DestroyProxiesSlavedToPlayer();
                    return;
                }
                goto Label_006B;
            }
            SlavedProxyClient.SpawnProxySlavedToPlayer();
        }
        return;
    Label_006B:
        DebugClient.DisplayDebugMessage("AnimProxy Usage:\n  Add a proxy: AnimProxy\n  Add a proxy: AnimProxy add\n  Remove all:  AnimProxy remove");
    }

    public static void TimeScale(float scale)
    {
        Time.timeScale = scale;
        Time.fixedDeltaTime = origFixedDeltaTime * Time.timeScale;
        Debug.Log("Local time scale changed to " + Time.timeScale + ". Server time unaffected.");
    }

    public static void ToggleAnimDebugCombat(string[] args, EntityId playerEntityId)
    {
        EntityMotion component = PlayerEntityClient.GetPlayer().GetComponent<EntityMotion>();
        component.debugInCombat = !component.debugInCombat;
        if (component.debugInCombat)
        {
            CombatClient.DrawWeapon();
        }
        else
        {
            CombatClient.StowWeapon();
        }
        if (UnityEditorTickMono.singleton != null)
        {
            Debug.LogWarning("Currently you can't play attack anims in Drop Player Here mode, so this is a bit pointless...");
        }
        else
        {
            DebugClient.DisplayDebugMessage("Debug Combat " + (component.debugInCombat ? "on." : "off."));
        }
    }
}

