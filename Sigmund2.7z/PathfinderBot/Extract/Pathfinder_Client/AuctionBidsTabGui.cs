﻿using GNGUI;
using System;
using System.Collections.Generic;
using UnityEngine;

public class AuctionBidsTabGui : AuctionOrdersBidsTabGui
{
    private UIImageButton bidButton;

    public override void Awake()
    {
        base.Awake();
        base.offerType = ItemOffer.OfferType.BID;
        foreach (UIImageButton button in base.GetComponentsInChildren<UIImageButton>())
        {
            if (button.name == "ButtonBid")
            {
                this.bidButton = button;
                UIEventListener listener1 = UIEventListener.Get(this.bidButton.gameObject);
                listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.OnBidClick));
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find needed children.", new object[] { this.bidButton });
    }

    protected override List<ItemOffer> GetItems()
    {
        return AuctionHouseGui.singleton.currentBidItems;
    }

    public void OnBidClick(GameObject filterGO)
    {
        AuctionItemPopupGui.singleton.Repopulate(AuctionHouseGui.singleton.currentItem, AuctionItemPopupGui.InputType.BID, Item.Container.INVALID);
    }
}

