﻿using GNGUI;
using System;
using UnityEngine;

public class TradeWindowGui : ItemWindowGui
{
    private UIImageButton acceptButton;
    private string[] acceptSprites = new string[] { "button_trade_accept_de", "button_trade_accept_mo", "button_trade_accept_cl" };
    private string[] alterOfferSprites = new string[] { "button_trade_alteroffer_de", "button_trade_alteroffer_mo", "button_trade_alteroffer_cl" };
    private UIImageButton cancelButton;
    private TradeRole myRole;
    private UILabel offerAccept;
    private UIImageButton offerButton;
    private string[] offerSprites = new string[] { "button_trade_offer_de", "button_trade_offer_mo", "button_trade_offer_cl" };
    private PlayerTrade prevTrade = new PlayerTrade();
    private string[] rejectSprites = new string[] { "button_trade_reject_de", "button_trade_reject_mo", "button_trade_reject_cl" };
    public static TradeWindowGui singleton;
    [NonSerialized, HideInInspector]
    public EntityId targetId;
    private UILabel targetName;
    private UILabel targetRep;
    private TradePanelGui[] tradePanels = new TradePanelGui[2];
    private string[] tradeSprites = new string[] { "button_trade_trade_de", "button_trade_trade_mo", "button_trade_trade_cl" };

    public void AcceptClicked(GameObject ignored)
    {
        InventoryClient.AcceptTrade();
    }

    public void AddItem(ItemGui item, ItemWindowGui.Interaction interaction)
    {
        InventoryClient.AddTradeItem(base.AdjustItemOnInteract(item.item, interaction));
    }

    public void Awake()
    {
        singleton = this;
        this.OnAwake();
    }

    public void CancelClicked(GameObject ignored)
    {
        this.HideWindow();
    }

    public void ContentsChanged(PlayerTrade trade)
    {
        if (!base.IsShowing())
        {
            this.ShowWindow();
        }
        if (EntityCore.Match(EntityDataClient.owner.entityId, trade.initiatorEntityId))
        {
            this.myRole = TradeRole.INITIATOR;
        }
        else if (EntityCore.Match(EntityDataClient.owner.entityId, trade.targetEntityId))
        {
            this.myRole = TradeRole.TARGET;
        }
        else
        {
            GLog.LogError(new object[] { "Got a trade to which client doesn't belong... client:", EntityDataClient.owner.entityId, "trade info:", trade.initiatorEntityId, trade.initiatorStatus, trade.targetEntityId, trade.targetStatus });
            this.myRole = TradeRole.NONE;
            return;
        }
        EntityId entityIdA = (this.myRole == TradeRole.INITIATOR) ? trade.targetEntityId : trade.initiatorEntityId;
        EntityId entityIdB = (this.myRole == TradeRole.INITIATOR) ? this.prevTrade.targetEntityId : this.prevTrade.initiatorEntityId;
        if (!EntityCore.Match(entityIdA, entityIdB))
        {
            Entity entity = EntityCore.GetEntity(entityIdA);
            if (entity == null)
            {
                GLog.Log(new object[] { "Am trading with ent#", (this.myRole == TradeRole.INITIATOR) ? trade.targetEntityId : trade.initiatorEntityId, "but I don't know him." });
                this.targetName.text = "Trader's Offer";
                this.targetRep.text = "Reputation: unknown";
            }
            else
            {
                this.targetName.text = entity.EntityName + "'s Offer";
                if (PvpConst.IsPoorlyReputable(entity.pvp.reputation))
                {
                    this.targetRep.text = "Reputation: poor";
                }
                else if (PvpConst.IsHighlyReputable(entity.pvp.reputation))
                {
                    this.targetRep.text = "Reputation: high";
                }
                else
                {
                    this.targetRep.text = "Reputation: standard";
                }
            }
        }
        PlayerTrade.Status status = (this.myRole == TradeRole.INITIATOR) ? trade.initiatorStatus : trade.targetStatus;
        PlayerTrade.Status status2 = (this.myRole == TradeRole.INITIATOR) ? this.prevTrade.initiatorStatus : this.prevTrade.targetStatus;
        PlayerTrade.Status status3 = (this.myRole == TradeRole.INITIATOR) ? trade.targetStatus : trade.initiatorStatus;
        PlayerTrade.Status status4 = (this.myRole == TradeRole.INITIATOR) ? this.prevTrade.targetStatus : this.prevTrade.initiatorStatus;
        if (status != status2)
        {
            if ((status == PlayerTrade.Status.OFFER_ACCEPTED) && (status3 == PlayerTrade.Status.OFFER))
            {
                NGUITools.SetActive(this.acceptButton.gameObject, true);
                this.acceptButton.normalSprite = this.tradeSprites[0];
                this.acceptButton.hoverSprite = this.tradeSprites[1];
                this.acceptButton.pressedSprite = this.tradeSprites[2];
                this.acceptButton.SendMessage("OnHover", false, SendMessageOptions.DontRequireReceiver);
            }
            if (status < PlayerTrade.Status.OFFER)
            {
                this.offerButton.normalSprite = this.offerSprites[0];
                this.offerButton.hoverSprite = this.offerSprites[1];
                this.offerButton.pressedSprite = this.offerSprites[2];
                this.offerButton.SendMessage("OnHover", false, SendMessageOptions.DontRequireReceiver);
            }
            else
            {
                this.offerButton.normalSprite = this.alterOfferSprites[0];
                this.offerButton.hoverSprite = this.alterOfferSprites[1];
                this.offerButton.pressedSprite = this.alterOfferSprites[2];
                this.offerButton.SendMessage("OnHover", false, SendMessageOptions.DontRequireReceiver);
            }
            if (status == PlayerTrade.Status.OFFER_ACCEPTED)
            {
                NGUITools.SetActive(this.offerAccept.gameObject, true);
            }
            else
            {
                NGUITools.SetActive(this.offerAccept.gameObject, false);
            }
            status2 = status;
        }
        if (status3 != status4)
        {
            if ((status == PlayerTrade.Status.OFFER_ACCEPTED) && (status3 == PlayerTrade.Status.OFFER))
            {
                NGUITools.SetActive(this.acceptButton.gameObject, true);
                this.acceptButton.normalSprite = this.tradeSprites[0];
                this.acceptButton.hoverSprite = this.tradeSprites[1];
                this.acceptButton.pressedSprite = this.tradeSprites[2];
                this.acceptButton.SendMessage("OnHover", false, SendMessageOptions.DontRequireReceiver);
            }
            else if (status3 == PlayerTrade.Status.OFFER)
            {
                NGUITools.SetActive(this.acceptButton.gameObject, true);
                this.acceptButton.normalSprite = this.acceptSprites[0];
                this.acceptButton.hoverSprite = this.acceptSprites[1];
                this.acceptButton.pressedSprite = this.acceptSprites[2];
                this.acceptButton.SendMessage("OnHover", false, SendMessageOptions.DontRequireReceiver);
            }
            else if (status3 == PlayerTrade.Status.OFFER_ACCEPTED)
            {
                this.acceptButton.normalSprite = this.rejectSprites[0];
                this.acceptButton.hoverSprite = this.rejectSprites[1];
                this.acceptButton.pressedSprite = this.rejectSprites[2];
                this.acceptButton.SendMessage("OnHover", false, SendMessageOptions.DontRequireReceiver);
            }
            else
            {
                NGUITools.SetActive(this.acceptButton.gameObject, false);
            }
            status4 = status3;
        }
        InventoryItem[] tradeContainer = (this.myRole == TradeRole.INITIATOR) ? trade.initiatorItems : trade.targetItems;
        InventoryItem[] itemArray2 = (this.myRole == TradeRole.INITIATOR) ? trade.targetItems : trade.initiatorItems;
        this.tradePanels[0].ContentsChanged(tradeContainer);
        this.tradePanels[1].ContentsChanged(itemArray2);
        this.prevTrade = trade;
    }

    public override void DragEnd(InventoryItem item, BasicItemData.ItemSlot slot)
    {
        if (UICamera.hoveredObject.GetComponent<TradeWindowGui>() == null)
        {
            InventoryClient.RemoveTradeItem(item);
        }
        foreach (TradePanelGui gui2 in this.tradePanels)
        {
            gui2.DragEnd();
        }
    }

    public override void DragStart(InventoryItem item)
    {
    }

    public override void HideWindow()
    {
        base.HideWindow();
        foreach (TradePanelGui gui in this.tradePanels)
        {
            gui.ResetScroll();
            gui.ClearItems();
        }
        InventoryClient.CancelTrade();
    }

    public override void ItemInteract(ItemGui item, ItemWindowGui.Interaction interaction)
    {
        if ((interaction == ItemWindowGui.Interaction.DROP) && (item is InventoryItemGui))
        {
            this.AddItem(item, interaction);
        }
        else
        {
            InventoryItem item2 = base.AdjustItemOnInteract(item.item, interaction);
            TradeItemGui gui = item as TradeItemGui;
            if ((gui != null) && (gui.owner == TradePanel.OWNER))
            {
                InventoryClient.RemoveTradeItem(item2);
            }
        }
    }

    public bool LoadingTickFinished()
    {
        foreach (TradePanelGui gui in this.tradePanels)
        {
            gui.LoadingTickFinished();
        }
        return true;
    }

    public void OfferClicked(GameObject ignored)
    {
        InventoryClient.OfferTrade();
    }

    public void OnAwake()
    {
        ClientTick.tradeGuiLoadFinish = new GUtil.BoolFilterDelegate(this.LoadingTickFinished);
        foreach (UILabel label in base.GetComponentsInChildren<UILabel>())
        {
            if (label.name == "TargetName")
            {
                this.targetName = label;
            }
            else if (label.name == "TargetReputation")
            {
                this.targetRep = label;
            }
            else if (label.name == "OfferAccepted")
            {
                this.offerAccept = label;
            }
        }
        foreach (UIImageButton button in base.GetComponentsInChildren<UIImageButton>())
        {
            if (button.name == "SelfButton")
            {
                this.offerButton = button;
            }
            else if (button.name == "TargetButton")
            {
                this.acceptButton = button;
            }
            else if (button.name == "CancelButton")
            {
                this.cancelButton = button;
            }
        }
        foreach (TradePanelGui gui in base.GetComponentsInChildren<TradePanelGui>())
        {
            if (gui.name == "TradeSelfPanel")
            {
                this.tradePanels[0] = gui;
                gui.panelType = TradePanel.OWNER;
            }
            else if (gui.name == "TradeTargetPanel")
            {
                this.tradePanels[1] = gui;
                gui.panelType = TradePanel.TARGET;
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find children.", new object[] { this.targetName, this.targetRep, this.offerButton, this.acceptButton, this.cancelButton });
        GuiHelper.GuiAssertNotNull("Couldn't find panels.", this.tradePanels);
        UIEventListener listener1 = UIEventListener.Get(this.offerButton.gameObject);
        listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.OfferClicked));
        UIEventListener listener2 = UIEventListener.Get(this.acceptButton.gameObject);
        listener2.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener2.onClick, new UIEventListener.VoidDelegate(this.AcceptClicked));
        UIEventListener listener3 = UIEventListener.Get(this.cancelButton.gameObject);
        listener3.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener3.onClick, new UIEventListener.VoidDelegate(this.CancelClicked));
    }

    public override void OnDestroy()
    {
        base.OnDestroy();
        singleton = null;
    }

    public override void ShowWindow()
    {
        base.ShowWindow();
        if (BankWindowGui.singleton.IsShowing())
        {
            BankWindowGui.singleton.HideWindow();
        }
    }

    public void Start()
    {
        base.Init(2, true);
    }

    public void TradeFinished(PlayerTrade.TradeFailure reason)
    {
        if (reason == PlayerTrade.TradeFailure.PLAYER_CANCEL)
        {
            ChatGui.singleton.DisplayMessage("Trade canceled.", ChatClient.ERROR_COLOR);
        }
        else if (reason == PlayerTrade.TradeFailure.INVALID_ENTITY)
        {
            ChatGui.singleton.DisplayMessage("Trader lost.", ChatClient.ERROR_COLOR);
        }
        else if (reason == PlayerTrade.TradeFailure.GHOSTED_ENTITY)
        {
            ChatGui.singleton.DisplayMessage("Trading cannot happen near hex borders.", ChatClient.ERROR_COLOR);
        }
        else if (reason == PlayerTrade.TradeFailure.INVALID_DISTANCE)
        {
            ChatGui.singleton.DisplayMessage("Try standing closer together.", ChatClient.ERROR_COLOR);
        }
        else if (reason == PlayerTrade.TradeFailure.IN_COMBAT)
        {
            ChatGui.singleton.DisplayMessage("Cannot be in combat while trading.", ChatClient.ERROR_COLOR);
        }
        else if (reason == PlayerTrade.TradeFailure.ALREADY_TRADING)
        {
            ChatGui.singleton.DisplayMessage("That player is busy right now.", ChatClient.ERROR_COLOR);
        }
        this.prevTrade = new PlayerTrade();
        this.myRole = TradeRole.NONE;
        this.HideWindow();
    }

    public enum TradePanel
    {
        OWNER,
        TARGET,
        NUM_TRADE_PANELS
    }

    private enum TradeRole
    {
        NONE,
        INITIATOR,
        TARGET
    }
}

