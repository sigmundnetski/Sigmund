﻿using System;
using UnityEngine;

public static class Conning
{
    private static Color challengingColor = new Color(1f, 0.8470588f, 0.003921569f);
    private static Color deadlyColor = new Color(0.2745098f, 0.1058824f, 0.4941176f);
    private static Color easyColor = new Color(0.3333333f, 0.4901961f, 0.8f);
    private static Color effortlessColor = new Color(0.2196078f, 0.1960784f, 0.2f);
    private static Color hostilePlayerColor = new Color(1f, 0f, 0f);
    private static Color nonCombatColor = normalColor;
    private static Color normalColor = new Color(1f, 1f, 1f);
    private static Color veryChallengingColor = new Color(0.8627451f, 0.2196078f, 0.1215686f);
    private static Color veryEasyColor = new Color(0.4901961f, 0.7843137f, 0.3098039f);

    private static int GetPlayerLevel()
    {
        return EntityDataClient.owner.combat.level;
    }

    public static Strength GetRelativeStrength(EntityId targetEntityId)
    {
        Entity entity = EntityCore.GetEntity(ref targetEntityId);
        if ((entity == null) || (entity.combat == null))
        {
            return Strength.NonCombat;
        }
        if (IsPlayer(targetEntityId) && IsHostilePlayer(targetEntityId))
        {
            return Strength.HostilePlayer;
        }
        return GetRelativeStrength(entity.combat.level);
    }

    public static Strength GetRelativeStrength(int challengeRating)
    {
        int num = challengeRating - GetPlayerLevel();
        Strength effortless = Strength.Effortless;
        if (num >= 8)
        {
            return Strength.Deadly;
        }
        if (num >= 5)
        {
            return Strength.VeryChallenging;
        }
        if (num >= 2)
        {
            return Strength.Challenging;
        }
        if (num >= -1)
        {
            return Strength.Normal;
        }
        if (num >= -4)
        {
            return Strength.Easy;
        }
        if (num >= -7)
        {
            effortless = Strength.VeryEasy;
        }
        return effortless;
    }

    public static Color GetRelativeStrengthColor(Strength relStr)
    {
        Color white = Color.white;
        switch (relStr)
        {
            case Strength.Effortless:
                return effortlessColor;

            case Strength.VeryEasy:
                return veryEasyColor;

            case ~Strength.VeryChallenging:
            case ((Strength) (-5)):
            case ~Strength.Challenging:
            case ((Strength) (-2)):
            case ((Strength) 1):
                return white;

            case Strength.Easy:
                return easyColor;

            case Strength.Normal:
                return normalColor;

            case Strength.NonCombat:
                return nonCombatColor;

            case Strength.Challenging:
                return challengingColor;

            case Strength.VeryChallenging:
                return veryChallengingColor;

            case ~Strength.VeryEasy:
            case ~Strength.Effortless:
                return white;

            case Strength.Deadly:
                return deadlyColor;

            case Strength.HostilePlayer:
                return hostilePlayerColor;
        }
        return white;
    }

    public static string GetReputationBadge(EntityId targetEntityId)
    {
        Entity entity = EntityCore.GetEntity(ref targetEntityId);
        if ((entity != null) && (entity.pvp != null))
        {
            if (PvpConst.IsPoorlyReputable(entity.pvp.reputation))
            {
                return "map_icon_enemy";
            }
            if (PvpConst.IsHighlyReputable(entity.pvp.reputation))
            {
                return "map_icon_playerowner";
            }
            if (entity.pvp.gameHours < CombatData.singleton.newPlayerHours)
            {
                return "map_icon_char";
            }
        }
        return null;
    }

    public static bool IsHostilePlayer(EntityId targetEntityId)
    {
        Entity entity = EntityCore.GetEntity(ref targetEntityId);
        if ((entity == null) || (entity.pvp == null))
        {
            return false;
        }
        bool flag = false;
        if ((entity.pvp.pvpFlags.attacker >= 2) || entity.pvp.IsAggressee(EntityDataClient.owner.playerId))
        {
            flag = true;
        }
        if (entity.pvp.killerTraitStacks >= 10)
        {
            flag = true;
        }
        return flag;
    }

    public static bool IsPlayer(EntityId targetEntityId)
    {
        Entity entity = EntityCore.GetEntity(ref targetEntityId);
        if ((entity == null) || (entity.combat == null))
        {
            return false;
        }
        return (entity.pvp != null);
    }

    public enum Strength
    {
        Challenging = 2,
        Deadly = 8,
        Easy = -4,
        Effortless = -8,
        HostilePlayer = 9,
        NonCombat = 0,
        Normal = -1,
        VeryChallenging = 5,
        VeryEasy = -7
    }
}

