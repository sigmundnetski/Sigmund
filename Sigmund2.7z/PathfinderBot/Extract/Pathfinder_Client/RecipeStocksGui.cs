﻿using GNGUI;
using System;
using UnityEngine;

public class RecipeStocksGui : MonoBehaviour
{
    private UIGrid grid;
    private RecipeStockElement[] inputElements;

    public void Repopulate()
    {
        if (this.grid == null)
        {
            this.grid = base.GetComponent<UIGrid>();
        }
        if (this.inputElements == null)
        {
            this.inputElements = base.transform.GetComponentsInChildren<RecipeStockElement>(true);
        }
        BaseRecipeData recipe = CraftingClient.activeRequest.GetRecipe();
        uint[] inputQtys = new uint[0];
        if (recipe != null)
        {
            inputQtys = recipe.inputQtys;
        }
        int inputIndex = 0;
        while (inputIndex < inputQtys.Length)
        {
            uint current = InventoryItemUtils.TotalItemCount(CraftingClient.GetAllocatedItems(inputIndex));
            this.inputElements[inputIndex].SetData(inputIndex, current, recipe.inputQtys[inputIndex]);
            inputIndex++;
        }
        while (inputIndex < this.inputElements.Length)
        {
            this.inputElements[inputIndex].SetData(inputIndex, 0, 0);
            inputIndex++;
        }
        this.grid.repositionNow = true;
    }
}

