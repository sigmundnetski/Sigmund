﻿using GNGUI;
using System;
using System.Collections.Generic;
using UnityEngine;

public class MiniMapContextGui : ContextWindowGui
{
    public List<ToggleText> allFilters = new List<ToggleText>();
    public static MiniMapContextGui singleton;

    public void Awake()
    {
        singleton = this;
    }

    public void FilterClicked(GameObject filterGO)
    {
        Debug.Log(filterGO.name);
        foreach (ToggleText text in this.allFilters)
        {
            if (filterGO == text.gameObject)
            {
                text.ToggleActive();
                if (text.isActive)
                {
                    MiniMapGui.singleton.SetFlag((MiniMapGui.MapFilter) ((byte) text.filterIds[0]));
                }
                else
                {
                    MiniMapGui.singleton.UnsetFlag((MiniMapGui.MapFilter) ((byte) text.filterIds[0]));
                }
            }
        }
    }

    public override void OnDestroy()
    {
        base.OnDestroy();
        singleton = null;
    }

    public override void Start()
    {
        foreach (ToggleText text in base.GetComponentsInChildren<ToggleText>())
        {
            this.allFilters.Add(text);
            UIEventListener listener1 = UIEventListener.Get(text.gameObject);
            listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.FilterClicked));
            if (text.name == "PlayersToggle")
            {
                text.Init(new int[] { 1 });
            }
            else if (text.name == "MonstersToggle")
            {
                text.Init(new int[] { 2 });
            }
            else if (text.name == "GatheringToggle")
            {
                text.Init(new int[] { 4 });
            }
            else if (text.name == "QuestToggle")
            {
                text.Init(new int[] { 8 });
            }
            else if (text.name == "PinsToggle")
            {
                text.Init(new int[] { 0x10 });
            }
            else
            {
                GLog.LogError(new object[] { "Unknown filter!", text.name });
            }
        }
        base.Start();
    }
}

