﻿using GNGUI;
using System;
using System.Linq;
using UnityEngine;

public class InventoryEquipmentTabGui : InventoryTabGui
{
    public override void Awake()
    {
        base.Awake();
        base.tabSpriteName = "panel_inventory_tab_left_equipment";
        base.tabType = InventoryTabGui.Tabs.EQUIPMENT;
        foreach (ToggleText text in base.GetComponentsInChildren<ToggleText>())
        {
            base.allFilters.Add(text);
            UIEventListener listener1 = UIEventListener.Get(text.gameObject);
            listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.FilterClicked));
            if (text.name == "F1_Armor")
            {
                text.Init(new int[1]);
            }
            else if (text.name == "F2_Gear")
            {
                text.Init(new int[] { 1, 2, 3, 4, 5, 6, 0x12, 0x18 });
            }
            else if (text.name == "F0_Weapons")
            {
                text.Init(new int[] { 0x13, 20, 0x15, 0x16 });
            }
            else if (text.name == "F3_Implements")
            {
                text.Init(new int[] { 0x17 });
            }
            else if (text.name == "F4_Consumables")
            {
                text.Init(new int[0]);
            }
            else
            {
                GLog.LogError(new object[] { "Unknown filter!", text.name });
            }
        }
        foreach (SortButton button in base.GetComponentsInChildren<SortButton>())
        {
            base.allSorts.Add(button);
            UIEventListener listener2 = UIEventListener.Get(button.gameObject);
            listener2.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener2.onClick, new UIEventListener.VoidDelegate(this.SortClicked));
            if (button.name == "S0_Name")
            {
                button.Init(0, SortButton.SortType.ASCENDING);
            }
            else if (button.name == "S1_Encumbrance")
            {
                button.Init(1, SortButton.SortType.INACTIVE);
            }
            else if (button.name == "S2_Durability")
            {
                button.Init(2, SortButton.SortType.INACTIVE);
            }
            else if (button.name == "S3_Tier")
            {
                button.Init(3, SortButton.SortType.INACTIVE);
            }
            else
            {
                GLog.LogError(new object[] { "Unknown sort!", button.name });
            }
            if ((button.sort != SortButton.SortType.INACTIVE) && (base.currentSort == null))
            {
                base.currentSort = button;
            }
            else if ((button.sort != SortButton.SortType.INACTIVE) && (base.currentSort != null))
            {
                GLog.LogError(new object[] { "Should only have one non-inactive sort! You have", base.currentSort.name, "and", button.name });
            }
        }
    }

    public override void FilterClicked(GameObject filterGO)
    {
        base.FilterClicked(filterGO);
        PaperdollWindowGui.singleton.SetValidityByFilter(PaperdollWindowGui.FilterType.EQUIPMENT, base.activeFilter);
    }

    protected override bool IsValidForFilter(InventoryItem item)
    {
        BasicItemData data;
        bool flag = false;
        if ((ItemDatabase.itemById.TryGetValue(item.staticItemId, out data) && (base.activeFilter != null)) && base.activeFilter.filterIds.Contains<int>(((int) data.slot)))
        {
            flag = true;
        }
        else if (((base.activeFilter == null) && (data != null)) && (data.slot != BasicItemData.ItemSlot.NONE))
        {
            flag = true;
        }
        bool flag2 = true;
        return (flag && flag2);
    }
}

