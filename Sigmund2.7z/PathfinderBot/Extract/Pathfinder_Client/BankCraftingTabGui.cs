﻿using GNGUI;
using System;
using System.Linq;

public class BankCraftingTabGui : InventoryTabGui
{
    public override void Awake()
    {
        base.Awake();
        base.tabSpriteName = "panel_inventory_tab_middle_crafting";
        base.tabType = InventoryTabGui.Tabs.CRAFTING;
        foreach (ToggleText text in base.GetComponentsInChildren<ToggleText>())
        {
            base.allFilters.Add(text);
            UIEventListener listener1 = UIEventListener.Get(text.gameObject);
            listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.FilterClicked));
            if (text.name == "F0_Raw")
            {
                text.Init(new int[] { 1 });
            }
            else if (text.name == "F1_Salvage")
            {
                text.Init(new int[] { 3 });
            }
            else if (text.name == "F2_Refined")
            {
                text.Init(new int[] { 2 });
            }
            else if (text.name == "F3_Recipes")
            {
                text.Init(new int[] { 4 });
            }
            else
            {
                GLog.LogError(new object[] { "Unknown filter!", text.name });
            }
        }
        foreach (SortButton button in base.GetComponentsInChildren<SortButton>())
        {
            base.allSorts.Add(button);
            UIEventListener listener2 = UIEventListener.Get(button.gameObject);
            listener2.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener2.onClick, new UIEventListener.VoidDelegate(this.SortClicked));
            if (button.name == "S0_Name")
            {
                button.Init(0, SortButton.SortType.ASCENDING);
            }
            else if (button.name == "S1_Variety")
            {
                button.Init(4, SortButton.SortType.INACTIVE);
            }
            else if (button.name == "S2_Encumbrance")
            {
                button.Init(1, SortButton.SortType.INACTIVE);
            }
            else if (button.name == "S3_Tier")
            {
                button.Init(3, SortButton.SortType.INACTIVE);
            }
            else
            {
                GLog.LogError(new object[] { "Unknown sort!", button.name });
            }
            if ((button.sort != SortButton.SortType.INACTIVE) && (base.currentSort == null))
            {
                base.currentSort = button;
            }
            else if ((button.sort != SortButton.SortType.INACTIVE) && (base.currentSort != null))
            {
                GLog.LogError(new object[] { "Should only have one active sort! You have", base.currentSort.name, "and", button.name });
            }
        }
    }

    protected override InventoryItem[] GetReadonlyItems()
    {
        return InventoryClient.playerBank;
    }

    protected override bool IsValidForFilter(InventoryItem item)
    {
        BasicItemData data;
        bool flag = false;
        bool flag2 = ItemDatabase.itemById.TryGetValue(item.staticItemId, out data);
        CraftingItemData data2 = data as CraftingItemData;
        CraftRecipeItemData data3 = data as CraftRecipeItemData;
        if (((data2 != null) && (base.activeFilter != null)) && base.activeFilter.filterIds.Contains<int>(((int) data2.material)))
        {
            return true;
        }
        if (((data3 != null) && (base.activeFilter != null)) && base.activeFilter.filterIds.Contains<int>(4))
        {
            return true;
        }
        if (((data2 != null) || (data3 != null)) && (base.activeFilter == null))
        {
            flag = true;
        }
        return flag;
    }
}

