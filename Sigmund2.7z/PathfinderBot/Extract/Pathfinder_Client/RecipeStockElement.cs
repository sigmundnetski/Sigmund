﻿using GNGUI;
using System;
using System.Runtime.InteropServices;
using System.Text;
using UnityEngine;

public class RecipeStockElement : MonoBehaviour
{
    private UILabel countLabel;
    private static readonly Color INSUFFICIENT = new Color(1f, 0.52f, 0.18f);
    public int myInputIndex;
    private static readonly Color SUFFICIENT = new Color(0.94f, 0.89f, 0.66f);

    private void GetDisplayName(out string displayName, out bool isStock)
    {
        BaseRecipeData recipe = CraftingClient.activeRequest.GetRecipe();
        isStock = recipe.inputStockIds.Length > 0;
        if (isStock)
        {
            displayName = StockData.stocksById[recipe.inputStockIds[this.myInputIndex]].displayName;
        }
        else
        {
            displayName = ItemDatabase.itemById[recipe.inputItemIds[this.myInputIndex]].displayName;
        }
    }

    public void OnClick()
    {
        CraftingClient.selectedInputIndex = this.myInputIndex;
        CraftingWindow.singleton.OnInputGroupSelected();
    }

    public void OnTooltip(bool show)
    {
        InventoryItem[] allocatedItems = CraftingClient.GetAllocatedItems(this.myInputIndex);
        BaseRecipeData recipe = CraftingClient.activeRequest.GetRecipe();
        if (!(show && (recipe != null)))
        {
            CraftingWindow.singleton.ShowTooltip(null, null);
        }
        else
        {
            bool flag;
            string str;
            StringBuilder quickText = GUtil.GetQuickText();
            this.GetDisplayName(out str, out flag);
            quickText.Append(flag ? "   Stock: " : "   Input: ");
            quickText.Append(str);
            for (int i = 0; i < allocatedItems.Length; i++)
            {
                if (!InventoryItem.EMPTY_MATCH(allocatedItems[i]))
                {
                    quickText.Append("\n");
                    quickText.Append(allocatedItems[i].quantity);
                    quickText.Append("x ");
                    InventoryClient.GetColoredItemDisplayName(ref quickText, allocatedItems[i]);
                }
            }
            CraftingWindow.singleton.ShowTooltip(quickText.ToString(), base.gameObject);
        }
    }

    public void SetData(int inputIndex, uint current, uint max)
    {
        if (this.countLabel == null)
        {
            this.countLabel = base.transform.FindChild("CountLabel").GetComponent<UILabel>();
        }
        this.myInputIndex = inputIndex;
        if (max > 0)
        {
            base.gameObject.name = this.myInputIndex.ToString();
            base.gameObject.SetActive(true);
        }
        else
        {
            base.gameObject.name = "ZZ_UNUSED";
            base.gameObject.SetActive(false);
        }
        this.countLabel.text = current.ToString() + "/" + max.ToString();
        this.countLabel.color = (current == max) ? SUFFICIENT : INSUFFICIENT;
    }
}

