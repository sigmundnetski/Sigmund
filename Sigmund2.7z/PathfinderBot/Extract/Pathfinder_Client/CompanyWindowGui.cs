﻿using GNGUI;
using System;
using UnityEngine;

public class CompanyWindowGui : WindowGui
{
    public static Color ACTIVE_TAB = new Color(0.9411765f, 0.8784314f, 0.6588235f);
    private Tabs activeTab = Tabs.DETAILS;
    public static ulong companyId = 0L;
    public static Color INACTIVE_TAB = new Color(0.4705882f, 0.4392157f, 0.3294118f);
    public static CompanyWindowGui singleton;
    private UILabel[] tabButtons = new UILabel[3];
    private CompanyWindowTabGui[] tabs = new CompanyWindowTabGui[3];

    public void AlliancesTabClicked(GameObject ignored)
    {
        this.OnTabChange(Tabs.ALLIANCES);
    }

    public void Awake()
    {
        singleton = this;
        this.OnAwake();
    }

    public void DetailsTabClicked(GameObject ignored)
    {
        this.OnTabChange(Tabs.DETAILS);
    }

    public void DisplayCompany(ulong companyId_)
    {
        companyId = companyId_;
        for (int i = 0; i < this.tabs.Length; i++)
        {
            this.tabs[i].DisplayCompany();
        }
    }

    public override void HideWindow()
    {
        base.HideWindow();
        this.tabs[(int) this.activeTab].HideTab();
    }

    public void HoldingsTabClicked(GameObject ignored)
    {
        this.OnTabChange(Tabs.HOLDINGS);
    }

    public bool LoadingTickFinished()
    {
        foreach (CompanyWindowTabGui gui in this.tabs)
        {
            gui.LoadingTickFinished();
        }
        return true;
    }

    public void OnAwake()
    {
        ClientTick.companyGuiLoadFinish = new GUtil.BoolFilterDelegate(this.LoadingTickFinished);
        ClientTick.companyGuiTick = new GUtil.BoolFilterDelegate(this.SyncFixedUpdate);
        foreach (UILabel label in base.GetComponentsInChildren<UILabel>())
        {
            if (label.name == "TabButtonDetails")
            {
                this.tabButtons[0] = label;
            }
            else if (label.name == "TabButtonHoldings")
            {
                this.tabButtons[1] = label;
            }
            else if (label.name == "TabButtonAlliances")
            {
                this.tabButtons[2] = label;
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find buttons.", this.tabButtons);
        UIEventListener listener1 = UIEventListener.Get(this.tabButtons[0].gameObject);
        listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.DetailsTabClicked));
        UIEventListener listener2 = UIEventListener.Get(this.tabButtons[1].gameObject);
        listener2.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener2.onClick, new UIEventListener.VoidDelegate(this.HoldingsTabClicked));
        UIEventListener listener3 = UIEventListener.Get(this.tabButtons[2].gameObject);
        listener3.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener3.onClick, new UIEventListener.VoidDelegate(this.AlliancesTabClicked));
        foreach (CompanyWindowTabGui gui in base.GetComponentsInChildren<CompanyWindowTabGui>())
        {
            string name = gui.name;
            if (name != null)
            {
                if (!(name == "Tab0Details"))
                {
                    if (name == "Tab1Holdings")
                    {
                        goto Label_01AF;
                    }
                    if (name == "Tab2Alliances")
                    {
                        goto Label_01BA;
                    }
                }
                else
                {
                    this.tabs[0] = gui;
                }
            }
            continue;
        Label_01AF:
            this.tabs[1] = gui;
            continue;
        Label_01BA:
            this.tabs[2] = gui;
        }
        GuiHelper.GuiAssertNotNull("Couldn't find any tabs.", this.tabs);
    }

    public override void OnDestroy()
    {
        base.OnDestroy();
        singleton = null;
    }

    private void OnTabChange(Tabs newTab)
    {
        if (this.activeTab != newTab)
        {
            this.activeTab = newTab;
            this.ShowTab();
        }
    }

    public void RefreshCompany()
    {
        if (!GroupClient.playerCompanyIds.Contains(companyId))
        {
            for (int i = 0; i < this.tabs.Length; i++)
            {
                this.tabs[i].RefreshCompany();
            }
        }
    }

    public void ShowTab()
    {
        for (int i = 0; i < this.tabs.Length; i++)
        {
            if (i == this.activeTab)
            {
                this.tabButtons[i].color = ACTIVE_TAB;
                this.tabs[i].ShowTab();
            }
            else
            {
                this.tabButtons[i].color = INACTIVE_TAB;
                this.tabs[i].HideTab();
            }
        }
    }

    public override void ShowWindow()
    {
        base.ShowWindow();
        this.ShowTab();
    }

    public void Start()
    {
        foreach (CompanyWindowTabGui gui in this.tabs)
        {
            gui.HideTab();
        }
        base.Init(2, true);
    }

    public bool SyncFixedUpdate()
    {
        foreach (CompanyWindowTabGui gui in this.tabs)
        {
            gui.SyncFixedUpdate();
        }
        return true;
    }

    public void ToggleWindowVis(string[] args, EntityId playerEntityId)
    {
        this.ToggleWindowVisibility();
    }

    public void UpdateCompany()
    {
        if (GroupClient.playerCompanyIds.Contains(companyId))
        {
            for (int i = 0; i < this.tabs.Length; i++)
            {
                this.tabs[i].UpdateCompany();
            }
        }
    }

    public enum Tabs
    {
        DETAILS,
        HOLDINGS,
        ALLIANCES,
        NUM_TABS
    }
}

