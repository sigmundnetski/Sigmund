﻿using GNGUI;
using System;
using System.Runtime.InteropServices;
using UnityEngine;

public class BankPopupGui : WindowGui
{
    public InputType currentType = InputType.NONE;
    private UILabel errorLabel;
    private const string POSTFIX_COPPER = "c";
    private const string POSTFIX_GOLD = "g";
    private const string POSTFIX_PLATINUM = "p";
    private const string POSTFIX_SILVER = "s";
    public static BankPopupGui singleton;
    private UIImageButton withdrawalButton;
    private UIInput withdrawalInput;

    public void Awake()
    {
        singleton = this;
        this.OnAwake();
    }

    public override void HideWindow()
    {
        this.errorLabel.text = string.Empty;
        base.HideWindow();
    }

    private void OnAwake()
    {
        base.disableAutoZ = true;
        foreach (UILabel label in base.GetComponentsInChildren<UILabel>())
        {
            if (label.name == "ErrorLabel")
            {
                this.errorLabel = label;
            }
        }
        foreach (UIInput input in base.GetComponentsInChildren<UIInput>())
        {
            if (input.name == "AmountInput")
            {
                this.withdrawalInput = input;
                this.withdrawalInput.onSubmit = (UIInput.OnSubmit) Delegate.Combine(this.withdrawalInput.onSubmit, new UIInput.OnSubmit(this.OnWithdrawalSubmit));
            }
        }
        foreach (UIImageButton button in base.GetComponentsInChildren<UIImageButton>())
        {
            if (button.name == "ButtonWithdrawal")
            {
                this.withdrawalButton = button;
                UIEventListener listener1 = UIEventListener.Get(this.withdrawalButton.gameObject);
                listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.OnWithdrawalClick));
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find required children.", new object[] { this.errorLabel, this.withdrawalButton, this.withdrawalInput });
        this.withdrawalInput.ClearText();
        base.Init(3, true);
    }

    public override void OnDestroy()
    {
        base.OnDestroy();
        singleton = null;
    }

    public void OnWithdrawalClick(GameObject ignored)
    {
        this.errorLabel.text = string.Empty;
        ulong price = 0L;
        if (!this.TryGetPrice(this.withdrawalInput.text, out price))
        {
            this.errorLabel.text = "Don't understand: '" + this.withdrawalInput.text + "'";
        }
        if (price != 0L)
        {
            BankWindowGui.singleton.Withdrawal(price);
        }
    }

    public void OnWithdrawalSubmit(string input)
    {
        ulong num;
        this.errorLabel.text = string.Empty;
        if (!this.TryGetPrice(input, out num))
        {
            this.errorLabel.text = "Don't understand: '" + input + "'";
        }
    }

    private bool TryGetPrice(string input, out ulong price)
    {
        price = 0L;
        ulong num = 0L;
        ulong num2 = 0L;
        ulong num3 = 0L;
        ulong num4 = 0L;
        string[] strArray = input.ToLower().Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
        if (strArray.Length == 0)
        {
            return false;
        }
        bool flag = true;
        for (int i = 0; i < strArray.Length; i++)
        {
            ulong num6;
            if (this.TryGetPriceDenomination(strArray[i], "p", out num6))
            {
                num += num6;
            }
            else if (this.TryGetPriceDenomination(strArray[i], "g", out num6))
            {
                num2 += num6;
            }
            else if (this.TryGetPriceDenomination(strArray[i], "s", out num6))
            {
                num3 += num6;
            }
            else if (this.TryGetPriceDenomination(strArray[i], "c", out num6))
            {
                num4 += num6;
            }
            else if (ulong.TryParse(strArray[i], out num6))
            {
                num4 += num6;
            }
            else
            {
                flag = false;
            }
        }
        price = (((num * ((ulong) 0xf4240L)) + (num2 * ((ulong) 0x2710L))) + (num3 * ((ulong) 100L))) + num4;
        return flag;
    }

    private bool TryGetPriceDenomination(string input, string denomination, out ulong price)
    {
        price = 0L;
        if (!input.EndsWith(denomination))
        {
            return false;
        }
        return ulong.TryParse(input.Substring(0, input.LastIndexOf(denomination)), out price);
    }

    public enum InputType
    {
        NONE,
        SELL,
        BUY,
        BID
    }
}

