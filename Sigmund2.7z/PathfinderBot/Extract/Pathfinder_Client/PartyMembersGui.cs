﻿using GNGUI;
using System;
using System.Collections.Generic;
using UnityEngine;

public class PartyMembersGui : MonoBehaviour
{
    private UIGrid grid;
    private List<PartyPlayerGui> gridItems = new List<PartyPlayerGui>();
    private GameObject memberPrefab;
    public static PartyMembersGui singleton;

    public void Awake()
    {
        singleton = this;
        this.OnAwake();
    }

    public void Hide()
    {
        NGUITools.SetActive(base.gameObject, false);
    }

    public bool IsShowing()
    {
        return NGUITools.GetActive(base.gameObject);
    }

    public bool LoadingTickFinished()
    {
        this.memberPrefab = UIClient.guiPrefabs["PartyPlayerGui"];
        this.grid = base.GetComponent<UIGrid>();
        GuiHelper.GuiAssertNotNull("Couldn't find prefab or grid.", new object[] { this.memberPrefab, this.grid });
        return true;
    }

    private void OnAwake()
    {
        ClientTick.partyGuiLoadFinish = new GUtil.BoolFilterDelegate(this.LoadingTickFinished);
        ClientTick.partyGuiTick = new GUtil.BoolFilterDelegate(this.SyncFixedUpdate);
    }

    public void OnDestroy()
    {
        singleton = null;
    }

    public void Show()
    {
        NGUITools.SetActive(base.gameObject, true);
    }

    public bool SyncFixedUpdate()
    {
        if (GroupClient.activeParty != null)
        {
            this.UpdateMembers(GroupClient.activeParty);
        }
        else if (this.gridItems.Count > 0)
        {
            this.TrimGridItems(0);
        }
        return true;
    }

    private void TrimGridItems(int size)
    {
        while (this.gridItems.Count > size)
        {
            PartyPlayerGui gui = this.gridItems[this.gridItems.Count - 1];
            this.gridItems.RemoveAt(this.gridItems.Count - 1);
            gui.gameObject.SetActive(false);
            gui.transform.parent = DragDropRoot.root;
            UnityEngine.Object.Destroy(gui.gameObject);
        }
        this.grid.repositionNow = true;
    }

    public void UpdateMembers(Party party)
    {
        int size = 0;
        Party.PartyMember[] orderedMembers = party.orderedMembers;
        for (int i = 0; i < orderedMembers.Length; i++)
        {
            if ((orderedMembers[i] != null) && (orderedMembers[i].playerId != EntityDataClient.owner.playerId))
            {
                if (size >= this.gridItems.Count)
                {
                    GameObject go = NGUITools.AddChild(base.gameObject, this.memberPrefab);
                    PartyPlayerGui component = go.GetComponent<PartyPlayerGui>();
                    UIEventListener listener1 = UIEventListener.Get(go);
                    listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(component.DoTarget));
                    this.gridItems.Add(component);
                }
                this.gridItems[size].SyncFixedUpdate(orderedMembers[i].playerId, orderedMembers[i].name, party.IsOwner(orderedMembers[i]));
                size++;
            }
        }
        this.TrimGridItems(size);
    }
}

