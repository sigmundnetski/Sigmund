﻿using System;
using UnityEngine;

[RequireComponent(typeof(ParticleSystem))]
public class FxScaleLifetime : MonoBehaviour
{
    private float origParticleLifetime;
    private ParticleSystem particleCmp;

    private void ScaleFx(float dist)
    {
        if (this.particleCmp == null)
        {
            this.particleCmp = base.GetComponent<ParticleSystem>();
            this.origParticleLifetime = this.particleCmp.startLifetime;
        }
        this.particleCmp.startLifetime = (this.origParticleLifetime * dist) / 50f;
    }
}

