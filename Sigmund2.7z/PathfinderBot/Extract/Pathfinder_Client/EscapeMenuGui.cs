﻿using GNGUI;
using System;
using UnityEngine;

public class EscapeMenuGui : MonoBehaviour
{
    public static EscapeMenuGui singleton;

    public void AboutClicked(GameObject go)
    {
        AboutWindowGui.singleton.ToggleWindowVisibility();
    }

    public void Awake()
    {
        singleton = this;
    }

    public void HelpClicked(GameObject go)
    {
        HelpWindowGui.singleton.ToggleWindowVisibility();
    }

    public void HideWindow()
    {
        NGUITools.SetActive(base.gameObject, false);
    }

    public bool IsShowing()
    {
        return NGUITools.GetActive(base.gameObject);
    }

    public void LogOutClicked(GameObject go)
    {
        UIClient.LogOut(UIClient.DisconnectType.LOG_OUT);
    }

    public void OnDestroy()
    {
        singleton = null;
    }

    public void QuitClicked(GameObject go)
    {
        UIClient.LogOut(UIClient.DisconnectType.QUIT);
    }

    public void SettingsClicked(GameObject go)
    {
        SettingsWindowGui.singleton.ToggleWindowVisibility();
    }

    public void ShowWindow()
    {
        NGUITools.SetActive(base.gameObject, true);
    }

    public void Start()
    {
        GameObject gameObject = base.transform.Find("MenuItems/LogOut").gameObject;
        UIEventListener listener1 = UIEventListener.Get(gameObject);
        listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.LogOutClicked));
        if (!GUtil.internalMode)
        {
            NGUITools.SetActive(gameObject, false);
        }
        UIEventListener listener2 = UIEventListener.Get(base.transform.Find("MenuItems/Quit").gameObject);
        listener2.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener2.onClick, new UIEventListener.VoidDelegate(this.QuitClicked));
        UIEventListener listener3 = UIEventListener.Get(base.transform.Find("MenuItems/Help").gameObject);
        listener3.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener3.onClick, new UIEventListener.VoidDelegate(this.HelpClicked));
        UIEventListener listener4 = UIEventListener.Get(base.transform.Find("MenuItems/SubmitBug").gameObject);
        listener4.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener4.onClick, new UIEventListener.VoidDelegate(this.SubmitBugClicked));
        UIEventListener listener5 = UIEventListener.Get(base.transform.Find("MenuItems/Settings").gameObject);
        listener5.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener5.onClick, new UIEventListener.VoidDelegate(this.SettingsClicked));
        UIEventListener listener6 = UIEventListener.Get(base.transform.Find("MenuItems/About").gameObject);
        listener6.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener6.onClick, new UIEventListener.VoidDelegate(this.AboutClicked));
        this.HideWindow();
    }

    public void SubmitBugClicked(GameObject go)
    {
        BugReportGui.singleton.ToggleWindowVisibility();
    }
}

