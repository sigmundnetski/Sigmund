﻿using GNGUI;
using System;
using System.Runtime.InteropServices;
using UnityEngine;

public class ContextInvokerGui : MonoBehaviour
{
    private int desiredClickId;
    public ContextWindowGui menuToInvoke;
    public int referenceId;

    public void Init(int referenceId_, ContextWindowGui menuToInvoke_, NguiMouse desiredClick = -2)
    {
        this.referenceId = referenceId_;
        this.menuToInvoke = menuToInvoke_;
        this.desiredClickId = (int) desiredClick;
        this.menuToInvoke.RegisterInvoker(base.gameObject);
    }

    public void OnClick()
    {
        if ((this.menuToInvoke != null) && (UICamera.currentTouchID == this.desiredClickId))
        {
            this.menuToInvoke.Invoke(this.referenceId);
        }
    }

    public enum NguiMouse
    {
        LEFT = -1,
        MIDDLE = -3,
        RIGHT = -2
    }
}

