﻿using GNetwork;
using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

public class ClientInputManager : MonoBehaviour
{
    private bool autorun = false;
    public float autorunForwardAxis = 0f;
    public float autorunRotationAxis = 0f;
    public float autorunStrafeAxis = 0f;
    private float dragMagnitude = 0f;
    public float forwardAxis = 0f;
    private bool ignoreEnter = false;
    private static bool initialized = false;
    private Vector2 lastMousePos = Vector2.zero;
    private static bool loadingFinished = false;
    private const float MOUSE_DRAG_THRESHOLD = 4f;
    public Vector2 mouseAxis = Vector2.zero;
    public float mouseScroll = 0f;
    private bool[] nonCommandInput = new bool[12];
    public float rotationAxis = 0f;
    public static ClientInputManager singleton;
    public float strafeAxis = 0f;
    private Vector2 totalDelta = Vector2.zero;

    protected void ActOnInput()
    {
        this.ResetNonCommandInput();
        InputManager.ProcessAllCommands();
        this.mouseAxis.x = Input.GetAxis("Mouse X");
        this.mouseAxis.y = Input.GetAxis("Mouse Y");
        this.mouseScroll = Input.GetAxis("Mouse ScrollWheel");
        if (!this.ignoreEnter)
        {
            if (this.nonCommandInput[8])
            {
                InputManager.chatFlag = true;
            }
            if (this.nonCommandInput[9] && InputManager.chatFlag)
            {
                ChatGui.singleton.GiveInputFocus();
                InputManager.chatFlag = false;
            }
        }
        else
        {
            this.ignoreEnter = false;
        }
        if (this.nonCommandInput[10])
        {
            InputManager.debugFlag = true;
        }
        if (this.nonCommandInput[11] && InputManager.debugFlag)
        {
            DebugGui.singleton.GiveInputFocus();
            InputManager.debugFlag = false;
        }
        this.ProcessMovementInput();
        if (EntityMotion.singleton != null)
        {
            EntityMotion.singleton.SetSteering(this.forwardAxis, this.rotationAxis);
            EntityMotion.singleton.SetStrafe(this.strafeAxis);
        }
    }

    protected void ActOnUIFocus()
    {
        this.forwardAxis = 0f;
        this.rotationAxis = 0f;
        this.strafeAxis = 0f;
        this.mouseAxis = Vector2.zero;
        this.mouseScroll = 0f;
        this.ProcessAutorun();
        if (EntityMotion.singleton != null)
        {
            EntityMotion.singleton.SetSteering(this.forwardAxis, this.rotationAxis);
            EntityMotion.singleton.SetStrafe(this.strafeAxis);
        }
        InputManager.chatFlag = false;
        InputManager.debugFlag = false;
    }

    protected void AddScripts()
    {
        if (DebugGui.singleton != null)
        {
            DebugGui.singleton.ignoreEnterCallback = new DebugGui.IgnoreEnterCallback(this.IgnoreEnter);
        }
        if (ChatGui.singleton != null)
        {
            ChatGui.singleton.ignoreEnterCallback = new ChatGui.IgnoreEnterCallback(this.IgnoreEnter);
        }
    }

    public void Awake()
    {
        singleton = this;
        if (base.GetComponent<UICamera>() == null)
        {
            throw new MissingComponentException(string.Concat(new object[] { base.GetType(), " on '", base.name, "' requires UICamera component! See this class's summary for details." }));
        }
    }

    public void CancelAutorun()
    {
        this.autorun = false;
    }

    public void CommandEvent(string[] args, EntityId playerEntityId)
    {
        this.autorun = !this.autorun;
        this.autorunForwardAxis = 1f;
        this.autorunStrafeAxis = this.strafeAxis;
        this.autorunRotationAxis = this.rotationAxis;
    }

    public void EscapeCommandEvent(string[] args, EntityId playerEntityId)
    {
        if (EscapeMenuGui.singleton.IsShowing())
        {
            EscapeMenuGui.singleton.HideWindow();
        }
        else if (!WindowGuiUtils.CloseTopWindow())
        {
            if (Targeting.selectedTarget != null)
            {
                Targeting.CommandEvent(args, playerEntityId);
            }
            else
            {
                EscapeMenuGui.singleton.ShowWindow();
            }
        }
    }

    public static void ExportKeybinds(string[] args, EntityId playerEntityId)
    {
        string str = args[0];
        if (!CommandCore.RemoveCommandFromString(ref str))
        {
            str = InputManager.LOCAL_KEYBIND_DIR + InputManager.KEYBIND_FILE;
        }
        else if (!Path.IsPathRooted(str))
        {
            str = InputManager.LOCAL_KEYBIND_DIR + str;
        }
        if (!str.ToLower().EndsWith(".ini"))
        {
            str = str + ".ini";
        }
        string directoryName = Path.GetDirectoryName(str);
        if ((directoryName == Path.GetDirectoryName(InputManager.LOCAL_KEYBIND_DIR)) && !Directory.Exists(directoryName))
        {
            try
            {
                Directory.CreateDirectory(directoryName);
            }
            catch (Exception)
            {
                DebugClient.DisplayDebugMessage("Could not create folder '" + directoryName + "' to export keybinds to.");
                throw;
            }
        }
        if (!(!string.IsNullOrEmpty(directoryName) && Directory.Exists(directoryName)))
        {
            DebugClient.DisplayDebugMessage("Could not find folder '" + directoryName + "' to export keybinds to.");
        }
        else
        {
            InputManager.WriteKeybinds(str);
            DebugClient.DisplayDebugMessage("Keybinds written: '" + str + "'.");
        }
    }

    public void IgnoreEnter()
    {
        this.ignoreEnter = true;
    }

    public static void ImportKeybinds(string[] args, EntityId playerEntityId)
    {
        string str = args[0];
        if (!CommandCore.RemoveCommandFromString(ref str))
        {
            str = InputManager.LOCAL_KEYBIND_DIR + InputManager.KEYBIND_FILE;
        }
        else if (str == "default")
        {
            str = InputManager.FALLBACK_KEYBIND_DIR + InputManager.FALLBACK_KEYBIND_FILE;
        }
        else if (!Path.IsPathRooted(str))
        {
            str = InputManager.LOCAL_KEYBIND_DIR + str;
        }
        if (!str.ToLower().EndsWith(".ini"))
        {
            str = str + ".ini";
        }
        if (!File.Exists(str))
        {
            DebugClient.DisplayDebugMessage("Could not find file '" + str + "'.");
        }
        else
        {
            InputManager.UpdateKeybinds(str);
            DebugClient.DisplayDebugMessage("Keybinds loaded: '" + str + "'.");
            GRouting.SendMyMapRpc(GRpcID.PlayerEntityServer_UpdatePlayerKeybinds, new object[] { InputManager.KeybindsToString() });
        }
    }

    private void Init()
    {
        InputManager.LoadingTickFinished(base.gameObject);
        this.AddScripts();
        initialized = true;
    }

    public void InputHappened(InputManager.InputEvent inputEvent)
    {
        switch (inputEvent.command)
        {
            case "forward":
                this.nonCommandInput[0] = true;
                break;

            case "back":
                this.nonCommandInput[1] = true;
                break;

            case "turnleft":
                this.nonCommandInput[2] = true;
                break;

            case "turnright":
                this.nonCommandInput[3] = true;
                break;

            case "strafeleft":
                this.nonCommandInput[4] = true;
                break;

            case "straferight":
                this.nonCommandInput[5] = true;
                break;

            case "mouselook":
                this.nonCommandInput[6] = true;
                break;

            case "freelook":
                this.nonCommandInput[7] = true;
                break;

            case "chat":
                if (inputEvent.inputType != InputManager.InputType.DOWN_EDGE)
                {
                    this.nonCommandInput[9] = true;
                    break;
                }
                this.nonCommandInput[8] = true;
                break;

            case "debugconsole":
                if (inputEvent.inputType != InputManager.InputType.DOWN_EDGE)
                {
                    this.nonCommandInput[11] = true;
                    break;
                }
                this.nonCommandInput[10] = true;
                break;
        }
    }

    private bool IsOverDragThreshold()
    {
        return (this.dragMagnitude > 4f);
    }

    public static bool LoadingTickFinished()
    {
        loadingFinished = true;
        return true;
    }

    public void OnDestroy()
    {
        InputManager.Reset();
        singleton = null;
    }

    private void ProcessAutorun()
    {
        if (this.autorun)
        {
            bool flag = false;
            this.forwardAxis = this.autorunForwardAxis;
            flag = true;
            flag = true;
        }
    }

    public void ProcessMovementInput()
    {
        bool mouseLooking = this.nonCommandInput[6];
        bool freeLooking = this.nonCommandInput[7];
        if (mouseLooking || freeLooking)
        {
            this.totalDelta += InputManager.mousePosition - this.lastMousePos;
            this.dragMagnitude = this.totalDelta.magnitude;
        }
        else
        {
            this.dragMagnitude = 0f;
            this.totalDelta = Vector2.zero;
        }
        if (mouseLooking)
        {
            this.strafeAxis = this.nonCommandInput[5] ? 1f : 0f;
            this.strafeAxis += this.nonCommandInput[4] ? -1f : 0f;
            this.strafeAxis += this.nonCommandInput[3] ? 1f : 0f;
            this.strafeAxis += this.nonCommandInput[2] ? -1f : 0f;
            this.strafeAxis = Mathf.Clamp(this.strafeAxis, -1f, 1f);
            this.rotationAxis = 0f;
        }
        else
        {
            this.rotationAxis = this.nonCommandInput[3] ? 1f : 0f;
            this.rotationAxis += this.nonCommandInput[2] ? -1f : 0f;
            this.strafeAxis = this.nonCommandInput[5] ? 1f : 0f;
            this.strafeAxis += this.nonCommandInput[4] ? -1f : 0f;
        }
        this.forwardAxis = this.nonCommandInput[0] ? 1f : 0f;
        this.forwardAxis += this.nonCommandInput[1] ? -1f : 0f;
        CustomCamera.singleton.KeybindEvents(mouseLooking, freeLooking, this.IsOverDragThreshold());
        if (this.autorun && (this.forwardAxis < 0f))
        {
            this.autorun = false;
        }
        this.ProcessAutorun();
    }

    public void ResetNonCommandInput()
    {
        for (int i = 0; i < 12; i++)
        {
            this.nonCommandInput[i] = false;
        }
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void SetPlayerKeybinds(string keybinds)
    {
        InputManager.keybindOverride = keybinds;
    }

    public void Start()
    {
        ClientTick.inputTick = new GUtil.BoolFilterDelegate(this.SyncUpdate);
        InputManager.inputCallback = new InputManager.InputHappened(this.InputHappened);
        if (loadingFinished)
        {
            this.Init();
        }
    }

    public bool SyncUpdate()
    {
        if (!(initialized || !loadingFinished))
        {
            this.Init();
        }
        InputManager.mousePosition = Input.mousePosition;
        InputManager.UpdateModifierKeys();
        if (InputManager.IsUIFocused())
        {
            this.ActOnUIFocus();
            this.dragMagnitude = 0f;
            this.totalDelta = Vector2.zero;
        }
        else
        {
            this.ActOnInput();
        }
        this.lastMousePos = InputManager.mousePosition;
        return true;
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void UpdatePlayerKeybindsReply(string unknownCommandsCsv)
    {
        string[] strArray = unknownCommandsCsv.Split(new char[] { ',' });
        List<string> list = new List<string>();
        foreach (string str in strArray)
        {
            if (!(CommandCore.IsCommandCallable(str, EntityDataClient.owner.entityId) || InputManager.nonStandardCommands.ContainsKey(str)))
            {
                list.Add(str);
            }
        }
        int count = list.Count;
        if (count != 0)
        {
            string msg = "Unknown commands in your keybinds:\n";
            for (int i = 0; i < count; i++)
            {
                msg = msg + "  " + list[i];
                if (i < (count - 1))
                {
                    msg = msg + "\n";
                }
            }
            GLog.LogError(new object[] { "Unknown commands in your keybinds:", list });
            DebugClient.DisplayDebugMessage(msg);
        }
    }

    public enum NonCommand
    {
        FORWARD,
        BACK,
        TURN_LEFT,
        TURN_RIGHT,
        STRAFE_LEFT,
        STRAFE_RIGHT,
        MOUSELOOK,
        FREELOOK,
        CHAT_DOWN,
        CHAT_UP,
        DEBUG_DOWN,
        DEBUG_UP,
        NUM_NON_COMMANDS
    }
}

