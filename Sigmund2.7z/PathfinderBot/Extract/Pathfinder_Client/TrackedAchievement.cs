﻿using System;

internal class TrackedAchievement : ITrackerElement
{
    public readonly GenericAchievementData achievementData;
    public readonly float timestamp = 0f;
    public readonly bool userPinned = false;

    public TrackedAchievement(GenericAchievementData _data, float _time, bool _userPinned)
    {
        this.achievementData = _data;
        this.timestamp = _time;
        this.userPinned = _userPinned;
    }

    public string GetBody()
    {
        return AdvancementClient.GetBody(null, this.achievementData);
    }

    public string GetHoverText()
    {
        return AdvancementClient.GetHoverText(null, this.achievementData);
    }

    public string GetName()
    {
        return string.Concat(new object[] { this.achievementData.displayName, " Level: ", this.achievementData.level, "/", MergedAchievementData.GetMaxLevel(this.achievementData.slotId) });
    }

    public void OnClick()
    {
    }
}

