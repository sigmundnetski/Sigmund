﻿using GNetwork;
using System;
using UnityEngine;

public class ClientLoginTick : Ticker.TickBase
{
    private static GUtil.BoolFilterDelegate bundleTick = new GUtil.BoolFilterDelegate(BundleService.SyncFixedUpdate);
    public static GUtil.BoolFilterDelegate loginGuiLoadFinished = null;
    private static GUtil.BoolFilterDelegate networkTick = new GUtil.BoolFilterDelegate(GNetworkService.SyncFixedUpdate);
    private static GUtil.BoolFilterDelegate resourceLoad = new GUtil.BoolFilterDelegate(ResourceManager.LoadingTick);
    private static GUtil.BoolFilterDelegate sceneTick = new GUtil.BoolFilterDelegate(SceneService.SyncFixedUpdate);
    private static GUtil.BoolFilterDelegate staticDataLoad = new GUtil.BoolFilterDelegate(StaticDataService.LoadingTick);
    public static GUtil.BoolFilterDelegate staticDataShutdown = new GUtil.BoolFilterDelegate(StaticDataService.Shutdown);
    private static GUtil.BoolFilterDelegate staticDataTick = new GUtil.BoolFilterDelegate(StaticDataService.SyncFixedUpdate);

    public ClientLoginTick()
    {
        base.fixedUpdateFunctions.Add(new Ticker.FixedUpdateTickFunction(this.Unittest));
        base.fixedUpdateFunctions.Add(new Ticker.FixedUpdateTickFunction(this.StartServices));
        base.fixedUpdateFunctions.Add(new Ticker.FixedUpdateTickFunction(this.LoadingTick));
        base.fixedUpdateFunctions.Add(new Ticker.FixedUpdateTickFunction(this.LoadingTickFinished));
        base.fixedUpdateFunctions.Add(new Ticker.FixedUpdateTickFunction(this.SyncFixedUpdate));
        if (!(!Application.isEditor || ResourceManager.SERVER_MODE))
        {
            GLog.Log(new object[] { "Unity Editor Detected, running textures in server mode." });
            ResourceManager.SERVER_MODE = true;
        }
    }

    private bool LoadingTick()
    {
        bool flag = true;
        flag = GUtil.FilterExceptions(staticDataLoad, "StaticDataService.LoadingTick") && flag;
        flag = GUtil.FilterExceptions(resourceLoad, "ResourceManager.LoadingTick") && flag;
        flag = GUtil.FilterExceptions(bundleTick, "BundleService.SyncFixedUpdate") && flag;
        flag = GUtil.FilterExceptions(sceneTick, "SceneService.SyncFixedUpdate") && flag;
        return ((ClientLoginGui.singleton != null) && flag);
    }

    private bool LoadingTickFinished()
    {
        GUtil.FilterExceptions(loginGuiLoadFinished, "ClientLoginGui.singleton.LoadingTickFinished");
        return true;
    }

    protected override void OnTickDestroyed()
    {
        GUtil.FilterExceptions(staticDataShutdown, "StaticDataService.Shutdown");
    }

    private bool StartServices()
    {
        ServiceList.StartOnce(typeof(StaticDataService), new object[] { true });
        ServiceList.StartOnce(typeof(BundleService), new object[0]);
        ServiceList.StartOnce(typeof(GNetworkService), new object[0]);
        return true;
    }

    private bool SyncFixedUpdate()
    {
        GUtil.FilterExceptions(staticDataTick, "StaticDataService.SyncFixedUpdate");
        GUtil.FilterExceptions(bundleTick, "BundleService.SyncFixedUpdate");
        GUtil.FilterExceptions(sceneTick, "SceneService.SyncFixedUpdate");
        GUtil.FilterExceptions(networkTick, "GNetworkService.SyncFixedUpdate");
        return false;
    }

    private bool Unittest()
    {
        bool flag = false;
        string[] commandLineArgs = Environment.GetCommandLineArgs();
        foreach (string str in commandLineArgs)
        {
            if (str.Contains("-unittest"))
            {
                flag = true;
            }
        }
        if (flag)
        {
            UUnitTestSuite suite = new UUnitTestSuite();
            suite.FindAndAddAllTestCases<UUnitTestMethod>(null);
            UUnitTestResult result = suite.RunAll();
            foreach (string str2 in result.Summary())
            {
                if (str2.Contains("succeeded"))
                {
                    Debug.Log(str2);
                }
                else
                {
                    Debug.LogError(str2);
                }
            }
        }
        return true;
    }
}

