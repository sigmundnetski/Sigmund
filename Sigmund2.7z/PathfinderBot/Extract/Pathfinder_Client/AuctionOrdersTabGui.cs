﻿using System;
using System.Collections.Generic;

public class AuctionOrdersTabGui : AuctionOrdersBidsTabGui
{
    public override void Awake()
    {
        base.Awake();
        base.offerType = ItemOffer.OfferType.OFFER;
    }

    protected override List<ItemOffer> GetItems()
    {
        return AuctionHouseGui.singleton.currentOrderItems;
    }
}

