﻿using GNetwork;
using System;
using System.Collections.Generic;
using UnityEngine;

public static class PlayerEntityClient
{
    private static DateTime lastUpdateTime;
    private static bool pendingRepopulate = false;
    private static GameObject playerGO = null;
    public static Transform playerParent = null;
    private static Transform playerXform = null;

    public static void AssignPlayerEntity(GameObject newPlayerGO, EntityId newEntityId, int entityDefnId, string name)
    {
        playerGO = newPlayerGO;
        playerXform = playerGO.transform;
        ResourceManager.referenceXform = playerXform;
        EntityCore.MoveToLayer(playerXform, 2);
        EntityMotion component = playerGO.GetComponent<EntityMotion>();
        CombatClient.entityMotion = component;
        component.movementChanged = new BaseMotion.MovementChanged(PlayerEntityClient.MovementChanged);
        playerGO.GetComponent<EntityVars>().AssignEntityVars(newEntityId, entityDefnId, name);
        if (PlayerBarGui.singleton != null)
        {
            PlayerBarGui.singleton.NewPlayerGameObject(playerGO);
        }
    }

    private static void Client_SendTickRPC()
    {
        if ((playerGO != null) && (NetworkClient.serverConnection != null))
        {
            ushort calculateCurrentMapId = TerrainService.CalculateCurrentMapId;
            GRouting.SendMyMapRpc(GRpcID.PlayerEntityServer_ReceiveMovement, new object[] { Time.time, TerrainService.TranslateLocalToServer(calculateCurrentMapId, playerXform.position), playerXform.rotation, 0, calculateCurrentMapId });
        }
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void ForcePosition(ushort mapId, Vector3 position, Quaternion rotation)
    {
        GameObject player = GetPlayer();
        if (player != null)
        {
            player.GetComponent<EntityMotion>().Teleport(TerrainService.TranslateServerToLocal(mapId, position), rotation);
        }
    }

    public static GameObject GetPlayer()
    {
        return playerGO;
    }

    public static EntityId GetPlayerEntityId()
    {
        if (EntityDataClient.owner != null)
        {
            return EntityDataClient.owner.entityId;
        }
        return EntityId.INVALID_ID;
    }

    public static Transform GetPlayerTransform()
    {
        return playerXform;
    }

    public static void InitializePlayerEntity(Entity playerEntity)
    {
        EntityClient.UpdateEquipment(playerEntity);
        IEnumerable<EquipmentAsset> allEquippedAssets = InventoryClient.GetAllEquippedAssets(playerEntity.gear.equippedGear, playerEntity.entityDefnId);
        playerGO = EntityLoadClient.CreateCompleteCharacter(playerEntity, allEquippedAssets, GConst.CreateType.PLAYER, playerParent, playerEntity.GetLocalPosition(), playerEntity.rotation, playerEntity.entityName);
        AssignPlayerEntity(playerGO, playerEntity.entityId, playerEntity.entityDefnId, playerEntity.entityName);
        playerEntity.gameObject = playerGO;
        playerEntity.Initialize();
        EntityLoadClient.UpdateWeaponTypes(playerEntity);
    }

    public static bool LoadingTick()
    {
        if (playerParent == null)
        {
            GameObject obj2 = GameObject.Find("/Programming/SelfParent");
            playerParent = (obj2 != null) ? obj2.transform : null;
        }
        return (playerParent != null);
    }

    public static void MovementChanged(GameObject entityGO, Movement.MovementType moveType)
    {
        if (((playerGO != null) && (entityGO == playerGO)) && (NetworkClient.serverConnection != null))
        {
            ushort calculateCurrentMapId = TerrainService.CalculateCurrentMapId;
            GRouting.SendMyMapRpc(GRpcID.PlayerEntityServer_ReceiveMovement, new object[] { Time.time, TerrainService.TranslateLocalToServer(calculateCurrentMapId, playerXform.position), playerXform.rotation, (int) moveType, calculateCurrentMapId });
        }
    }

    public static void OnClientEntityUpdate(Entity entity)
    {
        if ((entity == EntityDataClient.owner) && ((((pendingRepopulate && (AchievementsWindowGui.singleton != null)) && ((EventBarGui.singleton != null) && (EntityDataClient.owner != null))) && (EntityDataClient.owner.combat != null)) && (ButtonBarGui.singleton != null)))
        {
            ButtonBarGui.singleton.SetAllButtons(EntityDataClient.owner.combat);
        }
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void OnHotbarUpdate()
    {
        pendingRepopulate = true;
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void Sayonara(ushort mapId)
    {
        EntityDataClient.OnSayonara(mapId);
        EncounterClient.OnSayonara(mapId);
        TerrainClient.OnSayonara(mapId);
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void SetClientMapId(ushort mapId)
    {
        TerrainClient.UpdateCurrentMap(mapId);
        MapClient.OnMapTransfer(mapId);
        ChatClient.OnMapTransfer(mapId);
    }

    public static bool SyncFixedUpdate()
    {
        DateTime utcNow = DateTime.UtcNow;
        if ((lastUpdateTime + GConst.MOVEMENT_SYNC_DELTA) < utcNow)
        {
            Client_SendTickRPC();
            lastUpdateTime = utcNow;
        }
        return true;
    }
}

