﻿using System;
using UnityEngine;

public class FxRayTester : MonoBehaviour
{
    public float distance;

    private void Start()
    {
        this.distance = 50f;
    }

    private void Update()
    {
        base.transform.localScale = new Vector3(1f, 1f, this.distance / 50f);
        base.gameObject.BroadcastMessage("ScaleFx", this.distance);
    }
}

