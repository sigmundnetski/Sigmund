﻿using GNGUI;
using System;
using UnityEngine;

public class TextButton : MonoBehaviour
{
    public Color clickColor = new Color(0.9764706f, 0.9568627f, 0.7686275f);
    public Color hoverColor = new Color(1f, 0.7803922f, 0.427451f);
    private bool hovering = false;
    private UILabel label;
    public Color normalColor = new Color(0.9411765f, 0.8901961f, 0.6588235f);

    public void Awake()
    {
        this.label = base.GetComponent<UILabel>();
        if (this.label == null)
        {
            this.label = base.GetComponentInChildren<UILabel>();
        }
        GuiHelper.GuiAssertNotNull(base.gameObject.name + ": Couldn't find label on self or children.", new object[] { this.label });
    }

    public void OnHover(bool isOver)
    {
        if (isOver)
        {
            this.label.color = this.hoverColor;
        }
        else
        {
            this.label.color = this.normalColor;
        }
        this.hovering = isOver;
    }

    public void OnPress(bool isDown)
    {
        if (isDown)
        {
            this.label.color = this.clickColor;
        }
        else if (this.hovering)
        {
            this.label.color = this.hoverColor;
        }
        else
        {
            this.label.color = this.normalColor;
        }
    }
}

