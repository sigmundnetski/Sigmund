﻿using GNGUI;
using System;
using UnityEngine;

public class HidablePanelGui : MonoBehaviour
{
    protected UIImageButton closeButton;
    private ImageButtonSprites[] closeButtonImages = new ImageButtonSprites[2];
    protected string closeButtonName = "CloseButton";
    protected bool userHidingPanel = false;
    protected bool userShowingPanel = false;

    protected void AlwaysShow(GameObject go)
    {
        go.transform.parent = base.gameObject.transform.parent;
        go.transform.BroadcastMessage("CheckParent", SendMessageOptions.DontRequireReceiver);
    }

    protected void ButtonImageSets(ImageButtonSprites showPanel, ImageButtonSprites hidePanel)
    {
        this.closeButtonImages[0] = showPanel;
        this.closeButtonImages[1] = hidePanel;
    }

    public virtual void CloseClicked(GameObject go)
    {
        this.UserTogglePanel();
    }

    public virtual void CommandEvent(string[] args, EntityId playerEntityId)
    {
        this.UserTogglePanel();
    }

    public virtual void HidePanel()
    {
        if (this.closeButtonImages[0] != null)
        {
            this.SetButton(this.closeButtonImages[0]);
        }
        NGUITools.SetActive(base.gameObject, false);
    }

    public bool IsShowing()
    {
        return NGUITools.GetActive(base.gameObject);
    }

    private void SetButton(ImageButtonSprites sprites)
    {
        this.closeButton.normalSprite = sprites.normal;
        this.closeButton.hoverSprite = sprites.hover;
        this.closeButton.pressedSprite = sprites.pressed;
    }

    public virtual void ShowPanel()
    {
        if (this.closeButtonImages[1] != null)
        {
            this.SetButton(this.closeButtonImages[1]);
        }
        NGUITools.SetActive(base.gameObject, true);
    }

    public virtual void Start()
    {
        foreach (UIImageButton button in base.GetComponentsInChildren<UIImageButton>())
        {
            if (button.name == this.closeButtonName)
            {
                this.closeButton = button;
            }
        }
        GuiHelper.GuiAssertNotNull(base.gameObject.name + " could not find needed child objects.", new object[] { this.closeButton });
        UIEventListener listener1 = UIEventListener.Get(this.closeButton.gameObject);
        listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.CloseClicked));
    }

    public virtual void TogglePanel()
    {
        if (this.IsShowing())
        {
            this.HidePanel();
        }
        else
        {
            this.ShowPanel();
        }
    }

    public virtual void UserTogglePanel()
    {
        if (this.IsShowing())
        {
            this.HidePanel();
            this.userHidingPanel = true;
        }
        else
        {
            this.ShowPanel();
            this.userShowingPanel = true;
        }
    }

    protected enum ButtonState
    {
        SHOW_PANEL,
        HIDE_PANEL,
        NUM_STATES
    }

    protected class ImageButtonSprites
    {
        public string hover;
        public string normal;
        public string pressed;

        public ImageButtonSprites(string normal_, string hover_, string pressed_)
        {
            this.normal = normal_;
            this.hover = hover_;
            this.pressed = pressed_;
        }
    }
}

