﻿using GNGUI;
using System;
using UnityEngine;

public class EventBarItem : MonoBehaviour
{
    private UILabel eventDetailsLabel;
    private UILabel eventLabel;
    private ITrackerElement info = null;

    private void Awake()
    {
        this.eventLabel = base.transform.Find("EventName").GetComponent<UILabel>();
        this.eventDetailsLabel = base.transform.Find("EventDetails").GetComponent<UILabel>();
        GuiHelper.GuiAssertNotNull("Could not find needed components!", new object[] { this.eventLabel });
        this.eventLabel.text = string.Empty;
        this.eventDetailsLabel.text = string.Empty;
    }

    public void OnClick()
    {
        this.info.OnClick();
    }

    public void OnTooltip(bool show)
    {
        if ((show && (EventBarGui.singleton != null)) && EventBarGui.singleton.IsShowing())
        {
            string hoverText = this.info.GetHoverText();
            if (!string.IsNullOrEmpty(hoverText))
            {
                UITooltip.ShowText(hoverText, base.gameObject);
                return;
            }
        }
        UITooltip.ShowText(null, null);
    }

    public void UpdateText(ITrackerElement _info)
    {
        this.info = _info;
        this.eventLabel.text = this.info.GetName();
        this.eventDetailsLabel.text = this.info.GetBody();
    }
}

