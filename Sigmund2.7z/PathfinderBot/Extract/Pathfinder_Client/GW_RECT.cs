﻿using System;
using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Sequential)]
public struct GW_RECT
{
    public readonly ushort left;
    public readonly ushort top;
    public readonly ushort width;
    public readonly ushort height;
    public static readonly GW_RECT Zero;
    public GW_RECT(ushort _left, ushort _top, ushort _width, ushort _height)
    {
        this.left = _left;
        this.top = _top;
        this.width = _width;
        this.height = _height;
    }

    public override string ToString()
    {
        return string.Concat(new object[] { "[", this.left, ", ", this.top, ", ", this.width, ", ", this.height, "]" });
    }

    static GW_RECT()
    {
        Zero = new GW_RECT(0, 0, 0, 0);
    }
}

