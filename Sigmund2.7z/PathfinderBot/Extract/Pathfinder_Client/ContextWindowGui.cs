﻿using GNGUI;
using System;
using System.Collections.Generic;
using UnityEngine;

public class ContextWindowGui : WindowGui
{
    public int currentReferenceId = -1;
    protected List<Collider> invokers = new List<Collider>();
    protected Collider topLevelCollider;

    public virtual void Invoke(int referenceId)
    {
        if (referenceId == this.currentReferenceId)
        {
            this.ToggleWindowVisibility();
        }
        else
        {
            this.ShowWindow();
            this.currentReferenceId = referenceId;
        }
    }

    public void RegisterInvoker(GameObject go)
    {
        Collider component = go.GetComponent<Collider>();
        if (component != null)
        {
            this.invokers.Add(component);
        }
    }

    public virtual void Start()
    {
        this.topLevelCollider = base.GetComponent<Collider>();
        base.Init(2, false);
    }

    public void Update()
    {
        if (base.IsShowing())
        {
            bool flag = (Input.GetMouseButtonDown(0) || Input.GetMouseButtonDown(1)) || Input.GetMouseButtonDown(2);
            if (flag && ((this.topLevelCollider == null) || (this.topLevelCollider.gameObject != UICamera.hoveredObject)))
            {
                foreach (Collider collider in this.invokers)
                {
                    if (collider.gameObject == UICamera.hoveredObject)
                    {
                        return;
                    }
                }
                Collider[] componentsInChildren = base.GetComponentsInChildren<Collider>();
                bool flag2 = false;
                for (int i = 0; i < componentsInChildren.Length; i++)
                {
                    if (componentsInChildren[i].gameObject == UICamera.hoveredObject)
                    {
                        flag2 = true;
                        break;
                    }
                }
                if (!flag2)
                {
                    this.HideWindow();
                }
            }
        }
    }

    public virtual void UpdateContents(int referenceId)
    {
    }
}

