﻿using GNGUI;
using System;
using UnityEngine;

public class CompanyDetailsMembersTabGui : CompanyDetailsTabGui
{
    public override void Awake()
    {
        base.Awake();
        base.tabSpriteName = "frame_company_header_tab_left";
    }

    protected override void MakeListItems()
    {
        VentureCompanyRecord company = GroupClient.GetCompany(CompanyWindowGui.companyId);
        int num = 0;
        if (company != null)
        {
            for (int i = 0; i < company.members.Length; i++)
            {
                if ((company.members[i] != null) && !company.members[i].IsLeader())
                {
                    if (num >= base.displayedItems.Count)
                    {
                        CompanyMemberInfoGui component = NGUITools.AddChild(base.gridList.gameObject, base.listItemPrefab).GetComponent<CompanyMemberInfoGui>();
                        base.displayedItems.Add(component);
                    }
                    ((CompanyMemberInfoGui) base.displayedItems[num]).Assign(company.members[i]);
                    num++;
                }
            }
        }
        while (base.displayedItems.Count > num)
        {
            TabListItem item = base.displayedItems[base.displayedItems.Count - 1];
            base.displayedItems.RemoveAt(base.displayedItems.Count - 1);
            item.gameObject.SetActive(false);
            item.transform.parent = DragDropRoot.root;
            UnityEngine.Object.Destroy(item.gameObject);
        }
    }
}

