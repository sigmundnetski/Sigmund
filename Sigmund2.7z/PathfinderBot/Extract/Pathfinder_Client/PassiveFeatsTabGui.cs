﻿using GNGUI;
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class PassiveFeatsTabGui : WindowTabGui
{
    public override void Awake()
    {
        base.Awake();
        base.tabSpriteName = "panel_feats_tab_left_passivefeats";
        base.prefabName = "FeatGridItem";
        foreach (ToggleText text in base.GetComponentsInChildren<ToggleText>())
        {
            base.allFilters.Add(text);
            UIEventListener listener1 = UIEventListener.Get(text.gameObject);
            listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.FilterClicked));
            if (text.name == "F1_Armor")
            {
                text.Init(new int[] { 12 });
            }
            else if (text.name == "F4_Defensive")
            {
                text.Init(new int[] { 11 });
            }
            else if (text.name == "F0_Feature")
            {
                text.Init(new int[] { 9 });
            }
            else if (text.name == "F2_MagicItem")
            {
                text.Init(new int[0]);
            }
            else if (text.name == "F3_Reactive")
            {
                text.Init(new int[] { 10 });
            }
            else
            {
                GLog.LogError(new object[] { "Unknown filter!", text.name });
            }
        }
    }

    private void ClearFeatList()
    {
        foreach (TabListItem item in base.displayedItems)
        {
            item.gameObject.SetActive(false);
            item.transform.parent = DragDropRoot.root;
            UnityEngine.Object.Destroy(item.gameObject);
        }
        base.displayedItems.Clear();
    }

    public override void ContentsChanged()
    {
        IEnumerable<NonAttackFeatData> enumerable;
        IEnumerable<NonAttackFeatData> enumerable2;
        IEnumerable<NonAttackFeatData> newItems = from each in NonAttackFeatData.GetAvailableFeats(EntityDataClient.owner, EntityDataClient.owner.advancementVars)
            where (each != null) && this.IsValidForFilter(each)
            select each;
        IEnumerable<NonAttackFeatData> oldItems = from each in base.displayedItems select NonAttackFeatData.GetFeatById(((FeatGridItem) each).featId);
        GUtil.GetDeltasWithDuplicates<NonAttackFeatData>(newItems, oldItems, out enumerable, out enumerable2);
        foreach (NonAttackFeatData data in enumerable)
        {
            this.UpdateFeatList(data, WindowTabGui.UpdateType.REMOVE);
        }
        foreach (NonAttackFeatData data in enumerable2)
        {
            this.UpdateFeatList(data, WindowTabGui.UpdateType.ADD);
        }
    }

    private FeatGridItem CreateFeatGridItem(NonAttackFeatData feat)
    {
        FeatGridItem component = NGUITools.AddChild(base.gridList.gameObject, base.listItemPrefab).GetComponent<FeatGridItem>();
        component.Assign(feat.id, feat.type, Combat.FeatType.NonAttack, feat.icon, feat.displayName, EntityDataClient.owner.advancementVars.GetFeatLevelByFeatId(feat.id));
        return component;
    }

    public override void FilterClicked(GameObject filterGO)
    {
        foreach (ToggleText text in base.allFilters)
        {
            if (filterGO == text.gameObject)
            {
                text.ToggleActive();
                base.activeFilter = text.isActive ? text : null;
            }
            else
            {
                text.SetActive(false);
            }
        }
        this.ContentsChanged();
        PaperdollWindowGui.singleton.SetValidityByFilter(PaperdollWindowGui.FilterType.FEATS, base.activeFilter);
        base.FilterClicked(filterGO);
    }

    public override void HideTab()
    {
        base.HideTab();
        this.ClearFeatList();
    }

    private bool IsValidForFilter(NonAttackFeatData feat)
    {
        bool flag = false;
        if ((base.activeFilter != null) && base.activeFilter.filterIds.Contains<int>(((int) feat.type)))
        {
            flag = true;
        }
        else if ((base.activeFilter == null) && (feat.generalType == Combat.FeatType.Passive))
        {
            flag = true;
        }
        bool flag2 = false;
        int roleIdFilter = FeatsWindowGui.singleton.roleIdFilter;
        if (roleIdFilter == 0)
        {
            flag2 = true;
        }
        else if ((feat != null) && (roleIdFilter == feat.roleId))
        {
            flag2 = true;
        }
        return (flag && flag2);
    }

    protected override void MakeListItems()
    {
        if (base.displayedItems.Count<TabListItem>() > 0)
        {
            this.ClearFeatList();
        }
        foreach (NonAttackFeatData data in NonAttackFeatData.GetAvailableFeats(EntityDataClient.owner, EntityDataClient.owner.advancementVars))
        {
            if (this.IsValidForFilter(data))
            {
                base.displayedItems.Add(this.CreateFeatGridItem(data));
            }
        }
        this.RepositionListItems();
    }

    public override void ShowTab()
    {
        this.MakeListItems();
        base.ShowTab();
    }

    private void UpdateFeatList(NonAttackFeatData item, WindowTabGui.UpdateType updateType)
    {
        Predicate<TabListItem> match = null;
        if (updateType == WindowTabGui.UpdateType.REMOVE)
        {
            if (match == null)
            {
                match = i => ((FeatGridItem) i).featId == item.id;
            }
            TabListItem item2 = base.displayedItems.Find(match);
            if (item2 == null)
            {
                return;
            }
            item2.gameObject.SetActive(false);
            item2.transform.parent = DragDropRoot.root;
            UnityEngine.Object.Destroy(item2.gameObject);
            base.displayedItems.Remove(item2);
        }
        else
        {
            FeatGridItem item3 = this.CreateFeatGridItem(item);
            base.displayedItems.Add(item3);
        }
        this.RepositionListItems();
    }
}

