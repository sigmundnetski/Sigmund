﻿using System;
using UnityEngine;

public class EntityCleanup : MonoBehaviour
{
    private void OnDestroy()
    {
        EntityLoadClient.RemoveSmrsOnCleanup(base.gameObject, true);
    }
}

