﻿using GNetwork;
using Map;
using System;
using System.Collections.Generic;
using UnityEngine;

public static class MapClient
{
    public static readonly float BOTTOM_Z_WORLD;
    public static readonly Vector3 centerOfImage = new Vector3(-4865.5f, 0f, -4428.5f);
    private static Color HUSK_DISTANT;
    private static Color HUSK_GONE;
    private static Color HUSK_OTHER;
    private static Color HUSK_PARTY;
    private static Color HUSK_SELF;
    public static readonly float LEFT_X_WORLD;
    public static readonly float MAP_HEIGHT_METERS;
    public static readonly float MAP_WIDTH_METERS;
    public const float METERS_PER_PIXEL = 5f;
    public static readonly float PIXELS_PER_METER;
    public const string POSITION_FORMAT_SHORT = "{0:f2}km {1}, {2:f2}km {3}";
    public const string POSITION_FORMAT_THORNKEEP = "{0:f2}km {1}, {2:f2}km {3} of Thornkeep";
    public static readonly float RIGHT_X_WORLD;
    public static readonly float TOP_Z_WORLD;

    static MapClient()
    {
        Vector3 vector = TerrainUtils.TranslateHexToHex(Vector3.zero, TerrainService.InitialHex, TerrainConsts.THORNKEEP);
        Vector3 vector2 = vector - centerOfImage;
        LEFT_X_WORLD = (vector.x - vector2.x) - 10240f;
        RIGHT_X_WORLD = (vector.x - vector2.x) + 10240f;
        TOP_Z_WORLD = (vector.z - vector2.z) + 10240f;
        BOTTOM_Z_WORLD = (vector.z - vector2.z) - 10240f;
        MAP_WIDTH_METERS = Math.Abs((float) (RIGHT_X_WORLD - LEFT_X_WORLD));
        MAP_HEIGHT_METERS = Math.Abs((float) (TOP_Z_WORLD - BOTTOM_Z_WORLD));
        PIXELS_PER_METER = 0.2f;
    }

    public static void AddMapPin(Vector3 pinWorldPos)
    {
        GRouting.SendMyMapRpc(GRpcID.MapServer_AddPlayerPin, new object[] { pinWorldPos });
    }

    public static void AddPinCommand(string[] args, EntityId playerEntityId)
    {
        if (args.Length != 5)
        {
            ChatGui.singleton.DisplayMessage("Adds a map pin based on distance from Thornkeep.\nUsage: AddPin 2.5km N 3.3km E", ChatClient.ERROR_COLOR);
        }
        else
        {
            float maxValue = float.MaxValue;
            float result = float.MaxValue;
            if (!float.TryParse(args[1].Replace("km", ""), out maxValue))
            {
                ChatGui.singleton.DisplayMessage("Could not parse " + args[1] + " as a number.", ChatClient.ERROR_COLOR);
            }
            else if (!float.TryParse(args[3].Replace("km", ""), out result))
            {
                ChatGui.singleton.DisplayMessage("Could not parse " + args[1] + " as a number.", ChatClient.ERROR_COLOR);
            }
            else
            {
                if ((args[2] != "n") && !(args[2] == "north"))
                {
                    if ((args[2] == "s") || (args[2] == "south"))
                    {
                        maxValue = -maxValue;
                    }
                    else
                    {
                        ChatGui.singleton.DisplayMessage("Could not understand " + args[2] + ". Expected 'N' or 'S'.", ChatClient.ERROR_COLOR);
                        return;
                    }
                }
                if ((args[4] != "e") && !(args[4] == "east"))
                {
                    if ((args[4] == "w") || (args[4] == "west"))
                    {
                        result = -result;
                    }
                    else
                    {
                        ChatGui.singleton.DisplayMessage("Could not understand " + args[4] + ". Expected 'E' or 'W'.", ChatClient.ERROR_COLOR);
                        return;
                    }
                }
                Vector3 pinWorldPos = new Vector3(result * 1000f, 0f, maxValue * 1000f);
                AddMapPin(pinWorldPos);
            }
        }
    }

    public static int FindWidgetDepth(IconType type, int[] nextIconDepth, Queue<int>[] availableDepths)
    {
        int index = (int) type;
        Queue<int> queue = availableDepths[index];
        if (queue.Count > 0)
        {
            return queue.Dequeue();
        }
        int num2 = nextIconDepth[index];
        nextIconDepth[index]++;
        return num2;
    }

    public static string GetDisplayPosition(string format, Vector3 worldSpacePos)
    {
        float f = worldSpacePos.z / 1000f;
        float num2 = worldSpacePos.x / 1000f;
        return string.Format(format, new object[] { Mathf.Abs(f), (f > 0f) ? "N" : "S", Mathf.Abs(num2), (num2 > 0f) ? "E" : "W" });
    }

    public static Color GetHuskColor(Entity huskEntity, uint ownerPlayerId)
    {
        if (!object.ReferenceEquals(huskEntity, EntityDataClient.owner))
        {
            if (huskEntity.huskVars.huskPlayerId == ownerPlayerId)
            {
                return HUSK_SELF;
            }
            if ((GroupClient.activeParty != null) && (GroupClient.activeParty.FindMember(huskEntity.huskVars.huskPlayerId) != null))
            {
                return HUSK_PARTY;
            }
            return HUSK_OTHER;
        }
        switch (huskEntity.playerRecord.huskState)
        {
            case HuskVars.LastKnownState.PRESENT:
                return HUSK_SELF;

            case HuskVars.LastKnownState.LOOTED:
                return HUSK_GONE;
        }
        return HUSK_DISTANT;
    }

    public static Vector3 GuiToWorld(Vector2 pos, Vector2 pixelsPerMeter)
    {
        Vector2 b = new Vector2(1f / pixelsPerMeter.x, 1f / pixelsPerMeter.y);
        Vector2 vector2 = Vector2.Scale(pos, b);
        return new Vector3(vector2.x, 0f, vector2.y);
    }

    public static bool LoadingTickFinished()
    {
        HUSK_GONE = ColorData.GetColorByName("husk_gone", true);
        HUSK_OTHER = ColorData.GetColorByName("husk_other", true);
        HUSK_PARTY = ColorData.GetColorByName("husk_party", true);
        HUSK_SELF = ColorData.GetColorByName("husk_self", true);
        HUSK_DISTANT = ColorData.GetColorByName("husk_distant", true);
        return true;
    }

    public static void OnMapTransfer(ushort mapId)
    {
        if (MiniMapGui.singleton != null)
        {
            MiniMapGui.singleton.OnMapTransfer(mapId);
        }
        if (MapWindowGui.singleton != null)
        {
            MapWindowGui.singleton.OnMapTransfer(mapId);
        }
    }

    public static void PrintPins(string[] args, EntityId playerEntityId)
    {
        DebugClient.GenericDebugMessage("Client MapPlaces:" + GUtil.PrettyPrint(EntityDataClient.owner.localMapPlaces, ", ", "[]"));
    }

    public static void RemovePlayerPin()
    {
        GRouting.SendMyMapRpc(GRpcID.MapServer_RemovePlayerPin, new object[0]);
    }

    public static Vector3 UVToWorld(Vector2 uvPos)
    {
        float x = (uvPos.x * MAP_WIDTH_METERS) + LEFT_X_WORLD;
        return new Vector3(x, 0f, (uvPos.y * MAP_HEIGHT_METERS) + BOTTOM_Z_WORLD);
    }

    public static Quaternion WorldToGui(Quaternion rot)
    {
        return Quaternion.Euler(0f, 0f, -rot.eulerAngles.y);
    }

    public static Vector3 WorldToGui(Vector3 pos, Vector2 pixelsPerMeter)
    {
        Vector3 vector = Vector3.Scale(pos, new Vector3(pixelsPerMeter.x, 0f, pixelsPerMeter.y));
        vector.y = vector.z;
        vector.z = 0f;
        return vector;
    }

    public static Vector2 WorldToUV(Vector3 pos)
    {
        float x = (pos.x - LEFT_X_WORLD) / (RIGHT_X_WORLD - LEFT_X_WORLD);
        return new Vector2(x, (pos.z - BOTTOM_Z_WORLD) / (TOP_Z_WORLD - BOTTOM_Z_WORLD));
    }
}

