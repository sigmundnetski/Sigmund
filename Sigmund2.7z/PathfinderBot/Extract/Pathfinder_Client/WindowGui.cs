﻿using GNGUI;
using System;
using System.Runtime.InteropServices;
using UnityEngine;

[RequireComponent(typeof(UIPanel))]
public class WindowGui : MonoBehaviour
{
    private const string CLOSE_BUTTON_NAME = "CloseButton";
    public bool disableAutoZ = false;
    public WindowTooltipGui tooltip;
    internal UIPanel[] uiPanels;
    public static GameObject windowParent;

    private void CloseClicked(GameObject go)
    {
        this.HideWindow();
    }

    public virtual void HideWindow()
    {
        NGUITools.SetActive(base.gameObject, false);
        if (this.tooltip != null)
        {
            this.tooltip.ShowText(null, null);
        }
        WindowGuiUtils.MoveToBack(this);
        WindowGuiUtils.ResetAllZIndexes();
    }

    protected void Init(int max_levels_deeps, bool requireCloseButton = true)
    {
        WindowGuiUtils.AddWindow(this);
        UIPanel component = base.GetComponent<UIPanel>();
        Transform transform = WindowGuiUtils.FindDescendent(base.transform, "CloseButton", max_levels_deeps);
        this.tooltip = base.GetComponentInChildren<WindowTooltipGui>();
        GuiHelper.GuiAssertNotNull("Could not find needed child objects.", new object[] { component });
        this.uiPanels = WindowGuiUtils.GetSubPanels(base.transform);
        if (requireCloseButton || (transform != null))
        {
            GuiHelper.GuiAssertNotNull("Could not find needed child objects.", new object[] { transform });
            MonoBehaviour behaviour = transform.GetComponent<UIButton>();
            if (behaviour == null)
            {
                behaviour = transform.GetComponent<UIImageButton>();
            }
            GuiHelper.GuiAssertNotNull(base.name + " requires a close button.", new object[] { behaviour });
            UIEventListener listener1 = UIEventListener.Get(behaviour.gameObject);
            listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.CloseClicked));
        }
        Collider[] componentsInChildren = base.transform.GetComponentsInChildren<Collider>(true);
        foreach (Collider collider in componentsInChildren)
        {
            UIEventListener listener2 = UIEventListener.Get(collider.gameObject);
            listener2.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener2.onClick, new UIEventListener.VoidDelegate(WindowGuiUtils.Refocus));
        }
        this.HideWindow();
    }

    public bool IsShowing()
    {
        return NGUITools.GetActive(base.gameObject);
    }

    public virtual void OnDestroy()
    {
        WindowGuiUtils.RemoveWindow(this);
    }

    public void ShowTooltip(string text, GameObject tooltippedObject)
    {
        if (this.tooltip == null)
        {
            Debug.LogWarning(base.name + " does not have a tooltip object.");
        }
        else
        {
            this.tooltip.ShowText(text, tooltippedObject);
        }
    }

    public virtual void ShowWindow()
    {
        NGUITools.SetActive(base.gameObject, true);
        WindowGuiUtils.MoveToFront(this);
        WindowGuiUtils.ResetAllZIndexes();
    }

    public virtual void ToggleWindowVisibility()
    {
        if (this.IsShowing())
        {
            this.HideWindow();
        }
        else
        {
            this.ShowWindow();
        }
    }
}

