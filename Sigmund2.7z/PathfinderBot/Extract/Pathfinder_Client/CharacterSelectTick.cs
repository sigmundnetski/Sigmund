﻿using System;

public class CharacterSelectTick : Ticker.TickBase
{
    private static GUtil.BoolFilterDelegate bundleTick = new GUtil.BoolFilterDelegate(BundleService.SyncFixedUpdate);
    public static GUtil.BoolFilterDelegate charManageBundles = null;
    public static GUtil.BoolFilterDelegate charManageLoadFinish = null;
    public static GUtil.BoolFilterDelegate charManageWait = null;
    public static GUtil.BoolFilterDelegate charSelectLoadFinish = null;
    private static GUtil.BoolFilterDelegate entityBundles = new GUtil.BoolFilterDelegate(EntityLoadClient.ExtractBundles);
    private static GUtil.BoolFilterDelegate mergeJobTick = new GUtil.BoolFilterDelegate(MergeJobService.SyncUpdate);
    private static GUtil.BoolFilterDelegate networkTick = new GUtil.BoolFilterDelegate(GNetworkService.SyncFixedUpdate);
    public static GUtil.BoolFilterDelegate redeemLoadFinish = null;
    private static GUtil.BoolFilterDelegate resourceLoad = new GUtil.BoolFilterDelegate(ResourceManager.LoadingTick);
    private static GUtil.BoolFilterDelegate resourceTick = new GUtil.BoolFilterDelegate(ResourceManager.SyncUpdate);
    private static GUtil.BoolFilterDelegate sceneTick = new GUtil.BoolFilterDelegate(SceneService.SyncFixedUpdate);
    private static GUtil.BoolFilterDelegate staticDataLoad = new GUtil.BoolFilterDelegate(StaticDataService.LoadingTick);
    private static GUtil.BoolFilterDelegate staticDataShutdown = new GUtil.BoolFilterDelegate(StaticDataService.Shutdown);
    private static GUtil.BoolFilterDelegate staticDataTick = new GUtil.BoolFilterDelegate(StaticDataService.SyncFixedUpdate);
    private static GUtil.BoolFilterDelegate uiBundles = new GUtil.BoolFilterDelegate(UIClient.ExtractBundles);
    private static GUtil.BoolFilterDelegate uiTick = new GUtil.BoolFilterDelegate(UIClient.SyncUpdate);

    public CharacterSelectTick()
    {
        base.fixedUpdateFunctions.Add(new Ticker.FixedUpdateTickFunction(this.StartServices));
        base.updateFunctions.Add(null);
        base.fixedUpdateFunctions.Add(new Ticker.FixedUpdateTickFunction(this.LoadingTick));
        base.updateFunctions.Add(null);
        base.fixedUpdateFunctions.Add(new Ticker.FixedUpdateTickFunction(this.ExtractBundles));
        base.updateFunctions.Add(null);
        base.fixedUpdateFunctions.Add(new Ticker.FixedUpdateTickFunction(this.WaitForRemoteCallbacks));
        base.updateFunctions.Add(null);
        base.fixedUpdateFunctions.Add(new Ticker.FixedUpdateTickFunction(this.LoadingTickFinished));
        base.updateFunctions.Add(null);
        base.fixedUpdateFunctions.Add(new Ticker.FixedUpdateTickFunction(this.SyncFixedUpdate));
        base.updateFunctions.Add(new Ticker.UpdateTickFunction(this.SyncUpdate));
    }

    private bool ExtractBundles()
    {
        this.TickLoadingMessage("Extracting bundles");
        GUtil.FilterExceptions(entityBundles, "EntityLoadClient.ExtractBundles");
        GUtil.FilterExceptions(charManageBundles, "CharacterManagementGui.ExtractBundles");
        GUtil.FilterExceptions(uiBundles, "UIClient.ExtractBundles");
        GUtil.FilterExceptions(sceneTick, "SceneService.SyncFixedUpdate");
        GUtil.FilterExceptions(networkTick, "GNetworkService.SyncFixedUpdate");
        return true;
    }

    private bool LoadingTick()
    {
        bool flag = true;
        this.TickLoadingMessage("Loading data");
        flag = GUtil.FilterExceptions(staticDataLoad, "StaticDataService.LoadingTick") && flag;
        flag = GUtil.FilterExceptions(resourceLoad, "ResourceManager.LoadingTick") && flag;
        flag = GUtil.FilterExceptions(bundleTick, "BundleService.SyncFixedUpdate") && flag;
        flag = (CharacterManagementGui.singleton != null) && flag;
        flag = (RedeemWindowGui.singleton != null) && flag;
        flag = (LoadingMessageGUI.singleton != null) && flag;
        if (!flag)
        {
            GUtil.FilterExceptions(sceneTick, "SceneService.SyncFixedUpdate");
        }
        GUtil.FilterExceptions(networkTick, "GNetworkService.SyncFixedUpdate");
        return flag;
    }

    private bool LoadingTickFinished()
    {
        GUtil.FilterExceptions(charManageLoadFinish, "CharacterManagementGui.LoadingTickFinished");
        GUtil.FilterExceptions(charSelectLoadFinish, "CharacterSelectionGui.LoadingTickFinished");
        GUtil.FilterExceptions(redeemLoadFinish, "RedeemWindowGui.LoadingTickFinished");
        GUtil.FilterExceptions(sceneTick, "SceneService.SyncFixedUpdate");
        GUtil.FilterExceptions(networkTick, "GNetworkService.SyncFixedUpdate");
        LoadingMessageGUI.UpdateLoadingStatus(false, "Client loading complete.");
        return true;
    }

    protected override void OnTickDestroyed()
    {
        GUtil.FilterExceptions(staticDataShutdown, "StaticDataService.Shutdown");
    }

    private bool StartServices()
    {
        this.TickLoadingMessage("Initializing");
        ServiceList.StartOnce(typeof(StaticDataService), new object[] { true });
        ServiceList.StartOnce(typeof(BundleService), new object[0]);
        ServiceList.StartOnce(typeof(EntityClient), new object[0]);
        ServiceList.StartOnce(typeof(EntityLoadClient), new object[0]);
        ServiceList.StartOnce(typeof(MergeJobService), new object[0]);
        ServiceList.StartOnce(typeof(UIClient), new object[0]);
        return true;
    }

    private bool SyncFixedUpdate()
    {
        GUtil.FilterExceptions(staticDataTick, "StaticDataService.SyncFixedUpdate");
        GUtil.FilterExceptions(bundleTick, "BundleService.SyncFixedUpdate");
        GUtil.FilterExceptions(sceneTick, "SceneService.SyncFixedUpdate");
        GUtil.FilterExceptions(networkTick, "GNetworkService.SyncFixedUpdate");
        return false;
    }

    private void SyncUpdate()
    {
        GUtil.FilterExceptions(resourceTick, "ResourceManager.SyncUpdate");
        GUtil.FilterExceptions(mergeJobTick, "MergeJobService.SyncUpdate");
        GUtil.FilterExceptions(uiTick, "UIClient.SyncUpdate");
    }

    private void TickLoadingMessage(string message)
    {
        if (LoadingMessageGUI.singleton != null)
        {
            LoadingMessageGUI.UpdateLoadingStatus(true, message);
            GUtil.FilterExceptions(new GUtil.BoolFilterDelegate(LoadingMessageGUI.singleton.SyncFixedUpdate), "LoadingMessageGUI.SyncFixedUpdate");
        }
    }

    private bool WaitForRemoteCallbacks()
    {
        bool flag = true;
        this.TickLoadingMessage("Waiting for character list");
        flag = GUtil.FilterExceptions(charManageWait, "CharacterManagementGui.WaitForRemoteCallbacks") && flag;
        GUtil.FilterExceptions(networkTick, "GNetworkService.SyncFixedUpdate");
        GUtil.FilterExceptions(sceneTick, "SceneService.SyncFixedUpdate");
        GUtil.FilterExceptions(networkTick, "GNetworkService.SyncFixedUpdate");
        return flag;
    }
}

