﻿using System;
using System.Collections.Generic;
using System.Text;

public class TrackedEvent : ITrackerElement
{
    private const string counterHudTextColorCode = "[7DC84F]";
    private EventData eventData;
    private ActiveEventInfo eventInfo;
    private const string questHudTextColorCode = "[F0E3A8]";

    public TrackedEvent(int _eventId)
    {
        EscalationVars escalationVars = EntityDataClient.owner.escalationVars;
        EventData.eventsById.TryGetValue(_eventId, out this.eventData);
        this.eventInfo = escalationVars.GetEvent(_eventId);
    }

    private string _GetEncounterEventText(bool isLongText)
    {
        StringBuilder quickText = GUtil.GetQuickText();
        if ((this.eventData != null) && (this.eventInfo.eventStatus == EscalationConst.Flow.INCOMPLETE))
        {
            foreach (ActiveCounterInfo info in SparseArray.Iterate<ActiveCounterInfo>(this.eventInfo.counters))
            {
                if (info.current < info.max)
                {
                    quickText.AppendFormat("{0}{1}: {2}/{3}[-]\n", new object[] { "[7DC84F]", info.GenerateHudText(), info.current, info.max });
                }
            }
            using (IEnumerator<QuestRecord> enumerator2 = EntityDataClient.owner.playerRecord.GetActiveQuests().GetEnumerator())
            {
                while (enumerator2.MoveNext())
                {
                    Predicate<int> predicate = null;
                    QuestRecord eachQuestRecord = enumerator2.Current;
                    if (eachQuestRecord == null)
                    {
                    }
                    if ((predicate == null) && (-1 != SparseArray.IndexOf<int>(this.eventData.linkedQuestIds, predicate = x => x == eachQuestRecord.questId)))
                    {
                        quickText.Append("[F0E3A8]");
                        QuestData.AppendObjective(quickText, eachQuestRecord, isLongText);
                        quickText.Append("[-]\n");
                    }
                }
            }
        }
        return quickText.ToString();
    }

    public string GetBody()
    {
        return this._GetEncounterEventText(false);
    }

    public string GetHoverText()
    {
        return this._GetEncounterEventText(true);
    }

    public string GetName()
    {
        return EventData.EventHudText(this.eventData.id, this.eventInfo.eventStatus);
    }

    public void OnClick()
    {
        QuestClient.SetQuestBlob(this.eventData.linkedQuestIds);
    }
}

