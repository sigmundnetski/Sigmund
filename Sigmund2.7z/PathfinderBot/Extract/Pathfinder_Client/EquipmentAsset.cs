﻿using System;
using System.Runtime.InteropServices;
using UnityEngine;

[StructLayout(LayoutKind.Sequential)]
public struct EquipmentAsset
{
    public static readonly EquipmentAsset EMPTY;
    public readonly string assetName;
    public readonly Color materialColor;
    public readonly Color userColor1;
    public readonly Color userColor2;
    public EquipmentAsset(string _name)
    {
        this.assetName = _name;
        this.materialColor = this.userColor1 = this.userColor2 = Color.black;
    }

    public EquipmentAsset(string _name, Color _mat, Color _user1, Color _user2)
    {
        this.assetName = _name;
        this.materialColor = _mat;
        this.userColor1 = _user1;
        this.userColor2 = _user2;
    }

    public override string ToString()
    {
        return string.Concat(new object[] { "<", this.assetName, " mat:", this.materialColor, " usr1:", this.userColor1, " usr2:", this.userColor2, ">" });
    }

    static EquipmentAsset()
    {
        EMPTY = new EquipmentAsset(null);
    }
}

