﻿using GNetwork;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using UnityEngine;

public static class ChatClient
{
    private static Dictionary<string, int> channelNameToId = new Dictionary<string, int>();
    private static int currentChannelId = -1;
    private static string currentWhisperName;
    public static Color DEBUG_COLOR = new Color(1f, 0.8f, 1f);
    public static Color DEFAULT_COLOR = new Color(0.9411765f, 0.8901961f, 0.6588235f);
    public static Color EMOTE_COLOR = new Color(0.5411765f, 0.4666667f, 0.8f);
    public static Color ERROR_COLOR = new Color(1f, 0f, 0f);
    private static ushort mapId = 0;
    private static string replyWhisperName;
    public static Color TAB_DEFAULT_COLOR = new Color(0.9411765f, 0.8901961f, 0.6588235f);
    public static Color TAB_UNREAD_COLOR = new Color(0.9411765f, 0.8901961f, 0.8823529f);
    public static Color WHISPER_COLOR = new Color(1f, 0.4f, 0.9333333f);

    public static bool ChangeChannel(string channel)
    {
        if (ChatHelper.IsWhisperChannel(channel))
        {
            if (!string.IsNullOrEmpty(currentWhisperName))
            {
                currentChannelId = -2;
                ChatGui.singleton.SetChannel(currentChannelId, currentWhisperName, ChannelType.WHISPER);
                return true;
            }
            currentChannelId = -1;
            ChatGui.singleton.SetChannel(currentChannelId, currentWhisperName, ChannelType.WHISPER);
            return false;
        }
        bool flag = true;
        int num = -1;
        if (!(!string.IsNullOrEmpty(channel) && channelNameToId.TryGetValue(channel.ToLower(), out num)))
        {
            currentChannelId = -1;
            num = -1;
            flag = false;
        }
        SwitchChannel(num, channel, ChannelType.CHAT);
        return flag;
    }

    public static void ChangeChannel(string[] args, EntityId playerEntityId)
    {
        if (args.Length < 2)
        {
            ChatGui.singleton.GetActiveTab().AddMessage("The name of the channel to switch to is required.", DEFAULT_COLOR);
        }
        else
        {
            string channelName = ChatHelper.GetChannelName(args);
            if (!ChatGui.singleton.ChangeTab(channelName))
            {
                if (!ChangeChannel(channelName))
                {
                    ChatGui.singleton.GetActiveTab().AddMessage("You are not in the '" + channelName + "' channel.", EMOTE_COLOR);
                }
                else if (args.Length > 2)
                {
                    SendMessageToServer(string.Join(" ", args.Skip<string>(2).ToArray<string>()));
                }
            }
        }
    }

    private static bool ExtractPlayerName(ref string args, out string playerName)
    {
        CommandCore.ExtractLongParam(ref args, out playerName);
        return VerifyPlayerName(playerName);
    }

    public static int GetChannelId(string channelName)
    {
        int num;
        if (channelNameToId.TryGetValue(channelName.ToLower(), out num))
        {
            return num;
        }
        return -1;
    }

    public static void GetCurrentChannels(string[] args, EntityId playerEntityId)
    {
        if (channelNameToId.Count<KeyValuePair<string, int>>() == 0)
        {
            ChatGui.singleton.GetActiveTab().AddMessage("You're not in any channels.", DEFAULT_COLOR);
        }
        else
        {
            string[] strArray = (from each in channelNameToId
                orderby each.Key
                select each.Key).ToArray<string>();
            ChatGui.singleton.GetActiveTab().AddMessage("Channels you're in: " + string.Join(", ", strArray), DEFAULT_COLOR);
        }
    }

    public static bool InChannel(string channelName)
    {
        int num;
        return channelNameToId.TryGetValue(channelName.ToLower(), out num);
    }

    public static void JoinChannel(string channel)
    {
        string str = channel.ToLower();
        if (ChatHelper.IsWhisperChannel(channel))
        {
            ChatGui.singleton.AddChannelToTab(-2);
            ChatGui.singleton.AddChannelToTab(-3);
        }
        else
        {
            int num;
            if (channelNameToId.TryGetValue(channel.ToLower(), out num))
            {
                ChatGui.singleton.AddChannelToTab(num);
            }
            else
            {
                CommandClient.SendCommandToServer("JoinChannel " + channel, PlayerEntityClient.GetPlayerEntityId());
            }
        }
    }

    public static void JoinChannel(string[] args, EntityId playerEntityId)
    {
    }

    public static void LeaveChannel(string channel)
    {
        CommandClient.SendCommandToServer("LeaveChannel " + channel, PlayerEntityClient.GetPlayerEntityId());
    }

    public static void LeaveChannel(string[] args, EntityId playerEntityId)
    {
    }

    public static bool LoadingTickFinished()
    {
        channelNameToId.Clear();
        currentChannelId = -1;
        currentWhisperName = null;
        replyWhisperName = null;
        return true;
    }

    public static void LocalChatCommand(string[] args, EntityId playerEntityId)
    {
        if (!ChatGui.singleton.ChangeTab("Local"))
        {
            SwitchChannel(-4, "Local", ChannelType.CHAT);
        }
        string str = args[0];
        if (CommandCore.RemoveCommandFromString(ref str))
        {
            SendMessageToServer(str);
        }
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void OnEmoteReceived(int channelId, string sourceCharacterName, string emoteMessage)
    {
        ChatGui.singleton.DisplayEmote(channelId, sourceCharacterName + " " + emoteMessage.Trim(), EMOTE_COLOR);
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void OnJoinChannel(int channelId, string channelName, bool successful, string description)
    {
        if (!successful)
        {
            ChatGui.singleton.DisplayMessage("Failed to Join Channel:" + channelName + " " + description, ERROR_COLOR);
        }
        else
        {
            channelNameToId[channelName.ToLower()] = channelId;
            ChatGui.singleton.ChannelJoined(channelId, channelName);
            if ((currentChannelId == -1) && ChatGui.singleton.GetActiveTab().DesireChannel(channelName))
            {
                SwitchChannel(channelId, channelName, ChannelType.CHAT);
            }
        }
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void OnLeaveChannel(int channelId, string channelName, bool successful, string description)
    {
        channelNameToId.Remove(channelName.ToLower());
        ChatGui.singleton.ChannelLeft(channelId, channelName);
        if (channelId == currentChannelId)
        {
            SwitchChannel(-1, string.Empty, ChannelType.CHAT);
        }
    }

    public static void OnMapTransfer(ushort mapId_)
    {
        if (mapId != 0)
        {
            LeaveChannel("hex" + mapId);
        }
        JoinChannel("hex" + mapId_);
        mapId = mapId_;
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void OnMessageReceived(int channelId, string sourceCharacterName, string message)
    {
        if (channelId == -3)
        {
            replyWhisperName = sourceCharacterName;
        }
        ChatGui.singleton.DisplayMessage(channelId, sourceCharacterName, message);
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void OnTargetedEmoteReceived(int channelId, int emoteId, EntityId srcEntityId, EntityId targetEntityId)
    {
        EmoteData data;
        bool flag = (EntityDataClient.owner != null) ? (EntityDataClient.owner.entityId == srcEntityId) : false;
        bool flag2 = (EntityDataClient.owner != null) ? (EntityDataClient.owner.entityId == targetEntityId) : false;
        if (EmoteData.emoteById.TryGetValue(emoteId, out data))
        {
            string receiverResponse;
            if (flag2)
            {
                receiverResponse = data.receiverResponse;
            }
            else if (targetEntityId != EntityId.INVALID_ID)
            {
                receiverResponse = flag ? data.selfTargetedResponse : data.otherTargetedResponse;
            }
            else
            {
                receiverResponse = flag ? data.selfUntargetedResponse : data.otherUntargetedResponse;
            }
            receiverResponse = UIClient.ParseReplacementWords(receiverResponse, EntityDataClient.owner, EntityCore.GetEntity(srcEntityId), EntityCore.GetEntity(targetEntityId));
            ChatGui.singleton.DisplayEmote(channelId, receiverResponse, EMOTE_COLOR);
        }
    }

    public static void PartyChatCommand(string[] args, EntityId playerEntityId)
    {
        string str = args[0];
        if (!CommandCore.RemoveCommandFromString(ref str))
        {
            ChatGui.singleton.ChangeTab("Party");
        }
        else
        {
            int num;
            if (!channelNameToId.TryGetValue("party", out num))
            {
                ChatGui.singleton.GetActiveTab().AddMessage("No party channel found", ERROR_COLOR);
            }
            else
            {
                SendMessageToServer(str, num);
            }
        }
    }

    public static void ProcessCommand(string command)
    {
        CommandCore.ExecuteAllCommands(command, EntityDataClient.owner.entityId);
    }

    public static void RemoveChannel(string[] args, EntityId playerEntityId)
    {
    }

    public static void ReplyCommand(string[] args, EntityId playerEntityId)
    {
        if (string.IsNullOrEmpty(replyWhisperName))
        {
            ChatGui.singleton.GetActiveTab().AddMessage("No one has whispered you yet.", DEFAULT_COLOR);
        }
        else
        {
            string str = args[0];
            if (!CommandCore.RemoveCommandFromString(ref str))
            {
                ChatGui.singleton.GetActiveTab().AddMessage("Usage: /r Hello, person who whispered me.", DEFAULT_COLOR);
            }
            else
            {
                currentWhisperName = replyWhisperName;
                if (!string.IsNullOrEmpty(str))
                {
                    SendMessageToServer(str, -2);
                }
            }
        }
    }

    public static void ResetChatSettings(string[] args, EntityId playerEntityId)
    {
        PlayerPrefs.DeleteKey("chat");
        ChatGui.singleton.GetActiveTab().AddMessage("Chat reset to default. Log back in to see change.", DEBUG_COLOR);
    }

    public static void SendEmote(string[] args, EntityId playerEntityId)
    {
        EntityId selectedEntityId = Targeting.selectedEntityId;
        int key = DataClass.GenerateId(args[0]);
        if (EmoteData.emoteById.ContainsKey(key))
        {
            GRouting.SendMyMapRpc(GRpcID.ChatServer_DoTargetedEmote, new object[] { key, selectedEntityId });
        }
    }

    private static void SendMessageToServer(string message)
    {
        SendMessageToServer(message, currentChannelId);
    }

    public static void SendMessageToServer(string message, int channelId)
    {
        if (message.StartsWith("/"))
        {
            ProcessCommand(message.Substring(1));
        }
        else if (channelId == -2)
        {
            GRouting.SendAuthorityRpc(1, GRpcID.ChatAuthority_PlayerWhisper, new object[] { currentWhisperName, message });
        }
        else if (channelId == -4)
        {
            GRouting.SendMyMapRpc(GRpcID.ChatServer_PlayerPostToLocal, new object[] { message });
        }
        else if (channelId == -1)
        {
            ChatGui.singleton.GetActiveTab().AddMessage("Not in any channels.", ERROR_COLOR);
        }
        else
        {
            GRouting.SendAuthorityRpc(1, GRpcID.ChatAuthority_PlayerPostToChannel, new object[] { channelId, message });
        }
    }

    private static void SwitchChannel(int channelId, string channelName, ChannelType channelType)
    {
        currentChannelId = channelId;
        ChatGui.singleton.SetChannel(currentChannelId, channelName, channelType);
    }

    private static void SyncStart()
    {
        ChatGui.chatEnteredCallback = new ChatGui.ChatEnteredCallback(ChatClient.SendMessageToServer);
        StaticDataService.RegisterCallback<ColorData>(new StaticDataService.StaticDataServiceCallback(ChatClient.UpdateColors));
    }

    public static void UpdateColors(List<DataClass> ignored)
    {
        ERROR_COLOR = ColorData.GetColorByName("chat_error", true);
        DEBUG_COLOR = ColorData.GetColorByName("chat_debug", true);
        EMOTE_COLOR = ColorData.GetColorByName("chat_emote", true);
        WHISPER_COLOR = ColorData.GetColorByName("chat_whisper", true);
        DEFAULT_COLOR = ColorData.GetColorByName("chat_channel_default", true);
        TAB_DEFAULT_COLOR = ColorData.GetColorByName("chat_tab_default", true);
        TAB_UNREAD_COLOR = ColorData.GetColorByName("chat_tab_unread", true);
    }

    private static bool VerifyPlayerName(string playerName)
    {
        int num = 0;
        for (int i = 0; i < playerName.Length; i++)
        {
            if (playerName[i] == ' ')
            {
                num++;
            }
        }
        return (num < 2);
    }

    public static void WhisperCommand(string[] args, EntityId playerEntityId)
    {
        string str2;
        string str = args[0];
        if ((!CommandCore.RemoveCommandFromString(ref str) || !ExtractPlayerName(ref str, out str2)) || string.IsNullOrEmpty(str))
        {
            ChatGui.singleton.GetActiveTab().AddMessage("Usage: /w <player name>, <message>", DEFAULT_COLOR);
        }
        else
        {
            currentWhisperName = str2;
            SendMessageToServer(str, -2);
        }
    }

    public enum ChannelType : byte
    {
        CHAT = 0,
        WHISPER = 1
    }
}

