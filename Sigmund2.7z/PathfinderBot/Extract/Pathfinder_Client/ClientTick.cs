﻿using System;
using UnityEngine;

public class ClientTick : Ticker.TickBase
{
    public static GUtil.BoolFilterDelegate achieveGuiLoadFinish = null;
    public static GUtil.BoolFilterDelegate auctionGuiLoadFinish = null;
    public static GUtil.BoolFilterDelegate auctionGuiTick = null;
    public static GUtil.BoolFilterDelegate bankGuiLoadFinish = null;
    private static GUtil.BoolFilterDelegate bundleTick = new GUtil.BoolFilterDelegate(BundleService.SyncFixedUpdate);
    public static GUtil.BoolFilterDelegate buttonGuiLoadFinish = null;
    public static GUtil.BoolFilterDelegate buttonGuiTick = null;
    public static GUtil.BoolFilterDelegate characterGuiLoadFinish = null;
    private static GUtil.BoolFilterDelegate chatClientLoadFinish = new GUtil.BoolFilterDelegate(ChatClient.LoadingTickFinished);
    public static GUtil.BoolFilterDelegate chatCtxLoadFinish = null;
    public static GUtil.BoolFilterDelegate chatGuiLoadFinish = null;
    private static GUtil.BoolFilterDelegate combatClientSyncFixedUpdate = new GUtil.BoolFilterDelegate(CombatClient.SyncFixedUpdate);
    private static GUtil.BoolFilterDelegate combatClientSyncUpdate = new GUtil.BoolFilterDelegate(CombatClient.SyncUpdate);
    private static GUtil.BoolFilterDelegate combatCoreTick = new GUtil.BoolFilterDelegate(CombatCore.ClientCombatTick);
    private static GUtil.BoolFilterDelegate combatLoad = new GUtil.BoolFilterDelegate(CombatCore.LoadingTick);
    private static GUtil.BoolFilterDelegate combatLoadFinish = new GUtil.BoolFilterDelegate(CombatCore.LoadingTickFinished);
    private static GUtil.BoolFilterDelegate commandLoadFinish = new GUtil.BoolFilterDelegate(CommandClient.LoadingTickFinished);
    public static GUtil.BoolFilterDelegate companyGuiLoadFinish = null;
    public static GUtil.BoolFilterDelegate companyGuiTick = null;
    public static GUtil.BoolFilterDelegate companySearchGuiLoadFinish = null;
    private static GUtil.BoolFilterDelegate craftingSyncFixedUpdate = new GUtil.BoolFilterDelegate(CraftingClient.SyncFixedUpdate);
    public static GUtil.BoolFilterDelegate craftingSyncUpdate = null;
    private static GUtil.BoolFilterDelegate debugClientTick = new GUtil.BoolFilterDelegate(DebugClient.SyncUpdate);
    public static GUtil.BoolFilterDelegate diceGuiLoadFinish = null;
    private static GUtil.BoolFilterDelegate encounterBundle = new GUtil.BoolFilterDelegate(EncounterClient.ExtractBundles);
    private static GUtil.BoolFilterDelegate encounterLoad = new GUtil.BoolFilterDelegate(EncounterClient.LoadingTick);
    private static GUtil.BoolFilterDelegate entityCoreTick = new GUtil.BoolFilterDelegate(EntityCore.SyncFixedUpdate);
    private static GUtil.BoolFilterDelegate entityLoad = new GUtil.BoolFilterDelegate(EntityClient.LoadingTick);
    private static GUtil.BoolFilterDelegate entityLoadBundle = new GUtil.BoolFilterDelegate(EntityLoadClient.ExtractBundles);
    private static GUtil.BoolFilterDelegate entityLost = new GUtil.BoolFilterDelegate(EntityDataClient.CheckLostPlayerIssue);
    public static GUtil.BoolFilterDelegate entityMotionTick = null;
    private static GUtil.BoolFilterDelegate entityShutdown = new GUtil.BoolFilterDelegate(EntityDataClient.Shutdown);
    private static GUtil.BoolFilterDelegate entityTick = new GUtil.BoolFilterDelegate(EntityData.SyncFixedUpdate);
    public static GUtil.BoolFilterDelegate eventGuiLoadFinish = null;
    private static GUtil.BoolFilterDelegate eventGuiTick = new GUtil.BoolFilterDelegate(EventBarGui.SyncFixedUpdate);
    public static GUtil.BoolFilterDelegate featGuiLoadFinish = null;
    private static GUtil.BoolFilterDelegate fxBundle = new GUtil.BoolFilterDelegate(FxService.ExtractBundles);
    private static GUtil.BoolFilterDelegate fxTick = new GUtil.BoolFilterDelegate(FxService.SyncUpdate);
    private static GUtil.BoolFilterDelegate graphicsLoadFinish = new GUtil.BoolFilterDelegate(GraphicsClient.LoadingTickFinished);
    private static GUtil.BoolFilterDelegate graphicsTick = new GUtil.BoolFilterDelegate(GraphicsClient.SyncFixedUpdate);
    private static GUtil.BoolFilterDelegate groupClient = new GUtil.BoolFilterDelegate(GroupClient.SyncFixedUpdate);
    private static GUtil.BoolFilterDelegate groupLoadFinish = new GUtil.BoolFilterDelegate(GroupClient.LoadingTickFinished);
    public static GUtil.BoolFilterDelegate inputLoadFinish = new GUtil.BoolFilterDelegate(ClientInputManager.LoadingTickFinished);
    public static GUtil.BoolFilterDelegate inputTick = null;
    public static GUtil.BoolFilterDelegate invGuiLoadFinish = null;
    private static GUtil.BoolFilterDelegate lootWindowTick = new GUtil.BoolFilterDelegate(LootWindowGui.SyncUpdate);
    private static GUtil.BoolFilterDelegate mapClientLoadFinish = new GUtil.BoolFilterDelegate(MapClient.LoadingTickFinished);
    private static GUtil.BoolFilterDelegate mergeJobTick = new GUtil.BoolFilterDelegate(MergeJobService.SyncUpdate);
    public static GUtil.BoolFilterDelegate miniMapGuiLoadFinish = null;
    public static GUtil.BoolFilterDelegate miniMapGuiTick = null;
    private static GUtil.BoolFilterDelegate netShutdown = new GUtil.BoolFilterDelegate(GNetworkService.Shutdown);
    private static GUtil.BoolFilterDelegate networkTick = new GUtil.BoolFilterDelegate(GNetworkService.SyncFixedUpdate);
    public static GUtil.BoolFilterDelegate partyGuiLoadFinish = null;
    public static GUtil.BoolFilterDelegate partyGuiTick = null;
    private static GUtil.BoolFilterDelegate playerEntityLoad = new GUtil.BoolFilterDelegate(PlayerEntityClient.LoadingTick);
    private static GUtil.BoolFilterDelegate playerEntityTick = new GUtil.BoolFilterDelegate(PlayerEntityClient.SyncFixedUpdate);
    public static GUtil.BoolFilterDelegate playerGuiTick = null;
    public static GUtil.BoolFilterDelegate pvpGuiLoadFinish = null;
    public static GUtil.BoolFilterDelegate pvpGuiTick = null;
    private static GUtil.BoolFilterDelegate questGiverTick = new GUtil.BoolFilterDelegate(QuestGiverGui.SyncFixedUpdate);
    private static GUtil.BoolFilterDelegate resourceLoad = new GUtil.BoolFilterDelegate(ResourceManager.LoadingTick);
    private static GUtil.BoolFilterDelegate resourceTick = new GUtil.BoolFilterDelegate(ResourceManager.SyncUpdate);
    private static GUtil.BoolFilterDelegate sceneTick = new GUtil.BoolFilterDelegate(SceneService.SyncFixedUpdate);
    public bool serverSceneReceived;
    public static GUtil.BoolFilterDelegate settingsGuiLoadFinish = null;
    public static GUtil.BoolFilterDelegate settingsGuiTick = null;
    private static GUtil.BoolFilterDelegate slaveShutdown = new GUtil.BoolFilterDelegate(SlavedProxyClient.Shutdown);
    private static GUtil.BoolFilterDelegate slaveTick = new GUtil.BoolFilterDelegate(SlavedProxyClient.SyncFixedUpdate);
    private static GUtil.BoolFilterDelegate staticDataLoad = new GUtil.BoolFilterDelegate(StaticDataService.LoadingTick);
    private static GUtil.BoolFilterDelegate staticDataShutdown = new GUtil.BoolFilterDelegate(StaticDataService.Shutdown);
    private static GUtil.BoolFilterDelegate staticDataTick = new GUtil.BoolFilterDelegate(StaticDataService.SyncFixedUpdate);
    private static GUtil.BoolFilterDelegate targetingLoadFinish = new GUtil.BoolFilterDelegate(Targeting.LoadingTickFinished);
    private static GUtil.BoolFilterDelegate targetingTick = new GUtil.BoolFilterDelegate(Targeting.SyncUpdate);
    private static GUtil.BoolFilterDelegate terrainClientTick = new GUtil.BoolFilterDelegate(TerrainClient.SyncFixedUpdate);
    private static GUtil.BoolFilterDelegate terrainShutdown = new GUtil.BoolFilterDelegate(TerrainClient.Shutdown);
    private static GUtil.BoolFilterDelegate terrainTick = new GUtil.BoolFilterDelegate(TerrainService.SyncFixedUpdate);
    public static GUtil.BoolFilterDelegate tradeGuiLoadFinish = null;
    public static GUtil.BoolFilterDelegate trainerGuiLoadFinish = null;
    public static GUtil.BoolFilterDelegate trainerGuiTick = null;
    private static GUtil.BoolFilterDelegate uiLoadFinish = new GUtil.BoolFilterDelegate(UIClient.ClientTick_LoadingTickFinished);
    private static GUtil.BoolFilterDelegate uiTick = new GUtil.BoolFilterDelegate(UIClient.SyncUpdate);
    public static GUtil.BoolFilterDelegate worldMapGuiLoadFinish = null;
    public static GUtil.BoolFilterDelegate worldMapGuiTick = null;

    public ClientTick()
    {
        base.fixedUpdateFunctions.Add(new Ticker.FixedUpdateTickFunction(this.StartServices));
        base.updateFunctions.Add(null);
        base.fixedUpdateFunctions.Add(new Ticker.FixedUpdateTickFunction(this.WaitForSceneName));
        base.updateFunctions.Add(null);
        base.fixedUpdateFunctions.Add(new Ticker.FixedUpdateTickFunction(this.LoadingTick));
        base.updateFunctions.Add(null);
        base.fixedUpdateFunctions.Add(new Ticker.FixedUpdateTickFunction(this.ExtractBundles));
        base.updateFunctions.Add(null);
        base.fixedUpdateFunctions.Add(new Ticker.FixedUpdateTickFunction(this.LoadDynamicWindows));
        base.updateFunctions.Add(null);
        base.fixedUpdateFunctions.Add(new Ticker.FixedUpdateTickFunction(this.LoadingTickFinished));
        base.updateFunctions.Add(null);
        base.fixedUpdateFunctions.Add(new Ticker.FixedUpdateTickFunction(this.GoInGame));
        base.updateFunctions.Add(null);
        base.fixedUpdateFunctions.Add(new Ticker.FixedUpdateTickFunction(this.WaitForEnvironmentLoad));
        base.updateFunctions.Add(null);
        base.fixedUpdateFunctions.Add(new Ticker.FixedUpdateTickFunction(this.WaitForCharacterLoad));
        base.updateFunctions.Add(null);
        base.fixedUpdateFunctions.Add(new Ticker.FixedUpdateTickFunction(this.PrepareSyncFixedUpdate));
        base.updateFunctions.Add(null);
        base.fixedUpdateFunctions.Add(new Ticker.FixedUpdateTickFunction(this.SyncFixedUpdate));
        base.updateFunctions.Add(new Ticker.UpdateTickFunction(this.SyncUpdate));
        LoadingMessageGUI.UpdateLoadingStatus(true, "Connecting to Server...");
    }

    private bool ExtractBundles()
    {
        this.TickLoadingMessage("Extracting bundles");
        GUtil.FilterExceptions(encounterBundle, "EncounterClient.ExtractBundles");
        GUtil.FilterExceptions(entityLoadBundle, "EntityLoadClient.ExtractBundles");
        GUtil.FilterExceptions(networkTick, "GNetworkService.SyncFixedUpdate");
        GUtil.FilterExceptions(fxBundle, "FxService.ExtractBundles");
        return true;
    }

    private bool GoInGame()
    {
        PlayerConnectionClient.InGame();
        GUtil.FilterExceptions(networkTick, "GNetworkService.SyncFixedUpdate");
        return true;
    }

    private bool LoadDynamicWindows()
    {
        this.TickLoadingMessage("Loading GUI");
        GUtil.FilterExceptions(networkTick, "GNetworkService.SyncFixedUpdate");
        bool flag = true;
        flag = (WindowParent.LoadWindow("AchievementsWindow", new Vector3(-480f, 210f, 0f)) && (AchievementsWindowGui.singleton != null)) && flag;
        flag = (WindowParent.LoadWindow("CharacterSheet", new Vector3(-500f, 300f, 0f)) && (CharacterWindowGui.singleton != null)) && flag;
        flag = (WindowParent.LoadWindow("CraftingWindow", Vector3.zero) && (CraftingWindow.singleton != null)) && flag;
        flag = (WindowParent.LoadWindow("CompanySearchWindow", new Vector3(-500f, 297f, 0f)) && (CompanySearchWindowGui.singleton != null)) && flag;
        flag = (WindowParent.LoadWindow("FeatsWindow", new Vector3(-600f, 300f, 0f)) && (FeatsWindowGui.singleton != null)) && flag;
        flag = (WindowParent.LoadWindow("InventoryWindow", new Vector3(220f, 300f, 0f)) && (InventoryWindowGui.singleton != null)) && flag;
        flag = (WindowParent.LoadWindow("LootWindow", GConst.VECTOR3_INVALID) && (LootWindowGui.singleton != null)) && flag;
        flag = (WindowParent.LoadWindow("MapWindow", new Vector3(-400f, 260f, 0f)) && (MapWindowGui.singleton != null)) && flag;
        flag = (WindowParent.LoadWindow("PaperdollWindow", new Vector3(0f, 330f, 0f)) && (PaperdollWindowGui.singleton != null)) && flag;
        flag = (WindowParent.LoadWindow("QuestGiverGui", Vector3.zero) && (QuestGiverGui.singleton != null)) && flag;
        flag = (WindowParent.LoadWindow("QuestLogGui", Vector3.zero) && (QuestLogGui.singleton != null)) && flag;
        flag = (WindowParent.LoadWindow("SettingsWindow", new Vector3(-400f, 240f, 0f)) && (SettingsWindowGui.singleton != null)) && flag;
        flag = (WindowParent.LoadWindow("TextBlobGui", new Vector3(160f, 100f, 0f)) && (TextBlobGui.singleton != null)) && flag;
        flag = (WindowParent.LoadWindow("TrainerWindow", new Vector3(-490f, 290f, 0f)) && (TrainerWindowGui.singleton != null)) && flag;
        flag = (WindowParent.LoadWindow("TreasureBoxSelectorGui", new Vector3(-160f, -100f, 0f)) && (TreasureBoxSelectorGui.singleton != null)) && flag;
        flag = (WindowParent.LoadWindow("ItemQtyGui", Vector3.zero) && (ItemQtyGui.singleton != null)) && flag;
        flag = WindowBackgroundParent.LoadWindowBg("CraftingWindowBackground", CraftingWindow.singleton, new Vector3(0f, 0f, -8f)) && flag;
        flag = WindowBackgroundParent.LoadWindowBg("AuctionWindowBackground", AuctionHouseGui.singleton, new Vector3(0f, 0f, -8f)) && flag;
        return ((WindowParent.LoadWindow("InventoryItemRClick", GConst.VECTOR3_INVALID) && (InventoryItemRClick.singleton != null)) && flag);
    }

    private bool LoadingTick()
    {
        bool flag = true;
        this.TickLoadingMessage("Loading data");
        flag = GUtil.FilterExceptions(staticDataLoad, "StaticDataService.LoadingTick") && flag;
        flag = GUtil.FilterExceptions(resourceLoad, "ResourceManager.LoadingTick") && flag;
        flag = GUtil.FilterExceptions(bundleTick, "BundleService.SyncFixedUpdate") && flag;
        flag = (ChatGui.singleton != null) && flag;
        flag = (ChatContextGui.singleton != null) && flag;
        flag = (DebugGui.singleton != null) && flag;
        flag = (EscapeMenuGui.singleton != null) && flag;
        flag = (EventBarGui.singleton != null) && flag;
        flag = (GamingTableDiceGUI.singleton != null) && flag;
        flag = (MiniMapGui.singleton != null) && flag;
        flag = (PlayerBarGui.singleton != null) && flag;
        flag = (ButtonBarGui.singleton != null) && flag;
        flag = (TradeWindowGui.singleton != null) && flag;
        flag = (CompanyWindowGui.singleton != null) && flag;
        flag = (AuctionHouseGui.singleton != null) && flag;
        flag = GUtil.FilterExceptions(encounterLoad, "EncounterClient.LoadingTick") && flag;
        flag = GUtil.FilterExceptions(entityLoad, "EntityClient.LoadingTick") && flag;
        flag = GUtil.FilterExceptions(playerEntityLoad, "PlayerEntityClient.LoadingTick") && flag;
        flag = GUtil.FilterExceptions(combatLoad, "CombatCore.LoadingTick") && flag;
        if (!flag)
        {
            GUtil.FilterExceptions(sceneTick, "SceneService.SyncFixedUpdate");
        }
        GUtil.FilterExceptions(networkTick, "GNetworkService.SyncFixedUpdate");
        return flag;
    }

    private bool LoadingTickFinished()
    {
        this.TickLoadingMessage("Loading data");
        GUtil.FilterExceptions(graphicsLoadFinish, "GraphicsClient.LoadingTickFinished");
        GUtil.FilterExceptions(commandLoadFinish, "CommandClient.LoadingTickFinished");
        GUtil.FilterExceptions(combatLoadFinish, "CombatCore.LoadingTickFinished");
        GUtil.FilterExceptions(uiLoadFinish, "UIClient.ClientTick_LoadingTickFinished");
        GUtil.FilterExceptions(chatClientLoadFinish, "ChatClient.LoadingTickFinished");
        GUtil.FilterExceptions(groupLoadFinish, "GroupClient.LoadingTickFinished");
        GUtil.FilterExceptions(chatGuiLoadFinish, "ChatGui.LoadingTickFinished");
        GUtil.FilterExceptions(chatCtxLoadFinish, "ChatContextGui.LoadingTickFinished");
        GUtil.FilterExceptions(eventGuiLoadFinish, "EventBarGui.LoadingTickFinished");
        GUtil.FilterExceptions(featGuiLoadFinish, "FeatsWindowGui.LoadingTickFinished");
        GUtil.FilterExceptions(invGuiLoadFinish, "InventoryWindowGui.LoadingTickFinished");
        GUtil.FilterExceptions(bankGuiLoadFinish, "BankWindowGui.LoadingTickFinished");
        GUtil.FilterExceptions(diceGuiLoadFinish, "GamingTableDiceGUI.LoadingTickFinished");
        GUtil.FilterExceptions(achieveGuiLoadFinish, "AchievementsWindowGui.LoadingTickFinished");
        GUtil.FilterExceptions(trainerGuiLoadFinish, "TrainerWindowGui.LoadingTickFinished");
        GUtil.FilterExceptions(partyGuiLoadFinish, "PartyMembersGui.LoadingTickFinished");
        GUtil.FilterExceptions(pvpGuiLoadFinish, "PvpFlagsGui.LoadingTickFinished");
        GUtil.FilterExceptions(miniMapGuiLoadFinish, "MiniMapGui.LoadingTickFinished");
        GUtil.FilterExceptions(worldMapGuiLoadFinish, "MapWindowGui.LoadingTickFinished");
        GUtil.FilterExceptions(tradeGuiLoadFinish, "TradeWindowGui.LoadingTickFinished");
        GUtil.FilterExceptions(characterGuiLoadFinish, "CharacterWindowGui.LoadingTickFinished");
        GUtil.FilterExceptions(companySearchGuiLoadFinish, "CompanySearchWindowGui.LoadingTickFinished");
        GUtil.FilterExceptions(companyGuiLoadFinish, "CompanyWindowGui.LoadingTickFinished");
        GUtil.FilterExceptions(settingsGuiLoadFinish, "SettingsWindowGui.LoadingTickFinished");
        GUtil.FilterExceptions(auctionGuiLoadFinish, "AuctionHouseGui.LoadingTickFinished");
        GUtil.FilterExceptions(mapClientLoadFinish, "MapClient.LoadingTickFinished");
        GUtil.FilterExceptions(networkTick, "GNetworkService.SyncFixedUpdate");
        GUtil.FilterExceptions(targetingLoadFinish, "Targeting.LoadingTickFinished");
        GUtil.FilterExceptions(inputLoadFinish, "ClientInputManager.LoadingTickFinished");
        GUtil.FilterExceptions(buttonGuiLoadFinish, "ButtonBarGui.LoadingTickFinished");
        return true;
    }

    protected override void OnTickDestroyed()
    {
        if (NetworkClient.serverConnection != null)
        {
            GUtil.FilterExceptions(netShutdown, "GNetworkService.Shutdown");
        }
        GUtil.FilterExceptions(entityShutdown, "EntityDataClient.Shutdown");
        GUtil.FilterExceptions(terrainShutdown, "TerrainClient.Shutdown");
        GUtil.FilterExceptions(staticDataShutdown, "StaticDataService.Shutdown");
        GUtil.FilterExceptions(slaveShutdown, "SlavedProxyClient.Shutdown");
        GLog.StopFileLog();
    }

    private bool PrepareSyncFixedUpdate()
    {
        LoadingMessageGUI.UpdateLoadingStatus(false, "Client loading complete.");
        BundleService.UnloadBundle("Client", false);
        GLog.ActivateFileLog("Client");
        return true;
    }

    private bool StartServices()
    {
        this.TickLoadingMessage("Initialize");
        this.serverSceneReceived = false;
        ServiceList.StartOnce(typeof(StaticDataService), new object[] { true });
        ServiceList.StartOnce(typeof(BundleService), new object[0]);
        ServiceList.StartOnce(typeof(CombatCore), new object[0]);
        ServiceList.StartOnce(typeof(CombatClient), new object[0]);
        ServiceList.StartOnce(typeof(ChatClient), new object[0]);
        ServiceList.StartOnce(typeof(CommandClient), new object[0]);
        ServiceList.StartOnce(typeof(DebugClient), new object[0]);
        ServiceList.StartOnce(typeof(EncounterClient), new object[0]);
        ServiceList.StartOnce(typeof(SlavedProxyClient), new object[0]);
        ServiceList.StartOnce(typeof(FxService), new object[0]);
        ServiceList.StartOnce(typeof(InventoryClient), new object[0]);
        ServiceList.StartOnce(typeof(MovementClient), new object[0]);
        ServiceList.StartOnce(typeof(CraftingClient), new object[0]);
        ServiceList.StartOnce(typeof(GroupClient), new object[0]);
        EntityDataClient.SyncStart();
        PlayerConnectionClient.StartGame();
        return true;
    }

    private bool SyncFixedUpdate()
    {
        GUtil.FilterExceptions(staticDataTick, "StaticDataService.SyncFixedUpdate");
        GUtil.FilterExceptions(entityCoreTick, "EntityCore.SyncFixedUpdate");
        GUtil.FilterExceptions(combatCoreTick, "CombatCore.ClientCombatTick");
        if (EntityMotion.singleton != null)
        {
            GUtil.FilterExceptions(entityMotionTick, "EntityMotion.SyncFixedUpdate");
        }
        GUtil.FilterExceptions(combatClientSyncFixedUpdate, "CombatClient.SyncFixedUpdate");
        GUtil.FilterExceptions(graphicsTick, "GraphicsClient.SyncFixedUpdate");
        GUtil.FilterExceptions(bundleTick, "BundleService.SyncFixedUpdate");
        GUtil.FilterExceptions(sceneTick, "SceneService.SyncFixedUpdate");
        GUtil.FilterExceptions(playerEntityTick, "PlayerEntityClient.SyncFixedUpdate");
        GUtil.FilterExceptions(networkTick, "GNetworkService.SyncFixedUpdate");
        GUtil.FilterExceptions(slaveTick, "SlavedProxyClient.SyncFixedUpdate");
        GUtil.FilterExceptions(entityTick, "EntityData.SyncFixedUpdate");
        GUtil.FilterExceptions(craftingSyncFixedUpdate, "CraftingClient.SyncFixedUpdate");
        GUtil.FilterExceptions(eventGuiTick, "EventBarGui.SyncFixedUpdate");
        GUtil.FilterExceptions(questGiverTick, "QuestGiverGui.SyncFixedUpdate");
        GUtil.FilterExceptions(trainerGuiTick, "TrainerWindowGui.SyncFixedUpdate");
        GUtil.FilterExceptions(partyGuiTick, "PartyMembersGui.SyncFixedUpdate");
        GUtil.FilterExceptions(pvpGuiTick, "PvpFlagsGui.SyncFixedUpdate");
        GUtil.FilterExceptions(terrainTick, "TerrainService.SyncFixedUpdate");
        GUtil.FilterExceptions(terrainClientTick, "TerrainClient.SyncFixedUpdate");
        GUtil.FilterExceptions(groupClient, "GroupClient.SyncFixedUpdate");
        GUtil.FilterExceptions(settingsGuiTick, "SettingsWindowGui.SyncFixedUpdate");
        GUtil.FilterExceptions(auctionGuiTick, "AuctionHouseGui.SyncFixedUpdate");
        GUtil.FilterExceptions(companyGuiTick, "CompanyWindowGui.SyncFixedUpdate");
        GUtil.FilterExceptions(entityLost, "EntityDataClient.CheckLostPlayerIssue");
        return false;
    }

    private void SyncUpdate()
    {
        GUtil.FilterExceptions(resourceTick, "ResourceManager.SyncUpdate");
        GUtil.FilterExceptions(craftingSyncUpdate, "CraftingWindow.SyncUpdate");
        GUtil.FilterExceptions(uiTick, "UIClient.SyncUpdate");
        GUtil.FilterExceptions(inputTick, "ClientInputManager.SyncUpdate");
        GUtil.FilterExceptions(combatClientSyncUpdate, "CombatClient.SyncUpdate");
        GUtil.FilterExceptions(fxTick, "FxService.SyncUpdate");
        GUtil.FilterExceptions(targetingTick, "Targeting.SyncUpdate");
        GUtil.FilterExceptions(playerGuiTick, "PlayerBarGui.SyncUpdate");
        GUtil.FilterExceptions(buttonGuiTick, "ButtonBarGui.SyncUpdate");
        GUtil.FilterExceptions(miniMapGuiTick, "MiniMapGui.SyncUpdate");
        GUtil.FilterExceptions(worldMapGuiTick, "MapWindowGui.SyncUpdate");
        GUtil.FilterExceptions(mergeJobTick, "MergeJobService.SyncUpdate");
        GUtil.FilterExceptions(debugClientTick, "DebugClient.SyncUpdate");
        GUtil.FilterExceptions(lootWindowTick, "LootWindowGui.SyncUpdate");
    }

    private void TickLoadingMessage(string message)
    {
        if (LoadingMessageGUI.singleton != null)
        {
            LoadingMessageGUI.UpdateLoadingStatus(true, message);
            GUtil.FilterExceptions(new GUtil.BoolFilterDelegate(LoadingMessageGUI.singleton.SyncFixedUpdate), "LoadingMessageGUI.SyncFixedUpdate");
        }
    }

    private bool WaitForCharacterLoad()
    {
        this.TickLoadingMessage("Waiting for character");
        GUtil.FilterExceptions(networkTick, "GNetworkService.SyncFixedUpdate");
        return !object.ReferenceEquals(EntityDataClient.owner, null);
    }

    private bool WaitForEnvironmentLoad()
    {
        this.TickLoadingMessage("Loading terrain");
        GUtil.FilterExceptions(bundleTick, "BundleService.SyncFixedUpdate");
        GUtil.FilterExceptions(sceneTick, "SceneService.SyncFixedUpdate");
        GUtil.FilterExceptions(networkTick, "GNetworkService.SyncFixedUpdate");
        if (TerrainService.InUse)
        {
            GUtil.FilterExceptions(terrainTick, "TerrainService.SyncFixedUpdate");
            return TerrainService.InitialTerrainLoaded;
        }
        return (UnityEngine.Object.FindObjectsOfType(typeof(PlayerSpawn)).Length > 0);
    }

    private bool WaitForSceneName()
    {
        this.TickLoadingMessage("Waiting for server location");
        GUtil.FilterExceptions(sceneTick, "SceneService.SyncFixedUpdate");
        GUtil.FilterExceptions(networkTick, "GNetworkService.SyncFixedUpdate");
        return this.serverSceneReceived;
    }
}

