﻿using System;

public class AboutWindowGui : WindowGui
{
    public static AboutWindowGui singleton;

    public void Awake()
    {
        singleton = this;
    }

    public override void OnDestroy()
    {
        base.OnDestroy();
        singleton = null;
    }

    public void Start()
    {
        base.Init(2, true);
    }
}

