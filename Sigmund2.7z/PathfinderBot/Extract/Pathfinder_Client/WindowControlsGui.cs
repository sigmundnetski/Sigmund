﻿using GNGUI;
using System;
using UnityEngine;

public class WindowControlsGui : MonoBehaviour
{
    private UIImageButton closeButton;
    private UIImageButton restoreButton;

    private void CloseClicked(GameObject go)
    {
        UIClient.LogOut(UIClient.DisconnectType.QUIT);
    }

    private void RestoreClicked(GameObject go)
    {
        SettingsHelper.SetWindowed(true);
    }

    public void Start()
    {
        foreach (UIImageButton button in base.GetComponentsInChildren<UIImageButton>())
        {
            if (button.name == "CloseButton")
            {
                this.closeButton = button;
            }
            else if (button.name == "RestoreButton")
            {
                this.restoreButton = button;
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find a menu button.", new object[] { this.closeButton, this.restoreButton });
        UIEventListener listener1 = UIEventListener.Get(this.closeButton.gameObject);
        listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.CloseClicked));
        UIEventListener listener2 = UIEventListener.Get(this.restoreButton.gameObject);
        listener2.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener2.onClick, new UIEventListener.VoidDelegate(this.RestoreClicked));
    }

    public void Update()
    {
        if (!(!NGUITools.GetActive(base.gameObject) || Screen.fullScreen))
        {
            NGUITools.SetActive(base.gameObject, false);
        }
        else if (!(NGUITools.GetActive(base.gameObject) || !Screen.fullScreen))
        {
            NGUITools.SetActive(base.gameObject, true);
        }
    }
}

