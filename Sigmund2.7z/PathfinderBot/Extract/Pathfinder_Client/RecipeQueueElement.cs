﻿using GNetwork;
using GNGUI;
using System;
using System.Text;
using UnityEngine;

public class RecipeQueueElement : MonoBehaviour
{
    private UIImageButton cancelBtn;
    private bool eventsSet = false;
    private bool isFirst;
    private UILabel mainLabel;
    private CraftingQueue myData = new CraftingQueue();
    private int myQueueIndex;
    private UIFilledSprite progressBar;
    private UILabel timeLabel;

    private void OnCancel(GameObject go)
    {
        CraftingClient.Cancel(this.myQueueIndex, this.myData);
    }

    private void OnTooltip(GameObject go, bool show)
    {
        if (!show)
        {
            CraftingWindow.singleton.ShowTooltip(null, null);
        }
        else
        {
            BaseRecipeData data;
            StringBuilder quickText = GUtil.GetQuickText();
            if (BaseRecipeData.recipeById.TryGetValue(this.myData.rId, out data))
            {
                double num = (this.myData.upg + data.outputUpgrade) + data.GetSkillUpgradeAdjustment(EntityDataClient.owner);
                BasicItemData data2 = ItemDatabase.GetItem(data.outputItemId);
                InventoryItem item = new InventoryItem(data2.id, data.outputQty, (byte) num, data2.durability);
                InventoryClient.GetColoredItemDisplayName(ref quickText, item);
                quickText.Append(" - ");
            }
            else
            {
                quickText.Append("<INVALID ITEM>");
            }
            quickText.Append(this.TimeRemainingString());
            CraftingWindow.singleton.ShowTooltip(quickText.ToString(), go);
        }
    }

    public void SetData(bool isFirst_, int queueIndex, CraftingQueue data)
    {
        BaseRecipeData data2;
        if (this.cancelBtn == null)
        {
            this.cancelBtn = base.transform.GetComponentInChildren<UIImageButton>();
        }
        if (this.progressBar == null)
        {
            this.progressBar = base.transform.GetComponentInChildren<UIFilledSprite>();
        }
        if ((this.mainLabel == null) && (this.timeLabel == null))
        {
            foreach (UILabel label in base.GetComponentsInChildren<UILabel>())
            {
                if (label.name == "RecipeQueueLabel")
                {
                    this.mainLabel = label;
                }
                else if (label.name == "TimeLabel")
                {
                    this.timeLabel = label;
                }
            }
        }
        if (!this.eventsSet)
        {
            UIEventListener listener1 = UIEventListener.Get(this.cancelBtn.gameObject);
            listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.OnCancel));
            UIEventListener listener2 = UIEventListener.Get(this.progressBar.gameObject);
            listener2.onTooltip = (UIEventListener.BoolDelegate) Delegate.Combine(listener2.onTooltip, new UIEventListener.BoolDelegate(this.OnTooltip));
            this.eventsSet = true;
        }
        this.isFirst = isFirst_;
        this.myQueueIndex = queueIndex;
        data.DataCopyTo(ref this.myData, 0xff);
        base.gameObject.name = queueIndex.ToString("D4");
        if (BaseRecipeData.recipeById.TryGetValue(data.rId, out data2))
        {
            double num = (this.myData.upg + data2.outputUpgrade) + data2.GetSkillUpgradeAdjustment(EntityDataClient.owner);
            BasicItemData data3 = ItemDatabase.GetItem(data2.outputItemId);
            InventoryItem item = new InventoryItem(data3.id, data2.outputQty, (byte) num, data3.durability);
            this.mainLabel.text = InventoryClient.GetColoredItemDisplayName(item);
        }
        else
        {
            this.mainLabel.text = "<Invalid Recipe>";
        }
        if (this.isFirst)
        {
            this.SyncUpdate();
        }
        else
        {
            this.progressBar.fillAmount = 0f;
        }
    }

    public void SyncUpdate()
    {
        if (this.isFirst)
        {
            DateTime time = DateTime.FromBinary(EntityDataClient.owner.playerRecord.baseCraftBinary);
            TimeSpan span = (TimeSpan) (GNetworkService.ServerUtc - time);
            this.progressBar.fillAmount = (float) (span.TotalSeconds / this.myData.drn);
        }
        this.timeLabel.text = this.TimeRemainingString() + " remaining";
    }

    private string TimeRemainingString()
    {
        TimeSpan span = TimeSpan.FromSeconds(this.myData.drn);
        if (this.isFirst)
        {
            DateTime time2 = DateTime.FromBinary(EntityDataClient.owner.playerRecord.baseCraftBinary) + span;
            span = (TimeSpan) (time2 - GNetworkService.ServerUtc);
        }
        if (span.TotalSeconds <= 10.0)
        {
            return "(very soon!)";
        }
        if (span.TotalSeconds <= 120.0)
        {
            return (span.TotalSeconds.ToString("F0") + " seconds");
        }
        if (span.TotalMinutes <= 120.0)
        {
            return (span.TotalMinutes.ToString("F0") + " minutes");
        }
        if (span.TotalHours <= 48.0)
        {
            return (span.TotalHours.ToString("F0") + " hours");
        }
        return (span.TotalDays.ToString("F0") + " days");
    }
}

