﻿using GNGUI;
using System;
using UnityEngine;

public class PartyPlayerGui : CharacterBarGui
{
    private UISprite background;
    private const string DEFAULT_BACKGROUND_SPRITE = "panel_party_wide";
    private bool isTargeted = false;
    private UILabel nameLabel;
    private UISprite partyLeader;
    [NonSerialized, HideInInspector]
    public uint playerId;
    private bool prevKnownEntity = true;
    [NonSerialized, HideInInspector]
    public EntityId prevTargetedEntityId = EntityId.INVALID_ID;
    private const string TARGETED_BACKGROUND_SPRITE = "panel_party_wide_target";

    public override void Awake()
    {
        this.nameLabel = base.GetComponentInChildren<UILabel>();
        foreach (UISprite sprite in base.GetComponentsInChildren<UISprite>())
        {
            if (sprite.name == "Background")
            {
                this.background = sprite;
            }
            else if (sprite.name == "PartyLeader")
            {
                this.partyLeader = sprite;
            }
        }
        GuiHelper.GuiAssertNotNull("Something's null...", new object[] { this.nameLabel, this.background, this.partyLeader });
        this.background.spriteName = "panel_party_wide";
        base.Awake();
    }

    public void DoTarget(GameObject go)
    {
        Entity entityByPlayerId = EntityCore.GetEntityByPlayerId(this.playerId);
        if (entityByPlayerId != null)
        {
            Targeting.SelectTarget(entityByPlayerId.gameObject);
        }
    }

    public override void SetName(string name, Conning.Strength ignored)
    {
        this.nameLabel.text = name;
    }

    public override void SetPower(float powerPercentage, int power)
    {
    }

    public override void SetStamina(float staminaPercentage, int stamina)
    {
    }

    private void ShowCombatInfo(bool active)
    {
        int num;
        for (num = 0; num < base.hitPointBars.Length; num++)
        {
            NGUITools.SetActive(base.hitPointBars[num].gameObject, active);
        }
        for (num = 0; num < base.buffRibbons.Length; num++)
        {
            NGUITools.SetActive(base.buffRibbons[num].gameObject, active);
        }
    }

    public void SyncFixedUpdate(uint id, string name, bool isLeader)
    {
        if (this.playerId != id)
        {
            this.playerId = id;
            this.SetName(name, Conning.Strength.Normal);
        }
        this.UpdateDisplay(isLeader);
    }

    public void UpdateDisplay(bool isLeader)
    {
        Entity entityByPlayerId = EntityCore.GetEntityByPlayerId(this.playerId);
        bool flag = entityByPlayerId != null;
        if (flag != this.prevKnownEntity)
        {
            if (flag)
            {
                this.ShowCombatInfo(true);
            }
            else
            {
                this.ShowCombatInfo(false);
            }
            this.prevKnownEntity = flag;
        }
        if (isLeader != NGUITools.GetActive(this.partyLeader.gameObject))
        {
            NGUITools.SetActive(this.partyLeader.gameObject, isLeader);
        }
        if (entityByPlayerId == null)
        {
            this.isTargeted = false;
            this.background.spriteName = "panel_party_wide";
            this.prevTargetedEntityId = EntityId.INVALID_ID;
        }
        else if (!EntityCore.Match(Targeting.selectedEntityId, this.prevTargetedEntityId))
        {
            if (EntityCore.Match(entityByPlayerId.entityId, Targeting.selectedEntityId))
            {
                this.isTargeted = true;
                this.background.spriteName = "panel_party_wide_target";
            }
            else if (this.isTargeted)
            {
                this.isTargeted = false;
                this.background.spriteName = "panel_party_wide";
            }
            this.prevTargetedEntityId = Targeting.selectedEntityId;
        }
        if (flag)
        {
            this.SyncUpdateCv(entityByPlayerId.combat);
        }
    }
}

