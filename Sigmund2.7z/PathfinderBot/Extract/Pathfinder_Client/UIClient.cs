﻿using GNetwork;
using GNGUI;
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;
using UnityEngine;

public static class UIClient
{
    private static ScalingType currentScale = ScalingType.DEFAULT;
    public static DisconnectType dcType = DisconnectType.LOG_OUT;
    private const int DEFAULT_MAX_HEIGHT = 0x600;
    private const int DEFAULT_MIN_HEIGHT = 320;
    private const float DEFAULT_NUMBER_TIME = 3f;
    private const float DEFAULT_TEXT_TIME = 5f;
    public static readonly string[] desiredGUIPrefabs = new string[] { 
        "AchievementItem", "AchievementsWindow", "BuffSprite", "ChannelGridItem", "CharSheetSkill", "CombatText", "CompanyAllyInfo", "CompanyDetailsGoal", "CompanyDetailsPlayerInfo", "CompanyHoldingsInfo", "CompanySearchItem", "EventBarItem", "FeatGridItem", "FlagDetailsGui", "FlagIcon", "GamingTableDie", 
        "GoblinCamera", "GoblinAudio", "HexBoundaryWall", "InventoryItemRClick", "InventoryListItem", "LevinBrand", "LootItem", "LootWindow", "MapItem", "PartyPlayerGui", "RecipeGridRow", "RedeemGridItem", "RedeemWindow", "SelfCombatText", "TrainerListItem", "TradeItem", 
        "TreasureBoxGridItem", "TreasureBoxSelectorGui", "AuctionSearchItem", "AuctionWindowBackground", "MarketItem", "OrderBidItem", "ShortInventoryItem", "CraftingWindow", "CraftingWindowBackground", "RecipeInputElement", "RecipeNameElement", "RecipeQueueElement", "QuestGiverGui", "QuestTab", "QuestLogGui", "QuestLogItem", 
        "TextBlobGui", "CharacterSheet", "CompanySearchWindow", "FeatsWindow", "InventoryWindow", "ItemQtyGui", "MapWindow", "PaperdollWindow", "SettingsWindow", "TrainerWindow"
     };
    public static readonly string[] desiredMaterials = new string[] { "TerrainBumpDefault" };
    public static Dictionary<string, GameObject> guiPrefabs = new Dictionary<string, GameObject>();
    private static NguiAlphaLerper[] lerpsInProgress = new NguiAlphaLerper[10];
    public static Dictionary<string, Material> materialPrefabs = new Dictionary<string, Material>();
    public static Color NPC_CONVO_COLOR = Color.white;
    private const float TOOLTIP_DELAY = 0.5f;
    public static readonly string[] UI_SCALE_NAMES = new string[] { "Largest", "Large", "Default", "Small", "Smallest" };
    private static readonly float[] UI_SCALES = new float[] { 0.5f, 0.75f, 1f, 1.25f, 1.5f };

    public static void AddOverheadNumber(GameObject entityGO, Color color, int amount, float duration = 3f)
    {
        EntityLoadClient.GetOverheadHudText(entityGO).Add(amount, color, duration);
    }

    public static void AddOverheadText(GameObject entityGO, Color color, string message, float duration = 5f)
    {
        EntityLoadClient.GetOverheadHudText(entityGO).Add(message, color, duration);
    }

    public static void AlphaLerp(GameObject parent, float from, float to, float duration, GameObject[] ignored = null)
    {
        SparseArray.Add<NguiAlphaLerper>(ref lerpsInProgress, new NguiAlphaLerper(parent, from, to, duration, ignored));
    }

    public static void CancelAlphaLerp(GameObject parent, float setAlpha, GameObject[] ignored = null)
    {
        for (int i = 0; i < lerpsInProgress.Length; i++)
        {
            if ((lerpsInProgress[i] != null) && (lerpsInProgress[i].parent == parent))
            {
                lerpsInProgress[i] = null;
                break;
            }
        }
        NguiAlphaLerper lerper = new NguiAlphaLerper(parent, setAlpha, 0f, 0f, ignored);
    }

    public static bool ClientTick_LoadingTickFinished()
    {
        Camera camera = NGUITools.FindCameraForLayer(8);
        GuiHelper.GuiAssertNotNull("Could not find NGUI's camera.", new object[0]);
        UICamera component = camera.GetComponent<UICamera>();
        GuiHelper.GuiAssertNotNull("NGUI camera " + camera.name + " does not have UICamera component!", new object[] { component });
        component.tooltipDelay = 0.5f;
        return true;
    }

    public static void DisplayOverheadOrChat(Color color, string message)
    {
        if (WindowGuiUtils.IsFullscreenWindowActive)
        {
            ChatGui.singleton.DisplayMessage(message, color);
        }
        else
        {
            AddOverheadText(EntityDataClient.owner.gameObject, color, message, 5f);
        }
    }

    public static bool ExtractBundles()
    {
        foreach (string str in desiredGUIPrefabs)
        {
            guiPrefabs[str] = BundleService.Load<GameObject>(BundleConsts.GUI_BUNDLE, str);
        }
        foreach (Material material in BundleService.LoadAll<Material>(BundleConsts.GUI_BUNDLE))
        {
            materialPrefabs[material.name] = material;
        }
        return true;
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void GenericErrorMessage(string message)
    {
        ChatGui.singleton.DisplayMessage(message, ChatClient.ERROR_COLOR);
    }

    public static void LogOut(DisconnectType discType)
    {
        if (NetworkClient.serverConnection == null)
        {
            Application.Quit();
        }
        else
        {
            if (PlayerBarGui.singleton != null)
            {
                PlayerBarGui.singleton.LogOut();
            }
            NetworkClient.serverConnection.Disconnect("Log Out");
            dcType = discType;
        }
    }

    public static void OnDisconnectedFromServer()
    {
        switch (dcType)
        {
            case DisconnectType.SWITCH:
                dcType = DisconnectType.LOG_OUT;
                break;

            case DisconnectType.LOG_OUT:
                if ((ClientTickMono.singleton != null) || (CharacterSelectTickMono.singleton != null))
                {
                    SceneService.LoadBySceneID(SceneService.SceneID.Client_ClientLoginGUI, false);
                }
                break;

            case DisconnectType.QUIT:
                if (Application.isEditor)
                {
                    GLog.LogError(new object[] { "Cannot quit from Editor!" });
                    GLog.LogWarning(new object[] { "Push the Play button yourself." });
                    GLog.Log(new object[] { "You're now disconnected from the server. Sorry." });
                    DebugClient.DisplayDebugMessage("Cannot quit from Editor! You're now disconnected from the server.");
                }
                Application.Quit();
                break;

            default:
                GLog.Log(new object[] { "Unknow disconnect reason:", dcType, ". Quitting client app." });
                Application.Quit();
                break;
        }
    }

    public static string ParseReplacementWords(string message, Entity playerEntity, Entity sourceEntity, Entity targetEntity)
    {
        StringBuilder quickText = GUtil.GetQuickText();
        quickText.Append(message);
        quickText.Replace("{playername}", (playerEntity != null) ? playerEntity.EntityName : "Someone");
        quickText.Replace("{sourcename}", (sourceEntity != null) ? sourceEntity.EntityName : "Someone");
        quickText.Replace("{targetname}", (targetEntity != null) ? targetEntity.EntityName : "Someone");
        return quickText.ToString();
    }

    public static void ScaleGui(string[] args, EntityId playerEntityId)
    {
        uint result = 2;
        bool flag = false;
        if ((args.Length >= 2) && (!uint.TryParse(args[1], out result) || (result > UI_SCALES.Length)))
        {
            result = 2;
            flag = true;
        }
        ScalingType output = (ScalingType) result;
        if ((args.Length >= 2) && flag)
        {
            GUtil.TryParseEnum<ScalingType>(args[1].ToUpper(), ScalingType.DEFAULT, out output);
        }
        if (output == ScalingType.DEFAULT)
        {
            List<UIRoot> list = UIRoot.list;
            for (int i = 0; i < list.Count; i++)
            {
                list[i].minimumHeight = 320;
                list[i].maximumHeight = 0x600;
            }
        }
        currentScale = output;
    }

    private static void SyncStart()
    {
        BundleService.StartLoadingBundle(BundleConsts.GUI_BUNDLE, false);
        StaticDataService.RegisterCallback<ColorData>(new StaticDataService.StaticDataServiceCallback(UIClient.UpdateColors));
    }

    public static bool SyncUpdate()
    {
        int num3;
        if (currentScale != ScalingType.DEFAULT)
        {
            float num = UI_SCALES[(int) ((IntPtr) currentScale)];
            int num2 = (int) Math.Round((double) (Screen.height * num));
            List<UIRoot> list = UIRoot.list;
            for (num3 = 0; num3 < list.Count; num3++)
            {
                list[num3].minimumHeight = num2;
                list[num3].maximumHeight = num2;
            }
        }
        for (num3 = 0; num3 < lerpsInProgress.Length; num3++)
        {
            if ((lerpsInProgress[num3] != null) && lerpsInProgress[num3].Update())
            {
                lerpsInProgress[num3] = null;
            }
        }
        return true;
    }

    public static void UpdateColors(List<DataClass> ignored)
    {
        NPC_CONVO_COLOR = ColorData.GetColorByName("npc_overhead_convo", true);
    }

    public enum DisconnectType
    {
        SWITCH,
        LOG_OUT,
        QUIT
    }

    public enum ScalingType : uint
    {
        DEFAULT = 2,
        LARGER = 1,
        LARGEST = 0,
        SMALLER = 3,
        SMALLEST = 4
    }
}

