﻿using GNGUI;
using System;
using UnityEngine;

public abstract class DraggableTabListItem : TabListItem
{
    protected bool isBeingDragged = false;
    protected Transform parent;
    protected bool showingTooltip = false;

    protected DraggableTabListItem()
    {
    }

    public override void Awake()
    {
        base.Awake();
        UIDragObject componentInChildren = base.GetComponentInChildren<UIDragObject>();
        GuiHelper.GuiAssertNotNull("Couldn't find drag script.", new object[] { componentInChildren });
        componentInChildren.dragEffect = UIDragObject.DragEffect.None;
    }

    public virtual void OnDrag(Vector2 delta)
    {
        if (!this.isBeingDragged)
        {
            this.isBeingDragged = true;
            this.OnDragStart();
            this.parent = base.transform.parent;
            GuiHelper.Reparent(base.gameObject, DragDropRoot.root);
        }
    }

    public virtual void OnDragEnd()
    {
    }

    public virtual void OnDragStart()
    {
    }

    public virtual void OnPress(bool isPressed)
    {
        Collider collider = base.collider;
        if (collider != null)
        {
            collider.enabled = !isPressed;
        }
        if (!(isPressed || !this.isBeingDragged))
        {
            this.isBeingDragged = false;
            this.OnDragEnd();
            GuiHelper.Reparent(base.gameObject, this.parent);
        }
    }
}

