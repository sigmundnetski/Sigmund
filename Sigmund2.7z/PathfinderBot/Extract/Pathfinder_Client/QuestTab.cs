﻿using GNGUI;
using System;
using UnityEngine;

public class QuestTab : MonoBehaviour
{
    private bool onClickSet = false;
    public int questId = 0;
    private UILabel title = null;

    public void SetQuestId(int _questId)
    {
        QuestData data;
        this.questId = _questId;
        if (this.title == null)
        {
            this.title = base.transform.FindChild("Label").GetComponent<UILabel>();
        }
        if (QuestData.questById.TryGetValue(this.questId, out data))
        {
            base.gameObject.name = this.title.text = data.displayName;
        }
        else
        {
            this.title.text = "<Invalid Quest " + this.questId + ">";
        }
        if (!this.onClickSet)
        {
            UIEventListener listener1 = UIEventListener.Get(base.gameObject);
            listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(QuestGiverGui.singleton.OnTabClicked));
            this.onClickSet = true;
        }
    }
}

