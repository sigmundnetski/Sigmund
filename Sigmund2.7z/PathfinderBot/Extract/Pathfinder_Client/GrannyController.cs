﻿using System;
using System.IO;
using UnityEngine;

public class GrannyController : AnimController
{
    private string activeElementName = string.Empty;
    private int aiDrawNumber = -2;
    protected GrannyAnimator anim;
    protected Params animParams = null;
    private int attackId = 0;
    private float attackStartTime = float.PositiveInfinity;
    private int currentWeaponAnimSet = 1;
    private int debugLoopAttack = -1;
    private bool fakeMovement = false;
    private bool initAttack = false;
    private float INSTASTOP_TRANSITION_TIME = 0.101f;
    private bool inTransition = true;
    private readonly string[] jumpStates = new string[] { "blendedCharacter::WholeCharacter::idles->jump0", "blendedCharacter::WholeCharacter::walks->jump0", "blendedCharacter::WholeCharacter::runs->jump0", "blendedCharacter::WholeCharacter::jumps->jump0", "blendedCharacter::WholeCharacter::jump0", "blendedCharacter::WholeCharacter::jump0->jump1", "blendedCharacter::WholeCharacter::jump1", "blendedCharacter::WholeCharacter::jump1->jump2", "blendedCharacter::WholeCharacter::jump2", "blendedCharacter::WholeCharacter::jump2->idles", "blendedCharacter::WholeCharacter::jump2->walks", "blendedCharacter::WholeCharacter::jump2->runs", "blendedCharacter::WholeCharacter::jump2->jumps" };
    private int mainhandCategoryId = 0;
    private bool moving = false;
    private int nonCombatAnimSet = 0;
    private int offhandCategoryId = 0;
    private float prevNormSpeed = 0f;
    private float prevSmoothForward = 0f;
    private float subHighLerpStartTime = 0f;
    private const float UPPER_BODY_LERP_DURATION_SEC = 0.25f;

    public GrannyController(GameObject go)
    {
        this.anim = go.GetComponent<GrannyAnimator>();
        if (this.anim == null)
        {
            throw new MissingComponentException(string.Concat(new object[] { base.GetType(), " on '", go.name, "' requires GrannyAnimator component!" }));
        }
        if (!File.Exists(this.anim.targetRigFile))
        {
            GLog.LogError(new object[] { this.anim.name + ": Rig file does not exist:", this.anim.targetRigFile });
        }
        if (!File.Exists(this.anim.machineFile))
        {
            GLog.LogError(new object[] { this.anim.name + ": Machine file does not exist:", this.anim.machineFile });
        }
        this.InitDebug();
    }

    public override bool AbleToJump()
    {
        return (!this.InJumpStates() && !this.inTransition);
    }

    protected override void AssertInit()
    {
        base.AssertInit();
        if (!this.animParams.valid)
        {
            throw new Exception(string.Concat(new object[] { base.GetType(), " does not have valid param IDs from ", this.anim.GetType(), "!" }));
        }
    }

    public override void DebugLoopAttack(int attackToLoop, string animSet)
    {
        int animationSetId = this.anim.GetAnimationSetId(animSet);
        if (animationSetId < 0)
        {
            GLog.LogError(new object[] { this.anim.name + ": Granny does not know about anim set:", animSet });
        }
        else
        {
            this.anim.ChangeAnimationSet(animationSetId);
        }
        this.debugLoopAttack = attackToLoop;
    }

    public void InitDebug()
    {
        base.debugAnimOutput = new object[15, 2];
        base.debugAnimOutput[0, 0] = " Speed:";
        base.debugAnimOutput[1, 0] = " Speed Turn:";
        base.debugAnimOutput[2, 0] = " Velocity Z:";
        base.debugAnimOutput[3, 0] = " Velocity X:";
        base.debugAnimOutput[4, 0] = " Jump State:";
        base.debugAnimOutput[5, 0] = " Attack Type:";
        base.debugAnimOutput[6, 0] = " Draw Stow Type:";
        base.debugAnimOutput[7, 0] = " Crowd Control:";
        base.debugAnimOutput[8, 0] = " Crowd Control Type:";
        base.debugAnimOutput[9, 0] = " Death Type:";
        base.debugAnimOutput[10, 0] = " Layer Override:";
        base.debugAnimOutput[11, 0] = " Transitioning?";
        base.debugAnimOutput[12, 0] = " Whole Body Element:";
        base.debugAnimOutput[13, 0] = " Upper Body Element:";
        base.debugAnimOutput[14, 0] = " Anim Set:";
        base.debugAnimInput = new object[6, 2];
        base.debugAnimInput[0, 0] = " Speed:";
        base.debugAnimInput[1, 0] = " Forward:";
        base.debugAnimInput[2, 0] = " Strafe:";
        base.debugAnimInput[3, 0] = " Rotate:";
        base.debugAnimInput[4, 0] = " Attack:";
        base.debugAnimInput[5, 0] = " Events Triggered:";
    }

    public override void Initialize(Entity entity)
    {
        if (!base.initialized)
        {
            this.Start();
        }
        if (!((entity.combat == null) || string.IsNullOrEmpty(entity.combat.combatClass.idleAnimSetName)))
        {
            this.SetNpcAnimSets(entity.combat.combatClass.idleAnimSetName, entity.combat.combatClass.combatAnimSetName);
            this.aiDrawNumber = entity.combat.combatClass.drawAnimNumber;
        }
        else if (entity.combat != null)
        {
            CombatWeapon weapon = entity.combat.GetWeapon(CombatClassVars.LogicalHand.MAIN_HAND);
            this.mainhandCategoryId = (weapon != null) ? weapon.weaponCategoryId : 0;
            CombatWeapon weapon2 = entity.combat.GetWeapon(CombatClassVars.LogicalHand.OFF_HAND);
            this.offhandCategoryId = (weapon2 != null) ? weapon2.weaponCategoryId : 0;
            this.SetWeaponAnimSet(this.mainhandCategoryId, this.offhandCategoryId);
            this.SetNonCombatSet();
        }
        else
        {
            this.SetNonCombatSet();
        }
        if (((entity != null) && (entity.combat != null)) && entity.combat.inCombat)
        {
            this.anim.ChangeAnimationSet(this.currentWeaponAnimSet);
        }
        else
        {
            this.anim.ChangeAnimationSet(this.nonCombatAnimSet);
        }
    }

    public override bool InJumpStates()
    {
        for (int i = 0; i < this.jumpStates.Length; i++)
        {
            if (this.jumpStates[i] == this.activeElementName)
            {
                return true;
            }
        }
        return false;
    }

    public override void ProcessAttack(AnimationData attackAnim, bool useOffhand, bool isRooted, bool attackInterrupted, float currentTime, ref float attackEndTime)
    {
        this.UpdateDebugInput(5, 1, string.Empty);
        if (attackInterrupted)
        {
            this.anim.TriggerEvent(this.animParams.interruptEvent);
        }
        else if ((currentTime < attackEndTime) && !this.initAttack)
        {
            this.attackId = attackAnim.id;
            if (isRooted)
            {
                this.anim.TriggerEvent(this.animParams.instaStopEvent);
                this.UpdateDebugInput(5, 1, ((string) base.debugAnimInput[5, 1]) + "instaStop " + this.animParams.instaStopEvent);
                this.fakeMovement = true;
            }
            if ((attackAnim.id == MovementClient.DRAW.id) || (attackAnim.id == MovementClient.SWAP.id))
            {
                int num = this.SetDrawNum(this.mainhandCategoryId, this.offhandCategoryId);
                if (num > -1)
                {
                    string str = null;
                    if (attackAnim.id == MovementClient.DRAW.id)
                    {
                        this.anim.TriggerEvent(this.animParams.drawEvent);
                        str = "draw";
                    }
                    else if (attackAnim.id == MovementClient.SWAP.id)
                    {
                        this.anim.TriggerEvent(this.animParams.weaponSwapEvent);
                        str = "swap";
                    }
                    this.UpdateDebugInput(4, 1, attackAnim.name + ": #" + num);
                    this.UpdateDebugInput(5, 1, string.Concat(new object[] { (string) base.debugAnimInput[5, 1], str, " ", this.animParams.drawEvent }));
                }
                else if (this.aiDrawNumber == -2)
                {
                    GLog.LogWarning(new object[] { "There is no draw animation defined for weapon category IDs: ", this.mainhandCategoryId, this.offhandCategoryId });
                }
            }
            else if (attackAnim.id == MovementClient.STOW.id)
            {
                this.anim.SetInteger(this.animParams.drawStowType, 0);
                this.anim.TriggerEvent(this.animParams.stowEvent);
                this.UpdateDebugInput(4, 1, attackAnim.name + ": #0");
                this.UpdateDebugInput(5, 1, ((string) base.debugAnimInput[5, 1]) + "stow " + this.animParams.stowEvent);
            }
            else
            {
                if (useOffhand && (attackAnim.offhand > -1))
                {
                    this.anim.SetInteger(this.animParams.attackType, attackAnim.offhand);
                    this.anim.SetInteger(this.animParams.attackHand, 1);
                    this.UpdateDebugInput(4, 1, attackAnim.name + ": offhand #" + attackAnim.offhand);
                }
                else
                {
                    this.anim.SetInteger(this.animParams.attackType, attackAnim.mainhand);
                    this.anim.SetInteger(this.animParams.attackHand, 0);
                    this.UpdateDebugInput(4, 1, attackAnim.name + ": mainhand #" + attackAnim.mainhand);
                }
                this.anim.TriggerEvent(this.animParams.attackEvent);
                this.UpdateDebugInput(5, 1, ((string) base.debugAnimInput[5, 1]) + "attack " + this.animParams.attackEvent);
            }
            this.initAttack = true;
            this.attackStartTime = currentTime;
        }
        else if ((((currentTime < attackEndTime) && isRooted) && this.fakeMovement) && (currentTime > (this.attackStartTime + this.INSTASTOP_TRANSITION_TIME)))
        {
            this.fakeMovement = false;
        }
    }

    public override void ProcessCrowdControl(bool initialize, float animNum, float ccLength)
    {
        this.anim.SetInteger(this.animParams.crowdControlled, 1);
        this.anim.SetInteger(this.animParams.crowdControlType, (int) animNum);
    }

    public override void ProcessGather()
    {
        this.anim.SetInteger(this.animParams.harvestType, 1);
    }

    public override void ProcessTurn(bool turning, Transform transform, float rotate, float yawTarget, float yawDeltaAbs)
    {
    }

    public override void ResetAllAnimInputs()
    {
        if (this.animParams.valid)
        {
            this.animParams.Reset(this.anim);
        }
    }

    public override void ResetAttack(int prevAttackId)
    {
        this.UpdateDebugInput(4, 1, string.Empty);
        if ((prevAttackId == MovementClient.DRAW.id) || (prevAttackId == MovementClient.SWAP.id))
        {
            this.anim.ChangeAnimationSet(this.currentWeaponAnimSet);
        }
        else if (prevAttackId == MovementClient.STOW.id)
        {
            this.anim.ChangeAnimationSet(this.nonCombatAnimSet);
        }
        this.initAttack = false;
        this.attackStartTime = float.PositiveInfinity;
        this.fakeMovement = false;
        this.attackId = 0;
    }

    public override void ResetCrowdControl()
    {
        this.anim.SetInteger(this.animParams.crowdControlled, 0);
        this.anim.SetInteger(this.animParams.crowdControlType, 0);
    }

    public override void ResetGather()
    {
        this.anim.SetInteger(this.animParams.harvestType, 0);
    }

    public override void ResetJump()
    {
        this.anim.SetInteger(this.animParams.jumpState, 0);
    }

    private int SetDrawNum(int mainCatId, int offCatId)
    {
        int drawAnimNumber;
        if (this.aiDrawNumber == -2)
        {
            if (mainCatId == 0)
            {
                drawAnimNumber = 0;
            }
            else
            {
                string mainhand = string.Empty;
                string offhand = string.Empty;
                if (mainCatId != 0)
                {
                    mainhand = WeaponCategoryData.categoriesById[mainCatId].name;
                }
                if (offCatId != 0)
                {
                    offhand = WeaponCategoryData.categoriesById[offCatId].name;
                }
                drawAnimNumber = AnimSuiteData.GetByNames(mainhand, offhand).drawAnimNumber;
            }
        }
        else
        {
            drawAnimNumber = this.aiDrawNumber;
        }
        if (drawAnimNumber > -1)
        {
            this.anim.SetInteger(this.animParams.drawStowType, drawAnimNumber);
        }
        return drawAnimNumber;
    }

    public override void SetMovement(float rawTotalSpeed, float rawForwardSpeed, float rawStrafeSpeed, float rawForward, float rawStrafe, float rawRotate, float smoothForward, float smoothStrafe, float smoothRotate)
    {
        float prevNormSpeed = 0f;
        if (rawTotalSpeed > 0f)
        {
            prevNormSpeed = Mathf.Clamp01((rawTotalSpeed - MovementData.singleton.minForwardSpeed) / (MovementData.singleton.maxForwardSpeed - MovementData.singleton.minForwardSpeed));
        }
        else if (rawTotalSpeed < 0f)
        {
            prevNormSpeed = Mathf.Clamp01((-rawTotalSpeed - MovementData.singleton.minBackwardSpeed) / (MovementData.singleton.maxBackwardSpeed - MovementData.singleton.minBackwardSpeed));
        }
        this.AssertInit();
        if (this.fakeMovement)
        {
            prevNormSpeed = this.prevNormSpeed;
            smoothForward = this.prevSmoothForward;
        }
        this.anim.SetFloat(this.animParams.speed, prevNormSpeed);
        this.anim.SetFloat(this.animParams.speedTurn, smoothRotate);
        this.anim.SetFloat(this.animParams.forward, smoothForward);
        this.anim.SetFloat(this.animParams.strafe, smoothStrafe);
        this.UpdateDebugInput(0, 1, rawTotalSpeed);
        this.UpdateDebugInput(1, 1, smoothForward);
        this.UpdateDebugInput(2, 1, smoothStrafe);
        this.UpdateDebugInput(3, 1, smoothRotate);
        this.moving = ((rawForward != 0f) || (rawRotate != 0f)) || !(rawStrafe == 0f);
        this.prevNormSpeed = prevNormSpeed;
        this.prevSmoothForward = smoothForward;
    }

    private void SetNonCombatSet()
    {
        int animationSetId = this.anim.GetAnimationSetId(AnimSuiteData.NON_COMBAT_DATA.setName);
        if (animationSetId < 0)
        {
            GLog.LogError(new object[] { this.anim.name + ": Can not change non-combat animation set!", "'" + AnimSuiteData.NON_COMBAT_DATA.setName + "'", "does not exist on granny state machine:", this.anim.machineFile });
        }
        else
        {
            this.nonCombatAnimSet = animationSetId;
        }
    }

    public void SetNpcAnimSets(string idle, string combat)
    {
        int animationSetId = this.anim.GetAnimationSetId(idle);
        if (animationSetId < 0)
        {
            GLog.LogError(new object[] { this.anim.name + ": Can not change non-combat animation set!", "'" + idle + "'", "does not exist on granny state machine:", this.anim.machineFile });
        }
        else
        {
            this.nonCombatAnimSet = animationSetId;
        }
        animationSetId = this.anim.GetAnimationSetId(combat);
        if (animationSetId < 0)
        {
            GLog.LogError(new object[] { this.anim.name + ": Can not change weapon animation set!", "'" + combat + "'", "does not exist on granny state machine:", this.anim.machineFile });
        }
        else
        {
            this.currentWeaponAnimSet = animationSetId;
        }
    }

    public override void SetStealth(bool enabled)
    {
        base.SetStealth(enabled);
    }

    public override void SetUnconscious(bool isUnconscious)
    {
        this.anim.SetInteger(this.animParams.deathType, isUnconscious ? 1 : 0);
    }

    public override void SetWeapon(int _mainhandCategoryId, int _offhandCategoryId)
    {
        this.mainhandCategoryId = _mainhandCategoryId;
        this.offhandCategoryId = _offhandCategoryId;
        this.SetWeaponAnimSet(this.mainhandCategoryId, this.offhandCategoryId);
        this.SetDrawNum(this.mainhandCategoryId, this.offhandCategoryId);
    }

    private void SetWeaponAnimSet(int mainhandCategoryId, int offhandCategoryId)
    {
        if (this.aiDrawNumber == -2)
        {
            WeaponCategoryData data;
            if (WeaponCategoryData.categoriesById.TryGetValue(mainhandCategoryId, out data))
            {
                WeaponCategoryData data2;
                string offhand = string.Empty;
                if (WeaponCategoryData.categoriesById.TryGetValue(offhandCategoryId, out data2))
                {
                    offhand = data2.name;
                }
                AnimSuiteData byNames = AnimSuiteData.GetByNames(data.name, offhand);
                int animationSetId = this.anim.GetAnimationSetId(byNames.setName);
                if (animationSetId < 0)
                {
                    GLog.LogError(new object[] { this.anim.name + ": Can not change weapon (" + data.name + ", " + offhand + ") animation set!", "'" + byNames.setName + "'", "does not exist on granny state machine:", this.anim.machineFile });
                }
                else
                {
                    this.currentWeaponAnimSet = animationSetId;
                }
            }
            else
            {
                this.currentWeaponAnimSet = this.nonCombatAnimSet;
                if (mainhandCategoryId != 0)
                {
                    GLog.LogError(new object[] { this.anim.name + ": Can not change animation set! Invalid weapon ID:", mainhandCategoryId });
                }
            }
        }
    }

    public override void Start()
    {
        this.animParams = new Params(this.anim);
        base.Start();
    }

    public override void Update(bool validEntity, bool inCombat, bool prevInCombat, bool attackInProgress, bool prevAttackInProgress, bool attackIsRooted, CombatVars.DeathState deathState, AnimationData attackAnim, bool debugManualLayers)
    {
        this.inTransition = this.anim.IsInTransition((uint) 0);
        this.activeElementName = this.anim.GetActiveElementName(this.animParams.wholeBodyNode);
        if (prevAttackInProgress != attackInProgress)
        {
            if ((this.moving && !attackIsRooted) && attackInProgress)
            {
                this.anim.SetFloat(this.animParams.subHighLayer, 1f);
            }
            if (!attackInProgress)
            {
                this.subHighLerpStartTime = Time.time;
            }
        }
        float @float = this.anim.GetFloat(this.animParams.subHighLayer);
        if (!(attackInProgress || (@float <= 0f)))
        {
            float num2 = Mathf.Lerp(1f, 0f, (Time.time - this.subHighLerpStartTime) / 0.25f);
            this.anim.SetFloat(this.animParams.subHighLayer, num2);
        }
        this.UpdateDebugOutput(@float);
        if (this.debugLoopAttack != -1)
        {
            this.anim.TriggerEvent(this.animParams.attackEvent);
            this.anim.SetInteger(this.animParams.attackType, this.debugLoopAttack);
        }
    }

    private void UpdateDebugInput(int row, int column, object value)
    {
        if (base.debugLevel != BaseMotion.DebugLevel.None)
        {
            base.debugAnimInput[row, column] = value;
        }
    }

    private void UpdateDebugOutput(float subHighLayerWeight)
    {
        if (base.debugLevel != BaseMotion.DebugLevel.None)
        {
            base.debugAnimOutput[0, 1] = this.anim.GetFloat(this.animParams.speed);
            base.debugAnimOutput[1, 1] = this.anim.GetFloat(this.animParams.speedTurn);
            base.debugAnimOutput[2, 1] = this.anim.GetFloat(this.animParams.forward);
            base.debugAnimOutput[3, 1] = this.anim.GetFloat(this.animParams.strafe);
            base.debugAnimOutput[4, 1] = this.anim.GetInteger(this.animParams.jumpState);
            base.debugAnimOutput[5, 1] = this.anim.GetInteger(this.animParams.attackType);
            base.debugAnimOutput[6, 1] = this.anim.GetInteger(this.animParams.drawStowType);
            base.debugAnimOutput[7, 1] = this.anim.GetInteger(this.animParams.crowdControlled);
            base.debugAnimOutput[8, 1] = this.anim.GetInteger(this.animParams.crowdControlType);
            base.debugAnimOutput[9, 1] = this.anim.GetInteger(this.animParams.crowdControlType);
            base.debugAnimOutput[10, 1] = subHighLayerWeight;
            base.debugAnimOutput[11, 1] = this.inTransition;
            base.debugAnimOutput[12, 1] = this.anim.GetActiveElementName(this.animParams.wholeBodyNode);
            base.debugAnimOutput[13, 1] = this.anim.GetActiveElementName(this.animParams.upperBodyNode);
            base.debugAnimOutput[14, 1] = this.anim.GetAnimationSetName(this.anim.GetCurrentAnimationSet());
        }
    }

    public override void UpdateJump(BaseMotion.JumpState currentJumpState)
    {
        switch (currentJumpState)
        {
            case BaseMotion.JumpState.LIFT_OFF:
                this.anim.SetInteger(this.animParams.jumpState, 2);
                break;

            case BaseMotion.JumpState.FALL:
                this.anim.SetInteger(this.animParams.jumpState, 1);
                break;

            case BaseMotion.JumpState.HIT_GROUND:
                this.anim.SetInteger(this.animParams.jumpState, 0);
                break;
        }
    }

    protected class Params
    {
        public uint attackEvent = uint.MaxValue;
        public uint attackHand = uint.MaxValue;
        public uint attackType = uint.MaxValue;
        public uint crowdControlled = uint.MaxValue;
        public uint crowdControlType = uint.MaxValue;
        public uint deathType = uint.MaxValue;
        public uint drawEvent = uint.MaxValue;
        public uint drawStowType = uint.MaxValue;
        public uint forward = uint.MaxValue;
        public uint harvestType = uint.MaxValue;
        public uint instaStopEvent = uint.MaxValue;
        public uint interruptEvent = uint.MaxValue;
        public uint jumpState = uint.MaxValue;
        public uint speed = uint.MaxValue;
        public uint speedTurn = uint.MaxValue;
        public uint stowEvent = uint.MaxValue;
        public uint strafe = uint.MaxValue;
        public uint subHighLayer = uint.MaxValue;
        public uint upperBodyNode = uint.MaxValue;
        public bool valid = false;
        public uint weaponSwapEvent = uint.MaxValue;
        public uint wholeBodyNode = uint.MaxValue;

        public Params(GrannyAnimator anim)
        {
            this.speed = anim.GetParameterId("speedParams", "speed");
            this.speedTurn = anim.GetParameterId("speedParams", "speedTurn");
            this.forward = anim.GetParameterId("speedParams", "velocityZ");
            this.strafe = anim.GetParameterId("speedParams", "velocityX");
            this.jumpState = anim.GetParameterId("jumpParams", "jumpState");
            this.attackType = anim.GetParameterId("attackParams", "attackType");
            this.attackHand = anim.GetParameterId("attackParams", "attackHand");
            this.subHighLayer = anim.GetParameterId("blendParams", "layerOverride");
            this.drawStowType = anim.GetParameterId("drawStowParams", "drawStowType");
            this.crowdControlled = anim.GetParameterId("ccParams", "crowdControl");
            this.crowdControlType = anim.GetParameterId("ccParams", "crowdControlType");
            this.deathType = anim.GetParameterId("ccParams", "deathType");
            this.harvestType = anim.GetParameterId("harvestParams", "harvestType");
            this.attackEvent = anim.GetParameterId("externalEvents", "attack");
            this.interruptEvent = anim.GetParameterId("externalEvents", "interrupt");
            this.drawEvent = anim.GetParameterId("externalEvents", "draw");
            this.stowEvent = anim.GetParameterId("externalEvents", "stow");
            this.instaStopEvent = anim.GetParameterId("externalEvents", "instaStop");
            this.weaponSwapEvent = anim.GetParameterId("externalEvents", "weaponSwap");
            this.wholeBodyNode = anim.GetParameterId("blendedCharacter", "WholeCharacter");
            this.upperBodyNode = anim.GetParameterId("blendedCharacter", "UpperBodyLayer");
            this.valid = this.VerifyId(this.speed, "speed", anim.name);
            this.valid = this.valid && this.VerifyId(this.strafe, "velocityX", anim.name);
            this.valid = this.valid && this.VerifyId(this.forward, "velocityZ", anim.name);
            this.valid = this.valid && this.VerifyId(this.drawEvent, "draw", anim.name);
            this.valid = this.valid && this.VerifyId(this.stowEvent, "stow", anim.name);
            this.valid = this.valid && this.VerifyId(this.jumpState, "jumpState", anim.name);
            this.valid = this.valid && this.VerifyId(this.speedTurn, "speedTurn", anim.name);
            this.valid = this.valid && this.VerifyId(this.deathType, "deathType", anim.name);
            this.valid = this.valid && this.VerifyId(this.attackType, "attackType", anim.name);
            this.valid = this.valid && this.VerifyId(this.attackHand, "attackHand", anim.name);
            this.valid = this.valid && this.VerifyId(this.attackEvent, "attack", anim.name);
            this.valid = this.valid && this.VerifyId(this.drawStowType, "drawStowType", anim.name);
            this.valid = this.valid && this.VerifyId(this.subHighLayer, "layerOverride", anim.name);
            this.valid = this.valid && this.VerifyId(this.wholeBodyNode, "WholeCharacter", anim.name);
            this.valid = this.valid && this.VerifyId(this.upperBodyNode, "UpperBodyLayer", anim.name);
            this.valid = this.valid && this.VerifyId(this.interruptEvent, "interrupt", anim.name);
            this.valid = this.valid && this.VerifyId(this.instaStopEvent, "instaStop", anim.name);
            this.valid = this.valid && this.VerifyId(this.weaponSwapEvent, "weaponSwap", anim.name);
            this.valid = this.valid && this.VerifyId(this.crowdControlled, "crowdControl", anim.name);
            this.valid = this.valid && this.VerifyId(this.crowdControlType, "crowdControlType", anim.name);
        }

        public void Reset(GrannyAnimator anim)
        {
            anim.SetFloat(this.speed, 0f);
            anim.SetFloat(this.speedTurn, 0f);
            anim.SetFloat(this.forward, 0f);
            anim.SetFloat(this.strafe, 0f);
            anim.SetInteger(this.jumpState, 0);
            anim.SetInteger(this.attackType, 0);
            anim.SetInteger(this.attackHand, 0);
            anim.SetFloat(this.subHighLayer, 0f);
            anim.SetInteger(this.drawStowType, 0);
            anim.SetInteger(this.crowdControlled, 0);
            anim.SetInteger(this.crowdControlType, 0);
            anim.SetInteger(this.deathType, 0);
        }

        private bool VerifyId(uint id, string paramName, string goName)
        {
            if (id == uint.MaxValue)
            {
                GLog.LogError(new object[] { "Could not find", paramName, "on", goName, "." });
                return false;
            }
            return true;
        }
    }
}

