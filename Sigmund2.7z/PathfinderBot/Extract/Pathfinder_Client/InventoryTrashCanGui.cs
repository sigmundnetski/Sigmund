﻿using GNGUI;
using System;
using UnityEngine;

public class InventoryTrashCanGui : MonoBehaviour
{
    private UISprite emptyTrashIcon;
    private UISprite hoverTrashIcon;
    private bool isDraggingInvItem;
    public static InventoryTrashCanGui singleton;
    private UIImageButton undoBtn;

    public void Awake()
    {
        singleton = this;
    }

    private void OnBtnDrop(GameObject go, GameObject droppedGo)
    {
        this.OnDrop(droppedGo);
    }

    public void OnDestroy()
    {
        singleton = null;
    }

    public void OnDrop(GameObject droppedGo)
    {
        InventoryItem item = droppedGo.GetComponent<InventoryItemGui>().item;
        if (item.quantity == 1)
        {
            InventoryClient.TrashItem(item);
        }
        else
        {
            ItemQtyGui.singleton.Populate(new ItemQtyGui.Callback(this.OnQtyChosen), "Trash", item);
        }
    }

    private void OnQtyChosen(InventoryItem updatedStack)
    {
        InventoryClient.TrashItem(updatedStack);
    }

    private void OnUndoClick(GameObject go)
    {
        InventoryClient.UndoTrash();
    }

    public void Refresh()
    {
        bool flag = SparseArray.Count<InventoryItem>(EntityDataClient.owner.playerRecord.trashContainer, InventoryItem.EMPTY_MATCH) > 0;
        if (this.emptyTrashIcon != null)
        {
            this.emptyTrashIcon.gameObject.SetActive(!this.isDraggingInvItem && !flag);
        }
        if (this.hoverTrashIcon != null)
        {
            this.hoverTrashIcon.gameObject.SetActive(this.isDraggingInvItem && !flag);
        }
        if (this.undoBtn != null)
        {
            this.undoBtn.gameObject.SetActive(flag);
        }
    }

    public void SetDragging(bool isDragging)
    {
        this.isDraggingInvItem = isDragging;
        this.Refresh();
    }

    public void Start()
    {
        this.undoBtn = base.GetComponentInChildren<UIImageButton>();
        foreach (UISprite sprite in base.GetComponentsInChildren<UISprite>())
        {
            if (sprite.name == "EmptyTrash")
            {
                this.emptyTrashIcon = sprite;
            }
            else if (sprite.name == "HoverTrash")
            {
                this.hoverTrashIcon = sprite;
            }
        }
        GuiHelper.GuiAssertNotNull("InventoryTrashCanGui", new object[] { this.emptyTrashIcon, this.hoverTrashIcon, this.undoBtn });
        UIEventListener.Get(this.undoBtn.gameObject).onClick = new UIEventListener.VoidDelegate(this.OnUndoClick);
        UIEventListener.Get(this.undoBtn.gameObject).onDrop = new UIEventListener.ObjectDelegate(this.OnBtnDrop);
        this.Refresh();
    }
}

