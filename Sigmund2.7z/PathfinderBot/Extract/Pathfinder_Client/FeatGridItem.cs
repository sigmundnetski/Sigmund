﻿using GNGUI;
using System;
using System.Text;

public class FeatGridItem : DraggableTabListItem
{
    public Combat.FeatType featBaseType;
    public int featId;
    public byte featLevel;
    public Combat.FeatType featType;
    private UISprite icon;

    public void Assign(int featId_, Combat.FeatType featType_, Combat.FeatType featBaseType_, string featIcon, string featDisplayName, byte level)
    {
        this.featId = featId_;
        this.featType = featType_;
        this.featBaseType = featBaseType_;
        this.featLevel = level;
        base.name = (0x3e8 - level) + " " + featDisplayName;
        base.nameLabel.text = featDisplayName + "\n  Level: " + level;
        GuiHelper.SetSpriteWithFallback(this.icon, featIcon, "hud_hotbar_icon_questionmark", true);
    }

    public override void Awake()
    {
        base.Awake();
        this.icon = base.GetComponentInChildren<UISprite>();
        GuiHelper.GuiAssertNotNull("Couldn't find icon.", new object[] { this.icon });
    }

    public override void OnDragEnd()
    {
        FeatsWindowGui.singleton.DragEnd(base.gameObject, this.featType, this.featId);
    }

    public override void OnDragStart()
    {
        FeatsWindowGui.singleton.DragStart(this.featType, this.featId);
    }

    public override void OnTooltip(bool show)
    {
        if (this.featId != 0)
        {
            base.showingTooltip = show;
            if (!show)
            {
                FeatsWindowGui.singleton.ShowTooltip(null, null);
            }
            else
            {
                StringBuilder quickText = GUtil.GetQuickText();
                CombatClient.AppendFeatTooltip(quickText, this.featId, this.featLevel, true);
                FeatsWindowGui.singleton.ShowTooltip(quickText.ToString(), base.gameObject);
            }
        }
    }
}

