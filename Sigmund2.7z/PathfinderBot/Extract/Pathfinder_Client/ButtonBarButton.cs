﻿using GNGUI;
using System;
using System.Text;
using UnityEngine;

public class ButtonBarButton : MonoBehaviour
{
    private static Color activeColor = new Color(0.8862745f, 0.7921569f, 0.4352941f);
    public BasicItemData.ItemSlot bodySlot = BasicItemData.ItemSlot.NONE;
    private UISprite capitalize;
    public string command;
    private UIFilledSprite cooldown;
    private float cooldownEndTime = 0f;
    private float cooldownStartTime = 0f;
    private UISprite disabled;
    private static Color dontShowColor = new Color(1f, 1f, 1f, 0f);
    private static Color doShowColor = Color.white;
    private UIDragObject dragScript;
    public Combat.EffectType effectType = Combat.EffectType.Neutral;
    public FeatData.FeatForm featForm;
    public int featId;
    public byte featLevel;
    public Combat.FeatType featType;
    public Combat.FeatType generalType;
    private static Color grayedOutColor = new Color(0.5f, 0.5f, 0.5f);
    private static Color grayedOutTransparentColor = new Color(0.5f, 0.5f, 0.5f, 0.5f);
    private UISprite highlight;
    public int hotbarIndex;
    private static Color hoverColor = new Color(0.8f, 0.8f, 0.8f);
    private UISprite icon;
    private bool isBeingDragged = false;
    private bool isHovered = false;
    private bool isPressed = false;
    public int itemId = 0;
    private UILabel kbdShortcut;
    private NonAttackFeatData nonAttackFeat = null;
    private static Color normalColor = new Color(0.7686275f, 0.7254902f, 0.5450981f);
    private OffensiveFeatData offensiveFeat = null;
    private static Color pressedColor = new Color(0.9f, 0.9f, 0.9f);
    private bool prevCapitalizable = false;
    private ButtonState prevDisabledState = ButtonState.NONE;
    private ButtonState prevIconState = ButtonState.NONE;
    private static Color queuedColor = new Color(0.9058824f, 0.5333334f, 0.9098039f);

    public void AttackToggle(bool show)
    {
        NGUITools.SetActive(this.kbdShortcut.gameObject, show);
    }

    private void ChangeIcon(string iconName, CombatVars playerCV, GameObject target, float distance)
    {
        GuiHelper.SetSpriteWithFallback(this.icon, iconName, "hud_hotbar_icon_questionmark", true);
        NGUITools.SetActive(this.icon.gameObject, true);
        this.UpdateButtonState(playerCV, target, distance);
    }

    public void Init(Combat.FeatType featType_, FeatData.FeatForm featForm_, bool startAsHidden, string command_)
    {
        int num;
        this.featType = featType_;
        this.featForm = featForm_;
        this.command = command_;
        this.dragScript.enabled = false;
        this.kbdShortcut.text = KeyboardData.KeyCodeToString(InputManager.GetCommandKeybind(this.command));
        NGUITools.SetActive(this.kbdShortcut.gameObject, !startAsHidden);
        string[] strArray = base.name.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
        if ((strArray.Length == 2) && int.TryParse(strArray[1], out num))
        {
            this.hotbarIndex = num - 1;
        }
        else
        {
            this.hotbarIndex = -1;
        }
        if ((this.featForm == FeatData.FeatForm.Wondrous) && (this.hotbarIndex > -1))
        {
            this.bodySlot = (BasicItemData.ItemSlot) ((byte) (15 + this.hotbarIndex));
        }
    }

    private bool IsCapitalizable(CombatVars target, CombatVars player)
    {
        bool flag = false;
        if (target != null)
        {
            if (this.nonAttackFeat != null)
            {
                flag = CombatCore.ConditionCapitalizationExists(CombatClient.CurrentTick, this.nonAttackFeat.combatMods, target, player);
            }
            else if (this.offensiveFeat != null)
            {
                flag = CombatCore.ConditionCapitalizationExists(CombatClient.CurrentTick, this.offensiveFeat.attackMods, target, player) || CombatCore.ConditionCapitalizationExists(CombatClient.CurrentTick, this.offensiveFeat.buffMods, target, player);
            }
        }
        return flag;
    }

    public void OnDrag(Vector2 delta)
    {
        if ((this.featId != 0) && !this.isBeingDragged)
        {
            this.isBeingDragged = true;
            ButtonBarGui.singleton.DragStart(this.featType, this.featId);
            this.dragScript.target = this.icon.transform;
            GuiHelper.Reparent(this.icon.gameObject, DragDropRoot.root);
        }
    }

    public void OnHover(bool isOver)
    {
        this.isHovered = isOver;
        if (this.isHovered)
        {
            this.icon.color = hoverColor;
        }
        else
        {
            this.icon.color = doShowColor;
            this.prevIconState = ButtonState.NONE;
        }
    }

    public void OnInCombat(bool inCombat)
    {
        if (this.featId == 0)
        {
            this.dragScript.enabled = false;
        }
        else
        {
            this.dragScript.enabled = !inCombat;
            if (this.isBeingDragged && inCombat)
            {
                this.OnPress(false);
            }
        }
    }

    public void OnPress(bool isDown)
    {
        this.isPressed = isDown;
        if (this.isPressed)
        {
            this.icon.color = pressedColor;
        }
        else
        {
            this.icon.color = doShowColor;
            this.prevIconState = ButtonState.NONE;
        }
        if (!(this.isPressed || !this.isBeingDragged))
        {
            this.isBeingDragged = false;
            ButtonBarGui.singleton.DragEnd(base.gameObject, this.featType, this.featId);
            GuiHelper.Reparent(this.icon.gameObject, base.gameObject.transform);
            this.icon.gameObject.transform.localPosition = Vector3.zero;
        }
    }

    public void OnTooltip(bool show)
    {
        if (!(show && (this.featId != 0)))
        {
            UITooltip.ShowText(null, null);
        }
        else
        {
            StringBuilder quickText = GUtil.GetQuickText();
            CombatClient.AppendFeatTooltip(quickText, this.featId, this.featLevel, true);
            UITooltip.ShowText(quickText.ToString(), base.gameObject);
        }
    }

    public void Reset()
    {
        this.featId = 0;
        this.offensiveFeat = null;
        this.nonAttackFeat = null;
        this.effectType = Combat.EffectType.Neutral;
        this.dragScript.enabled = false;
        if ((this.featForm != FeatData.FeatForm.Wondrous) && ((this.featType == Combat.FeatType.Attack) || (this.featType == Combat.FeatType.Expendable)))
        {
            this.icon.spriteName = "hud_hotbar_icon_blank";
        }
        else
        {
            NGUITools.SetActive(this.icon.gameObject, false);
        }
        this.icon.MakePixelPerfect();
    }

    public void ResetDragTargetValidity()
    {
        this.highlight.color = dontShowColor;
        this.prevIconState = ButtonState.NONE;
    }

    public void Set(CombatVars playerCV, GameObject target, float distance, FeatData.FeatForm form)
    {
        OffensiveFeatData feat = null;
        if (form == FeatData.FeatForm.Wondrous)
        {
            InventoryItem item = EntityDataClient.owner.playerRecord.bodySlots[(int) this.bodySlot];
            WondrousItemData data2 = null;
            if ((InventoryItem.EMPTY_MATCH(item) || ((data2 = ItemDatabase.GetItem(item.staticItemId) as WondrousItemData) == null)) || ((feat = FeatDatabase.GetFeatById(data2.featId) as OffensiveFeatData) == null))
            {
                this.Reset();
                return;
            }
            this.itemId = data2.id;
        }
        else
        {
            GLog.LogWarning(new object[] { base.name, "Set() doesn't support form:", form });
            this.Reset();
            return;
        }
        this.Set(feat, 1, playerCV, target, distance);
    }

    public void Set(NonAttackFeatData feat, CombatVars playerCV, GameObject target, float distance)
    {
        if (feat.type != this.featType)
        {
            GLog.LogError(new object[] { string.Concat(new object[] { "Wrong feat type! Button expects ", this.featType, ". Feat is ", feat.type }) });
        }
        else
        {
            this.offensiveFeat = null;
            this.nonAttackFeat = feat;
            this.featId = feat.id;
            this.featLevel = feat.level;
            this.generalType = feat.generalType;
            this.effectType = feat.effectType;
            this.ChangeIcon(feat.icon, playerCV, target, distance);
            this.OnInCombat(playerCV.inCombat);
        }
    }

    public void Set(OffensiveFeatData feat, byte level, CombatVars playerCV, GameObject target, float distance)
    {
        if (feat.type != this.featType)
        {
            GLog.LogError(new object[] { string.Concat(new object[] { "Wrong feat type! Button expects ", this.featType, ". Feat is ", feat.type }) });
        }
        else
        {
            this.offensiveFeat = feat;
            this.nonAttackFeat = null;
            this.featId = feat.id;
            this.featLevel = level;
            this.generalType = feat.generalType;
            this.effectType = feat.effectType;
            this.ChangeIcon(feat.icon, playerCV, target, distance);
            this.OnInCombat(playerCV.inCombat);
        }
    }

    private void SetButtonState(ButtonState iconState, ButtonState disabledState, bool capitalizable)
    {
        if (((iconState != this.prevIconState) || (disabledState != this.prevDisabledState)) || (capitalizable != this.prevCapitalizable))
        {
            Color doShowColor = ButtonBarButton.doShowColor;
            Color dontShowColor = ButtonBarButton.dontShowColor;
            Color normalColor = ButtonBarButton.normalColor;
            Color color4 = capitalizable ? ButtonBarButton.doShowColor : ButtonBarButton.dontShowColor;
            switch (iconState)
            {
                case ButtonState.ACTIVE:
                    doShowColor = activeColor;
                    break;

                case ButtonState.QUEUED:
                    doShowColor = queuedColor;
                    break;
            }
            if (this.isHovered)
            {
                doShowColor = hoverColor;
            }
            if (this.isPressed)
            {
                doShowColor = pressedColor;
            }
            if (disabledState != ButtonState.NONE)
            {
                dontShowColor = grayedOutTransparentColor;
                doShowColor *= grayedOutColor;
                if (color4.a > 0f)
                {
                    color4 *= grayedOutColor;
                }
            }
            this.icon.color = doShowColor;
            this.kbdShortcut.color = normalColor;
            this.capitalize.color = color4;
            this.disabled.color = dontShowColor;
            this.prevIconState = iconState;
            this.prevDisabledState = disabledState;
            this.prevCapitalizable = capitalizable;
        }
    }

    private void SetCooldownPercentage(CombatVars player)
    {
        CombatCooldowns.FeatCooldown cooldown = player.cooldowns.GetCooldown(this.featId);
        if (cooldown.id != 0)
        {
            if (this.cooldownStartTime == 0f)
            {
                this.cooldownStartTime = Time.time;
                this.cooldownEndTime = this.cooldownStartTime + CombatCore.SecondsFromTicks(cooldown.cooldownTick - CombatClient.CurrentTick);
            }
            float num = 1f - ((Time.time - this.cooldownStartTime) / (this.cooldownEndTime - this.cooldownStartTime));
            this.cooldown.fillAmount = num;
        }
        else
        {
            this.cooldownStartTime = 0f;
            this.cooldownEndTime = 0f;
            this.cooldown.fillAmount = 0f;
        }
    }

    public void SetDragTargetValidity()
    {
        if (FeatsWindowGui.singleton.IsValidForFilter(this.featType))
        {
            this.SetDragTargetValidity(this.featType, this.featForm);
        }
        else
        {
            this.ResetDragTargetValidity();
        }
    }

    public void SetDragTargetValidity(Combat.FeatType featType_, FeatData.FeatForm featForm_)
    {
        if ((this.featType == featType_) && (this.featForm == featForm_))
        {
            this.highlight.color = doShowColor;
        }
        else
        {
            this.ResetDragTargetValidity();
        }
    }

    public void Start()
    {
        this.featType = Combat.FeatType.None;
        foreach (UISprite sprite in base.GetComponentsInChildren<UISprite>())
        {
            string name = sprite.name;
            if (name != null)
            {
                if (!(name == "Icon"))
                {
                    if (name == "Capitalize")
                    {
                        goto Label_0062;
                    }
                    if (name == "Disabled")
                    {
                        goto Label_006B;
                    }
                    if (name == "Highlight")
                    {
                        goto Label_0074;
                    }
                }
                else
                {
                    this.icon = sprite;
                }
            }
            continue;
        Label_0062:
            this.capitalize = sprite;
            continue;
        Label_006B:
            this.disabled = sprite;
            continue;
        Label_0074:
            this.highlight = sprite;
        }
        this.cooldown = base.GetComponentInChildren<UIFilledSprite>();
        this.kbdShortcut = base.GetComponentInChildren<UILabel>();
        this.dragScript = base.GetComponent<UIDragObject>();
        GuiHelper.GuiAssertNotNull(base.gameObject.name + " could not find needed child objects.", new object[] { this.icon, this.capitalize, this.cooldown, this.disabled, this.kbdShortcut, this.dragScript, this.highlight });
        this.icon.color = doShowColor;
        this.kbdShortcut.color = normalColor;
        this.capitalize.color = dontShowColor;
        this.cooldown.fillAmount = 0f;
        this.disabled.color = dontShowColor;
        this.highlight.color = dontShowColor;
    }

    public void UpdateButtonState(CombatVars player, GameObject target, float distance)
    {
        if (player == null)
        {
            this.SetButtonState(ButtonState.DEFAULT, ButtonState.NONE, false);
        }
        else
        {
            this.SetCooldownPercentage(player);
            if (this.featId == 0)
            {
                this.SetButtonState(ButtonState.DEFAULT, ButtonState.NONE, false);
            }
            else
            {
                EntityId entityId = EntityCore.GetEntityId(target);
                CombatVars combatVarsFromId = CombatCore.GetCombatVarsFromId(ref entityId);
                ButtonState nONE = ButtonState.NONE;
                if ((((this.nonAttackFeat != null) && (this.nonAttackFeat.type == Combat.FeatType.Refresh)) && !player.refresh.RefreshFeatUsable(this.nonAttackFeat.id)) || ((this.offensiveFeat != null) && !player.refresh.OffensiveFeatUsable(this.offensiveFeat)))
                {
                    nONE = ButtonState.UNAVAILABLE;
                }
                else if (((this.nonAttackFeat != null) && (player.stamina < this.nonAttackFeat.stamina)) || ((this.offensiveFeat != null) && (player.stamina < this.offensiveFeat.stamina)))
                {
                    nONE = ButtonState.OUT_OF_STAMINA;
                }
                else if ((this.offensiveFeat != null) && (player.power < this.offensiveFeat.power))
                {
                    nONE = ButtonState.OUT_OF_POWER;
                }
                else if (!((CombatClient.SelfTargetOverride(this.effectType, entityId) || (combatVarsFromId == null)) || CombatCore.WithinRange(player, combatVarsFromId, this.featId, this.generalType, false)))
                {
                    nONE = ButtonState.OUT_OF_RANGE;
                }
                ButtonState dEFAULT = ButtonState.DEFAULT;
                if (this.featId == CombatClient.currentFeat.featId)
                {
                    dEFAULT = ButtonState.ACTIVE;
                }
                else if (this.featId == CombatClient.queuedFeat.featId)
                {
                    dEFAULT = ButtonState.QUEUED;
                }
                this.SetButtonState(dEFAULT, nONE, this.IsCapitalizable(combatVarsFromId, player));
            }
        }
    }

    private enum ButtonState
    {
        NONE,
        DEFAULT,
        ACTIVE,
        QUEUED,
        OUT_OF_RANGE,
        OUT_OF_POWER,
        OUT_OF_STAMINA,
        UNAVAILABLE
    }
}

