﻿using GNGUI;
using System;
using UnityEngine;

public class FullscreenWindowBackgroundGui : MonoBehaviour
{
    public void Hide()
    {
        NGUITools.SetActive(base.gameObject, false);
    }

    public void Show()
    {
        NGUITools.SetActive(base.gameObject, true);
    }

    public void Start()
    {
        this.Hide();
    }
}

