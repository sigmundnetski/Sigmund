﻿using GNGUI;
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;
using UnityEngine;

public class CompanyWindowHoldingsTabGui : CompanyWindowTabGui
{
    private List<CompanyHoldingsInfoGui> displayedTowers = new List<CompanyHoldingsInfoGui>();
    private EditSaveAction editSaveAction = EditSaveAction.NONE;
    private UIImageButton editSaveButton;
    private UILabel editSaveLabel;
    private GameObject holdingsPrefab;
    private UILabel localTimeEndLabel;
    private UILabel localTimeStartLabel;
    private const string PVP_CHANGE_FORMAT = "Changes will not take effect until {0} UTC ({1} local).";
    private const string PVP_TOWER_FORMAT = "Towers ({0})";
    private const string PVP_WINDOW_FORMAT = "PvP window: {0} hours, {1} minutes";
    private const string PVP_WINDOW_WARNING_FORMAT = "Your PvP window cannot overlap the hours of:\n{0} and {1} UTC ({2} and {3} local).";
    private UILabel pvpDurationLabel;
    private UILabel pvpInfoLabel;
    private UILabel pvpWarningLabel;
    private UILabel settlementLabel;
    public static CompanyWindowHoldingsTabGui singleton;
    private UIGrid towerGrid;
    private UILabel towerLabel;
    private UILabel utcTimeEndLabel;
    private UIInput utcTimeStartInput;
    private UISprite utcTimeStartInputBg;

    public void Awake()
    {
        singleton = this;
        this.OnAwake();
    }

    public override void DisplayCompany()
    {
        VentureCompanyRecord company = GroupClient.GetCompany(CompanyWindowGui.companyId);
        SettlementRecord settlement = GroupClient.GetSettlement(0);
        if (company == null)
        {
            this.SetPvpInfo(false, false, 0L, settlement);
            this.SetTerritoryInfo(settlement, company);
        }
        else
        {
            settlement = GroupClient.GetSettlement(company.settlementId);
            this.SetTerritoryInfo(settlement, company);
            if (GroupClient.InOwnerCompany(company))
            {
                VentureCompanyMember member = GroupClient.GetCompany(settlement.ownerCompanyId).FindMember(EntityDataClient.owner.playerId);
                this.SetPvpInfo(member.HasPermission(VentureCompanyMember.MemberPermission.NONE | VentureCompanyMember.MemberPermission.PVP), true, company.companyId, settlement);
            }
            else
            {
                this.SetPvpInfo(false, false, company.companyId, settlement);
            }
        }
    }

    public void EditSaveClicked(GameObject go)
    {
        if (GroupClient.GetSettlementCompany() != null)
        {
            if (this.editSaveAction == EditSaveAction.EDIT)
            {
                this.utcTimeStartInput.enabled = true;
                NGUITools.SetActive(this.utcTimeStartInputBg.gameObject, true);
                NGUITools.SetActive(this.pvpInfoLabel.gameObject, true);
                this.editSaveLabel.text = "Save";
                this.editSaveAction = EditSaveAction.SAVE;
            }
            else if (this.editSaveAction == EditSaveAction.SAVE)
            {
                TimeSpan span;
                if (!this.ParseTime(out span))
                {
                    this.pvpWarningLabel.color = Color.red;
                }
                else
                {
                    GroupClient.RequestNewPvpWindow(span);
                    this.utcTimeStartInput.enabled = false;
                    NGUITools.SetActive(this.utcTimeStartInputBg.gameObject, false);
                    NGUITools.SetActive(this.pvpInfoLabel.gameObject, false);
                    this.editSaveLabel.text = "Edit";
                    this.editSaveAction = EditSaveAction.EDIT;
                }
            }
        }
    }

    public override void LoadingTickFinished()
    {
        this.holdingsPrefab = UIClient.guiPrefabs["CompanyHoldingsInfo"];
        GuiHelper.GuiAssertNotNull("Couldn't load prefabs.", new object[] { this.holdingsPrefab });
    }

    public void OnAwake()
    {
        foreach (UILabel label in base.GetComponentsInChildren<UILabel>())
        {
            if (label.name == "SettlementLabel")
            {
                this.settlementLabel = label;
            }
            else if (label.name == "TowerInfoLabel")
            {
                this.towerLabel = label;
            }
            else if (label.name == "PvpDurationLabel")
            {
                this.pvpDurationLabel = label;
            }
            else if (label.name == "WarningLabel")
            {
                this.pvpWarningLabel = label;
            }
            else if (label.name == "InfoLabel")
            {
                this.pvpInfoLabel = label;
            }
            else if (label.name == "TimeUtcAmountEnd")
            {
                this.utcTimeEndLabel = label;
            }
            else if (label.name == "TimeLocalAmountStart")
            {
                this.localTimeStartLabel = label;
            }
            else if (label.name == "TimeLocalAmountEnd")
            {
                this.localTimeEndLabel = label;
            }
            else if (label.name == "TowerInfoLabel")
            {
                this.towerLabel = label;
            }
            else if (label.name == "EditSaveLabel")
            {
                this.editSaveLabel = label;
            }
        }
        foreach (UIInput input in base.GetComponentsInChildren<UIInput>())
        {
            if (input.name == "TimeUtcAmountStart")
            {
                this.utcTimeStartInput = input;
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find labels or inputs.", new object[] { this.settlementLabel, this.towerLabel, this.pvpDurationLabel, this.pvpWarningLabel, this.pvpInfoLabel, this.utcTimeEndLabel, this.localTimeStartLabel, this.localTimeEndLabel, this.utcTimeStartInput, this.editSaveLabel });
        foreach (UISprite sprite in base.GetComponentsInChildren<UISprite>())
        {
            if (sprite.name == "TimeUtcAmountStartBackground")
            {
                this.utcTimeStartInputBg = sprite;
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find sprites.", new object[] { this.utcTimeStartInputBg });
        foreach (UIGrid grid in base.GetComponentsInChildren<UIGrid>())
        {
            if (grid.name == "TowersGrid")
            {
                this.towerGrid = grid;
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find grid.", new object[] { this.towerGrid });
        foreach (UIImageButton button in base.GetComponentsInChildren<UIImageButton>())
        {
            if (button.name == "ButtonEditSave")
            {
                this.editSaveButton = button;
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find buttons.", new object[] { this.editSaveButton });
        this.settlementLabel.text = "No Settlement";
        this.towerLabel.text = string.Empty;
        this.pvpDurationLabel.text = "PvP Window:";
        this.SetPvpWarningLabelTimes();
        this.pvpInfoLabel.text = string.Format("Changes will not take effect until {0} UTC ({1} local).", "10am", "10am");
        this.utcTimeStartInput.ClearText();
        this.utcTimeStartInput.text = "None";
        this.utcTimeStartInput.defaultText = "None";
        this.utcTimeEndLabel.text = "None";
        this.localTimeStartLabel.text = "None";
        this.localTimeEndLabel.text = "None";
        UIEventListener listener1 = UIEventListener.Get(this.editSaveButton.gameObject);
        listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.EditSaveClicked));
    }

    public void OnDestroy()
    {
        singleton = null;
    }

    private bool ParseTime(out TimeSpan newStartTime)
    {
        int num2;
        string s = this.utcTimeStartInput.text.ToLower().Trim();
        newStartTime = TimeSpan.Zero;
        int num = 0;
        if (s.Contains("am"))
        {
            s = s.Replace("am", string.Empty).Trim();
        }
        else if (s.Contains("pm"))
        {
            s = s.Replace("pm", string.Empty).Trim();
            num = 12;
        }
        if (s.Contains(":"))
        {
            TimeSpan span;
            if (!TimeSpan.TryParse(s, out span))
            {
                this.pvpWarningLabel.text = "Don't understand: " + this.utcTimeStartInput.text;
                this.pvpWarningLabel.color = Color.red;
                return false;
            }
            if (span.Days > 0)
            {
                this.pvpWarningLabel.text = "Don't understand: " + this.utcTimeStartInput.text;
                this.pvpWarningLabel.color = Color.red;
                return false;
            }
            num2 = span.Hours + num;
            if (num2 == 0x18)
            {
                num2 = 0;
            }
            newStartTime = new TimeSpan(0, num2, span.Minutes, 0);
            if (newStartTime.Hours > 0x17)
            {
                this.pvpWarningLabel.text = "Don't understand: " + this.utcTimeStartInput.text;
                this.pvpWarningLabel.color = Color.red;
                return false;
            }
        }
        else
        {
            uint num3;
            if (!uint.TryParse(s, out num3))
            {
                this.pvpWarningLabel.text = "Don't understand: " + this.utcTimeStartInput.text;
                this.pvpWarningLabel.color = Color.red;
                return false;
            }
            num2 = ((int) num3) + num;
            if ((num2 == 12) && (num == 0))
            {
                num2 = 0;
            }
            if ((num2 == 0x18) && (num == 12))
            {
                num2 = 12;
            }
            if (num2 > 0x17)
            {
                this.pvpWarningLabel.text = "Don't understand: " + this.utcTimeStartInput.text;
                this.pvpWarningLabel.color = Color.red;
                return false;
            }
            newStartTime = new TimeSpan(0, num2, 0, 0);
            if (newStartTime.Hours > 0x17)
            {
                this.pvpWarningLabel.text = "Don't understand: " + this.utcTimeStartInput.text;
                this.pvpWarningLabel.color = Color.red;
                return false;
            }
        }
        return true;
    }

    public void PvpWindowResponse(GroupConst.CommandStatus status)
    {
        this.SetPvpWarningLabelTimes();
        if (status == GroupConst.CommandStatus.PVP_START_INVALID)
        {
            this.pvpWarningLabel.color = Color.red;
        }
        else
        {
            this.pvpWarningLabel.color = new Color(0.9411765f, 0.8901961f, 0.6588235f);
        }
    }

    public override void RefreshCompany()
    {
        this.DisplayCompany();
    }

    private void SetPvpInfo(bool editPower, bool memberOfOwnerCompany, ulong companyId, SettlementRecord settlement)
    {
        this.utcTimeStartInput.enabled = false;
        NGUITools.SetActive(this.utcTimeStartInputBg.gameObject, false);
        this.editSaveAction = editPower ? EditSaveAction.EDIT : EditSaveAction.NONE;
        this.editSaveLabel.text = "Edit";
        NGUITools.SetActive(this.editSaveButton.gameObject, editPower);
        StringBuilder quickText = GUtil.GetQuickText();
        quickText.Append(settlement.settlementName);
        if ((settlement.settlementId != 0) && ((settlement.ownerCompanyId != companyId) && SparseArray.Contains<ulong>(settlement.memberCompanyIds, companyId)))
        {
            VentureCompanyRecord company = GroupClient.GetCompany(settlement.ownerCompanyId);
            if (company == null)
            {
                quickText.Append(" (Pledged)");
            }
            else
            {
                quickText.Append(" (Pledged), ").Append(company.vcName);
            }
        }
        this.settlementLabel.text = quickText.ToString();
        this.SetPvpWarningLabelTimes();
        this.pvpInfoLabel.text = string.Format("Changes will not take effect until {0} UTC ({1} local).", (int) SettlementPvpData.singleton.noPvpEnd.TotalHours, (int) ClockGui.ServerTimeOfDayToLocalTimeOfDay(SettlementPvpData.singleton.noPvpEnd).TotalHours);
        NGUITools.SetActive(this.pvpInfoLabel.gameObject, false);
        this.SetPvpWindowTimes(settlement);
    }

    private void SetPvpWarningLabelTimes()
    {
        TimeSpan noPvpStart = SettlementPvpData.singleton.noPvpStart;
        TimeSpan noPvpEnd = SettlementPvpData.singleton.noPvpEnd;
        TimeSpan span3 = ClockGui.ServerTimeOfDayToLocalTimeOfDay(noPvpStart);
        TimeSpan span4 = ClockGui.ServerTimeOfDayToLocalTimeOfDay(noPvpEnd);
        this.pvpWarningLabel.text = string.Format("Your PvP window cannot overlap the hours of:\n{0} and {1} UTC ({2} and {3} local).", new object[] { (int) span3.TotalHours, (int) span4.TotalHours, (int) noPvpStart.TotalHours, (int) noPvpEnd.TotalHours });
    }

    private void SetPvpWindowTimes(SettlementRecord settlement)
    {
        TimeSpan span = TimeSpan.FromMinutes((double) settlement.pvpWindowDuration);
        TimeSpan span2 = ClockGui.ModTimeStamp(TimeSpan.FromMinutes((double) settlement.pvpWindowBegin), ClockGui.DAY);
        TimeSpan span3 = ClockGui.ModTimeStamp(span2 + span, ClockGui.DAY);
        TimeSpan span4 = ClockGui.ServerTimeOfDayToLocalTimeOfDay(TimeSpan.FromMinutes((double) settlement.pvpWindowBegin));
        TimeSpan span5 = ClockGui.ModTimeStamp(span4 + span, ClockGui.DAY);
        this.pvpDurationLabel.text = string.Format("PvP window: {0} hours, {1} minutes", span.Hours, span.Minutes);
        this.utcTimeStartInput.text = span2.Hours + ":" + span2.Minutes.ToString("d2");
        this.utcTimeStartInput.defaultText = this.utcTimeStartInput.text;
        this.utcTimeEndLabel.text = span3.Hours + ":" + span3.Minutes.ToString("d2");
        this.localTimeStartLabel.text = span4.Hours + ":" + span4.Minutes.ToString("d2");
        this.localTimeEndLabel.text = span5.Hours + ":" + span5.Minutes.ToString("d2");
    }

    private void SetTerritoryInfo(SettlementRecord settlement, VentureCompanyRecord company)
    {
        List<GroupClient.TerritoryClientVars> list;
        int num3;
        bool flag = GroupClient.OwnsSettlement(company);
        int count = 0;
        int num2 = 0;
        if (GroupClient.settlementTerritories.TryGetValue(settlement.settlementId, out list))
        {
            num2 = list.Count;
            if (flag)
            {
                count = list.Count;
            }
            else
            {
                for (num3 = 0; num3 < list.Count; num3++)
                {
                    count += (list[num3].companyId == company.companyId) ? 1 : 0;
                }
            }
        }
        UIGrid.SetElementCount<CompanyHoldingsInfoGui>(DragDropRoot.root, this.towerGrid, this.holdingsPrefab, this.displayedTowers, count);
        this.towerLabel.text = string.Format("Towers ({0})", count);
        int num4 = 0;
        for (num3 = 0; num3 < num2; num3++)
        {
            if (flag || (list[num3].companyId == company.companyId))
            {
                this.displayedTowers[num4].SetData(list[num3], settlement.settlementId);
                num4++;
            }
        }
        this.towerGrid.repositionNow = true;
    }

    public override void ShowTab()
    {
        base.ShowTab();
        this.DisplayCompany();
    }

    public override void UpdateCompany()
    {
        this.DisplayCompany();
    }

    private enum EditSaveAction
    {
        NONE,
        EDIT,
        SAVE
    }
}

