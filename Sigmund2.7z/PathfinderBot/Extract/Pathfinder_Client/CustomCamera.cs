﻿using System;
using UnityEngine;

public class CustomCamera : MonoBehaviour
{
    private float CAM_FOCUS_HEIGHT = float.NaN;
    private const float CAM_MIN_DAMPENING_ANGLE = 1f;
    private float cameraIncl = 0f;
    private bool cameraLocked = true;
    private float cameraYaw = 0f;
    private SimpleMovingAverage camFocusHeightSMA;
    private bool clampingMaxDistance = false;
    private bool cursorIsLocked = false;
    private bool customPosition = false;
    public bool debugRotationLock = false;
    private float distance = 3f;
    private int DISTANCE_CAST_LAYERS = 0;
    private const float DISTANCE_CAST_RADIUS = 0.5f;
    private bool freeLooking = false;
    private float HEIGHT_CAST_RADIUS = 0.3f;
    private const float HEIGHT_CLAMP = 2f;
    private const float HEIGHT_RAYCAST_DISTANCE = 100f;
    private bool isOverDragThreshold = false;
    private const float MAX_DISTANCE = 10f;
    private const float MIN_DISTANCE = 1.5f;
    private bool mouseLooking = false;
    private float rotationDampening = 3f;
    public static CustomCamera singleton;
    public Transform standardPos;
    private float unclampedDistance = 0f;
    private float xSpeed = 250f;
    private float yMaxLimit = 80f;
    private float yMinLimit = -20f;
    private float ySpeed = 120f;
    private float zoomRate = 20f;

    public void Awake()
    {
        singleton = this;
    }

    private float ClampInclination(float angle, float min, float max)
    {
        if (angle < -360f)
        {
            angle += 360f;
        }
        if (angle > 360f)
        {
            angle -= 360f;
        }
        return Mathf.Clamp(angle, min, max);
    }

    public void FixedUpdate()
    {
        if ((this.standardPos != null) && !this.customPosition)
        {
            if (this.mouseLooking && this.isOverDragThreshold)
            {
                this.LockCursor();
                this.ProcessMouseLooking();
            }
            else if (this.freeLooking && this.isOverDragThreshold)
            {
                this.UnlockCursor();
                this.ProcessFreeLooking();
            }
            else
            {
                this.UnlockCursor();
                this.ProcessCameraEase();
            }
            this.RepositionCamera();
            bool flag = this.mouseLooking && this.freeLooking;
            EntityMotion.singleton.SetMouseSteering(this.mouseLooking, this.freeLooking, this.cameraYaw, flag, 1f);
        }
    }

    public void Init(Transform camPos)
    {
        this.standardPos = camPos;
        this.CAM_FOCUS_HEIGHT = this.standardPos.position.y - EntityMotion.singleton.gameObject.transform.position.y;
        this.camFocusHeightSMA = new SimpleMovingAverage(Mathf.RoundToInt(0.5f / Time.fixedDeltaTime));
        base.transform.position = this.standardPos.position - ((Vector3) ((this.standardPos.rotation * Vector3.forward) * this.distance));
        base.transform.rotation = this.standardPos.rotation;
        this.cameraYaw = this.standardPos.eulerAngles.y;
    }

    public void KeybindEvents(bool mouseLooking, bool freeLooking, bool isOverDragThreshold)
    {
        this.mouseLooking = mouseLooking;
        this.freeLooking = freeLooking;
        if (this.isOverDragThreshold)
        {
            if (!((mouseLooking || freeLooking) || isOverDragThreshold))
            {
                this.isOverDragThreshold = false;
            }
        }
        else
        {
            this.isOverDragThreshold = isOverDragThreshold;
        }
    }

    public void LockCursor()
    {
        if (!this.cursorIsLocked)
        {
            Screen.lockCursor = true;
            this.cursorIsLocked = true;
        }
    }

    public void OnDestroy()
    {
        singleton = null;
    }

    public void OnTeleport()
    {
        this.camFocusHeightSMA.SetAll(this.standardPos.position.y);
    }

    private void ProcessCameraEase()
    {
        if (!this.debugRotationLock && (!InputManager.IsUIFocused() && ((ClientInputManager.singleton.rotationAxis != 0f) || (ClientInputManager.singleton.forwardAxis != 0f))))
        {
            float yawTarget = EntityMotion.singleton.yawTarget;
            float cameraYaw = this.cameraYaw;
            if (this.cameraLocked)
            {
                this.cameraYaw = yawTarget;
            }
            else
            {
                this.cameraYaw = Mathf.LerpAngle(cameraYaw, yawTarget, this.rotationDampening * Time.deltaTime);
                if (Mathf.Abs((float) (this.cameraYaw - yawTarget)) <= 1f)
                {
                    this.cameraLocked = true;
                }
            }
        }
    }

    private void ProcessFreeLooking()
    {
        this.cameraLocked = false;
        this.cameraYaw += (ClientInputManager.singleton.mouseAxis.x * this.xSpeed) * 0.02f;
        this.cameraIncl -= (ClientInputManager.singleton.mouseAxis.y * this.ySpeed) * 0.02f;
    }

    private void ProcessMouseLooking()
    {
        this.cameraYaw += (ClientInputManager.singleton.mouseAxis.x * this.xSpeed) * 0.02f;
        this.cameraIncl -= (ClientInputManager.singleton.mouseAxis.y * this.ySpeed) * 0.02f;
    }

    public void ReleaseCustomPosition()
    {
        this.customPosition = false;
    }

    private void RepositionCamera()
    {
        RaycastHit hit;
        RaycastHit hit2;
        float num = 0f;
        if (!InputManager.IsUIHovered())
        {
            num = ((ClientInputManager.singleton.mouseScroll * Time.deltaTime) * this.zoomRate) * Mathf.Abs(this.distance);
        }
        this.cameraIncl = this.ClampInclination(this.cameraIncl, this.yMinLimit, this.yMaxLimit);
        Quaternion quaternion = Quaternion.Euler(this.cameraIncl, this.cameraYaw, 0f);
        Vector3 position = this.standardPos.position;
        float y = position.y;
        Vector3 origin = position;
        origin += new Vector3(0f, 2f, 0f);
        if (Physics.SphereCast(origin, this.HEIGHT_CAST_RADIUS, Vector3.down, out hit, 102f, ((int) 1) << LayerMask.NameToLayer("Default")))
        {
            y = hit.point.y + this.CAM_FOCUS_HEIGHT;
        }
        if (Mathf.Abs((float) (y - this.standardPos.position.y)) > 2f)
        {
            y = this.standardPos.position.y - 2f;
            this.camFocusHeightSMA.Update(y);
            position.y = y;
        }
        else
        {
            this.camFocusHeightSMA.Update(y);
            position.y = this.camFocusHeightSMA.Average;
        }
        if (!this.clampingMaxDistance)
        {
            this.unclampedDistance = this.distance;
        }
        else
        {
            this.distance = Mathf.Max(this.distance, this.unclampedDistance);
        }
        float num3 = 10f;
        Vector3 vector3 = position - ((Vector3) ((quaternion * Vector3.forward) * 10f));
        if (Physics.SphereCast(this.standardPos.position, 0.5f, vector3 - this.standardPos.position, out hit2, 10f, this.DISTANCE_CAST_LAYERS))
        {
            this.clampingMaxDistance = true;
            num3 = hit2.distance - 1f;
        }
        else
        {
            this.clampingMaxDistance = false;
        }
        num3 = Mathf.Clamp(num3, 1.5f, 10f);
        this.distance = Mathf.Clamp(this.distance - num, 1.5f, num3);
        if ((this.clampingMaxDistance && (num > 0f)) && (Mathf.Abs((float) (this.distance - 1.5f)) > 0.0001f))
        {
            this.unclampedDistance = this.distance;
        }
        Vector3 vector4 = position - ((Vector3) ((quaternion * Vector3.forward) * this.distance));
        base.transform.rotation = quaternion;
        base.transform.position = vector4;
        if (GoblinAudioListener.singleton != null)
        {
            Vector3 vector5 = position - ((Vector3) (((quaternion * Vector3.forward) * this.unclampedDistance) * GoblinAudioListener.singleton.percentDistance));
            GoblinAudioListener.singleton.transform.position = vector5;
            GoblinAudioListener.singleton.transform.rotation = quaternion;
        }
    }

    public void SetCustomPosition(Vector3 position, Quaternion rotation)
    {
        base.transform.position = position;
        base.transform.rotation = rotation;
        this.customPosition = true;
    }

    public void Start()
    {
        this.cameraIncl = base.transform.eulerAngles.x;
        this.cameraYaw = base.transform.eulerAngles.y;
        if (base.rigidbody != 0)
        {
            base.rigidbody.freezeRotation = true;
        }
        int num = 0x400;
        int num2 = 0xa00;
        int num3 = 4;
        int num4 = 0x100;
        this.DISTANCE_CAST_LAYERS = ~(((num | num2) | num3) | num4);
        GuiHelper.GuiAssertNotNull("CustomCamera needs a Camera component on " + base.name, new object[] { base.camera });
    }

    public void UnlockCursor()
    {
        if (this.cursorIsLocked)
        {
            Screen.lockCursor = false;
            this.cursorIsLocked = false;
        }
    }
}

