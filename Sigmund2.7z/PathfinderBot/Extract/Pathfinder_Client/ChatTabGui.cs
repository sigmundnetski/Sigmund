﻿using GNGUI;
using System;
using System.Collections.Generic;
using UnityEngine;

public class ChatTabGui
{
    private const float ACTIVATE_Y = -2f;
    private string activeChannelName = string.Empty;
    private UISprite background;
    private int[] channelIdsInTab;
    private UITextList chatOutput;
    private const float DEACTIVATE_Y = 2f;
    private static readonly Color DEFAULT_COLOR = new Color(0.9411765f, 0.8901961f, 0.6588235f);
    private string[] desiredChannels;
    private bool isActive;
    private int tabId = -1;
    private string tabName;
    private UILabel title;
    private GameObject titleParent;
    private static readonly Color UNREAD_COLOR = new Color(0.9098039f, 0.6470588f, 0.254902f);

    public ChatTabGui(string tabGoNamePrefix, GameObject chatGuiGo, int tabId_, string[] desiredChannels_, string tabName_)
    {
        this.tabId = tabId_;
        this.desiredChannels = desiredChannels_;
        for (int i = 0; i < this.desiredChannels.Length; i++)
        {
            if (i == 0)
            {
                this.activeChannelName = this.desiredChannels[i];
            }
        }
        Transform transform = chatGuiGo.transform.Find("PixelPanel/" + tabGoNamePrefix + "Title");
        this.chatOutput = chatGuiGo.transform.Find("PixelPanel/" + tabGoNamePrefix + "TextList").GetComponent<UITextList>();
        this.background = chatGuiGo.transform.Find("PixelPanel/" + tabGoNamePrefix + "Background").GetComponent<UISprite>();
        GuiHelper.GuiAssertNotNull("Could not find needed child objects.", new object[] { transform, this.background, this.chatOutput });
        this.titleParent = transform.gameObject;
        this.title = this.titleParent.GetComponentInChildren<UILabel>();
        GuiHelper.GuiAssertNotNull("Could not find title.", new object[] { this.title });
        this.tabName = tabName_;
        this.title.text = this.tabName;
        this.title.color = ChatClient.TAB_DEFAULT_COLOR;
        NGUITools.SetActive(this.chatOutput.gameObject, false);
        UIEventListener listener1 = UIEventListener.Get(this.titleParent.gameObject);
        listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.OnClick));
        this.channelIdsInTab = new int[] { -1, -1, -1, -1 };
    }

    public void AddDesiredChannel(string channelName)
    {
        SparseArray.Add<string>(ref this.desiredChannels, channelName);
    }

    public void AddMessage(string message)
    {
        this.chatOutput.Add(message);
    }

    public void AddMessage(int channelId, string message)
    {
        for (int i = 0; i < this.channelIdsInTab.Length; i++)
        {
            if (this.channelIdsInTab[i] == channelId)
            {
                this.AddMessage(message);
                if (!(this.isActive || ChatGui.singleton.ChannelViewed(channelId)))
                {
                    ChatGui.singleton.UnreadChannel(channelId);
                }
                break;
            }
        }
    }

    public void AddMessage(string message, Color color)
    {
        this.AddMessage(string.Format("{0}{1}[-]", NguiColorFormatter.ToNguiString(color, NguiColorFormatter.StringType.DEFAULT), message));
    }

    public void Clear()
    {
        this.chatOutput.Clear();
    }

    public bool DesireChannel(string channelName)
    {
        channelName = channelName.ToLower();
        for (int i = 0; i < this.desiredChannels.Length; i++)
        {
            if (this.desiredChannels[i].ToLower() == channelName)
            {
                return true;
            }
        }
        return false;
    }

    public bool InChannel(int channelId)
    {
        for (int i = 0; i < this.channelIdsInTab.Length; i++)
        {
            if (this.channelIdsInTab[i] == channelId)
            {
                return true;
            }
        }
        return false;
    }

    public void JoinChannel(int channelId, string channelName)
    {
        if (!this.InChannel(channelId))
        {
            SparseArray.Add<int>(ref this.channelIdsInTab, channelId, id => id == -1, -1);
            this.UpdateContextMenu();
            if (ChatHelper.IsMapChannel(channelName))
            {
                this.AddMessage(channelId, "Changed to new Hex's chat channel.");
            }
            else if (!string.IsNullOrEmpty(channelName))
            {
                this.AddMessage(channelId, "Successfully joined " + channelName + " channel.");
            }
        }
    }

    public void JoinChannels()
    {
        for (int i = 0; i < this.desiredChannels.Length; i++)
        {
            if (!string.IsNullOrEmpty(this.desiredChannels[i]) && !SparseArray.Contains<string>(ChatGui.DELAYED_JOIN, this.desiredChannels[i]))
            {
                if (!ChatHelper.IsSpecialChannel(this.desiredChannels[i]))
                {
                    ChatClient.JoinChannel(this.desiredChannels[i]);
                }
                else if (ChatHelper.IsWhisperChannel(this.desiredChannels[i]))
                {
                    this.JoinChannel(-2, string.Empty);
                    this.JoinChannel(-3, string.Empty);
                }
            }
        }
    }

    private void JoinDelayedChannels()
    {
        for (int i = 0; i < ChatGui.DELAYED_JOIN.Length; i++)
        {
            if (this.DesireChannel(ChatGui.DELAYED_JOIN[i]))
            {
                if (!ChatClient.InChannel(ChatGui.DELAYED_JOIN[i]))
                {
                    ChatClient.JoinChannel(ChatGui.DELAYED_JOIN[i]);
                }
                else
                {
                    int channelId = ChatClient.GetChannelId(ChatGui.DELAYED_JOIN[i]);
                    if (!((channelId == -1) || this.InChannel(channelId)))
                    {
                        this.JoinChannel(channelId, ChatGui.DELAYED_JOIN[i]);
                    }
                }
            }
        }
    }

    public void LeaveChannel(int channelId)
    {
        for (int i = 0; i < this.channelIdsInTab.Length; i++)
        {
            if (this.channelIdsInTab[i] == channelId)
            {
                this.channelIdsInTab[i] = -1;
                this.UpdateContextMenu();
                break;
            }
        }
    }

    public void OnClick(GameObject go)
    {
        if (!this.isActive)
        {
            ChatGui.singleton.TabSelected(this.tabId);
        }
    }

    public void RemoveDesiredChannel(string channelName)
    {
        channelName = channelName.ToLower();
        for (int i = 0; i < this.desiredChannels.Length; i++)
        {
            if (this.desiredChannels[i].ToLower() == channelName)
            {
                this.desiredChannels[i] = null;
            }
        }
    }

    public void SetActive(bool active)
    {
        this.isActive = active;
        float num = active ? -2f : 2f;
        Vector3 localPosition = this.titleParent.transform.localPosition;
        this.titleParent.transform.localPosition = new Vector3(localPosition.x, localPosition.y + num, localPosition.z);
        localPosition = this.background.transform.localPosition;
        this.background.transform.localPosition = new Vector3(localPosition.x, localPosition.y + num, localPosition.z);
        NGUITools.SetActive(this.chatOutput.gameObject, active);
        if (active)
        {
            ChatClient.ChangeChannel(this.activeChannelName);
            this.JoinDelayedChannels();
            ChatGui.singleton.ReadChannels(this.channelIdsInTab);
        }
    }

    public void SetChannel(string channelName, int channelId)
    {
        if (channelId == -2)
        {
            this.activeChannelName = "whisper";
        }
        else
        {
            this.activeChannelName = channelName;
        }
        this.UpdateContextMenu();
    }

    public void UnreadChannels(HashSet<int> unreadChannelIds)
    {
        for (int i = 0; i < this.channelIdsInTab.Length; i++)
        {
            if (unreadChannelIds.Contains(this.channelIdsInTab[i]))
            {
                this.title.color = ChatClient.TAB_UNREAD_COLOR;
                return;
            }
        }
        this.title.color = ChatClient.TAB_DEFAULT_COLOR;
    }

    private void UpdateContextMenu()
    {
        if (ChatContextGui.singleton.IsShowing() && (ChatContextGui.singleton.currentReferenceId == this.tabId))
        {
            ChatContextGui.singleton.UpdateContents(this.tabId);
        }
    }

    public string ActiveChannel
    {
        get
        {
            return this.activeChannelName;
        }
    }

    public int[] ChannelIds
    {
        get
        {
            return this.channelIdsInTab;
        }
    }

    public string TabName
    {
        get
        {
            return this.tabName;
        }
    }
}

