﻿using GNetwork;
using System;

public static class FacilityClient
{
    public static void OnDoorClick(Door door)
    {
        GRouting.SendMyMapRpc(GRpcID.FacilityServer_OnDoorClick, new object[] { TerrainService.TranslateLocalToServer(EntityDataClient.owner.ownerMapId, door.gameObject.transform.position) });
    }
}

