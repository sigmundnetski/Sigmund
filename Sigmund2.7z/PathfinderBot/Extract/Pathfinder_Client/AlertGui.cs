﻿using GNGUI;
using System;
using UnityEngine;

public class AlertGui : MonoBehaviour
{
    public bool autoMaximized;
    public float autoMaximizedTime;
    public float autoMinimizeTime;
    public float hoverStartTime;
    public uint id;
    public bool inAlphaLerp;
    public bool isHovered;
    public bool isMinimized;
    private UILabel label;
    private GameObject maximized;
    private GameObject minimized;
    public float startTime;
    public float timeoutTime;
    private UIImageButton toggleButton;
    private static string[][] typeSprites = new string[][] { new string[] { "button_alerts_toggle_system_de", "button_alerts_toggle_system_mo", "button_alerts_toggle_system_cl" }, new string[] { "button_alerts_toggle_party_de", "button_alerts_toggle_party_mo", "button_alerts_toggle_party_cl" }, new string[] { "button_alerts_toggle_company_de", "button_alerts_toggle_company_mo", "button_alerts_toggle_company_cl" }, new string[] { "button_alerts_toggle_system_de", "button_alerts_toggle_system_mo", "button_alerts_toggle_system_cl" } };

    public void AcceptClicked(GameObject go)
    {
        AlertsManagerGui.singleton.AlertInteraction(this, AlertsManagerGui.AlertAction.ACCEPTED);
    }

    public void Awake()
    {
        this.id = uint.MaxValue;
        this.startTime = float.NegativeInfinity;
        this.timeoutTime = float.NegativeInfinity;
        this.isHovered = false;
        this.isMinimized = false;
        this.hoverStartTime = float.NegativeInfinity;
        this.autoMaximized = false;
        this.autoMaximizedTime = float.NegativeInfinity;
        this.autoMinimizeTime = float.PositiveInfinity;
        this.inAlphaLerp = false;
        UIImageButton button = null;
        UIImageButton button2 = null;
        UIImageButton button3 = null;
        UIImageButton button4 = null;
        foreach (UIImageButton button5 in base.GetComponentsInChildren<UIImageButton>())
        {
            if (button5.name == "AcceptButton")
            {
                button = button5;
            }
            else if (button5.name == "DeclineButton")
            {
                button2 = button5;
            }
            else if (button5.name == "CloseMaximized")
            {
                button4 = button5;
            }
            else if (button5.name == "CloseMinimized")
            {
                button3 = button5;
            }
            else if (button5.name == "ToggleButton")
            {
                this.toggleButton = button5;
            }
        }
        this.label = base.GetComponentInChildren<UILabel>();
        Transform transform = base.transform.Find("Minimized");
        Transform transform2 = base.transform.Find("Maximized");
        GuiHelper.GuiAssertNotNull("NULL BUTTONS!", new object[] { button, button2, button3, button4, this.toggleButton, this.label, transform, transform2 });
        this.minimized = transform.gameObject;
        this.maximized = transform2.gameObject;
        UIEventListener listener1 = UIEventListener.Get(button.gameObject);
        listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.AcceptClicked));
        UIEventListener listener2 = UIEventListener.Get(button2.gameObject);
        listener2.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener2.onClick, new UIEventListener.VoidDelegate(this.DeclineClicked));
        UIEventListener listener3 = UIEventListener.Get(button4.gameObject);
        listener3.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener3.onClick, new UIEventListener.VoidDelegate(this.CloseClicked));
        UIEventListener listener4 = UIEventListener.Get(button3.gameObject);
        listener4.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener4.onClick, new UIEventListener.VoidDelegate(this.CloseClicked));
        UIEventListener listener5 = UIEventListener.Get(this.toggleButton.gameObject);
        listener5.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener5.onClick, new UIEventListener.VoidDelegate(this.ToggleClicked));
        UIEventListener listener6 = UIEventListener.Get(button.gameObject);
        listener6.onHover = (UIEventListener.BoolDelegate) Delegate.Combine(listener6.onHover, new UIEventListener.BoolDelegate(this.OnHover));
        UIEventListener listener7 = UIEventListener.Get(button2.gameObject);
        listener7.onHover = (UIEventListener.BoolDelegate) Delegate.Combine(listener7.onHover, new UIEventListener.BoolDelegate(this.OnHover));
        UIEventListener listener8 = UIEventListener.Get(button4.gameObject);
        listener8.onHover = (UIEventListener.BoolDelegate) Delegate.Combine(listener8.onHover, new UIEventListener.BoolDelegate(this.OnHover));
        UIEventListener listener9 = UIEventListener.Get(button3.gameObject);
        listener9.onHover = (UIEventListener.BoolDelegate) Delegate.Combine(listener9.onHover, new UIEventListener.BoolDelegate(this.OnHover));
        UIEventListener listener10 = UIEventListener.Get(this.toggleButton.gameObject);
        listener10.onHover = (UIEventListener.BoolDelegate) Delegate.Combine(listener10.onHover, new UIEventListener.BoolDelegate(this.OnHover));
        UIEventListener listener11 = UIEventListener.Get(this.minimized);
        listener11.onHover = (UIEventListener.BoolDelegate) Delegate.Combine(listener11.onHover, new UIEventListener.BoolDelegate(this.OnHover));
        UIEventListener listener12 = UIEventListener.Get(this.maximized);
        listener12.onHover = (UIEventListener.BoolDelegate) Delegate.Combine(listener12.onHover, new UIEventListener.BoolDelegate(this.OnHover));
    }

    public void CloseClicked(GameObject go)
    {
        AlertsManagerGui.singleton.AlertInteraction(this, AlertsManagerGui.AlertAction.IGNORED);
    }

    public void DeclineClicked(GameObject go)
    {
        AlertsManagerGui.singleton.AlertInteraction(this, AlertsManagerGui.AlertAction.DECLINED);
    }

    public void OnHover(GameObject go, bool isOver)
    {
        this.isHovered = isOver;
        if (this.isHovered)
        {
            this.hoverStartTime = Time.time;
        }
        else
        {
            this.hoverStartTime = float.PositiveInfinity;
        }
    }

    public void Reset()
    {
        this.id = uint.MaxValue;
        this.startTime = float.NegativeInfinity;
        this.timeoutTime = float.NegativeInfinity;
        this.isHovered = false;
        this.isMinimized = false;
        this.hoverStartTime = float.NegativeInfinity;
        this.autoMaximized = false;
        this.autoMaximizedTime = float.NegativeInfinity;
        this.autoMinimizeTime = float.PositiveInfinity;
        this.inAlphaLerp = false;
        base.gameObject.name = float.MaxValue.ToString("f1");
        NGUITools.SetActive(base.gameObject, false);
        NGUITools.SetActive(this.minimized, false);
        NGUITools.SetActive(this.maximized, true);
    }

    public void Set(uint setId, AlertsManagerGui.AlertType type, string text)
    {
        this.id = setId;
        this.startTime = Time.time;
        this.timeoutTime = this.startTime + 30f;
        this.label.text = text;
        this.isHovered = false;
        this.isMinimized = false;
        this.hoverStartTime = float.NegativeInfinity;
        this.autoMaximized = false;
        this.autoMaximizedTime = float.NegativeInfinity;
        this.autoMinimizeTime = Time.time + 10f;
        this.inAlphaLerp = false;
        base.gameObject.name = this.startTime.ToString("f1");
        this.toggleButton.normalSprite = typeSprites[(int) type][0];
        this.toggleButton.hoverSprite = typeSprites[(int) type][1];
        this.toggleButton.pressedSprite = typeSprites[(int) type][2];
        NGUITools.SetActive(base.gameObject, true);
        NGUITools.SetActive(this.minimized, false);
        NGUITools.SetActive(this.maximized, true);
        UIClient.AlphaLerp(base.gameObject, 0f, 1f, 0.5f, null);
    }

    public void Start()
    {
        NGUITools.SetActive(base.gameObject, false);
        NGUITools.SetActive(this.minimized, false);
    }

    public void ToggleClicked(GameObject go)
    {
        if (!this.minimized.activeSelf)
        {
            NGUITools.SetActive(this.minimized, true);
            NGUITools.SetActive(this.maximized, false);
            this.isMinimized = true;
        }
        else
        {
            NGUITools.SetActive(this.minimized, false);
            NGUITools.SetActive(this.maximized, true);
            this.isMinimized = false;
        }
        this.isHovered = false;
        this.hoverStartTime = float.PositiveInfinity;
        this.autoMinimizeTime = float.PositiveInfinity;
    }
}

