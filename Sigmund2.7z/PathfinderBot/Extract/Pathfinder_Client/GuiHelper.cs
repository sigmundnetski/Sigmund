﻿using GNGUI;
using System;
using UnityEngine;

public static class GuiHelper
{
    public static void GuiAssertNotNull(string message, params object[] nullChecks)
    {
        for (int i = 0; i < nullChecks.Length; i++)
        {
            if (nullChecks[i] == null)
            {
                throw new GoblinGuiException(message + "\n  >> index of first null object: " + i);
            }
        }
    }

    public static void GuiAssertNotNull(string message, object[,] nullChecks)
    {
        for (int i = 0; i < nullChecks.GetLength(0); i++)
        {
            for (int j = 0; j < nullChecks.GetLength(1); j++)
            {
                if (nullChecks[i, j] == null)
                {
                    throw new GoblinGuiException(string.Concat(new object[] { message, "\n  >> index of first null object: ", i, ",", j }));
                }
            }
        }
    }

    public static bool InViewFrustrum(Camera camera, Vector3 position)
    {
        Vector3 vector = camera.WorldToScreenPoint(position);
        return ((((vector.x > 0f) && (vector.x < Screen.width)) && ((vector.y > 0f) && (vector.y < Screen.height))) && (vector.z > 0f));
    }

    public static void Reparent(GameObject go, Transform newParent)
    {
        go.transform.parent = newParent;
        Vector3 localPosition = go.transform.localPosition;
        localPosition.z = 0f;
        go.transform.localPosition = localPosition;
        go.transform.BroadcastMessage("CheckParent", SendMessageOptions.DontRequireReceiver);
    }

    public static void SetItemIcon(UISprite icon, InventoryItem item, BasicItemData itemData)
    {
        if ((itemData == null) || string.IsNullOrEmpty(itemData.icon))
        {
            icon.atlas = UIAtlasManager.singleton.GetAtlas("PFO_Weapon_Icons");
            icon.spriteName = "icon_item_weapon_64_unknown";
        }
        else
        {
            CombatArmor armor = itemData as CombatArmor;
            CombatWeapon weapon = itemData as CombatWeapon;
            CraftingItemData data = itemData as CraftingItemData;
            if (((armor != null) || (weapon != null)) || (itemData is GearItemData))
            {
                EntityVars component = PlayerEntityClient.GetPlayer().GetComponent<EntityVars>();
                EntityDefnData data2 = EntityDefnData.defnById[component.entityDefnId];
                string format = itemData.icon.ToLower();
                char gender = (char) data2.gender;
                if ((weapon != null) || (itemData is WondrousItemData))
                {
                    icon.atlas = UIAtlasManager.singleton.GetAtlas("PFO_Weapon_Icons");
                }
                else if ((armor != null) || (itemData is GearItemData))
                {
                    icon.atlas = UIAtlasManager.singleton.GetAtlas("PFO_Armor_Icons");
                }
                string match = string.Format(format, new object[] { "1", gender, item.upgrade, BasicItemData.SlotToString(itemData.slot) });
                if (icon.atlas.GetListOfSprites(match).size == 0)
                {
                    match = string.Format(format, new object[] { "1", gender, "0", BasicItemData.SlotToString(itemData.slot) });
                }
                icon.spriteName = match;
            }
            else if ((((data != null) || (itemData is CurrencyItemData)) || ((itemData is TreasureBoxItemData) || (itemData is CraftRecipeItemData))) || (itemData is ExpendableRecipeItemData))
            {
                icon.atlas = UIAtlasManager.singleton.GetAtlas("PFO_Component_Icons");
                icon.spriteName = itemData.icon;
            }
            else
            {
                GLog.LogWarning(new object[] { "Don't know what atlas to use for", item });
                icon.atlas = UIAtlasManager.singleton.GetAtlas("PFO_Weapon_Icons");
                icon.spriteName = "icon_item_weapon_64_unknown";
            }
        }
    }

    public static void SetSpriteWithFallback(UISprite sprite, string desiredSprite, string fallbackSprite, bool makePixelPerfect)
    {
        if (sprite.atlas.GetListOfSprites().Contains(desiredSprite))
        {
            sprite.spriteName = desiredSprite;
        }
        else
        {
            sprite.spriteName = fallbackSprite;
        }
        if (makePixelPerfect)
        {
            sprite.MakePixelPerfect();
        }
    }
}

