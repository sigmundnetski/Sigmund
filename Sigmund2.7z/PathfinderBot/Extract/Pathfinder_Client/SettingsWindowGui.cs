﻿using GNGUI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using UnityEngine;

public class SettingsWindowGui : WindowGui
{
    private UIScrollBar ambientVolume;
    private int currQuality = 0x7fffffff;
    private int currResolution = 0x7fffffff;
    private int currScale = 0x7fffffff;
    private string[] IGNORED_QUALITIES = new string[] { "Fastest", "Mac Low End", "Ultra Low End" };
    private UIScrollBar musicVolume;
    private int prevMonitorId = -1;
    private int prevSecond = 0;
    private UIPopupListKvp qualityOptions;
    private Dictionary<int, Dictionary<int, string>> resolutionElements;
    private Dictionary<int, ResolutionKey[]> resolutionKeys;
    private UIPopupListKvp resolutionOptions;
    private UIPopupListKvp scaleOptions;
    public static SettingsWindowGui singleton;

    public void AmbientVolumeChanged(UIScrollBar sb)
    {
        GraphicsClient.SetVolume("ambient", sb.scrollValue);
    }

    public void AmbientVolumeDragFinished()
    {
        PlayerPrefs.SetFloat("ambient_volume", this.ambientVolume.scrollValue);
    }

    public void Awake()
    {
        singleton = this;
    }

    public bool LoadingTickFinished()
    {
        this.SetResolutions();
        this.SetQualities();
        this.SetScales();
        this.SetVolume();
        return true;
    }

    public void MusicVolumeChanged(UIScrollBar sb)
    {
        GraphicsClient.SetVolume("music", sb.scrollValue);
    }

    public void MusicVolumeDragFinished()
    {
        PlayerPrefs.SetFloat("music_volume", this.musicVolume.scrollValue);
    }

    public override void OnDestroy()
    {
        base.OnDestroy();
        singleton = null;
    }

    public void QualityChanged(string ignored)
    {
        if (this.currQuality != this.qualityOptions.selectedKey)
        {
            int selectedKey = this.qualityOptions.selectedKey;
            if (selectedKey != QualitySettings.GetQualityLevel())
            {
                SettingsHelper.SetQuality((uint) selectedKey);
            }
            this.currQuality = this.qualityOptions.selectedKey;
        }
    }

    public void ResolutionChanged(string ignored)
    {
        if (this.currResolution != this.resolutionOptions.selectedKey)
        {
            int currentMonitorIndex = Screen.GetCurrentMonitorIndex();
            if (currentMonitorIndex != this.prevMonitorId)
            {
                this.UpdateResolutions(currentMonitorIndex);
            }
            else
            {
                int selectedKey = this.resolutionOptions.selectedKey;
                ResolutionKey key = this.resolutionKeys[currentMonitorIndex][selectedKey];
                SettingsHelper.SetResolution((uint) key.width, (uint) key.height, key.fullscreen);
                this.currResolution = selectedKey;
            }
        }
    }

    public void ScaleChanged(string ignored)
    {
        if (this.currScale != this.scaleOptions.selectedKey)
        {
            CommandCore.ExecuteAllCommands("ScaleGui " + this.scaleOptions.selectedKey, PlayerEntityClient.GetPlayerEntityId());
            this.currScale = this.scaleOptions.selectedKey;
        }
    }

    private void SetQualities()
    {
        Dictionary<int, string> elements = new Dictionary<int, string>();
        for (int i = 0; i < QualitySettings.names.Length; i++)
        {
            if (Array.IndexOf<string>(this.IGNORED_QUALITIES, QualitySettings.names[i]) == -1)
            {
                elements.Add(i, QualitySettings.names[i]);
            }
        }
        this.currQuality = QualitySettings.GetQualityLevel();
        this.qualityOptions.UpdateElements(elements);
        this.qualityOptions.SetSelectionToKey(this.currQuality);
    }

    private void SetResolutions()
    {
        int num;
        int num2;
        SettingsHelper.GwResolution[] resolutions = SettingsHelper.GetResolutions();
        Dictionary<int, int> dictionary = new Dictionary<int, int>();
        for (num = 0; num < resolutions.Length; num++)
        {
            num2 = 0;
            if (!dictionary.TryGetValue(resolutions[num].monId, out num2))
            {
                dictionary[resolutions[num].monId] = 0;
            }
            dictionary[resolutions[num].monId] = num2 + 1;
        }
        this.resolutionKeys = new Dictionary<int, ResolutionKey[]>();
        this.resolutionElements = new Dictionary<int, Dictionary<int, string>>();
        Dictionary<int, int> dictionary2 = new Dictionary<int, int>();
        foreach (KeyValuePair<int, int> pair in dictionary)
        {
            int key = pair.Key;
            num2 = pair.Value;
            this.resolutionKeys[key] = new ResolutionKey[num2 + 1];
            this.resolutionElements[key] = new Dictionary<int, string>();
            dictionary2[key] = 0;
            this.resolutionKeys[key][0] = (ResolutionKey[]) new ResolutionKey(0x500, 720, false);
            this.resolutionElements[key].Add(dictionary2[key], "Windowed");
            dictionary2[key] += 1;
        }
        Array.Sort<SettingsHelper.GwResolution>(resolutions, new Comparison<SettingsHelper.GwResolution>(this.SortResolutions));
        int num4 = 0;
        int currentMonitorIndex = Screen.GetCurrentMonitorIndex();
        for (num = resolutions.Length - 1; num >= 0; num--)
        {
            SettingsHelper.GwResolution resolution = resolutions[num];
            if (((resolution.width == Screen.currentResolution.width) && (resolution.height == Screen.currentResolution.height)) && (currentMonitorIndex == resolution.monId))
            {
                num4 = dictionary2[resolution.monId];
            }
            string str = string.Concat(new object[] { "Fullscreen (", resolution.width, "x", resolution.height, ")" });
            this.resolutionKeys[resolution.monId][dictionary2[resolution.monId]] = (ResolutionKey[]) new ResolutionKey(resolution.width, resolution.height, true);
            this.resolutionElements[resolution.monId].Add(dictionary2[resolution.monId], str);
            dictionary2[resolution.monId] += 1;
        }
        if (currentMonitorIndex == -1)
        {
            currentMonitorIndex = this.resolutionKeys.Keys.First<int>();
            this.currResolution = 0;
        }
        else
        {
            this.currResolution = Screen.fullScreen ? num4 : 0;
        }
        this.resolutionOptions.UpdateElements(this.resolutionElements[currentMonitorIndex]);
        this.resolutionOptions.SetSelectionToKey(this.currResolution);
    }

    private void SetScales()
    {
        Dictionary<int, string> elements = new Dictionary<int, string>();
        foreach (UIClient.ScalingType type in Enum.GetValues(typeof(UIClient.ScalingType)))
        {
            elements.Add((int) type, UIClient.UI_SCALE_NAMES[(int) type]);
        }
        this.currScale = 2;
        this.scaleOptions.UpdateElements(elements);
        this.scaleOptions.SetSelectionToKey(this.currScale);
    }

    private void SetVolume()
    {
        float @float;
        if (PlayerPrefs.HasKey("music_volume"))
        {
            @float = PlayerPrefs.GetFloat("music_volume");
            this.musicVolume.scrollValue = Mathf.Clamp01(@float);
            this.MusicVolumeChanged(this.musicVolume);
        }
        else
        {
            this.musicVolume.scrollValue = Mathf.Clamp01(GraphicsClient.GetVolume("music"));
        }
        if (PlayerPrefs.HasKey("ambient_volume"))
        {
            @float = PlayerPrefs.GetFloat("ambient_volume");
            this.ambientVolume.scrollValue = Mathf.Clamp01(@float);
            this.AmbientVolumeChanged(this.ambientVolume);
        }
        else
        {
            this.ambientVolume.scrollValue = Mathf.Clamp01(GraphicsClient.GetVolume("ambient"));
        }
    }

    private int SortResolutions(SettingsHelper.GwResolution lhs, SettingsHelper.GwResolution rhs)
    {
        if (lhs.width < rhs.width)
        {
            return -1;
        }
        if (lhs.width > rhs.width)
        {
            return 1;
        }
        if (lhs.height < rhs.height)
        {
            return -1;
        }
        if (lhs.height > rhs.height)
        {
            return 1;
        }
        return 0;
    }

    public void Start()
    {
        ClientTick.settingsGuiLoadFinish = new GUtil.BoolFilterDelegate(this.LoadingTickFinished);
        ClientTick.settingsGuiTick = new GUtil.BoolFilterDelegate(this.SyncFixedUpdate);
        foreach (UIPopupListKvp kvp in base.GetComponentsInChildren<UIPopupListKvp>())
        {
            if (kvp.name == "ResolutionList")
            {
                this.resolutionOptions = kvp;
            }
            else if (kvp.name == "QualityList")
            {
                this.qualityOptions = kvp;
            }
            else if (kvp.name == "ScaleList")
            {
                this.scaleOptions = kvp;
            }
        }
        foreach (UIScrollBar bar in base.GetComponentsInChildren<UIScrollBar>())
        {
            if (bar.name == "VolumeSliderMusic")
            {
                this.musicVolume = bar;
            }
            else if (bar.name == "VolumeSliderAmbient")
            {
                this.ambientVolume = bar;
            }
        }
        GuiHelper.GuiAssertNotNull("Could not find needed children.", new object[] { this.resolutionOptions, this.qualityOptions, this.scaleOptions, this.musicVolume, this.ambientVolume });
        this.resolutionOptions.onSelectionChange = new UIPopupList.OnSelectionChange(this.ResolutionChanged);
        this.qualityOptions.onSelectionChange = new UIPopupList.OnSelectionChange(this.QualityChanged);
        this.scaleOptions.onSelectionChange = new UIPopupList.OnSelectionChange(this.ScaleChanged);
        this.musicVolume.onChange = new UIScrollBar.OnScrollBarChange(this.MusicVolumeChanged);
        this.musicVolume.onDragFinished = new UIScrollBar.OnDragFinished(this.MusicVolumeDragFinished);
        this.ambientVolume.onChange = new UIScrollBar.OnScrollBarChange(this.AmbientVolumeChanged);
        this.ambientVolume.onDragFinished = new UIScrollBar.OnDragFinished(this.AmbientVolumeDragFinished);
        base.Init(2, true);
    }

    public bool SyncFixedUpdate()
    {
        int time = (int) Time.time;
        if (time != this.prevSecond)
        {
            this.prevSecond = time;
            if (this.prevMonitorId == -1)
            {
                this.prevMonitorId = Screen.GetCurrentMonitorIndex();
                return true;
            }
            int currentMonitorIndex = Screen.GetCurrentMonitorIndex();
            if (currentMonitorIndex == this.prevMonitorId)
            {
                return true;
            }
            this.UpdateResolutions(currentMonitorIndex);
        }
        return true;
    }

    private void UpdateResolutions(int currentMonitorId)
    {
        int num = 0;
        for (int i = 0; i < this.resolutionKeys[currentMonitorId].Length; i++)
        {
            ResolutionKey key = this.resolutionKeys[currentMonitorId][i];
            if ((key.width == Screen.currentResolution.width) && (key.height == Screen.currentResolution.height))
            {
                num = i;
                break;
            }
        }
        this.currResolution = Screen.fullScreen ? num : 0;
        this.resolutionOptions.OnSelect(false);
        this.resolutionOptions.UpdateElements(this.resolutionElements[currentMonitorId]);
        this.resolutionOptions.SetSelectionToKey(this.currResolution);
        this.prevMonitorId = currentMonitorId;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct ResolutionKey
    {
        public readonly int width;
        public readonly int height;
        public readonly bool fullscreen;
        public ResolutionKey(int width_, int height_, bool fullscreen_)
        {
            this.width = width_;
            this.height = height_;
            this.fullscreen = fullscreen_;
        }

        public override string ToString()
        {
            return string.Concat(new object[] { this.fullscreen ? "Fullscreen " : "Windowed ", this.width, "x", this.height });
        }
    }
}

