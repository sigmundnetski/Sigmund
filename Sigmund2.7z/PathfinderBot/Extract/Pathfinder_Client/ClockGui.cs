﻿using GNetwork;
using GNGUI;
using System;
using UnityEngine;

public class ClockGui : MonoBehaviour
{
    public static readonly TimeSpan DAY = TimeSpan.FromDays(1.0);
    private uint reducedTickAmount;
    public static ClockGui singleton;
    private uint tick = 0;
    private UILabel timeLabel;
    private const string TOOLTIP_FORMAT = "Your time: {0}\nServer time: {1}";

    public void Awake()
    {
        singleton = this;
    }

    public void FixedUpdate()
    {
        if (this.tick == 0)
        {
            this.timeLabel.text = GNetworkService.ServerUtc.ToShortTimeString();
        }
        this.tick = (this.tick + 1) % this.reducedTickAmount;
    }

    public static TimeSpan LocalTimeOfDayToServerTimeOfDay(TimeSpan localTimeOfDay)
    {
        return ModTimeStamp((localTimeOfDay + GNetworkService.localUtcOffset) - GNetworkService.serverTimeOffset, DAY);
    }

    public static TimeSpan ModTimeStamp(TimeSpan input, TimeSpan mod)
    {
        return TimeSpan.FromSeconds((DAY.TotalSeconds + input.TotalSeconds) % mod.TotalSeconds);
    }

    public void OnDestroy()
    {
        singleton = null;
    }

    public void OnTooltip(bool show)
    {
        if (!show)
        {
            UITooltip.ShowText(null, null);
        }
        else
        {
            UITooltip.ShowText(string.Format("Your time: {0}\nServer time: {1}", DateTime.Now.ToShortTimeString(), GNetworkService.ServerUtc.ToShortTimeString()), base.gameObject);
        }
    }

    public static TimeSpan ServerTimeOfDayToLocalTimeOfDay(TimeSpan serverTimeOfDay)
    {
        return ModTimeStamp((serverTimeOfDay + GNetworkService.serverTimeOffset) - GNetworkService.localUtcOffset, DAY);
    }

    public void Start()
    {
        this.timeLabel = base.GetComponentInChildren<UILabel>();
        GuiHelper.GuiAssertNotNull("Couldn't find needed children.", new object[] { this.timeLabel });
        this.reducedTickAmount = (uint) (1f / Time.fixedDeltaTime);
    }
}

