﻿using GNGUI;
using System;
using UnityEngine;

public class CompanyAlliesTabGui : CompanyAlliancesTabGui
{
    private UIImageButton breakAllianceButton;

    public override void AllianceSelected(ulong companyId_, uint settlementId_)
    {
        base.AllianceSelected(companyId_, settlementId_);
        if (GroupClient.InOwnerCompany(base.settlementId))
        {
            NGUITools.SetActive(this.breakAllianceButton.gameObject, false);
        }
        else
        {
            SettlementRecord settlement = GroupClient.GetSettlement(base.settlementId);
            VentureCompanyRecord company = null;
            company = GroupClient.GetCompany(settlement.ownerCompanyId);
            bool state = false;
            if (company != null)
            {
                GLog.Log(new object[] { company.vcName });
                VentureCompanyMember member = company.FindMember(EntityDataClient.owner.playerId);
                if (member != null)
                {
                    state = member.HasPermission(VentureCompanyMember.MemberPermission.ALLY_KICK);
                }
            }
            NGUITools.SetActive(this.breakAllianceButton.gameObject, state);
        }
    }

    public override void Awake()
    {
        base.Awake();
        base.tabSpriteName = "frame_company_header_tab_center";
        foreach (UIImageButton button in base.GetComponentsInChildren<UIImageButton>())
        {
            if (button.name == "ButtonBreakAlliance")
            {
                this.breakAllianceButton = button;
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find buttons.", new object[] { this.breakAllianceButton });
        UIEventListener listener1 = UIEventListener.Get(this.breakAllianceButton.gameObject);
        listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.BreakAllianceClicked));
        NGUITools.SetActive(this.breakAllianceButton.gameObject, false);
    }

    public void BreakAllianceClicked(GameObject go)
    {
        GroupClient.BreakAlliance(base.companyId, base.settlementId);
    }

    protected override void MakeListItems()
    {
        VentureCompanyRecord company = GroupClient.GetCompany(CompanyWindowGui.companyId);
        SettlementRecord settlement = null;
        int count = 0;
        if (company != null)
        {
            settlement = GroupClient.GetSettlement(company.settlementId);
        }
        if (settlement != null)
        {
            count = SparseArray.Count<uint>(settlement.allySettlementIds, GroupConst.EMPTY_SETTLEMENT);
        }
        UIGrid.SetElementCount<TabListItem>(DragDropRoot.root, base.gridList, base.listItemPrefab, base.displayedItems, count);
        int index = 0;
        int num3 = 0;
        bool flag = false;
        if ((settlement != null) && (settlement.allySettlementIds != null))
        {
            while (index < settlement.allySettlementIds.Length)
            {
                if (settlement.allySettlementIds[index] != 0)
                {
                    ((CompanyAllyInfo) base.displayedItems[num3]).Assign(settlement.allySettlementIds[index], this, num3, false);
                    num3++;
                    flag = flag || (settlement.allySettlementIds[index] == base.settlementId);
                }
                index++;
            }
        }
        if (!flag)
        {
            base.settlementId = 0;
        }
        this.AllianceSelected(base.companyId, base.settlementId);
    }
}

