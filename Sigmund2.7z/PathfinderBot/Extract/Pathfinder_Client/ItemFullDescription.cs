﻿using GNGUI;
using System;
using UnityEngine;

public class ItemFullDescription : MonoBehaviour
{
    protected UILabel fullDescription;
    protected UISprite icon;
    protected UILabel nameLabel;
    protected UILabel upgrade;

    public void Awake()
    {
        foreach (UILabel label in base.GetComponentsInChildren<UILabel>())
        {
            if (label.name == "FullDescription")
            {
                this.fullDescription = label;
            }
            else if (label.name == "Name")
            {
                this.nameLabel = label;
            }
            else if (label.name == "Upgrade")
            {
                this.upgrade = label;
            }
        }
        foreach (UISprite sprite in base.transform.parent.GetComponentsInChildren<UISprite>())
        {
            if (sprite.name == "ItemIcon")
            {
                this.icon = sprite;
                break;
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find required children.", new object[] { this.fullDescription, this.nameLabel, this.upgrade, this.icon });
        this.ResetDescription();
    }

    public void ItemChanged(InventoryItem item)
    {
        BasicItemData itemData = ItemDatabase.GetItem(item.staticItemId);
        if (itemData == null)
        {
            this.ResetDescription();
        }
        else
        {
            Color qualityColor = InventoryClient.GetQualityColor(item.GetQuality());
            this.fullDescription.text = item.GetDescription();
            this.upgrade.text = "+" + item.upgrade;
            this.nameLabel.text = InventoryClient.GetColoredItemDisplayName(item);
            NGUITools.SetActive(this.icon.gameObject, true);
            GuiHelper.SetItemIcon(this.icon, item, itemData);
        }
    }

    public void ResetDescription()
    {
        this.fullDescription.text = string.Empty;
        this.upgrade.text = string.Empty;
        this.nameLabel.text = string.Empty;
        NGUITools.SetActive(this.icon.gameObject, false);
    }
}

