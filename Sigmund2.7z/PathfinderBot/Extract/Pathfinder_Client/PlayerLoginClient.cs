﻿using GNetwork;
using System;
using System.Collections.Generic;
using System.Net;
using System.Runtime.InteropServices;

public static class PlayerLoginClient
{
    private static PlayerInfo[] curPlayers;
    private static int curTraining = 0;
    private static int maxTraining = 1;
    private static int numTwins = 0;
    public static Dictionary<int, int> redeemableItems = new Dictionary<int, int>();
    public static Dictionary<int, int> redeemItemIds = new Dictionary<int, int>();
    private static uint[] trainingPlayerIds = new uint[3];

    public static void CharacterCreated(int entityDefnId, int raceId, byte gender, int bodyAssetVariant, int faceAssetVariant, int hairAssetVariant, int skinColorId, int hairColorId, int eyeColorId, byte permissions, string characterName)
    {
        NetworkClient.serverConnection.SendRpc(GRpcID.PlayerLoginServer_CharacterCreated, new object[] { entityDefnId, raceId, gender, bodyAssetVariant, faceAssetVariant, hairAssetVariant, skinColorId, hairColorId, eyeColorId, permissions, characterName });
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void CharacterCreateFailure(string reason)
    {
        CharacterManagementGui.singleton.CreationError(reason);
    }

    public static void CharacterDeleted(uint playerId)
    {
        NetworkClient.serverConnection.SendRpc(GRpcID.PlayerLoginServer_CharacterDeleted, new object[] { playerId, true });
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void CharacterSelectAccept(uint playerId, byte permissions, byte ip0, byte ip1, byte ip2, byte ip3, int connectionServerPortId)
    {
        GLog.Log(new object[] { "CharacterSelectAccept" });
        CharacterManagementGui.singleton.RecordLastSelectedPlayer(playerId);
        UIClient.dcType = UIClient.DisconnectType.SWITCH;
        NetworkClient.serverConnection.Disconnect("Transfer to ConnectionServer");
        NetworkClient.serverConnection = null;
        NetworkClient.playerId = playerId;
        CommandClient.permissionLevel = (CommandCore.PermissionLevel) permissions;
        PlayerConnectionClient.ConnectToConnectionServer(new IPAddress(new byte[] { ip0, ip1, ip2, ip3 }), connectionServerPortId);
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void CharacterSelectFailure(string reason)
    {
        GLog.Log(new object[] { "CharacterSelectFailure" });
        CharacterManagementGui.singleton.SelectionError(reason);
    }

    public static void CharacterUndeleted(uint playerId)
    {
        NetworkClient.serverConnection.SendRpc(GRpcID.PlayerLoginServer_CharacterDeleted, new object[] { playerId, false });
    }

    public static void CheckTrainingPlayers(out string errorText, out string twinWarning)
    {
        int num = SparseArray.Count<uint>(trainingPlayerIds, SparseArray.UINT_ZERO);
        if (num == 0)
        {
            errorText = "At least one character must be training";
        }
        else if (num <= (maxTraining + numTwins))
        {
            errorText = null;
        }
        else
        {
            errorText = "Unable to change training, max: " + (maxTraining + numTwins);
        }
        twinWarning = null;
        if (num > maxTraining)
        {
            twinWarning = "Destiny's Twin allows you to select up to 2 characters to train simultaneously. Both of these characters will earn XP at the same rate.\nWarning! Once you select a second character and activate Destiny's Twin you will not be able to alter which of your characters is earning XP without losing the Destiny's Twin upgrade on your second character for good.";
        }
        else if (curTraining > maxTraining)
        {
            twinWarning = "One of these characters is training using Destiny's Twin. Changing training options for any character will remove Destiny's Twin for good, leaving you with only one character earning XP. You will be able to switch which character continues to earn XP but the advantage of Destiny's Twin will be lost.";
        }
    }

    public static void ClientSelectCharacter(uint playerId)
    {
        BitBuffer quickBuffer = GUtil.GetQuickBuffer();
        quickBuffer.PushUInt(playerId);
        int num = 0;
        foreach (KeyValuePair<int, int> pair in redeemItemIds)
        {
            num += pair.Value;
        }
        quickBuffer.PushInt(num);
        foreach (KeyValuePair<int, int> pair in redeemItemIds)
        {
            for (int i = 0; i < pair.Value; i++)
            {
                quickBuffer.PushInt(pair.Key);
            }
        }
        NetworkClient.serverConnection.SendRpc(GRpcID.PlayerLoginServer_CharacterSelected, new object[] { quickBuffer });
    }

    public static bool ConnectToLoginServer()
    {
        redeemItemIds.Clear();
        redeemableItems.Clear();
        GLog.Log(new object[] { "ConnectToLoginServer" });
        NetworkClient.errorMessage = null;
        NetworkClient.serverConnection = GNetworkService.ConnectToHost(NetworkClient.loginServerIP, 0x8fc, new GNetworkService.OnConnectionEventDelegate(PlayerLoginClient.OnConnectionClosed), GConst.RpcMode.FROM_SERVER);
        if (NetworkClient.serverConnection == null)
        {
            GLog.LogError(new object[] { "Could not connect to server:", NetworkClient.loginServerIP, 0x8fc });
            return false;
        }
        NetworkClient.DHStart();
        return true;
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void LoginResult(bool success, bool matchingVersions, long banTimeout)
    {
        GLog.Log(new object[] { "LoginResult" });
        if (!success)
        {
            ClientLoginGui.singleton.LoginFailure(matchingVersions, banTimeout);
        }
        else
        {
            GNetworkService.SetNetworkState(GNetworkService.NetworkState.CLIENT_CONNECTED);
            SceneService.LoadBySceneID(SceneService.SceneID.Client_CharacterSelect, false);
        }
    }

    private static void OnConnectionClosed(GNetworkConnection closedConnection)
    {
        GLog.Log(new object[] { "PlayerLoginClient.OnConnectionClosed" });
        if (!string.IsNullOrEmpty(closedConnection.remoteTerminateReason))
        {
            NetworkClient.errorMessage = "The server has dropped your connection: " + closedConnection.remoteTerminateReason;
        }
        GNetworkService.SetNetworkState(GNetworkService.NetworkState.CLIENT_DISCONNECTED);
        UIClient.OnDisconnectedFromServer();
        TerrainClient.Shutdown();
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void PlayerListResult(IBitBufferRead buffer)
    {
        int num2;
        CharacterManagementGui.singleton.SetDeletionTime(buffer.PopTime());
        CharacterManagementGui.singleton.SetPermissionLevel((CommandCore.PermissionLevel) buffer.PopByte());
        maxTraining = buffer.PopInt();
        numTwins = buffer.PopInt();
        curPlayers = PlayerInfo.Read(buffer);
        redeemableItems.Clear();
        int num = buffer.PopInt();
        for (num2 = 0; num2 < num; num2++)
        {
            redeemableItems[buffer.PopInt()] = buffer.PopInt();
        }
        int result = 0;
        int.TryParse(StartupParameters.RemoveParameterToProcess("hackKits"), out result);
        if (result > 0)
        {
            BasicItemData data = ItemDatabase.itemByName["new player pack"];
            redeemableItems[data.id] = result;
            data = ItemDatabase.itemByName["role pack"];
            redeemableItems[data.id] = result;
        }
        SparseArray.EnsureCapacity<uint>(ref trainingPlayerIds, curPlayers.Length);
        SparseArray.Clear<uint>(ref trainingPlayerIds, 0);
        GLog.Log(new object[] { "PlayerListResult", curPlayers.Length, SparseArray.Count<PlayerInfo>(curPlayers) });
        for (num2 = 0; num2 < curPlayers.Length; num2++)
        {
            if (curPlayers[num2].isTraining)
            {
                trainingPlayerIds[num2] = curPlayers[num2].playerId;
            }
        }
        curTraining = SparseArray.Count<uint>(trainingPlayerIds, SparseArray.UINT_ZERO);
        CharacterManagementGui.singleton.UpdateCharacters(curPlayers);
        RedeemWindowGui.singleton.Populate();
    }

    public static void RequestPlayerList()
    {
        NetworkClient.serverConnection.SendRpc(GRpcID.PlayerLoginServer_RequestPlayerList, new object[0]);
    }

    public static void ToggleTraining(uint playerId)
    {
        for (int i = 0; i < trainingPlayerIds.Length; i++)
        {
            if (trainingPlayerIds[i] == playerId)
            {
                trainingPlayerIds[i] = 0;
                return;
            }
        }
        SparseArray.Add<uint>(ref trainingPlayerIds, playerId, SparseArray.UINT_ZERO, 0);
    }

    public static void UpdateTrainingPlayers()
    {
        BitBuffer quickBuffer = GUtil.GetQuickBuffer();
        quickBuffer.PushInt(SparseArray.Count<uint>(trainingPlayerIds, SparseArray.UINT_ZERO));
        foreach (uint num in SparseArray.Iterate<uint>(trainingPlayerIds, SparseArray.UINT_ZERO))
        {
            quickBuffer.PushUInt(num);
        }
        NetworkClient.serverConnection.SendRpc(GRpcID.PlayerLoginServer_SwitchTraining, new object[] { quickBuffer });
    }

    public static bool WillBeTraining(uint playerId)
    {
        return ((playerId != 0) && SparseArray.Contains<uint>(trainingPlayerIds, playerId));
    }
}

