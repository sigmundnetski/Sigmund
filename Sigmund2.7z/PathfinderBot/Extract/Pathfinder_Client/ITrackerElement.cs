﻿using System;

public interface ITrackerElement
{
    string GetBody();
    string GetHoverText();
    string GetName();
    void OnClick();
}

