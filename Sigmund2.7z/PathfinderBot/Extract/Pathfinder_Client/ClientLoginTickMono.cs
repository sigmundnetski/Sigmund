﻿using System;
using UnityEngine;

public class ClientLoginTickMono : MonoBehaviour
{
    public string curState;
    public ClientLoginTick myTick;
    public static ClientLoginTickMono singleton;

    public void Awake()
    {
        singleton = this;
    }

    public void FixedUpdate()
    {
        this.myTick.FixedUpdate();
        this.curState = this.myTick.curState;
    }

    public void OnDestroy()
    {
        this.myTick.StopTicking();
        singleton = null;
    }

    public void Start()
    {
        this.myTick = new ClientLoginTick();
    }
}

