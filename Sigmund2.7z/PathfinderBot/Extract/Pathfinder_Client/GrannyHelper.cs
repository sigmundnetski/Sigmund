﻿using System;
using System.IO;
using UnityEngine;

public static class GrannyHelper
{
    private static readonly string ASSET_ANIM_PATH = GUtil.PathCombine(new object[] { "Assets", "animation", "" }).ToLower();
    private static readonly string FALLBACK_ANIM_PATH = GUtil.PathCombine(new object[] { GConst.depotDir, "bin", "Data", "Animations", "" }).ToLower();
    private static readonly string LOCAL_ANIM_DIR = GUtil.PathCombine(new object[] { Application.dataPath, "Animations", "" }).ToLower();

    public static void FixAnimPaths(GrannyAnimator anim)
    {
        string path = ASSET_ANIM_PATH;
        if (!Directory.Exists(path))
        {
            path = LOCAL_ANIM_DIR;
        }
        if (!Directory.Exists(path))
        {
            path = FALLBACK_ANIM_PATH;
        }
        if (path != ASSET_ANIM_PATH)
        {
            anim.sourceRigFile = anim.sourceRigFile.ToLower().Replace(ASSET_ANIM_PATH, path);
            anim.targetRigFile = anim.targetRigFile.ToLower().Replace(ASSET_ANIM_PATH, path);
            anim.machineFile = anim.machineFile.ToLower().Replace(ASSET_ANIM_PATH, path);
        }
    }
}

