﻿using GNetwork;
using GNGUI;
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class CharacterWindowGui : WindowGui
{
    private UILabel[,] abilityScores = new UILabel[6, 2];
    private UILabel[] attackAmounts = new UILabel[6];
    private UILabel[] defenseAmounts = new UILabel[4];
    private List<SkillInfoGui> displayedSkills = new List<SkillInfoGui>();
    private const int FREQUENCY_REDUCTION = 120;
    private int frequencyTick = 0;
    private UILabel genderLabel;
    private UILabel hpTotal;
    private bool initialized = false;
    private UILabel playerName;
    private UILabel raceLabel;
    private UILabel reputation;
    private UILabel[] resistanceAmounts = new UILabel[11];
    private UILabel roleMain;
    private UILabel roleOthers;
    public static CharacterWindowGui singleton;
    private UIGrid skillGrid;
    private GameObject skillPrefab;
    private UILabel xpAmount;

    public void Awake()
    {
        singleton = this;
        this.OnAwake();
    }

    public void ContentsChanged()
    {
        if (!this.initialized)
        {
            this.SetPlayerInfo();
        }
        this.UpdateRoles();
        this.UpdateAttacks();
        this.UpdateDefenses();
        this.UpdateResistances();
        this.UpdateAbilityScores();
        this.UpdateSkills();
        this.hpTotal.text = "Hit Points: " + EntityDataClient.owner.combat.GetMaxHitPoints().ToString();
        this.xpAmount.text = EntityDataClient.owner.advancementVars.PredictAvailableExpAtTime(GNetworkService.ServerUtc).ToString();
        this.reputation.text = "Reputation: " + Math.Round((double) EntityDataClient.owner.pvp.reputation).ToString();
    }

    public bool LoadingTickFinished()
    {
        this.skillPrefab = UIClient.guiPrefabs["CharSheetSkill"];
        GuiHelper.GuiAssertNotNull("Couldn't load prefab.", new object[] { this.skillPrefab });
        if (this.abilityScores.GetLength(0) != AbilityScoreData.scoreById.Count)
        {
            throw new GoblinGuiException(string.Concat(new object[] { "Ability Score lengths do not agree. UI: ", this.abilityScores.GetLength(0), " Data: ", AbilityScoreData.scoreById.Count }));
        }
        return true;
    }

    public void OnAwake()
    {
        ClientTick.characterGuiLoadFinish = new GUtil.BoolFilterDelegate(this.LoadingTickFinished);
        this.skillGrid = base.GetComponentInChildren<UIGrid>();
        GuiHelper.GuiAssertNotNull("Couldn't find children.", new object[] { this.skillGrid });
        foreach (UILabel label in base.GetComponentsInChildren<UILabel>())
        {
            if (label.name == "Amount0BAB")
            {
                this.attackAmounts[0] = label;
            }
            else if (label.name == "Amount1Heavy")
            {
                this.attackAmounts[1] = label;
            }
            else if (label.name == "Amount2Light")
            {
                this.attackAmounts[2] = label;
            }
            else if (label.name == "Amount3Ranged")
            {
                this.attackAmounts[3] = label;
            }
            else if (label.name == "Amount4Arcane")
            {
                this.attackAmounts[5] = label;
            }
            else if (label.name == "Amount5Divine")
            {
                this.attackAmounts[4] = label;
            }
            else if (label.name == "Amount1Will")
            {
                this.defenseAmounts[3] = label;
            }
            else if (label.name == "Amount2Reflex")
            {
                this.defenseAmounts[1] = label;
            }
            else if (label.name == "Amount3Fortitude")
            {
                this.defenseAmounts[2] = label;
            }
            else if (label.name == "Gender")
            {
                this.genderLabel = label;
            }
            else if (label.name == "HitPoints")
            {
                this.hpTotal = label;
            }
            else if (label.name == "Reputation")
            {
                this.reputation = label;
            }
            else if (label.name == "PlayerName")
            {
                this.playerName = label;
            }
            else if (label.name == "Race")
            {
                this.raceLabel = label;
            }
            else if (label.name == "Amount01Physical")
            {
                this.resistanceAmounts[0] = label;
            }
            else if (label.name == "Amount02Fire")
            {
                this.resistanceAmounts[1] = label;
            }
            else if (label.name == "Amount03Acid")
            {
                this.resistanceAmounts[5] = label;
            }
            else if (label.name == "Amount04Sonic")
            {
                this.resistanceAmounts[4] = label;
            }
            else if (label.name == "Amount05Holy")
            {
                this.resistanceAmounts[7] = label;
            }
            else if (label.name == "Amount06Psychic")
            {
                this.resistanceAmounts[9] = label;
            }
            else if (label.name == "Amount07Cold")
            {
                this.resistanceAmounts[2] = label;
            }
            else if (label.name == "Amount08Electricity")
            {
                this.resistanceAmounts[3] = label;
            }
            else if (label.name == "Amount09Force")
            {
                this.resistanceAmounts[8] = label;
            }
            else if (label.name == "Amount10Negative")
            {
                this.resistanceAmounts[6] = label;
            }
            else if (label.name == "RoleMain")
            {
                this.roleMain = label;
            }
            else if (label.name == "RoleOther")
            {
                this.roleOthers = label;
            }
            else if (label.name == "StatLabel0")
            {
                this.abilityScores[0, 0] = label;
            }
            else if (label.name == "StatAmount0")
            {
                this.abilityScores[0, 1] = label;
            }
            else if (label.name == "StatLabel1")
            {
                this.abilityScores[1, 0] = label;
            }
            else if (label.name == "StatAmount1")
            {
                this.abilityScores[1, 1] = label;
            }
            else if (label.name == "StatLabel2")
            {
                this.abilityScores[2, 0] = label;
            }
            else if (label.name == "StatAmount2")
            {
                this.abilityScores[2, 1] = label;
            }
            else if (label.name == "StatLabel3")
            {
                this.abilityScores[3, 0] = label;
            }
            else if (label.name == "StatAmount3")
            {
                this.abilityScores[3, 1] = label;
            }
            else if (label.name == "StatLabel4")
            {
                this.abilityScores[4, 0] = label;
            }
            else if (label.name == "StatAmount4")
            {
                this.abilityScores[4, 1] = label;
            }
            else if (label.name == "StatLabel5")
            {
                this.abilityScores[5, 0] = label;
            }
            else if (label.name == "StatAmount5")
            {
                this.abilityScores[5, 1] = label;
            }
            else if (label.name == "AmountXP")
            {
                this.xpAmount = label;
            }
        }
        this.defenseAmounts[0] = this.defenseAmounts[2];
        this.resistanceAmounts[10] = this.resistanceAmounts[1];
        GuiHelper.GuiAssertNotNull("Couldn't find attack labels.", this.attackAmounts);
        GuiHelper.GuiAssertNotNull("Couldn't find defense labels.", this.defenseAmounts);
        GuiHelper.GuiAssertNotNull("Couldn't find resistance labels.", this.resistanceAmounts);
        GuiHelper.GuiAssertNotNull("Couldn't find abilityScore labels.", this.abilityScores);
        GuiHelper.GuiAssertNotNull("Couldn't find children.", new object[] { this.genderLabel, this.hpTotal, this.playerName, this.raceLabel, this.roleMain, this.roleOthers, this.xpAmount });
    }

    public static void OnClientEntityUpdate(Entity entity)
    {
        if (((entity == EntityDataClient.owner) && (singleton != null)) && singleton.IsShowing())
        {
            singleton.ContentsChanged();
        }
    }

    public override void OnDestroy()
    {
        base.OnDestroy();
        singleton = null;
    }

    private void SetPlayerInfo()
    {
        this.initialized = true;
        this.playerName.text = EntityDataClient.owner.EntityName;
        this.genderLabel.text = "Gender: Androgynous";
        NGUITools.SetActive(this.genderLabel.gameObject, false);
        RaceData data = RaceData.raceById[EntityDataClient.owner.entityDefn.raceId];
        this.raceLabel.text = "Race: " + data.displayName;
    }

    public override void ShowWindow()
    {
        base.ShowWindow();
        this.ContentsChanged();
    }

    public void Start()
    {
        base.Init(3, true);
    }

    public void SyncFixedUpdate()
    {
        this.frequencyTick = (this.frequencyTick + 1) % 120;
        if ((this.frequencyTick == 0) && base.IsShowing())
        {
            this.xpAmount.text = EntityDataClient.owner.advancementVars.PredictAvailableExpAtTime(GNetworkService.ServerUtc).ToString();
        }
    }

    public void ToggleCharacterWindow(string[] args, EntityId playerEntityId)
    {
        this.ToggleWindowVisibility();
    }

    private void UpdateAbilityScores()
    {
        foreach (KeyValuePair<int, AbilityScoreData> pair in AbilityScoreData.scoreById)
        {
            AbilityScoreData data = pair.Value;
            this.abilityScores[data.scoreIndex, 0].text = data.displayName;
            this.abilityScores[data.scoreIndex, 1].text = ((int) EntityDataClient.owner.advancementVars.GetAbilityScore(data.scoreIndex)).ToString();
        }
    }

    private void UpdateAttacks()
    {
        for (int i = 0; i < this.attackAmounts.Length; i++)
        {
            this.attackAmounts[i].text = EntityDataClient.owner.combat.GetAttackBonus((AttackType) ((byte) i)).ToString();
        }
    }

    private void UpdateDefenses()
    {
        for (int i = 0; i < this.defenseAmounts.Length; i++)
        {
            if (((byte) i) != 0)
            {
                this.defenseAmounts[i].text = EntityDataClient.owner.combat.GetDefenseBonus((DefenseType) ((byte) i), EntityDataClient.owner.combat.combatClass.GetArmor()).ToString();
            }
        }
    }

    private void UpdateResistances()
    {
        for (int i = 0; i < this.resistanceAmounts.Length; i++)
        {
            if (((byte) i) != 10)
            {
                this.resistanceAmounts[i].text = EntityDataClient.owner.combat.GetResistanceBonus((ResistanceType) ((byte) i)).ToString();
            }
        }
    }

    private void UpdateRoles()
    {
        this.roleMain.text = "Roles:";
        IOrderedEnumerable<KeyValuePair<string, byte>> enumerable2 = from each in EntityDataClient.owner.advancementVars.GetAllLevels()
            orderby each.Key
            select each;
        List<string> list = new List<string>();
        foreach (KeyValuePair<string, byte> pair in enumerable2)
        {
            list.Add(pair.Key + " " + pair.Value);
        }
        this.roleOthers.text = string.Join(",", list.ToArray());
    }

    private void UpdateSkills()
    {
        int index = 0;
        while (index < SkillData.skillByIndex.Length)
        {
            if (index >= this.displayedSkills.Count)
            {
                SkillInfoGui component = NGUITools.AddChild(this.skillGrid.gameObject, this.skillPrefab).GetComponent<SkillInfoGui>();
                this.displayedSkills.Add(component);
            }
            this.displayedSkills[index].Assign(SkillData.skillByIndex[index]);
            index++;
        }
        while (this.displayedSkills.Count > index)
        {
            SkillInfoGui gui2 = this.displayedSkills[this.displayedSkills.Count - 1];
            this.displayedSkills.RemoveAt(this.displayedSkills.Count - 1);
            gui2.gameObject.SetActive(false);
            gui2.transform.parent = DragDropRoot.root;
            UnityEngine.Object.Destroy(gui2.gameObject);
        }
        this.skillGrid.repositionNow = true;
    }
}

