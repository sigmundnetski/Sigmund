﻿using GNGUI;
using System;
using System.Runtime.CompilerServices;
using UnityEngine;

public class ItemQtyGui : WindowGui
{
    private UIImageButton acceptButton;
    private UILabel acceptLabel;
    private Callback callback;
    private float curQty;
    private InventoryItem fullStack;
    private UILabel maxQtyLabel;
    private UIInput qtyInput;
    private UIScrollBar qtySlider;
    public static ItemQtyGui singleton;

    public void AcceptButtonClicked(GameObject go)
    {
        uint num;
        uint.TryParse(this.qtyInput.text, out num);
        this.callback(InventoryItem.ChangeQuantity(this.fullStack, num));
        this.HideWindow();
    }

    public void Awake()
    {
        singleton = this;
    }

    public override void OnDestroy()
    {
        base.OnDestroy();
        singleton = null;
    }

    public void OnSliderChange(UIScrollBar sb)
    {
        this.UpdateCurQty(sb.scrollValue * this.fullStack.quantity);
    }

    public void OnSliderFinish()
    {
        this.UpdateCurQty(this.qtySlider.scrollValue * this.fullStack.quantity);
    }

    public void OnTextChanged(GameObject go, string newText)
    {
        uint num;
        if (uint.TryParse(this.qtyInput.text, out num))
        {
            this.UpdateCurQty((float) num);
        }
    }

    public void Populate(Callback _callback, string acceptText, InventoryItem _fullStack)
    {
        this.callback = _callback;
        this.maxQtyLabel.text = _fullStack.quantity.ToString();
        this.acceptLabel.text = acceptText;
        this.fullStack = _fullStack;
        this.acceptLabel.text = acceptText;
        this.UpdateCurQty(1f);
        this.ShowWindow();
    }

    public void Start()
    {
        this.qtySlider = base.GetComponentInChildren<UIScrollBar>();
        this.qtyInput = base.GetComponentInChildren<UIInput>();
        foreach (UILabel label in base.GetComponentsInChildren<UILabel>())
        {
            if (label.name == "MaxQtyLabel")
            {
                this.maxQtyLabel = label;
            }
        }
        foreach (UIImageButton button in base.GetComponentsInChildren<UIImageButton>())
        {
            if (button.name == "AcceptButton")
            {
                this.acceptButton = button;
                this.acceptLabel = button.GetComponentInChildren<UILabel>();
            }
        }
        GuiHelper.GuiAssertNotNull("ItemQtyGui", new object[] { this.acceptButton, this.qtySlider, this.maxQtyLabel, this.qtyInput });
        UIEventListener listener1 = UIEventListener.Get(this.acceptButton.gameObject);
        listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.AcceptButtonClicked));
        UIEventListener listener2 = UIEventListener.Get(this.qtyInput.gameObject);
        listener2.onInput = (UIEventListener.StringDelegate) Delegate.Combine(listener2.onInput, new UIEventListener.StringDelegate(this.OnTextChanged));
        this.qtySlider.onChange = new UIScrollBar.OnScrollBarChange(this.OnSliderChange);
        this.qtySlider.onDragFinished = new UIScrollBar.OnDragFinished(this.OnSliderFinish);
        base.Init(2, true);
    }

    private void UpdateCurQty(float newQty)
    {
        this.curQty = Math.Min(Math.Max(1f, newQty), (float) this.fullStack.quantity);
        this.qtySlider.scrollValue = Math.Min(Math.Max((float) 0f, (float) ((1f * this.curQty) / ((float) this.fullStack.quantity))), 1f);
        this.qtyInput.text = this.curQty.ToString("f0");
    }

    public delegate void Callback(InventoryItem updatedStack);
}

