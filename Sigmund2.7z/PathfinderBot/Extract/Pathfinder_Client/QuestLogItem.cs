﻿using GNGUI;
using System;
using System.Text;
using UnityEngine;

public class QuestLogItem : MonoBehaviour
{
    private UIImageButton abandonButton;
    private UILabel displayName;
    private bool onClickSet = false;
    private QuestLogGui parent;
    private const string pin_cl = "panel_button_pin_cl";
    private const string pin_de = "panel_button_pin_ac";
    private const string pin_mo = "panel_button_pin_mo";
    private UIImageButton pinButton;
    public int questId = 0;
    private UILabel shortDescription;
    private const string unpin_cl = "panel_button_unpin_cl";
    private const string unpin_de = "panel_button_unpin_de";
    private const string unpin_mo = "panel_button_unpin_mo";

    private void CheckButtons()
    {
        if (this.pinButton == null)
        {
            this.pinButton = base.transform.FindChild("PinButton").GetComponent<UIImageButton>();
        }
        if (this.abandonButton == null)
        {
            this.abandonButton = base.transform.FindChild("AbandonButton").GetComponent<UIImageButton>();
        }
        if (!this.onClickSet)
        {
            UIEventListener listener1 = UIEventListener.Get(this.pinButton.gameObject);
            listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.OnPinClicked));
            UIEventListener listener2 = UIEventListener.Get(this.abandonButton.gameObject);
            listener2.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener2.onClick, new UIEventListener.VoidDelegate(this.OnAbandonClicked));
            this.onClickSet = true;
        }
    }

    private void OnAbandonClicked(GameObject clickedGO)
    {
        QuestClient.AbandonQuest(this.questId);
    }

    public void OnClick()
    {
        QuestClient.SetQuestBlob(new int[] { this.questId });
    }

    private void OnPinClicked(GameObject clickedGO)
    {
        QuestClient.TogglePinButton(this.questId);
        this.UpdatePin(true);
    }

    public void OnTooltip(bool show)
    {
        QuestData data;
        if (show && QuestData.questById.TryGetValue(this.questId, out data))
        {
            QuestRecord quest = EntityDataClient.owner.playerRecord.GetQuest(data.id);
            StringBuilder quickText = GUtil.GetQuickText();
            quickText.Append(data.displayName);
            quickText.Append("\n");
            quickText.Append(data.longDescription);
            if (quest != null)
            {
                quickText.Append("\n\nObjective:\n");
                quickText.Append("[F0E3A8]");
                QuestData.AppendObjective(quickText, quest, true);
                quickText.Append("[-]\n");
            }
            this.parent.tooltip.ShowText(quickText.ToString(), this.parent.gameObject);
        }
        else
        {
            this.parent.tooltip.ShowText(null, null);
        }
    }

    public void SetQuest(QuestLogGui _parent, QuestRecord qRecord)
    {
        QuestData data;
        this.parent = _parent;
        this.questId = qRecord.questId;
        if (this.displayName == null)
        {
            this.displayName = base.transform.FindChild("DisplayName").GetComponent<UILabel>();
        }
        if (this.shortDescription == null)
        {
            this.shortDescription = base.transform.FindChild("ShortDescription").GetComponent<UILabel>();
        }
        if (QuestData.questById.TryGetValue(this.questId, out data))
        {
            base.gameObject.name = this.displayName.text = data.displayName;
            this.shortDescription.text = data.shortDescription;
        }
        else
        {
            this.displayName.text = "<Invalid Quest " + this.questId + ">";
        }
        this.UpdateAbandonButton(qRecord);
    }

    private void UpdateAbandonButton(QuestRecord qRecord)
    {
        this.CheckButtons();
        this.abandonButton.gameObject.SetActive(qRecord.CanAbandon());
    }

    public void UpdatePin(bool showPin)
    {
        this.CheckButtons();
        bool flag = QuestClient.IsPinned(this.questId);
        this.pinButton.gameObject.SetActive(showPin || flag);
        if (QuestClient.IsPinned(this.questId))
        {
            this.pinButton.normalSprite = "panel_button_pin_ac";
            this.pinButton.hoverSprite = "panel_button_pin_mo";
            this.pinButton.pressedSprite = "panel_button_pin_cl";
            if (EventBarGui.singleton != null)
            {
                EventBarGui.singleton.ShowPanel();
            }
        }
        else
        {
            this.pinButton.normalSprite = "panel_button_unpin_de";
            this.pinButton.hoverSprite = "panel_button_unpin_mo";
            this.pinButton.pressedSprite = "panel_button_unpin_cl";
        }
        this.pinButton.SendMessage("OnHover", false, SendMessageOptions.DontRequireReceiver);
    }
}

