﻿using System;

public class ClientCompany
{
    public ulong companyId;
    public string[] members;
    public string name;
    public VentureCompanyMember.MemberPermission permissions;
    public byte priority;
    public uint settlementId;

    public ClientCompany(ulong companyId)
    {
        this.companyId = companyId;
        this.name = "";
        this.members = new string[0];
        this.permissions = VentureCompanyMember.MemberPermission.NONE;
    }
}

