﻿using GNGUI;
using System;
using UnityEngine;

public class AuctionItemGui : MonoBehaviour
{
    protected UISprite icon;
    protected InventoryItem item;
    protected UILabel nameLabel;
    protected Color prevColor = AuctionHouseGui.NORMAL_TEXT;
    protected bool selected;

    public void OnHover(bool isHovered)
    {
        if (isHovered)
        {
            this.nameLabel.color = AuctionHouseGui.HOVERED_TEXT;
        }
        else
        {
            this.nameLabel.color = this.prevColor;
        }
    }

    public virtual void SetData(InventoryItem item_)
    {
        GuiHelper.GuiAssertNotNull("Couldn't find needed children.", new object[] { this.nameLabel, this.icon });
        this.item = item_;
        BasicItemData item = ItemDatabase.GetItem(this.item.staticItemId);
        if (item == null)
        {
            base.name = "ZZZ";
            this.nameLabel.text = string.Empty;
        }
        else
        {
            GuiHelper.SetItemIcon(this.icon, this.item, item);
            base.name = item.name + this.item.upgrade;
            this.nameLabel.text = this.item.GetDisplayName(false);
        }
    }

    public void UpdateSelected(InventoryItem selectedItem)
    {
        this.selected = (this.item.staticItemId == selectedItem.staticItemId) && (this.item.upgrade == selectedItem.upgrade);
        this.nameLabel.color = this.selected ? AuctionHouseGui.SELECTED_TEXT : AuctionHouseGui.NORMAL_TEXT;
        this.prevColor = this.selected ? AuctionHouseGui.SELECTED_TEXT : AuctionHouseGui.NORMAL_TEXT;
    }
}

