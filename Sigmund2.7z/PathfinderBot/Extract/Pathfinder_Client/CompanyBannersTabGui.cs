﻿using GNGUI;
using System;
using UnityEngine;

public class CompanyBannersTabGui : CompanyAlliancesTabGui
{
    private UIImageButton breakAllianceButton;

    public override void AllianceSelected(ulong companyId_, uint settlementId_)
    {
        base.AllianceSelected(companyId_, settlementId_);
        VentureCompanyRecord company = GroupClient.GetCompany(base.companyId);
        if ((companyId_ == 0L) || (company == null))
        {
            NGUITools.SetActive(this.breakAllianceButton.gameObject, false);
        }
        else
        {
            SettlementRecord settlement = GroupClient.GetSettlement(company.settlementId);
            if ((settlement != null) && (base.companyId == settlement.ownerCompanyId))
            {
                NGUITools.SetActive(this.breakAllianceButton.gameObject, false);
            }
            else if (GroupClient.InOwnerCompany(company))
            {
                VentureCompanyMember member = GroupClient.GetSettlementCompany().FindMember(EntityDataClient.owner.playerId);
                NGUITools.SetActive(this.breakAllianceButton.gameObject, member.HasPermission(VentureCompanyMember.MemberPermission.ALLY_KICK));
            }
            else
            {
                NGUITools.SetActive(this.breakAllianceButton.gameObject, false);
            }
        }
    }

    public override void Awake()
    {
        base.Awake();
        base.tabSpriteName = "frame_company_header_tab_left";
        foreach (UIImageButton button in base.GetComponentsInChildren<UIImageButton>())
        {
            if (button.name == "ButtonBreakAlliance")
            {
                this.breakAllianceButton = button;
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find buttons.", new object[] { this.breakAllianceButton });
        UIEventListener listener1 = UIEventListener.Get(this.breakAllianceButton.gameObject);
        listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.BreakAllianceClicked));
        NGUITools.SetActive(this.breakAllianceButton.gameObject, false);
    }

    public void BreakAllianceClicked(GameObject go)
    {
        GroupClient.BreakAlliance(base.companyId, base.settlementId);
    }

    protected override void MakeListItems()
    {
        VentureCompanyRecord company = GroupClient.GetCompany(CompanyWindowGui.companyId);
        SettlementRecord settlement = null;
        int count = 0;
        if (company != null)
        {
            settlement = GroupClient.GetSettlement(company.settlementId);
        }
        if (settlement != null)
        {
            count = SparseArray.Count<ulong>(settlement.memberCompanyIds, GroupConst.EMPTY_COMPANY);
        }
        UIGrid.SetElementCount<TabListItem>(DragDropRoot.root, base.gridList, base.listItemPrefab, base.displayedItems, count);
        int index = 0;
        int num3 = 0;
        bool flag = false;
        if ((settlement != null) && (settlement.memberCompanyIds != null))
        {
            while (index < settlement.memberCompanyIds.Length)
            {
                if (settlement.memberCompanyIds[index] != 0L)
                {
                    ((CompanyAllyInfo) base.displayedItems[num3]).Assign(settlement.memberCompanyIds[index], settlement, this, num3, false);
                    num3++;
                    flag = flag || (settlement.memberCompanyIds[index] == base.companyId);
                }
                index++;
            }
        }
        if (!flag)
        {
            base.companyId = 0L;
        }
        this.AllianceSelected(base.companyId, base.settlementId);
    }
}

