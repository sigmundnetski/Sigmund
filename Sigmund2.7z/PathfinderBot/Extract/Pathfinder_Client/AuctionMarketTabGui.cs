﻿using GNGUI;
using System;
using System.Collections.Generic;
using UnityEngine;

public class AuctionMarketTabGui : AuctionHouseTabGui
{
    private UIImageButton bidButton;
    private UIImageButton buyButton;
    public ItemOffer currentItem = null;
    private List<AuctionMarketItemGui> marketItemGuis = new List<AuctionMarketItemGui>();
    private GameObject marketItemPrefab;
    public static AuctionMarketTabGui singleton;
    private List<ItemOffer> visibleItems = new List<ItemOffer>();

    public void Awake()
    {
        singleton = this;
        this.OnAwake();
    }

    public override void ContentsChanged()
    {
        if (base.IsShowing())
        {
            this.Repopulate(AuctionHouseGui.singleton.currentMarketItems);
        }
    }

    private ItemOffer GetItem()
    {
        if (this.currentItem != null)
        {
            return this.currentItem;
        }
        ItemOffer offer = null;
        for (int i = 0; i < AuctionHouseGui.singleton.currentMarketItems.Length; i++)
        {
            if (offer == null)
            {
                offer = AuctionHouseGui.singleton.currentMarketItems[i];
            }
            else if (AuctionHouseGui.singleton.currentMarketItems[i].curPrice < offer.curPrice)
            {
                offer = AuctionHouseGui.singleton.currentMarketItems[i];
            }
        }
        return offer;
    }

    public override void ItemInterest(InventoryItem item)
    {
        int num;
        for (num = 0; num < this.marketItemGuis.Count; num++)
        {
            this.marketItemGuis[num].UpdateSelected(item);
        }
        if ((this.currentItem == null) || !this.currentItem.item.DataEquals(item, 0xff))
        {
            ItemOffer[] currentMarketItems = AuctionHouseGui.singleton.currentMarketItems;
            if (currentMarketItems != null)
            {
                bool flag = false;
                for (num = 0; num < currentMarketItems.Length; num++)
                {
                    bool flag2 = currentMarketItems[num].item.staticItemId == item.staticItemId;
                    flag = flag || flag2;
                    if (flag2 && (this.currentItem == null))
                    {
                        this.currentItem = currentMarketItems[num];
                    }
                    else if (flag2 && (this.currentItem.item.staticItemId != item.staticItemId))
                    {
                        this.currentItem = currentMarketItems[num];
                    }
                }
                if (!flag)
                {
                    this.currentItem = null;
                }
            }
        }
    }

    public override void LoadingTickFinished()
    {
        this.marketItemPrefab = UIClient.guiPrefabs["MarketItem"];
    }

    private void OnAwake()
    {
        foreach (UIImageButton button in base.GetComponentsInChildren<UIImageButton>())
        {
            if (button.name == "ButtonBid")
            {
                this.bidButton = button;
                UIEventListener listener1 = UIEventListener.Get(this.bidButton.gameObject);
                listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.OnBidClick));
            }
            else if (button.name == "ButtonBuy")
            {
                this.buyButton = button;
                UIEventListener listener2 = UIEventListener.Get(this.buyButton.gameObject);
                listener2.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener2.onClick, new UIEventListener.VoidDelegate(this.OnBuyClick));
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find needed children.", new object[] { this.bidButton, this.buyButton });
        base.Init("MarketItemsGrid");
    }

    public void OnBidClick(GameObject filterGO)
    {
        AuctionItemPopupGui.singleton.Repopulate(this.GetItem(), AuctionItemPopupGui.InputType.BID);
    }

    public void OnBuyClick(GameObject filterGO)
    {
        AuctionItemPopupGui.singleton.Repopulate(this.GetItem(), AuctionItemPopupGui.InputType.BUY);
    }

    public void OnDestroy()
    {
        singleton = null;
    }

    public void OnItemBuyClick(ItemOffer marketItem)
    {
        this.OnItemSelected(marketItem);
        AuctionItemPopupGui.singleton.Repopulate(this.GetItem(), AuctionItemPopupGui.InputType.BUY);
    }

    public void OnItemSelected(ItemOffer marketItem)
    {
        this.currentItem = marketItem;
        base.OnItemSelected((marketItem == null) ? InventoryItem.EMPTY : marketItem.item, AuctionHouseGui.Tabs.MARKET);
        if (AuctionItemPopupGui.singleton.IsShowing())
        {
            AuctionItemPopupGui.singleton.Repopulate(this.GetItem(), AuctionItemPopupGui.singleton.currentType);
        }
    }

    private void Repopulate(ItemOffer[] marketItems)
    {
        int count = (marketItems == null) ? 0 : marketItems.Length;
        UIGrid.SetElementCount<AuctionMarketItemGui>(DragDropRoot.root, base.gridList, this.marketItemPrefab, this.marketItemGuis, count);
        for (int i = 0; i < count; i++)
        {
            this.marketItemGuis[i].SetData(marketItems[i]);
        }
        if (count == 0)
        {
            AuctionHouseGui.singleton.ShowTabItemInfo("No market items.");
        }
        else
        {
            AuctionHouseGui.singleton.ShowTabItemInfo(string.Empty);
        }
    }

    public override void ShowTab()
    {
        base.ShowTab();
        this.Repopulate(AuctionHouseGui.singleton.currentMarketItems);
    }
}

