﻿using GNetwork;
using System;
using System.Net;

public static class PlayerConnectionClient
{
    public static bool ConnectToConnectionServer(IPAddress connServerIp, int portId)
    {
        GLog.Log(new object[] { "ConnectToConnectionServer", connServerIp, portId });
        NetworkClient.serverConnection = GNetworkService.ConnectToHost(connServerIp, portId, new GNetworkService.OnConnectionEventDelegate(PlayerConnectionClient.OnConnectionClosed), GConst.RpcMode.FROM_SERVER);
        if (NetworkClient.serverConnection != null)
        {
            NetworkClient.DHStart();
        }
        return (NetworkClient.serverConnection != null);
    }

    public static void InGame()
    {
        GLog.Log(new object[] { "InGame" });
        NetworkClient.serverConnection.SendRpc(GRpcID.PlayerConnectionServer_InGame, new object[0]);
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void InGameResult(bool success)
    {
        GLog.Log(new object[] { "InGameResult" });
        if (!success)
        {
            NetworkClient.errorMessage = "Server entity collection is full.  Unable to create player entity.";
            GLog.LogError(new object[] { NetworkClient.errorMessage });
        }
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void LoadEnvironmentScene(string sceneName, ushort mapId)
    {
        GLog.Log(new object[] { "LoadEnvironmentScene" });
        ClientTickMono.singleton.LoadEnvironmentScene(sceneName, mapId);
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void LoadGameClient()
    {
        GLog.Log(new object[] { "LoadGameClient" });
        SceneService.LoadAndStartClientMainFromBundle();
    }

    private static void OnConnectionClosed(GNetworkConnection closedConnection)
    {
        NetworkClient.playerId = 0;
        GLog.Log(new object[] { "PlayerConnectionClient.OnConnectionClosed" });
        if (!string.IsNullOrEmpty(closedConnection.remoteTerminateReason))
        {
            NetworkClient.errorMessage = "The server has dropped your connection: " + closedConnection.remoteTerminateReason;
        }
        GNetworkService.SetNetworkState(GNetworkService.NetworkState.CLIENT_DISCONNECTED);
        EncounterClient.OnDisconnectedFromServer();
        EntityClient.OnDisconnectedFromServer();
        CombatClient.OnDisconnectedFromServer();
        UIClient.OnDisconnectedFromServer();
        TerrainClient.Shutdown();
    }

    public static void StartGame()
    {
        GLog.Log(new object[] { "StartGame" });
        NetworkClient.serverConnection.SendRpc(GRpcID.PlayerConnectionServer_StartGame, new object[0]);
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void TryAgain()
    {
        GLog.Log(new object[] { "TryAgain" });
        NetworkClient.DHStart();
    }
}

