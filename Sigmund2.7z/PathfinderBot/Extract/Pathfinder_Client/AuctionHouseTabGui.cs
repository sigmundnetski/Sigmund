﻿using GNGUI;
using System;
using UnityEngine;

public class AuctionHouseTabGui : MonoBehaviour
{
    protected UIGrid gridList;
    protected UIScrollBar scrollBar;

    public virtual void ContentsChanged()
    {
    }

    public virtual void HideTab()
    {
        NGUITools.SetActive(base.gameObject, false);
    }

    protected void Init(string gridName)
    {
        foreach (UIGrid grid in base.GetComponentsInChildren<UIGrid>())
        {
            if (grid.name == gridName)
            {
                this.gridList = grid;
            }
        }
        foreach (UIScrollBar bar in base.transform.parent.GetComponentsInChildren<UIScrollBar>())
        {
            if (bar.name == "CommonScrollbar")
            {
                this.scrollBar = bar;
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find needed children.", new object[] { this.gridList, this.scrollBar });
    }

    public bool IsShowing()
    {
        return NGUITools.GetActive(base.gameObject);
    }

    public virtual void ItemInterest(InventoryItem item)
    {
    }

    public virtual void LoadingTickFinished()
    {
    }

    public virtual void OnItemSelected(InventoryItem item, AuctionHouseGui.Tabs itemSource)
    {
        AuctionHouseGui.singleton.ItemInterest(item, itemSource);
    }

    public virtual void RepositionListItems()
    {
        this.gridList.repositionNow = true;
    }

    public void ResetScroll()
    {
        this.scrollBar.scrollValue = 0f;
    }

    public virtual void ShowTab()
    {
        this.ResetScroll();
        AuctionHouseGui.singleton.ShowTabItemInfo(string.Empty);
        NGUITools.SetActive(base.gameObject, true);
        NGUITools.SetActive(this.scrollBar.gameObject, true);
    }
}

