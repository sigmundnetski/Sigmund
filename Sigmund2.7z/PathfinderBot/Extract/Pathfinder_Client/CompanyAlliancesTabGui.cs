﻿using System;
using UnityEngine;

public abstract class CompanyAlliancesTabGui : WindowTabGui
{
    protected ulong companyId = 0L;
    protected uint settlementId = 0;

    protected CompanyAlliancesTabGui()
    {
    }

    public virtual void AllianceSelected(ulong companyId_, uint settlementId_)
    {
        this.companyId = companyId_;
        this.settlementId = settlementId_;
        for (int i = 0; i < base.displayedItems.Count; i++)
        {
            ((CompanyAllyInfo) base.displayedItems[i]).AllianceSelected(this.companyId, this.settlementId);
        }
    }

    public override void Awake()
    {
        base.Awake();
        base.prefabName = "CompanyAllyInfo";
    }

    public override void ContentsChanged()
    {
        this.MakeListItems();
    }

    public virtual void DisplayCompanies()
    {
        this.ContentsChanged();
    }

    public override void FilterClicked(GameObject filterGO)
    {
    }

    public override void ShowTab()
    {
        this.ContentsChanged();
        base.ShowTab();
    }
}

