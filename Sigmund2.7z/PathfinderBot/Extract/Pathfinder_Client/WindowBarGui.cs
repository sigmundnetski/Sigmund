﻿using GNGUI;
using System;
using UnityEngine;

public class WindowBarGui : MonoBehaviour
{
    private readonly string[,] ENCUMBRANCE_SPRITES = new string[,] { { "button_mainmenu_inventory_ac", "button_mainmenu_inventory_de" }, { "button_mainmenu_inventory_ac", "button_mainmenu_inventory100_de" }, { "button_mainmenu_inventory_ac", "button_mainmenu_inventory200_de" } };
    private UIImageButton[] menuButtons = new UIImageButton[9];
    private float MIN_HEAVY = 2f;
    private float MIN_LIGHT = 1f;
    private readonly string[,] NORMAL_SPRITES = new string[,] { { "button_mainmenu_ribbon_ac", "button_mainmenu_ribbon_de" }, { "button_mainmenu_paperdoll_ac", "button_mainmenu_paperdoll_de" }, { "button_mainmenu_map_ac", "button_mainmenu_map_de" }, { "button_mainmenu_activefeats_ac", "button_mainmenu_activefeats_de" }, { "button_mainmenu_inventory_ac", "button_mainmenu_inventory_de" }, { "button_mainmenu_charsheet_ac", "button_mainmenu_charsheet_de" }, { "button_mainmenu_achievements_ac", "button_mainmenu_achievements_de" }, { "button_mainmenu_quest_ac", "button_mainmenu_quest_de" }, { "button_mainmenu_political_ac", "button_mainmenu_political_de" } };
    private Encumbrance prevEnc = Encumbrance.UNENCUMBERED;
    private bool[] prevVisibility = new bool[9];
    public static WindowBarGui singleton;

    public void AchievementClicked(GameObject go)
    {
        AchievementsWindowGui.singleton.ToggleWindowVisibility();
    }

    public void Awake()
    {
        singleton = this;
    }

    public void CharacterClicked(GameObject go)
    {
        CharacterWindowGui.singleton.ToggleWindowVisibility();
    }

    public void EscapeClicked(GameObject go)
    {
        if (EscapeMenuGui.singleton.IsShowing())
        {
            EscapeMenuGui.singleton.HideWindow();
        }
        else
        {
            EscapeMenuGui.singleton.ShowWindow();
        }
    }

    public void FeatsClicked(GameObject go)
    {
        FeatsWindowGui.singleton.ToggleFeatsWindow(null, PlayerEntityClient.GetPlayerEntityId());
    }

    public void InventoryClicked(GameObject go)
    {
        InventoryWindowGui.singleton.ToggleInventoryWindow(null, PlayerEntityClient.GetPlayerEntityId());
    }

    public void MapClicked(GameObject go)
    {
        MapWindowGui.singleton.ToggleWindowVisibility();
    }

    public void OnDestroy()
    {
        singleton = null;
    }

    public void PaperdollClicked(GameObject go)
    {
        PaperdollWindowGui.singleton.ToggleWindowVisibility();
    }

    public void PoliticalClicked(GameObject go)
    {
        CompanySearchWindowGui.singleton.ToggleWindowVisibility();
    }

    public void QuestLogClicked(GameObject go)
    {
        QuestLogGui.singleton.ToggleWindowVisibility();
    }

    public void Start()
    {
        foreach (UIImageButton button in base.GetComponentsInChildren<UIImageButton>())
        {
            if (button.name.Contains("EscapeMenuButton"))
            {
                this.menuButtons[0] = button;
                UIEventListener listener1 = UIEventListener.Get(button.gameObject);
                listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.EscapeClicked));
            }
            else if (button.name.Contains("PaperdollWindowButton"))
            {
                this.menuButtons[1] = button;
                UIEventListener listener2 = UIEventListener.Get(button.gameObject);
                listener2.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener2.onClick, new UIEventListener.VoidDelegate(this.PaperdollClicked));
            }
            else if (button.name.Contains("MapWindowButton"))
            {
                this.menuButtons[2] = button;
                UIEventListener listener3 = UIEventListener.Get(button.gameObject);
                listener3.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener3.onClick, new UIEventListener.VoidDelegate(this.MapClicked));
            }
            else if (button.name.Contains("FeatWindowButton"))
            {
                this.menuButtons[3] = button;
                UIEventListener listener4 = UIEventListener.Get(button.gameObject);
                listener4.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener4.onClick, new UIEventListener.VoidDelegate(this.FeatsClicked));
            }
            else if (button.name.Contains("InventoryWindowButton"))
            {
                this.menuButtons[4] = button;
                UIEventListener listener5 = UIEventListener.Get(button.gameObject);
                listener5.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener5.onClick, new UIEventListener.VoidDelegate(this.InventoryClicked));
            }
            else if (button.name.Contains("CharacterWindowButton"))
            {
                this.menuButtons[5] = button;
                UIEventListener listener6 = UIEventListener.Get(button.gameObject);
                listener6.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener6.onClick, new UIEventListener.VoidDelegate(this.CharacterClicked));
            }
            else if (button.name.Contains("AchievementWindowButton"))
            {
                this.menuButtons[6] = button;
                UIEventListener listener7 = UIEventListener.Get(button.gameObject);
                listener7.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener7.onClick, new UIEventListener.VoidDelegate(this.AchievementClicked));
            }
            else if (button.name.Contains("QuestLogWindowButton"))
            {
                this.menuButtons[7] = button;
                UIEventListener listener8 = UIEventListener.Get(button.gameObject);
                listener8.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener8.onClick, new UIEventListener.VoidDelegate(this.QuestLogClicked));
            }
            else if (button.name.Contains("PoliticalWindowButton"))
            {
                this.menuButtons[8] = button;
                UIEventListener listener9 = UIEventListener.Get(button.gameObject);
                listener9.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener9.onClick, new UIEventListener.VoidDelegate(this.PoliticalClicked));
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find a menu button.", this.menuButtons);
    }

    public void Update()
    {
        bool flag = EscapeMenuGui.singleton.IsShowing();
        int index = 0;
        if (flag != this.prevVisibility[index])
        {
            UIImageButton button = this.menuButtons[index];
            button.normalSprite = this.NORMAL_SPRITES[index, flag ? 0 : 1];
            button.SendMessage("OnHover", false, SendMessageOptions.DontRequireReceiver);
            this.prevVisibility[index] = flag;
        }
        this.UpdateWindow(PaperdollWindowGui.singleton, 1);
        this.UpdateWindow(MapWindowGui.singleton, 2);
        this.UpdateWindow(FeatsWindowGui.singleton, 3);
        this.UpdateInventory();
        this.UpdateWindow(CharacterWindowGui.singleton, 5);
        this.UpdateWindow(AchievementsWindowGui.singleton, 6);
        this.UpdateWindow(QuestLogGui.singleton, 7);
        this.UpdateWindow(CompanySearchWindowGui.singleton, 8);
    }

    public void UpdateInventory()
    {
        if (InventoryWindowGui.singleton != null)
        {
            float num = InventoryClient.totalEncumbrance / ((float) InventoryClient.prevMaxEncumbrance);
            Encumbrance uNENCUMBERED = Encumbrance.UNENCUMBERED;
            if (num >= this.MIN_HEAVY)
            {
                uNENCUMBERED = Encumbrance.HEAVY_ENCUMBERED;
            }
            else if (num >= this.MIN_LIGHT)
            {
                uNENCUMBERED = Encumbrance.LIGHT_ENCUMBERED;
            }
            int index = 4;
            bool flag = InventoryWindowGui.singleton.IsShowing();
            if ((uNENCUMBERED != this.prevEnc) || (flag != this.prevVisibility[index]))
            {
                UIImageButton button = this.menuButtons[index];
                button.normalSprite = this.ENCUMBRANCE_SPRITES[(int) uNENCUMBERED, flag ? 0 : 1];
                button.SendMessage("OnHover", false, SendMessageOptions.DontRequireReceiver);
                this.prevEnc = uNENCUMBERED;
                this.prevVisibility[index] = flag;
            }
        }
    }

    private void UpdateWindow(WindowGui window, int index)
    {
        if (window != null)
        {
            bool flag = window.IsShowing();
            if (flag != this.prevVisibility[index])
            {
                UIImageButton button = this.menuButtons[index];
                button.normalSprite = this.NORMAL_SPRITES[index, flag ? 0 : 1];
                button.SendMessage("OnHover", false, SendMessageOptions.DontRequireReceiver);
                this.prevVisibility[index] = flag;
            }
        }
    }

    private enum Active
    {
        ACTIVE,
        INACTIVE
    }

    private enum Encumbrance
    {
        UNENCUMBERED,
        LIGHT_ENCUMBERED,
        HEAVY_ENCUMBERED
    }

    private enum MenuItem
    {
        ESCAPE,
        PAPERDOLL,
        MAP,
        FEATS,
        INVENTORY,
        CHARACTER,
        ACHIEVEMENT,
        QUEST_LOG,
        POLITICAL,
        NUM_MENU_ITEMS
    }
}

