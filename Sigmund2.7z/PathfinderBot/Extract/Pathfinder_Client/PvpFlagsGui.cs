﻿using GNGUI;
using System;
using System.Collections.Generic;
using UnityEngine;

public class PvpFlagsGui : MonoBehaviour
{
    private const string ATTACKER_ICON = "icon_minimap_war_de";
    private List<FlagDetailsGui> detailItems = new List<FlagDetailsGui>();
    private GameObject detailPrefab;
    private UIGrid detailsGrid;
    private List<FlagIconGui> iconItems = new List<FlagIconGui>();
    private GameObject iconPrefab;
    private UIGrid iconsGrid;
    public static PvpFlagsGui singleton;

    public void Awake()
    {
        singleton = this;
        this.OnAwake();
    }

    public void Hide()
    {
        NGUITools.SetActive(base.gameObject, false);
    }

    public void IconHover(bool isOver, FlagIconGui icon)
    {
        this.detailsGrid.gameObject.SetActive(isOver);
    }

    public bool IsShowing()
    {
        return NGUITools.GetActive(base.gameObject);
    }

    public bool LoadingTickFinished()
    {
        this.detailPrefab = UIClient.guiPrefabs["FlagDetailsGui"];
        this.iconPrefab = UIClient.guiPrefabs["FlagIcon"];
        foreach (UIGrid grid in base.GetComponentsInChildren<UIGrid>())
        {
            if (grid.name == "Icons")
            {
                this.iconsGrid = grid;
            }
            else if (grid.name == "Details")
            {
                this.detailsGrid = grid;
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find prefab or grid.", new object[] { this.iconPrefab, this.detailPrefab, this.iconsGrid, this.detailsGrid });
        this.detailsGrid.gameObject.SetActive(false);
        return true;
    }

    private void OnAwake()
    {
        ClientTick.pvpGuiLoadFinish = new GUtil.BoolFilterDelegate(this.LoadingTickFinished);
        ClientTick.pvpGuiTick = new GUtil.BoolFilterDelegate(this.SyncFixedUpdate);
    }

    public void OnDestroy()
    {
        singleton = null;
    }

    public void Show()
    {
        NGUITools.SetActive(base.gameObject, true);
    }

    public bool SyncFixedUpdate()
    {
        if ((EntityDataClient.owner != null) && (EntityDataClient.owner.pvp != null))
        {
            this.UpdateFlags(EntityDataClient.owner.pvp.pvpFlags);
        }
        else if (this.iconItems.Count > 0)
        {
            this.TrimGridItems(0);
        }
        return true;
    }

    private void TrimGridItems(int size)
    {
        while (this.iconItems.Count > size)
        {
            FlagIconGui gui = this.iconItems[this.iconItems.Count - 1];
            this.iconItems.RemoveAt(this.iconItems.Count - 1);
            gui.gameObject.SetActive(false);
            gui.transform.parent = DragDropRoot.root;
            UnityEngine.Object.Destroy(gui.gameObject);
        }
        while (this.detailItems.Count > size)
        {
            FlagDetailsGui gui2 = this.detailItems[this.detailItems.Count - 1];
            this.detailItems.RemoveAt(this.detailItems.Count - 1);
            gui2.gameObject.SetActive(false);
            gui2.transform.parent = DragDropRoot.root;
            UnityEngine.Object.Destroy(gui2.gameObject);
        }
        this.iconsGrid.repositionNow = true;
        this.detailsGrid.repositionNow = true;
    }

    public void UpdateFlags(PvpFlags status)
    {
        int size = 0;
        if (status.attacker > 0)
        {
            if (size >= this.iconItems.Count)
            {
                FlagIconGui component = NGUITools.AddChild(this.iconsGrid.gameObject, this.iconPrefab).GetComponent<FlagIconGui>();
                component.parent = this;
                this.iconItems.Add(component);
                this.detailItems.Add(NGUITools.AddChild(this.detailsGrid.gameObject, this.detailPrefab).GetComponent<FlagDetailsGui>());
            }
            string iconName = "icon_minimap_war_de";
            this.detailItems[size].SyncFixedUpdate(iconName, status.AttackerTitle(), status.AttackerSource(), status.AttackerDuration());
            this.iconItems[size].SyncFixedUpdate(iconName);
            size++;
        }
        this.TrimGridItems(size);
    }
}

