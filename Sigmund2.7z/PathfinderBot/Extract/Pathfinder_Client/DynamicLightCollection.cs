﻿using System;
using System.Collections.Generic;
using UnityEngine;

public class DynamicLightCollection
{
    public Color curColor;
    public float curIntensity;
    public float curRange;
    public Quaternion curRotation;
    public float curShadowStrength;
    public List<Light> dynamicLights = new List<Light>();
    public readonly string lightName;
    public bool valid = false;

    public DynamicLightCollection(string name)
    {
        this.lightName = name;
    }
}

