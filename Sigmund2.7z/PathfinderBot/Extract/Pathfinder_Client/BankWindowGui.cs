﻿using GNGUI;
using System;
using UnityEngine;

public class BankWindowGui : ItemWindowGui
{
    private Tabs activeTab = Tabs.EQUIPMENT;
    private InventoryTabGui[] allTabs = new InventoryTabGui[3];
    private UILabel coinAmount;
    protected string LOCK_REASON = "Cannot move until local vault is closed.";
    public static BankWindowGui singleton;

    public void AddItem(ItemGui item, ItemWindowGui.Interaction interaction)
    {
        InventoryClient.MoveItemBank(base.AdjustItemOnInteract(item.item, interaction), Item.Container.INVENTORY);
    }

    public void Awake()
    {
        singleton = this;
        this.OnAwake();
    }

    public void CoinChanged()
    {
        this.coinAmount.text = AuctionHouseGui.PriceToString(EntityDataClient.owner.playerRecord.bankCopper);
    }

    public void ContentsChanged()
    {
        if (base.IsShowing())
        {
            this.GetActiveTab().ContentsChanged();
        }
    }

    public override void DragEnd(InventoryItem item, BasicItemData.ItemSlot slot)
    {
        this.GetActiveTab().RepositionListItems();
    }

    public override void DragStart(InventoryItem item)
    {
    }

    public InventoryTabGui GetActiveTab()
    {
        return this.allTabs[(int) this.activeTab];
    }

    public override void HideWindow()
    {
        if (WindowGuiUtils.escapeEvent && BankPopupGui.singleton.IsShowing())
        {
            BankPopupGui.singleton.HideWindow();
        }
        else
        {
            base.HideWindow();
            if (CombatClient.entityMotion != null)
            {
                CombatClient.entityMotion.UnlockPosition(BaseMotion.PositionLock.RootedGuiInteract);
            }
            this.GetActiveTab().HideTab();
        }
    }

    public override void ItemInteract(ItemGui item, ItemWindowGui.Interaction interaction)
    {
        if (interaction == ItemWindowGui.Interaction.DROP)
        {
            if ((item is InventoryItemGui) && InventoryWindowGui.singleton.IsShowing())
            {
                this.AddItem(item, interaction);
            }
        }
        else if (item is InventoryItemGui)
        {
            this.RemoveItem(item, interaction);
        }
    }

    public bool LoadingTickFinished()
    {
        foreach (InventoryTabGui gui in this.allTabs)
        {
            gui.LoadingTickFinished();
        }
        return true;
    }

    public void OnAllTabClick(GameObject button)
    {
        this.OnTabChange(Tabs.ALL);
    }

    private void OnAwake()
    {
        ClientTick.bankGuiLoadFinish = new GUtil.BoolFilterDelegate(this.LoadingTickFinished);
        foreach (InventoryTabGui gui in base.GetComponentsInChildren<InventoryTabGui>())
        {
            string name = gui.name;
            if (name == null)
            {
                goto Label_0081;
            }
            if (!(name == "TabEquipment"))
            {
                if (name == "TabCrafting")
                {
                    goto Label_006B;
                }
                if (name == "TabAll")
                {
                    goto Label_0076;
                }
                goto Label_0081;
            }
            this.allTabs[0] = gui;
            continue;
        Label_006B:
            this.allTabs[1] = gui;
            continue;
        Label_0076:
            this.allTabs[2] = gui;
            continue;
        Label_0081:;
            GLog.LogWarning(new object[] { "Unknown tab '" + gui.name + "'." });
        }
        GuiHelper.GuiAssertNotNull("Couldn't find needed tabs.", this.allTabs);
        foreach (Collider collider in base.GetComponentsInChildren<Collider>())
        {
            if (collider.name == "ButtonAll")
            {
                UIEventListener listener1 = UIEventListener.Get(collider.gameObject);
                listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.OnAllTabClick));
            }
            else if (collider.name == "ButtonEquipment")
            {
                UIEventListener listener2 = UIEventListener.Get(collider.gameObject);
                listener2.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener2.onClick, new UIEventListener.VoidDelegate(this.OnEquipmentTabClick));
            }
            else if (collider.name == "ButtonCrafting")
            {
                UIEventListener listener3 = UIEventListener.Get(collider.gameObject);
                listener3.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener3.onClick, new UIEventListener.VoidDelegate(this.OnCraftingTabClick));
            }
            else if (collider.name == "CoinParent")
            {
                UIEventListener listener4 = UIEventListener.Get(collider.gameObject);
                listener4.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener4.onClick, new UIEventListener.VoidDelegate(this.OnCoinClick));
            }
        }
        foreach (UILabel label in base.GetComponentsInChildren<UILabel>())
        {
            if (label.name == "CoinAmount")
            {
                this.coinAmount = label;
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find needed children.", new object[] { this.coinAmount });
    }

    public void OnCoinClick(GameObject ignored)
    {
        BankPopupGui.singleton.ShowWindow();
    }

    public void OnCraftingTabClick(GameObject button)
    {
        this.OnTabChange(Tabs.CRAFTING);
    }

    public override void OnDestroy()
    {
        base.OnDestroy();
        singleton = null;
    }

    public void OnEquipmentTabClick(GameObject button)
    {
        this.OnTabChange(Tabs.EQUIPMENT);
    }

    private void OnTabChange(Tabs newTab)
    {
        if (this.activeTab != newTab)
        {
            this.activeTab = newTab;
            this.ShowTab();
        }
    }

    public void RemoveItem(ItemGui item, ItemWindowGui.Interaction interaction)
    {
        InventoryClient.MoveItemBank(base.AdjustItemOnInteract(item.item, interaction), Item.Container.BANK);
    }

    public void ShowTab()
    {
        for (int i = 0; i < this.allTabs.Length; i++)
        {
            if (i == this.activeTab)
            {
                this.allTabs[i].ShowTab();
            }
            else
            {
                this.allTabs[i].HideTab();
            }
        }
    }

    public override void ShowWindow()
    {
        base.ShowWindow();
        if (CombatClient.entityMotion != null)
        {
            CombatClient.entityMotion.LockPosition(BaseMotion.PositionLock.RootedGuiInteract, this.LOCK_REASON);
        }
        this.ShowTab();
        InventoryWindowGui.singleton.ShowWindow();
        if (TradeWindowGui.singleton.IsShowing())
        {
            TradeWindowGui.singleton.HideWindow();
        }
    }

    public void Start()
    {
        foreach (InventoryTabGui gui in this.allTabs)
        {
            gui.Init(this);
            gui.HideTab();
        }
        base.Init(1, true);
    }

    public void Withdrawal(ulong copper)
    {
        InventoryClient.Withdrawal(copper);
    }

    public enum Tabs
    {
        EQUIPMENT,
        CRAFTING,
        ALL,
        NUM_TABS
    }
}

