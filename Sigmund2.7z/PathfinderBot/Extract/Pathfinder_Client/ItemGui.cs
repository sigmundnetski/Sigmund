﻿using GNetwork;
using GNGUI;
using System;
using System.Text;
using UnityEngine;

public abstract class ItemGui : DraggableTabListItem
{
    protected UISprite icon;
    public InventoryItem item = InventoryItem.EMPTY;
    public ItemWindowGui parentWindow = null;
    protected static InventoryItem prevClickedItem = InventoryItem.EMPTY;
    protected static float prevClickTime = 0f;
    protected static ItemWindowGui prevParentWindow = null;

    protected ItemGui()
    {
    }

    public virtual void Assign(InventoryItem setItem, ItemWindowGui parent)
    {
        this.parentWindow = parent;
        if (!setItem.DataEquals(this.item, 0xff))
        {
            this.item = setItem;
            BasicItemData item = ItemDatabase.GetItem(this.item.staticItemId);
            this.SetLabel(item);
            this.SetInfo(this.item, item);
            this.SetIcon(this.item, item);
        }
    }

    public override void Awake()
    {
        base.Awake();
        this.icon = base.GetComponentInChildren<UISprite>();
        GuiHelper.GuiAssertNotNull("Couldn't find icon.", new object[] { this.icon });
    }

    public virtual void OnClick()
    {
        bool flag = (Time.time - prevClickTime) < 0.35f;
        bool flag2 = this.item.DataEqualsIgnoreQuantity(prevClickedItem);
        bool flag3 = this.parentWindow == prevParentWindow;
        ItemWindowGui.Interaction interaction = ((flag && flag2) && flag3) ? ItemWindowGui.Interaction.DOUBLE_CLICK : ItemWindowGui.Interaction.SINGLE_CLICK;
        this.parentWindow.ItemInteract(this, interaction);
        InventoryItemRClick.singleton.HideWindow();
        prevClickTime = Time.time;
        prevClickedItem = this.item;
        prevParentWindow = this.parentWindow;
    }

    public override void OnDragEnd()
    {
        this.parentWindow.DragEnd(this.item, BasicItemData.ItemSlot.NONE);
        InventoryTrashCanGui.singleton.SetDragging(false);
    }

    public override void OnDragStart()
    {
        this.parentWindow.DragStart(this.item);
        InventoryItemRClick.singleton.HideWindow();
        InventoryTrashCanGui.singleton.SetDragging(this.parentWindow.GetType() == typeof(InventoryWindowGui));
    }

    public virtual void OnDrop(GameObject droppedGo)
    {
        ItemGui component = droppedGo.GetComponent<ItemGui>();
        if (component != null)
        {
            this.parentWindow.ItemInteract(component, ItemWindowGui.Interaction.DROP);
        }
    }

    public override void OnTooltip(bool show)
    {
        BasicItemData item = ItemDatabase.GetItem(this.item.staticItemId);
        if (item != null)
        {
            base.showingTooltip = show;
            if (!show)
            {
                this.parentWindow.ShowTooltip(null, null);
            }
            else
            {
                StringBuilder quickText = GUtil.GetQuickText();
                InventoryClient.GetColoredItemDisplayName(ref quickText, this.item);
                quickText.Append("\n");
                quickText.Append(item.description);
                if (item is ExpendableRecipeItemData)
                {
                    FeatAdvancementData data2;
                    int featAdvancementId = ((ExpendableRecipeItemData) item).featAdvancementId;
                    if (FeatAdvancementData.dataByFeatAdvancementId.TryGetValue(featAdvancementId, out data2))
                    {
                        quickText.Append("\n\nExp Cost:");
                        quickText.Append(data2.GetDetailsForLevel(1).expCost);
                        quickText.Append("\n");
                        quickText.Append(EntityDataClient.owner.advancementVars.GetFeatHovertext(featAdvancementId, 1, GNetworkService.ServerUtc));
                    }
                }
                this.parentWindow.ShowTooltip(quickText.ToString(), base.gameObject);
            }
        }
    }

    protected void SetIcon(InventoryItem item, BasicItemData itemData)
    {
        GuiHelper.SetItemIcon(this.icon, item, itemData);
    }

    protected abstract void SetInfo(InventoryItem item, BasicItemData itemData);
    protected abstract void SetLabel(BasicItemData itemData);
}

