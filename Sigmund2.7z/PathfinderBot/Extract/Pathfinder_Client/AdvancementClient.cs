﻿using GNetwork;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using UnityEngine;

public static class AdvancementClient
{
    private static Color ACHIEVE_TXT_COLOR = new Color(0.9176471f, 0.7294118f, 0.1098039f);
    private static bool pendingRepopulate = true;
    private static TrackedAchievement[] trackedAchievements = new TrackedAchievement[3];

    private static void CounterCompletion(GenericAchievementData data, out ushort max, out ushort cur)
    {
        max = 1;
        cur = 0;
        if (data.linkedCounterReqs.Length == 1)
        {
            AchievementCounterData data2;
            AchievementCounterData.countersById.TryGetValue(data.linkedCounterIds[0], out data2);
            max = data.linkedCounterReqs[0];
            cur = EntityDataClient.owner.advancementVars.GetCounterValue(data2);
        }
    }

    private static void FlagCompletion(GenericAchievementData data, out int finishedFlags, out int totalFlags)
    {
        finishedFlags = 0;
        totalFlags = data.linkedFlagIds.Length;
        foreach (int num in data.linkedFlagIds)
        {
            AchievementFlagData data2;
            if (AchievementFlagData.flagsById.TryGetValue(data.linkedFlagIds[0], out data2) && EntityDataClient.owner.advancementVars.HasFlag(data2))
            {
                finishedFlags++;
            }
        }
    }

    public static IEnumerable<ITrackerElement> GetAchievementsToDisplay()
    {
        return SparseArray.Iterate<ITrackerElement>(trackedAchievements);
    }

    public static GenericAchievementData[] GetActiveAchievements()
    {
        return MergedAchievementData.GetNextAchievements(EntityDataClient.owner.advancementVars, MergedAchievementData.GetAllAchievements(), 1);
    }

    public static string GetBody(string prefix, GenericAchievementData data)
    {
        StringBuilder quickText = GUtil.GetQuickText();
        if (!string.IsNullOrEmpty(prefix))
        {
            quickText.Append(prefix);
        }
        quickText.Append(data.displayName);
        for (int i = 0; i < data.categoryIds.Length; i++)
        {
            quickText.Append(CategoryData.categoryById[data.categoryIds[i]].displayName);
            quickText.Append(": ");
            quickText.Append(data.categoryPoints[i]);
            quickText.Append(" ");
        }
        if (quickText.Length > 0)
        {
            quickText.Append("\n");
        }
        if (data.linkedCounterReqs.Length == 1)
        {
            ushort num2;
            ushort num3;
            CounterCompletion(data, out num2, out num3);
            if (num3 < num2)
            {
                quickText.Append(num3);
                quickText.Append("/");
                quickText.Append(num2);
                quickText.Append("\n");
            }
        }
        if (data.linkedFlagIds.Length > 0)
        {
            int num4;
            int num5;
            FlagCompletion(data, out num4, out num5);
            if (num4 < data.linkedFlagIds.Length)
            {
                quickText.Append(num4);
                quickText.Append("/");
                quickText.Append(data.linkedFlagIds.Length);
                quickText.Append("\n");
            }
        }
        return quickText.ToString();
    }

    public static GenericAchievementData[] GetFinishedAchievements()
    {
        return MergedAchievementData.GetFinishedAchievements(EntityDataClient.owner.advancementVars, MergedAchievementData.GetAllAchievements());
    }

    public static string GetHoverText(string prefix, GenericAchievementData data)
    {
        StringBuilder quickText = GUtil.GetQuickText();
        if (!string.IsNullOrEmpty(prefix))
        {
            quickText.Append(prefix);
        }
        if (!string.IsNullOrEmpty(data.description))
        {
            quickText.Append(data.description);
            quickText.Append("\n");
        }
        for (int i = 0; i < data.categoryIds.Length; i++)
        {
            quickText.Append(CategoryData.categoryById[data.categoryIds[i]].displayName);
            quickText.Append(": ");
            quickText.Append(data.categoryPoints[i]);
            quickText.Append(" ");
        }
        if (quickText.Length > 0)
        {
            quickText.Append("\n");
        }
        if (data.linkedCounterReqs.Length == 1)
        {
            ushort num2;
            ushort num3;
            CounterCompletion(data, out num2, out num3);
            if (num3 < num2)
            {
                quickText.Append("TODO Counter Desc: ");
                quickText.Append(num3);
                quickText.Append("/");
                quickText.Append(num2);
                quickText.Append("\n");
            }
        }
        if (data.linkedFlagIds.Length > 0)
        {
            int num4;
            int num5;
            FlagCompletion(data, out num4, out num5);
            if (num4 < data.linkedFlagIds.Length)
            {
                quickText.Append("TODO Flags Desc: ");
                quickText.Append(num4);
                quickText.Append("/");
                quickText.Append(data.linkedFlagIds.Length);
                quickText.Append("\n");
            }
        }
        return quickText.ToString();
    }

    public static IEnumerable<GenericAchievementData> GetMaxAchievements()
    {
        List<GenericAchievementData> list = new List<GenericAchievementData>(MergedAchievementData.allSlotIds.Count);
        using (HashSet<int>.Enumerator enumerator = MergedAchievementData.allSlotIds.GetEnumerator())
        {
            while (enumerator.MoveNext())
            {
                Func<GenericAchievementData, bool> func = null;
                int eachSlotId = enumerator.Current;
                if (func == null)
                {
                    func = each => each.slotId == eachSlotId;
                }
                GenericAchievementData item = (from each in Enumerable.Where<GenericAchievementData>(MergedAchievementData.GetAllAchievements(), func)
                    orderby each.level descending
                    select each).FirstOrDefault<GenericAchievementData>();
                if (item != null)
                {
                    list.Add(item);
                }
            }
        }
        return list;
    }

    public static GenericAchievementData[] GetNewAchievements()
    {
        return MergedAchievementData.GetNewAchievements(EntityDataClient.owner.advancementVars, MergedAchievementData.GetAllAchievements());
    }

    public static string GetOrderingString(GenericAchievementData data)
    {
        ushort num;
        ushort num2;
        int num4;
        int num5;
        StringBuilder quickText = GUtil.GetQuickText();
        quickText.Append(IsPinned(data.id) ? "0 " : "1 ");
        CounterCompletion(data, out num, out num2);
        int num3 = (int) Math.Round((double) ((num2 * 100f) / ((float) num)), 1, MidpointRounding.AwayFromZero);
        quickText.Append((int) (100 - num3));
        quickText.Append(" ");
        FlagCompletion(data, out num4, out num5);
        if (num5 == 0)
        {
            num5 = 1;
        }
        int num6 = (int) Math.Round((double) ((num4 * 100f) / ((float) num5)), 1, MidpointRounding.AwayFromZero);
        quickText.Append((int) (100 - num6));
        quickText.Append(" ");
        quickText.Append(data.displayName);
        return quickText.ToString();
    }

    public static bool IsPinned(int achievementId)
    {
        for (int i = 0; i < trackedAchievements.Length; i++)
        {
            if ((trackedAchievements[i] != null) && (trackedAchievements[i].achievementData.id == achievementId))
            {
                return true;
            }
        }
        return false;
    }

    public static bool IsTracked(int achievementId)
    {
        return ((from each in trackedAchievements
            where (each != null) && (each.achievementData.id == achievementId)
            select each).FirstOrDefault<TrackedAchievement>() != null);
    }

    public static void MakeTargetOlder(string[] args, EntityId playerEntityId)
    {
        double num;
        if (!((args.Length == 2) && double.TryParse(args[1], out num)))
        {
            ChatGui.singleton.DisplayMessage("Incorrect arguments: MakeTargetOlder <hours>", ChatClient.ERROR_COLOR);
        }
        else if (Targeting.selectedEntityId == EntityId.INVALID_ID)
        {
            ChatGui.singleton.DisplayMessage("Need to select target to make older.", ChatClient.ERROR_COLOR);
        }
        else
        {
            StringBuilder quickText = GUtil.GetQuickText();
            quickText.Append("MakeTargetOlderServer ").Append(Targeting.selectedEntityId).Append(" ").Append(args[1]);
            CommandCore.ExecuteCommand(quickText.ToString(), playerEntityId);
        }
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void OnAchievementAwarded(int achievementId)
    {
        if (EntityDataClient.owner != null)
        {
            GenericAchievementData data;
            if (!MergedAchievementData.dataById.TryGetValue(achievementId, out data))
            {
                GLog.LogError(new object[] { "Awarded an achievement that doesn't exist:", achievementId, MergedAchievementData.dataById });
            }
            else
            {
                UIClient.DisplayOverheadOrChat(ACHIEVE_TXT_COLOR, "Achievement awarded: " + data.displayName);
                UntrackAchievement(achievementId);
                pendingRepopulate = true;
            }
        }
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void OnAchievementProgress(IBitBufferRead achievementIdData)
    {
        int num2 = achievementIdData.PopInt();
        for (int i = 0; i < num2; i++)
        {
            GenericAchievementData data;
            int key = achievementIdData.PopInt();
            if (!MergedAchievementData.dataById.TryGetValue(key, out data))
            {
                GLog.LogError(new object[] { "Progress on unknown Achievement:", key });
            }
            else
            {
                if (!IsTracked(key))
                {
                    TrackNewAchievement(data, false);
                }
                if (IsTracked(key))
                {
                    pendingRepopulate = true;
                }
            }
        }
    }

    public static void OnClientEntityUpdate(Entity entity)
    {
        if ((entity == EntityDataClient.owner) && (pendingRepopulate && (AchievementsWindowGui.singleton != null)))
        {
            if (AchievementsWindowGui.singleton.IsShowing())
            {
                AchievementsWindowGui.singleton.Repopulate();
            }
            EventBarGui.Repopulate();
        }
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void OnTrainerInteract(EntityId trainerEntityId, int trainerId, byte trainerLevel)
    {
        TrainerWindowGui.singleton.OnTrainerInteract(trainerEntityId, trainerId, trainerLevel);
    }

    public static void TogglePinButton(GenericAchievementData data)
    {
        if (!UntrackAchievement(data.id))
        {
            TrackNewAchievement(data, true);
        }
    }

    private static void TrackNewAchievement(GenericAchievementData data, bool userPinned)
    {
        int num;
        TrackedAchievement achievement = new TrackedAchievement(data, Time.time, userPinned);
        for (num = 0; num < trackedAchievements.Length; num++)
        {
            if (trackedAchievements[num] == null)
            {
                trackedAchievements[num] = achievement;
                return;
            }
        }
        float num2 = (from each in trackedAchievements
            where !each.userPinned
            orderby each.timestamp
            select each.timestamp).FirstOrDefault<float>();
        for (num = 0; num < trackedAchievements.Length; num++)
        {
            if (trackedAchievements[num].timestamp == num2)
            {
                trackedAchievements[num] = achievement;
                return;
            }
        }
        if (userPinned)
        {
            num2 = (from each in trackedAchievements
                orderby each.timestamp
                select each.timestamp).First<float>();
            for (num = 0; num < trackedAchievements.Length; num++)
            {
                if (trackedAchievements[num].timestamp == num2)
                {
                    trackedAchievements[num] = achievement;
                    break;
                }
            }
        }
    }

    public static bool UntrackAchievement(int achievementId)
    {
        for (int i = 0; i < trackedAchievements.Length; i++)
        {
            if ((trackedAchievements[i] != null) && (trackedAchievements[i].achievementData.id == achievementId))
            {
                trackedAchievements[i] = null;
                return true;
            }
        }
        return false;
    }
}

