﻿using GNGUI;
using System;
using System.Linq;
using System.Runtime.CompilerServices;
using UnityEngine;

public class AlertsManagerGui : MonoBehaviour
{
    private AlertGui[] alerts;
    private UIGrid alertsGrid;
    private const float ALPHA_LERP_OFF_SEC = 5f;
    public const float ALPHA_LERP_ON_SEC = 0.5f;
    private OnAlertInteraction[] callbacks = new OnAlertInteraction[3];
    private const float HOVER_MAXIMIZE_SEC = 2f;
    private const int MAX_ALERTS = 3;
    public const float MINIMIZE_SEC = 10f;
    private const float POST_HOVER_MINIMIZE_SEC = 5f;
    public static AlertsManagerGui singleton;
    public const float TIMEOUT_SEC = 30f;

    public void AlertInteraction(AlertGui alert, AlertAction interaction)
    {
        this.callbacks[alert.id](alert.id, interaction);
        this.callbacks[alert.id] = null;
        this.alerts[alert.id].Reset();
        this.alertsGrid.repositionNow = true;
    }

    public void Awake()
    {
        singleton = this;
        this.OnAwake();
    }

    public void CancelAlert(uint alertId)
    {
        if (alertId >= this.alerts.Length)
        {
            GLog.LogError(new object[] { "Alert ID out of range. ID:", alertId, "range: 0 -", this.alerts.Length - 1 });
        }
        else
        {
            this.AlertInteraction(this.alerts[alertId], AlertAction.CANCEL);
        }
    }

    public void FixedUpdate()
    {
        for (int i = 0; i < this.alerts.Length; i++)
        {
            if (this.alerts[i].gameObject.activeSelf)
            {
                if (!(this.alerts[i].inAlphaLerp || (Time.time <= (this.alerts[i].timeoutTime - 5f))))
                {
                    this.alerts[i].inAlphaLerp = true;
                    UIClient.AlphaLerp(this.alerts[i].gameObject, 1f, 0f, 5f, null);
                }
                if (this.alerts[i].isHovered)
                {
                    AlertGui gui1 = this.alerts[i];
                    gui1.timeoutTime += Time.fixedDeltaTime;
                    if (this.alerts[i].isMinimized && (Time.time > (this.alerts[i].hoverStartTime + 2f)))
                    {
                        this.alerts[i].autoMaximized = true;
                        this.alerts[i].autoMaximizedTime = Time.time;
                        this.alerts[i].ToggleClicked(base.gameObject);
                    }
                    if (this.alerts[i].inAlphaLerp)
                    {
                        this.alerts[i].inAlphaLerp = false;
                        this.alerts[i].timeoutTime = Time.time + 5f;
                        UIClient.CancelAlphaLerp(this.alerts[i].gameObject, 1f, null);
                    }
                }
                else if (!(this.alerts[i].isMinimized || (Time.time <= this.alerts[i].autoMinimizeTime)))
                {
                    this.alerts[i].ToggleClicked(base.gameObject);
                }
                else if ((!this.alerts[i].isMinimized && this.alerts[i].autoMaximized) && (Time.time > (this.alerts[i].autoMaximizedTime + 5f)))
                {
                    this.alerts[i].ToggleClicked(base.gameObject);
                }
                if (Time.time > this.alerts[i].timeoutTime)
                {
                    this.AlertInteraction(this.alerts[i], AlertAction.IGNORED);
                }
            }
        }
    }

    public uint NewAlert(AlertType type, string text, OnAlertInteraction callback)
    {
        uint index = 0;
        bool flag = false;
        float positiveInfinity = float.PositiveInfinity;
        uint id = 0;
        while (index < this.alerts.Length)
        {
            if (!this.alerts[index].gameObject.activeSelf)
            {
                flag = true;
                break;
            }
            if (this.alerts[index].startTime < positiveInfinity)
            {
                positiveInfinity = this.alerts[index].startTime;
                id = this.alerts[index].id;
            }
            index++;
        }
        uint setId = index;
        if (!flag)
        {
            this.AlertInteraction(this.alerts[id], AlertAction.FELL_OFF_STACK);
            setId = id;
        }
        this.alerts[setId].Set(setId, type, text);
        this.callbacks[setId] = callback;
        this.alertsGrid.repositionNow = true;
        return setId;
    }

    private void OnAwake()
    {
        this.alertsGrid = base.GetComponent<UIGrid>();
        GuiHelper.GuiAssertNotNull("Couldn't find grid.", new object[] { this.alertsGrid });
        this.alerts = base.GetComponentsInChildren<AlertGui>().ToArray<AlertGui>();
        GuiHelper.GuiAssertNotNull("Couldn't find alerts.", this.alerts);
        if (this.alerts.Length != 3)
        {
            throw new GoblinGuiException("Incorrect number of alerts.");
        }
    }

    public void OnDestroy()
    {
        singleton = null;
    }

    public enum AlertAction
    {
        IGNORED,
        DECLINED,
        FELL_OFF_STACK,
        CANCEL,
        ACCEPTED
    }

    public enum AlertType
    {
        TRADE,
        PARTY,
        COMPANY,
        SYSTEM,
        NUM_TYPES
    }

    public delegate void OnAlertInteraction(uint alertId, AlertsManagerGui.AlertAction action);
}

