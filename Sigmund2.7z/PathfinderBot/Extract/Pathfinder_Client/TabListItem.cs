﻿using GNGUI;
using System;
using UnityEngine;

public abstract class TabListItem : MonoBehaviour
{
    protected UILabel nameLabel;

    protected TabListItem()
    {
    }

    public virtual void Awake()
    {
        this.nameLabel = base.GetComponentInChildren<UILabel>();
        GuiHelper.GuiAssertNotNull("Couldn't find label.", new object[] { this.nameLabel });
    }

    public abstract void OnTooltip(bool show);
}

