﻿using System;
using UnityEngine;

public class FullscreenWindowGui : WindowGui
{
    public FullscreenWindowBackgroundGui background;
    protected string lockReason = "Cannot move until fullscreen window is closed.";
    public static GameObject windowBgParent;

    public override void HideWindow()
    {
        WindowGuiUtils.visibleFullscreenWindows.Remove(this);
        if (CombatClient.entityMotion != null)
        {
            CombatClient.entityMotion.UnlockPosition(BaseMotion.PositionLock.RootedGuiInteract);
        }
        if (this.background != null)
        {
            this.background.Hide();
        }
        base.HideWindow();
    }

    public override void ShowWindow()
    {
        WindowGuiUtils.visibleFullscreenWindows.Add(this);
        if (CombatClient.entityMotion != null)
        {
            CombatClient.entityMotion.LockPosition(BaseMotion.PositionLock.RootedGuiInteract, this.lockReason);
        }
        if (this.background != null)
        {
            this.background.Show();
        }
        base.ShowWindow();
    }
}

