﻿using GNetwork;
using GNGUI;
using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

public class HexConflictHover : MonoBehaviour
{
    private static ColorData allyColor;
    private static UILabel detailsLabel;
    private static ColorData hostileColor;
    private static UISlicedSprite hoverBG;
    private static bool hoverMode = false;
    private static UISlicedSprite nonHoverBG;
    private static UISprite pvpActiveIcon;
    private static UISprite pvpInactiveIcon;
    private static ColorData selfColor;
    public static HexConflictHover singleton;
    private static UILabel timeLabel;

    public void Awake()
    {
        singleton = this;
    }

    private static string GetColor(ulong companyId, uint settlementId, ulong selfCompanyId, uint allySettlementId)
    {
        if (allyColor == null)
        {
            allyColor = ColorData.GetColorDataByName("map_ally");
            hostileColor = ColorData.GetColorDataByName("map_hostile");
            selfColor = ColorData.GetColorDataByName("map_self");
        }
        if ((companyId != 0L) && (companyId == selfCompanyId))
        {
            return selfColor.nguiColorCode;
        }
        if ((settlementId != 0) && (settlementId == allySettlementId))
        {
            return allyColor.nguiColorCode;
        }
        return hostileColor.nguiColorCode;
    }

    private static string GetDetailText(CapturePointVars capturePointVars, ulong selfCompanyId, uint selfSettlementId, int numScores)
    {
        StringBuilder quickText = GUtil.GetQuickText();
        int num = 0;
        if (hoverMode)
        {
            quickText.Append(GetColor(capturePointVars.companyOwnerId, capturePointVars.settlementOwnerId, selfCompanyId, selfSettlementId));
            quickText.Append(capturePointVars.companyOwnerName);
            quickText.Append("[-]\n");
            num += 2;
            if (!string.IsNullOrEmpty(capturePointVars.settlementOwnerName))
            {
                quickText.Append(GetColor(0L, capturePointVars.settlementOwnerId, selfCompanyId, selfSettlementId));
                quickText.Append(capturePointVars.settlementOwnerName);
                quickText.Append("[-]\n");
                num++;
            }
        }
        if ((capturePointVars.captureGameState == TerritoryConst.PvpStatus.PVP_ACTIVE) && (capturePointVars.companyNames != null))
        {
            int num2 = Math.Min(hoverMode ? 5 : 2, numScores);
            List<CapturePointScore> sortedScores = capturePointVars.GetSortedScores();
            for (int i = 0; i < num2; i++)
            {
                quickText.Append("\n");
                num++;
                quickText.Append(GetColor(sortedScores[i].companyId, sortedScores[i].settlementId, selfCompanyId, selfSettlementId));
                quickText.Append(sortedScores[i].companyScore);
                quickText.Append(": ");
                quickText.Append(sortedScores[i].companyName);
                quickText.Append("[-]");
            }
        }
        hoverBG.transform.localScale = new Vector3(170f, (float) (0x15 + (15 * num)), 1f);
        nonHoverBG.transform.localScale = new Vector3(170f, (float) (0x15 + (15 * num)), 1f);
        return quickText.ToString();
    }

    public void OnConflictHover(GameObject buttonGO, bool isHovered)
    {
        hoverMode = isHovered;
        Refresh();
    }

    public void OnDestroy()
    {
        singleton = null;
    }

    public static void Refresh()
    {
        bool flag = ((singleton != null) && (EntityDataClient.owner != null)) && (EntityDataClient.owner.capturePointVars != null);
        singleton.gameObject.SetActive(flag);
        if (flag)
        {
            CapturePointVars capturePointVars = EntityDataClient.owner.capturePointVars;
            ulong primaryCompanyId = GroupClient.GetPrimaryCompanyId();
            uint playerSettlementId = GroupClient.playerSettlementId;
            int numScores = SparseArray.Count<string>(capturePointVars.companyNames);
            hoverBG.gameObject.SetActive(hoverMode);
            nonHoverBG.gameObject.SetActive(!hoverMode && (numScores > 0));
            pvpActiveIcon.gameObject.SetActive(capturePointVars.captureGameState == TerritoryConst.PvpStatus.PVP_ACTIVE);
            pvpInactiveIcon.gameObject.SetActive(capturePointVars.captureGameState != TerritoryConst.PvpStatus.PVP_ACTIVE);
            bool flag2 = hoverMode || (numScores > 0);
            timeLabel.gameObject.SetActive(flag2);
            detailsLabel.gameObject.SetActive(flag2);
            if (flag2)
            {
                DateTime serverUtc = GNetworkService.ServerUtc;
                bool flag3 = GUtil.WithinTimeWindow(serverUtc, capturePointVars.pvpTimeOfDay, capturePointVars.duration);
                TimeSpan curTimeOfDay = new TimeSpan(serverUtc.Hour, serverUtc.Minute, serverUtc.Second);
                TimeSpan span2 = (capturePointVars.captureGameState != TerritoryConst.PvpStatus.PVP_ACTIVE) ? GUtil.DurationToNext(curTimeOfDay, capturePointVars.pvpTimeOfDay) : GUtil.DurationToNext(curTimeOfDay, capturePointVars.pvpTimeOfDay + capturePointVars.duration);
                string str = (capturePointVars.captureGameState == TerritoryConst.PvpStatus.PVP_ACTIVE) ? "" : "PvP in ";
                if (span2.Hours > 0)
                {
                    timeLabel.text = string.Format("{0}{1}Hours, {2}Mins", str, span2.Hours, span2.Minutes + 1);
                }
                else
                {
                    timeLabel.text = string.Format("{0}{1}Mins", str, span2.Minutes + 1);
                }
                detailsLabel.text = GetDetailText(capturePointVars, primaryCompanyId, playerSettlementId, numScores);
            }
        }
    }

    public void Start()
    {
        foreach (UISlicedSprite sprite in base.GetComponentsInChildren<UISlicedSprite>())
        {
            if (sprite.name == "HoverBG")
            {
                hoverBG = sprite;
            }
            else if (sprite.name == "NonHoverBG")
            {
                nonHoverBG = sprite;
            }
        }
        foreach (UILabel label in base.GetComponentsInChildren<UILabel>())
        {
            if (label.name == "DetailsLabel")
            {
                detailsLabel = label;
            }
            else if (label.name == "TimeLabel")
            {
                timeLabel = label;
            }
        }
        foreach (UISprite sprite2 in base.GetComponentsInChildren<UISprite>())
        {
            if (sprite2.name == "PvpActiveIcon")
            {
                pvpActiveIcon = sprite2;
            }
            else if (sprite2.name == "PvpInactiveIcon")
            {
                pvpInactiveIcon = sprite2;
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find needed objects.", new object[] { detailsLabel, timeLabel, hoverBG, nonHoverBG, pvpActiveIcon, pvpInactiveIcon });
        UIEventListener listener1 = UIEventListener.Get(pvpActiveIcon.gameObject);
        listener1.onHover = (UIEventListener.BoolDelegate) Delegate.Combine(listener1.onHover, new UIEventListener.BoolDelegate(this.OnConflictHover));
        UIEventListener listener2 = UIEventListener.Get(pvpInactiveIcon.gameObject);
        listener2.onHover = (UIEventListener.BoolDelegate) Delegate.Combine(listener2.onHover, new UIEventListener.BoolDelegate(this.OnConflictHover));
        Refresh();
    }
}

