﻿using GNGUI;
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class FeatsWindowGui : WindowGui
{
    private Tabs activeTab = Tabs.PASSIVE_FEATS;
    private WindowTabGui[] allTabs = new WindowTabGui[2];
    private const string ANY_ROLE = "Any Role";
    private UIImageButton roleButton;
    public int roleIdFilter = 0;
    private UIPopupList roleList;
    private Dictionary<string, int> roleNameToId = new Dictionary<string, int>();
    public static FeatsWindowGui singleton;

    public void ActiveTabSelected(GameObject button)
    {
        Tabs activeTab = this.activeTab;
        this.activeTab = Tabs.ACTIVE_FEATS;
        if (this.activeTab != activeTab)
        {
            this.ShowTab();
            PaperdollWindowGui.singleton.ResetValidity(PaperdollWindowGui.FilterType.FEATS);
        }
    }

    public void Awake()
    {
        singleton = this;
        this.OnAwake();
    }

    public void ContentsChanged()
    {
        if (base.IsShowing())
        {
            this.GetActiveTab().ContentsChanged();
        }
    }

    public void DragEnd(GameObject go, Combat.FeatType featType, int featId)
    {
        PaperdollWindowGui.singleton.DragEnd(go, featType, featId);
        if (this.activeTab == Tabs.ACTIVE_FEATS)
        {
            ButtonBarGui.singleton.SetDragTargetValidity();
        }
        this.GetActiveTab().RepositionListItems();
    }

    public void DragStart(Combat.FeatType featType, int featId)
    {
        PaperdollWindowGui.singleton.DragStart(featType);
        if (this.activeTab == Tabs.ACTIVE_FEATS)
        {
            ButtonBarGui.singleton.SetDragTargetValidity(featType, featId);
        }
    }

    public void EmptyActiveFeatClicked(ButtonBarButton button)
    {
        if (this.activeTab != Tabs.ACTIVE_FEATS)
        {
            this.activeTab = Tabs.ACTIVE_FEATS;
            this.ShowTab();
        }
        if (!base.IsShowing())
        {
            this.ShowWindow();
        }
        WindowTabGui activeTab = this.GetActiveTab();
        List<ToggleText> allFilters = activeTab.allFilters;
        foreach (ToggleText text in allFilters)
        {
            bool flag = false;
            if (text.filterIds != null)
            {
                for (int i = 0; i < text.filterIds.Length; i++)
                {
                    flag = flag || (button.featType == ((byte) text.filterIds[i]));
                }
            }
            if (flag)
            {
                activeTab.FilterClicked(text.gameObject);
                break;
            }
        }
    }

    public void FeatSlotClicked(FeatSlotGui slotGui)
    {
        this.PassiveTabSelected(null);
        if (!base.IsShowing())
        {
            this.ShowWindow();
        }
        WindowTabGui activeTab = this.GetActiveTab();
        List<ToggleText> allFilters = activeTab.allFilters;
        foreach (ToggleText text in allFilters)
        {
            if (slotGui.IsValid(text.filterIds))
            {
                activeTab.FilterClicked(text.gameObject);
                break;
            }
        }
    }

    public WindowTabGui GetActiveTab()
    {
        return this.allTabs[(int) this.activeTab];
    }

    public override void HideWindow()
    {
        base.HideWindow();
        this.GetActiveTab().HideTab();
        PaperdollWindowGui.singleton.ResetValidity(PaperdollWindowGui.FilterType.FEATS);
    }

    public bool IsValidForFilter(Combat.FeatType featType)
    {
        if (this.activeTab != Tabs.ACTIVE_FEATS)
        {
            return false;
        }
        ToggleText text = (this.GetActiveTab().activeFilter == null) ? null : this.GetActiveTab().activeFilter;
        return (((text != null) && text.filterIds.Contains<int>(((int) featType))) || ((text == null) && false));
    }

    public bool LoadingTickFinished()
    {
        foreach (WindowTabGui gui in this.allTabs)
        {
            gui.LoadingTickFinished();
        }
        List<string> list = new List<string> { "Any Role" };
        foreach (RoleData data in StaticDataService.GetValues<RoleData>())
        {
            list.Add(data.displayName);
            this.roleNameToId[data.displayName] = data.id;
        }
        this.roleNameToId["Any Role"] = 0;
        this.roleList.items = list;
        this.roleList.selection = "Any Role";
        return true;
    }

    private void OnAwake()
    {
        ClientTick.featGuiLoadFinish = new GUtil.BoolFilterDelegate(this.LoadingTickFinished);
        foreach (WindowTabGui gui in base.GetComponentsInChildren<WindowTabGui>())
        {
            string name = gui.name;
            if (name == null)
            {
                goto Label_0065;
            }
            if (!(name == "TabPassiveFeats"))
            {
                if (name == "TabActiveFeats")
                {
                    goto Label_005A;
                }
                goto Label_0065;
            }
            this.allTabs[0] = gui;
            continue;
        Label_005A:
            this.allTabs[1] = gui;
            continue;
        Label_0065:;
            GLog.LogWarning(new object[] { "Unknown tab '" + gui.name + "'." });
        }
        GuiHelper.GuiAssertNotNull("Couldn't find needed tabs.", this.allTabs);
        foreach (Collider collider in base.GetComponentsInChildren<Collider>())
        {
            if (collider.name == "ActiveFeatsButton")
            {
                UIEventListener listener1 = UIEventListener.Get(collider.gameObject);
                listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.ActiveTabSelected));
            }
            else if (collider.name == "PassiveFeatsButton")
            {
                UIEventListener listener2 = UIEventListener.Get(collider.gameObject);
                listener2.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener2.onClick, new UIEventListener.VoidDelegate(this.PassiveTabSelected));
            }
        }
        this.roleList = base.GetComponentInChildren<UIPopupList>();
        foreach (UIImageButton button in base.GetComponentsInChildren<UIImageButton>())
        {
            if (button.name == "FilterButton")
            {
                this.roleButton = button;
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find popup list!", new object[] { this.roleList, this.roleButton });
        UIEventListener listener3 = UIEventListener.Get(this.roleList.gameObject);
        listener3.onPress = (UIEventListener.BoolDelegate) Delegate.Combine(listener3.onPress, new UIEventListener.BoolDelegate(this.RolePress));
        UIEventListener listener4 = UIEventListener.Get(this.roleList.gameObject);
        listener4.onHover = (UIEventListener.BoolDelegate) Delegate.Combine(listener4.onHover, new UIEventListener.BoolDelegate(this.RoleHover));
        this.roleList.onSelectionChange = new GNGUI.UIPopupList.OnSelectionChange(this.OnSelectionChange);
    }

    public static void OnClientEntityUpdate(Entity entity)
    {
        if (((singleton != null) && (entity == EntityDataClient.owner)) && (entity.advancementVars != null))
        {
            singleton.ContentsChanged();
        }
    }

    public override void OnDestroy()
    {
        base.OnDestroy();
        singleton = null;
    }

    public void OnSelectionChange(string newSelection)
    {
        this.roleIdFilter = this.roleNameToId[newSelection];
        this.ContentsChanged();
        this.GetActiveTab().ResetScroll();
    }

    public void PassiveTabSelected(GameObject button)
    {
        Tabs activeTab = this.activeTab;
        this.activeTab = Tabs.PASSIVE_FEATS;
        if (this.activeTab != activeTab)
        {
            this.ShowTab();
            PaperdollWindowGui.singleton.SetValidityByFilter(PaperdollWindowGui.FilterType.FEATS, this.GetActiveTab().activeFilter);
        }
    }

    public void RoleHover(GameObject go, bool isOver)
    {
        this.roleButton.SendMessage("OnHover", isOver, SendMessageOptions.DontRequireReceiver);
    }

    public void RolePress(GameObject go, bool isDown)
    {
        this.roleButton.SendMessage("OnPress", isDown, SendMessageOptions.DontRequireReceiver);
    }

    public void ShowTab()
    {
        for (int i = 0; i < this.allTabs.Length; i++)
        {
            if (i == this.activeTab)
            {
                this.allTabs[i].ShowTab();
            }
            else
            {
                this.allTabs[i].HideTab();
            }
        }
    }

    public override void ShowWindow()
    {
        base.ShowWindow();
        this.ShowTab();
    }

    public void Start()
    {
        foreach (WindowTabGui gui in this.allTabs)
        {
            gui.HideTab();
        }
        base.Init(3, true);
    }

    public void ToggleFeatsWindow(string[] args, EntityId playerEntityId)
    {
        this.ToggleWindowVisibility();
        if (base.IsShowing() && (this.activeTab == Tabs.PASSIVE_FEATS))
        {
            PaperdollWindowGui.singleton.SetValidityByFilter(PaperdollWindowGui.FilterType.FEATS, this.GetActiveTab().activeFilter);
        }
    }

    public enum Tabs
    {
        PASSIVE_FEATS,
        ACTIVE_FEATS,
        NUM_TABS
    }
}

