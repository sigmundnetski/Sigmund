﻿using System;
using System.Collections.Generic;
using UnityEngine;

public static class SlavedProxyClient
{
    private static Vector3 EAST_OFFSET = new Vector3(3f, 0f, 0f);
    private static DateTime lastUpdateTime;
    private static Vector3 NORTH_OFFSET = new Vector3(0f, 0f, 3f);
    private const float OFFSET = 3f;
    private static Dictionary<GameObject, SlavedProxy[]> slavedProxiesByOwner = new Dictionary<GameObject, SlavedProxy[]>();
    private static Vector3 SOUTH_OFFSET = new Vector3(0f, 0f, -3f);
    private static Vector3 WEST_OFFSET = new Vector3(-3f, 0f, 0f);

    public static void CreateSlave(GameObject ownerGO, RelativePosition slaveOffset, int entityDefnId, string skeletonName, List<EquipmentAsset> characterSlots)
    {
        Vector3 vector;
        Transform transform;
        SlavedProxy[] proxyArray;
        if (ownerGO == null)
        {
            Debug.LogError("Owner does not exist. ");
        }
        else
        {
            switch (slaveOffset)
            {
                case RelativePosition.NORTH:
                    vector = NORTH_OFFSET;
                    goto Label_00E2;

                case RelativePosition.EAST:
                    vector = EAST_OFFSET;
                    goto Label_00E2;

                case RelativePosition.SOUTH:
                    vector = SOUTH_OFFSET;
                    goto Label_00E2;

                case RelativePosition.WEST:
                    vector = WEST_OFFSET;
                    goto Label_00E2;
            }
            Debug.LogError(string.Concat(new object[] { "Invalid position '", slaveOffset, "'. Valid options are: ", RelativePosition.NORTH, ", ", RelativePosition.EAST, ", ", RelativePosition.SOUTH, ", ", RelativePosition.WEST }));
        }
        return;
    Label_00E2:
        transform = EntityClient.playerProxyParent;
        GameObject obj2 = null;
        if (entityDefnId != 0)
        {
            obj2 = EntityLoadClient.CreateDefinedCharacter(entityDefnId, GConst.CreateType.PLAYER_PROXY, transform, ownerGO.transform.position + vector, ownerGO.transform.rotation, string.Concat(new object[] { "SlavedTo_", ownerGO.name, "_", slaveOffset }));
        }
        else
        {
            obj2 = EntityLoadClient.CreateCharacter(0, skeletonName, characterSlots, GConst.CreateType.PLAYER_PROXY, transform, ownerGO.transform.position + vector, ownerGO.transform.rotation, string.Concat(new object[] { "SlavedTo_", ownerGO.name, "_", slaveOffset }));
        }
        if (!slavedProxiesByOwner.TryGetValue(ownerGO, out proxyArray))
        {
            proxyArray = new SlavedProxy[4];
            slavedProxiesByOwner[ownerGO] = proxyArray;
            EntityMotion component = ownerGO.GetComponent<EntityMotion>();
            if (component != null)
            {
                component.movementChanged = (BaseMotion.MovementChanged) Delegate.Combine(component.movementChanged, new BaseMotion.MovementChanged(SlavedProxyClient.MovementChanged));
            }
            PassiveAnimator animator = ownerGO.GetComponent<PassiveAnimator>();
            if (animator != null)
            {
                animator.movementChanged = (BaseMotion.MovementChanged) Delegate.Combine(animator.movementChanged, new BaseMotion.MovementChanged(SlavedProxyClient.MovementChanged));
            }
        }
        int index = (int) slaveOffset;
        if ((proxyArray[index] != null) && (proxyArray[index].movement != null))
        {
            DestroySlaveProxy(proxyArray[index].movement.gameObject);
        }
        proxyArray[index] = new SlavedProxy(obj2.GetComponent<Movement>(), vector);
    }

    public static void DestroyProxiesSlavedToPlayer()
    {
        GameObject player = PlayerEntityClient.GetPlayer();
        if (player == null)
        {
            Debug.LogError("Could not get Player's GameObject.");
        }
        else if (slavedProxiesByOwner.ContainsKey(player))
        {
            foreach (SlavedProxy proxy in slavedProxiesByOwner[player])
            {
                if ((proxy != null) && (proxy.movement != null))
                {
                    DestroySlaveProxy(proxy.movement.gameObject);
                }
            }
            EntityMotion component = player.GetComponent<EntityMotion>();
            if (component != null)
            {
                component.movementChanged = (BaseMotion.MovementChanged) Delegate.Remove(component.movementChanged, new BaseMotion.MovementChanged(SlavedProxyClient.MovementChanged));
            }
            PassiveAnimator animator = player.GetComponent<PassiveAnimator>();
            if (animator != null)
            {
                animator.movementChanged = (BaseMotion.MovementChanged) Delegate.Remove(animator.movementChanged, new BaseMotion.MovementChanged(SlavedProxyClient.MovementChanged));
            }
            slavedProxiesByOwner.Remove(player);
        }
    }

    private static void DestroySlaveProxy(GameObject proxy)
    {
        UnityEngine.Object.Destroy(proxy);
    }

    public static void MovementChanged(GameObject entityGO, Movement.MovementType moveType)
    {
        if (slavedProxiesByOwner.ContainsKey(entityGO))
        {
            UpdateSlavePositions(entityGO, slavedProxiesByOwner[entityGO], moveType);
        }
    }

    public static bool Shutdown()
    {
        slavedProxiesByOwner.Clear();
        return true;
    }

    public static void SpawnProxy(GameObject owner, int entityDefnId)
    {
        if (owner == null)
        {
            Debug.LogError("Need a valid owner GameObject.");
        }
        else if (!slavedProxiesByOwner.ContainsKey(owner))
        {
            CreateSlave(owner, RelativePosition.EAST, entityDefnId, null, null);
        }
        else if (slavedProxiesByOwner[owner][1] == null)
        {
            CreateSlave(owner, RelativePosition.EAST, entityDefnId, null, null);
        }
        else if (slavedProxiesByOwner[owner][3] == null)
        {
            CreateSlave(owner, RelativePosition.WEST, entityDefnId, null, null);
        }
        else if (slavedProxiesByOwner[owner][0] == null)
        {
            CreateSlave(owner, RelativePosition.NORTH, entityDefnId, null, null);
        }
        else
        {
            CreateSlave(owner, RelativePosition.SOUTH, entityDefnId, null, null);
        }
    }

    public static void SpawnProxy(GameObject owner, string entitySkeleton, List<EquipmentAsset> entityAssets)
    {
        if (owner == null)
        {
            Debug.LogError("Need a valid owner GameObject.");
        }
        else if (!slavedProxiesByOwner.ContainsKey(owner))
        {
            CreateSlave(owner, RelativePosition.EAST, 0, entitySkeleton, entityAssets);
        }
        else if (slavedProxiesByOwner[owner][1] == null)
        {
            CreateSlave(owner, RelativePosition.EAST, 0, entitySkeleton, entityAssets);
        }
        else if (slavedProxiesByOwner[owner][3] == null)
        {
            CreateSlave(owner, RelativePosition.WEST, 0, entitySkeleton, entityAssets);
        }
        else if (slavedProxiesByOwner[owner][0] == null)
        {
            CreateSlave(owner, RelativePosition.NORTH, 0, entitySkeleton, entityAssets);
        }
        else
        {
            CreateSlave(owner, RelativePosition.SOUTH, 0, entitySkeleton, entityAssets);
        }
    }

    public static void SpawnProxySlavedToPlayer()
    {
        GameObject player = PlayerEntityClient.GetPlayer();
        if (player == null)
        {
            Debug.LogError("Could not get Player's GameObject.");
        }
        else
        {
            int entityDefnId = player.GetComponent<EntityVars>().entityDefnId;
            if (entityDefnId == 0)
            {
                Debug.LogError("Invalid entity type on player.");
            }
            else
            {
                SpawnProxy(player, entityDefnId);
            }
        }
    }

    public static bool SyncFixedUpdate()
    {
        DateTime utcNow = DateTime.UtcNow;
        if ((lastUpdateTime + GConst.MOVEMENT_SYNC_DELTA) <= utcNow)
        {
            lastUpdateTime = utcNow;
            List<GameObject> list = new List<GameObject>();
            foreach (KeyValuePair<GameObject, SlavedProxy[]> pair in slavedProxiesByOwner)
            {
                GameObject key = pair.Key;
                if (key == null)
                {
                    list.Add(key);
                    foreach (SlavedProxy proxy in pair.Value)
                    {
                        if ((proxy != null) && (proxy.movement != null))
                        {
                            DestroySlaveProxy(proxy.movement.gameObject);
                        }
                    }
                }
                else
                {
                    UpdateSlavePositions(key, pair.Value, Movement.MovementType.Standard);
                }
            }
            if (list.Count > 0)
            {
                foreach (GameObject obj3 in list)
                {
                    slavedProxiesByOwner.Remove(obj3);
                }
            }
        }
        return true;
    }

    public static void SyncStart()
    {
        lastUpdateTime = DateTime.UtcNow - GConst.MOVEMENT_SYNC_DELTA;
    }

    private static void UpdateSlavePositions(GameObject ownerGO, SlavedProxy[] slavedProxies, Movement.MovementType moveType)
    {
        for (int i = 0; i < slavedProxies.Length; i++)
        {
            if ((slavedProxies[i] != null) && (slavedProxies[i].movement != null))
            {
                SlavedProxy proxy = slavedProxies[i];
                proxy.movement.PushTimeStamp(Time.time, ownerGO.transform.position + proxy.offset, ownerGO.transform.rotation, moveType);
            }
        }
    }

    public enum RelativePosition
    {
        NORTH,
        EAST,
        SOUTH,
        WEST,
        NUM_PROXIES
    }

    private class SlavedProxy
    {
        public Movement movement;
        public Vector3 offset;

        public SlavedProxy(Movement movement_, Vector3 offset_)
        {
            this.movement = movement_;
            this.offset = offset_;
        }
    }
}

