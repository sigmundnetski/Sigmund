﻿using GNGUI;
using System;
using UnityEngine;

public class SettlementMapTabGui : MapWindowTabGui
{
    public static readonly float BOTTOM_Z_WORLD = -512f;
    private const uint DEFAULT_ZOOM_METERS = 0x200;
    public static readonly float LEFT_X_WORLD = -512f;
    public static readonly float MAP_HEIGHT_METERS = Math.Abs((float) (TOP_Z_WORLD - BOTTOM_Z_WORLD));
    public static readonly float MAP_WIDTH_METERS = Math.Abs((float) (RIGHT_X_WORLD - LEFT_X_WORLD));
    private const uint MAX_ZOOM_IN_METERS = 0x80;
    private const uint MAX_ZOOM_OUT_METERS = 0x200;
    public const float METERS_PER_PIXEL = 1f;
    public static readonly float PIXELS_PER_METER = 1f;
    public static readonly float RIGHT_X_WORLD = 512f;
    public static readonly float TOP_Z_WORLD = 512f;
    private const uint ZOOM_METERS = 0x80;

    public override void AddMapPin()
    {
    }

    protected override void CenterAt(Vector3 pos, Rect uvRect)
    {
        uvRect.center = FakeWorldToUV(pos);
        bool flag = false;
        if (uvRect.x < 0f)
        {
            uvRect.x = 0f;
            flag = true;
        }
        if (uvRect.y < 0f)
        {
            uvRect.y = 0f;
            flag = true;
        }
        if ((uvRect.x + uvRect.width) > 1f)
        {
            uvRect.x = 1f - uvRect.width;
            flag = true;
        }
        if ((uvRect.y + uvRect.height) > 1f)
        {
            uvRect.y = 1f - uvRect.height;
            flag = true;
        }
        base.mapTexture.uvRect = uvRect;
        if (flag)
        {
            base.centerOfMap_worldSpace = FakeUVToWorld(uvRect.center);
        }
    }

    public static Vector3 FakeUVToWorld(Vector2 uvPos)
    {
        float x = (uvPos.x * MAP_WIDTH_METERS) + LEFT_X_WORLD;
        return new Vector3(x, 0f, (uvPos.y * MAP_HEIGHT_METERS) + BOTTOM_Z_WORLD);
    }

    public static Vector2 FakeWorldToUV(Vector3 pos)
    {
        float x = (pos.x - LEFT_X_WORLD) / (RIGHT_X_WORLD - LEFT_X_WORLD);
        return new Vector2(x, (pos.z - BOTTOM_Z_WORLD) / (TOP_Z_WORLD - BOTTOM_Z_WORLD));
    }

    public override void Init(UITexture mapTexture_, UIImageButton tabButton_, GameObject mapIconPrefab_, GameObject mapIconParent_, Rect mapRect_, UIPanel clippingPanel_)
    {
        base.Init(mapTexture_, tabButton_, mapIconPrefab_, mapIconParent_, mapRect_, clippingPanel_);
        base.centerOfMap_worldSpace = Vector3.zero;
        this.ZoomTo(base.centerOfMap_worldSpace, 0x200);
    }

    public override void SyncUpdate()
    {
        this.CenterAt(base.centerOfMap_worldSpace);
    }

    public override void ZoomIn()
    {
        this.ZoomTo(base.centerOfMap_worldSpace, base.currentZoom - 0x80);
    }

    public override void ZoomOut()
    {
        this.ZoomTo(base.centerOfMap_worldSpace, base.currentZoom + 0x80);
    }

    private void ZoomTo(Vector3 pos, uint viewRadiusMeters)
    {
        if ((viewRadiusMeters >= 0x80) && (viewRadiusMeters <= 0x200))
        {
            base.currentZoom = viewRadiusMeters;
            Rect uvRect = base.mapTexture.uvRect;
            uvRect.height = (viewRadiusMeters * 2f) / MAP_WIDTH_METERS;
            uvRect.width = uvRect.height;
            this.CenterAt(pos, uvRect);
        }
    }
}

