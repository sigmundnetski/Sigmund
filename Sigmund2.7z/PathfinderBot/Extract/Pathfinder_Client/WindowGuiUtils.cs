﻿using GNGUI;
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public static class WindowGuiUtils
{
    private static List<WindowGui> _allWindows = new List<WindowGui>();
    internal const float DRAG_LAYER_Z_INDEX = -210f;
    public static bool escapeEvent = false;
    internal const float FRONT_Z_INDEX = -200f;
    internal const float REAR_Z_INDEX = -10f;
    public static HashSet<FullscreenWindowGui> visibleFullscreenWindows = new HashSet<FullscreenWindowGui>();
    internal const float WINDOW_Z_INCREMENT = 10f;

    public static void AddWindow(WindowGui window)
    {
        _allWindows.Add(window);
    }

    private static IEnumerable<WindowGui> AllWindows()
    {
        for (int i = _allWindows.Count - 1; i >= 0; i--)
        {
            if (_allWindows[i] == null)
            {
                _allWindows.RemoveAt(i);
            }
        }
        return _allWindows;
    }

    public static bool CloseTopWindow()
    {
        foreach (WindowGui gui in AllWindows())
        {
            if (gui.IsShowing())
            {
                escapeEvent = true;
                gui.HideWindow();
                escapeEvent = false;
                ResetAllZIndexes();
                return true;
            }
        }
        return false;
    }

    public static Transform FindDescendent(Transform transform, string name, int maxLevelsDeep)
    {
        if (transform != null)
        {
            if (transform.gameObject.name == name)
            {
                return transform;
            }
            if (maxLevelsDeep == 1)
            {
                return transform.FindChild(name);
            }
            for (int i = 0; i < transform.childCount; i++)
            {
                Transform transform2 = FindDescendent(transform.GetChild(i), name, maxLevelsDeep - 1);
                if (transform2 != null)
                {
                    return transform2;
                }
            }
        }
        return null;
    }

    internal static WindowGui FindWindow(GameObject nguiGO)
    {
        Transform parent = nguiGO.transform;
        WindowGui item = null;
        while ((parent != null) && (item == null))
        {
            item = parent.GetComponent<WindowGui>();
            parent = parent.parent;
        }
        return (((item != null) && _allWindows.Contains(item)) ? item : null);
    }

    internal static UIPanel[] GetSubPanels(Transform transform)
    {
        return (from each in transform.GetComponentsInChildren<UIPanel>(true)
            where each.transform != transform
            select each).ToArray<UIPanel>();
    }

    public static void MoveToBack(WindowGui window)
    {
        _allWindows.Remove(window);
        if (window != null)
        {
            _allWindows.Add(window);
        }
    }

    public static void MoveToFront(WindowGui window)
    {
        _allWindows.Remove(window);
        if (window != null)
        {
            _allWindows.Insert(0, window);
        }
    }

    internal static void Refocus(GameObject go)
    {
        WindowGui item = FindWindow(go);
        if (item != null)
        {
            _allWindows.Remove(item);
            _allWindows.Insert(0, item);
            ResetAllZIndexes();
        }
    }

    public static void RemoveWindow(WindowGui window)
    {
        _allWindows.Remove(window);
    }

    internal static void ResetAllZIndexes()
    {
        float num2 = 0f;
        foreach (WindowGui gui in AllWindows())
        {
            if (!gui.disableAutoZ && gui.IsShowing())
            {
                float newZIndex = Math.Min((float) (-200f + (num2 * 10f)), (float) -10f);
                UpdateZForPanel(gui.transform, newZIndex);
                num2++;
            }
        }
    }

    internal static void UpdateZForPanel(Transform panelTransform, float newZIndex)
    {
        Vector3 localPosition = panelTransform.localPosition;
        localPosition.z = newZIndex;
        panelTransform.localPosition = localPosition;
    }

    public static bool IsFullscreenWindowActive
    {
        get
        {
            return (visibleFullscreenWindows.Count > 0);
        }
    }
}

