﻿using GNGUI;
using System;
using UnityEngine;

public class PlayerBarGui : FloatingCharacterBarGui
{
    private Color aliveHpColor = new Color(1f, 1f, 1f);
    private const string ALT_PLAYER_BAR_POS = "GrannyRootBone/biped";
    private Color deadHpColor = new Color(0.5f, 0.5f, 0.5f);
    private bool delayedShouldBeShowing = false;
    private bool delaying = false;
    private const string PLAYER_BAR_POS = "biped";
    private UIFilledSprite powerBar;
    private const float SHOW_HIDE_DELAY = 0.25f;
    private float showHideTime = 0f;
    public static PlayerBarGui singleton;

    public override void Awake()
    {
        singleton = this;
        base.Awake();
        ClientTick.playerGuiTick = new GUtil.BoolFilterDelegate(this.SyncUpdate);
        foreach (UIFilledSprite sprite in base.GetComponentsInChildren<UIFilledSprite>())
        {
            if (sprite.name == "PowerCurrent")
            {
                this.powerBar = sprite;
            }
        }
        GuiHelper.GuiAssertNotNull("Could not find needed children.", new object[] { this.powerBar });
    }

    public void LogOut()
    {
        NGUITools.SetActive(singleton.gameObject, false);
    }

    public void NewPlayerGameObject(GameObject playerGO)
    {
        if (GraphicsClient.goblinCamera != null)
        {
            Transform followTransform = playerGO.transform.Find("biped");
            if (followTransform == null)
            {
                followTransform = playerGO.transform.Find("GrannyRootBone/biped");
            }
            this.Init(followTransform);
            base.followTarget.target = followTransform;
            Targeting.Init(followTransform);
        }
    }

    public void OnDestroy()
    {
        singleton = null;
    }

    public override void SetName(string name, Conning.Strength strength)
    {
    }

    public override void SetPower(float powerPercentage, int power)
    {
        this.powerBar.fillAmount = powerPercentage;
    }

    public override void SetStamina(float staminaPercentage, int stamina)
    {
        base.staminaBar.fillAmount = staminaPercentage;
    }

    private bool ShouldBeShowing(CombatVars cv)
    {
        int num2;
        bool inCombat = cv.inCombat;
        int num = (cv.hitPointRBCV.debuffSubmission + cv.hitPointRBCV.debuffTorment) + cv.hitPointRBCV.debuffWeakness;
        bool flag2 = (cv.hitPoints - num) < cv.GetMaxHitPoints();
        bool flag3 = cv.stamina < CombatData.singleton.staminaLimit;
        bool flag4 = false;
        for (num2 = 0; num2 < base.buffRibbons.Length; num2++)
        {
            flag4 = flag4 || base.buffRibbons[num2].gameObject.activeSelf;
        }
        bool flag5 = false;
        for (num2 = 0; num2 < base.stateBuffs.Length; num2++)
        {
            flag5 = flag5 || base.stateBuffs[num2].gameObject.activeSelf;
        }
        bool flag6 = ((inCombat || flag2) || (flag3 || flag4)) || flag5;
        if (!(((flag6 == this.delayedShouldBeShowing) || (this.showHideTime >= Time.time)) || this.delaying))
        {
            this.showHideTime = Time.time + 0.25f;
            this.delaying = true;
        }
        if (this.showHideTime < Time.time)
        {
            this.delaying = false;
            this.delayedShouldBeShowing = flag6;
        }
        return this.delayedShouldBeShowing;
    }

    public bool SyncUpdate()
    {
        CombatVars playerCombatVars = CombatClient.playerCombatVars;
        base.SyncUpdateCv(playerCombatVars);
        if (playerCombatVars != null)
        {
            if (!base.initialized)
            {
                this.NewPlayerGameObject(PlayerEntityClient.GetPlayer());
            }
            bool flag = base.IsShowing();
            bool flag2 = this.ShouldBeShowing(playerCombatVars);
            if (!(!flag || flag2))
            {
                this.Hide();
            }
            else if (!(flag || !flag2))
            {
                this.Show();
            }
        }
        return true;
    }
}

