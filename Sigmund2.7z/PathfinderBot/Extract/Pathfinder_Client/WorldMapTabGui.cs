﻿using GNGUI;
using Map;
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class WorldMapTabGui : MapWindowTabGui
{
    private uint DEFAULT_ZOOM_METERS;
    private bool initialized = false;
    private const uint MAX_ZOOM_IN_METERS = 0x200;
    private uint MAX_ZOOM_OUT_METERS;
    private int METERS_PER_PIXEL_ZOOM;
    private const uint ZOOM_METERS = 0x200;

    public override void AddMapPin()
    {
        Vector3 pos = base.clippingPanel.transform.InverseTransformPoint(UICamera.lastHit.point);
        Vector3 pinWorldPos = base.centerOfMap_worldSpace + MapClient.GuiToWorld(pos, this.PixelsPerMeter());
        MapClient.AddMapPin(pinWorldPos);
    }

    private void DisplayEntity(Entity entity, int iconId, Vector3 centerOfMap, EntityId playerEntityId)
    {
        IconUniqueKey key = new IconUniqueKey((entity.entityId == playerEntityId) ? IconType.START : IconType.ENTITY, PlaceType.INVALID, (ulong) EntityCore.GetForeignId(entity.entityId));
        MapIcon icon = null;
        if (!base.mapIcons.TryGetValue(key, out icon))
        {
            icon = MapIcon.NewMapIcon(base.mapIconParent, base.mapIconPrefab, key, iconId, "ent_" + entity.entityName, MapClient.FindWidgetDepth(key.iconType, base.nextIconDepth, base.availableDepths), MapWindowTabGui.COLLIDER_Z[(int) key.iconType], entity.EntityName, null);
            base.mapIcons[key] = icon;
        }
        base.iconsThisTick.Add(key);
        this.DisplayIcon(TerrainService.TranslateLocalToWorld(entity.gameObject.transform.position), icon, centerOfMap);
    }

    private void DisplayIcon(Vector3 position, MapIcon icon, Vector3 centerOfMap)
    {
        Vector3 pos = position - centerOfMap;
        Vector3 vector2 = MapClient.WorldToGui(pos, this.PixelsPerMeter());
        if (vector2.x < this.mapRect.x)
        {
            vector2.x = this.mapRect.x - 1f;
        }
        if (vector2.y > this.mapRect.y)
        {
            vector2.y = this.mapRect.y + 1f;
        }
        if (vector2.x > (this.mapRect.x + this.mapRect.width))
        {
            vector2.x = (this.mapRect.x + this.mapRect.width) + 1f;
        }
        if (vector2.y < (this.mapRect.y - this.mapRect.height))
        {
            vector2.y = (this.mapRect.y - this.mapRect.height) - 1f;
        }
        icon.SetPosition(vector2);
    }

    private void DisplayMapPlaces(MapPlace[] knownPlaces, Vector3 centerOfMap, params PlaceType[] placeTypeFilter)
    {
        if (knownPlaces != null)
        {
            using (IEnumerator<MapPlace> enumerator = SparseArray.Iterate<MapPlace>(knownPlaces).GetEnumerator())
            {
                while (enumerator.MoveNext())
                {
                    Predicate<PlaceType> predicate = null;
                    MapPlace place = enumerator.Current;
                    if (placeTypeFilter.Length != 0)
                    {
                    }
                    if ((predicate != null) || Array.Exists<PlaceType>(placeTypeFilter, predicate = i => i == place.mapKey.placeType))
                    {
                        MapIcon icon = null;
                        if (!base.mapIcons.TryGetValue(place.mapKey, out icon))
                        {
                            icon = MapIcon.NewMapIcon(base.mapIconParent, base.mapIconPrefab, place.mapKey, place.iconId, string.Concat(new object[] { "place_", place.mapKey.placeType, "_", place.mapKey.uniqueId }), MapClient.FindWidgetDepth(IconType.PLACE, base.nextIconDepth, base.availableDepths), MapWindowTabGui.COLLIDER_Z[2], place.popupText, null);
                            base.mapIcons[place.mapKey] = icon;
                        }
                        base.iconsThisTick.Add(place.mapKey);
                        this.DisplayIcon(TerrainService.TranslateServerToWorld(place.mapId, place.position), icon, centerOfMap);
                        if (place.mapKey.placeType == PlaceType.PLAYER_HUSK)
                        {
                            icon.icon.color = MapClient.GetHuskColor(EntityDataClient.owner, EntityDataClient.owner.playerId);
                        }
                        icon.popupText = place.popupText.Replace("{0}", EntityDataClient.owner.entityName);
                    }
                }
            }
        }
    }

    public override void Init(UITexture mapTexture_, UIImageButton tabButton_, GameObject mapIconPrefab_, GameObject mapIconParent_, Rect mapRect_, UIPanel clippingPanel_)
    {
        base.Init(mapTexture_, tabButton_, mapIconPrefab_, mapIconParent_, mapRect_, clippingPanel_);
        this.DEFAULT_ZOOM_METERS = Math.Min((uint) (MapClient.MAP_WIDTH_METERS / 2f), 0x1000);
        this.MAX_ZOOM_OUT_METERS = (uint) (MapClient.MAP_WIDTH_METERS / 2f);
        this.METERS_PER_PIXEL_ZOOM = (int) (MapClient.MAP_WIDTH_METERS / 2f);
        base.centerOfMap_worldSpace = MapClient.centerOfImage;
        MapWindowTabGui.ICON_PLAYER_OWNER = ImageData.MapIconIdFromName("player_proxy");
        MapWindowTabGui.ICON_PLAYER_PROXY = ImageData.MapIconIdFromName("player_proxy");
        this.ZoomTo(base.centerOfMap_worldSpace, this.DEFAULT_ZOOM_METERS);
    }

    public override Vector2 PixelsPerMeter()
    {
        Vector2 vector;
        float x = 0.2f * (((float) this.METERS_PER_PIXEL_ZOOM) / ((float) base.currentZoom));
        return new Vector3(x, x) { x = (vector.x * (this.mapRect.width * 5f)) / MapClient.MAP_WIDTH_METERS, y = (vector.y * (this.mapRect.height * 5f)) / MapClient.MAP_HEIGHT_METERS };
    }

    public override void SyncUpdate()
    {
        if (!(this.initialized || (EntityDataClient.owner == null)))
        {
            base.centerOfMap_worldSpace = TerrainService.TranslateLocalToWorld(EntityDataClient.owner.gameObject.transform.position);
            this.CenterAt(base.centerOfMap_worldSpace);
            this.initialized = true;
        }
        base.iconsThisTick.Clear();
        this.CenterAt(base.centerOfMap_worldSpace);
        EntityId entityId = EntityDataClient.owner.entityId;
        foreach (Entity entity in EntityCore.GetAllPlayerEntities(true))
        {
            if (entity.entityId == entityId)
            {
                this.DisplayEntity(entity, MapWindowTabGui.ICON_PLAYER_OWNER, base.centerOfMap_worldSpace, entityId);
                this.DisplayMapPlaces(entity.localMapPlaces, base.centerOfMap_worldSpace, new PlaceType[0]);
                this.DisplayMapPlaces(entity.playerRecord.mapPlaces, base.centerOfMap_worldSpace, new PlaceType[0]);
            }
            else
            {
                this.DisplayEntity(entity, MapWindowTabGui.ICON_PLAYER_PROXY, base.centerOfMap_worldSpace, entityId);
            }
        }
        List<IconUniqueKey> list = (from kvp in base.mapIcons select kvp.Key).Except<IconUniqueKey>(base.iconsThisTick).ToList<IconUniqueKey>();
        foreach (IconUniqueKey key in list)
        {
            MapIcon icon = base.mapIcons[key];
            base.availableDepths[(int) icon.info.iconType].Enqueue(icon.icon.depth);
            icon.Destroy();
            base.mapIcons.Remove(key);
        }
    }

    public override void ZoomIn()
    {
        this.ZoomTo(base.centerOfMap_worldSpace, base.currentZoom - 0x200);
    }

    public override void ZoomOut()
    {
        this.ZoomTo(base.centerOfMap_worldSpace, base.currentZoom + 0x200);
    }

    private void ZoomTo(Vector3 pos, uint viewRadiusMeters)
    {
        if ((viewRadiusMeters >= 0x200) && (viewRadiusMeters <= this.MAX_ZOOM_OUT_METERS))
        {
            base.currentZoom = viewRadiusMeters;
            Rect uvRect = base.mapTexture.uvRect;
            uvRect.height = (viewRadiusMeters * 2f) / MapClient.MAP_WIDTH_METERS;
            uvRect.width = uvRect.height;
            this.CenterAt(pos, uvRect);
        }
    }
}

