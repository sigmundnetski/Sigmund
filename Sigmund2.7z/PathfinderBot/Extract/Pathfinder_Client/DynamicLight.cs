﻿using System;
using UnityEngine;

[RequireComponent(typeof(Light))]
public class DynamicLight : MonoBehaviour
{
    public bool theSun = false;

    public void OnDestroy()
    {
        GraphicsClient.RemoveDynamicLight(base.GetComponent<Light>());
        if (this.theSun)
        {
            GraphicsClient.SetSun(null);
        }
    }

    public void Start()
    {
        base.gameObject.name = base.gameObject.name.ToLower();
        GraphicsClient.RegisterDynamicLight(base.GetComponent<Light>());
        if (this.theSun)
        {
            GraphicsClient.SetSun(base.gameObject);
        }
    }
}

