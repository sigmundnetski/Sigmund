﻿using GNGUI;
using System;
using UnityEngine;

public class CraftingWindow : FullscreenWindowGui
{
    private UIScrollBar[] allScrolls;
    private Color disabledButtonText = new Color(0.5019608f, 0.5019608f, 0.5019608f);
    private Color enabledButtonText = new Color(0.9411765f, 0.8901961f, 0.6588235f);
    private CraftingOutputDescription outputDescription;
    private CraftingOutputDetails outputDetails;
    private DisabledButton queueButton;
    private RecipeStocksGui recipeInputGroupGui;
    private RecipeInputsGui recipeInputsGui;
    private RecipeNameGui recipeNameGui;
    private RecipeQueueGui recipeQueueGui;
    private static readonly char[] SEARCH_SPLIT = new char[] { ' ' };
    private string[] searchArgs;
    private UIInput searchInput;
    public static CraftingWindow singleton;
    private int[] skillIds;
    private UILabel skillNameLabel;

    public void Awake()
    {
        singleton = this;
    }

    public override void HideWindow()
    {
        base.HideWindow();
        CraftingClient.OnCloseCrafting();
    }

    public void OnAllocationChange()
    {
        this.recipeInputGroupGui.Repopulate();
        this.recipeInputsGui.Repopulate();
        this.SetQueueButtonState();
        this.outputDetails.Update();
        this.outputDescription.Update();
    }

    public override void OnDestroy()
    {
        base.OnDestroy();
        singleton = null;
    }

    public void OnInputGroupSelected()
    {
        this.recipeInputsGui.Repopulate();
    }

    public void OnOwnerInvUpdate()
    {
        this.recipeQueueGui.Repopulate();
        this.recipeInputsGui.Repopulate();
        this.SetQueueButtonState();
        this.outputDetails.Update();
        this.outputDescription.Update();
    }

    public void OnQueueClick(GameObject go)
    {
        CraftingClient.QueueRequest();
    }

    public void OnRecipeSelected()
    {
        this.recipeInputGroupGui.Repopulate();
        this.recipeInputsGui.Repopulate();
        this.SetQueueButtonState();
        this.outputDetails.Update();
        this.outputDescription.Update();
    }

    public void OnSubmit(string input)
    {
        this.searchArgs = input.ToLower().Split(SEARCH_SPLIT, StringSplitOptions.RemoveEmptyEntries);
        this.recipeNameGui.Repopulate(this.skillIds, this.searchArgs);
    }

    public void OpenRecipeWindow(int[] skillIds_)
    {
        this.skillIds = skillIds_;
        this.recipeNameGui.Repopulate(skillIds_, this.searchArgs);
        this.recipeInputGroupGui.Repopulate();
        this.recipeInputGroupGui.Repopulate();
        this.SetQueueButtonState();
        this.outputDetails.Update();
        this.outputDescription.Update();
    }

    private void SetQueueButtonState()
    {
        this.queueButton.IsDisabled(!CraftingClient.RecipeReady());
    }

    public override void ShowWindow()
    {
        for (int i = 0; i < this.allScrolls.Length; i++)
        {
            this.allScrolls[i].scrollValue = 0f;
        }
        base.ShowWindow();
    }

    public void Start()
    {
        ClientTick.craftingSyncUpdate = new GUtil.BoolFilterDelegate(this.SyncUpdate);
        this.searchArgs = new string[0];
        this.recipeInputsGui = base.GetComponentInChildren<RecipeInputsGui>();
        this.recipeNameGui = base.GetComponentInChildren<RecipeNameGui>();
        this.recipeQueueGui = base.GetComponentInChildren<RecipeQueueGui>();
        this.recipeInputGroupGui = base.GetComponentInChildren<RecipeStocksGui>();
        this.queueButton = base.GetComponentInChildren<DisabledButton>();
        this.outputDetails = base.GetComponentInChildren<CraftingOutputDetails>();
        this.outputDescription = base.GetComponentInChildren<CraftingOutputDescription>();
        this.searchInput = base.GetComponentInChildren<UIInput>();
        this.allScrolls = base.GetComponentsInChildren<UIScrollBar>();
        foreach (UILabel label in base.GetComponentsInChildren<UILabel>())
        {
            if (label.name == "SkillNameLabel")
            {
                this.skillNameLabel = label;
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find required children.", new object[] { this.recipeInputsGui, this.recipeNameGui, this.recipeQueueGui, this.recipeInputGroupGui, this.queueButton, this.outputDetails, this.outputDescription, this.searchInput, this.skillNameLabel, this.allScrolls });
        this.skillNameLabel.text = "Recipes";
        this.queueButton.Assign(new string[] { "button_crafting_disabled_de", "button_crafting_disabled_de", "button_crafting_disabled_de" }, new string[] { "button_crafting_general_de", "button_crafting_general_mo", "button_crafting_general_cl" }, this.disabledButtonText, this.enabledButtonText);
        this.queueButton.IsDisabled(true);
        UIEventListener listener1 = UIEventListener.Get(this.queueButton.gameObject);
        listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.OnQueueClick));
        this.searchInput.onSubmit = (GNGUI.UIInput.OnSubmit) Delegate.Combine(this.searchInput.onSubmit, new GNGUI.UIInput.OnSubmit(this.OnSubmit));
        base.Init(3, true);
    }

    public bool SyncUpdate()
    {
        if (base.IsShowing())
        {
            this.recipeQueueGui.SyncUpdate();
        }
        return true;
    }
}

