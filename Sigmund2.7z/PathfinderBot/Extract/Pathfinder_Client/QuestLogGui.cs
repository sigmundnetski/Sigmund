﻿using GNGUI;
using System;
using System.Collections.Generic;
using UnityEngine;

public class QuestLogGui : WindowGui
{
    private UIImageButton acceptedBtn;
    private UIImageButton finishedBtn;
    private UIGrid questGrid;
    private List<QuestLogItem> questList = new List<QuestLogItem>();
    private GameObject questLogItem;
    private bool showActive = true;
    public static QuestLogGui singleton;
    private static Dictionary<int, QuestRecord> tempQuestIds = new Dictionary<int, QuestRecord>();
    private UIImageButton undoBtn;

    public void AcceptedClicked(GameObject clickedGO)
    {
        this.showActive = true;
        this.RebuildFromRecord();
    }

    public void Awake()
    {
        singleton = this;
    }

    public void FinishedClicked(GameObject clickedGO)
    {
        this.showActive = false;
        this.RebuildFromRecord();
    }

    public override void OnDestroy()
    {
        base.OnDestroy();
        singleton = null;
    }

    private void RebuildFromRecord()
    {
        QuestRecord[] activePersonalQuests = QuestClient.GetActivePersonalQuests(!this.showActive);
        UIGrid.SetElementCount<QuestLogItem>(DragDropRoot.root, this.questGrid, this.questLogItem, this.questList, SparseArray.Count<QuestRecord>(activePersonalQuests));
        tempQuestIds.Clear();
        foreach (QuestRecord record in SparseArray.Iterate<QuestRecord>(activePersonalQuests))
        {
            tempQuestIds[record.questId] = record;
        }
        foreach (QuestLogItem item in this.questList)
        {
            if (!tempQuestIds.Remove(item.questId))
            {
                item.questId = 0;
            }
        }
        foreach (QuestLogItem item in this.questList)
        {
            if (item.questId == 0)
            {
                foreach (KeyValuePair<int, QuestRecord> pair in tempQuestIds)
                {
                    item.SetQuest(this, pair.Value);
                    tempQuestIds.Remove(pair.Key);
                    break;
                }
            }
            item.UpdatePin(this.showActive);
        }
        bool flag = (EntityDataClient.owner.playerRecord.abandonedQuests != null) && (SparseArray.Count<QuestRecord>(EntityDataClient.owner.playerRecord.abandonedQuests) > 0);
        this.undoBtn.gameObject.SetActive(this.showActive && flag);
    }

    public static void Repopulate(bool forceShow)
    {
        if ((singleton != null) && (forceShow || singleton.IsShowing()))
        {
            singleton.RebuildFromRecord();
            if (forceShow)
            {
                singleton.ShowWindow();
            }
        }
    }

    public void Start()
    {
        this.questLogItem = UIClient.guiPrefabs["QuestLogItem"];
        this.questGrid = base.GetComponentInChildren<UIGrid>();
        this.acceptedBtn = base.transform.FindChild("HPO").FindChild("Accepted").GetComponent<UIImageButton>();
        this.finishedBtn = base.transform.FindChild("HPO").FindChild("Finished").GetComponent<UIImageButton>();
        this.undoBtn = base.transform.FindChild("HPO").FindChild("Undo").GetComponent<UIImageButton>();
        GuiHelper.GuiAssertNotNull("Couldn't load prefabs.", new object[] { this.questLogItem, this.acceptedBtn, this.finishedBtn, this.questGrid });
        UIEventListener listener1 = UIEventListener.Get(this.acceptedBtn.gameObject);
        listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.AcceptedClicked));
        UIEventListener listener2 = UIEventListener.Get(this.finishedBtn.gameObject);
        listener2.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener2.onClick, new UIEventListener.VoidDelegate(this.FinishedClicked));
        UIEventListener listener3 = UIEventListener.Get(this.undoBtn.gameObject);
        listener3.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener3.onClick, new UIEventListener.VoidDelegate(this.UndoClicked));
        this.undoBtn.gameObject.SetActive(false);
        base.Init(2, true);
    }

    public override void ToggleWindowVisibility()
    {
        if (!base.IsShowing())
        {
            Repopulate(true);
        }
        else
        {
            this.HideWindow();
        }
    }

    public void UndoClicked(GameObject clickedGO)
    {
        QuestClient.UndoAbandonQuest();
        this.RebuildFromRecord();
    }
}

