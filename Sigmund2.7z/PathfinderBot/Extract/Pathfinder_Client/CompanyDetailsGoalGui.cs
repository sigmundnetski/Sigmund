﻿using GNGUI;
using System;
using UnityEngine;

public class CompanyDetailsGoalGui : MonoBehaviour
{
    private VentureCompanyRecord.Goal goal;
    private UISprite goalIcon;

    public void Assign(VentureCompanyRecord.Goal goal)
    {
        this.goal = goal;
        switch (goal)
        {
            case (VentureCompanyRecord.Goal.NONE | VentureCompanyRecord.Goal.PVE):
                this.goalIcon.spriteName = "button_company_goal_pve_on";
                break;

            case (VentureCompanyRecord.Goal.NONE | VentureCompanyRecord.Goal.PVP):
                this.goalIcon.spriteName = "button_company_goal_pvp_on";
                break;

            case VentureCompanyRecord.Goal.MERC:
                this.goalIcon.spriteName = "button_company_goal_merc_on";
                break;

            case (VentureCompanyRecord.Goal.NONE | VentureCompanyRecord.Goal.RP):
                this.goalIcon.spriteName = "button_company_goal_rp_on";
                break;

            case (VentureCompanyRecord.Goal.NONE | VentureCompanyRecord.Goal.POI):
                this.goalIcon.spriteName = "button_company_goal_poi_on";
                break;

            case VentureCompanyRecord.Goal.CRAFT:
                this.goalIcon.spriteName = "button_company_goal_craft_on";
                break;

            case (VentureCompanyRecord.Goal.NONE | VentureCompanyRecord.Goal.SETTLEMENT):
                this.goalIcon.spriteName = "button_company_goal_settlement_on";
                break;
        }
        base.gameObject.name = ((int) goal).ToString("d2") + "_" + goal;
    }

    public void Awake()
    {
        this.goalIcon = base.GetComponentInChildren<UISprite>();
        GuiHelper.GuiAssertNotNull("Couldn't find sprite.", new object[] { this.goalIcon });
    }

    public void OnTooltip(bool show)
    {
        CompanyWindowGui.singleton.ShowTooltip(this.goal.ToString(), base.gameObject);
    }
}

