﻿using System;
using UnityEngine;

public abstract class AnimController
{
    protected bool animateStationaryAttack = true;
    public object[,] debugAnimInput = null;
    public object[,] debugAnimOutput = null;
    public BaseMotion.DebugLevel debugLevel = BaseMotion.DebugLevel.None;
    protected bool initialized = false;
    public const int NO_DEBUG_ATTACK_LOOP = -1;
    protected bool stealthed;

    protected AnimController()
    {
    }

    public abstract bool AbleToJump();
    protected virtual void AssertInit()
    {
        if (!this.initialized)
        {
            throw new Exception(base.GetType() + " is not initialized yet!");
        }
    }

    public abstract void DebugLoopAttack(int attackToLoop, string animSet);
    public abstract void Initialize(Entity entity);
    public abstract bool InJumpStates();
    public abstract void ProcessAttack(AnimationData attackAnim, bool useOffhand, bool isRooted, bool attackInterrupted, float currentTime, ref float attackEndTime);
    public abstract void ProcessCrowdControl(bool initialize, float animNum, float ccLength);
    public abstract void ProcessGather();
    public abstract void ProcessTurn(bool turning, Transform transform, float rotate, float yawTarget, float yawDeltaAbs);
    public abstract void ResetAllAnimInputs();
    public abstract void ResetAttack(int prevAttack);
    public abstract void ResetCrowdControl();
    public abstract void ResetGather();
    public abstract void ResetJump();
    public abstract void SetMovement(float rawTotalSpeed, float rawForwardSpeed, float rawStrafeSpeed, float rawForward, float rawStrafe, float rawRotate, float smoothForward, float smoothStrafe, float smoothRotate);
    public virtual void SetStealth(bool enabled)
    {
        this.stealthed = enabled;
    }

    public abstract void SetUnconscious(bool isUnconscious);
    public abstract void SetWeapon(int _mainhandCategoryId, int _offhandCategoryId);
    public virtual void Start()
    {
        this.initialized = true;
        this.ResetAllAnimInputs();
    }

    public abstract void Update(bool validEntity, bool inCombat, bool prevInCombat, bool attackInProgress, bool prevAttackInProgress, bool attackIsRooted, CombatVars.DeathState deathState, AnimationData attackAnim, bool debugManualLayers);
    public abstract void UpdateJump(BaseMotion.JumpState currentJumpState);
}

