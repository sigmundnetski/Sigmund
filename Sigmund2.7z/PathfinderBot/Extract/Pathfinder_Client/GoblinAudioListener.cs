﻿using System;
using UnityEngine;

public class GoblinAudioListener : MonoBehaviour
{
    private const float DEFAULT_POS = 0.5f;
    public float percentDistance = 0.5f;
    public static GoblinAudioListener singleton;

    public void Awake()
    {
        singleton = this;
    }

    public void OnDestroy()
    {
        singleton = null;
    }
}

