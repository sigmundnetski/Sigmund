﻿using GNGUI;
using Map;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

public class MiniMapGui : MonoBehaviour
{
    private Queue<int>[] availableDepths;
    private Vector3 centerOfMap_worldSpace = GConst.VECTOR3_INVALID;
    private UIPanel clippingPanel;
    private static readonly float[] COLLIDER_Z;
    private static Color COLOR_FRIENDLY;
    private static Color COLOR_HOSTILE;
    private static Color COLOR_NEUTRAL;
    private static Color COLOR_PARTY;
    private static Color COLOR_SELF;
    private ushort currentMapId;
    private uint currentZoom;
    private const float DEFAULT_OPACITY = 0.9f;
    private const uint DEFAULT_ZOOM_METERS = 100;
    private static readonly float[] ESCALATION_ICON_INDEX;
    private static readonly string[] ESCALATION_ICONS;
    private string escalationHoverText = null;
    private UISprite escalationInfoIcon;
    private const float FOCUSED_OPACITY = 1f;
    private string hexHoverText = null;
    private UISprite hexInfoBackground;
    private UISprite hexInfoIcon;
    private static int ICON_COMBAT_NPC;
    private static int ICON_GATHER_NODE;
    private static int ICON_GUARD;
    private static int ICON_HUSK;
    private static int ICON_PLAYER_OWNER;
    private static int ICON_PLAYER_PROXY;
    private static int ICON_TRAINER;
    private HashSet<IconUniqueKey> iconsThisTick = new HashSet<IconUniqueKey>();
    private const float MAGNET_OVERHANG_GUI = 109f;
    private GameObject mapIconParent;
    private GameObject mapIconPrefab;
    private Dictionary<IconUniqueKey, MapIcon> mapIcons = new Dictionary<IconUniqueKey, MapIcon>();
    private UIImageButton mapWindowButton;
    private const uint MAX_ZOOM_IN_METERS = 50;
    private const uint MAX_ZOOM_OUT_METERS = 200;
    private const int METERS_PER_PIXEL_ZOOM = 120;
    private UITexture minimap;
    private bool needsUpdate = false;
    private int[] nextIconDepth;
    private Camera nguiCamera;
    private MapFilter playerFilter = MapFilter.ALL_ICONS;
    private bool prevMapWindowVis;
    public static MiniMapGui singleton;
    private static readonly int[] WIDGET_DEPTH_MIN = new int[] { 500, 10, 410 };
    private const uint ZOOM_METERS = 0x19;
    private UIImageButton zoomInButton;
    private UIImageButton zoomOutButton;

    static MiniMapGui()
    {
        float[] numArray = new float[3];
        numArray[0] = -1f;
        numArray[2] = -2f;
        COLLIDER_Z = numArray;
        ESCALATION_ICON_INDEX = new float[] { 0.75f, 0.5f, 0.25f, 0f };
        ESCALATION_ICONS = new string[] { "icon_minimap_escalation3_de", "icon_minimap_escalation2_de", "icon_minimap_escalation1_de", "icon_minimap_escalation0_de" };
    }

    public void Awake()
    {
        singleton = this;
        this.OnAwake();
    }

    private void CenterAt(Vector3 pos)
    {
        Rect uvRect = this.minimap.uvRect;
        this.CenterAt(pos, uvRect);
    }

    private void CenterAt(Vector3 pos, Rect uvRect)
    {
        float x = (pos.x - MapClient.LEFT_X_WORLD) / (MapClient.RIGHT_X_WORLD - MapClient.LEFT_X_WORLD);
        float y = (pos.z - MapClient.BOTTOM_Z_WORLD) / (MapClient.TOP_Z_WORLD - MapClient.BOTTOM_Z_WORLD);
        uvRect.center = new Vector2(x, y);
        this.minimap.uvRect = uvRect;
    }

    private void DisplayEachEntity(EntityId playerEntityId, Quaternion playerRot, Entity eachEntity)
    {
        if (eachEntity.entityId == playerEntityId)
        {
            this.DisplayPlayer(eachEntity, playerRot);
            this.DisplayMapPlaces(eachEntity.localMapPlaces, eachEntity.entityId, ColorType.PLAYER_OWNER, this.centerOfMap_worldSpace, new PlaceType[0]);
            this.DisplayMapPlaces(eachEntity.playerRecord.mapPlaces, eachEntity.entityId, ColorType.PLAYER_OWNER, this.centerOfMap_worldSpace, new PlaceType[0]);
        }
        else if (eachEntity.createType == GConst.CreateType.PLAYER)
        {
            this.DisplayEntity(eachEntity, ICON_PLAYER_PROXY, this.GetEntityColor(eachEntity, ColorType.PLAYER_PROXY), this.centerOfMap_worldSpace);
        }
        else if (eachEntity.entityDefn.trainerId != 0)
        {
            this.DisplayEntity(eachEntity, ICON_TRAINER, COLOR_NEUTRAL, this.centerOfMap_worldSpace);
        }
        else if (eachEntity.entityDefn.aiType == AiData.AiType.AiGuard)
        {
            this.DisplayEntity(eachEntity, ICON_GUARD, COLOR_NEUTRAL, this.centerOfMap_worldSpace);
        }
        else if (eachEntity.entityDefn.gatheringNodeId != 0)
        {
            this.DisplayEntity(eachEntity, ICON_GATHER_NODE, this.GetEntityColor(eachEntity, ColorType.NONE), this.centerOfMap_worldSpace);
        }
        else if (eachEntity.huskVars != null)
        {
            this.DisplayEntity(eachEntity, ICON_HUSK, MapClient.GetHuskColor(eachEntity, EntityDataClient.owner.playerId), this.centerOfMap_worldSpace);
        }
        else if ((eachEntity.createType == GConst.CreateType.NPC) && (eachEntity.combat != null))
        {
            this.DisplayEntity(eachEntity, ICON_COMBAT_NPC, this.GetEntityColor(eachEntity, ColorType.NPC), this.centerOfMap_worldSpace);
        }
    }

    private void DisplayEntity(Entity entity, int iconId, Color setColor, Vector3 centerOfMap)
    {
        if (this.EntityValidForFilter(entity))
        {
            IconUniqueKey key = new IconUniqueKey(IconType.ENTITY, PlaceType.INVALID, (ulong) EntityCore.GetForeignId(entity.entityId));
            MapIcon icon = null;
            if (!this.mapIcons.TryGetValue(key, out icon))
            {
                icon = MapIcon.NewMapIcon(this.mapIconParent, this.mapIconPrefab, key, iconId, "ent_" + entity.entityName, MapClient.FindWidgetDepth(key.iconType, this.nextIconDepth, this.availableDepths), COLLIDER_Z[(int) key.iconType], entity.EntityName, null);
                this.mapIcons[key] = icon;
            }
            this.iconsThisTick.Add(key);
            this.DisplayIcon(TerrainService.TranslateLocalToWorld(entity.GetLocalPosition()), icon, centerOfMap);
            icon.icon.color = setColor;
        }
    }

    private void DisplayIcon(Vector3 position, MapIcon icon, Vector3 centerOfMap)
    {
        Vector3 pos = position - centerOfMap;
        Vector3 vector2 = Vector3.ClampMagnitude(MapClient.WorldToGui(pos, this.PixelsPerMeter()), 109f);
        icon.SetPosition(vector2);
    }

    private void DisplayMapPlaces(MapPlace[] knownPlaces, EntityId entityId, ColorType colorType, Vector3 centerOfMap, params PlaceType[] placeTypeFilter)
    {
        if (knownPlaces != null)
        {
            using (IEnumerator<MapPlace> enumerator = SparseArray.Iterate<MapPlace>(knownPlaces).GetEnumerator())
            {
                while (enumerator.MoveNext())
                {
                    Predicate<PlaceType> predicate = null;
                    MapPlace place = enumerator.Current;
                    if (this.MapPlaceValidForFilter(place))
                    {
                        if (placeTypeFilter.Length != 0)
                        {
                        }
                        if ((predicate != null) || Array.Exists<PlaceType>(placeTypeFilter, predicate = i => i == place.mapKey.placeType))
                        {
                            MapIcon icon = null;
                            if (!this.mapIcons.TryGetValue(place.mapKey, out icon))
                            {
                                icon = MapIcon.NewMapIcon(this.mapIconParent, this.mapIconPrefab, place.mapKey, place.iconId, string.Concat(new object[] { "place_", place.mapKey.placeType, "_", place.mapKey.uniqueId }), MapClient.FindWidgetDepth(IconType.PLACE, this.nextIconDepth, this.availableDepths), COLLIDER_Z[2], place.popupText, null);
                                this.mapIcons[place.mapKey] = icon;
                            }
                            this.iconsThisTick.Add(place.mapKey);
                            this.DisplayIcon(TerrainService.TranslateServerToWorld(place.mapId, place.position), icon, centerOfMap);
                            Entity huskEntity = EntityCore.GetEntity(entityId);
                            if (huskEntity.huskVars != null)
                            {
                                icon.icon.color = MapClient.GetHuskColor(huskEntity, EntityDataClient.owner.playerId);
                            }
                            else
                            {
                                icon.icon.color = this.GetEntityColor(huskEntity, colorType);
                            }
                            icon.popupText = place.popupText.Replace("{0}", EntityDataClient.owner.entityName);
                        }
                    }
                }
            }
        }
    }

    private void DisplayPlayer(Entity playerEnt, Quaternion rotation)
    {
        IconUniqueKey key = new IconUniqueKey(IconType.START, PlaceType.INVALID, (ulong) EntityCore.GetForeignId(playerEnt.entityId));
        MapIcon icon = null;
        if (!this.mapIcons.TryGetValue(key, out icon))
        {
            icon = MapIcon.NewMapIcon(this.mapIconParent, this.mapIconPrefab, key, ICON_PLAYER_OWNER, "player_" + playerEnt.entityName, MapClient.FindWidgetDepth(IconType.START, this.nextIconDepth, this.availableDepths), COLLIDER_Z[0], null, new MapIcon.TooltipTextDelegate(this.GetPlayerTooltip));
            this.mapIcons[key] = icon;
        }
        this.iconsThisTick.Add(key);
        icon.SetRotation(MapClient.WorldToGui(rotation));
        icon.icon.color = this.GetEntityColor(playerEnt, ColorType.PLAYER_OWNER);
    }

    private bool EntityValidForFilter(Entity entity)
    {
        if (((!this.IsFlagSet(MapFilter.ALL_ICONS | MapFilter.PLAYERS) && (entity.createType == GConst.CreateType.PLAYER)) || (!this.IsFlagSet(MapFilter.ALL_ICONS | MapFilter.MONSTERS) && (entity.createType == GConst.CreateType.NPC))) || (!this.IsFlagSet(MapFilter.ALL_ICONS | MapFilter.GATHER_NODES) && (entity.entityDefn.gatheringNodeId != 0)))
        {
            return false;
        }
        return true;
    }

    public void EscalationChange()
    {
        this.needsUpdate = true;
    }

    private Color GetEntityColor(Entity entity, ColorType type)
    {
        Color color = COLOR_NEUTRAL;
        if (type == ColorType.PLAYER_PROXY)
        {
            if ((GroupClient.activeParty != null) && GroupClient.activeParty.IsPartyMember(entity.playerId))
            {
                return COLOR_PARTY;
            }
            if (Conning.GetRelativeStrength(entity.entityId) == Conning.Strength.HostilePlayer)
            {
                color = COLOR_HOSTILE;
            }
            return color;
        }
        if (type == ColorType.NPC)
        {
            return COLOR_HOSTILE;
        }
        if (type == ColorType.PLAYER_OWNER)
        {
            color = COLOR_SELF;
        }
        return color;
    }

    public string GetPlayerTooltip(IconUniqueKey context)
    {
        if (context.iconType != IconType.START)
        {
            return null;
        }
        return MapClient.GetDisplayPosition("{0:f2}km {1}, {2:f2}km {3} of Thornkeep", this.centerOfMap_worldSpace);
    }

    private void HandleUpdate()
    {
        this.hexHoverText = null;
        this.escalationHoverText = null;
        HexData data = null;
        HexTypeData data2 = null;
        if (HexData.dataByMapId.TryGetValue(this.currentMapId, out data) && HexTypeData.typeById.TryGetValue(data.hexTypeId, out data2))
        {
            this.SetHexInfo(data, data2);
            this.SetEscalationInfo();
        }
        else
        {
            NGUITools.SetActive(this.hexInfoIcon.gameObject, false);
            NGUITools.SetActive(this.hexInfoBackground.gameObject, false);
            NGUITools.SetActive(this.escalationInfoIcon.gameObject, false);
        }
    }

    private bool IsFlagSet(MapFilter flag)
    {
        return ((this.playerFilter == MapFilter.ALL_ICONS) || ((this.playerFilter & flag) == flag));
    }

    public bool LoadingTickFinished()
    {
        ContextInvokerGui componentInChildren = base.GetComponentInChildren<ContextInvokerGui>();
        GuiHelper.GuiAssertNotNull("Could not find context invoker.", new object[] { componentInChildren });
        componentInChildren.Init(-1, MiniMapContextGui.singleton, ContextInvokerGui.NguiMouse.LEFT);
        this.nextIconDepth = new int[3];
        this.availableDepths = new Queue<int>[3];
        for (int i = 0; i < 3; i++)
        {
            this.nextIconDepth[i] = WIDGET_DEPTH_MIN[i];
            this.availableDepths[i] = new Queue<int>();
        }
        ICON_PLAYER_OWNER = ImageData.MapIconIdFromName("player_owner");
        ICON_PLAYER_PROXY = ImageData.MapIconIdFromName("player_proxy");
        ICON_COMBAT_NPC = ImageData.MapIconIdFromName("combat_npc");
        ICON_GATHER_NODE = ImageData.MapIconIdFromName("gather_node");
        ICON_GUARD = ImageData.MapIconIdFromName("guard_npc");
        ICON_HUSK = ImageData.MapIconIdFromName("player_husk");
        ICON_TRAINER = ImageData.MapIconIdFromName("trainer_npc");
        COLOR_NEUTRAL = ColorData.GetColorByName("map_neutral", true);
        COLOR_HOSTILE = ColorData.GetColorByName("map_hostile", true);
        COLOR_FRIENDLY = ColorData.GetColorByName("map_friendly", true);
        COLOR_PARTY = ColorData.GetColorByName("map_party", true);
        COLOR_SELF = ColorData.GetColorByName("map_self", true);
        this.mapIconPrefab = UIClient.guiPrefabs["MapItem"];
        GuiHelper.GuiAssertNotNull("Couldn't load prefabs.", new object[] { this.mapIconPrefab });
        this.nguiCamera = NGUITools.FindCameraForLayer(base.gameObject.layer);
        this.clippingPanel = base.GetComponentInChildren<UIPanel>();
        GuiHelper.GuiAssertNotNull("Couldn't find needed children.", new object[] { this.clippingPanel });
        this.minimap = this.clippingPanel.GetComponentInChildren<UITexture>();
        this.mapIconParent = base.transform.Find("FgPanel/MapIconParent").gameObject;
        foreach (UIImageButton button in base.GetComponentsInChildren<UIImageButton>())
        {
            if (button.name == "ZoomIn")
            {
                this.zoomInButton = button;
            }
            else if (button.name == "ZoomOut")
            {
                this.zoomOutButton = button;
            }
            else if (button.name == "OpenBigMap")
            {
                this.mapWindowButton = button;
            }
        }
        foreach (UISprite sprite in base.GetComponentsInChildren<UISprite>())
        {
            if (sprite.name == "HexInfoIcon")
            {
                this.hexInfoIcon = sprite;
            }
            else if (sprite.name == "HexInfoBackground")
            {
                this.hexInfoBackground = sprite;
            }
            else if (sprite.name == "EscalationInfoIcon")
            {
                this.escalationInfoIcon = sprite;
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find needed objects.", new object[] { this.nguiCamera, this.minimap, this.mapIconParent, this.zoomInButton, this.zoomOutButton, this.mapWindowButton, this.hexInfoIcon, this.hexInfoBackground, this.escalationInfoIcon });
        this.clippingPanel.customAlphaMultiplier = 0.9f;
        UIEventListener listener1 = UIEventListener.Get(this.zoomInButton.gameObject);
        listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.ZoomIn));
        UIEventListener listener2 = UIEventListener.Get(this.zoomOutButton.gameObject);
        listener2.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener2.onClick, new UIEventListener.VoidDelegate(this.ZoomOut));
        UIEventListener listener3 = UIEventListener.Get(this.mapWindowButton.gameObject);
        listener3.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener3.onClick, new UIEventListener.VoidDelegate(this.ToggleMapWindow));
        UIEventListener listener4 = UIEventListener.Get(this.hexInfoIcon.gameObject);
        listener4.onHover = (UIEventListener.BoolDelegate) Delegate.Combine(listener4.onHover, new UIEventListener.BoolDelegate(this.OnHexHover));
        UIEventListener listener5 = UIEventListener.Get(this.escalationInfoIcon.gameObject);
        listener5.onHover = (UIEventListener.BoolDelegate) Delegate.Combine(listener5.onHover, new UIEventListener.BoolDelegate(this.OnEscalationHover));
        this.ZoomTo(Vector3.zero, 100);
        HexConflictHover.Refresh();
        return true;
    }

    private bool MapPlaceValidForFilter(MapPlace place)
    {
        if ((!this.IsFlagSet(MapFilter.ALL_ICONS | MapFilter.EVENT) && (place.mapKey.placeType == PlaceType.EVENT)) || (!this.IsFlagSet(MapFilter.ALL_ICONS | MapFilter.PINS) && (place.mapKey.placeType == PlaceType.PLAYER_MAP_PIN)))
        {
            return false;
        }
        return true;
    }

    private void OnAwake()
    {
        ClientTick.miniMapGuiLoadFinish = new GUtil.BoolFilterDelegate(this.LoadingTickFinished);
        ClientTick.miniMapGuiTick = new GUtil.BoolFilterDelegate(this.SyncUpdate);
    }

    public void OnDestroy()
    {
        singleton = null;
    }

    public void OnDoubleClick()
    {
        Vector3 pos = base.transform.InverseTransformPoint(UICamera.lastHit.point);
        Vector3 pinWorldPos = this.centerOfMap_worldSpace + MapClient.GuiToWorld(pos, this.PixelsPerMeter());
        MapClient.AddMapPin(pinWorldPos);
    }

    public void OnEscalationHover(GameObject buttonGO, bool isHovered)
    {
        if (isHovered)
        {
            UITooltip.ShowText(this.escalationHoverText, this.escalationInfoIcon.gameObject);
        }
        else
        {
            UITooltip.ShowText(null, null);
        }
    }

    public void OnHexHover(GameObject buttonGO, bool isHovered)
    {
        if (isHovered)
        {
            UITooltip.ShowText(this.hexHoverText, this.hexInfoIcon.gameObject);
        }
        else
        {
            UITooltip.ShowText(null, null);
        }
    }

    public void OnMapTransfer(ushort mapId)
    {
        this.needsUpdate = true;
        this.currentMapId = mapId;
    }

    private void OrientMap(Vector3 position, Quaternion rotation)
    {
        this.CenterAt(position);
    }

    public Vector2 PixelsPerMeter()
    {
        float x = 120f / ((float) this.currentZoom);
        return new Vector3(x, x);
    }

    public void SetConningInfo()
    {
        Conning.Strength relativeStrength = Conning.GetRelativeStrength(EntityDataClient.owner.escalationVars.hexCR);
        this.hexInfoIcon.color = Conning.GetRelativeStrengthColor(relativeStrength);
    }

    public void SetEscalationInfo()
    {
        EscalationVars escalationVars = EntityDataClient.owner.escalationVars;
        if (escalationVars.escalationId == 0)
        {
            NGUITools.SetActive(this.escalationInfoIcon.gameObject, false);
        }
        else
        {
            EscalationDetailData details = EscalationData.escalationsById[escalationVars.escalationId].details;
            StringBuilder quickText = GUtil.GetQuickText();
            quickText.Append(details.displayName);
            quickText.Append("\n").Append(details.phaseDisplayName[escalationVars.phase]);
            quickText.Append("\n").Append(details.phaseDisplayBlurb[escalationVars.phase]);
            quickText.Append("\n\n").Append("strength: ").Append(escalationVars.strength.ToString("f1")).Append("(").Append(escalationVars.normalizedStrength.ToString("p1")).Append(")");
            this.escalationHoverText = quickText.ToString();
            for (int i = 0; i < ESCALATION_ICONS.Length; i++)
            {
                if (escalationVars.normalizedStrength >= ESCALATION_ICON_INDEX[i])
                {
                    this.escalationInfoIcon.spriteName = ESCALATION_ICONS[i];
                    break;
                }
            }
            NGUITools.SetActive(this.escalationInfoIcon.gameObject, true);
        }
    }

    public void SetFlag(MapFilter flag)
    {
        this.playerFilter = (MapFilter) ((byte) (this.playerFilter | flag));
    }

    public void SetHexInfo(HexData hex, HexTypeData hexType)
    {
        this.hexInfoIcon.spriteName = hexType.icon;
        if (((byte) (hexType.uiFlags & (HexTypeData.UiFlags.NONE | HexTypeData.UiFlags.OWNERSHIP))) == 1)
        {
            this.SetOwnershipInfo(hex, hexType);
        }
        if (((byte) (hexType.uiFlags & HexTypeData.UiFlags.MONSTER_TYPE)) == 2)
        {
            this.SetMonsterTypeInfo(hex, hexType);
        }
        if (((byte) (hexType.uiFlags & (HexTypeData.UiFlags.NONE | HexTypeData.UiFlags.NPC))) == 0x10)
        {
            this.SetNpcInfo(hex, hexType);
        }
        if (((byte) (hexType.uiFlags & HexTypeData.UiFlags.HOSTILITY)) == 0x20)
        {
            this.SetHostilityInfo(hex, hexType);
        }
        if (((byte) (hexType.uiFlags & HexTypeData.UiFlags.CONNING)) == 0x40)
        {
            this.SetConningInfo();
        }
        NGUITools.SetActive(this.hexInfoIcon.gameObject, true);
        NGUITools.SetActive(this.hexInfoBackground.gameObject, true);
    }

    public void SetHostilityInfo(HexData hex, HexTypeData hexType)
    {
    }

    public void SetMonsterTypeInfo(HexData hex, HexTypeData hexType)
    {
    }

    public void SetNpcInfo(HexData hex, HexTypeData hexType)
    {
    }

    public void SetOpacity()
    {
        if (MapClient.GuiToWorld(base.transform.InverseTransformPoint(this.nguiCamera.ScreenToWorldPoint((Vector3) UICamera.lastTouchPosition)), this.PixelsPerMeter()).magnitude <= this.currentZoom)
        {
            this.clippingPanel.customAlphaMultiplier = 1f;
        }
        else
        {
            this.clippingPanel.customAlphaMultiplier = 0.9f;
        }
    }

    public void SetOwnershipInfo(HexData hex, HexTypeData hexType)
    {
    }

    public bool SyncUpdate()
    {
        this.iconsThisTick.Clear();
        if (!object.ReferenceEquals(EntityDataClient.owner, null) && !object.ReferenceEquals(EntityDataClient.owner.gameObject, null))
        {
            if (this.needsUpdate)
            {
                this.needsUpdate = false;
                this.HandleUpdate();
            }
            GameObject gameObject = EntityDataClient.owner.gameObject;
            EntityId entityId = EntityDataClient.owner.entityId;
            this.centerOfMap_worldSpace = TerrainService.TranslateLocalToWorld(gameObject.transform.position);
            Quaternion rotation = gameObject.transform.rotation;
            this.OrientMap(this.centerOfMap_worldSpace, rotation);
            this.SetOpacity();
            foreach (Entity entity in EntityCore.GetAllEntities(true))
            {
                GUtil.FilterExceptions(this, "DisplayEachEntity", new object[] { entityId, rotation, entity });
            }
            List<IconUniqueKey> list = (from kvp in this.mapIcons select kvp.Key).Except<IconUniqueKey>(this.iconsThisTick).ToList<IconUniqueKey>();
            foreach (IconUniqueKey key in list)
            {
                MapIcon icon = this.mapIcons[key];
                this.availableDepths[(int) icon.info.iconType].Enqueue(icon.icon.depth);
                icon.Destroy();
                this.mapIcons.Remove(key);
            }
            bool flag = MapWindowGui.singleton.IsShowing();
            if (flag != this.prevMapWindowVis)
            {
                this.mapWindowButton.normalSprite = flag ? "button_minimap_expand_ac" : "button_minimap_expand_de";
                this.mapWindowButton.SendMessage("OnHover", false, SendMessageOptions.DontRequireReceiver);
                this.prevMapWindowVis = flag;
            }
        }
        return true;
    }

    public void ToggleMapWindow(GameObject buttonGO)
    {
        MapWindowGui.singleton.ToggleWindowVisibility();
    }

    public void UnsetFlag(MapFilter flag)
    {
        this.playerFilter = (MapFilter) ((byte) (this.playerFilter & ((byte) ~flag)));
    }

    public void UpdateHexCR()
    {
        HexData data = null;
        HexTypeData data2 = null;
        if ((HexData.dataByMapId.TryGetValue(this.currentMapId, out data) && HexTypeData.typeById.TryGetValue(data.hexTypeId, out data2)) && (((byte) (data2.uiFlags & HexTypeData.UiFlags.CONNING)) == 0x40))
        {
            this.SetConningInfo();
        }
    }

    public void ZoomIn(GameObject buttonGO)
    {
        GameObject player = PlayerEntityClient.GetPlayer();
        if (player != null)
        {
            this.ZoomTo(player.transform.position, this.currentZoom - 0x19);
        }
    }

    public void ZoomOut(GameObject buttonGO)
    {
        GameObject player = PlayerEntityClient.GetPlayer();
        if (player != null)
        {
            this.ZoomTo(player.transform.position, this.currentZoom + 0x19);
        }
    }

    private void ZoomTo(Vector3 pos, uint viewRadiusMeters)
    {
        if ((viewRadiusMeters >= 50) && (viewRadiusMeters <= 200))
        {
            this.currentZoom = viewRadiusMeters;
            Rect uvRect = this.minimap.uvRect;
            uvRect.height = (viewRadiusMeters * 2f) / MapClient.MAP_WIDTH_METERS;
            uvRect.width = uvRect.height;
            this.CenterAt(pos, uvRect);
        }
    }

    private enum ColorType
    {
        NONE,
        NPC,
        PLAYER_OWNER,
        PLAYER_PROXY
    }

    [Flags]
    public enum MapFilter : byte
    {
        ALL_ICONS = 0,
        EVENT = 8,
        GATHER_NODES = 4,
        MONSTERS = 2,
        PINS = 0x10,
        PLAYERS = 1,
        QUEST = 0x10
    }
}

