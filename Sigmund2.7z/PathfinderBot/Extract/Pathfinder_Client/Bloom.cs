﻿using System;
using UnityEngine;

[RequireComponent(typeof(Camera)), AddComponentMenu("Image Effects/Bloom (4.0, HDR, Lens Flares)"), ExecuteInEditMode]
internal class Bloom : PostEffectsBase
{
    public int bloomBlurIterations = 2;
    public float bloomIntensity = 0.5f;
    public float bloomThreshhold = 0.5f;
    public Color bloomThreshholdColor = Color.white;
    private Material blurAndFlaresMaterial;
    public Shader blurAndFlaresShader = null;
    public float blurWidth = 1f;
    private Material brightPassFilterMaterial;
    public Shader brightPassFilterShader = null;
    public float chromaticBloom = 0f;
    private bool doHdr = false;
    public Color flareColorA = new Color(0.4f, 0.4f, 0.8f, 0.75f);
    public Color flareColorB = new Color(0.4f, 0.8f, 0.8f, 0.75f);
    public Color flareColorC = new Color(0.8f, 0.4f, 0.8f, 0.75f);
    public Color flareColorD = new Color(0.8f, 0.4f, 0f, 0.75f);
    public float flareRotation = 0f;
    public HDRBloomMode hdr = HDRBloomMode.Auto;
    public float hollyStretchWidth = 2.5f;
    public int hollywoodFlareBlurIterations = 2;
    public float lensflareIntensity = 0f;
    private Material lensFlareMaterial;
    public LensFlareStyle lensflareMode = LensFlareStyle.Anamorphic;
    public float lensFlareSaturation = 0.75f;
    public Shader lensFlareShader = null;
    public float lensflareThreshhold = 0.3f;
    public Texture2D lensFlareVignetteMask = null;
    public BloomQuality quality = BloomQuality.High;
    private Material screenBlend;
    public BloomScreenBlendMode screenBlendMode = BloomScreenBlendMode.Add;
    public Shader screenBlendShader = null;
    public float sepBlurSpread = 2.5f;
    public TweakMode tweakMode = TweakMode.Basic;

    private void AddTo(float intensity_, RenderTexture from, RenderTexture to)
    {
        this.screenBlend.SetFloat("_Intensity", intensity_);
        Graphics.Blit(from, to, this.screenBlend, 9);
    }

    private void BlendFlares(RenderTexture from, RenderTexture to)
    {
        this.lensFlareMaterial.SetVector("colorA", (Vector4) (new Vector4(this.flareColorA.r, this.flareColorA.g, this.flareColorA.b, this.flareColorA.a) * this.lensflareIntensity));
        this.lensFlareMaterial.SetVector("colorB", (Vector4) (new Vector4(this.flareColorB.r, this.flareColorB.g, this.flareColorB.b, this.flareColorB.a) * this.lensflareIntensity));
        this.lensFlareMaterial.SetVector("colorC", (Vector4) (new Vector4(this.flareColorC.r, this.flareColorC.g, this.flareColorC.b, this.flareColorC.a) * this.lensflareIntensity));
        this.lensFlareMaterial.SetVector("colorD", (Vector4) (new Vector4(this.flareColorD.r, this.flareColorD.g, this.flareColorD.b, this.flareColorD.a) * this.lensflareIntensity));
        Graphics.Blit(from, to, this.lensFlareMaterial);
    }

    private void BrightFilter(float thresh, RenderTexture from, RenderTexture to)
    {
        this.brightPassFilterMaterial.SetVector("_Threshhold", new Vector4(thresh, thresh, thresh, thresh));
        Graphics.Blit(from, to, this.brightPassFilterMaterial, 0);
    }

    private void BrightFilter(Color threshColor, RenderTexture from, RenderTexture to)
    {
        this.brightPassFilterMaterial.SetVector("_Threshhold", (Vector4) threshColor);
        Graphics.Blit(from, to, this.brightPassFilterMaterial, 1);
    }

    public override bool CheckResources()
    {
        base.CheckSupport(false);
        this.screenBlend = base.CheckShaderAndCreateMaterial(this.screenBlendShader, this.screenBlend);
        this.lensFlareMaterial = base.CheckShaderAndCreateMaterial(this.lensFlareShader, this.lensFlareMaterial);
        this.blurAndFlaresMaterial = base.CheckShaderAndCreateMaterial(this.blurAndFlaresShader, this.blurAndFlaresMaterial);
        this.brightPassFilterMaterial = base.CheckShaderAndCreateMaterial(this.brightPassFilterShader, this.brightPassFilterMaterial);
        if (!base.isSupported)
        {
            base.ReportAutoDisable();
        }
        return base.isSupported;
    }

    public void OnRenderImage(RenderTexture source, RenderTexture destination)
    {
        if (!this.CheckResources())
        {
            Graphics.Blit(source, destination);
        }
        else
        {
            this.doHdr = false;
            if (this.hdr == HDRBloomMode.Auto)
            {
                this.doHdr = (source.format == RenderTextureFormat.ARGBHalf) && base.camera.hdr;
            }
            else
            {
                this.doHdr = this.hdr == HDRBloomMode.On;
            }
            this.doHdr = this.doHdr && base.supportHDRTextures;
            BloomScreenBlendMode screenBlendMode = this.screenBlendMode;
            if (this.doHdr)
            {
                screenBlendMode = BloomScreenBlendMode.Add;
            }
            RenderTextureFormat format = this.doHdr ? RenderTextureFormat.ARGBHalf : RenderTextureFormat.Default;
            RenderTexture dest = RenderTexture.GetTemporary(source.width / 2, source.height / 2, 0, format);
            RenderTexture texture2 = RenderTexture.GetTemporary(source.width / 4, source.height / 4, 0, format);
            RenderTexture texture3 = RenderTexture.GetTemporary(source.width / 4, source.height / 4, 0, format);
            RenderTexture texture4 = RenderTexture.GetTemporary(source.width / 4, source.height / 4, 0, format);
            float num = (1f * source.width) / (1f * source.height);
            float num2 = 0.001953125f;
            this.screenBlend.SetFloat("_ChromaticBloom", 0f);
            this.screenBlend.SetFloat("_ChromaticBloomThresh", 1f);
            if (this.quality > BloomQuality.Cheap)
            {
                Graphics.Blit(source, dest, this.screenBlend, 2);
                Graphics.Blit(dest, texture3, this.screenBlend, 2);
                Graphics.Blit(texture3, texture2, this.screenBlend, 6);
            }
            else
            {
                Graphics.Blit(source, dest);
                Graphics.Blit(dest, texture2, this.screenBlend, 6);
            }
            this.BrightFilter((Color) (this.bloomThreshhold * this.bloomThreshholdColor), texture2, texture3);
            if (this.bloomBlurIterations < 1)
            {
                this.bloomBlurIterations = 1;
            }
            else if (this.bloomBlurIterations > 10)
            {
                this.bloomBlurIterations = 10;
            }
            int num3 = 0;
            while (num3 < this.bloomBlurIterations)
            {
                float num4 = (1f + (num3 * 0.25f)) * this.sepBlurSpread;
                this.blurAndFlaresMaterial.SetVector("_Offsets", new Vector4(0f, num4 * num2, 0f, 0f));
                Graphics.Blit(texture3, texture4, this.blurAndFlaresMaterial, 4);
                if (this.quality > BloomQuality.Cheap)
                {
                    this.blurAndFlaresMaterial.SetVector("_Offsets", new Vector4((num4 / num) * num2, 0f, 0f, 0f));
                    Graphics.Blit(texture4, texture3, this.blurAndFlaresMaterial, 4);
                    if (num3 == 0)
                    {
                        Graphics.Blit(texture3, texture2);
                    }
                    else
                    {
                        Graphics.Blit(texture3, texture2, this.screenBlend, 10);
                    }
                }
                else
                {
                    this.blurAndFlaresMaterial.SetVector("_Offsets", new Vector4((num4 / num) * num2, 0f, 0f, 0f));
                    Graphics.Blit(texture4, texture3, this.blurAndFlaresMaterial, 4);
                }
                num3++;
            }
            if (this.quality > BloomQuality.Cheap)
            {
                Graphics.Blit(texture2, texture3, this.screenBlend, 6);
            }
            if (this.lensflareIntensity > float.Epsilon)
            {
                if (this.lensflareMode == LensFlareStyle.Ghosting)
                {
                    this.BrightFilter(this.lensflareThreshhold, texture3, texture4);
                    if (this.quality > BloomQuality.Cheap)
                    {
                        this.blurAndFlaresMaterial.SetVector("_Offsets", new Vector4(0f, 1.5f / (1f * texture2.height), 0f, 0f));
                        Graphics.Blit(texture4, texture2, this.blurAndFlaresMaterial, 4);
                        this.blurAndFlaresMaterial.SetVector("_Offsets", new Vector4(1.5f / (1f * texture2.width), 0f, 0f, 0f));
                        Graphics.Blit(texture2, texture4, this.blurAndFlaresMaterial, 4);
                    }
                    this.Vignette(0.975f, texture4, texture4);
                    this.BlendFlares(texture4, texture3);
                }
                else
                {
                    float x = 1f * Mathf.Cos(this.flareRotation);
                    float y = 1f * Mathf.Sin(this.flareRotation);
                    float num7 = ((this.hollyStretchWidth * 1f) / num) * num2;
                    float num8 = this.hollyStretchWidth * num2;
                    this.blurAndFlaresMaterial.SetVector("_Offsets", new Vector4(x, y, 0f, 0f));
                    this.blurAndFlaresMaterial.SetVector("_Threshhold", new Vector4(this.lensflareThreshhold, 1f, 0f, 0f));
                    this.blurAndFlaresMaterial.SetVector("_TintColor", (Vector4) ((new Vector4(this.flareColorA.r, this.flareColorA.g, this.flareColorA.b, this.flareColorA.a) * this.flareColorA.a) * this.lensflareIntensity));
                    this.blurAndFlaresMaterial.SetFloat("_Saturation", this.lensFlareSaturation);
                    Graphics.Blit(texture4, texture2, this.blurAndFlaresMaterial, 2);
                    Graphics.Blit(texture2, texture4, this.blurAndFlaresMaterial, 3);
                    this.blurAndFlaresMaterial.SetVector("_Offsets", new Vector4(x * num7, y * num7, 0f, 0f));
                    this.blurAndFlaresMaterial.SetFloat("_StretchWidth", this.hollyStretchWidth);
                    Graphics.Blit(texture4, texture2, this.blurAndFlaresMaterial, 1);
                    this.blurAndFlaresMaterial.SetFloat("_StretchWidth", this.hollyStretchWidth * 2f);
                    Graphics.Blit(texture2, texture4, this.blurAndFlaresMaterial, 1);
                    this.blurAndFlaresMaterial.SetFloat("_StretchWidth", this.hollyStretchWidth * 4f);
                    Graphics.Blit(texture4, texture2, this.blurAndFlaresMaterial, 1);
                    for (num3 = 0; num3 < this.hollywoodFlareBlurIterations; num3++)
                    {
                        num7 = ((this.hollyStretchWidth * 2f) / num) * num2;
                        this.blurAndFlaresMaterial.SetVector("_Offsets", new Vector4(num7 * x, num7 * y, 0f, 0f));
                        Graphics.Blit(texture2, texture4, this.blurAndFlaresMaterial, 4);
                        this.blurAndFlaresMaterial.SetVector("_Offsets", new Vector4(num7 * x, num7 * y, 0f, 0f));
                        Graphics.Blit(texture4, texture2, this.blurAndFlaresMaterial, 4);
                    }
                    if (this.lensflareMode == LensFlareStyle.Anamorphic)
                    {
                        this.AddTo(1f, texture2, texture3);
                    }
                    else
                    {
                        this.Vignette(1f, texture2, texture4);
                        this.BlendFlares(texture4, texture2);
                        this.AddTo(1f, texture2, texture3);
                    }
                }
            }
            BloomScreenBlendMode mode2 = screenBlendMode;
            if (Mathf.Abs(this.chromaticBloom) < float.Epsilon)
            {
                mode2 += 4;
            }
            this.screenBlend.SetFloat("_Intensity", this.bloomIntensity);
            this.screenBlend.SetTexture("_ColorBuffer", source);
            this.screenBlend.SetFloat("_ChromaticBloom", this.chromaticBloom);
            this.screenBlend.SetFloat("_ChromaticBloomThresh", this.bloomThreshhold * (((this.bloomThreshholdColor.r * 0.3f) + (this.bloomThreshholdColor.g * 0.59f)) + (this.bloomThreshholdColor.b * 0.11f)));
            if (this.quality > BloomQuality.Cheap)
            {
                Graphics.Blit(texture3, dest);
                Graphics.Blit(dest, destination, this.screenBlend, (int) mode2);
            }
            else
            {
                Graphics.Blit(texture3, destination, this.screenBlend, (int) mode2);
            }
            RenderTexture.ReleaseTemporary(dest);
            RenderTexture.ReleaseTemporary(texture2);
            RenderTexture.ReleaseTemporary(texture3);
            RenderTexture.ReleaseTemporary(texture4);
        }
    }

    private void Vignette(float amount, RenderTexture from, RenderTexture to)
    {
        if (this.lensFlareVignetteMask != 0)
        {
            this.screenBlend.SetTexture("_ColorBuffer", this.lensFlareVignetteMask);
            Graphics.Blit((from == to) ? null : from, to, this.screenBlend, (from == to) ? 7 : 3);
        }
        else if (from != to)
        {
            Graphics.Blit(from, to);
        }
    }

    public enum BloomQuality
    {
        Cheap,
        High
    }

    public enum BloomScreenBlendMode
    {
        Screen,
        Add
    }

    public enum HDRBloomMode
    {
        Auto,
        On,
        Off
    }

    public enum LensFlareStyle
    {
        Ghosting,
        Anamorphic,
        Combined
    }

    public enum TweakMode
    {
        Basic,
        Complex
    }
}

