﻿using System;
using System.Linq;

public class SimpleMovingAverage
{
    private float _average;
    private float[] circularBuffer;
    private int index;

    public SimpleMovingAverage(int numSamples)
    {
        this.circularBuffer = new float[numSamples];
        this.index = 0;
    }

    public void SetAll(float value)
    {
        for (int i = 0; i < this.circularBuffer.Length; i++)
        {
            this.circularBuffer[i] = value;
        }
        this._average = value;
    }

    public void Update(float newValue)
    {
        this.circularBuffer[this.index] = newValue;
        this.index = (this.index + 1) % this.circularBuffer.Length;
        this._average = this.circularBuffer.Sum() / ((float) this.circularBuffer.Length);
    }

    public float Average
    {
        get
        {
            if ((this._average > -0.1f) && (this._average < 0.1f))
            {
                return 0f;
            }
            return this._average;
        }
        private set
        {
            this._average = value;
        }
    }
}

