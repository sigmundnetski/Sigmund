﻿using GNGUI;
using System;
using UnityEngine;

public abstract class SlotGui : MonoBehaviour
{
    protected static Color dontShowColor = new Color(1f, 1f, 1f, 0f);
    protected static Color doShowColor = Color.white;
    protected UIDragObject dragScript;
    public UISprite highlight;
    public UISprite icon;
    protected bool isBeingDragged = false;
    protected bool showingTooltip = false;

    protected SlotGui()
    {
    }

    public void Awake()
    {
        foreach (UISprite sprite in base.GetComponentsInChildren<UISprite>())
        {
            if (sprite.name == "Icon")
            {
                this.icon = sprite;
            }
            else if (sprite.name == "Highlight")
            {
                this.highlight = sprite;
            }
        }
        this.dragScript = base.GetComponentInChildren<UIDragObject>();
        GuiHelper.GuiAssertNotNull("Couldn't find needed children.", new object[] { this.icon, this.highlight, this.dragScript });
        this.dragScript.dragEffect = UIDragObject.DragEffect.None;
        this.dragScript.target = this.icon.transform;
        this.ResetValidity();
        this.ResetIcon();
    }

    protected void ResetIcon()
    {
        this.icon.color = dontShowColor;
    }

    public void ResetValidity()
    {
        this.highlight.color = dontShowColor;
    }

    protected abstract void SetIcon();
    protected void SetValidity(bool valid)
    {
        if (valid)
        {
            this.highlight.color = doShowColor;
        }
        else
        {
            this.highlight.color = dontShowColor;
        }
    }
}

