﻿using System;
using System.Text;
using UnityEngine;

public class EquipmentSlotGui : SlotGui
{
    public BasicItemData equippedItem;
    public InventoryItem equippedItemInfo = InventoryItem.EMPTY;
    public BasicItemData.ItemSlot slot;

    public void Assign(BasicItemData.ItemSlot slot_)
    {
        this.slot = slot_;
        this.equippedItem = null;
    }

    public void EquipItem(InventoryItem item)
    {
        this.equippedItemInfo = item;
        this.equippedItem = ItemDatabase.GetItem(item.staticItemId);
        this.SetIcon();
        if (BasicItemData.SlotAccepts(this.slot, BasicItemData.ItemSlot.WONDROUS))
        {
            ButtonBarGui.singleton.SetAllButtons(CombatClient.playerCombatVars);
        }
    }

    public bool IsValid(int[] slotFilters)
    {
        bool flag = false;
        if (slotFilters != null)
        {
            for (int i = 0; i < slotFilters.Length; i++)
            {
                flag = flag || BasicItemData.SlotAccepts(this.slot, (BasicItemData.ItemSlot) ((byte) slotFilters[i]));
            }
        }
        return flag;
    }

    public void OnDrag(Vector2 delta)
    {
        if ((this.equippedItem != null) && !base.isBeingDragged)
        {
            base.isBeingDragged = true;
            PaperdollWindowGui.singleton.DragStart(this.equippedItemInfo);
            InventoryItemRClick.singleton.HideWindow();
            base.dragScript.target = base.icon.transform;
        }
    }

    public void OnDrop(GameObject draggedObject)
    {
        InventoryItemGui component = draggedObject.GetComponent<InventoryItemGui>();
        EquipmentSlotGui gui2 = draggedObject.GetComponent<EquipmentSlotGui>();
        InventoryItem eMPTY = InventoryItem.EMPTY;
        BasicItemData item = null;
        BasicItemData.ItemSlot nONE = BasicItemData.ItemSlot.NONE;
        if ((component != null) || (gui2 != null))
        {
            if (component != null)
            {
                eMPTY = component.item;
                item = ItemDatabase.GetItem(eMPTY.staticItemId);
            }
            else if (gui2 != null)
            {
                eMPTY = gui2.equippedItemInfo;
                if (eMPTY.staticItemId == 0)
                {
                    return;
                }
                item = ItemDatabase.GetItem(eMPTY.staticItemId);
                nONE = gui2.slot;
                if (!BasicItemData.SlotAccepts(this.slot, item.slot))
                {
                    gui2.SetIcon();
                }
            }
            if (BasicItemData.SlotAccepts(this.slot, item.slot))
            {
                PaperdollWindowGui.singleton.EquipmentSlotChange(nONE, this.slot, this.equippedItemInfo, eMPTY);
            }
        }
    }

    public void OnPress(bool isPressed)
    {
        if (!(isPressed || !base.isBeingDragged))
        {
            base.isBeingDragged = false;
            base.icon.gameObject.transform.localPosition = Vector3.zero;
            PaperdollWindowGui.singleton.DragEnd(this.equippedItemInfo, this.slot);
        }
    }

    public void OnTooltip(bool show)
    {
        base.showingTooltip = show;
        if (!((this.equippedItem != null) && show))
        {
            PaperdollWindowGui.singleton.ShowTooltip(null, null);
        }
        else
        {
            InventoryItem item = EntityDataClient.owner.playerRecord.bodySlots[(int) this.slot];
            StringBuilder quickText = GUtil.GetQuickText();
            InventoryClient.GetColoredItemDisplayName(ref quickText, item);
            quickText.Append("\n");
            quickText.Append(this.equippedItem.description);
            PaperdollWindowGui.singleton.ShowTooltip(quickText.ToString(), base.gameObject);
        }
    }

    protected override void SetIcon()
    {
        GuiHelper.SetItemIcon(base.icon, this.equippedItemInfo, this.equippedItem);
        base.icon.color = SlotGui.doShowColor;
    }

    public void SetValidity(int[] slotFilters)
    {
        base.SetValidity(this.IsValid(slotFilters));
    }

    public void SetValidity(BasicItemData.ItemSlot itemType)
    {
        base.SetValidity(BasicItemData.SlotAccepts(this.slot, itemType));
    }

    public void UnequipItem()
    {
        this.equippedItemInfo = InventoryItem.EMPTY;
        this.equippedItem = null;
        base.ResetIcon();
        if (BasicItemData.SlotAccepts(this.slot, BasicItemData.ItemSlot.WONDROUS))
        {
            ButtonBarGui.singleton.SetAllButtons(CombatClient.playerCombatVars);
        }
    }
}

