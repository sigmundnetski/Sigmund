﻿using GNGUI;
using System;
using System.Collections.Generic;
using UnityEngine;

public class ChatContextGui : ContextWindowGui
{
    private UISprite background;
    private UIGrid channelGrid;
    private GameObject channelItemPrefab;
    private List<ChannelGridItem> channelItems = new List<ChannelGridItem>();
    private const string CURRENTLY_IN = " is in these channels:";
    private UILabel currentlyInDescLabel;
    private UIInput joinChannel;
    private const string NO_CHANNELS = " is current in no channels.";
    public static ChatContextGui singleton;
    private UILabel title;

    public void Awake()
    {
        singleton = this;
    }

    public override void Invoke(int referenceId)
    {
        if (referenceId != base.currentReferenceId)
        {
            this.SetInfo(ChatGui.singleton.GetTab(referenceId));
        }
        base.Invoke(referenceId);
    }

    public bool LoadingTickFinished()
    {
        this.channelItemPrefab = UIClient.guiPrefabs["ChannelGridItem"];
        GuiHelper.GuiAssertNotNull("Could not find prefab.", new object[] { this.channelItemPrefab });
        return true;
    }

    public override void OnDestroy()
    {
        base.OnDestroy();
        singleton = null;
    }

    public void OnSubmit(string input)
    {
        ChatGui.singleton.GetTab(base.currentReferenceId).AddDesiredChannel(input);
        CommandCore.ExecuteCommand("JoinChannel " + input, PlayerEntityClient.GetPlayerEntityId());
        this.joinChannel.text = this.joinChannel.defaultText;
    }

    private void SetInfo(ChatTabGui chatTab)
    {
        this.title.text = chatTab.TabName;
        if (chatTab.ChannelIds.Length == 0)
        {
            this.currentlyInDescLabel.text = chatTab.TabName + " is current in no channels.";
        }
        else
        {
            this.currentlyInDescLabel.text = chatTab.TabName + " is in these channels:";
        }
        int num = 0;
        for (int i = 0; i < chatTab.ChannelIds.Length; i++)
        {
            if ((chatTab.ChannelIds[i] != -1) && (chatTab.ChannelIds[i] != -2))
            {
                if (num >= this.channelItems.Count)
                {
                    ChannelGridItem component = NGUITools.AddChild(this.channelGrid.gameObject, this.channelItemPrefab).GetComponent<ChannelGridItem>();
                    this.channelItems.Add(component);
                }
                string displayName = ChatGui.singleton.GetDisplayName(chatTab.ChannelIds[i]);
                this.channelItems[num].Init(displayName, displayName == chatTab.ActiveChannel);
                num++;
            }
        }
        while (this.channelItems.Count > num)
        {
            ChannelGridItem item2 = this.channelItems[this.channelItems.Count - 1];
            this.channelItems.RemoveAt(this.channelItems.Count - 1);
            item2.gameObject.SetActive(false);
            item2.transform.parent = DragDropRoot.root;
            UnityEngine.Object.Destroy(item2.gameObject);
        }
        this.channelGrid.repositionNow = true;
    }

    public override void Start()
    {
        ClientTick.chatCtxLoadFinish = new GUtil.BoolFilterDelegate(this.LoadingTickFinished);
        base.currentReferenceId = -1;
        foreach (UISprite sprite in base.GetComponentsInChildren<UISprite>())
        {
            if (sprite.name == "MenuBackground")
            {
                this.background = sprite;
            }
        }
        this.channelGrid = base.GetComponentInChildren<UIGrid>();
        this.joinChannel = base.GetComponentInChildren<UIInput>();
        foreach (UILabel label in base.GetComponentsInChildren<UILabel>())
        {
            if (label.name == "Title")
            {
                this.title = label;
            }
            else if (label.name == "CurrentLabel")
            {
                this.currentlyInDescLabel = label;
            }
        }
        GuiHelper.GuiAssertNotNull("Could not find needed childern.", new object[] { this.background, this.channelGrid, this.joinChannel, this.title, this.currentlyInDescLabel });
        this.joinChannel.onSubmit = new GNGUI.UIInput.OnSubmit(this.OnSubmit);
        base.Start();
    }

    public override void UpdateContents(int referenceId)
    {
        this.SetInfo(ChatGui.singleton.GetTab(referenceId));
    }
}

