﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using UnityEngine;

public static class MergeJobService
{
    private static MergeJob currentJob = null;
    private static Queue<Texture2D> dxt1Textures = new Queue<Texture2D>();
    private static Queue<Texture2D> dxt5Textures = new Queue<Texture2D>();
    private static bool isDirect3D = false;
    private static bool isDx11 = false;
    private static List<MergeJob> jobs = new List<MergeJob>();
    private const int MAX_ATLAS_SIZE = 0x800;
    private const int MAX_ATTACH_SIZE = 0x100;
    private static int MAX_MERGED_CHARACTERS = 0;
    private static List<GameObject> mergedObjs = new List<GameObject>();
    private static HashSet<int> queuedIds = new HashSet<int>();
    private static Queue<Texture2D> rgbTextures = new Queue<Texture2D>();
    private static Stopwatch timer = new Stopwatch();
    public static bool useFixedLayout = true;

    static MergeJobService()
    {
        string str = SystemInfo.graphicsDeviceVersion.ToLower();
        isDirect3D = str.Contains("direct3d");
        isDx11 = isDirect3D && str.Contains("11");
        if (isDx11)
        {
            MAX_MERGED_CHARACTERS = 10;
        }
        else
        {
            MAX_MERGED_CHARACTERS = 0;
        }
        ATLAS_SIZE = ((int) 0x800) >> ResourceConsts.MAX_MIP_LEVEL;
    }

    public static void AddJob(MergeJob job)
    {
        if (mergedObjs.Count < MAX_MERGED_CHARACTERS)
        {
            int instanceID = job.Object.GetInstanceID();
            if (queuedIds.Contains(instanceID))
            {
                int index = -1;
                for (int i = 0; i < jobs.Count; i++)
                {
                    if (jobs[i].Object.GetInstanceID() == instanceID)
                    {
                        index = i;
                        break;
                    }
                }
                if (index > -1)
                {
                    jobs.RemoveAt(index);
                }
                queuedIds.Remove(instanceID);
            }
            if ((currentJob != null) && (currentJob.Object == job.Object))
            {
                currentJob.Abandon();
            }
            jobs.Add(job);
            queuedIds.Add(instanceID);
        }
    }

    public static void CacheTexture(Texture2D tex)
    {
        if (tex != null)
        {
            if (!isDirect3D)
            {
                UnityEngine.Object.Destroy(tex);
            }
            else
            {
                switch (tex.format)
                {
                    case TextureFormat.DXT1:
                        if ((tex.width == ATLAS_SIZE) || (tex.height == ATLAS_SIZE))
                        {
                            dxt1Textures.Enqueue(tex);
                            break;
                        }
                        UnityEngine.Object.Destroy(tex);
                        break;

                    case TextureFormat.DXT5:
                        if ((tex.width == ATLAS_SIZE) || (tex.height == ATLAS_SIZE))
                        {
                            dxt5Textures.Enqueue(tex);
                            break;
                        }
                        UnityEngine.Object.Destroy(tex);
                        break;

                    case TextureFormat.RGB24:
                        rgbTextures.Enqueue(tex);
                        break;
                }
            }
        }
    }

    private static void CacheTexture(Material mat, string textureName)
    {
        Texture2D texture = (Texture2D) mat.GetTexture(textureName);
        CacheTexture(texture);
        mat.SetTexture(textureName, null);
    }

    public static void CacheTextures(GameObject obj, bool isDestroying, bool isMerged)
    {
        if (obj != null)
        {
            Transform transform = obj.transform.Find("reserved_mergedSMR");
            if (transform != null)
            {
                SkinnedMeshRenderer component = transform.GetComponent<SkinnedMeshRenderer>();
                if (component != null)
                {
                    if (isDestroying)
                    {
                        UnityEngine.Object.Destroy(component.sharedMesh);
                    }
                    Material[] sharedMaterials = component.sharedMaterials;
                    if (sharedMaterials != null)
                    {
                        int num;
                        if (isMerged && (sharedMaterials[0] != null))
                        {
                            for (num = 0; num < MergeJob.TEX_NAMES.Length; num++)
                            {
                                CacheTexture(sharedMaterials[0], MergeJob.TEX_NAMES[num]);
                            }
                            CacheTexture(sharedMaterials[0], "_ColorPalette");
                        }
                        for (num = 0; num < sharedMaterials.Length; num++)
                        {
                            ResourceManager.ReleaseMaterial(sharedMaterials[num], null);
                        }
                    }
                }
            }
        }
    }

    private static Texture2D CreateTexture(TextureFormat format)
    {
        Texture2D textured = null;
        switch (format)
        {
            case TextureFormat.DXT1:
                if (!isDirect3D)
                {
                    textured = new Texture2D(ATLAS_SIZE, ATLAS_SIZE, TextureFormat.RGB24, true);
                    break;
                }
                textured = new Texture2D(ATLAS_SIZE, ATLAS_SIZE, format, true);
                break;

            case (TextureFormat.DXT1 | TextureFormat.Alpha8):
                return textured;

            case TextureFormat.DXT5:
                if (!isDirect3D)
                {
                    textured = new Texture2D(ATLAS_SIZE, ATLAS_SIZE, TextureFormat.RGBA32, true);
                }
                else
                {
                    textured = new Texture2D(ATLAS_SIZE, ATLAS_SIZE, format, true);
                }
                textured.filterMode = FilterMode.Bilinear;
                textured.wrapMode = TextureWrapMode.Repeat;
                textured.Apply(false, true);
                return textured;

            case TextureFormat.RGB24:
                textured = new Texture2D(0x18, 8, format, false) {
                    filterMode = FilterMode.Point,
                    wrapMode = TextureWrapMode.Repeat
                };
                textured.Apply(false, true);
                return textured;

            default:
                return textured;
        }
        textured.filterMode = FilterMode.Bilinear;
        textured.wrapMode = TextureWrapMode.Repeat;
        textured.Apply(false, true);
        return textured;
    }

    public static bool IsObjectMerged(GameObject obj)
    {
        return mergedObjs.Contains(obj);
    }

    public static void OnObjectDestroyed(GameObject obj, bool isDestroying)
    {
        if (obj != null)
        {
            int instanceID = obj.GetInstanceID();
            bool isMerged = false;
            if (mergedObjs.Contains(obj))
            {
                mergedObjs.Remove(obj);
                isMerged = true;
            }
            else if (!queuedIds.Contains(instanceID))
            {
                if (((currentJob != null) && (currentJob.Object != null)) && (currentJob.Object.GetInstanceID() == instanceID))
                {
                    currentJob.Abandon();
                }
            }
            else
            {
                int index = -1;
                for (int i = 0; i < jobs.Count; i++)
                {
                    if (jobs[i].Object.GetInstanceID() == instanceID)
                    {
                        index = i;
                        break;
                    }
                }
                if (index > -1)
                {
                    jobs.RemoveAt(index);
                }
                queuedIds.Remove(instanceID);
            }
            CacheTextures(obj, isDestroying, isMerged);
        }
    }

    public static MergeJob RequestNewJob(GameObject obj, Dictionary<string, EquipmentAsset> data)
    {
        if (useFixedLayout)
        {
            return new FixedMergeJob(obj, data, ResourceConsts.MAX_MIP_LEVEL);
        }
        return new FlowedMergeJob(obj, data, ResourceConsts.MAX_MIP_LEVEL);
    }

    public static Texture2D RetrieveTexture(TextureFormat format)
    {
        if (!isDirect3D)
        {
            return CreateTexture(format);
        }
        Texture2D textured = null;
        switch (format)
        {
            case TextureFormat.DXT1:
                if (dxt1Textures.Count <= 0)
                {
                    return CreateTexture(format);
                }
                return dxt1Textures.Dequeue();

            case (TextureFormat.DXT1 | TextureFormat.Alpha8):
                return textured;

            case TextureFormat.DXT5:
                if (dxt5Textures.Count <= 0)
                {
                    return CreateTexture(format);
                }
                return dxt5Textures.Dequeue();

            case TextureFormat.RGB24:
                if (rgbTextures.Count > 0)
                {
                    textured = rgbTextures.Dequeue();
                }
                else
                {
                    textured = CreateTexture(format);
                }
                return textured;
        }
        return textured;
    }

    private static void SyncStart()
    {
        if (isDx11)
        {
            for (int i = 0; i < 10; i++)
            {
                dxt1Textures.Enqueue(CreateTexture(TextureFormat.DXT1));
                dxt1Textures.Enqueue(CreateTexture(TextureFormat.DXT1));
                dxt1Textures.Enqueue(CreateTexture(TextureFormat.DXT1));
                dxt5Textures.Enqueue(CreateTexture(TextureFormat.DXT5));
                rgbTextures.Enqueue(CreateTexture(TextureFormat.RGB24));
            }
        }
    }

    public static bool SyncUpdate()
    {
        if (currentJob != null)
        {
            MergeJob.Status invalid = MergeJob.Status.Invalid;
            try
            {
                invalid = currentJob.Process();
            }
            catch (Exception exception)
            {
                GLog.LogError(new object[] { "There was a problem executing MergeJob for " + currentJob.Object.name + "\nThis generally indicates there is a problem with at least one of its assets.\n" + exception.ToString() });
                invalid = MergeJob.Status.InProgress;
                currentJob.Abandon();
            }
            if (invalid == MergeJob.Status.Completed)
            {
                mergedObjs.Add(currentJob.Object);
            }
            if (invalid != MergeJob.Status.InProgress)
            {
                currentJob = null;
            }
        }
        if (((currentJob == null) && (jobs.Count > 0)) && (mergedObjs.Count < MAX_MERGED_CHARACTERS))
        {
            MergeJob item = jobs[0];
            jobs.RemoveAt(0);
            bool flag = true;
            for (int i = 0; i < item.NumMaterials(); i++)
            {
                if (!ResourceManager.IsMaterialUpgraded(item.GetMaterial(i), ResourceConsts.MAX_MIP_LEVEL))
                {
                    flag = false;
                    break;
                }
            }
            if (flag)
            {
                currentJob = item;
                queuedIds.Remove(currentJob.Object.GetInstanceID());
            }
            else
            {
                jobs.Add(item);
            }
        }
        return true;
    }

    public static void ToggleFixedLayout(string[] args, EntityId playerEntityId)
    {
        useFixedLayout = !useFixedLayout;
        ChatGui.singleton.DisplayMessage("Character mesh merging now using " + (useFixedLayout ? "a fixed layout." : "a flowed layout."), ChatClient.DEFAULT_COLOR);
    }

    public static int ATLAS_SIZE
    {
        [CompilerGenerated]
        get
        {
            return <ATLAS_SIZE>k__BackingField;
        }
        [CompilerGenerated]
        private set
        {
            <ATLAS_SIZE>k__BackingField = value;
        }
    }

    private class FixedMergeJob : MergeJobService.MergeJob
    {
        private int attachIndex;
        private int attachX;
        private int attachY;
        private int destIndex;

        public FixedMergeJob(GameObject obj, Dictionary<string, EquipmentAsset> data, int _atlas_size) : base(obj, data, _atlas_size)
        {
            this.destIndex = 0;
            this.attachX = (int) MergeJobService.MergeJob.ATLAS_OFFSETS[9].xMin;
            this.attachY = (int) MergeJobService.MergeJob.ATLAS_OFFSETS[9].yMin;
            this.attachIndex = 9;
        }

        protected override void ProcessMaterials(int index)
        {
            Material material = base.materials[index];
            string item = material.name.ToLower();
            if (!base.processedMaterials.Contains(item))
            {
                SkinnedMeshRenderer renderer = base.atlasedSmrs[base.atlasedMaterialIndices[index]];
                GameObject gameObject = renderer.gameObject;
                int width = 0;
                int height = 0;
                MergeJobService.MergeJob.ATLAS_SLOTS atlas_slots = MergeJobService.MergeJob.FindSlotForAsset(gameObject);
                if (atlas_slots != MergeJobService.MergeJob.ATLAS_SLOTS.INVALID)
                {
                    int num4;
                    Rect rect;
                    int attachIndex = (int) atlas_slots;
                    bool flag = false;
                    if (atlas_slots == MergeJobService.MergeJob.ATLAS_SLOTS.suitAttach)
                    {
                        flag = true;
                        attachIndex = this.attachIndex;
                    }
                    for (num4 = 0; num4 < MergeJobService.MergeJob.TEX_NAMES.Length; num4++)
                    {
                        Texture texture = material.GetTexture(MergeJobService.MergeJob.TEX_NAMES[num4]);
                        base.inputTextures[num4][this.destIndex] = texture;
                        if ((texture != null) && ((width == 0) || (height == 0)))
                        {
                            width = texture.width;
                            height = texture.height;
                        }
                    }
                    if (base.cubeTexture == null)
                    {
                        base.cubeTexture = (Cubemap) material.GetTexture("_Cube");
                    }
                    for (num4 = 0; num4 < MergeJobService.MergeJob.COLOR_NAMES.Length; num4++)
                    {
                        base.colors[(this.destIndex * MergeJobService.MergeJob.COLOR_NAMES.Length) + num4] = material.GetColor(MergeJobService.MergeJob.COLOR_NAMES[num4]);
                    }
                    if (flag)
                    {
                        rect = new Rect((float) this.attachX, (float) this.attachY, 256f, 256f);
                        if ((this.attachX + 0x100) >= 0x800)
                        {
                            this.attachX = (int) MergeJobService.MergeJob.ATLAS_OFFSETS[9].xMin;
                            this.attachY -= 0x100;
                        }
                        else
                        {
                            this.attachX += 0x100;
                        }
                        this.attachIndex++;
                    }
                    else
                    {
                        rect = MergeJobService.MergeJob.ATLAS_OFFSETS[attachIndex];
                    }
                    base.offsets[this.destIndex] = new GW_RECT((ushort) rect.xMin, (ushort) rect.yMin, (ushort) rect.width, (ushort) rect.height);
                    base.materialNameToOffset[item] = new Rect((float) (((int) rect.xMin) >> base.targetMipLevel), (float) (((int) rect.yMin) >> base.targetMipLevel), (float) (((int) rect.width) >> base.targetMipLevel), (float) (((int) rect.height) >> base.targetMipLevel));
                    base.processedMaterials.Add(item);
                    this.destIndex++;
                }
            }
        }
    }

    private class FlowedMergeJob : MergeJobService.MergeJob
    {
        private Stack<Rect> currRow;
        private int destIndex;
        private List<int> materialHeights;
        private List<int> materialWidths;
        private int offsetX;
        private int offsetY;

        public FlowedMergeJob(GameObject obj, Dictionary<string, EquipmentAsset> data, int _atlas_size) : base(obj, data, _atlas_size)
        {
            this.currRow = new Stack<Rect>();
            this.offsetX = 0;
            this.offsetY = 0;
            this.destIndex = 0;
            this.materialWidths = new List<int>();
            this.materialHeights = new List<int>();
        }

        protected override void ProcessMaterials(int index)
        {
            if (this.offsetY < 0x800)
            {
                Material material = base.materials[index];
                string item = material.name.ToLower();
                if (!base.processedMaterials.Contains(item))
                {
                    int num;
                    for (num = 0; num < MergeJobService.MergeJob.TEX_NAMES.Length; num++)
                    {
                        Texture texture = material.GetTexture(MergeJobService.MergeJob.TEX_NAMES[num]);
                        base.inputTextures[num][this.destIndex] = texture;
                    }
                    if (base.cubeTexture == null)
                    {
                        base.cubeTexture = (Cubemap) material.GetTexture("_Cube");
                    }
                    int num2 = this.destIndex * MergeJobService.MergeJob.COLOR_NAMES.Length;
                    for (num = 0; num < MergeJobService.MergeJob.COLOR_NAMES.Length; num++)
                    {
                        base.colors[num2 + num] = material.GetColor(MergeJobService.MergeJob.COLOR_NAMES[num]);
                    }
                    Rect rect = new Rect((float) this.offsetX, (float) this.offsetY, (float) this.materialWidths[index], (float) this.materialHeights[index]);
                    base.offsets[this.destIndex] = new GW_RECT((ushort) rect.xMin, (ushort) rect.yMin, (ushort) this.materialWidths[index], (ushort) this.materialHeights[index]);
                    base.materialNameToOffset[item] = new Rect((float) (((int) rect.xMin) >> base.targetMipLevel), (float) (((int) rect.yMin) >> base.targetMipLevel), (float) (((int) rect.width) >> base.targetMipLevel), (float) (((int) rect.height) >> base.targetMipLevel));
                    if ((this.offsetX + this.materialWidths[index]) >= 0x800)
                    {
                        Rect rect2 = this.currRow.Peek();
                        while ((rect2.yMax == (this.offsetY + this.materialHeights[index])) && (this.currRow.Count > 0))
                        {
                            this.currRow.Pop();
                            if (this.currRow.Count > 0)
                            {
                                rect2 = this.currRow.Peek();
                            }
                        }
                        if (this.currRow.Count == 0)
                        {
                            this.offsetX = 0;
                            this.currRow.Clear();
                        }
                        else
                        {
                            this.offsetX = (int) rect2.xMax;
                        }
                        this.offsetY += this.materialHeights[index];
                    }
                    else
                    {
                        this.offsetX += this.materialWidths[index];
                        this.currRow.Push(rect);
                    }
                    base.processedMaterials.Add(item);
                    this.destIndex++;
                }
            }
        }

        protected override void ProcessSmr(int index)
        {
            Material item = base.newSmr.sharedMaterials[index];
            base.materials.Add(item);
            Texture mainTexture = item.mainTexture;
            this.materialWidths.Add(mainTexture.width);
            this.materialHeights.Add(mainTexture.height);
        }

        protected override void SortMaterials()
        {
            int num;
            Material material;
            int num2;
            int num3;
            int num4;
            for (num = 1; num < base.materials.Count; num++)
            {
                material = base.materials[num];
                num2 = this.materialWidths[num];
                num3 = this.materialHeights[num];
                num4 = num;
                while ((num4 > 0) && (this.materialHeights[num4 - 1] < num3))
                {
                    base.materials[num4] = base.materials[num4 - 1];
                    this.materialWidths[num4] = this.materialWidths[num4 - 1];
                    this.materialHeights[num4] = this.materialHeights[num4 - 1];
                    num4--;
                }
                base.materials[num4] = material;
                this.materialWidths[num4] = num2;
                this.materialHeights[num4] = num3;
            }
            for (num = 1; num < base.materials.Count; num++)
            {
                material = base.materials[num];
                num2 = this.materialWidths[num];
                num3 = this.materialHeights[num];
                num4 = num;
                while ((num4 > 0) && (this.materialWidths[num4 - 1] < num2))
                {
                    base.materials[num4] = base.materials[num4 - 1];
                    this.materialWidths[num4] = this.materialWidths[num4 - 1];
                    this.materialHeights[num4] = this.materialHeights[num4 - 1];
                    num4--;
                }
                base.materials[num4] = material;
                this.materialWidths[num4] = num2;
                this.materialHeights[num4] = num3;
            }
        }
    }

    public abstract class MergeJob
    {
        protected List<SkinnedMeshRenderer> allSmrs;
        public static readonly Rect[] ATLAS_OFFSETS = new Rect[] { new Rect(0f, 1024f, 512f, 1024f), new Rect(512f, 1536f, 512f, 512f), new Rect(512f, 1024f, 512f, 512f), new Rect(0f, 0f, 1024f, 1024f), new Rect(1024f, 1024f, 1024f, 1024f), new Rect(1024f, 0f, 256f, 256f), new Rect(1280f, 0f, 256f, 256f), new Rect(1536f, 0f, 256f, 256f), new Rect(1792f, 0f, 256f, 256f), new Rect(1024f, 768f, 1024f, 768f) };
        protected int atlasedMaterialCount;
        protected List<int> atlasedMaterialIndices;
        protected List<SkinnedMeshRenderer> atlasedSmrs;
        private Vector2[] atlasUvs;
        public const string CLRS_TEX = "_ColorPalette";
        protected Texture2D clrsTexture;
        protected static readonly string[] COLOR_NAMES = new string[] { "_MatColor", "_UserColor1", "_UserColor2" };
        protected Dictionary<string, EquipmentAsset> colorData;
        protected Color[] colors;
        public const int COLORS_PER_OFFSET = 3;
        public const string CUBE_TEX = "_Cube";
        protected Cubemap cubeTexture;
        private int currentIndex;
        private Stage currentStage;
        private Status currentStatus = Status.Initialized;
        protected IntPtr[] inputTexturePtrs;
        protected Texture[][] inputTextures;
        protected Dictionary<string, Rect> materialNameToOffset;
        protected List<Material> materials;
        public const string MERGED_CHILD_NAME = "reserved_mergedSMR";
        private static Material mergedMaterial = null;
        protected SkinnedMeshRenderer newSmr;
        private int numBones;
        private int numSubMeshes;
        private int numVerts;
        private GameObject obj;
        protected GW_RECT[] offsets;
        private Material[] outputMaterials;
        protected Texture2D[] outputTextures;
        public const int PALETTE_HEIGHT = 8;
        public const int PALETTE_WIDTH = 0x18;
        protected HashSet<string> processedMaterials;
        private Transform rootBone;
        protected readonly int targetMipLevel;
        public static readonly string[] TEX_NAMES = new string[] { "_MainTex", "_BumpMap", "_Spec_Gloss_Reflec_Masks", "_ControlMap" };
        protected static readonly TextureFormat[] textureFormats = new TextureFormat[] { TextureFormat.DXT1, TextureFormat.DXT5, TextureFormat.DXT1, TextureFormat.DXT1 };
        protected List<SkinnedMeshRenderer> unatlasedSmrs;
        private int uvIndex;

        static MergeJob()
        {
            mergedMaterial = BundleService.Load<Material>(BundleConsts.CHARACTER_BUNDLE, "reserved_mergedSMR");
        }

        protected MergeJob(GameObject _obj, Dictionary<string, EquipmentAsset> data, int _targetMipLevel)
        {
            this.obj = _obj;
            this.numBones = 0;
            this.numVerts = 0;
            this.numSubMeshes = 0;
            this.atlasedMaterialCount = -1;
            this.colorData = data;
            this.allSmrs = new List<SkinnedMeshRenderer>();
            this.atlasedSmrs = new List<SkinnedMeshRenderer>();
            this.unatlasedSmrs = new List<SkinnedMeshRenderer>();
            foreach (SkinnedMeshRenderer renderer in this.obj.GetComponentsInChildren<SkinnedMeshRenderer>())
            {
                if (renderer.enabled && (renderer.name != "reserved_mergedSMR"))
                {
                    string str;
                    AssetMetadata component = renderer.GetComponent<AssetMetadata>();
                    if (((component != null) && component.TryGetData("slotID", out str)) && IsSlotAtlasable(str))
                    {
                        this.atlasedSmrs.Add(renderer);
                    }
                    else
                    {
                        this.unatlasedSmrs.Add(renderer);
                    }
                    this.numBones += renderer.bones.Length * renderer.sharedMesh.subMeshCount;
                    this.numVerts += renderer.sharedMesh.vertexCount;
                    this.numSubMeshes += renderer.sharedMesh.subMeshCount;
                }
            }
            if ((this.atlasedSmrs.Count + this.unatlasedSmrs.Count) == 0)
            {
                this.currentStatus = Status.Invalid;
            }
            else
            {
                this.allSmrs.AddRange(this.atlasedSmrs);
                this.allSmrs.AddRange(this.unatlasedSmrs);
                this.targetMipLevel = _targetMipLevel;
                this.currentIndex = 0;
                this.processedMaterials = new HashSet<string>();
                this.materials = new List<Material>();
                this.materialNameToOffset = new Dictionary<string, Rect>();
                this.outputTextures = new Texture2D[TEX_NAMES.Length];
                this.cubeTexture = null;
                GameObject target = null;
                Transform transform = this.obj.transform.Find("reserved_mergedSMR");
                if (transform != null)
                {
                    target = transform.gameObject;
                }
                if (target == null)
                {
                    target = new GameObject("reserved_mergedSMR");
                    UnityEngine.Object.DontDestroyOnLoad(target);
                    target.transform.parent = this.obj.transform;
                    target.transform.localPosition = Vector3.zero;
                    target.transform.localRotation = Quaternion.identity;
                }
                this.newSmr = target.GetComponent<SkinnedMeshRenderer>();
                if (this.newSmr == null)
                {
                    this.newSmr = target.AddComponent<SkinnedMeshRenderer>();
                }
                if (this.newSmr.sharedMesh == null)
                {
                    this.newSmr.sharedMesh = new Mesh();
                }
                this.currentStatus = Status.InProgress;
            }
        }

        public void Abandon()
        {
            this.obj = null;
        }

        protected void CleanupInProgress()
        {
            int num;
            if (this.outputTextures != null)
            {
                for (num = 0; num < TEX_NAMES.Length; num++)
                {
                    MergeJobService.CacheTexture(this.outputTextures[num]);
                }
            }
            MergeJobService.CacheTexture(this.clrsTexture);
            if (this.outputMaterials != null)
            {
                for (num = 0; num < this.outputMaterials.Length; num++)
                {
                    ResourceManager.ReleaseMaterial(this.outputMaterials[num], null);
                }
            }
        }

        private void ConfigureMaterials()
        {
            Material[] sharedMaterials = this.newSmr.sharedMaterials;
            int atlasedMaterialCount = this.atlasedMaterialCount;
            int num2 = sharedMaterials.Length - this.atlasedMaterialCount;
            this.outputMaterials = new Material[num2 + 1];
            this.outputMaterials[0] = (Material) UnityEngine.Object.Instantiate(mergedMaterial);
            for (int i = 0; i < num2; i++)
            {
                this.outputMaterials[i + 1] = sharedMaterials[atlasedMaterialCount + i];
            }
        }

        private void ConfigureTargetSmr()
        {
            int num2;
            int num = 0;
            for (num2 = 0; num2 < this.unatlasedSmrs.Count; num2++)
            {
                num += this.unatlasedSmrs[num2].sharedMesh.triangles.Length;
            }
            int[] triangles = this.newSmr.sharedMesh.triangles;
            int[] destinationArray = new int[triangles.Length - num];
            int num3 = 0;
            Array.Copy(triangles, 0, destinationArray, 0, destinationArray.Length);
            this.newSmr.sharedMesh.SetTriangles(destinationArray, num3++);
            int length = destinationArray.Length;
            for (num2 = 0; num2 < this.unatlasedSmrs.Count; num2++)
            {
                int[] numArray3;
                Mesh sharedMesh = this.unatlasedSmrs[num2].sharedMesh;
                if (sharedMesh.subMeshCount == 1)
                {
                    numArray3 = new int[sharedMesh.triangles.Length];
                    Array.Copy(triangles, length, numArray3, 0, numArray3.Length);
                    this.newSmr.sharedMesh.SetTriangles(numArray3, num3++);
                    length += numArray3.Length;
                }
                else
                {
                    int num5 = 0;
                    for (int i = 0; i < sharedMesh.subMeshCount; i++)
                    {
                        num5 = sharedMesh.GetTriangles(i).Length;
                        numArray3 = new int[num5];
                        Array.Copy(triangles, length, numArray3, 0, num5);
                        this.newSmr.sharedMesh.SetTriangles(numArray3, num3++);
                        length += numArray3.Length;
                    }
                }
            }
            this.newSmr.sharedMesh.subMeshCount = num3;
            TextureCleanup component = this.newSmr.GetComponent<TextureCleanup>();
            Material[] sharedMaterials = this.newSmr.sharedMaterials;
            this.newSmr.sharedMaterials = this.outputMaterials;
            for (num2 = 0; num2 < this.atlasedMaterialCount; num2++)
            {
                ResourceManager.ReleaseMaterial(sharedMaterials[num2], component);
            }
            BaseMotion motion = this.obj.GetComponent<BaseMotion>();
            if (motion != 0)
            {
                motion.ProcessStealth(true);
            }
            this.newSmr.sharedMesh.uv = this.atlasUvs;
            this.newSmr.localBounds = new Bounds(Vector3.zero, new Vector3(1.5f, 1f, 2f));
        }

        private Material CopyMaterialAndAssignColors(string assetName, Material original)
        {
            EquipmentAsset asset;
            Material material = ResourceManager.CopyMaterial(original);
            material.name = material.name.Replace("(Clone)", "");
            if (!this.colorData.TryGetValue(assetName, out asset))
            {
                asset = new EquipmentAsset(assetName);
            }
            if (((asset.materialColor.r != 0f) || (asset.materialColor.g != 0f)) || (asset.materialColor.b != 0f))
            {
                material.SetColor("_MatColor", asset.materialColor);
            }
            if (((asset.userColor1.r != 0f) || (asset.userColor1.g != 0f)) || (asset.userColor1.b != 0f))
            {
                material.SetColor("_UserColor1", asset.userColor1);
            }
            if (((asset.userColor2.r != 0f) || (asset.userColor2.g != 0f)) || (asset.userColor2.b != 0f))
            {
                material.SetColor("_UserColor2", asset.userColor2);
            }
            return material;
        }

        [DllImport("RenderingPlugin")]
        private static extern void CreateColorPalette(Color[] colors, GW_RECT[] offsets, int count, int colorsPerOffset, IntPtr texturePtr);
        protected static ATLAS_SLOTS FindIndexForComponentName(string input)
        {
            string[] strArray = input.ToLower().Split(new char[] { '_' });
            string str = string.Empty;
            if (strArray.Length >= 8)
            {
                str = strArray[7];
                switch (str)
                {
                    case "suit":
                        return ATLAS_SLOTS.suitMain;

                    case "glovlowr":
                        return ATLAS_SLOTS.gloveLower;

                    case "glovuppr":
                        return ATLAS_SLOTS.gloveUpper;

                    case "bootlowr":
                        return ATLAS_SLOTS.bootLower;

                    case "backitem":
                        return ATLAS_SLOTS.backItem;

                    case "suitatt":
                        return ATLAS_SLOTS.suitAttach;

                    case "suitatt 1":
                        return ATLAS_SLOTS.suitAttach;

                    case "suitarms":
                        return ATLAS_SLOTS.suitAttach;

                    case "suitlegs":
                        return ATLAS_SLOTS.suitAttach;

                    case "suitshrd":
                        return ATLAS_SLOTS.suitAttach;

                    case "suitshdruppr":
                        return ATLAS_SLOTS.suitAttach;
                }
            }
            if (strArray.Length >= 6)
            {
                str = strArray[5];
                ATLAS_SLOTS iNVALID = ATLAS_SLOTS.INVALID;
                if (GUtil.TryParseEnum<ATLAS_SLOTS>(str, ATLAS_SLOTS.INVALID, out iNVALID))
                {
                    return iNVALID;
                }
            }
            if (strArray.Length >= 4)
            {
                switch (strArray[3])
                {
                    case "bd":
                        return ATLAS_SLOTS.bodyFull;

                    case "fc":
                        return ATLAS_SLOTS.head;

                    case "bk":
                        return ATLAS_SLOTS.backItem;
                }
            }
            return ATLAS_SLOTS.INVALID;
        }

        public static ATLAS_SLOTS FindSlotForAsset(GameObject obj)
        {
            string str;
            AssetMetadata component = obj.GetComponent<AssetMetadata>();
            if (component == null)
            {
                return FindIndexForComponentName(obj.name);
            }
            if (!component.TryGetData("slotID", out str))
            {
                return ATLAS_SLOTS.INVALID;
            }
            ATLAS_SLOTS iNVALID = ATLAS_SLOTS.INVALID;
            GUtil.TryParseEnum<ATLAS_SLOTS>(str, ATLAS_SLOTS.INVALID, out iNVALID);
            return iNVALID;
        }

        public Material GetMaterial(int index)
        {
            return this.newSmr.sharedMaterials[index];
        }

        private static bool IsSlotAtlasable(string slotName)
        {
            ATLAS_SLOTS iNVALID = ATLAS_SLOTS.INVALID;
            GUtil.TryParseEnum<ATLAS_SLOTS>(slotName, ATLAS_SLOTS.INVALID, out iNVALID);
            return (iNVALID != ATLAS_SLOTS.INVALID);
        }

        public int NumMaterials()
        {
            return this.newSmr.sharedMaterials.Length;
        }

        [DllImport("RenderingPlugin")]
        private static extern void PackTexturesIntoAtlas(IntPtr[] textures, GW_RECT[] offsets, int count, int targetMipLevel, IntPtr texturePtr);
        public bool PreCombineMeshes()
        {
            int num4;
            Material[] sharedMaterials;
            if (this.allSmrs.Count == 0)
            {
                return false;
            }
            try
            {
                int num5;
                CombineInstance[] combine = new CombineInstance[this.numSubMeshes];
                Material[] array = new Material[this.numSubMeshes];
                Transform[] destinationArray = new Transform[this.numBones];
                Dictionary<string, Transform> bipedMap = EntityLoadClient.GetBipedMap(EntityLoadClient.FindRootBone(this.obj), null);
                bipedMap.TryGetValue("biped", out this.rootBone);
                this.atlasedMaterialIndices = new List<int>();
                Dictionary<Material, int> dictionary2 = new Dictionary<Material, int>();
                Dictionary<Material, int> dictionary3 = new Dictionary<Material, int>();
                Dictionary<Material, List<CombineInstance>> dictionary4 = new Dictionary<Material, List<CombineInstance>>();
                Dictionary<CombineInstance, Transform[]> dictionary5 = new Dictionary<CombineInstance, Transform[]>();
                int destinationIndex = 0;
                int num2 = 0;
                int newSize = 0;
                for (num4 = 0; num4 < this.allSmrs.Count; num4++)
                {
                    if (num4 == this.atlasedSmrs.Count)
                    {
                        this.atlasedMaterialCount = num2;
                    }
                    num5 = 0;
                    while (num5 < this.allSmrs[num4].sharedMaterials.Length)
                    {
                        Dictionary<Material, int> dictionary6;
                        Material material2;
                        CombineInstance item = new CombineInstance {
                            mesh = this.allSmrs[num4].sharedMesh,
                            subMeshIndex = num5
                        };
                        Material key = this.allSmrs[num4].sharedMaterials[num5];
                        int num6 = -1;
                        if (!dictionary2.TryGetValue(key, out num6))
                        {
                            if (num4 < this.atlasedSmrs.Count)
                            {
                                this.atlasedMaterialIndices.Add(num4);
                            }
                            dictionary2.Add(key, num2);
                            num6 = num2;
                            array[num6] = this.CopyMaterialAndAssignColors(this.allSmrs[num4].name, key);
                            dictionary3.Add(array[num6], 0);
                            dictionary4.Add(array[num6], new List<CombineInstance>());
                            num2++;
                        }
                        (dictionary6 = dictionary3)[material2 = array[num6]] = dictionary6[material2] + this.allSmrs[num4].sharedMesh.GetTriangles(num5).Length;
                        dictionary4[array[num6]].Add(item);
                        dictionary5[item] = this.RemapBones(this.allSmrs[num4], bipedMap);
                        num5++;
                    }
                }
                if (this.atlasedMaterialCount < 0)
                {
                    this.atlasedMaterialCount = num2;
                }
                int num7 = 0;
                destinationIndex = 0;
                for (num4 = 0; num4 < num2; num4++)
                {
                    List<CombineInstance> list = dictionary4[array[num4]];
                    for (num5 = 0; num5 < list.Count; num5++)
                    {
                        Transform[] sourceArray = dictionary5[list[num5]];
                        Array.Copy(sourceArray, 0, destinationArray, destinationIndex, sourceArray.Length);
                        destinationIndex += sourceArray.Length;
                        combine[num7++] = list[num5];
                    }
                }
                this.newSmr.sharedMesh.CombineMeshes(combine, false, false);
                this.atlasUvs = new Vector2[this.newSmr.sharedMesh.vertexCount];
                int[] numArray = new int[0];
                int[] triangles = this.newSmr.sharedMesh.triangles;
                int sourceIndex = 0;
                for (num4 = 0; num4 < num2; num4++)
                {
                    newSize = dictionary3[array[num4]];
                    if ((sourceIndex + newSize) > triangles.Length)
                    {
                        newSize = triangles.Length - sourceIndex;
                    }
                    Array.Resize<int>(ref numArray, newSize);
                    Array.Copy(triangles, sourceIndex, numArray, 0, newSize);
                    this.newSmr.sharedMesh.SetTriangles(numArray, num4);
                    sourceIndex += newSize;
                }
                this.newSmr.sharedMesh.subMeshCount = num2;
                Array.Resize<Material>(ref array, num2);
                this.newSmr.bones = destinationArray;
                this.newSmr.rootBone = this.rootBone;
                this.newSmr.localBounds = new Bounds(Vector3.zero, new Vector3(1.5f, 1f, 2f));
                sharedMaterials = this.newSmr.sharedMaterials;
                this.newSmr.sharedMaterials = array;
                if (sharedMaterials != null)
                {
                    for (num4 = 0; num4 < sharedMaterials.Length; num4++)
                    {
                        ResourceManager.ReleaseMaterial(sharedMaterials[num4], null);
                    }
                }
                EntityLoadClient.CacheSmrsOnMerge(this.obj);
                ResourceManager.RegisterForNondynamicTextures(this.obj, false, false);
                BaseMotion component = this.obj.GetComponent<BaseMotion>();
                if (component != 0)
                {
                    component.ProcessStealth(true);
                }
            }
            catch (Exception exception)
            {
                GLog.LogError(new object[] { "There was a problem merging object " + this.obj.name + ".  " + exception.ToString() });
                sharedMaterials = this.newSmr.sharedMaterials;
                if (sharedMaterials != null)
                {
                    for (num4 = 0; num4 < sharedMaterials.Length; num4++)
                    {
                        ResourceManager.ReleaseMaterial(sharedMaterials[num4], null);
                    }
                }
                UnityEngine.Object.Destroy(this.newSmr.sharedMesh);
                UnityEngine.Object.Destroy(this.newSmr.gameObject);
                return false;
            }
            return true;
        }

        public Status Process()
        {
            if (this.obj == null)
            {
                this.CleanupInProgress();
                return Status.Invalid;
            }
            if (this.currentStatus == Status.InProgress)
            {
                int num;
                int num2;
                switch (this.currentStage)
                {
                    case Stage.ProcessSmrs:
                        for (num = 0; num < this.atlasedMaterialCount; num++)
                        {
                            this.ProcessSmr(num);
                        }
                        this.currentStage = Stage.SortMaterials;
                        break;

                    case Stage.SortMaterials:
                        this.SortMaterials();
                        this.offsets = new GW_RECT[this.atlasedMaterialCount];
                        this.colors = new Color[this.atlasedMaterialCount * COLOR_NAMES.Length];
                        this.inputTextures = new Texture2D[TEX_NAMES.Length][];
                        this.inputTexturePtrs = new IntPtr[this.atlasedMaterialCount];
                        for (num = 0; num < TEX_NAMES.Length; num++)
                        {
                            this.inputTextures[num] = new Texture2D[this.atlasedMaterialCount];
                        }
                        this.currentStage = Stage.ProcessMaterials;
                        break;

                    case Stage.ProcessMaterials:
                        for (num = 0; num < this.materials.Count; num++)
                        {
                            this.ProcessMaterials(num);
                        }
                        this.currentStage = Stage.UpdateAtlasedUvs;
                        this.uvIndex = 0;
                        break;

                    case Stage.UpdateAtlasedUvs:
                        for (num = 0; num < this.atlasedSmrs.Count; num++)
                        {
                            num2 = 0;
                            while (num2 < this.atlasedSmrs[num].sharedMesh.subMeshCount)
                            {
                                this.UpdateUvs(this.atlasedSmrs[num], true, ref this.uvIndex);
                                num2++;
                            }
                        }
                        this.currentStage = Stage.UpdateUnatlasedUvs;
                        break;

                    case Stage.UpdateUnatlasedUvs:
                        for (num = 0; num < this.unatlasedSmrs.Count; num++)
                        {
                            for (num2 = 0; num2 < this.unatlasedSmrs[num].sharedMesh.subMeshCount; num2++)
                            {
                                this.UpdateUvs(this.unatlasedSmrs[num], false, ref this.uvIndex);
                            }
                        }
                        this.currentIndex = 0;
                        this.currentStage = Stage.PackTextures;
                        break;

                    case Stage.PackTextures:
                        this.outputTextures[this.currentIndex] = MergeJobService.RetrieveTexture(textureFormats[this.currentIndex]);
                        for (num = 0; num < this.inputTextures[this.currentIndex].Length; num++)
                        {
                            if (this.inputTextures[this.currentIndex][num] == null)
                            {
                                this.inputTexturePtrs[num] = IntPtr.Zero;
                            }
                            else
                            {
                                this.inputTexturePtrs[num] = this.inputTextures[this.currentIndex][num].GetNativeTexturePtr();
                            }
                        }
                        PackTexturesIntoAtlas(this.inputTexturePtrs, this.offsets, this.offsets.Length, this.targetMipLevel, this.outputTextures[this.currentIndex].GetNativeTexturePtr());
                        this.currentIndex++;
                        if (this.currentIndex >= TEX_NAMES.Length)
                        {
                            this.currentIndex = 0;
                            this.currentStage = Stage.CreateColorPalette;
                        }
                        break;

                    case Stage.CreateColorPalette:
                        this.clrsTexture = MergeJobService.RetrieveTexture(TextureFormat.RGB24);
                        CreateColorPalette(this.colors, this.offsets, this.offsets.Length, 3, this.clrsTexture.GetNativeTexturePtr());
                        this.currentStage = Stage.ConfigureMaterials;
                        break;

                    case Stage.ConfigureMaterials:
                        this.ConfigureMaterials();
                        this.currentStage = Stage.AssignTextures;
                        break;

                    case Stage.ConfigureTargetSmr:
                        this.ConfigureTargetSmr();
                        this.currentStatus = Status.Completed;
                        break;

                    case Stage.AssignTextures:
                        for (num = 0; num < TEX_NAMES.Length; num++)
                        {
                            this.outputMaterials[0].SetTexture(TEX_NAMES[num], this.outputTextures[num]);
                        }
                        this.outputMaterials[0].SetTexture("_ColorPalette", this.clrsTexture);
                        this.outputMaterials[0].SetTexture("_Cube", this.cubeTexture);
                        this.currentStage = Stage.ConfigureTargetSmr;
                        break;
                }
            }
            return this.currentStatus;
        }

        protected virtual void ProcessMaterials(int index)
        {
            throw new NotImplementedException("The type " + base.GetType() + " has not implemented ProcessMaterials.");
        }

        protected virtual void ProcessSmr(int index)
        {
            this.materials.Add(this.newSmr.sharedMaterials[index]);
        }

        private Transform[] RemapBones(SkinnedMeshRenderer smr, Dictionary<string, Transform> bipedMap)
        {
            Transform[] bones = smr.bones;
            Transform[] transformArray2 = new Transform[bones.Length];
            int index = 0;
            for (int i = 0; i < bones.Length; i++)
            {
                if (bones[i] != null)
                {
                    Transform transform = null;
                    if (bipedMap.TryGetValue(bones[i].name.ToLower(), out transform))
                    {
                        transformArray2[index] = transform;
                        index++;
                    }
                }
            }
            return transformArray2;
        }

        protected virtual void SortMaterials()
        {
        }

        private void UpdateUvs(SkinnedMeshRenderer smr, bool remap, ref int index)
        {
            Vector2[] uv = smr.sharedMesh.uv;
            int length = uv.Length;
            if (!remap)
            {
                Array.Copy(uv, 0, this.atlasUvs, index, length);
                index += length;
            }
            else
            {
                Rect rect;
                this.materialNameToOffset.TryGetValue(smr.sharedMaterial.name.ToLower(), out rect);
                for (int i = 0; i < length; i++)
                {
                    float x = uv[i].x;
                    float y = uv[i].y;
                    int num5 = (int) x;
                    if (x < 0f)
                    {
                        x = (x % 1f) * -1f;
                    }
                    else if (x > 1f)
                    {
                        x = x % 1f;
                    }
                    int num6 = (int) y;
                    if (y < 0f)
                    {
                        y = (y % 1f) * -1f;
                    }
                    else if (y > 1f)
                    {
                        y = y % 1f;
                    }
                    this.atlasUvs[index].x = num5 + (Mathf.Lerp(rect.xMin, rect.xMax, x) / ((float) MergeJobService.ATLAS_SIZE));
                    this.atlasUvs[index].y = num6 + (Mathf.Lerp(rect.yMin, rect.yMax, y) / ((float) MergeJobService.ATLAS_SIZE));
                    index++;
                }
            }
        }

        public Stage CurrentStage
        {
            get
            {
                return this.currentStage;
            }
        }

        public GameObject Object
        {
            get
            {
                return this.obj;
            }
        }

        public enum ATLAS_SLOTS
        {
            armLL = 0,
            armLR = 0,
            armML = 0,
            armMR = 0,
            armUL = 0,
            armUR = 0,
            backItem = 3,
            bodyFull = 0,
            bootLower = 7,
            bootUpper = 8,
            breast = 0,
            chest = 0,
            chestU = 0,
            ears = 1,
            faceMesh = 1,
            fingerL = 0,
            fingerR = 0,
            footL = 0,
            footR = 0,
            gloveLower = 5,
            gloveUpper = 6,
            handL = 0,
            handR = 0,
            head = 1,
            helmArmor = 2,
            hips = 0,
            INVALID = 10,
            legLL = 0,
            legLR = 0,
            legML = 0,
            legMR = 0,
            legUL = 0,
            legUR = 0,
            neck = 1,
            stomach = 0,
            suitAttach = 9,
            suitMain = 4
        }

        public enum Stage
        {
            ProcessSmrs,
            SortMaterials,
            ProcessMaterials,
            ProcessBones,
            UpdateAtlasedUvs,
            UpdateUnatlasedUvs,
            PackTextures,
            CreateColorPalette,
            ConfigureMaterials,
            ConfigureTargetSmr,
            AssignTextures,
            SwapCharacter
        }

        public enum Status
        {
            Invalid,
            Initialized,
            InProgress,
            Completed,
            Failed
        }
    }
}

