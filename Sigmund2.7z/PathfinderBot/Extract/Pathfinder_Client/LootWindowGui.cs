﻿using GNGUI;
using System;
using System.Collections.Generic;
using UnityEngine;

public class LootWindowGui : ItemWindowGui
{
    private List<LootItemGui> displayedItems = new List<LootItemGui>();
    public UIGrid lootGrid;
    private GameObject lootItemPrefab = null;
    private UIScrollBar scrollBar;
    public static LootWindowGui singleton;
    private UIButton takeAllButton;
    [NonSerialized, HideInInspector]
    public EntityId targetId;
    private UILabel windowTitle;

    public void Awake()
    {
        singleton = this;
    }

    public override void DragEnd(InventoryItem item, BasicItemData.ItemSlot slot)
    {
        this.lootGrid.repositionNow = true;
    }

    public override void DragStart(InventoryItem item)
    {
    }

    public override void ItemInteract(ItemGui item, ItemWindowGui.Interaction interaction)
    {
        if (interaction != ItemWindowGui.Interaction.DROP)
        {
            InventoryItem item2 = base.AdjustItemOnInteract(item.item, interaction);
            this.TakeItem(item2);
        }
    }

    public override void OnDestroy()
    {
        base.OnDestroy();
        singleton = null;
    }

    private void Repopulate(InventoryItem[] items)
    {
        int num = 0;
        for (int i = 0; i < items.Length; i++)
        {
            if (!InventoryItem.EMPTY_MATCH(items[i]))
            {
                if (num >= this.displayedItems.Count)
                {
                    LootItemGui component = NGUITools.AddChild(this.lootGrid.gameObject, this.lootItemPrefab).GetComponent<LootItemGui>();
                    this.displayedItems.Add(component);
                }
                this.displayedItems[num].Assign(items[i], this);
                num++;
            }
        }
        while (this.displayedItems.Count > num)
        {
            LootItemGui gui2 = this.displayedItems[this.displayedItems.Count - 1];
            this.displayedItems.RemoveAt(this.displayedItems.Count - 1);
            gui2.gameObject.SetActive(false);
            gui2.transform.parent = DragDropRoot.root;
            UnityEngine.Object.Destroy(gui2.gameObject);
        }
        IEnumerable<LootItemGui> enumerable = from each in this.displayedItems
            orderby each.sortEncumbrance descending
            select each;
        int num3 = 0;
        foreach (LootItemGui gui3 in enumerable)
        {
            gui3.name = num3 + "_" + gui3.sortName;
            num3++;
        }
        this.lootGrid.repositionNow = true;
    }

    public void ResetScroll()
    {
        this.scrollBar.scrollValue = 0f;
    }

    public void ShowLoot(EntityId _targetId, bool showLootAll, InventoryItem[] items)
    {
        this.targetId = _targetId;
        Entity entity = EntityCore.GetEntity(ref this.targetId);
        this.Repopulate(items);
        this.ResetScroll();
        this.ShowWindow();
        this.takeAllButton.gameObject.SetActive(showLootAll);
    }

    public void Start()
    {
        this.lootItemPrefab = UIClient.guiPrefabs["LootItem"];
        foreach (UILabel label in base.GetComponentsInChildren<UILabel>())
        {
            if (label.name == "Title")
            {
                this.windowTitle = label;
            }
        }
        this.lootGrid = base.GetComponentInChildren<UIGrid>();
        this.takeAllButton = base.transform.FindChild("TakeAllButton").GetComponent<UIButton>();
        this.scrollBar = base.GetComponentInChildren<UIScrollBar>();
        GuiHelper.GuiAssertNotNull("Couldn't load prefabs.", new object[] { this.lootGrid, this.lootItemPrefab, this.takeAllButton, this.windowTitle, this.scrollBar });
        UIEventListener listener1 = UIEventListener.Get(this.takeAllButton.gameObject);
        listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.TakeAllClicked));
        this.windowTitle.text = "Your Loot";
        base.Init(2, true);
    }

    public static bool SyncUpdate()
    {
        if (((singleton != null) && singleton.IsShowing()) && (EntityCore.GetEntity(singleton.targetId) == null))
        {
            singleton.HideWindow();
        }
        return true;
    }

    private void TakeAllClicked(GameObject go)
    {
        InventoryClient.TakeAll(this.targetId);
    }

    public void TakeItem(InventoryItem item)
    {
        InventoryClient.TakeStack(this.targetId, item);
    }
}

