﻿using System;
using System.Text;

public class TrackedQuest : ITrackerElement
{
    public readonly QuestData questData;
    public readonly float timestamp = 0f;
    public readonly bool userPinned = false;

    public TrackedQuest(QuestData _questData, float _time, bool _userPinned)
    {
        this.questData = _questData;
        this.timestamp = _time;
        this.userPinned = _userPinned;
    }

    public string GetBody()
    {
        QuestRecord quest = EntityDataClient.owner.playerRecord.GetQuest(this.questData.id);
        StringBuilder quickText = GUtil.GetQuickText();
        quickText.Append("\n");
        quickText.Append("[F0E3A8]");
        QuestData.AppendObjective(quickText, quest, false);
        quickText.Append("[-]\n");
        return quickText.ToString();
    }

    public string GetHoverText()
    {
        QuestRecord quest = EntityDataClient.owner.playerRecord.GetQuest(this.questData.id);
        StringBuilder quickText = GUtil.GetQuickText();
        quickText.Append(this.questData.displayName);
        quickText.Append("\n");
        quickText.Append(this.questData.shortDescription);
        quickText.Append("\nObjective:\n");
        quickText.Append("[F0E3A8]");
        QuestData.AppendObjective(quickText, quest, true);
        quickText.Append("[-]\n");
        return quickText.ToString();
    }

    public string GetName()
    {
        return this.questData.displayName;
    }

    public void OnClick()
    {
        QuestClient.SetQuestBlob(new int[] { this.questData.id });
    }
}

