﻿using GNGUI;
using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

public class AuctionOrdersBidsTabGui : AuctionHouseTabGui
{
    private UIScrollBar commonScrollbar;
    private UILabel infoLabel;
    protected ItemOffer.OfferType offerType;
    private List<AuctionOrderBidItemGui> orderItemGuis = new List<AuctionOrderBidItemGui>();
    private GameObject orderItemPrefab;
    private List<ItemOffer> visibleItems = new List<ItemOffer>();

    public virtual void Awake()
    {
        base.Init("OrdersGrid");
        this.commonScrollbar = base.scrollBar;
        base.scrollBar = base.GetComponentInChildren<UIScrollBar>();
        foreach (UILabel label in base.GetComponentsInChildren<UILabel>())
        {
            if (label.name == "SlotsUsedLabel")
            {
                this.infoLabel = label;
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find needed children.", new object[] { base.scrollBar, this.infoLabel });
    }

    public override void ContentsChanged()
    {
        if (base.IsShowing())
        {
            this.Repopulate(this.GetItems());
        }
    }

    protected virtual List<ItemOffer> GetItems()
    {
        return null;
    }

    public override void HideTab()
    {
        base.HideTab();
    }

    public override void ItemInterest(InventoryItem item)
    {
        for (int i = 0; i < this.orderItemGuis.Count; i++)
        {
            this.orderItemGuis[i].UpdateSelected(item.staticItemId, item.upgrade);
        }
    }

    public override void LoadingTickFinished()
    {
        this.orderItemPrefab = UIClient.guiPrefabs["OrderBidItem"];
    }

    private void Repopulate(List<ItemOffer> orderItems)
    {
        StringBuilder quickText = GUtil.GetQuickText();
        quickText.Append(AuctionHouseGui.singleton.slotsUsed).Append("/").Append(AuctionHouseGui.singleton.slotsMax);
        quickText.Append(" slots used.");
        this.infoLabel.text = quickText.ToString();
        UIGrid.SetElementCount<AuctionOrderBidItemGui>(DragDropRoot.root, base.gridList, this.orderItemPrefab, this.orderItemGuis, orderItems.Count);
        for (int i = 0; i < orderItems.Count; i++)
        {
            this.orderItemGuis[i].SetData(orderItems[i], this.offerType);
        }
        if (orderItems.Count == 0)
        {
            AuctionHouseGui.singleton.ShowTabItemInfo((this.offerType == ItemOffer.OfferType.BID) ? "No bids." : "No offers.");
        }
        else
        {
            AuctionHouseGui.singleton.ShowTabItemInfo(string.Empty);
        }
    }

    public override void ShowTab()
    {
        NGUITools.SetActive(this.commonScrollbar.gameObject, false);
        base.ShowTab();
        this.Repopulate(this.GetItems());
    }
}

