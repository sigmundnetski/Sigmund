﻿using GNGUI;
using System;
using UnityEngine;

public class RecipeInputElement : MonoBehaviour
{
    private UILabel countLabel;
    private bool eventsSet = false;
    private UIImageButton imgButton;
    private InventoryItem myItem = InventoryItem.EMPTY;

    public void OnInputClick(GameObject go)
    {
        CraftingClient.Earmark(this.myItem, 1);
    }

    public void OnInputDClick(GameObject go)
    {
        CraftingClient.Earmark(this.myItem, this.myItem.quantity);
    }

    public void OnInputTooltip(GameObject go, bool show)
    {
        if (!show)
        {
            CraftingWindow.singleton.ShowTooltip(null, null);
        }
        else
        {
            CraftingWindow.singleton.ShowTooltip(InventoryClient.GetColoredItemDisplayName(this.myItem), go);
        }
    }

    public void SetData(InventoryItem data)
    {
        if (this.countLabel == null)
        {
            this.countLabel = base.transform.FindChild("CountLabel").GetComponent<UILabel>();
        }
        if (this.imgButton == null)
        {
            this.imgButton = base.GetComponentsInChildren<UIImageButton>(true)[0];
        }
        if (!this.eventsSet)
        {
            UIEventListener listener1 = UIEventListener.Get(this.imgButton.gameObject);
            listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.OnInputClick));
            UIEventListener listener2 = UIEventListener.Get(this.imgButton.gameObject);
            listener2.onDoubleClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener2.onDoubleClick, new UIEventListener.VoidDelegate(this.OnInputDClick));
            UIEventListener listener3 = UIEventListener.Get(this.imgButton.gameObject);
            listener3.onTooltip = (UIEventListener.BoolDelegate) Delegate.Combine(listener3.onTooltip, new UIEventListener.BoolDelegate(this.OnInputTooltip));
            this.eventsSet = true;
        }
        this.myItem = data;
        base.gameObject.name = data.GetDisplayName(true);
        this.countLabel.text = data.quantity.ToString();
    }
}

