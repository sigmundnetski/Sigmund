﻿using GNGUI;
using System;
using UnityEngine;

public class StaticSplashGui : MonoBehaviour
{
    private const float ALPHA_LERP_TIME = 0.5f;
    private NguiAlphaLerper alphaLerper;
    private const float MIN_SHOW_TIME = 5f;
    public static StaticSplashGui singleton;
    private bool startHiding = false;
    private float startTime;

    public void Awake()
    {
        singleton = this;
    }

    public void Hide()
    {
        this.startHiding = true;
    }

    public void OnDestroy()
    {
        if (singleton == this)
        {
            singleton = null;
        }
    }

    public void Start()
    {
        this.startTime = Time.time;
    }

    public void Update()
    {
        if (this.startHiding && (Time.time > (this.startTime + 5f)))
        {
            this.alphaLerper = new NguiAlphaLerper(base.gameObject, 1f, 0f, 0.5f, null);
            this.startHiding = false;
        }
        if ((this.alphaLerper != null) && this.alphaLerper.Update())
        {
            this.alphaLerper = null;
            NGUITools.SetActive(base.gameObject, false);
        }
    }
}

