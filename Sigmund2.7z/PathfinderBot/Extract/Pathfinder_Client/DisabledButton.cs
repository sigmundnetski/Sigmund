﻿using GNGUI;
using System;
using UnityEngine;

public class DisabledButton : MonoBehaviour
{
    private UIImageButton button;
    public bool disabled;
    private Color disabledColor;
    private string[] disabledSprites;
    private Color enabledColor;
    private string[] enabledSprites;
    public UILabel label;

    public void Assign(string[] disabledIconNames, string[] enabledIconNames, Color disabledColor_, Color enabledColor_)
    {
        if ((disabledIconNames.Length != 3) || (enabledIconNames.Length != 3))
        {
            GLog.LogError(new object[] { base.name, "needs to be assigned 3 icons for both states. Got:", disabledIconNames.Length, enabledIconNames.Length });
        }
        else
        {
            int num;
            this.disabledSprites = disabledIconNames;
            this.enabledSprites = enabledIconNames;
            this.disabledColor = disabledColor_;
            this.enabledColor = enabledColor_;
            UIAtlas atlas = this.button.target.atlas;
            for (num = 0; num < this.disabledSprites.Length; num++)
            {
                if (atlas.GetSprite(this.disabledSprites[num]) == null)
                {
                    GLog.LogError(new object[] { base.name, "could not find sprite '" + this.disabledSprites[num] + "' in button's atlas." });
                    return;
                }
            }
            for (num = 0; num < this.enabledSprites.Length; num++)
            {
                if (atlas.GetSprite(this.enabledSprites[num]) == null)
                {
                    GLog.LogError(new object[] { base.name, "could not find sprite '" + this.enabledSprites[num] + "' in button's atlas." });
                    break;
                }
            }
        }
    }

    public void Awake()
    {
        this.disabled = false;
        this.button = base.GetComponentInChildren<UIImageButton>();
        this.label = base.GetComponentInChildren<UILabel>();
        GuiHelper.GuiAssertNotNull(base.name + " couldn't find required children.", new object[] { this.button });
        this.button.target = this.button.GetComponentInChildren<UISprite>();
    }

    public void IsDisabled(bool isDisabled)
    {
        string[] disabledSprites;
        Color disabledColor;
        this.disabled = isDisabled;
        if (this.disabled)
        {
            disabledSprites = this.disabledSprites;
            disabledColor = this.disabledColor;
        }
        else
        {
            disabledSprites = this.enabledSprites;
            disabledColor = this.enabledColor;
        }
        if (this.label != null)
        {
            this.label.color = disabledColor;
        }
        this.button.normalSprite = disabledSprites[0];
        this.button.hoverSprite = disabledSprites[1];
        this.button.pressedSprite = disabledSprites[2];
        this.button.SendMessage("OnHover", false, SendMessageOptions.DontRequireReceiver);
    }
}

