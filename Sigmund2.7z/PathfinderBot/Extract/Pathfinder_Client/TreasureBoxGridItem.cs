﻿using GNGUI;
using System;
using UnityEngine;

public class TreasureBoxGridItem : MonoBehaviour
{
    private UILabel itemLabel;
    private LootTableData lootTableData;
    private bool selected = false;
    private UILabel selectedLabel;

    public void OnClick()
    {
        TreasureBoxSelectorGui.selectedTableId = this.lootTableData.id;
        TreasureBoxSelectorGui.singleton.Refresh();
    }

    public void SetItem(int lootTableId, bool _selected)
    {
        LootTableData.tablesById.TryGetValue(lootTableId, out this.lootTableData);
        this.selected = _selected;
        this.UpdateLabels();
    }

    public void SetSelection(bool setSelected)
    {
        this.selected = setSelected;
        this.UpdateLabels();
    }

    public void Start()
    {
        foreach (UILabel label in base.gameObject.GetComponentsInChildren<UILabel>())
        {
            if (label.name == "Item Label")
            {
                this.itemLabel = label;
            }
            else if (label.name == "Selected Label")
            {
                this.selectedLabel = label;
            }
        }
        GuiHelper.GuiAssertNotNull("Error starting TreasureBoxGridItem:", new object[] { this.itemLabel, this.selectedLabel });
        this.UpdateLabels();
    }

    public void ToggleSelect(GameObject self)
    {
        this.SetSelection(!this.selected);
    }

    private void UpdateLabels()
    {
        if (this.itemLabel != null)
        {
            this.itemLabel.text = (this.lootTableData == null) ? "<unknown>" : this.lootTableData.displayName;
        }
        if (this.selectedLabel != null)
        {
            this.selectedLabel.text = this.selected ? "X" : "";
        }
    }
}

