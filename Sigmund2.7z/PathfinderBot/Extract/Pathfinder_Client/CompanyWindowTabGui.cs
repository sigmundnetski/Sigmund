﻿using GNGUI;
using System;
using UnityEngine;

public abstract class CompanyWindowTabGui : MonoBehaviour
{
    protected CompanyWindowTabGui()
    {
    }

    public abstract void DisplayCompany();
    public virtual void HideTab()
    {
        NGUITools.SetActive(base.gameObject, false);
    }

    public virtual void LoadingTickFinished()
    {
    }

    public abstract void RefreshCompany();
    public virtual void ShowTab()
    {
        NGUITools.SetActive(base.gameObject, true);
    }

    public virtual void SyncFixedUpdate()
    {
    }

    public abstract void UpdateCompany();
}

