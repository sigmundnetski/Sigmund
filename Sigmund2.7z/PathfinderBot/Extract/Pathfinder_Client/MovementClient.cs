﻿using System;

public static class MovementClient
{
    public static AnimationData DRAW;
    public static AnimationData STOW;
    public static AnimationData SWAP;

    public static void InitializeBaseMotion(Entity entity)
    {
        BaseMotion component = entity.gameObject.GetComponent<BaseMotion>();
        if (component != null)
        {
            component.Initialize(entity);
        }
    }

    public static void SyncStart()
    {
        Entity.initializeCallback = (EntityDataCallback) Delegate.Combine(Entity.initializeCallback, new EntityDataCallback(MovementClient.InitializeBaseMotion));
        DRAW = AnimationData.GetByName("Draw");
        STOW = AnimationData.GetByName("Stow");
        SWAP = AnimationData.GetByName("Swap");
    }
}

