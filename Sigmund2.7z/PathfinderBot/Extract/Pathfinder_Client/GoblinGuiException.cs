﻿using System;

internal class GoblinGuiException : Exception
{
    public GoblinGuiException(string message) : base(message)
    {
    }
}

