﻿using GNGUI;
using System;
using System.Runtime.CompilerServices;
using UnityEngine;

public class CharacterManagementGui : MonoBehaviour
{
    private PlayerInfo[] characters;
    private static string commandLineCharacterName;
    private CharacterCreationGui creationGui;
    private MonoBehaviour currentlyDisplayedGui;
    private Transform parentTransform;
    private static bool readCommandLine = true;
    private bool receivedCharacters;
    private CharacterSelectionGui selectionGui;
    public static CharacterManagementGui singleton;
    private GameObject spawnPoint;

    public void Awake()
    {
        singleton = this;
        this.OnAwake();
    }

    public void CreationError(string message)
    {
        this.creationGui.SetError(message);
    }

    public void DisplayCharacterCreation()
    {
        this.selectionGui.DisableCharacterModel();
        NGUITools.SetActive(this.selectionGui.gameObject, false);
        this.creationGui.ClearError();
        this.creationGui.EnableGui();
        this.currentlyDisplayedGui = this.creationGui;
    }

    public void DisplayCharacterSelection(GameObject go)
    {
        this.creationGui.DisableCharacterModel();
        NGUITools.SetActive(this.creationGui.gameObject, false);
        this.selectionGui.SetError(null);
        this.selectionGui.EnableGui();
        this.currentlyDisplayedGui = this.selectionGui;
    }

    public bool ExtractBundles()
    {
        PlayerLoginClient.RequestPlayerList();
        this.creationGui.AssignObjects(this.parentTransform, this.spawnPoint);
        this.selectionGui.AssignObjects(this.parentTransform, this.spawnPoint);
        return true;
    }

    public bool LoadingTickFinished()
    {
        this.creationGui.ConfigureFields();
        this.selectionGui.ConfigureFields(this.characters);
        if (readCommandLine)
        {
            CharacterManagementGui.commandLineCharacterName = StartupParameters.RemoveParameterToProcess("character");
            readCommandLine = false;
        }
        if (!string.IsNullOrEmpty(CharacterManagementGui.commandLineCharacterName))
        {
            string str = CharacterManagementGui.commandLineCharacterName.ToLower();
            string commandLineCharacterName = CharacterManagementGui.commandLineCharacterName;
            CharacterManagementGui.commandLineCharacterName = string.Empty;
            foreach (PlayerInfo info in this.characters)
            {
                if (info.playerName.ToLower() == str)
                {
                    this.DisplayCharacterSelection(null);
                    this.selectionGui.SelectCharacter(info.playerId);
                    this.selectionGui.UpdatePlayButton();
                    this.selectionGui.PlayGame(true);
                    return true;
                }
            }
            this.DisplayCharacterCreation();
            this.creationGui.CreateCharacterWithName(commandLineCharacterName);
            this.creationGui.PlayGame(null);
            return true;
        }
        if (this.characters.Length == 0)
        {
            this.DisplayCharacterCreation();
        }
        else
        {
            this.DisplayCharacterSelection(null);
        }
        return true;
    }

    public void OnAwake()
    {
        CharacterSelectTick.charManageBundles = new GUtil.BoolFilterDelegate(this.ExtractBundles);
        CharacterSelectTick.charManageWait = new GUtil.BoolFilterDelegate(this.WaitForRemoteCallbacks);
        CharacterSelectTick.charManageLoadFinish = new GUtil.BoolFilterDelegate(this.LoadingTickFinished);
        this.receivedCharacters = false;
        this.creationGui = base.GetComponentInChildren<CharacterCreationGui>();
        this.selectionGui = base.GetComponentInChildren<CharacterSelectionGui>();
        GameObject obj2 = GameObject.Find("/Programming/Entities");
        this.parentTransform = (obj2 != null) ? obj2.transform : null;
        this.spawnPoint = GameObject.Find("/SpawnPoint");
        GuiHelper.GuiAssertNotNull("Error starting CharacterManagementGui:", new object[] { this.creationGui, this.selectionGui, this.parentTransform, this.spawnPoint });
    }

    public void OnDestroy()
    {
        singleton = null;
    }

    public void RecordLastSelectedPlayer(uint playerId)
    {
        PlayerPrefs.SetInt("player", (int) playerId);
    }

    public void SelectionError(string message)
    {
        this.selectionGui.EnableGui();
        this.selectionGui.SetError(message);
    }

    public void SetDeletionTime(DateTime time)
    {
        this.localDeletionTime = time.ToLocalTime();
    }

    public void SetPermissionLevel(CommandCore.PermissionLevel result)
    {
        this.creationGui.UpdatePermissions(result);
    }

    public void TryCharacterCreation()
    {
        if (this.selectionGui.NumCharacters(true) < 3)
        {
            this.DisplayCharacterCreation();
        }
        else
        {
            this.selectionGui.SetError("Character limit reached");
        }
    }

    public void UpdateCharacters(PlayerInfo[] _characters)
    {
        this.characters = _characters;
        if (this.receivedCharacters)
        {
            this.selectionGui.ConfigureFields(this.characters);
            if ((this.currentlyDisplayedGui == this.selectionGui) && (this.selectionGui.NumCharacters(true) == 0))
            {
                this.DisplayCharacterCreation();
            }
        }
        else
        {
            this.receivedCharacters = true;
        }
    }

    public bool WaitForRemoteCallbacks()
    {
        return this.receivedCharacters;
    }

    public DateTime localDeletionTime { get; private set; }
}

