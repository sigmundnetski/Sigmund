﻿using GNGUI;
using System;
using UnityEngine;

public class AuctionMarketItemGui : MonoBehaviour
{
    private UIImageButton buyButton;
    private UILabel descriptionLabel;
    private ItemOffer marketItem;
    private UILabel nameLabel;
    private Color prevColor = AuctionHouseGui.NORMAL_TEXT;
    private UILabel priceLabel;
    private bool selected;

    public void OnBuyClick(GameObject filterGO)
    {
        AuctionMarketTabGui.singleton.OnItemBuyClick(this.marketItem);
    }

    public void OnClick()
    {
        if (this.selected)
        {
            AuctionMarketTabGui.singleton.OnItemSelected(null);
        }
        else
        {
            this.nameLabel.color = AuctionHouseGui.SELECTED_TEXT;
            AuctionMarketTabGui.singleton.OnItemSelected(this.marketItem);
        }
        this.prevColor = this.nameLabel.color;
    }

    public void OnHover(bool isHovered)
    {
        if (isHovered)
        {
            this.nameLabel.color = AuctionHouseGui.HOVERED_TEXT;
        }
        else
        {
            this.nameLabel.color = this.prevColor;
        }
    }

    public virtual void SetData(ItemOffer marketItem_)
    {
        if (this.nameLabel == null)
        {
            this.nameLabel = base.transform.FindChild("ItemLabel").GetComponent<UILabel>();
        }
        if (this.descriptionLabel == null)
        {
            this.descriptionLabel = base.transform.FindChild("DescriptionLabel").GetComponent<UILabel>();
        }
        if (this.priceLabel == null)
        {
            this.priceLabel = base.transform.FindChild("PriceLabel").GetComponent<UILabel>();
        }
        if (this.buyButton == null)
        {
            this.buyButton = base.transform.FindChild("ButtonBuy").GetComponent<UIImageButton>();
            UIEventListener listener1 = UIEventListener.Get(this.buyButton.gameObject);
            listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.OnBuyClick));
        }
        GuiHelper.GuiAssertNotNull("Couldn't find needed children.", new object[] { this.nameLabel, this.descriptionLabel, this.priceLabel, this.buyButton });
        this.marketItem = marketItem_;
        if (ItemDatabase.GetItem(this.marketItem.item.staticItemId) == null)
        {
            base.name = "ZZZ";
            this.nameLabel.text = string.Empty;
        }
        else
        {
            base.name = this.marketItem.curPrice.ToString().PadLeft(20, '0');
            this.nameLabel.text = this.marketItem.item.GetDisplayName(true);
            this.descriptionLabel.text = this.marketItem.item.GetDescription();
            this.priceLabel.text = AuctionHouseGui.PriceToString(this.marketItem.curPrice);
            this.UpdateSelected(AuctionHouseGui.singleton.currentItem);
        }
    }

    public void UpdateSelected(InventoryItem selectedItem)
    {
        this.selected = (this.marketItem.item.staticItemId == selectedItem.staticItemId) && (this.marketItem.item.upgrade == selectedItem.upgrade);
        this.nameLabel.color = this.selected ? AuctionHouseGui.SELECTED_TEXT : AuctionHouseGui.NORMAL_TEXT;
        this.prevColor = this.selected ? AuctionHouseGui.SELECTED_TEXT : AuctionHouseGui.NORMAL_TEXT;
    }
}

