﻿using GNetwork;
using System;

public static class AuctionHouseClient
{
    public static void BidItem(ItemOffer item, uint quantity, ulong bidPrice)
    {
        BitBuffer quickBuffer = GUtil.GetQuickBuffer();
        ItemOffer.PushToBuffer(quickBuffer, item);
        quickBuffer.PushUInt(quantity);
        quickBuffer.PushULong(bidPrice);
        GRouting.SendMyMapRpc(GRpcID.AuctionHouseServer_BidItem, new object[] { quickBuffer });
    }

    public static void BuyItem(ItemOffer item, uint quantity)
    {
        BitBuffer quickBuffer = GUtil.GetQuickBuffer();
        ItemOffer.PushToBuffer(quickBuffer, item);
        quickBuffer.PushUInt(quantity);
        GRouting.SendMyMapRpc(GRpcID.AuctionHouseServer_BuyItem, new object[] { quickBuffer });
    }

    public static void CancelItem(ItemOffer item, ItemOffer.OfferType offerType)
    {
        BitBuffer quickBuffer = GUtil.GetQuickBuffer();
        ItemOffer.PushToBuffer(quickBuffer, item);
        quickBuffer.PushByte((byte) offerType);
        GRouting.SendMyMapRpc(GRpcID.AuctionHouseServer_CancelItem, new object[] { quickBuffer });
    }

    public static void ItemInterest(InventoryItem item)
    {
        if (!InventoryItem.EMPTY_MATCH(item))
        {
            BitBuffer quickBuffer = GUtil.GetQuickBuffer();
            item.Write(quickBuffer, InventoryItem.EMPTY);
            GRouting.SendMyMapRpc(GRpcID.AuctionHouseServer_ItemInterest, new object[] { quickBuffer });
        }
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void MarketUpdate(IBitBufferRead buffer)
    {
        int itemId = buffer.PopInt();
        byte upgrade = buffer.PopByte();
        ItemOffer[] newOffer = ItemOffer.PopArrayFromBuffer(buffer);
        AuctionHouseGui.singleton.OnMarketUpdate(itemId, upgrade, newOffer);
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void OpenWindow()
    {
        AuctionHouseGui.singleton.ShowWindow();
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void OrdersBidsUpdate(IBitBufferRead buffer)
    {
        ItemOffer[] ordersAndBids = ItemOffer.PopArrayFromBuffer(buffer);
        AuctionHouseGui.singleton.OnOrdersBidsUpdate(ordersAndBids);
    }

    public static void SellItem(ItemOffer item, Item.Container source)
    {
        BitBuffer quickBuffer = GUtil.GetQuickBuffer();
        ItemOffer.PushToBuffer(quickBuffer, item);
        quickBuffer.PushByte((byte) source);
        GRouting.SendMyMapRpc(GRpcID.AuctionHouseServer_OfferItem, new object[] { quickBuffer });
    }
}

