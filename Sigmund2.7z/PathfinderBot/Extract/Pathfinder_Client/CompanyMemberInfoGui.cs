﻿using GNGUI;
using System;
using UnityEngine;

public class CompanyMemberInfoGui : TabListItem
{
    private bool selected;
    public string sortName;
    public string sortStatus;
    private UILabel statusLabel;

    public void Assign(VentureCompanyInvite invite)
    {
        this.selected = false;
        base.nameLabel.text = invite.inviteeName + ((invite.TypeOfInvite() == VentureCompanyInvite.InviteType.APPLICANT) ? " (Applicant)" : " (Invited)");
        this.sortName = invite.inviteeName;
        NGUITools.SetActive(this.statusLabel.gameObject, false);
        this.PlayerSelected(string.Empty);
    }

    public void Assign(VentureCompanyMember member)
    {
        this.selected = false;
        base.nameLabel.text = member.playerName;
        this.sortName = member.playerName;
        NGUITools.SetActive(this.statusLabel.gameObject, false);
        this.PlayerSelected(string.Empty);
    }

    public override void Awake()
    {
        base.Awake();
        this.selected = false;
        foreach (UILabel label in base.GetComponentsInChildren<UILabel>())
        {
            if (label.name == "Name")
            {
                base.nameLabel = label;
            }
            else if (label.name == "Status")
            {
                this.statusLabel = label;
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find label.", new object[] { base.nameLabel, this.statusLabel });
    }

    public void OnClick()
    {
        this.selected = !this.selected;
        CompanyWindowDetailsTabGui.singleton.PlayerSelected(this.selected ? this.sortName : string.Empty);
    }

    public override void OnTooltip(bool show)
    {
    }

    public void PlayerSelected(string playerName)
    {
        Color playerSelectedColor;
        if (this.sortName == playerName)
        {
            playerSelectedColor = CompanyWindowDetailsTabGui.playerSelectedColor;
        }
        else
        {
            playerSelectedColor = CompanyWindowDetailsTabGui.playerDefaultColor;
        }
        base.nameLabel.color = playerSelectedColor;
        this.statusLabel.color = playerSelectedColor;
    }
}

