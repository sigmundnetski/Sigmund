﻿using GNGUI;
using System;
using System.Collections.Generic;
using UnityEngine;

public class RecipeInputsGui : MonoBehaviour
{
    private UIGrid grid;
    private List<RecipeInputElement> inputElements = new List<RecipeInputElement>();
    private GameObject recipeInputPrefab;

    public void Repopulate()
    {
        if (this.recipeInputPrefab == null)
        {
            this.recipeInputPrefab = UIClient.guiPrefabs["RecipeInputElement"];
        }
        if (this.grid == null)
        {
            this.grid = base.GetComponent<UIGrid>();
        }
        InventoryItem[] availableItems = CraftingClient.GetAvailableItems();
        int count = SparseArray.Count<InventoryItem>(availableItems, InventoryItem.EMPTY_MATCH);
        UIGrid.SetElementCount<RecipeInputElement>(DragDropRoot.root, this.grid, this.recipeInputPrefab, this.inputElements, count);
        int num2 = 0;
        foreach (InventoryItem item in SparseArray.Iterate<InventoryItem>(availableItems, InventoryItem.EMPTY_MATCH))
        {
            this.inputElements[num2].SetData(item);
            num2++;
        }
    }
}

