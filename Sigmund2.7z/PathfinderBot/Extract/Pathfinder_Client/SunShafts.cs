﻿using System;
using UnityEngine;

[RequireComponent(typeof(Camera)), AddComponentMenu("Image Effects/Sun Shafts"), ExecuteInEditMode]
internal class SunShafts : PostEffectsBase
{
    public float maxRadius = 0.75f;
    public int radialBlurIterations = 2;
    public SunShaftsResolution resolution = SunShaftsResolution.Normal;
    public ShaftsScreenBlendMode screenBlendMode = ShaftsScreenBlendMode.Screen;
    private Material simpleClearMaterial;
    public Shader simpleClearShader = null;
    public Color sunColor = Color.white;
    public float sunShaftBlurRadius = 2.5f;
    public float sunShaftIntensity = 1.15f;
    private Material sunShaftsMaterial;
    public Shader sunShaftsShader = null;
    public Transform sunTransform = null;
    public bool useDepthTexture = true;
    public float useSkyBoxAlpha = 0.75f;

    public override bool CheckResources()
    {
        base.CheckSupport(this.useDepthTexture);
        this.sunShaftsMaterial = base.CheckShaderAndCreateMaterial(this.sunShaftsShader, this.sunShaftsMaterial);
        this.simpleClearMaterial = base.CheckShaderAndCreateMaterial(this.simpleClearShader, this.simpleClearMaterial);
        if (!base.isSupported)
        {
            base.ReportAutoDisable();
        }
        return base.isSupported;
    }

    private int ClampBlurIterationsToSomethingThatMakesSense(int its)
    {
        if (its < 1)
        {
            return 1;
        }
        if (its > 4)
        {
            return 4;
        }
        return its;
    }

    public void OnRenderImage(RenderTexture source, RenderTexture destination)
    {
        if (!this.CheckResources())
        {
            Graphics.Blit(source, destination);
        }
        else
        {
            if (this.useDepthTexture)
            {
                Camera camera = base.camera;
                camera.depthTextureMode |= DepthTextureMode.Depth;
            }
            float num = 4f;
            if (this.resolution == SunShaftsResolution.Normal)
            {
                num = 2f;
            }
            else if (this.resolution == SunShaftsResolution.High)
            {
                num = 1f;
            }
            Vector3 vector = (Vector3) (Vector3.one * 0.5f);
            if (this.sunTransform != 0)
            {
                vector = base.camera.WorldToViewportPoint(this.sunTransform.position);
            }
            else
            {
                vector = new Vector3(0.5f, 0.5f, 0f);
            }
            RenderTexture dest = RenderTexture.GetTemporary((int) Mathf.Floor(((float) source.width) / num), (int) Mathf.Floor(((float) source.height) / num), 0);
            RenderTexture texture2 = RenderTexture.GetTemporary((int) Mathf.Floor(((float) source.width) / num), (int) Mathf.Floor(((float) source.height) / num), 0);
            this.sunShaftsMaterial.SetVector("_BlurRadius4", (Vector4) (new Vector4(1f, 1f, 0f, 0f) * this.sunShaftBlurRadius));
            this.sunShaftsMaterial.SetVector("_SunPosition", new Vector4(vector.x, vector.y, vector.z, this.maxRadius));
            this.sunShaftsMaterial.SetFloat("_NoSkyBoxMask", 1f - this.useSkyBoxAlpha);
            if (!this.useDepthTexture)
            {
                RenderTexture texture = RenderTexture.GetTemporary(source.width, source.height, 0);
                RenderTexture.active = texture;
                GL.ClearWithSkybox(false, base.camera);
                this.sunShaftsMaterial.SetTexture("_Skybox", texture);
                Graphics.Blit(source, texture2, this.sunShaftsMaterial, 3);
                RenderTexture.ReleaseTemporary(texture);
            }
            else
            {
                Graphics.Blit(source, texture2, this.sunShaftsMaterial, 2);
            }
            base.DrawBorder(texture2, this.simpleClearMaterial);
            this.radialBlurIterations = this.ClampBlurIterationsToSomethingThatMakesSense(this.radialBlurIterations);
            float x = this.sunShaftBlurRadius * 0.001302083f;
            this.sunShaftsMaterial.SetVector("_BlurRadius4", new Vector4(x, x, 0f, 0f));
            this.sunShaftsMaterial.SetVector("_SunPosition", new Vector4(vector.x, vector.y, vector.z, this.maxRadius));
            for (int i = 0; i < this.radialBlurIterations; i++)
            {
                Graphics.Blit(texture2, dest, this.sunShaftsMaterial, 1);
                x = (this.sunShaftBlurRadius * (((i * 2f) + 1f) * 6f)) / 768f;
                this.sunShaftsMaterial.SetVector("_BlurRadius4", new Vector4(x, x, 0f, 0f));
                Graphics.Blit(dest, texture2, this.sunShaftsMaterial, 1);
                x = (this.sunShaftBlurRadius * (((i * 2f) + 2f) * 6f)) / 768f;
                this.sunShaftsMaterial.SetVector("_BlurRadius4", new Vector4(x, x, 0f, 0f));
            }
            if (vector.z >= 0.0)
            {
                this.sunShaftsMaterial.SetVector("_SunColor", (Vector4) (new Vector4(this.sunColor.r, this.sunColor.g, this.sunColor.b, this.sunColor.a) * this.sunShaftIntensity));
            }
            else
            {
                this.sunShaftsMaterial.SetVector("_SunColor", Vector4.zero);
            }
            this.sunShaftsMaterial.SetTexture("_ColorBuffer", texture2);
            Graphics.Blit(source, destination, this.sunShaftsMaterial, (this.screenBlendMode == ShaftsScreenBlendMode.Screen) ? 0 : 4);
            RenderTexture.ReleaseTemporary(texture2);
            RenderTexture.ReleaseTemporary(dest);
        }
    }

    public enum ShaftsScreenBlendMode
    {
        Screen,
        Add
    }

    public enum SunShaftsResolution
    {
        Low,
        Normal,
        High
    }
}

