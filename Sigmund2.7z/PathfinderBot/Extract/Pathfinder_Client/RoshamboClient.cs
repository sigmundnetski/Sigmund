﻿using GNetwork;
using System;
using UnityEngine;

public static class RoshamboClient
{
    public static void AcceptGame(string[] args, EntityId playerEntityId)
    {
        GRouting.SendMyMapRpc(GRpcID.RoshamboServer_AcceptGame, new object[0]);
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void Emote(EntityId entityId, int emoteEnum)
    {
        GConst.RoshamboEmotes emotes = (GConst.RoshamboEmotes) emoteEnum;
        GameObject gameObjectByEntityId = EntityCore.GetGameObjectByEntityId(ref entityId);
        if (gameObjectByEntityId != null)
        {
            EntityVars component = gameObjectByEntityId.GetComponent<EntityVars>();
            PassiveAnimator animator = gameObjectByEntityId.GetComponent<PassiveAnimator>();
            AnimatorStateInfo currentAnimatorStateInfo = gameObjectByEntityId.GetComponent<Animator>().GetCurrentAnimatorStateInfo(0);
            if ((((component != null) && (component.entName == "Goblin")) && (currentAnimatorStateInfo.nameHash == Animator.StringToHash("Base Layer.Idle"))) && (emotes == GConst.RoshamboEmotes.ACCEPT))
            {
                animator.Emote("EmoteConvers03", 2f);
            }
        }
    }

    public static void NewGame(string[] args, EntityId playerEntityId)
    {
        EntityId selectedEntityId = Targeting.selectedEntityId;
        if (selectedEntityId == EntityId.INVALID_ID)
        {
            ChatGui.singleton.DisplayMessage("Target the person you want to play against.", ChatClient.DEBUG_COLOR);
        }
        else
        {
            GRouting.SendMyMapRpc(GRpcID.RoshamboServer_NewGame, new object[] { selectedEntityId });
        }
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void ReceiveMessage(string msg)
    {
        ChatGui.singleton.DisplayMessage(msg, ChatClient.DEBUG_COLOR);
    }

    public static void Throw(string[] args, EntityId playerEntityId)
    {
        GConst.RoshamboOptions pAPER;
        string str = args[0];
        if (str != null)
        {
            if (!(str == "rock"))
            {
                if (str == "paper")
                {
                    pAPER = GConst.RoshamboOptions.PAPER;
                    goto Label_0058;
                }
                if (str == "scissors")
                {
                    pAPER = GConst.RoshamboOptions.SCISSORS;
                    goto Label_0058;
                }
            }
            else
            {
                pAPER = GConst.RoshamboOptions.START;
                goto Label_0058;
            }
        }
        ChatGui.singleton.DisplayMessage("Unknown Rock, Paper, Scissors choice. Oops.", ChatClient.DEBUG_COLOR);
        return;
    Label_0058:;
        GRouting.SendMyMapRpc(GRpcID.RoshamboServer_Throw, new object[] { (int) pAPER });
    }
}

