﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

public class FeatSlotGui : SlotGui
{
    public int featId = 0;
    public int featIndex = -1;
    public Combat.FeatType featType = Combat.FeatType.None;

    public void Assign(Combat.FeatType featType_, int featIndex_)
    {
        this.featType = featType_;
        this.featIndex = featIndex_;
    }

    public void EquipFeat(int featId_, Combat.FeatType featType_)
    {
        if (this.featType == featType_)
        {
            this.featId = featId_;
            this.SetIcon();
        }
    }

    public bool IsValid(int[] slotFilters)
    {
        bool flag = false;
        if (slotFilters != null)
        {
            for (int i = 0; i < slotFilters.Length; i++)
            {
                flag = flag || (this.featType == ((byte) slotFilters[i]));
            }
        }
        return flag;
    }

    public void OnDrag(Vector2 delta)
    {
        if ((this.featId != 0) && !base.isBeingDragged)
        {
            base.isBeingDragged = true;
            PaperdollWindowGui.singleton.DragStart(this.featType);
            base.dragScript.target = base.icon.transform;
        }
    }

    public void OnDrop(GameObject draggedObject)
    {
        FeatGridItem component = draggedObject.GetComponent<FeatGridItem>();
        FeatSlotGui gui = draggedObject.GetComponent<FeatSlotGui>();
        Combat.FeatType none = Combat.FeatType.None;
        int newFeatId = 0;
        if ((component != null) || (gui != null))
        {
            if (component != null)
            {
                none = component.featType;
                newFeatId = component.featId;
            }
            else if (gui != null)
            {
                if ((gui.featType == this.featType) && (gui.featIndex == this.featIndex))
                {
                    return;
                }
                none = gui.featType;
                newFeatId = gui.featId;
            }
            if (none == this.featType)
            {
                PaperdollWindowGui.singleton.FeatSlotChange(this.featId, newFeatId, this.featType);
            }
        }
    }

    public void OnPress(bool isPressed)
    {
        if (!(isPressed || !base.isBeingDragged))
        {
            base.isBeingDragged = false;
            base.icon.gameObject.transform.localPosition = Vector3.zero;
            PaperdollWindowGui.singleton.DragEnd(base.gameObject, this.featType, this.featId);
        }
    }

    public void OnTooltip(bool show)
    {
        if (this.featId != 0)
        {
            base.showingTooltip = show;
            if (!show)
            {
                PaperdollWindowGui.singleton.ShowTooltip(null, null);
            }
            else
            {
                StringBuilder quickText = GUtil.GetQuickText();
                CombatClient.AppendFeatTooltip(quickText, this.featId, 0, true);
                PaperdollWindowGui.singleton.ShowTooltip(quickText.ToString(), base.gameObject);
            }
        }
    }

    protected override void SetIcon()
    {
        if (this.featId != 0)
        {
            NonAttackFeatData featById = NonAttackFeatData.GetFeatById(this.featId);
            base.icon.spriteName = featById.icon;
            base.icon.MakePixelPerfect();
            base.icon.color = SlotGui.doShowColor;
        }
    }

    public void SetValidity(int[] slotFilters)
    {
        base.SetValidity(this.IsValid(slotFilters));
    }

    public void SetValidity(Combat.FeatType featType_)
    {
        base.SetValidity(this.featType == featType_);
    }

    public void UnequipFeat()
    {
        this.featId = 0;
        base.ResetIcon();
    }

    public void UpdateFeat()
    {
        CombatVars playerCombatVars = CombatClient.playerCombatVars;
        if (playerCombatVars != null)
        {
            List<NonAttackFeatData> list = new List<NonAttackFeatData>();
            int[] passiveFeatIds = playerCombatVars.combatClass.passiveFeatIds;
            for (int i = 0; i < passiveFeatIds.Length; i++)
            {
                if (passiveFeatIds[i] != 0)
                {
                    NonAttackFeatData featById = NonAttackFeatData.GetFeatById(passiveFeatIds[i]);
                    if (featById.type == this.featType)
                    {
                        list.Add(featById);
                    }
                }
            }
            if ((this.featIndex < 0) || (list.Count < (this.featIndex + 1)))
            {
                this.UnequipFeat();
            }
            else
            {
                NonAttackFeatData data2 = list[this.featIndex];
                if (data2.id != this.featId)
                {
                    this.EquipFeat(data2.id, data2.type);
                }
            }
        }
    }
}

