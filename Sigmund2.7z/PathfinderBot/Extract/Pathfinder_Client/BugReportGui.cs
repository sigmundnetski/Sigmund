﻿using GNetwork;
using GNGUI;
using System;
using System.Collections.Generic;
using UnityEngine;

public class BugReportGui : WindowGui
{
    private string[] categoryDisplay = new string[] { "Bug", "Report Player", "GM Assistance", "Question About Game" };
    private UIPopupListKvp categoryOptions;
    private const string DEFAULT_INPUT_TEXT = "Type here.";
    private const int MAX_BUG_REPORT_LENGTH = 0x3e8;
    public static BugReportGui singleton;
    private const string SUBMIT_MESSAGE = "Thanks!";
    private UIImageButton submitButton;
    private UILabel submitMessage;
    private UIInput textField;

    public void Awake()
    {
        singleton = this;
    }

    public override void HideWindow()
    {
        NGUITools.SetActive(this.submitMessage.gameObject, false);
        base.HideWindow();
    }

    public override void OnDestroy()
    {
        base.OnDestroy();
        singleton = null;
    }

    public void SelectInput(GameObject go, bool selected)
    {
        if (selected)
        {
            NGUITools.SetActive(this.submitMessage.gameObject, false);
        }
    }

    public override void ShowWindow()
    {
        NGUITools.SetActive(this.submitMessage.gameObject, false);
        base.ShowWindow();
    }

    public void Start()
    {
        this.textField = base.GetComponentInChildren<UIInput>();
        foreach (UIImageButton button in base.GetComponentsInChildren<UIImageButton>())
        {
            if (button.name == "SubmitButton")
            {
                this.submitButton = button;
            }
        }
        foreach (UILabel label in base.GetComponentsInChildren<UILabel>())
        {
            if (label.name == "SubmitConfirmLabel")
            {
                this.submitMessage = label;
            }
        }
        foreach (UIPopupListKvp kvp in base.GetComponentsInChildren<UIPopupListKvp>())
        {
            if (kvp.name == "CategoryList")
            {
                this.categoryOptions = kvp;
            }
        }
        GuiHelper.GuiAssertNotNull("Could not find needed children.", new object[] { this.textField, this.submitButton, this.submitMessage, this.categoryOptions });
        UIEventListener listener1 = UIEventListener.Get(this.submitButton.gameObject);
        listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.SubmitBug));
        UIEventListener listener2 = UIEventListener.Get(this.textField.gameObject);
        listener2.onSelect = (UIEventListener.BoolDelegate) Delegate.Combine(listener2.onSelect, new UIEventListener.BoolDelegate(this.SelectInput));
        this.textField.label.text = string.Empty;
        this.textField.maxChars = 0x3e8;
        this.textField.defaultText = "Type here.";
        this.textField.text = string.Empty;
        NGUITools.SetActive(this.submitMessage.gameObject, false);
        this.submitMessage.text = "Thanks!";
        Dictionary<int, string> elements = new Dictionary<int, string>();
        for (int i = 0; i < this.categoryDisplay.Length; i++)
        {
            elements[i] = this.categoryDisplay[i];
        }
        this.categoryOptions.UpdateElements(elements);
        this.categoryOptions.SetSelectionToKey(0);
        base.Init(2, true);
    }

    public void SubmitBug(GameObject go)
    {
        string str = this.textField.text.Trim();
        if (str.Length > 0x3e8)
        {
            str = str.Substring(0, 0x3e8);
        }
        GConst.BugCategory selectedKey = (GConst.BugCategory) ((byte) this.categoryOptions.selectedKey);
        if (string.IsNullOrEmpty(str))
        {
            this.textField.text = string.Empty;
        }
        else
        {
            Vector3 position = GConst.VECTOR3_INVALID;
            Quaternion identity = Quaternion.identity;
            GameObject player = PlayerEntityClient.GetPlayer();
            if (player != null)
            {
                position = player.transform.position;
                identity = player.transform.rotation;
            }
            GRouting.SendMyMapRpc(GRpcID.BugReportServer_SendReport, new object[] { TerrainService.CalculateCurrentMapId, position, identity, str, (byte) selectedKey });
            this.textField.text = string.Empty;
            NGUITools.SetActive(this.submitMessage.gameObject, true);
        }
    }
}

