﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;

public class BipedMap : MonoBehaviour
{
    private Dictionary<string, Transform> map;

    public void AssignVars(Dictionary<string, Transform> _map)
    {
        this.map = _map;
    }

    public Dictionary<string, Transform> GetMap()
    {
        return this.map;
    }

    public bool TryGetValue(string key, out Transform value)
    {
        value = null;
        if (this.map == null)
        {
            return false;
        }
        return this.map.TryGetValue(key, out value);
    }
}

