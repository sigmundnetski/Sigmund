﻿using System;
using System.Runtime.CompilerServices;
using UnityEngine;

public class UnityEditorTick : Ticker.TickBase
{
    public static GUtil.BoolFilterDelegate inputLoadFinish = new GUtil.BoolFilterDelegate(ClientInputManager.LoadingTickFinished);
    public GameObject playerSpawnPoint = null;
    private SpawnPlayerCallback spawnPlayerCallback;

    public UnityEditorTick(GameObject root, SpawnPlayerCallback callback)
    {
        this.playerSpawnPoint = root;
        this.spawnPlayerCallback = callback;
        EntityClient.playerProxyParent = root.transform;
        base.fixedUpdateFunctions.Add(new Ticker.FixedUpdateTickFunction(this.StartServices));
        base.updateFunctions.Add(null);
        base.fixedUpdateFunctions.Add(new Ticker.FixedUpdateTickFunction(this.LoadingTick));
        base.updateFunctions.Add(null);
        base.fixedUpdateFunctions.Add(new Ticker.FixedUpdateTickFunction(this.ExtractBundles));
        base.updateFunctions.Add(null);
        base.fixedUpdateFunctions.Add(new Ticker.FixedUpdateTickFunction(this.MakeGoblinCamera));
        base.updateFunctions.Add(null);
        base.fixedUpdateFunctions.Add(new Ticker.FixedUpdateTickFunction(this.LoadingTickFinished));
        base.updateFunctions.Add(null);
        base.fixedUpdateFunctions.Add(new Ticker.FixedUpdateTickFunction(this.SetupInputManager));
        base.updateFunctions.Add(null);
        base.fixedUpdateFunctions.Add(new Ticker.FixedUpdateTickFunction(this.WaitForPlayer));
        base.updateFunctions.Add(null);
        base.fixedUpdateFunctions.Add(new Ticker.FixedUpdateTickFunction(this.SyncFixedUpdate));
        base.updateFunctions.Add(new Ticker.UpdateTickFunction(this.SyncUpdate));
    }

    private void AddMovementComponent(GameObject newCharacter, GConst.CreateType flags)
    {
        GrannyAnimator component = newCharacter.GetComponent<GrannyAnimator>();
        if (component != null)
        {
            component.cullingMode = AnimatorCullingMode.AlwaysAnimate;
            if (flags == GConst.CreateType.PLAYER)
            {
                newCharacter.AddComponent<EntityMotion>();
            }
            else
            {
                newCharacter.AddComponent<PassiveAnimator>();
            }
        }
    }

    private bool ExtractBundles()
    {
        GUtil.FilterExceptions(typeof(EntityLoadClient), "ExtractBundles", new object[0]);
        GUtil.FilterExceptions(typeof(UIClient), "ExtractBundles", new object[0]);
        return true;
    }

    private bool LoadingTick()
    {
        bool flag = true;
        flag = ((bool) GUtil.FilterExceptions(typeof(StaticDataService), "LoadingTick", new object[0])) && flag;
        flag = ((bool) GUtil.FilterExceptions(typeof(ResourceManager), "LoadingTick", new object[0])) && flag;
        flag = ((bool) GUtil.FilterExceptions(typeof(BundleService), "SyncFixedUpdate", new object[0])) && flag;
        flag = ((bool) GUtil.FilterExceptions(typeof(PlayerEntityClient), "LoadingTick", new object[0])) && flag;
        flag = ((bool) GUtil.FilterExceptions(typeof(CombatCore), "LoadingTick", new object[0])) && flag;
        return (((bool) GUtil.FilterExceptions(typeof(SceneService), "SyncFixedUpdate", new object[0])) && flag);
    }

    private bool LoadingTickFinished()
    {
        GUtil.FilterExceptions(typeof(CombatCore), "LoadingTickFinished", new object[0]);
        GUtil.FilterExceptions(typeof(CommandClient), "LoadingTickFinished", new object[0]);
        return true;
    }

    private bool MakeGoblinCamera()
    {
        if (GraphicsClient.goblinCamera == null)
        {
            GameObject original = UIClient.guiPrefabs["GoblinCamera"];
            GraphicsClient.goblinCamera = (GameObject) UnityEngine.Object.Instantiate(original, this.playerSpawnPoint.transform.position, this.playerSpawnPoint.transform.rotation);
        }
        return (ClientInputManager.singleton != null);
    }

    protected override void OnTickDestroyed()
    {
        GUtil.FilterExceptions(typeof(StaticDataService), "Shutdown", new object[0]);
        GUtil.FilterExceptions(typeof(SlavedProxyClient), "Shutdown", new object[0]);
    }

    private bool SetupInputManager()
    {
        GUtil.FilterExceptions(inputLoadFinish, "ClientInputManager.LoadingTickFinished");
        this.spawnPlayerCallback();
        return true;
    }

    protected bool StartServices()
    {
        ServiceList.StartOnce(typeof(StaticDataService), new object[] { true });
        ServiceList.StartOnce(typeof(CombatCore), new object[0]);
        ServiceList.StartOnce(typeof(UIClient), new object[0]);
        EntityLoadClient.RegisterAddComponentDelegates(new EntityLoadClient.AddEntityComponentsDelegate(this.AddMovementComponent));
        ServiceList.StartOnce(typeof(EntityLoadClient), new object[0]);
        ServiceList.StartOnce(typeof(MergeJobService), new object[0]);
        PlayerEntityClient.playerParent = this.playerSpawnPoint.transform;
        ServiceList.StartOnce(typeof(SlavedProxyClient), new object[0]);
        ServiceList.StartOnce(typeof(CommandClient), new object[0]);
        return true;
    }

    private bool SyncFixedUpdate()
    {
        GUtil.FilterExceptions(typeof(StaticDataService), "SyncFixedUpdate", new object[0]);
        GUtil.FilterExceptions(EntityMotion.singleton, "SyncFixedUpdate", new object[0]);
        GUtil.FilterExceptions(typeof(PlayerEntityClient), "SyncFixedUpdate", new object[0]);
        GUtil.FilterExceptions(typeof(BundleService), "SyncFixedUpdate", new object[0]);
        GUtil.FilterExceptions(typeof(SlavedProxyClient), "SyncFixedUpdate", new object[0]);
        return false;
    }

    private void SyncUpdate()
    {
        GUtil.FilterExceptions(ClientInputManager.singleton, "SyncUpdate", new object[0]);
        GUtil.FilterExceptions(typeof(MergeJobService), "SyncUpdate", new object[0]);
    }

    private bool WaitForPlayer()
    {
        return (null != PlayerEntityClient.GetPlayer());
    }

    public delegate void SpawnPlayerCallback();
}

