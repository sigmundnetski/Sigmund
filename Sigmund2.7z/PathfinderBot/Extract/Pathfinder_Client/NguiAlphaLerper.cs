﻿using GNGUI;
using System;
using UnityEngine;

public class NguiAlphaLerper
{
    public float duration;
    public float from;
    public GameObject[] ignored;
    private const float LERP_EPSILON = 1E-06f;
    public GameObject parent;
    public float startTime;
    public float to;
    public UIWidget[] widgets;

    public NguiAlphaLerper(GameObject parent_, float from_, float to_, float duration_, GameObject[] ignored_)
    {
        this.parent = parent_;
        this.from = from_;
        this.to = to_;
        this.duration = duration_;
        this.startTime = Time.time;
        this.ignored = (ignored_ == null) ? new GameObject[0] : ignored_;
        this.widgets = this.parent.GetComponentsInChildren<UIWidget>(true);
        for (int i = 0; i < this.widgets.Length; i++)
        {
            for (int j = 0; j < this.ignored.Length; j++)
            {
                if (this.widgets[i].gameObject == this.ignored[j])
                {
                    this.widgets[i] = null;
                }
            }
            if (this.widgets[i] != null)
            {
                this.widgets[i].alpha = this.from;
                NGUITools.SetActive(this.widgets[i].gameObject, true);
            }
        }
    }

    public bool NearlyEqual(float a, float b, float epsilon)
    {
        float num = Mathf.Abs((float) (a - b));
        if (a == b)
        {
            return true;
        }
        if (((a == 0f) || (b == 0f)) || (num < float.MinValue))
        {
            return (num < (epsilon * float.MinValue));
        }
        return ((num / (Mathf.Abs(a) + Mathf.Abs(b))) < epsilon);
    }

    public bool Update()
    {
        float a = Mathf.Lerp(this.from, this.to, (Time.time - this.startTime) / this.duration);
        for (int i = 0; i < this.widgets.Length; i++)
        {
            if (this.widgets[i] != null)
            {
                this.widgets[i].alpha = a;
                if (this.NearlyEqual(a, 0f, 1E-06f))
                {
                    NGUITools.SetActive(this.widgets[i].gameObject, false);
                }
            }
        }
        return this.NearlyEqual(this.to, a, 1E-06f);
    }
}

