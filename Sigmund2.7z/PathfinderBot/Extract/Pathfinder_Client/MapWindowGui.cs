﻿using GNGUI;
using System;
using System.Runtime.InteropServices;
using UnityEngine;

public class MapWindowGui : WindowGui
{
    private Tabs activeTab = Tabs.WORLD_MAP;
    private UIPanel clippingPanel;
    private UIPanel mapIconPanel;
    private GameObject mapIconParent;
    private GameObject mapIconPrefab;
    private Rect mapRect;
    public Texture[] mapTextures;
    public static MapWindowGui singleton;
    private MapWindowTabGui[] tabs = new MapWindowTabGui[2];
    private UIImageButton zoomInButton;
    private UIImageButton zoomOutButton;

    public void AddMapPin(GameObject go)
    {
        this.tabs[(int) this.activeTab].AddMapPin();
    }

    public void Awake()
    {
        singleton = this;
        this.OnAwake();
    }

    public void CommandEvent(string[] args, EntityId playerEntityId)
    {
        this.ToggleWindowVisibility();
    }

    private void DragMap(GameObject go, Vector2 delta)
    {
        this.tabs[(int) this.activeTab].DragMap(delta);
    }

    public override void HideWindow()
    {
        UITooltip.ShowText(null, null);
        base.HideWindow();
    }

    public bool LoadingTickFinished()
    {
        this.mapIconPrefab = UIClient.guiPrefabs["MapItem"];
        GuiHelper.GuiAssertNotNull("Couldn't load prefabs.", new object[] { this.mapIconPrefab });
        foreach (UIPanel panel in base.GetComponentsInChildren<UIPanel>())
        {
            if (panel.name == "ClippingPanel")
            {
                this.clippingPanel = panel;
            }
            if (panel.name == "ForegroundPanel")
            {
                this.mapIconPanel = panel;
            }
        }
        UITexture texture = null;
        UITexture texture2 = null;
        foreach (UITexture texture3 in base.GetComponentsInChildren<UITexture>())
        {
            if (texture3.name == "WorldMap")
            {
                texture = texture3;
            }
            else if (texture3.name == "SettlementMap")
            {
                texture2 = texture3;
            }
        }
        this.mapIconParent = this.mapIconPanel.transform.Find("MapIconParent").gameObject;
        UIImageButton button = null;
        UIImageButton button2 = null;
        foreach (UIImageButton button3 in base.GetComponentsInChildren<UIImageButton>())
        {
            if (button3.name == "ZoomIn")
            {
                this.zoomInButton = button3;
            }
            else if (button3.name == "ZoomOut")
            {
                this.zoomOutButton = button3;
            }
            else if (button3.name == "ButtonWorldMap")
            {
                button = button3;
            }
            else if (button3.name == "ButtonSettlement")
            {
                button2 = button3;
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find needed children.", new object[] { this.clippingPanel, texture, texture2, this.zoomInButton, this.zoomOutButton, button, button2, this.mapIconPanel, this.mapIconParent });
        UIEventListener listener1 = UIEventListener.Get(this.zoomInButton.gameObject);
        listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.ZoomIn));
        UIEventListener listener2 = UIEventListener.Get(this.zoomOutButton.gameObject);
        listener2.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener2.onClick, new UIEventListener.VoidDelegate(this.ZoomOut));
        UIEventListener listener3 = UIEventListener.Get(button.gameObject);
        listener3.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener3.onClick, new UIEventListener.VoidDelegate(this.WorldMapClick));
        UIEventListener listener4 = UIEventListener.Get(button2.gameObject);
        listener4.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener4.onClick, new UIEventListener.VoidDelegate(this.SettlementClick));
        UIEventListener listener5 = UIEventListener.Get(this.clippingPanel.gameObject);
        listener5.onDrag = (UIEventListener.VectorDelegate) Delegate.Combine(listener5.onDrag, new UIEventListener.VectorDelegate(this.DragMap));
        UIEventListener listener6 = UIEventListener.Get(this.clippingPanel.gameObject);
        listener6.onDoubleClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener6.onDoubleClick, new UIEventListener.VoidDelegate(this.AddMapPin));
        Transform transform = this.clippingPanel.transform.Find("TopLeft");
        Transform transform2 = this.clippingPanel.transform.Find("BottomRight");
        GuiHelper.GuiAssertNotNull("Couldn't find needed children.", new object[] { transform, transform2 });
        Vector3 localPosition = transform.localPosition;
        Vector3 vector2 = transform2.localPosition;
        this.mapRect = new Rect(localPosition.x, localPosition.y, vector2.x - localPosition.x, localPosition.y - vector2.y);
        this.tabs[0] = new WorldMapTabGui();
        this.tabs[0].Init(texture, button, this.mapIconPrefab, this.mapIconParent, this.mapRect, this.clippingPanel);
        this.tabs[1] = new SettlementMapTabGui();
        this.tabs[1].Init(texture2, button2, this.mapIconPrefab, this.mapIconParent, this.mapRect, this.clippingPanel);
        this.ShowTab();
        base.Init(2, true);
        if (this.mapTextures == null)
        {
            this.mapTextures = new Texture[0];
        }
        return true;
    }

    private void OnAwake()
    {
        ClientTick.worldMapGuiLoadFinish = new GUtil.BoolFilterDelegate(this.LoadingTickFinished);
        ClientTick.worldMapGuiTick = new GUtil.BoolFilterDelegate(this.SyncUpdate);
    }

    public override void OnDestroy()
    {
        base.OnDestroy();
        singleton = null;
    }

    public void OnMapTransfer(ushort mapId)
    {
        HexData data = null;
        HexTypeData data2 = null;
        Texture mapTexture = null;
        if ((HexData.dataByMapId.TryGetValue(mapId, out data) && HexTypeData.typeById.TryGetValue(data.hexTypeId, out data2)) && this.TryGetTexture(data, out mapTexture))
        {
            this.SetHexInfo(data, data2, mapTexture);
        }
        else
        {
            this.ResetHexInfo();
        }
    }

    private void OnTabChange(Tabs newTab)
    {
        if (this.activeTab != newTab)
        {
            this.activeTab = newTab;
            this.ShowTab();
        }
    }

    public void ResetHexInfo()
    {
        if (this.activeTab == Tabs.SETTLEMENT_MAP)
        {
            this.OnTabChange(Tabs.WORLD_MAP);
        }
        this.tabs[1].Enabled(false);
    }

    public void SetHexInfo(HexData hex, HexTypeData hexType, Texture mapTexture)
    {
        if ((hexType.name == "settlement") && (mapTexture != null))
        {
            this.tabs[1].Enabled(true);
            this.tabs[1].MapTexture(mapTexture);
        }
        else
        {
            this.ResetHexInfo();
        }
    }

    public void SettlementClick(GameObject ignored)
    {
        this.OnTabChange(Tabs.SETTLEMENT_MAP);
    }

    private void ShowTab()
    {
        for (int i = 0; i < this.tabs.Length; i++)
        {
            if (i == this.activeTab)
            {
                this.tabs[i].ShowTab();
            }
            else
            {
                this.tabs[i].HideTab();
            }
        }
    }

    public bool SyncUpdate()
    {
        if (base.IsShowing() && (EntityDataClient.owner != null))
        {
            this.tabs[(int) this.activeTab].SyncUpdate();
        }
        return true;
    }

    private bool TryGetTexture(HexData hex, out Texture mapTexture)
    {
        mapTexture = null;
        if (!string.IsNullOrEmpty(hex.mapTexture))
        {
            for (int i = 0; i < this.mapTextures.Length; i++)
            {
                if (hex.mapTexture == this.mapTextures[i].name)
                {
                    mapTexture = this.mapTextures[i];
                    return true;
                }
            }
        }
        return false;
    }

    public void WorldMapClick(GameObject ignored)
    {
        this.OnTabChange(Tabs.WORLD_MAP);
    }

    public void ZoomIn(GameObject buttonGO)
    {
        this.tabs[(int) this.activeTab].ZoomIn();
    }

    public void ZoomOut(GameObject buttonGO)
    {
        this.tabs[(int) this.activeTab].ZoomOut();
    }

    private enum Tabs
    {
        WORLD_MAP,
        SETTLEMENT_MAP,
        NUM_TABS
    }
}

