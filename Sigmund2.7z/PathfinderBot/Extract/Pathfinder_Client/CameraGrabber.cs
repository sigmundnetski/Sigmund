﻿using System;
using UnityEngine;

public class CameraGrabber : MonoBehaviour
{
    private bool initialized = false;

    private void FixedUpdate()
    {
        this.Init();
    }

    private void Init()
    {
        if ((!this.initialized && (CustomCamera.singleton != null)) && (EntityMotion.singleton != null))
        {
            CustomCamera.singleton.Init(base.transform);
            this.initialized = true;
        }
    }

    private void Start()
    {
        this.Init();
    }
}

