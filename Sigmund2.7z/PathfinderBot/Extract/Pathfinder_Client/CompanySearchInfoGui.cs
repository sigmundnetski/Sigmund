﻿using GNGUI;
using System;
using System.Collections.Generic;
using UnityEngine;

public class CompanySearchInfoGui : MonoBehaviour
{
    private UILabel alignmentLabel;
    private ulong companyId;
    private UILabel holdingsLabel;
    private UILabel nameLabel;
    private UILabel repLabel;
    private UILabel settlementLabel;
    private UILabel sizeLabel;
    public string sortAlignment;
    public int sortHoldings;
    public string sortName;
    public float sortRep;
    public int sortSize;

    public void Assign(VentureCompanyRecord company)
    {
        List<GroupClient.TerritoryClientVars> list;
        this.companyId = company.companyId;
        bool flag = GroupClient.OwnsSettlement(company);
        this.nameLabel.text = company.vcName + (flag ? "  *" : string.Empty);
        this.sortName = company.vcName;
        int num = company.Count(false);
        this.sizeLabel.text = num.ToString();
        this.sortSize = num;
        int count = 0;
        if (GroupClient.settlementTerritories.TryGetValue(company.settlementId, out list))
        {
            if (flag)
            {
                count = list.Count;
            }
            else
            {
                for (int i = 0; i < list.Count; i++)
                {
                    count += (list[i].companyId == company.companyId) ? 1 : 0;
                }
            }
        }
        this.holdingsLabel.text = count.ToString();
        this.sortHoldings = count;
        this.settlementLabel.text = company.settlementName;
        this.sortRep = company.reputation;
        switch (PvpConst.GetReputationLevel(company.reputation))
        {
            case PvpConst.Reputation.HOSTILE:
                this.repLabel.text = "Hostile";
                break;

            case PvpConst.Reputation.UNFRIENDLY:
                this.repLabel.text = "Unfriendly";
                break;

            case PvpConst.Reputation.INDIFFERENT:
                this.repLabel.text = "Indifferent";
                break;

            case PvpConst.Reputation.FRIENDLY:
                this.repLabel.text = "Friendly";
                break;

            case PvpConst.Reputation.HELPFUL:
                this.repLabel.text = "Helpful";
                break;

            default:
                this.repLabel.text = "Unknown";
                break;
        }
        this.sortAlignment = "na";
    }

    public void Awake()
    {
        foreach (UILabel label in base.GetComponentsInChildren<UILabel>())
        {
            if (label.name == "Name")
            {
                this.nameLabel = label;
            }
            else if (label.name == "Settlement")
            {
                this.settlementLabel = label;
            }
            else if (label.name == "Size")
            {
                this.sizeLabel = label;
            }
            else if (label.name == "Alignment")
            {
                this.alignmentLabel = label;
            }
            else if (label.name == "Holdings")
            {
                this.holdingsLabel = label;
            }
            else if (label.name == "Reputation")
            {
                this.repLabel = label;
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find label.", new object[] { this.nameLabel, this.sizeLabel, this.alignmentLabel, this.repLabel, this.holdingsLabel });
        NGUITools.SetActive(this.alignmentLabel.gameObject, false);
    }

    public void OnClick()
    {
        CompanyWindowGui.singleton.DisplayCompany(this.companyId);
    }

    public void OnTooltip(bool show)
    {
        VentureCompanyRecord record = null;
        for (int i = 0; i < GroupClient.lastSearchResult.Length; i++)
        {
            if ((GroupClient.lastSearchResult[i] != null) && (GroupClient.lastSearchResult[i].companyId == this.companyId))
            {
                record = GroupClient.lastSearchResult[i];
            }
        }
        if (record != null)
        {
            CompanySearchWindowGui.singleton.ShowTooltip(record.recruitment, base.gameObject);
        }
    }
}

