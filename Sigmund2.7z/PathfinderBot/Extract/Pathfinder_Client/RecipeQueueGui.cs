﻿using GNGUI;
using System;
using System.Collections.Generic;
using UnityEngine;

public class RecipeQueueGui : MonoBehaviour
{
    private UIGrid grid;
    private List<RecipeQueueElement> queueElements = new List<RecipeQueueElement>();
    private GameObject recipeQueuePrefab;

    public void Repopulate()
    {
        if (this.recipeQueuePrefab == null)
        {
            this.recipeQueuePrefab = UIClient.guiPrefabs["RecipeQueueElement"];
        }
        if (this.grid == null)
        {
            this.grid = base.GetComponent<UIGrid>();
        }
        CraftingQueue[] craftingQueue = EntityDataClient.owner.playerRecord.craftingQueue;
        int count = 0;
        if (craftingQueue != null)
        {
            count = SparseArray.Count<CraftingQueue>(craftingQueue, CraftingQueue.EMPTY_MATCH);
        }
        UIGrid.SetElementCount<RecipeQueueElement>(DragDropRoot.root, this.grid, this.recipeQueuePrefab, this.queueElements, count);
        if (craftingQueue != null)
        {
            int num2 = 0;
            for (int i = 0; i < craftingQueue.Length; i++)
            {
                if (!CraftingQueue.EMPTY_MATCH(craftingQueue[i]))
                {
                    this.queueElements[num2].SetData(num2 == 0, i, craftingQueue[i]);
                    num2++;
                }
            }
        }
    }

    public void SyncUpdate()
    {
        for (int i = 0; i < this.queueElements.Count; i++)
        {
            this.queueElements[i].SyncUpdate();
        }
    }
}

