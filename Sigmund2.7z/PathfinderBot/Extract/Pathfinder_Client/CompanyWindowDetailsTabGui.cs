﻿using GNGUI;
using System;
using System.Collections.Generic;
using UnityEngine;

public class CompanyWindowDetailsTabGui : CompanyWindowTabGui
{
    private Tabs activeTab = Tabs.MEMBERS;
    private UILabel affiliation;
    private UILabel alignAndRep;
    private List<SortButton> allSorts = new List<SortButton>();
    private CompanyDetailsTabGui[] allTabs = new CompanyDetailsTabGui[2];
    private UIImageButton approveButton;
    private UILabel companyName;
    private SortButton currentSort = null;
    private List<CompanyDetailsGoalGui> displayedGoals = new List<CompanyDetailsGoalGui>();
    private List<CompanyMemberInfoGui> displayedItems = new List<CompanyMemberInfoGui>();
    private EditSaveAction editSaveAction = EditSaveAction.NONE;
    private UIImageButton editSaveButton;
    private UILabel editSaveLabel;
    private GameObject goalPrefab = null;
    private UIGrid goalsGrid;
    private UILabel goalsLabel;
    private UIImageButton inspectButton;
    private JoinLeaveAction joinLeaveAction = JoinLeaveAction.NONE;
    private UIImageButton joinLeaveButton;
    private UILabel joinLeaveLabel;
    private UIImageButton kickButton;
    private UIGrid leadersGrid;
    public static Color NEGATIVE_TEXT = new Color(0.9607843f, 0.4f, 0.2078431f);
    public static Color playerDefaultColor = new Color(0.9411765f, 0.8901961f, 0.6588235f);
    private GameObject playerInfoPrefab = null;
    public static Color playerSelectedColor = new Color(1f, 1f, 1f);
    public static Color POSITIVE_TEXT = new Color(0.9411765f, 0.8901961f, 0.6588235f);
    private UIImageButton promoteButton;
    private UIInput recruitment;
    private UISprite recruitmentBg;
    private UIImageButton refreshButton;
    private UIImageButton searchButton;
    private string selectedPlayer;
    public static CompanyWindowDetailsTabGui singleton;
    private UIInput statement;
    private UISprite statementBg;

    public void ApplicantsTabSelected(GameObject go)
    {
        Tabs activeTab = this.activeTab;
        this.activeTab = Tabs.APPLICANTS;
        if (this.activeTab != activeTab)
        {
            this.ShowSubtab();
        }
    }

    public void ApproveClicked(GameObject go)
    {
        VentureCompanyRecord company = GroupClient.GetCompany(CompanyWindowGui.companyId);
        if ((company != null) && !string.IsNullOrEmpty(this.selectedPlayer))
        {
            CommandCore.ExecuteCommand("VcInvite " + company.vcName + ", " + this.selectedPlayer, PlayerEntityClient.GetPlayerEntityId());
        }
    }

    public void Awake()
    {
        singleton = this;
        this.OnAwake();
    }

    public override void DisplayCompany()
    {
        VentureCompanyRecord company = GroupClient.GetCompany(CompanyWindowGui.companyId);
        if (company != null)
        {
            this.SetInfo(company);
            this.MakeLeaders(company);
            foreach (CompanyDetailsTabGui gui in this.allTabs)
            {
                gui.DisplayCompany(CompanyWindowGui.companyId);
            }
            if (!CompanyWindowGui.singleton.IsShowing())
            {
                CompanyWindowGui.singleton.DetailsTabClicked(base.gameObject);
                CompanyWindowGui.singleton.ShowWindow();
            }
        }
    }

    public void EditSaveClicked(GameObject go)
    {
        VentureCompanyRecord company = GroupClient.GetCompany(CompanyWindowGui.companyId);
        if (company != null)
        {
            if (this.editSaveAction == EditSaveAction.EDIT)
            {
                this.statement.enabled = true;
                this.recruitment.enabled = true;
                NGUITools.SetActive(this.recruitmentBg.gameObject, true);
                NGUITools.SetActive(this.statementBg.gameObject, true);
                this.editSaveLabel.text = "Save";
                this.editSaveAction = EditSaveAction.SAVE;
            }
            else if (this.editSaveAction == EditSaveAction.SAVE)
            {
                CommandCore.ExecuteCommand("VcStatement " + company.vcName + ", " + this.statement.text, PlayerEntityClient.GetPlayerEntityId());
                CommandCore.ExecuteCommand("VcRecruitMessage " + company.vcName + ", " + this.recruitment.text, PlayerEntityClient.GetPlayerEntityId());
                this.statement.enabled = false;
                this.recruitment.enabled = false;
                NGUITools.SetActive(this.recruitmentBg.gameObject, false);
                NGUITools.SetActive(this.statementBg.gameObject, false);
                this.editSaveLabel.text = "Edit";
                this.editSaveAction = EditSaveAction.EDIT;
            }
        }
    }

    public CompanyDetailsTabGui GetActiveTab()
    {
        return this.allTabs[(int) this.activeTab];
    }

    public override void HideTab()
    {
        base.HideTab();
        this.GetActiveTab().HideTab();
    }

    public void InspectClicked(GameObject go)
    {
    }

    public void JoinLeaveClicked(GameObject go)
    {
        VentureCompanyRecord company = GroupClient.GetCompany(CompanyWindowGui.companyId);
        if (company != null)
        {
            if (this.joinLeaveAction == JoinLeaveAction.JOIN)
            {
                if ((GroupClient.companyInvite != null) && (GroupClient.companyInvite.companyId == company.companyId))
                {
                    CommandCore.ExecuteCommand("VcAccept", PlayerEntityClient.GetPlayerEntityId());
                }
            }
            else if (this.joinLeaveAction == JoinLeaveAction.LEAVE)
            {
                CommandCore.ExecuteCommand("VcLeave " + company.vcName, PlayerEntityClient.GetPlayerEntityId());
            }
            else if (this.joinLeaveAction == JoinLeaveAction.APPLY)
            {
                CommandCore.ExecuteCommand("VcApply " + company.vcName + ", " + EntityDataClient.owner.entityName, PlayerEntityClient.GetPlayerEntityId());
            }
            CompanySearchWindowGui.singleton.RequestSearchResults();
        }
    }

    public void KickClicked(GameObject go)
    {
        VentureCompanyRecord company = GroupClient.GetCompany(CompanyWindowGui.companyId);
        if ((company != null) && !string.IsNullOrEmpty(this.selectedPlayer))
        {
            CommandCore.ExecuteCommand("VcKick " + company.vcName + ", " + this.selectedPlayer, PlayerEntityClient.GetPlayerEntityId());
        }
    }

    public override void LoadingTickFinished()
    {
        StaticDataService.RegisterCallback<ColorData>(new StaticDataService.StaticDataServiceCallback(CompanyWindowDetailsTabGui.UpdateColors));
        this.goalPrefab = UIClient.guiPrefabs["CompanyDetailsGoal"];
        this.playerInfoPrefab = UIClient.guiPrefabs["CompanyDetailsPlayerInfo"];
        GuiHelper.GuiAssertNotNull("Couldn't load prefabs.", new object[] { this.goalPrefab, this.playerInfoPrefab });
        foreach (CompanyDetailsTabGui gui in this.allTabs)
        {
            gui.LoadingTickFinished();
        }
        this.SetInfo(null);
    }

    private void MakeLeaders(VentureCompanyRecord company)
    {
        int num = 0;
        for (int i = 0; i < company.members.Length; i++)
        {
            if ((company.members[i] != null) && company.members[i].IsLeader())
            {
                if (num >= this.displayedItems.Count)
                {
                    CompanyMemberInfoGui component = NGUITools.AddChild(this.leadersGrid.gameObject, this.playerInfoPrefab).GetComponent<CompanyMemberInfoGui>();
                    this.displayedItems.Add(component);
                }
                this.displayedItems[num].Assign(company.members[i]);
                num++;
            }
        }
        while (this.displayedItems.Count > num)
        {
            CompanyMemberInfoGui gui2 = this.displayedItems[this.displayedItems.Count - 1];
            this.displayedItems.RemoveAt(this.displayedItems.Count - 1);
            gui2.gameObject.SetActive(false);
            gui2.transform.parent = DragDropRoot.root;
            UnityEngine.Object.Destroy(gui2.gameObject);
        }
        this.leadersGrid.repositionNow = true;
    }

    public void MembersTabSelected(GameObject go)
    {
        Tabs activeTab = this.activeTab;
        this.activeTab = Tabs.MEMBERS;
        if (this.activeTab != activeTab)
        {
            this.ShowSubtab();
        }
    }

    private void OnAwake()
    {
        foreach (UIImageButton button in base.GetComponentsInChildren<UIImageButton>())
        {
            if (button.name == "ButtonInspect")
            {
                this.inspectButton = button;
            }
            else if (button.name == "ButtonKick")
            {
                this.kickButton = button;
            }
            else if (button.name == "ButtonPromote")
            {
                this.promoteButton = button;
            }
            else if (button.name == "ButtonJoinLeave")
            {
                this.joinLeaveButton = button;
            }
            else if (button.name == "ButtonEditSave")
            {
                this.editSaveButton = button;
            }
            else if (button.name == "ButtonSearch")
            {
                this.searchButton = button;
            }
            else if (button.name == "ButtonRefresh")
            {
                this.refreshButton = button;
            }
            else if (button.name == "ButtonApprove")
            {
                this.approveButton = button;
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find buttons.", new object[] { this.inspectButton, this.kickButton, this.promoteButton, this.joinLeaveButton, this.editSaveButton, this.searchButton, this.refreshButton, this.approveButton });
        UIEventListener listener1 = UIEventListener.Get(this.inspectButton.gameObject);
        listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.InspectClicked));
        UIEventListener listener2 = UIEventListener.Get(this.kickButton.gameObject);
        listener2.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener2.onClick, new UIEventListener.VoidDelegate(this.KickClicked));
        UIEventListener listener3 = UIEventListener.Get(this.promoteButton.gameObject);
        listener3.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener3.onClick, new UIEventListener.VoidDelegate(this.PromoteClicked));
        UIEventListener listener4 = UIEventListener.Get(this.joinLeaveButton.gameObject);
        listener4.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener4.onClick, new UIEventListener.VoidDelegate(this.JoinLeaveClicked));
        UIEventListener listener5 = UIEventListener.Get(this.editSaveButton.gameObject);
        listener5.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener5.onClick, new UIEventListener.VoidDelegate(this.EditSaveClicked));
        UIEventListener listener6 = UIEventListener.Get(this.searchButton.gameObject);
        listener6.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener6.onClick, new UIEventListener.VoidDelegate(this.SearchClicked));
        UIEventListener listener7 = UIEventListener.Get(this.refreshButton.gameObject);
        listener7.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener7.onClick, new UIEventListener.VoidDelegate(this.RefreshClicked));
        UIEventListener listener8 = UIEventListener.Get(this.approveButton.gameObject);
        listener8.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener8.onClick, new UIEventListener.VoidDelegate(this.ApproveClicked));
        NGUITools.SetActive(this.inspectButton.gameObject, false);
        NGUITools.SetActive(this.promoteButton.gameObject, false);
        foreach (UIGrid grid in base.GetComponentsInChildren<UIGrid>())
        {
            if (grid.name == "Goals")
            {
                this.goalsGrid = grid;
            }
            else if (grid.name == "LeadersGrid")
            {
                this.leadersGrid = grid;
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find grids.", new object[] { this.goalsGrid, this.leadersGrid });
        foreach (UILabel label in base.GetComponentsInChildren<UILabel>())
        {
            if (label.name == "AlignmentReputation")
            {
                this.alignAndRep = label;
            }
            else if (label.name == "CompanyName")
            {
                this.companyName = label;
            }
            else if (label.name == "SettlementAffiliation")
            {
                this.affiliation = label;
            }
            else if (label.name == "Goals")
            {
                this.goalsLabel = label;
            }
            else if (label.name == "JoinLeaveLabel")
            {
                this.joinLeaveLabel = label;
            }
            else if (label.name == "EditSaveLabel")
            {
                this.editSaveLabel = label;
            }
        }
        foreach (UIInput input in base.GetComponentsInChildren<UIInput>())
        {
            if (input.name == "CompanyStatement")
            {
                this.statement = input;
            }
            else if (input.name == "RecruitmentMessage")
            {
                this.recruitment = input;
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find labels or inputs.", new object[] { this.alignAndRep, this.companyName, this.statement, this.affiliation, this.goalsLabel, this.joinLeaveLabel, this.editSaveLabel });
        this.statement.ClearText();
        this.recruitment.ClearText();
        foreach (UISprite sprite in base.GetComponentsInChildren<UISprite>())
        {
            if (sprite.name == "StatementBackground")
            {
                this.statementBg = sprite;
            }
            else if (sprite.name == "RecruitmentBackground")
            {
                this.recruitmentBg = sprite;
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find sprites.", new object[] { this.statementBg, this.recruitmentBg });
        foreach (SortButton button2 in base.GetComponentsInChildren<SortButton>())
        {
            if (button2.name == "SortLeader0Name")
            {
                button2.Init(0, SortButton.SortType.ASCENDING);
            }
            else
            {
                if (!(button2.name == "SortLeader1Status"))
                {
                    continue;
                }
                button2.Init(1, SortButton.SortType.INACTIVE);
            }
            this.allSorts.Add(button2);
            UIEventListener listener9 = UIEventListener.Get(button2.gameObject);
            listener9.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener9.onClick, new UIEventListener.VoidDelegate(this.SortClicked));
            if ((button2.sort != SortButton.SortType.INACTIVE) && (this.currentSort == null))
            {
                this.currentSort = button2;
            }
            else if ((button2.sort != SortButton.SortType.INACTIVE) && (this.currentSort != null))
            {
                GLog.LogError(new object[] { "Should only have one non-inactive sort! You have", this.currentSort.name, "and", button2.name });
            }
        }
        foreach (CompanyDetailsTabGui gui in base.GetComponentsInChildren<CompanyDetailsTabGui>())
        {
            string name = gui.name;
            if (name == null)
            {
                goto Label_0812;
            }
            if (!(name == "TabMembers"))
            {
                if (name == "TabApplicants")
                {
                    goto Label_0806;
                }
                goto Label_0812;
            }
            this.allTabs[0] = gui;
            continue;
        Label_0806:
            this.allTabs[1] = gui;
            continue;
        Label_0812:;
            GLog.LogWarning(new object[] { "Unknown tab '" + gui.name + "'." });
        }
        GuiHelper.GuiAssertNotNull("Couldn't find needed tabs.", this.allTabs);
        Collider collider = null;
        Collider collider2 = null;
        foreach (Collider collider3 in base.GetComponentsInChildren<Collider>())
        {
            if (collider3.name == "TabNameApplicants")
            {
                collider = collider3;
            }
            else if (collider3.name == "TabNameMembers")
            {
                collider2 = collider3;
            }
        }
        GuiHelper.GuiAssertNotNull("Can't find tab click targets!", new object[] { collider, collider2 });
        UIEventListener listener10 = UIEventListener.Get(collider.gameObject);
        listener10.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener10.onClick, new UIEventListener.VoidDelegate(this.ApplicantsTabSelected));
        UIEventListener listener11 = UIEventListener.Get(collider2.gameObject);
        listener11.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener11.onClick, new UIEventListener.VoidDelegate(this.MembersTabSelected));
        NGUITools.SetActive(this.goalsLabel.gameObject, false);
        NGUITools.SetActive(this.goalsGrid.gameObject, false);
    }

    public void OnDestroy()
    {
        singleton = null;
    }

    public void PlayerSelected(string playerName)
    {
        this.selectedPlayer = playerName;
        for (int i = 0; i < this.displayedItems.Count; i++)
        {
            this.displayedItems[i].PlayerSelected(playerName);
        }
        foreach (CompanyDetailsTabGui gui in this.allTabs)
        {
            gui.PlayerSelected(playerName);
        }
    }

    public void PromoteClicked(GameObject go)
    {
    }

    public void RefreshClicked(GameObject go)
    {
        CompanySearchWindowGui.singleton.RequestSearchResults();
    }

    public override void RefreshCompany()
    {
        this.DisplayCompany();
    }

    protected void ResortContents(Sort sortField, SortButton.SortType sortType)
    {
        IEnumerable<CompanyMemberInfoGui> enumerable = null;
        if (sortField == Sort.NAME)
        {
            if (sortType == SortButton.SortType.DESCENDING)
            {
                enumerable = from each in this.displayedItems
                    orderby each.sortName descending
                    select each;
            }
            else if (sortType == SortButton.SortType.ASCENDING)
            {
                enumerable = from each in this.displayedItems
                    orderby each.sortName
                    select each;
            }
            else
            {
                GLog.LogError(new object[] { "Don't know how to sort", sortField, "by", sortType });
            }
        }
        else if (sortField == Sort.STATUS)
        {
            if (sortType == SortButton.SortType.DESCENDING)
            {
                enumerable = from each in this.displayedItems
                    orderby each.sortStatus descending
                    select each;
            }
            else if (sortType == SortButton.SortType.ASCENDING)
            {
                enumerable = from each in this.displayedItems
                    orderby each.sortStatus
                    select each;
            }
            else
            {
                GLog.LogError(new object[] { "Don't know how to sort", sortField, "by", sortType });
            }
        }
        if (enumerable != null)
        {
            int num = 0;
            foreach (CompanyMemberInfoGui gui in enumerable)
            {
                gui.name = num.ToString("d3") + "_" + gui.sortName;
                num++;
            }
        }
        else
        {
            GLog.LogError(new object[] { "Failed to sort", sortField, sortType });
        }
        this.leadersGrid.repositionNow = true;
    }

    public void SearchClicked(GameObject go)
    {
        CompanySearchWindowGui.singleton.ToggleWindowVisibility();
    }

    private void SetApplicantButton()
    {
        VentureCompanyRecord company = GroupClient.GetCompany(CompanyWindowGui.companyId);
        if ((this.activeTab != Tabs.APPLICANTS) || (company == null))
        {
            NGUITools.SetActive(this.approveButton.gameObject, false);
        }
        else
        {
            VentureCompanyMember member = company.FindMember(EntityDataClient.owner.playerId);
            if (member == null)
            {
                NGUITools.SetActive(this.approveButton.gameObject, false);
            }
            else
            {
                NGUITools.SetActive(this.approveButton.gameObject, member.HasPermission(VentureCompanyMember.MemberPermission.INVITE));
            }
        }
    }

    private void SetGoals(VentureCompanyRecord company)
    {
        CompanyDetailsGoalGui gui;
        if (company == null)
        {
            this.goalsLabel.text = string.Empty;
            while (this.displayedGoals.Count > 0)
            {
                gui = this.displayedGoals[this.displayedGoals.Count - 1];
                this.displayedGoals.RemoveAt(this.displayedGoals.Count - 1);
                gui.gameObject.SetActive(false);
                gui.transform.parent = DragDropRoot.root;
                UnityEngine.Object.Destroy(gui.gameObject);
            }
        }
        else
        {
            if (company.goals == VentureCompanyRecord.Goal.NONE)
            {
                this.goalsLabel.text = "Company Goals: None";
                while (this.displayedGoals.Count > 0)
                {
                    gui = this.displayedGoals[this.displayedGoals.Count - 1];
                    this.displayedGoals.RemoveAt(this.displayedGoals.Count - 1);
                    gui.gameObject.SetActive(false);
                    gui.transform.parent = DragDropRoot.root;
                    UnityEngine.Object.Destroy(gui.gameObject);
                }
            }
            else
            {
                this.goalsLabel.text = "Company Goals";
                int num = 0;
                foreach (Enum enum2 in Enum.GetValues(typeof(VentureCompanyRecord.Goal)))
                {
                    VentureCompanyRecord.Goal goal = (VentureCompanyRecord.Goal) enum2;
                    if (((byte) (company.goals & goal)) == goal)
                    {
                        if (num >= this.displayedGoals.Count)
                        {
                            CompanyDetailsGoalGui component = NGUITools.AddChild(this.goalsGrid.gameObject, this.goalPrefab).GetComponent<CompanyDetailsGoalGui>();
                            this.displayedGoals.Add(component);
                        }
                        this.displayedGoals[num].Assign(goal);
                        num++;
                    }
                }
                while (this.displayedGoals.Count > num)
                {
                    gui = this.displayedGoals[this.displayedGoals.Count - 1];
                    this.displayedGoals.RemoveAt(this.displayedGoals.Count - 1);
                    gui.gameObject.SetActive(false);
                    gui.transform.parent = DragDropRoot.root;
                    UnityEngine.Object.Destroy(gui.gameObject);
                }
            }
            this.goalsGrid.repositionNow = true;
        }
    }

    private void SetInfo(VentureCompanyRecord company)
    {
        if (company == null)
        {
            this.companyName.text = string.Empty;
            this.alignAndRep.text = string.Empty;
            this.statement.enabled = true;
            this.statement.text = string.Empty;
            this.statement.defaultText = string.Empty;
            this.recruitment.enabled = true;
            this.recruitment.text = string.Empty;
            this.recruitment.defaultText = string.Empty;
            NGUITools.SetActive(this.affiliation.gameObject, false);
            this.SetGoals(null);
            this.SetMemberSpecifics(null);
        }
        else
        {
            this.companyName.text = company.vcName;
            string str = string.Empty;
            switch (PvpConst.GetReputationLevel(company.reputation))
            {
                case PvpConst.Reputation.HOSTILE:
                    str = "Hostile";
                    break;

                case PvpConst.Reputation.UNFRIENDLY:
                    str = "Unfriendly";
                    break;

                case PvpConst.Reputation.INDIFFERENT:
                    str = "Indifferent";
                    break;

                case PvpConst.Reputation.FRIENDLY:
                    str = "Friendly";
                    break;

                case PvpConst.Reputation.HELPFUL:
                    str = "Helpful";
                    break;

                default:
                    str = "Unknown";
                    break;
            }
            this.alignAndRep.text = str;
            this.statement.enabled = true;
            this.statement.text = company.statement;
            this.statement.defaultText = company.statement;
            this.recruitment.enabled = true;
            this.recruitment.text = company.recruitment;
            this.recruitment.defaultText = company.recruitment;
            NGUITools.SetActive(this.affiliation.gameObject, false);
            this.SetGoals(company);
            this.SetMemberSpecifics(company);
        }
    }

    private void SetMemberSpecifics(VentureCompanyRecord company)
    {
        if (company == null)
        {
            this.SetupJoinLeave(null);
            this.statement.enabled = false;
            this.recruitment.enabled = false;
            NGUITools.SetActive(this.recruitmentBg.gameObject, false);
            NGUITools.SetActive(this.statementBg.gameObject, false);
            NGUITools.SetActive(this.kickButton.gameObject, false);
            NGUITools.SetActive(this.editSaveButton.gameObject, false);
        }
        else
        {
            this.SetupJoinLeave(company);
            this.statement.enabled = false;
            this.recruitment.enabled = false;
            NGUITools.SetActive(this.recruitmentBg.gameObject, false);
            NGUITools.SetActive(this.statementBg.gameObject, false);
            this.editSaveAction = EditSaveAction.EDIT;
            this.editSaveLabel.text = "Edit";
            VentureCompanyMember member = company.FindMember(EntityDataClient.owner.playerId);
            if (member == null)
            {
                NGUITools.SetActive(this.kickButton.gameObject, false);
                NGUITools.SetActive(this.editSaveButton.gameObject, false);
                this.editSaveAction = EditSaveAction.NONE;
            }
            else
            {
                NGUITools.SetActive(this.kickButton.gameObject, member.HasPermission(VentureCompanyMember.MemberPermission.KICK));
                NGUITools.SetActive(this.editSaveButton.gameObject, member.HasPermission(VentureCompanyMember.MemberPermission.EDIT));
            }
            this.SetApplicantButton();
        }
    }

    public void SetupJoinLeave(VentureCompanyRecord company)
    {
        if (company == null)
        {
            NGUITools.SetActive(this.joinLeaveButton.gameObject, false);
        }
        else if ((EntityDataClient.owner != null) && (EntityDataClient.owner.playerRecord != null))
        {
            VentureCompanyMember member = company.FindMember(EntityDataClient.owner.playerId);
            VentureCompanyInvite invite = company.FindInvite(EntityDataClient.owner.playerId);
            if (member != null)
            {
                NGUITools.SetActive(this.joinLeaveButton.gameObject, false);
            }
            else if (invite != null)
            {
                if (invite.TypeOfInvite() == VentureCompanyInvite.InviteType.APPLICANT)
                {
                    NGUITools.SetActive(this.joinLeaveButton.gameObject, false);
                    this.joinLeaveAction = JoinLeaveAction.NONE;
                }
                else
                {
                    this.joinLeaveButton.normalSprite = "button_crafting_general_de";
                    this.joinLeaveButton.hoverSprite = "button_crafting_general_mo";
                    this.joinLeaveButton.pressedSprite = "button_crafting_general_cl";
                    this.joinLeaveButton.SendMessage("OnHover", false, SendMessageOptions.DontRequireReceiver);
                    this.joinLeaveLabel.text = "Join";
                    this.joinLeaveLabel.color = POSITIVE_TEXT;
                    NGUITools.SetActive(this.joinLeaveButton.gameObject, true);
                    this.joinLeaveAction = JoinLeaveAction.JOIN;
                }
            }
            else
            {
                this.joinLeaveButton.normalSprite = "button_crafting_general_de";
                this.joinLeaveButton.hoverSprite = "button_crafting_general_mo";
                this.joinLeaveButton.pressedSprite = "button_crafting_general_cl";
                this.joinLeaveButton.SendMessage("OnHover", false, SendMessageOptions.DontRequireReceiver);
                this.joinLeaveLabel.text = "Apply to Join";
                this.joinLeaveLabel.color = POSITIVE_TEXT;
                NGUITools.SetActive(this.joinLeaveButton.gameObject, true);
                this.joinLeaveAction = JoinLeaveAction.APPLY;
            }
        }
    }

    public void ShowSubtab()
    {
        for (int i = 0; i < this.allTabs.Length; i++)
        {
            if (i == this.activeTab)
            {
                this.allTabs[i].ShowTab();
            }
            else
            {
                this.allTabs[i].HideTab();
            }
        }
        this.SetApplicantButton();
    }

    public override void ShowTab()
    {
        base.ShowTab();
        this.ShowSubtab();
    }

    public void SortClicked(GameObject sortGO)
    {
        SortButton button = null;
        for (int i = 0; i < this.allSorts.Count; i++)
        {
            if (sortGO == this.allSorts[i].gameObject)
            {
                this.allSorts[i].ToggleSort(true);
                button = this.allSorts[i];
            }
            else
            {
                this.allSorts[i].ToggleSort(false);
            }
        }
        this.currentSort = button;
        this.ResortContents((Sort) this.currentSort.sortId, this.currentSort.sort);
    }

    public void Start()
    {
        foreach (CompanyDetailsTabGui gui in this.allTabs)
        {
            gui.HideTab();
        }
    }

    public static void UpdateColors(List<DataClass> ignored)
    {
        playerDefaultColor = ColorData.GetColorByName("company_player_default", true);
        playerSelectedColor = ColorData.GetColorByName("company_player_selected", true);
        POSITIVE_TEXT = ColorData.GetColorByName("company_button_positive", true);
        NEGATIVE_TEXT = ColorData.GetColorByName("company_button_negative", true);
    }

    public override void UpdateCompany()
    {
        this.DisplayCompany();
    }

    private enum EditSaveAction
    {
        NONE,
        EDIT,
        SAVE
    }

    private enum JoinLeaveAction
    {
        NONE,
        JOIN,
        LEAVE,
        APPLY
    }

    public enum Sort
    {
        NAME,
        STATUS
    }

    public enum Tabs
    {
        MEMBERS,
        APPLICANTS,
        NUM_TABS
    }
}

