﻿using System;
using UnityEngine;

public class SunShaftsTarget : MonoBehaviour
{
    private void AssignToCamera()
    {
        GameObject obj2 = GameObject.Find("/GoblinCamera(Clone)");
        if (obj2 != null)
        {
            SunShafts component = obj2.GetComponent<SunShafts>();
            if (component != null)
            {
                component.sunTransform = base.transform;
                component.enabled = true;
            }
            UnityEngine.Object.Destroy(this);
        }
    }

    private void Update()
    {
        this.AssignToCamera();
    }
}

