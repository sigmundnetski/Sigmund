﻿using GNGUI;
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class CharacterCreationGui : MonoBehaviour
{
    public CommandCore.PermissionLevel allowedPermission;
    private Dictionary<int, string> bodyAssets;
    private DisabledButton cancelButton;
    private UIInput characterNameInput;
    private Dictionary<string, GameObject> constructedEntities;
    private GameObject currentCharacter;
    private Dictionary<int, string> displayGenders;
    private Dictionary<int, string> eyeDisplay;
    private UIPopupListKvp eyeList;
    private UISlicedSprite eyeSprite;
    private Dictionary<int, string> faceAssets;
    private Dictionary<int, string> faceDisplay;
    private UIPopupListKvp faceList;
    private UISlicedSprite faceSprite;
    private UIPopupListKvp genderList;
    private string[] genderNames;
    private Dictionary<int, string> hairAssets;
    private Dictionary<int, string> hairColorDisplay;
    private UIPopupListKvp hairColorList;
    private UISlicedSprite hairColorSprite;
    private Dictionary<int, string> hairDisplay;
    private UIPopupListKvp hairList;
    private UISlicedSprite hairSprite;
    private UILabel infoLabel;
    private GameObject internalCommands;
    private Transform parentTransform;
    private Dictionary<int, string> pcRaces;
    private UIPopupListKvp permissionList;
    private PhysiqueRecord physique;
    private DisabledButton playButton;
    private UIPopupListKvp raceList;
    private EntityDefnData selectedDefn;
    private string selectedGender;
    private string selectedRace;
    public static CharacterCreationGui singleton;
    private Dictionary<int, string> skinDisplay;
    private UIPopupListKvp skinList;
    private UISlicedSprite skinSprite;
    private bool skipCharacterChange;
    private GameObject spawnPoint;

    public CharacterCreationGui()
    {
        Dictionary<int, string> dictionary = new Dictionary<int, string>();
        dictionary.Add(0, "Female");
        dictionary.Add(1, "Male");
        this.displayGenders = dictionary;
        this.genderNames = new string[] { "female", "male" };
        this.currentCharacter = null;
        this.allowedPermission = CommandCore.PermissionLevel.USER;
        this.selectedDefn = null;
        this.selectedRace = null;
        this.selectedGender = null;
        this.physique = new PhysiqueRecord();
        this.constructedEntities = new Dictionary<string, GameObject>();
        this.pcRaces = new Dictionary<int, string>();
        this.faceDisplay = new Dictionary<int, string>();
        this.hairDisplay = new Dictionary<int, string>();
        this.skinDisplay = new Dictionary<int, string>();
        this.hairColorDisplay = new Dictionary<int, string>();
        this.eyeDisplay = new Dictionary<int, string>();
        this.skipCharacterChange = false;
    }

    private bool AssetsValid()
    {
        return ((((this.physique.faceAssetVariant != -1) && (this.physique.hairAssetVariant != -1)) && ((this.physique.skinColorId != 0) && (this.physique.hairColorId != 0))) && (this.physique.eyeColorId != 0));
    }

    public void AssignObjects(Transform inParent, GameObject inSpawn)
    {
        this.parentTransform = inParent;
        this.spawnPoint = inSpawn;
    }

    public void Awake()
    {
        singleton = this;
    }

    private void ChangeSelection()
    {
        if (!string.IsNullOrEmpty(this.selectedRace) && !string.IsNullOrEmpty(this.selectedGender))
        {
            this.ModifyCharacter();
        }
    }

    public void ClearError()
    {
        this.infoLabel.color = CharacterSelectionGui.COLOR_TEXT_POSITIVE;
        this.infoLabel.text = string.Empty;
    }

    public void ConfigureFields()
    {
        foreach (RaceData data in RaceData.playableRaces)
        {
            this.pcRaces[data.id] = data.displayName;
        }
        this.raceList.UpdateElements(this.pcRaces);
        this.genderList.UpdateElements(this.displayGenders);
    }

    public void CreateCharacterWithName(string characterName)
    {
        this.raceList.SetSelectionToIndex(0);
        this.genderList.SetSelectionToIndex(0);
        this.ChangeSelection();
        this.characterNameInput.text = characterName;
        this.OnInput(null, characterName);
    }

    public void DisableCharacterModel()
    {
        if (this.currentCharacter != null)
        {
            this.currentCharacter.SetActive(false);
        }
    }

    private void EnableBodyFields()
    {
        if (this.RaceGenderValid())
        {
            string key = this.selectedRace + "_" + this.selectedGender;
            GameObject obj2 = null;
            this.constructedEntities.TryGetValue(key, out obj2);
            if ((this.currentCharacter != obj2) && (this.currentCharacter != null))
            {
                this.currentCharacter.SetActive(false);
            }
            this.currentCharacter = obj2;
            this.skipCharacterChange = true;
            if (this.AssetsValid() && (this.currentCharacter != null))
            {
                this.ReinitCharacter();
            }
            else
            {
                this.InitCharacter();
            }
            this.skipCharacterChange = false;
        }
    }

    public void EnableGui()
    {
        LoadingMessageGUI.UpdateLoadingStatus(false, "Client loading complete.");
        NGUITools.SetActive(base.gameObject, true);
        if (this.internalCommands != null)
        {
            NGUITools.SetActive(this.internalCommands, this.allowedPermission >= CommandCore.PermissionLevel.GM);
        }
        this.ChangeSelection();
        this.IsInputValid();
    }

    private Dictionary<string, EquipmentAsset> GetCharacterAssets()
    {
        EntityDefnData data = null;
        CombatClassData data3;
        foreach (string str in EntityDefnData.playerDefns)
        {
            EntityDefnData data2 = EntityDefnData.defnByName[str];
            if ((data2.raceId == this.raceList.selectedKey) && (data2.gender == this.selectedGender[0]))
            {
                data = data2;
                break;
            }
        }
        if (data == null)
        {
            GLog.LogError(new object[] { "No EntityDefnData for", this.selectedGender, this.selectedRace });
            return null;
        }
        this.selectedDefn = data;
        Dictionary<string, EquipmentAsset> equippedAssets = new Dictionary<string, EquipmentAsset>();
        string key = data.combatClassName.Replace("<level>", "1").ToLower();
        if (CombatClassData.classesByName.TryGetValue(key, out data3))
        {
            InventoryClient.GetAssetFromBasicItem(ItemDatabase.GetItem(data3.armorId), data3.armorUpgrade, this.selectedRace, this.selectedGender[0], BasicItemData.ItemSlot.ARMOR, ref equippedAssets, Color.black, Color.black, Color.black);
        }
        this.physique.bodyAssetVariant = this.bodyAssets.Keys.First<int>();
        return equippedAssets;
    }

    private void InitCharacter()
    {
        this.UpdateAssetOptions();
        Dictionary<string, EquipmentAsset> characterAssets = this.GetCharacterAssets();
        if (this.selectedDefn != null)
        {
            string characterName = this.selectedRace + "_" + this.selectedGender;
            bool displayGmSuit = false;
            if ((this.allowedPermission >= CommandCore.PermissionLevel.GM) && !string.IsNullOrEmpty(this.permissionList.selectedValue))
            {
                CommandCore.PermissionLevel level;
                GUtil.TryParseEnum<CommandCore.PermissionLevel>(this.permissionList.selectedValue, CommandCore.PermissionLevel.USER, out level);
                if (level >= CommandCore.PermissionLevel.GM)
                {
                    displayGmSuit = true;
                }
            }
            this.currentCharacter = EntityLoadClient.CreateCompleteCharacter(this.selectedDefn.id, displayGmSuit, this.physique, null, GConst.CreateType.TEST_EMPTY_ENTITY, this.parentTransform, this.spawnPoint.transform.position, this.spawnPoint.transform.rotation, characterName);
            this.currentCharacter.AddComponent<IdleAnimator>();
            this.constructedEntities[characterName] = this.currentCharacter;
        }
    }

    public void IsInputValid()
    {
        bool flag = this.RaceGenderValid();
        if (flag)
        {
            this.faceList.enabled = true;
            this.hairList.enabled = true;
            this.skinList.enabled = true;
            this.hairColorList.enabled = true;
            this.eyeList.enabled = true;
            this.faceSprite.color = Color.white;
            this.hairSprite.color = Color.white;
            this.skinSprite.color = Color.white;
            this.hairColorSprite.color = Color.white;
            this.eyeSprite.color = Color.white;
        }
        this.playButton.IsDisabled((!this.NameValid() || !flag) || !this.AssetsValid());
    }

    private void ModifyCharacter()
    {
        Dictionary<string, EquipmentAsset> characterAssets = this.GetCharacterAssets();
        if (this.currentCharacter != null)
        {
            this.currentCharacter.SetActive(true);
        }
        bool displayGmSuit = false;
        if ((this.allowedPermission >= CommandCore.PermissionLevel.GM) && !string.IsNullOrEmpty(this.permissionList.selectedValue))
        {
            CommandCore.PermissionLevel level;
            GUtil.TryParseEnum<CommandCore.PermissionLevel>(this.permissionList.selectedValue, CommandCore.PermissionLevel.USER, out level);
            if (level >= CommandCore.PermissionLevel.GM)
            {
                displayGmSuit = true;
            }
        }
        EntityLoadClient.ModifyCharacter(this.currentCharacter, this.selectedDefn.id, displayGmSuit, this.physique, characterAssets);
    }

    private bool NameValid()
    {
        return ((this.characterNameInput.text.IndexOf('<') == -1) && (this.characterNameInput.text.Length > 2));
    }

    public void OnDestroy()
    {
        singleton = null;
    }

    public void OnEyeChange(string ignored)
    {
        this.physique.eyeColorId = this.eyeList.selectedKey;
        if (!this.skipCharacterChange)
        {
            this.ChangeSelection();
            this.IsInputValid();
        }
    }

    public void OnFaceChange(string ignored)
    {
        this.physique.faceAssetVariant = this.faceList.selectedKey;
        if (!this.skipCharacterChange)
        {
            this.ChangeSelection();
            this.IsInputValid();
        }
    }

    public void OnGenderChange(string ignored)
    {
        this.selectedGender = this.genderNames[this.genderList.selectedKey];
        this.physique.gender = (byte) this.selectedGender[0];
        this.EnableBodyFields();
        this.IsInputValid();
    }

    public void OnHairChange(string ignored)
    {
        this.physique.hairAssetVariant = this.hairList.selectedKey;
        if (!this.skipCharacterChange)
        {
            this.ChangeSelection();
            this.IsInputValid();
        }
    }

    public void OnHairColorChange(string ignored)
    {
        this.physique.hairColorId = this.hairColorList.selectedKey;
        if (!this.skipCharacterChange)
        {
            this.ChangeSelection();
            this.IsInputValid();
        }
    }

    public void OnInput(GameObject go, string newText)
    {
        this.ClearError();
        string text = this.characterNameInput.text;
        string[] strArray = new string[] { ";", "|" };
        foreach (string str2 in strArray)
        {
            text = text.Replace(str2, "");
        }
        this.characterNameInput.text = text;
        this.IsInputValid();
    }

    private void OnPermissionChange(string ignored)
    {
        this.ChangeSelection();
    }

    public void OnRaceChange(string ignored)
    {
        this.selectedRace = RaceData.raceById[this.raceList.selectedKey].name;
        this.physique.raceId = this.raceList.selectedKey;
        this.EnableBodyFields();
        this.IsInputValid();
    }

    public void OnSkinChange(string ignored)
    {
        this.physique.skinColorId = this.skinList.selectedKey;
        if (!this.skipCharacterChange)
        {
            this.ChangeSelection();
            this.IsInputValid();
        }
    }

    public void PlayGame(GameObject go)
    {
        if (((this.NameValid() && this.RaceGenderValid()) && this.AssetsValid()) && !this.playButton.disabled)
        {
            this.ClearError();
            NGUITools.SetActive(base.gameObject, false);
            LoadingMessageGUI.UpdateLoadingStatus(true, "Connecting to Server...");
            CommandCore.PermissionLevel uSER = CommandCore.PermissionLevel.USER;
            if (this.allowedPermission >= CommandCore.PermissionLevel.GM)
            {
                GUtil.TryParseEnum<CommandCore.PermissionLevel>(this.permissionList.selectedValue, CommandCore.PermissionLevel.USER, out uSER);
            }
            PlayerLoginClient.CharacterCreated(this.selectedDefn.id, this.physique.raceId, this.physique.gender, this.physique.bodyAssetVariant, this.physique.faceAssetVariant, this.physique.hairAssetVariant, this.physique.skinColorId, this.physique.hairColorId, this.physique.eyeColorId, (byte) uSER, this.characterNameInput.text);
        }
    }

    private bool RaceGenderValid()
    {
        return (!string.IsNullOrEmpty(this.selectedRace) && !string.IsNullOrEmpty(this.selectedGender));
    }

    private void ReinitCharacter()
    {
        this.currentCharacter.SetActive(true);
        this.UpdateAssetOptions();
        this.ModifyCharacter();
    }

    public void SetError(string message)
    {
        this.infoLabel.text = message;
        this.infoLabel.color = Color.red;
        this.EnableGui();
    }

    public void Start()
    {
        foreach (UILabel label in base.GetComponentsInChildren<UILabel>())
        {
            if (label.name == "InfoLabel")
            {
                this.infoLabel = label;
            }
        }
        foreach (DisabledButton button in base.GetComponentsInChildren<DisabledButton>())
        {
            if (button.name == "PlayButton")
            {
                this.playButton = button;
            }
            else if (button.name == "CancelButton")
            {
                this.cancelButton = button;
            }
        }
        foreach (UIPopupListKvp kvp in base.GetComponentsInChildren<UIPopupListKvp>())
        {
            if (kvp.name == "RacePopupList")
            {
                this.raceList = kvp;
                this.raceList.onSelectionChange = new UIPopupList.OnSelectionChange(this.OnRaceChange);
            }
            else if (kvp.name == "GenderPopupList")
            {
                this.genderList = kvp;
                this.genderList.onSelectionChange = new UIPopupList.OnSelectionChange(this.OnGenderChange);
            }
            else if (kvp.name == "FacePopupList")
            {
                this.faceList = kvp;
                this.faceList.onSelectionChange = new UIPopupList.OnSelectionChange(this.OnFaceChange);
            }
            else if (kvp.name == "HairPopupList")
            {
                this.hairList = kvp;
                this.hairList.onSelectionChange = new UIPopupList.OnSelectionChange(this.OnHairChange);
            }
            else if (kvp.name == "SkinPopupList")
            {
                this.skinList = kvp;
                this.skinList.onSelectionChange = new UIPopupList.OnSelectionChange(this.OnSkinChange);
            }
            else if (kvp.name == "HairColorPopupList")
            {
                this.hairColorList = kvp;
                this.hairColorList.onSelectionChange = new UIPopupList.OnSelectionChange(this.OnHairColorChange);
            }
            else if (kvp.name == "EyePopupList")
            {
                this.eyeList = kvp;
                this.eyeList.onSelectionChange = new UIPopupList.OnSelectionChange(this.OnEyeChange);
            }
            else if (kvp.name == "PermissionsPopupList")
            {
                this.permissionList = kvp;
                this.permissionList.onSelectionChange = new UIPopupList.OnSelectionChange(this.OnPermissionChange);
            }
        }
        this.characterNameInput = base.GetComponentInChildren<UIInput>();
        GuiHelper.GuiAssertNotNull("Error starting CharacterCreationGui: ", new object[] { this.infoLabel, this.playButton, this.cancelButton, this.characterNameInput, this.raceList, this.genderList, this.faceList, this.hairList, this.skinList, this.hairColorList, this.eyeList, this.permissionList });
        this.faceSprite = this.faceList.GetComponentInChildren<UISlicedSprite>();
        this.hairSprite = this.hairList.GetComponentInChildren<UISlicedSprite>();
        this.skinSprite = this.skinList.GetComponentInChildren<UISlicedSprite>();
        this.hairColorSprite = this.hairColorList.GetComponentInChildren<UISlicedSprite>();
        this.eyeSprite = this.eyeList.GetComponentInChildren<UISlicedSprite>();
        GuiHelper.GuiAssertNotNull("Couldn't find popup backgrounds: ", new object[] { this.faceSprite, this.hairSprite, this.skinSprite, this.hairColorSprite, this.eyeSprite });
        UIEventListener listener1 = UIEventListener.Get(this.characterNameInput.gameObject);
        listener1.onInput = (UIEventListener.StringDelegate) Delegate.Combine(listener1.onInput, new UIEventListener.StringDelegate(this.OnInput));
        UIEventListener listener2 = UIEventListener.Get(this.cancelButton.gameObject);
        listener2.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener2.onClick, new UIEventListener.VoidDelegate(CharacterManagementGui.singleton.DisplayCharacterSelection));
        UIEventListener listener3 = UIEventListener.Get(this.playButton.gameObject);
        listener3.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener3.onClick, new UIEventListener.VoidDelegate(this.PlayGame));
        this.playButton.Assign(new string[] { "button_charselect_enterworld_di", "button_charselect_enterworld_di", "button_charselect_enterworld_di" }, new string[] { "button_charselect_enterworld_de", "button_charselect_enterworld_mo", "button_charselect_enterworld_cl" }, CharacterSelectionGui.COLOR_TEXT_DISABLED, CharacterSelectionGui.COLOR_TEXT_POSITIVE);
        this.faceList.enabled = false;
        this.hairList.enabled = false;
        this.skinList.enabled = false;
        this.hairColorList.enabled = false;
        this.eyeList.enabled = false;
        Transform transform = base.transform.Find("HPO - InternalCommands");
        if (transform != null)
        {
            this.internalCommands = transform.gameObject;
        }
        if (this.internalCommands != null)
        {
            NGUITools.SetActive(this.internalCommands, false);
        }
        this.faceSprite.color = new Color(0.5f, 0.5f, 0.5f);
        this.hairSprite.color = new Color(0.5f, 0.5f, 0.5f);
        this.skinSprite.color = new Color(0.5f, 0.5f, 0.5f);
        this.hairColorSprite.color = new Color(0.5f, 0.5f, 0.5f);
        this.eyeSprite.color = new Color(0.5f, 0.5f, 0.5f);
        NGUITools.SetActive(base.gameObject, false);
    }

    private void UpdateAssetOptions()
    {
        int num2;
        int num3;
        RaceColorData data2;
        this.faceDisplay.Clear();
        this.hairDisplay.Clear();
        this.skinDisplay.Clear();
        this.hairColorDisplay.Clear();
        this.eyeDisplay.Clear();
        this.bodyAssets = EntityLoadClient.GetAvailableAssetsFor("body", this.selectedRace, this.selectedGender);
        this.faceAssets = EntityLoadClient.GetAvailableAssetsFor("face", this.selectedRace, this.selectedGender);
        foreach (int num in this.faceAssets.Keys)
        {
            this.faceDisplay[num] = "Face " + num;
        }
        this.faceList.UpdateElements(this.faceDisplay);
        this.faceList.SetSelectionToIndex(GUtil.rng.Generate(0, this.faceDisplay.Count));
        this.hairAssets = EntityLoadClient.GetAvailableAssetsFor("hair", this.selectedRace, this.selectedGender);
        foreach (int num in this.hairAssets.Keys)
        {
            this.hairDisplay[num] = "Hair " + num;
        }
        this.hairList.UpdateElements(this.hairDisplay);
        this.hairList.SetSelectionToIndex(GUtil.rng.Generate(0, this.hairDisplay.Count));
        RaceData data = RaceData.raceById[this.raceList.selectedKey];
        for (num2 = 0; num2 < data.skinColorIds.Length; num2++)
        {
            num3 = data.skinColorIds[num2];
            if (RaceColorData.colorsById.TryGetValue(num3, out data2))
            {
                this.skinDisplay[num3] = data2.displayName;
            }
        }
        this.skinList.UpdateElements(this.skinDisplay);
        this.skinList.SetSelectionToIndex(GUtil.rng.Generate(0, this.skinDisplay.Count));
        for (num2 = 0; num2 < data.hairColorIds.Length; num2++)
        {
            num3 = data.hairColorIds[num2];
            if (RaceColorData.colorsById.TryGetValue(num3, out data2))
            {
                this.hairColorDisplay[num3] = data2.displayName;
            }
        }
        this.hairColorList.UpdateElements(this.hairColorDisplay);
        this.hairColorList.SetSelectionToIndex(GUtil.rng.Generate(0, this.hairColorDisplay.Count));
        for (num2 = 0; num2 < data.eyeColorIds.Length; num2++)
        {
            num3 = data.eyeColorIds[num2];
            if (RaceColorData.colorsById.TryGetValue(num3, out data2))
            {
                this.eyeDisplay[num3] = data2.displayName;
            }
        }
        this.eyeList.UpdateElements(this.eyeDisplay);
        this.eyeList.SetSelectionToIndex(GUtil.rng.Generate(0, this.eyeDisplay.Count));
    }

    public void UpdatePermissions(CommandCore.PermissionLevel maximumPermission)
    {
        this.allowedPermission = maximumPermission;
        Dictionary<int, string> elements = new Dictionary<int, string>();
        for (int i = 0; (i <= ((int) maximumPermission)) && (i < 3); i++)
        {
            elements[i] = ((CommandCore.PermissionLevel) ((byte) i)).ToString();
        }
        this.permissionList.UpdateElements(elements);
        this.permissionList.SetSelectionToKey(0);
    }
}

