﻿using GNGUI;
using System;
using UnityEngine;

public class SkillInfoGui : MonoBehaviour
{
    public UILabel amountLabel;
    public UILabel nameLabel;

    public void Assign(SkillData skillData)
    {
        base.name = skillData.displayName;
        this.nameLabel.text = skillData.displayName;
        this.amountLabel.text = EntityDataClient.owner.combat.GetSkillTotalByIndex(skillData.skillIndex).ToString();
    }

    public void Awake()
    {
        foreach (UILabel label in base.GetComponentsInChildren<UILabel>())
        {
            if (label.name == "Name")
            {
                this.nameLabel = label;
            }
            else if (label.name == "Amount")
            {
                this.amountLabel = label;
            }
        }
        GuiHelper.GuiAssertNotNull("Could not find a label.", new object[] { this.nameLabel, this.amountLabel });
    }
}

