﻿using GNGUI;
using System;
using UnityEngine;

public class InventoryItemRClick : WindowGui
{
    private UISprite accentColor;
    private InventoryItem item;
    private UISprite mainColor;
    private int previousColorId1;
    private int previousColorId2;
    private InventoryRecolorButton[] recolorButtons;
    public static InventoryItemRClick singleton;
    private BasicItemData.ItemSlot slot;

    public void Awake()
    {
        singleton = this;
    }

    private void ColorButtonClicked(GameObject recolorButton)
    {
        InventoryRecolorButton component = recolorButton.GetComponent<InventoryRecolorButton>();
        InventoryClient.RecolorItem(this.item, component.colorId, component.isPrimary, this.slot);
        this.item = InventoryItem.Recolor(this.item, component.colorId, component.isPrimary);
        if (component.isPrimary)
        {
            this.mainColor.color = component.color;
        }
        else
        {
            this.accentColor.color = component.color;
        }
    }

    private void DefaultButtonClicked(GameObject button)
    {
        InventoryClient.RecolorItem(this.item, 0, true, this.slot);
        InventoryClient.RecolorItem(this.item, 0, false, this.slot);
        this.HideWindow();
    }

    public override void OnDestroy()
    {
        base.OnDestroy();
        singleton = null;
    }

    public void ShowRecolorWindow(Vector3 parentPos, InventoryItem _item, BasicItemData.ItemSlot _slot)
    {
        this.previousColorId1 = _item.userColorId1;
        this.previousColorId2 = _item.userColorId2;
        this.item = _item;
        this.slot = _slot;
        this.mainColor.color = ColorData.GetColorById(_item.userColorId1);
        this.accentColor.color = ColorData.GetColorById(_item.userColorId2);
        base.transform.position = parentPos + Vector3.forward;
        this.ShowWindow();
    }

    public void Start()
    {
        this.recolorButtons = base.GetComponentsInChildren<InventoryRecolorButton>(true);
        foreach (InventoryRecolorButton button in this.recolorButtons)
        {
            UIEventListener listener1 = UIEventListener.Get(button.gameObject);
            listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.ColorButtonClicked));
        }
        Transform transform = base.transform.Find("Offset/CurrentMainColor/Background");
        Transform transform2 = base.transform.Find("Offset/CurrentAccentColor/Background");
        this.mainColor = transform.GetComponent<UISprite>();
        this.accentColor = transform2.GetComponent<UISprite>();
        Transform transform3 = base.transform.Find("Offset/ButtonDefault");
        Transform transform4 = base.transform.Find("Offset/ButtonUndo");
        GuiHelper.GuiAssertNotNull("Couldn't find the current color swatches or buttons.", new object[] { this.mainColor, this.accentColor, transform3, transform4 });
        UIEventListener listener2 = UIEventListener.Get(transform3.gameObject);
        listener2.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener2.onClick, new UIEventListener.VoidDelegate(this.DefaultButtonClicked));
        UIEventListener listener3 = UIEventListener.Get(transform4.gameObject);
        listener3.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener3.onClick, new UIEventListener.VoidDelegate(this.UndoButtonClicked));
        this.mainColor.color = Color.black;
        this.accentColor.color = Color.black;
        base.Init(2, true);
    }

    private void UndoButtonClicked(GameObject button)
    {
        InventoryClient.RecolorItem(this.item, this.previousColorId1, true, this.slot);
        InventoryClient.RecolorItem(this.item, this.previousColorId2, false, this.slot);
        this.HideWindow();
    }
}

