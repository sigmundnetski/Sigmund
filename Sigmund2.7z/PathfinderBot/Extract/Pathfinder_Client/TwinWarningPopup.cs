﻿using GNGUI;
using System;
using UnityEngine;

public class TwinWarningPopup : MonoBehaviour
{
    private UIImageButton acceptButton;
    public const string CANCEL_POPUP = "One of these characters is training using Destiny's Twin. Changing training options for any character will remove Destiny's Twin for good, leaving you with only one character earning XP. You will be able to switch which character continues to earn XP but the advantage of Destiny's Twin will be lost.";
    private UIImageButton cancelButton;
    public const string CONSUME_POPUP = "Destiny's Twin allows you to select up to 2 characters to train simultaneously. Both of these characters will earn XP at the same rate.\nWarning! Once you select a second character and activate Destiny's Twin you will not be able to alter which of your characters is earning XP without losing the Destiny's Twin upgrade on your second character for good.";
    private UILabel popupLabel;
    public static TwinWarningPopup singleton;

    public void Awake()
    {
        singleton = this;
    }

    public static void Hide()
    {
        if (singleton != null)
        {
            singleton.gameObject.SetActive(false);
        }
    }

    public void OnDestroy()
    {
        singleton = null;
    }

    public static void Show(string warningText)
    {
        if (singleton != null)
        {
            singleton.gameObject.SetActive(true);
            singleton.popupLabel.text = warningText;
        }
    }

    public void Start()
    {
        foreach (UILabel label in base.GetComponentsInChildren<UILabel>())
        {
            if (label.name == "PopupLabel")
            {
                this.popupLabel = label;
            }
        }
        foreach (UIImageButton button in base.GetComponentsInChildren<UIImageButton>())
        {
            if (button.name == "AcceptButton")
            {
                this.acceptButton = button;
            }
            if (button.name == "CancelButton")
            {
                this.cancelButton = button;
            }
        }
        GuiHelper.GuiAssertNotNull("Could not find needed children.", new object[] { this.popupLabel, this.acceptButton, this.cancelButton });
        UIEventListener listener1 = UIEventListener.Get(this.acceptButton.gameObject);
        listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(CharacterSelectionGui.singleton.AcceptTraining));
        UIEventListener listener2 = UIEventListener.Get(this.cancelButton.gameObject);
        listener2.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener2.onClick, new UIEventListener.VoidDelegate(CharacterSelectionGui.singleton.TwinCancel));
        Hide();
    }
}

