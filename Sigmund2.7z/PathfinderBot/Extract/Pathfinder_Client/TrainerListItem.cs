﻿using GNetwork;
using GNGUI;
using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

public class TrainerListItem : TabListItem
{
    private UIImageButton buyButton;
    private bool buyButtonEnabled = true;
    public int featAdvId = 0;
    public byte featAdvLevel = 0;
    private UISprite icon;

    public void Assign(FeatAdvancementData featAdvancement, byte featLevel)
    {
        int num;
        this.featAdvId = featAdvancement.id;
        this.featAdvLevel = featLevel;
        if (OffensiveFeatData.featAdvIdToFeatId.TryGetValue(this.featAdvId, out num))
        {
            OffensiveFeatData attackById = OffensiveFeatData.GetAttackById(num);
            GuiHelper.SetSpriteWithFallback(this.icon, attackById.icon, "hud_hotbar_icon_questionmark", true);
        }
        else if (NonAttackFeatData.featAdvIdToFeatId.TryGetValue(this.featAdvId, out num))
        {
            NonAttackFeatData featById = NonAttackFeatData.GetFeatById(num);
            GuiHelper.SetSpriteWithFallback(this.icon, featById.icon, "hud_hotbar_icon_questionmark", true);
        }
        base.name = featAdvancement.slotName + " " + this.featAdvLevel;
        FeatAdvancementDetails detailsForLevel = featAdvancement.GetDetailsForLevel(this.featAdvLevel);
        int num2 = (detailsForLevel != null) ? ((int) detailsForLevel.expCost) : -1;
        base.nameLabel.text = string.Concat(new object[] { featAdvancement.slotName, " ", this.featAdvLevel, "\nExp Cost: ", num2 });
        this.buyButtonEnabled = AdvancementVars.FeatAvailability.AVAILABLE == EntityDataClient.owner.advancementVars.CanBuyFeatAtLevel(featAdvancement, this.featAdvLevel, GNetworkService.ServerUtc);
    }

    public override void Awake()
    {
        base.Awake();
        this.icon = base.GetComponentInChildren<UISprite>();
        this.buyButton = base.GetComponentInChildren<UIImageButton>();
        GuiHelper.GuiAssertNotNull("Couldn't find needed children.", new object[] { this.icon, this.buyButton });
        UIEventListener listener1 = UIEventListener.Get(this.buyButton.gameObject);
        listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.BuyClicked));
        NGUITools.SetActive(base.nameLabel.gameObject, false);
        NGUITools.SetActive(this.icon.gameObject, false);
        NGUITools.SetActive(this.buyButton.gameObject, false);
    }

    private void BuyClicked(GameObject buttonGO)
    {
        TrainerWindowGui.singleton.BuyClicked(this);
    }

    public void Display()
    {
        NGUITools.SetActive(base.nameLabel.gameObject, true);
        NGUITools.SetActive(this.icon.gameObject, true);
        if (this.buyButtonEnabled)
        {
            NGUITools.SetActive(this.buyButton.gameObject, true);
        }
    }

    public override void OnTooltip(bool show)
    {
        if (this.featAdvId != 0)
        {
            if (!show)
            {
                UITooltip.ShowText(null, null);
            }
            else
            {
                List<int> list;
                StringBuilder quickText = GUtil.GetQuickText();
                string str = EntityDataClient.owner.advancementVars.GetFeatHovertext(this.featAdvId, this.featAdvLevel, GNetworkService.ServerUtc);
                if (!string.IsNullOrEmpty(str))
                {
                    quickText.Append(str);
                }
                if (FeatDatabase.featsByAdvancementId.TryGetValue(this.featAdvId, out list))
                {
                    foreach (int num in list)
                    {
                        NonAttackFeatData data;
                        if (!NonAttackFeatData.featsById.TryGetValue(num, out data) || (data.level == this.featAdvLevel))
                        {
                            if (quickText.Length > 0)
                            {
                                quickText.Append("\n\n");
                            }
                            CombatClient.AppendFeatTooltip(quickText, num, this.featAdvLevel, false);
                        }
                    }
                }
                UITooltip.ShowText(quickText.ToString(), base.gameObject);
            }
        }
    }
}

