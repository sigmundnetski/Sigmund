﻿using GNGUI;
using System;
using System.Collections.Generic;
using UnityEngine;

public abstract class MapWindowTabGui
{
    protected Queue<int>[] availableDepths;
    protected Vector3 centerOfMap_worldSpace = Vector3.zero;
    protected UIPanel clippingPanel;
    protected static readonly float[] COLLIDER_Z;
    protected uint currentZoom;
    protected static int ICON_PLAYER_OWNER;
    protected static int ICON_PLAYER_PROXY;
    protected HashSet<IconUniqueKey> iconsThisTick = new HashSet<IconUniqueKey>();
    protected const float magnetOverhang_gui = 1f;
    protected GameObject mapIconParent;
    protected GameObject mapIconPrefab;
    protected Dictionary<IconUniqueKey, MapIcon> mapIcons = new Dictionary<IconUniqueKey, MapIcon>();
    protected Rect mapRect;
    protected UITexture mapTexture;
    protected int[] nextIconDepth;
    protected UIImageButton tabButton;
    protected static readonly int[] WIDGET_DEPTH_MIN = new int[] { 0x1018, 10, 120 };

    static MapWindowTabGui()
    {
        float[] numArray = new float[3];
        numArray[0] = -1f;
        numArray[2] = -2f;
        COLLIDER_Z = numArray;
    }

    protected MapWindowTabGui()
    {
    }

    public abstract void AddMapPin();
    protected virtual void CenterAt(Vector3 pos)
    {
        Rect uvRect = this.mapTexture.uvRect;
        this.CenterAt(pos, uvRect);
    }

    protected virtual void CenterAt(Vector3 pos, Rect uvRect)
    {
        uvRect.center = MapClient.WorldToUV(pos);
        bool flag = false;
        if (uvRect.x < 0f)
        {
            uvRect.x = 0f;
            flag = true;
        }
        if (uvRect.y < 0f)
        {
            uvRect.y = 0f;
            flag = true;
        }
        if ((uvRect.x + uvRect.width) > 1f)
        {
            uvRect.x = 1f - uvRect.width;
            flag = true;
        }
        if ((uvRect.y + uvRect.height) > 1f)
        {
            uvRect.y = 1f - uvRect.height;
            flag = true;
        }
        this.mapTexture.uvRect = uvRect;
        if (flag)
        {
            this.centerOfMap_worldSpace = MapClient.UVToWorld(uvRect.center);
        }
    }

    public virtual void DragMap(Vector2 delta)
    {
        this.centerOfMap_worldSpace -= MapClient.GuiToWorld(delta, this.PixelsPerMeter());
    }

    public virtual void Enabled(bool isEnabled)
    {
        NGUITools.SetActive(this.tabButton.gameObject, isEnabled);
    }

    public virtual void HideTab()
    {
        this.tabButton.target.color = new Color(0.5f, 0.5f, 0.5f);
        NGUITools.SetActive(this.mapTexture.gameObject, false);
        this.SetIconVisibility(false);
    }

    public virtual void Init(UITexture mapTexture_, UIImageButton tabButton_, GameObject mapIconPrefab_, GameObject mapIconParent_, Rect mapRect_, UIPanel clippingPanel_)
    {
        this.mapTexture = mapTexture_;
        this.mapIconPrefab = mapIconPrefab_;
        this.mapIconParent = mapIconParent_;
        this.mapRect = mapRect_;
        this.tabButton = tabButton_;
        this.clippingPanel = clippingPanel_;
        this.nextIconDepth = new int[3];
        this.availableDepths = new Queue<int>[3];
        for (int i = 0; i < 3; i++)
        {
            this.nextIconDepth[i] = WIDGET_DEPTH_MIN[i];
            this.availableDepths[i] = new Queue<int>();
        }
    }

    public virtual void MapTexture(Texture texture)
    {
        this.mapTexture.mainTexture = texture;
    }

    public virtual Vector2 PixelsPerMeter()
    {
        return new Vector3(1f, 1f);
    }

    protected virtual void SetIconVisibility(bool isVisible)
    {
        foreach (KeyValuePair<IconUniqueKey, MapIcon> pair in this.mapIcons)
        {
            NGUITools.SetActive(pair.Value.gameObject, isVisible);
        }
    }

    public virtual void ShowTab()
    {
        this.tabButton.target.color = Color.white;
        NGUITools.SetActive(this.mapTexture.gameObject, true);
        this.SetIconVisibility(true);
    }

    public abstract void SyncUpdate();
    public abstract void ZoomIn();
    public abstract void ZoomOut();
}

