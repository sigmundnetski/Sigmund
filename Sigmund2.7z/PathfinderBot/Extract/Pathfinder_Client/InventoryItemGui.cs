﻿using GNGUI;
using System;

public class InventoryItemGui : ItemGui
{
    private UILabel[] allInfo = new UILabel[1];
    private UILabel[] craftingInfo = new UILabel[3];
    private UILabel[] equipmentInfo = new UILabel[3];
    public InventoryTabGui.Tabs infoType = InventoryTabGui.Tabs.INVALID;
    public byte sortDurability;
    public float sortEncumbrance;
    public string sortName;
    public byte sortTier;
    public int sortVariety;

    public void Assign(InventoryItem setItem, InventoryTabGui.Tabs setType, ItemWindowGui parent)
    {
        if (!setItem.DataEquals(base.item, 0xff) || (setType != this.infoType))
        {
            this.infoType = setType;
            base.Assign(setItem, parent);
            this.sortName = setItem.GetDisplayName(true);
            this.sortEncumbrance = setItem.GetEncumbrance();
            this.sortDurability = setItem.durability;
            this.sortTier = setItem.GetTier();
            CraftingItemData item = ItemDatabase.GetItem(this.item.staticItemId) as CraftingItemData;
            this.sortVariety = (item != null) ? ((int) item.variety) : 0;
        }
    }

    public override void Awake()
    {
        base.Awake();
        foreach (UILabel label in base.GetComponentsInChildren<UILabel>())
        {
            if (label.name == "Name")
            {
                base.nameLabel = label;
            }
            else if (label.name == "Encumbrance")
            {
                if (label.transform.parent.name == "InfoAll")
                {
                    this.allInfo[0] = label;
                }
                else if (label.transform.parent.name == "InfoEquipment")
                {
                    this.equipmentInfo[0] = label;
                }
                else if (label.transform.parent.name == "InfoCrafting")
                {
                    this.craftingInfo[1] = label;
                }
            }
            else if (label.name == "Tier")
            {
                if (label.transform.parent.name == "InfoEquipment")
                {
                    this.equipmentInfo[2] = label;
                }
                else if (label.transform.parent.name == "InfoCrafting")
                {
                    this.craftingInfo[2] = label;
                }
            }
            else if ((label.name == "Durability") && (label.transform.parent.name == "InfoEquipment"))
            {
                this.equipmentInfo[1] = label;
            }
            else if ((label.name == "Variety") && (label.transform.parent.name == "InfoCrafting"))
            {
                this.craftingInfo[0] = label;
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find all InfoAll labels.", this.allInfo);
        GuiHelper.GuiAssertNotNull("Couldn't find all InfoEquipment labels.", this.equipmentInfo);
        GuiHelper.GuiAssertNotNull("Couldn't find all InfoCrafting labels.", this.craftingInfo);
    }

    public override void OnClick()
    {
        if (UICamera.currentTouchID == -2)
        {
            InventoryClient.OnItemRClick(base.gameObject, base.item);
        }
        else
        {
            base.OnClick();
        }
    }

    protected override void SetInfo(InventoryItem item, BasicItemData itemData)
    {
        int num;
        for (num = 0; num < this.allInfo.Length; num++)
        {
            this.allInfo[num].text = string.Empty;
        }
        for (num = 0; num < this.equipmentInfo.Length; num++)
        {
            this.equipmentInfo[num].text = string.Empty;
        }
        for (num = 0; num < this.craftingInfo.Length; num++)
        {
            this.craftingInfo[num].text = string.Empty;
        }
        this.sortEncumbrance = item.GetEncumbrance();
        this.sortDurability = item.durability;
        this.sortName = item.GetDisplayName(true);
        this.sortTier = item.GetTier();
        if (this.infoType == InventoryTabGui.Tabs.ALL)
        {
            this.allInfo[0].text = this.sortEncumbrance.ToString("f1");
        }
        else if (this.infoType == InventoryTabGui.Tabs.EQUIPMENT)
        {
            this.equipmentInfo[0].text = this.sortEncumbrance.ToString("f1");
            this.equipmentInfo[2].text = this.sortTier.ToString();
            this.equipmentInfo[1].text = this.sortDurability.ToString();
        }
        else if (this.infoType == InventoryTabGui.Tabs.CRAFTING)
        {
            this.craftingInfo[1].text = this.sortEncumbrance.ToString("f1");
            this.craftingInfo[2].text = this.sortTier.ToString();
            CraftingItemData data = null;
            if ((itemData != null) && ((data = itemData as CraftingItemData) != null))
            {
                this.craftingInfo[0].text = CraftingItemData.varietyDisplayName[(int) data.variety];
            }
            else if ((itemData != null) && (itemData is CraftRecipeItemData))
            {
                this.craftingInfo[0].text = "Recipe";
            }
        }
    }

    protected override void SetLabel(BasicItemData itemData)
    {
        if (itemData == null)
        {
            base.nameLabel.text = "<NOT FOUND>";
        }
        else
        {
            base.nameLabel.text = this.item.GetDisplayName(true);
        }
        base.nameLabel.color = InventoryClient.GetQualityColor(this.item.GetQuality());
    }

    private enum AllInfo
    {
        ENCUMBRANCE,
        NUM_ITEMS
    }

    private enum CraftingInfo
    {
        VARIETY,
        ENCUMBRANCE,
        TIER,
        NUM_ITEMS
    }

    private enum EquipmentInfo
    {
        ENCUMBRANCE,
        DURABILITY,
        TIER,
        NUM_ITEMS
    }

    public enum Sort
    {
        NAME,
        ENCUMBRANCE,
        DURABILITY,
        TIER,
        VARIETY
    }
}

