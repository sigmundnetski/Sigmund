﻿using GNGUI;
using System;
using UnityEngine;

public abstract class FloatingCharacterBarGui : CharacterBarGui
{
    protected UIFollowTarget followTarget;
    protected bool initialized = false;
    protected UIFilledSprite staminaBar;
    protected BuffSprite[] stateBuffs;

    protected FloatingCharacterBarGui()
    {
    }

    public override void Awake()
    {
        this.stateBuffs = base.GetComponentsInChildren<BuffSprite>();
        GuiHelper.GuiAssertNotNull("Could not find State Buffs.", this.stateBuffs);
        foreach (UIFilledSprite sprite in base.GetComponentsInChildren<UIFilledSprite>())
        {
            if (sprite.name == "StaminaCurrent")
            {
                this.staminaBar = sprite;
            }
        }
        GuiHelper.GuiAssertNotNull("Could not find the stamina bar!", new object[] { this.staminaBar });
        base.Awake();
    }

    public virtual void Init(Transform followTransform)
    {
        if (!this.initialized)
        {
            this.followTarget = base.gameObject.AddComponent<UIFollowTarget>();
            this.followTarget.gameCamera = GraphicsClient.goblinCamera.GetComponent<Camera>();
            this.followTarget.uiCamera = NGUITools.FindCameraForLayer(8);
            this.followTarget.target = followTransform;
            this.followTarget.disableIfInvisible = false;
            this.followTarget.hideChildren = false;
            GuiHelper.GuiAssertNotNull("Could not find needed components.", new object[] { this.followTarget, this.followTarget.gameCamera, this.followTarget.uiCamera, this.followTarget.target });
            this.initialized = true;
        }
    }

    public override void SyncUpdateCv(CombatVars cv)
    {
        this.UpdateStateBuffs(cv);
        base.SyncUpdateCv(cv);
        if (cv != null)
        {
        }
    }

    private void UpdateStateBuffs(CombatVars cv)
    {
        for (int i = 0; i < this.stateBuffs.Length; i++)
        {
            this.stateBuffs[i].SyncUpdate(cv);
        }
    }
}

