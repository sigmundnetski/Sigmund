﻿using GNGUI;
using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

public class CompanyAllyInfo : TabListItem
{
    private ulong companyId;
    private UILabel infoLabel;
    private bool initialized = false;
    private const string MEMBER_COMPANY = "1_";
    private const string OWNER_COMPANY = "0_";
    private CompanyAlliancesTabGui parentTab;
    private bool selected;
    private const string SEPARATOR = ";";
    private uint settlementId;
    private UILabel sizeLabel;

    public void AllianceSelected(ulong companyId_, uint settlementId_)
    {
        Color playerSelectedColor;
        if ((this.companyId == companyId_) && (this.settlementId == settlementId_))
        {
            playerSelectedColor = CompanyWindowDetailsTabGui.playerSelectedColor;
        }
        else
        {
            playerSelectedColor = CompanyWindowDetailsTabGui.playerDefaultColor;
        }
        base.nameLabel.color = playerSelectedColor;
        this.sizeLabel.color = playerSelectedColor;
        this.infoLabel.color = playerSelectedColor;
    }

    public void Assign(uint settlementId_, CompanyAlliancesTabGui parent, int index, bool sortByIndex)
    {
        if (!this.initialized)
        {
            this.Init();
        }
        this.parentTab = parent;
        this.companyId = 0L;
        this.settlementId = settlementId_;
        SettlementRecord settlement = GroupClient.GetSettlement(this.settlementId);
        if (settlement == null)
        {
            base.nameLabel.text = string.Empty;
            this.sizeLabel.text = string.Empty;
            this.infoLabel.text = string.Empty;
            this.AllianceSelected(0L, 0);
        }
        else
        {
            this.selected = false;
            base.nameLabel.text = settlement.settlementName;
            base.name = sortByIndex ? index.ToString() : settlement.settlementName;
            this.sizeLabel.text = "Banner Companies: " + settlement.memberCompanyCount.ToString();
            this.infoLabel.text = string.Empty;
            this.AllianceSelected(0L, 0);
        }
    }

    public void Assign(ulong companyId_, SettlementRecord settlement, CompanyAlliancesTabGui parent, int index, bool sortByIndex)
    {
        if (!this.initialized)
        {
            this.Init();
        }
        this.companyId = companyId_;
        this.parentTab = parent;
        this.settlementId = 0;
        VentureCompanyRecord company = GroupClient.GetCompany(this.companyId);
        if (company == null)
        {
            base.nameLabel.text = string.Empty;
            this.sizeLabel.text = string.Empty;
            this.infoLabel.text = string.Empty;
            this.AllianceSelected(0L, 0);
        }
        else
        {
            List<GroupClient.TerritoryClientVars> list;
            bool flag = this.companyId == settlement.ownerCompanyId;
            this.selected = false;
            base.nameLabel.text = company.vcName;
            base.name = sortByIndex ? index.ToString() : ((flag ? "0_" : "1_") + company.vcName);
            this.sizeLabel.text = "Members: " + company.Count(false);
            StringBuilder quickText = GUtil.GetQuickText();
            if (flag)
            {
                quickText.Append(settlement.settlementName).Append(";");
            }
            int count = 0;
            if (GroupClient.settlementTerritories.TryGetValue(company.settlementId, out list))
            {
                count = list.Count;
            }
            for (int i = 0; i < count; i++)
            {
                GroupClient.TerritoryClientVars vars = list[i];
                if (vars.companyId == company.companyId)
                {
                    quickText.Append(MapClient.GetDisplayPosition("{0:f2}km {1}, {2:f2}km {3}", TerrainService.TranslateServerToWorld(vars.mapId, Vector3.zero)));
                    quickText.Append(";");
                }
            }
            this.infoLabel.text = quickText.ToString();
            this.AllianceSelected(0L, 0);
        }
    }

    public override void Awake()
    {
    }

    private void Init()
    {
        this.selected = false;
        foreach (UILabel label in base.GetComponentsInChildren<UILabel>(true))
        {
            if (label.name == "CompanyName")
            {
                base.nameLabel = label;
            }
            else if (label.name == "CompanySize")
            {
                this.sizeLabel = label;
            }
            else if (label.name == "CompanySettlementAndTowers")
            {
                this.infoLabel = label;
            }
        }
        GuiHelper.GuiAssertNotNull("Couldn't find label.", new object[] { base.nameLabel, this.sizeLabel, this.infoLabel });
        this.initialized = true;
    }

    public void OnClick()
    {
        this.selected = !this.selected;
        this.parentTab.AllianceSelected(this.selected ? this.companyId : ((ulong) 0L), this.selected ? this.settlementId : 0);
    }

    public override void OnTooltip(bool show)
    {
    }
}

