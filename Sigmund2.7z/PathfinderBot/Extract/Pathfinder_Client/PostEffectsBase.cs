﻿using System;
using UnityEngine;

[ExecuteInEditMode, RequireComponent(typeof(Camera))]
internal class PostEffectsBase : MonoBehaviour
{
    protected bool isSupported = true;
    protected bool supportDX11 = false;
    protected bool supportHDRTextures = true;

    public virtual bool CheckResources()
    {
        Debug.LogWarning("CheckResources() for " + this.ToString() + " should be overwritten.");
        return this.isSupported;
    }

    public bool CheckShader(Shader s)
    {
        Debug.Log("The shader " + s.ToString() + " on effect " + this.ToString() + " is not part of the Unity 3.2+ effects suite anymore. For best performance and quality, please ensure you are using the latest Standard Assets Image Effects(Pro only) package.");
        if (!s.isSupported)
        {
            this.NotSupported();
            return false;
        }
        return false;
    }

    public Material CheckShaderAndCreateMaterial(Shader s, Material m2Create)
    {
        if (s == null)
        {
            Debug.Log("Missing shader in " + this.ToString());
            base.enabled = false;
            return null;
        }
        if ((s.isSupported && (m2Create != null)) && (m2Create.shader == s))
        {
            return m2Create;
        }
        if (!s.isSupported)
        {
            this.NotSupported();
            Debug.LogError("The shader " + s.ToString() + " on effect " + this.ToString() + " is not supported on this platform!");
            return null;
        }
        m2Create = new Material(s);
        m2Create.hideFlags = HideFlags.DontSave;
        if (m2Create != 0)
        {
            return m2Create;
        }
        return null;
    }

    public bool CheckSupport()
    {
        return this.CheckSupport(false);
    }

    public bool CheckSupport(bool needDepth)
    {
        this.isSupported = true;
        this.supportHDRTextures = SystemInfo.SupportsRenderTextureFormat(RenderTextureFormat.ARGBHalf);
        this.supportDX11 = (SystemInfo.graphicsShaderLevel >= 50) && SystemInfo.supportsComputeShaders;
        if (!(SystemInfo.supportsImageEffects && SystemInfo.supportsRenderTextures))
        {
            this.NotSupported();
            return false;
        }
        if (!(!needDepth || SystemInfo.SupportsRenderTextureFormat(RenderTextureFormat.Depth)))
        {
            this.NotSupported();
            return false;
        }
        if (needDepth)
        {
            Camera camera = base.camera;
            camera.depthTextureMode |= DepthTextureMode.Depth;
        }
        return true;
    }

    public bool CheckSupport(bool needDepth, bool needHdr)
    {
        if (!this.CheckSupport(needDepth))
        {
            return false;
        }
        if (!(!needHdr || this.supportHDRTextures))
        {
            this.NotSupported();
            return false;
        }
        return true;
    }

    public Material CreateMaterial(Shader s, Material m2Create)
    {
        if (s == null)
        {
            Debug.Log("Missing shader in " + this.ToString());
            return null;
        }
        if (((m2Create != null) && (m2Create.shader == s)) && s.isSupported)
        {
            return m2Create;
        }
        if (s.isSupported)
        {
            m2Create = new Material(s);
            m2Create.hideFlags = HideFlags.DontSave;
            if (m2Create != 0)
            {
                return m2Create;
            }
        }
        return null;
    }

    public void DrawBorder(RenderTexture dest, Material material)
    {
        RenderTexture.active = dest;
        bool flag = true;
        GL.PushMatrix();
        GL.LoadOrtho();
        for (int i = 0; i < material.passCount; i++)
        {
            float num6;
            float num7;
            material.SetPass(i);
            if (flag)
            {
                num6 = 1f;
                num7 = 0f;
            }
            else
            {
                num6 = 0f;
                num7 = 1f;
            }
            float x = 0f;
            float num2 = 0f + (1f / (dest.width * 1f));
            float y = 0f;
            float num4 = 1f;
            GL.Begin(7);
            GL.TexCoord2(0f, num6);
            GL.Vertex3(x, y, 0.1f);
            GL.TexCoord2(1f, num6);
            GL.Vertex3(num2, y, 0.1f);
            GL.TexCoord2(1f, num7);
            GL.Vertex3(num2, num4, 0.1f);
            GL.TexCoord2(0f, num7);
            GL.Vertex3(x, num4, 0.1f);
            x = 1f - (1f / (dest.width * 1f));
            num2 = 1f;
            y = 0f;
            num4 = 1f;
            GL.TexCoord2(0f, num6);
            GL.Vertex3(x, y, 0.1f);
            GL.TexCoord2(1f, num6);
            GL.Vertex3(num2, y, 0.1f);
            GL.TexCoord2(1f, num7);
            GL.Vertex3(num2, num4, 0.1f);
            GL.TexCoord2(0f, num7);
            GL.Vertex3(x, num4, 0.1f);
            x = 0f;
            num2 = 1f;
            y = 0f;
            num4 = 0f + (1f / (dest.height * 1f));
            GL.TexCoord2(0f, num6);
            GL.Vertex3(x, y, 0.1f);
            GL.TexCoord2(1f, num6);
            GL.Vertex3(num2, y, 0.1f);
            GL.TexCoord2(1f, num7);
            GL.Vertex3(num2, num4, 0.1f);
            GL.TexCoord2(0f, num7);
            GL.Vertex3(x, num4, 0.1f);
            x = 0f;
            num2 = 1f;
            y = 1f - (1f / (dest.height * 1f));
            num4 = 1f;
            GL.TexCoord2(0f, num6);
            GL.Vertex3(x, y, 0.1f);
            GL.TexCoord2(1f, num6);
            GL.Vertex3(num2, y, 0.1f);
            GL.TexCoord2(1f, num7);
            GL.Vertex3(num2, num4, 0.1f);
            GL.TexCoord2(0f, num7);
            GL.Vertex3(x, num4, 0.1f);
            GL.End();
        }
        GL.PopMatrix();
    }

    public bool Dx11Support()
    {
        return this.supportDX11;
    }

    public void NotSupported()
    {
        base.enabled = false;
        this.isSupported = false;
    }

    public virtual void OnEnable()
    {
        this.isSupported = true;
    }

    public void ReportAutoDisable()
    {
        Debug.LogWarning("The image effect " + this.ToString() + " has been disabled as it's not supported on the current platform.");
    }

    public void Start()
    {
        this.CheckResources();
    }
}

