﻿using GNGUI;
using System;
using System.Collections.Generic;
using UnityEngine;

public class PaperdollWindowGui : WindowGui
{
    private FilterType currentFilter = FilterType.NONE;
    private Dictionary<BasicItemData.ItemSlot, EquipmentSlotGui> equipmentSlots = new Dictionary<BasicItemData.ItemSlot, EquipmentSlotGui>();
    private List<FeatSlotGui> featSlots = new List<FeatSlotGui>();
    public static PaperdollWindowGui singleton;

    public void Awake()
    {
        singleton = this;
        this.OnAwake();
    }

    public void CommandEvent(string[] args, EntityId playerEntityId)
    {
        this.ToggleWindowVisibility();
    }

    public void ContentsChanged()
    {
        if (base.IsShowing())
        {
            for (int i = 0; i < 0x11; i++)
            {
                InventoryItem item = EntityDataClient.owner.gear.bodySlots[i];
                if (!item.DataEquals(this.equipmentSlots[(BasicItemData.ItemSlot) ((byte) i)].equippedItemInfo, 0xff))
                {
                    if (InventoryItem.EMPTY_MATCH(item))
                    {
                        this.equipmentSlots[(BasicItemData.ItemSlot) ((byte) i)].UnequipItem();
                    }
                    else
                    {
                        this.equipmentSlots[(BasicItemData.ItemSlot) ((byte) i)].EquipItem(item);
                    }
                }
            }
            this.SetFeatSlots();
        }
    }

    public void DragEnd(InventoryItem item, BasicItemData.ItemSlot slot)
    {
        if ((UICamera.hoveredObject.GetComponent<EquipmentSlotGui>() == null) && (slot != BasicItemData.ItemSlot.NONE))
        {
            EquipmentSlotGui gui2 = this.equipmentSlots[slot];
            if (gui2.equippedItemInfo.DataEquals(item, 0xff))
            {
                this.EquipmentSlotChange(slot, BasicItemData.ItemSlot.NONE, item, InventoryItem.EMPTY);
            }
        }
        this.SetValidityByFilter(FilterType.EQUIPMENT, InventoryWindowGui.singleton.GetActiveTab().activeFilter);
    }

    public void DragEnd(GameObject go, Combat.FeatType featType, int featId)
    {
        FeatSlotGui component = go.GetComponent<FeatSlotGui>();
        FeatSlotGui gui2 = UICamera.hoveredObject.GetComponent<FeatSlotGui>();
        if ((component != null) && (gui2 == null))
        {
            foreach (FeatSlotGui gui3 in this.featSlots)
            {
                if (gui3.featId == featId)
                {
                    this.FeatSlotChange(gui3.featId, 0, featType);
                }
            }
        }
        this.SetValidityByFilter(FilterType.FEATS, FeatsWindowGui.singleton.GetActiveTab().activeFilter);
    }

    public void DragStart(Combat.FeatType featType)
    {
        foreach (EquipmentSlotGui gui in this.equipmentSlots.Values)
        {
            gui.ResetValidity();
        }
        foreach (FeatSlotGui gui2 in this.featSlots)
        {
            gui2.SetValidity(featType);
        }
    }

    public void DragStart(InventoryItem item)
    {
        BasicItemData.ItemSlot nONE = BasicItemData.ItemSlot.NONE;
        BasicItemData data = ItemDatabase.GetItem(item.staticItemId);
        if (data != null)
        {
            nONE = data.slot;
        }
        foreach (EquipmentSlotGui gui in this.equipmentSlots.Values)
        {
            gui.SetValidity(nONE);
        }
        foreach (FeatSlotGui gui2 in this.featSlots)
        {
            gui2.ResetValidity();
        }
    }

    public void EquipmentSlotChange(BasicItemData.ItemSlot fromSlot, BasicItemData.ItemSlot toSlot, InventoryItem oldItem, InventoryItem newItem)
    {
        InventoryClient.EquipmentSlotChange(fromSlot, toSlot, oldItem, newItem);
    }

    private void EquipmentSlotClicked(GameObject slotGO)
    {
        EquipmentSlotGui component = slotGO.GetComponent<EquipmentSlotGui>();
        if (component != null)
        {
            if (UICamera.currentTouchID == -2)
            {
                singleton.OnSlotRClick(component.gameObject, component.equippedItemInfo, component.slot);
            }
            else
            {
                InventoryWindowGui.singleton.EquipmentSlotClicked(component);
            }
        }
    }

    public void FeatSlotChange(int oldFeatId, int newFeatId, Combat.FeatType featType)
    {
        CommandCore.ExecuteCommand(string.Concat(new object[] { "SetPassiveFeat ", (int) featType, " ", oldFeatId, " ", newFeatId }), EntityDataClient.owner.entityId);
    }

    private void FeatSlotClicked(GameObject slotGO)
    {
        FeatSlotGui component = slotGO.GetComponent<FeatSlotGui>();
        if (component != null)
        {
            FeatsWindowGui.singleton.FeatSlotClicked(component);
        }
    }

    private void GetAllEqipmentSlots()
    {
        foreach (EquipmentSlotGui gui in base.GetComponentsInChildren<EquipmentSlotGui>())
        {
            UIEventListener listener1 = UIEventListener.Get(gui.gameObject);
            listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.EquipmentSlotClicked));
            switch (gui.name)
            {
                case "SlotArmor":
                    gui.Assign(BasicItemData.ItemSlot.ARMOR);
                    this.equipmentSlots[BasicItemData.ItemSlot.ARMOR] = gui;
                    break;

                case "SlotWaist":
                    gui.Assign(BasicItemData.ItemSlot.WAIST);
                    this.equipmentSlots[BasicItemData.ItemSlot.WAIST] = gui;
                    break;

                case "SlotHead":
                    gui.Assign(BasicItemData.ItemSlot.HEAD);
                    this.equipmentSlots[BasicItemData.ItemSlot.HEAD] = gui;
                    break;

                case "SlotFeet":
                    gui.Assign(BasicItemData.ItemSlot.FEET);
                    this.equipmentSlots[BasicItemData.ItemSlot.FEET] = gui;
                    break;

                case "SlotHands":
                    gui.Assign(BasicItemData.ItemSlot.HANDS);
                    this.equipmentSlots[BasicItemData.ItemSlot.HANDS] = gui;
                    break;

                case "SlotNeck":
                    gui.Assign(BasicItemData.ItemSlot.NECK);
                    this.equipmentSlots[BasicItemData.ItemSlot.NECK] = gui;
                    break;

                case "SlotFinger1":
                    gui.Assign(BasicItemData.ItemSlot.FINGER_1);
                    this.equipmentSlots[BasicItemData.ItemSlot.FINGER_1] = gui;
                    break;

                case "SlotFinger2":
                    gui.Assign(BasicItemData.ItemSlot.FINGER_2);
                    this.equipmentSlots[BasicItemData.ItemSlot.FINGER_2] = gui;
                    break;

                case "SlotBack":
                    gui.Assign(BasicItemData.ItemSlot.BACK);
                    this.equipmentSlots[BasicItemData.ItemSlot.BACK] = gui;
                    break;

                case "SlotWondrous1":
                    gui.Assign(BasicItemData.ItemSlot.WONDROUS_1);
                    this.equipmentSlots[BasicItemData.ItemSlot.WONDROUS_1] = gui;
                    break;

                case "SlotWondrous2":
                    gui.Assign(BasicItemData.ItemSlot.WONDROUS_2);
                    this.equipmentSlots[BasicItemData.ItemSlot.WONDROUS_2] = gui;
                    break;

                case "SlotWeapon1Main":
                    gui.Assign(BasicItemData.ItemSlot.WEAPON_SET_1_MAIN_HAND);
                    this.equipmentSlots[BasicItemData.ItemSlot.WEAPON_SET_1_MAIN_HAND] = gui;
                    break;

                case "SlotWeapon1Off":
                    gui.Assign(BasicItemData.ItemSlot.WEAPON_SET_1_OFF_HAND);
                    this.equipmentSlots[BasicItemData.ItemSlot.WEAPON_SET_1_OFF_HAND] = gui;
                    break;

                case "SlotWeapon2Main":
                    gui.Assign(BasicItemData.ItemSlot.WEAPON_SET_2_MAIN_HAND);
                    this.equipmentSlots[BasicItemData.ItemSlot.WEAPON_SET_2_MAIN_HAND] = gui;
                    break;

                case "SlotWeapon2Off":
                    gui.Assign(BasicItemData.ItemSlot.WEAPON_SET_2_OFF_HAND);
                    this.equipmentSlots[BasicItemData.ItemSlot.WEAPON_SET_2_OFF_HAND] = gui;
                    break;

                case "SlotImplement1":
                    gui.Assign(BasicItemData.ItemSlot.IMPLEMENT_1);
                    this.equipmentSlots[BasicItemData.ItemSlot.IMPLEMENT_1] = gui;
                    break;

                case "SlotImplement2":
                    gui.Assign(BasicItemData.ItemSlot.IMPLEMENT_2);
                    this.equipmentSlots[BasicItemData.ItemSlot.IMPLEMENT_2] = gui;
                    break;

                default:
                    Debug.LogWarning("Unknown equipment slot '" + gui.name + "'.");
                    break;
            }
        }
    }

    private void GetAllFeatSlots()
    {
        foreach (FeatSlotGui gui in base.GetComponentsInChildren<FeatSlotGui>())
        {
            this.featSlots.Add(gui);
            UIEventListener listener1 = UIEventListener.Get(gui.gameObject);
            listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.FeatSlotClicked));
            switch (gui.name)
            {
                case "FeatArmor":
                    gui.Assign(Combat.FeatType.Armor, 0);
                    break;

                case "FeatDefensive1":
                    gui.Assign(Combat.FeatType.Defensive, 0);
                    break;

                case "FeatDefensive2":
                    gui.Assign(Combat.FeatType.Defensive, 1);
                    break;

                case "FeatDefensive3":
                    gui.Assign(Combat.FeatType.Defensive, 2);
                    break;

                case "FeatFeature":
                    gui.Assign(Combat.FeatType.Feature, 0);
                    break;

                case "FeatMagic1":
                case "FeatMagic2":
                    break;

                case "FeatReactive1":
                    gui.Assign(Combat.FeatType.Reactive, 0);
                    break;

                case "FeatReactive2":
                    gui.Assign(Combat.FeatType.Reactive, 1);
                    break;

                default:
                    Debug.LogWarning("Unknown feat slot '" + gui.name + "'.");
                    break;
            }
        }
    }

    public override void HideWindow()
    {
        base.HideWindow();
        foreach (EquipmentSlotGui gui in this.equipmentSlots.Values)
        {
            gui.ResetValidity();
        }
    }

    private void OnAwake()
    {
        singleton = this;
        this.GetAllEqipmentSlots();
        this.GetAllFeatSlots();
    }

    public override void OnDestroy()
    {
        base.OnDestroy();
        singleton = null;
    }

    public void OnSlotRClick(GameObject clickedGO, InventoryItem item, BasicItemData.ItemSlot slot)
    {
        if (!InventoryItem.EMPTY_MATCH(item))
        {
            BasicItemData itemData = ItemDatabase.GetItem(item.staticItemId);
            if (SparseArray.IndexOf<BasicItemData.ItemSlot>(InventoryClient.COLORABLE_SLOTS, x => x == itemData.slot) != -1)
            {
                InventoryItemRClick.singleton.ShowRecolorWindow(clickedGO.transform.position, item, slot);
            }
        }
    }

    public void ResetValidity(FilterType type)
    {
        if (type == this.currentFilter)
        {
            foreach (EquipmentSlotGui gui in this.equipmentSlots.Values)
            {
                gui.ResetValidity();
            }
            foreach (FeatSlotGui gui2 in this.featSlots)
            {
                gui2.ResetValidity();
            }
        }
    }

    private void SetEquipmentSlots()
    {
        for (int i = 0; i < 0x11; i++)
        {
            InventoryItem item = EntityDataClient.owner.gear.bodySlots[i];
            if (InventoryItem.EMPTY_MATCH(item))
            {
                this.equipmentSlots[(BasicItemData.ItemSlot) ((byte) i)].UnequipItem();
            }
            else
            {
                this.equipmentSlots[(BasicItemData.ItemSlot) ((byte) i)].EquipItem(item);
            }
        }
    }

    private void SetFeatSlots()
    {
        foreach (FeatSlotGui gui in this.featSlots)
        {
            gui.UpdateFeat();
        }
    }

    public void SetValidityByFilter(FilterType type, ToggleText filter)
    {
        int[] slotFilters = (filter == null) ? null : filter.filterIds;
        if (type == FilterType.EQUIPMENT)
        {
            foreach (EquipmentSlotGui gui in this.equipmentSlots.Values)
            {
                gui.SetValidity(slotFilters);
            }
            foreach (FeatSlotGui gui2 in this.featSlots)
            {
                gui2.ResetValidity();
            }
        }
        else if (type == FilterType.FEATS)
        {
            foreach (EquipmentSlotGui gui in this.equipmentSlots.Values)
            {
                gui.ResetValidity();
            }
            foreach (FeatSlotGui gui2 in this.featSlots)
            {
                gui2.SetValidity(slotFilters);
            }
        }
        this.currentFilter = (filter == null) ? FilterType.NONE : type;
    }

    public override void ShowWindow()
    {
        base.ShowWindow();
        this.SetEquipmentSlots();
        this.SetFeatSlots();
    }

    public void Start()
    {
        base.Init(3, true);
    }

    public enum FilterType
    {
        NONE,
        EQUIPMENT,
        FEATS
    }

    public enum Tabs
    {
        PASSIVE_FEATS,
        ACTIVE_FEATS,
        NUM_TABS
    }
}

