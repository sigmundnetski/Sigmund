﻿using GNetwork;
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public static class EntityClient
{
    private static Transform npcProxyParent = null;
    public static Transform playerProxyParent = null;

    private static void AddPlayerComponents(GameObject newCharacter, GConst.CreateType flags)
    {
        if (flags != GConst.CreateType.TEST_EMPTY_ENTITY)
        {
            Animator component = newCharacter.GetComponent<Animator>();
            if (component != null)
            {
                component.cullingMode = AnimatorCullingMode.AlwaysAnimate;
            }
            GrannyAnimator animator2 = newCharacter.GetComponent<GrannyAnimator>();
            if (animator2 != null)
            {
                animator2.cullingMode = AnimatorCullingMode.AlwaysAnimate;
            }
            if ((component != null) || (animator2 != null))
            {
                if (flags == GConst.CreateType.PLAYER)
                {
                    newCharacter.AddComponent<EntityMotion>();
                }
                else
                {
                    newCharacter.AddComponent<PassiveAnimator>();
                }
            }
        }
    }

    public static void DespawnEntity(Entity entity)
    {
        UnityEngine.Object.Destroy(entity.gameObject);
        entity.CleanUp();
    }

    public static void InteractCommand(string[] args, EntityId playerEntityId)
    {
        GameObject obj2;
        Entity entity;
        Targeting.GetRaycastTarget(false, PlayerEntityClient.GetPlayer(), out obj2, out entity);
        if (entity != null)
        {
            ClientInputManager.singleton.CancelAutorun();
            GRouting.SendMyMapRpc(GRpcID.NpcEntityServer_Interact, new object[] { entity.entityId });
        }
        else if (obj2 != null)
        {
            Door component = obj2.GetComponent<Door>();
            if (component != null)
            {
                ClientInputManager.singleton.CancelAutorun();
                FacilityClient.OnDoorClick(component);
            }
        }
    }

    public static bool LoadingTick()
    {
        GameObject obj2 = GameObject.Find("/Programming/NpcProxyParent");
        GameObject obj3 = GameObject.Find("/Programming/PlayerProxyParent");
        npcProxyParent = (obj2 != null) ? obj2.transform : null;
        playerProxyParent = (obj3 != null) ? obj3.transform : null;
        return ((npcProxyParent != null) && (playerProxyParent != null));
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void NpcResponse(EntityId npcEntityId, bool copyToChat, string message)
    {
        GameObject gameObjectByEntityId = EntityCore.GetGameObjectByEntityId(ref npcEntityId);
        if (gameObjectByEntityId != null)
        {
            UIClient.AddOverheadText(gameObjectByEntityId, UIClient.NPC_CONVO_COLOR, message, 10f);
        }
        if (copyToChat)
        {
            DebugClient.GenericDebugMessage(message);
        }
    }

    public static void OnDisconnectedFromServer()
    {
        Entity[] entityArray = EntityCore.GetAllEntities(true).ToArray<Entity>();
        for (int i = 0; i < entityArray.Length; i++)
        {
            DespawnEntity(entityArray[i]);
        }
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void ReceiveLoginInfo(string name)
    {
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void ReceiveLogoutInfo(string name)
    {
    }

    public static void SpawnEntity(Entity entity)
    {
        GConst.CreateType createType;
        bool flag = entity.createType == GConst.CreateType.PLAYER;
        Transform parent = flag ? playerProxyParent : npcProxyParent;
        if (entity.createType == GConst.CreateType.PLAYER)
        {
            createType = GConst.CreateType.PLAYER_PROXY;
        }
        else
        {
            createType = entity.createType;
        }
        try
        {
            UpdateEquipment(entity);
            IEnumerable<EquipmentAsset> equipment = null;
            if (entity.gear != null)
            {
                equipment = InventoryClient.GetAllEquippedAssets(entity.gear.equippedGear, entity.entityDefnId);
            }
            GameObject obj2 = EntityLoadClient.CreateCompleteCharacter(entity, equipment, createType, parent, entity.GetLocalPosition(), entity.rotation, entity.entityName);
            entity.gameObject = obj2;
            if (flag)
            {
                EntityCore.MoveToLayer(obj2.transform, 10);
            }
            else if (createType == GConst.CreateType.COLLISIONLESS_NPC)
            {
                EntityCore.MoveToLayer(obj2.transform, 11);
            }
            else
            {
                EntityCore.MoveToLayer(obj2.transform, 9);
            }
            obj2.GetComponent<EntityVars>().AssignEntityVars(entity.entityId, entity.entityDefnId, entity.entityName);
        }
        catch (Exception exception)
        {
            GLog.LogError(new object[] { exception.ToString() });
        }
        entity.Initialize();
        if ((entity.combat != null) && entity.combat.inCombat)
        {
            EntityLoadClient.SetWeaponVis(entity.gameObject, true);
        }
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void SyncProxy(IBitBufferRead buffer)
    {
        ushort srcMapId = buffer.PopUShort();
        while (buffer.lengthBits > 0)
        {
            GameObject gameObjectByEntityId = EntityCore.GetGameObjectByEntityId(ref buffer.PopEntityId());
            if (gameObjectByEntityId != null)
            {
                gameObjectByEntityId.GetComponent<Movement>().PopFromBuffer(buffer, srcMapId);
            }
            else
            {
                Movement.PopOffOfBuffer(buffer);
            }
        }
    }

    private static void SyncStart()
    {
        EntityLoadClient.RegisterAddComponentDelegates(new EntityLoadClient.AddEntityComponentsDelegate(EntityClient.AddPlayerComponents));
    }

    public static void UpdateEntity(Entity entity)
    {
        if (UpdateEquipment(entity))
        {
            IEnumerable<EquipmentAsset> allEquippedAssets = InventoryClient.GetAllEquippedAssets(entity.gear.equippedGear, entity.entityDefnId);
            EntityLoadClient.ModifyCharacter(entity.gameObject, entity.entityDefnId, entity.physique, allEquippedAssets);
        }
    }

    public static bool UpdateEquipment(Entity entity)
    {
        if (entity.gear == null)
        {
            return false;
        }
        uint weaponSet = 0;
        if (entity.combat != null)
        {
            weaponSet = entity.combat.GetWeaponSet();
        }
        bool flag = false;
        for (int i = 0; i < 0x11; i++)
        {
            InventoryItem item = entity.gear.bodySlots[i];
            if (!item.DataEquals(entity.gear.equippedGear[i], 0xff))
            {
                entity.gear.equippedGear[i] = item;
                if (i <= 6)
                {
                    flag = true;
                }
                if ((weaponSet == 0) && ((i == 9) || (i == 10)))
                {
                    UpdateNonArmorAssets(entity, item, (BasicItemData.ItemSlot) ((byte) i));
                }
                else if ((weaponSet == 1) && ((i == 11) || (i == 12)))
                {
                    UpdateNonArmorAssets(entity, item, (BasicItemData.ItemSlot) ((byte) i));
                }
            }
        }
        if (((byte) (entity.flags & EntityFlags.GmSuit)) != ((byte) (entity.gear.flags & EntityFlags.GmSuit)))
        {
            entity.gear.flags = entity.flags;
            flag = true;
        }
        return flag;
    }

    private static void UpdateNonArmorAssets(Entity entity, InventoryItem item, BasicItemData.ItemSlot toSlot)
    {
        GameObject gameObject = entity.gameObject;
        if ((gameObject != null) && (toSlot != BasicItemData.ItemSlot.NONE))
        {
            WeaponComponent component = gameObject.GetComponent<WeaponComponent>();
            if (component != null)
            {
                component.SetWeaponType(item, ((toSlot == BasicItemData.ItemSlot.WEAPON_SET_1_MAIN_HAND) || (toSlot == BasicItemData.ItemSlot.WEAPON_SET_2_MAIN_HAND)) ? CombatClassVars.LogicalHand.MAIN_HAND : CombatClassVars.LogicalHand.OFF_HAND);
                BaseMotion motion = gameObject.GetComponent<BaseMotion>();
                if (motion != null)
                {
                    motion.ChangeWeapons(entity.combat);
                }
            }
            if ((gameObject == PlayerEntityClient.GetPlayer()) && (ButtonBarGui.singleton != null))
            {
                ButtonBarGui.singleton.SetAllButtons(entity.combat);
            }
        }
    }
}

