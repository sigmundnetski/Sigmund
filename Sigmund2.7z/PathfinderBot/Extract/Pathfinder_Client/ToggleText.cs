﻿using GNGUI;
using System;
using UnityEngine;

public class ToggleText : MonoBehaviour
{
    private static Color activeColor = new Color(0.9411765f, 0.8901961f, 0.6588235f);
    public int[] filterIds;
    public string filterName;
    private static Color inactiveColor = new Color(0.4705882f, 0.4431373f, 0.3294118f);
    public bool isActive = false;
    private UILabel label;

    public void Awake()
    {
        this.label = base.GetComponent<UILabel>();
        this.label.color = inactiveColor;
    }

    public void Init(int[] ids)
    {
        this.filterIds = ids;
    }

    public void Init(string text, int[] ids)
    {
        this.filterName = text;
        this.label.text = text;
        this.filterIds = ids;
    }

    public void SetActive(bool isActive_)
    {
        this.isActive = isActive_;
        if (this.isActive)
        {
            this.label.color = activeColor;
        }
        else
        {
            this.label.color = inactiveColor;
        }
    }

    public void ToggleActive()
    {
        this.SetActive(!this.isActive);
    }
}

