﻿using GNGUI;
using System;
using UnityEngine;

public class FlagIconGui : MonoBehaviour
{
    private UISprite icon;
    public PvpFlagsGui parent;

    public void Awake()
    {
        this.icon = base.GetComponentInChildren<UISprite>();
        GuiHelper.GuiAssertNotNull("Something's null...", new object[] { this.icon });
    }

    public void OnHover(bool isOver)
    {
        if (this.parent != null)
        {
            this.parent.IconHover(isOver, this);
        }
    }

    public void SyncFixedUpdate(string iconName)
    {
        this.icon.spriteName = iconName;
    }
}

