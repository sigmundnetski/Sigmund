﻿using GNGUI;
using System;
using UnityEngine;

public class AchievementItem : MonoBehaviour
{
    private const string colorFormat = "{0}{1}[-]";
    private GenericAchievementData data;
    private UILabel detailsLabel;
    private UILabel nameLabel;
    private AchievementsWindowGui parent;
    private const string pin_cl = "panel_button_pin_cl";
    private const string pin_de = "panel_button_pin_ac";
    private const string pin_mo = "panel_button_pin_mo";
    private UIImageButton pinButton;
    [HideInInspector]
    public int slotId = 0;
    private const string unpin_cl = "panel_button_unpin_cl";
    private const string unpin_de = "panel_button_unpin_de";
    private const string unpin_mo = "panel_button_unpin_mo";
    private const string whiteTextColorCode = "[FFFFFF]";

    private void Awake()
    {
        this.detailsLabel = base.transform.Find("Details").GetComponent<UILabel>();
        this.nameLabel = base.transform.Find("Name").GetComponent<UILabel>();
        this.pinButton = base.transform.Find("PinButton").GetComponent<UIImageButton>();
        GuiHelper.GuiAssertNotNull("Could not find needed components!", new object[] { this.detailsLabel, this.nameLabel, this.pinButton });
        this.nameLabel.text = string.Empty;
        this.detailsLabel.text = string.Empty;
        UIEventListener listener1 = UIEventListener.Get(this.pinButton.gameObject);
        listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.PinButtonClicked));
    }

    public void OnTooltip(bool show)
    {
        if (show)
        {
            string hoverText = AdvancementClient.GetHoverText(null, this.data);
            if (!string.IsNullOrEmpty(hoverText))
            {
                this.parent.tooltip.ShowText(hoverText, this.parent.gameObject);
                return;
            }
        }
        this.parent.tooltip.ShowText(null, null);
    }

    private void PinButtonClicked(GameObject go)
    {
        if ((this.data != null) && !EntityDataClient.owner.advancementVars.HasAchievement(this.data))
        {
            AdvancementClient.TogglePinButton(this.data);
            this.SetPinned(AdvancementClient.IsPinned(this.data.id));
            EventBarGui.Repopulate();
        }
    }

    public void SetAchievement(AchievementsWindowGui _parent, GenericAchievementData setData)
    {
        this.parent = _parent;
        if (this.data != setData)
        {
            this.data = setData;
            base.name = AdvancementClient.GetOrderingString(this.data);
            this.slotId = this.data.slotId;
            this.nameLabel.text = this.data.displayName;
            this.SetPinned(AdvancementClient.IsPinned(this.data.id));
        }
        this.detailsLabel.text = AdvancementClient.GetBody("Level: " + this.data.level + "\n", setData);
    }

    public void SetPinned(bool pinned)
    {
        if (pinned)
        {
            this.pinButton.normalSprite = "panel_button_pin_ac";
            this.pinButton.hoverSprite = "panel_button_pin_mo";
            this.pinButton.pressedSprite = "panel_button_pin_cl";
            if (EventBarGui.singleton != null)
            {
                EventBarGui.singleton.ShowPanel();
            }
        }
        else
        {
            this.pinButton.normalSprite = "panel_button_unpin_de";
            this.pinButton.hoverSprite = "panel_button_unpin_mo";
            this.pinButton.pressedSprite = "panel_button_unpin_cl";
        }
        this.pinButton.SendMessage("OnHover", false, SendMessageOptions.DontRequireReceiver);
    }
}

