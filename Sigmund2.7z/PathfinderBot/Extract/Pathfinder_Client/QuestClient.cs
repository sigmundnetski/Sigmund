﻿using GNetwork;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

public static class QuestClient
{
    public static HashSet<int> availableQuestIds = new HashSet<int>();
    public static int[] curBlobQuestIds = new int[0];
    private static int lastQuestHash = 0;
    public static EntityId questGiverEntityId = EntityId.INVALID_ID;
    internal const string questHudTextColorCode = "[F0E3A8]";
    private static int[] tempBlobIds = new int[8];
    private static QuestRecord[] tempRecordList = new QuestRecord[8];
    private static TrackedQuest[] trackedQuests = new TrackedQuest[3];
    private static bool updateBlobText;
    private static bool updateQuestLog;

    public static void AbandonQuest(int questId)
    {
        updateQuestLog = true;
        UntrackQuest(questId);
        GRouting.SendMyMapRpc(GRpcID.QuestServer_AbandonQuest, new object[] { questId });
    }

    public static void AcceptQuest(int questId)
    {
        GRouting.SendMyMapRpc(GRpcID.QuestServer_AcceptQuest, new object[] { questGiverEntityId, questId });
        availableQuestIds.Remove(questId);
        QuestGiverGui.Repopulate();
        TrackNewQuest(questId, false);
    }

    public static void DeclineQuest(int questId)
    {
        availableQuestIds.Remove(questId);
        QuestGiverGui.Repopulate();
    }

    public static QuestRecord[] GetActivePersonalQuests(bool isFinished)
    {
        SparseArray.Clear<QuestRecord>(ref tempRecordList);
        foreach (QuestRecord record in EntityDataClient.owner.playerRecord.GetActiveQuests())
        {
            if ((((record != null) && (record.eventId == 0)) && (isFinished == IsQuestFinished(record))) && QuestData.questById.ContainsKey(record.questId))
            {
                SparseArray.Add<QuestRecord>(ref tempRecordList, record);
            }
        }
        return tempRecordList;
    }

    public static IEnumerable<ITrackerElement> GetQuestsToDisplay()
    {
        return SparseArray.Iterate<ITrackerElement>(trackedQuests);
    }

    public static string GetQuestText(QuestData questData, bool longQuestText, bool longStateText)
    {
        QuestRecord quest = EntityDataClient.owner.playerRecord.GetQuest(questData.id);
        StringBuilder quickText = GUtil.GetQuickText();
        quickText.Append(questData.displayName);
        quickText.Append("\n");
        quickText.Append(longQuestText ? questData.longDescription : questData.shortDescription);
        quickText.Append("\n\nObjective:\n");
        quickText.Append("[F0E3A8]");
        QuestData.AppendObjective(quickText, quest, longStateText);
        quickText.Append("[-]\n");
        return quickText.ToString();
    }

    public static bool IsPinned(int questId)
    {
        for (int i = 0; i < trackedQuests.Length; i++)
        {
            if ((trackedQuests[i] != null) && (trackedQuests[i].questData.id == questId))
            {
                return true;
            }
        }
        return false;
    }

    private static bool IsQuestFinished(QuestRecord qRecord)
    {
        QuestData data;
        return (QuestData.questById.TryGetValue(qRecord.questId, out data) && (qRecord.stateIndex >= data.states.Count));
    }

    public static void OnClientEntityUpdate(Entity entity)
    {
        if (object.ReferenceEquals(entity, EntityDataClient.owner))
        {
            int questHashCode = entity.playerRecord.GetQuestHashCode();
            if (updateBlobText)
            {
                SetQuestBlob(curBlobQuestIds);
                updateBlobText = false;
            }
            if (((updateQuestLog || (lastQuestHash != questHashCode)) && (QuestLogGui.singleton != null)) && QuestLogGui.singleton.IsShowing())
            {
                UntrackFinishedQuests();
                QuestLogGui.Repopulate(false);
                lastQuestHash = questHashCode;
                updateQuestLog = false;
            }
        }
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void OnQuestAvailable(EntityId questEntityId, int questId)
    {
        if (!EntityCore.Match(questGiverEntityId, questEntityId))
        {
            questGiverEntityId = questEntityId;
            availableQuestIds.Clear();
        }
        availableQuestIds.Add(questId);
        QuestGiverGui.Repopulate();
    }

    public static void SetQuestBlob(params int[] questIds)
    {
        curBlobQuestIds = questIds;
        bool flag = false;
        SparseArray.Clear<int>(ref tempBlobIds, 0);
        for (int i = 0; i < questIds.Length; i++)
        {
            if (questIds[i] != 0)
            {
                QuestRecord quest = EntityDataClient.owner.playerRecord.GetQuest(questIds[i]);
                BaseQuestState currentState = QuestData.GetCurrentState(quest);
                if (((quest != null) && (currentState != null)) && (currentState.blobId != 0))
                {
                    SparseArray.Add<int>(ref tempBlobIds, currentState.blobId, SparseArray.INVALID_ID, 0);
                    flag = true;
                }
                else if (currentState == null)
                {
                    questIds[i] = 0;
                    flag = true;
                }
            }
        }
        if (flag)
        {
            TextBlobGui.Display(tempBlobIds);
        }
    }

    public static void TogglePinButton(int questId)
    {
        if (!UntrackQuest(questId))
        {
            TrackNewQuest(questId, true);
        }
        EventBarGui.Repopulate();
    }

    public static void ToggleQuestLog(string[] args, EntityId playerEntityId)
    {
        if (QuestLogGui.singleton != null)
        {
            QuestLogGui.singleton.ToggleWindowVisibility();
        }
    }

    public static void TrackNewQuest(int questId, bool userPinned)
    {
        int num;
        TrackedQuest quest = new TrackedQuest(QuestData.questById[questId], Time.time, userPinned);
        for (num = 0; num < trackedQuests.Length; num++)
        {
            if (trackedQuests[num] == null)
            {
                trackedQuests[num] = quest;
                return;
            }
        }
        float num2 = (from each in trackedQuests
            where !each.userPinned
            orderby each.timestamp
            select each.timestamp).FirstOrDefault<float>();
        for (num = 0; num < trackedQuests.Length; num++)
        {
            if (trackedQuests[num].timestamp == num2)
            {
                trackedQuests[num] = quest;
                return;
            }
        }
        if (userPinned)
        {
            num2 = (from each in trackedQuests
                orderby each.timestamp
                select each.timestamp).First<float>();
            for (num = 0; num < trackedQuests.Length; num++)
            {
                if (trackedQuests[num].timestamp == num2)
                {
                    trackedQuests[num] = quest;
                    break;
                }
            }
        }
    }

    public static void UndoAbandonQuest()
    {
        updateQuestLog = true;
        GRouting.SendMyMapRpc(GRpcID.QuestServer_AbandonQuest, new object[] { 0 });
    }

    private static void UntrackFinishedQuests()
    {
        for (int i = 0; i < trackedQuests.Length; i++)
        {
            if ((trackedQuests[i] != null) && IsQuestFinished(EntityDataClient.owner.playerRecord.GetQuest(trackedQuests[i].questData.id)))
            {
                trackedQuests[i] = null;
            }
        }
    }

    private static bool UntrackQuest(int questId)
    {
        for (int i = 0; i < trackedQuests.Length; i++)
        {
            if ((trackedQuests[i] != null) && (trackedQuests[i].questData.id == questId))
            {
                trackedQuests[i] = null;
                return true;
            }
        }
        return false;
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void UpdateTextBlob(int questId, bool auto, bool force)
    {
        bool flag = SparseArray.IndexOf<int>(curBlobQuestIds, x => x == questId, SparseArray.INVALID_ID) != -1;
        if (!(!auto || flag))
        {
            curBlobQuestIds = new int[] { questId };
        }
        updateBlobText |= (auto || flag) || force;
    }
}

