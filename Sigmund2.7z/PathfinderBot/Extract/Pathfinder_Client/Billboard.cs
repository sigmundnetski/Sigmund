﻿using System;
using UnityEngine;

internal class Billboard : MonoBehaviour
{
    private void Update()
    {
        if (GraphicsClient.goblinCamera != null)
        {
            base.transform.LookAt(base.transform.position + (GraphicsClient.goblinCamera.transform.rotation * Vector3.forward), (Vector3) (GraphicsClient.goblinCamera.transform.rotation * Vector3.up));
        }
    }
}

