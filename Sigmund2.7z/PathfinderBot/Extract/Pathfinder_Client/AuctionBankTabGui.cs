﻿using System;

public class AuctionBankTabGui : AuctionInvItemTabGui
{
    public static AuctionBankTabGui singleton;

    public override void Awake()
    {
        singleton = this;
        this.OnAwake();
    }

    protected override InventoryItem[] GetReadonlyItems()
    {
        return InventoryClient.playerBank;
    }

    private void OnAwake()
    {
        base.Awake();
        base.itemSource = Item.Container.BANK;
    }

    public void OnDestroy()
    {
        singleton = null;
    }
}

