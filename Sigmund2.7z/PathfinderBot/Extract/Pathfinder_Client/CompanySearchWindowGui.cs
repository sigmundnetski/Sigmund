﻿using GNGUI;
using System;
using System.Collections.Generic;
using UnityEngine;

public class CompanySearchWindowGui : WindowGui
{
    private List<SortButton> allSorts = new List<SortButton>();
    private UIGrid companyGrid;
    private GameObject companyInfoPrefab = null;
    private VentureCompanyRecord.Goal currentGoals;
    private PvpConst.Reputation currentReputations;
    private SortButton currentSort = null;
    private List<CompanySearchInfoGui> displayedItems = new List<CompanySearchInfoGui>();
    private ToggleIcon[] goalToggles = new ToggleIcon[8];
    private ToggleIcon[] repToggles = new ToggleIcon[5];
    private UIScrollBar scrollBar;
    private string search = string.Empty;
    private UIInput searchInput;
    public static CompanySearchWindowGui singleton;

    public void Awake()
    {
        singleton = this;
    }

    public void GoalToggleClicked(ToggleIcon toggleIcon)
    {
        if (toggleIcon.state)
        {
            this.currentGoals = (VentureCompanyRecord.Goal) ((byte) (this.currentGoals | ((byte) toggleIcon.id)));
        }
        else
        {
            this.currentGoals = (VentureCompanyRecord.Goal) ((byte) (this.currentGoals & ~((byte) toggleIcon.id)));
        }
        GLog.Log(new object[] { toggleIcon.name, toggleIcon.id, toggleIcon.state, "current:", this.currentGoals });
        this.RequestSearchResults();
    }

    public bool LoadingTickFinished()
    {
        this.companyInfoPrefab = UIClient.guiPrefabs["CompanySearchItem"];
        GuiHelper.GuiAssertNotNull("Couldn't load prefab.", new object[] { this.companyInfoPrefab });
        return true;
    }

    private void MakeItems()
    {
        int num = 0;
        for (int i = 0; i < GroupClient.lastSearchResult.Length; i++)
        {
            if (GroupClient.lastSearchResult[i] != null)
            {
                if (num >= this.displayedItems.Count)
                {
                    CompanySearchInfoGui component = NGUITools.AddChild(this.companyGrid.gameObject, this.companyInfoPrefab).GetComponent<CompanySearchInfoGui>();
                    this.displayedItems.Add(component);
                }
                this.displayedItems[num].Assign(GroupClient.lastSearchResult[i]);
                num++;
            }
        }
        while (this.displayedItems.Count > num)
        {
            CompanySearchInfoGui gui2 = this.displayedItems[this.displayedItems.Count - 1];
            this.displayedItems.RemoveAt(this.displayedItems.Count - 1);
            gui2.gameObject.SetActive(false);
            gui2.transform.parent = DragDropRoot.root;
            UnityEngine.Object.Destroy(gui2.gameObject);
        }
        this.ResortContents((Sort) this.currentSort.sortId, this.currentSort.sort);
    }

    public override void OnDestroy()
    {
        base.OnDestroy();
        singleton = null;
    }

    public void OnSubmit(string input)
    {
        this.search = input;
        this.RequestSearchResults();
    }

    public void RepToggleClicked(ToggleIcon toggleIcon)
    {
        if (toggleIcon.state)
        {
            this.currentReputations |= toggleIcon.id;
        }
        else
        {
            this.currentReputations &= ~toggleIcon.id;
        }
        GLog.Log(new object[] { toggleIcon.name, toggleIcon.id, toggleIcon.state, "current:", this.currentReputations });
        this.RequestSearchResults();
    }

    public void RequestSearchResults()
    {
        GroupClient.RequestCompanySearch(this.search, this.currentGoals, this.currentReputations);
    }

    public void ResetScroll()
    {
        this.scrollBar.scrollValue = 0f;
    }

    private void ResortContents(Sort sortField, SortButton.SortType sortType)
    {
        IEnumerable<CompanySearchInfoGui> enumerable = null;
        if (sortField == Sort.NAME)
        {
            if (sortType == SortButton.SortType.DESCENDING)
            {
                enumerable = from each in this.displayedItems
                    orderby each.sortName descending
                    select each;
            }
            else if (sortType == SortButton.SortType.ASCENDING)
            {
                enumerable = from each in this.displayedItems
                    orderby each.sortName
                    select each;
            }
            else
            {
                GLog.LogError(new object[] { "Don't know how to sort", sortField, "by", sortType });
            }
        }
        else if (sortField == Sort.SIZE)
        {
            if (sortType == SortButton.SortType.DESCENDING)
            {
                enumerable = from each in this.displayedItems
                    orderby each.sortSize descending
                    select each;
            }
            else if (sortType == SortButton.SortType.ASCENDING)
            {
                enumerable = from each in this.displayedItems
                    orderby each.sortSize
                    select each;
            }
            else
            {
                GLog.LogError(new object[] { "Don't know how to sort", sortField, "by", sortType });
            }
        }
        else if (sortField == Sort.ALIGNMENT)
        {
            if (sortType == SortButton.SortType.DESCENDING)
            {
                enumerable = from each in this.displayedItems
                    orderby each.sortAlignment descending
                    select each;
            }
            else if (sortType == SortButton.SortType.ASCENDING)
            {
                enumerable = from each in this.displayedItems
                    orderby each.sortAlignment
                    select each;
            }
            else
            {
                GLog.LogError(new object[] { "Don't know how to sort", sortField, "by", sortType });
            }
        }
        else if (sortField == Sort.HOLDINGS)
        {
            if (sortType == SortButton.SortType.DESCENDING)
            {
                enumerable = from each in this.displayedItems
                    orderby each.sortHoldings descending
                    select each;
            }
            else if (sortType == SortButton.SortType.ASCENDING)
            {
                enumerable = from each in this.displayedItems
                    orderby each.sortHoldings
                    select each;
            }
            else
            {
                GLog.LogError(new object[] { "Don't know how to sort", sortField, "by", sortType });
            }
        }
        else if (sortField == Sort.REPUTATION)
        {
            if (sortType == SortButton.SortType.DESCENDING)
            {
                enumerable = from each in this.displayedItems
                    orderby each.sortRep descending
                    select each;
            }
            else if (sortType == SortButton.SortType.ASCENDING)
            {
                enumerable = from each in this.displayedItems
                    orderby each.sortRep
                    select each;
            }
            else
            {
                GLog.LogError(new object[] { "Don't know how to sort", sortField, "by", sortType });
            }
        }
        if (enumerable != null)
        {
            int num = 0;
            foreach (CompanySearchInfoGui gui in enumerable)
            {
                gui.name = num.ToString("d3") + "_" + gui.sortName;
                num++;
            }
        }
        else
        {
            GLog.LogError(new object[] { "Failed to sort", sortField, sortType });
        }
        this.companyGrid.repositionNow = true;
        this.ResetScroll();
    }

    public void SearchResult(VentureCompanyRecord[] searchResult)
    {
        this.MakeItems();
        if (CompanyWindowGui.singleton.IsShowing())
        {
            CompanyWindowGui.singleton.RefreshCompany();
        }
    }

    public override void ShowWindow()
    {
        this.MakeItems();
        base.ShowWindow();
    }

    public void SortClicked(GameObject sortGO)
    {
        SortButton button = null;
        for (int i = 0; i < this.allSorts.Count; i++)
        {
            if (sortGO == this.allSorts[i].gameObject)
            {
                this.allSorts[i].ToggleSort(true);
                button = this.allSorts[i];
            }
            else
            {
                this.allSorts[i].ToggleSort(false);
            }
        }
        this.currentSort = button;
        this.ResortContents((Sort) this.currentSort.sortId, this.currentSort.sort);
    }

    public void Start()
    {
        ClientTick.companySearchGuiLoadFinish = new GUtil.BoolFilterDelegate(this.LoadingTickFinished);
        this.currentGoals = VentureCompanyRecord.Goal.NONE;
        this.currentReputations = PvpConst.Reputation.NONE;
        foreach (ToggleIcon icon in base.GetComponentsInChildren<ToggleIcon>())
        {
            if (icon.name == "Rep0Helpful")
            {
                this.repToggles[0] = icon;
                icon.Init(0x10, new ToggleIcon.ToggleIconClicked(this.RepToggleClicked), false, "button_company_radio_on", "button_company_radio_off");
            }
            else if (icon.name == "Rep1Friendly")
            {
                this.repToggles[1] = icon;
                icon.Init(8, new ToggleIcon.ToggleIconClicked(this.RepToggleClicked), false, "button_company_radio_on", "button_company_radio_off");
            }
            else if (icon.name == "Rep2Indifferent")
            {
                this.repToggles[2] = icon;
                icon.Init(4, new ToggleIcon.ToggleIconClicked(this.RepToggleClicked), false, "button_company_radio_on", "button_company_radio_off");
            }
            else if (icon.name == "Rep3Unfriendly")
            {
                this.repToggles[3] = icon;
                icon.Init(2, new ToggleIcon.ToggleIconClicked(this.RepToggleClicked), false, "button_company_radio_on", "button_company_radio_off");
            }
            else if (icon.name == "Rep4Hostile")
            {
                this.repToggles[4] = icon;
                icon.Init(1, new ToggleIcon.ToggleIconClicked(this.RepToggleClicked), false, "button_company_radio_on", "button_company_radio_off");
            }
            else if (icon.name == "Goal0RP")
            {
                this.goalToggles[0] = icon;
                icon.Init(1, new ToggleIcon.ToggleIconClicked(this.GoalToggleClicked), false, "button_company_goal_rp_on", "button_company_goal_rp_off");
            }
            else if (icon.name == "Goal1PoI")
            {
                this.goalToggles[1] = icon;
                icon.Init(2, new ToggleIcon.ToggleIconClicked(this.GoalToggleClicked), false, "button_company_goal_poi_on", "button_company_goal_poi_off");
            }
            else if (icon.name == "Goal2Craft")
            {
                this.goalToggles[2] = icon;
                icon.Init(4, new ToggleIcon.ToggleIconClicked(this.GoalToggleClicked), false, "button_company_goal_craft_on", "button_company_goal_craft_off");
            }
            else if (icon.name == "Goal3Settlement")
            {
                this.goalToggles[3] = icon;
                icon.Init(8, new ToggleIcon.ToggleIconClicked(this.GoalToggleClicked), false, "button_company_goal_settlement_on", "button_company_goal_settlement_off");
            }
            else if (icon.name == "Goal4PvE")
            {
                this.goalToggles[4] = icon;
                icon.Init(0x10, new ToggleIcon.ToggleIconClicked(this.GoalToggleClicked), false, "button_company_goal_pve_on", "button_company_goal_pve_off");
            }
            else if (icon.name == "Goal5PvP")
            {
                this.goalToggles[5] = icon;
                icon.Init(0x20, new ToggleIcon.ToggleIconClicked(this.GoalToggleClicked), false, "button_company_goal_pvp_on", "button_company_goal_pvp_off");
            }
            else if (icon.name == "Goal6Merc")
            {
                this.goalToggles[6] = icon;
                icon.Init(0x40, new ToggleIcon.ToggleIconClicked(this.GoalToggleClicked), false, "button_company_goal_merc_on", "button_company_goal_merc_off");
            }
            else if (icon.name == "OpenEnrollmentCheck")
            {
                this.goalToggles[7] = icon;
                icon.Init(0x80, new ToggleIcon.ToggleIconClicked(this.GoalToggleClicked), false, "button_company_radio_on", "button_company_radio_off");
            }
        }
        GuiHelper.GuiAssertNotNull("NULL REP TOGGLES!", this.repToggles);
        GuiHelper.GuiAssertNotNull("NULL GOAL TOGGLES!", this.goalToggles);
        this.companyGrid = base.GetComponentInChildren<UIGrid>();
        this.searchInput = base.GetComponentInChildren<UIInput>();
        this.scrollBar = base.GetComponentInChildren<UIScrollBar>();
        GuiHelper.GuiAssertNotNull("Couldn't find children.", new object[] { this.companyGrid, this.searchInput, this.scrollBar });
        this.searchInput.onSubmit = (GNGUI.UIInput.OnSubmit) Delegate.Combine(this.searchInput.onSubmit, new GNGUI.UIInput.OnSubmit(this.OnSubmit));
        this.ResetScroll();
        foreach (SortButton button in base.GetComponentsInChildren<SortButton>())
        {
            this.allSorts.Add(button);
            UIEventListener listener1 = UIEventListener.Get(button.gameObject);
            listener1.onClick = (UIEventListener.VoidDelegate) Delegate.Combine(listener1.onClick, new UIEventListener.VoidDelegate(this.SortClicked));
            if (button.name == "Sort0Name")
            {
                button.Init(0, SortButton.SortType.ASCENDING);
            }
            else if (button.name == "Sort1Size")
            {
                button.Init(1, SortButton.SortType.INACTIVE);
            }
            else if (button.name == "Sort2Alignment")
            {
                button.Init(2, SortButton.SortType.INACTIVE);
                NGUITools.SetActive(button.gameObject, false);
            }
            else if (button.name == "Sort2Holdings")
            {
                button.Init(4, SortButton.SortType.INACTIVE);
            }
            else if (button.name == "Sort3Rep")
            {
                button.Init(3, SortButton.SortType.INACTIVE);
            }
            else
            {
                GLog.LogError(new object[] { "Unknown sort!", button.name });
            }
            if ((button.sort != SortButton.SortType.INACTIVE) && (this.currentSort == null))
            {
                this.currentSort = button;
            }
            else if ((button.sort != SortButton.SortType.INACTIVE) && (this.currentSort != null))
            {
                GLog.LogError(new object[] { "Should only have one non-inactive sort! You have", this.currentSort.name, "and", button.name });
            }
        }
        base.Init(2, true);
        foreach (ToggleIcon icon2 in this.repToggles)
        {
            NGUITools.SetActive(icon2.gameObject, false);
        }
        foreach (ToggleIcon icon3 in this.goalToggles)
        {
            NGUITools.SetActive(icon3.gameObject, false);
        }
        NGUITools.SetActive(base.transform.FindChild("HPO/Goals").gameObject, false);
        NGUITools.SetActive(base.transform.FindChild("HPO/Reputation").gameObject, false);
        NGUITools.SetActive(base.transform.FindChild("HPO/OpenEnrollmentText").gameObject, false);
    }

    public void ToggleWindowVis(string[] args, EntityId playerEntityId)
    {
        this.ToggleWindowVisibility();
    }

    private enum Sort
    {
        NAME,
        SIZE,
        ALIGNMENT,
        REPUTATION,
        HOLDINGS
    }
}

