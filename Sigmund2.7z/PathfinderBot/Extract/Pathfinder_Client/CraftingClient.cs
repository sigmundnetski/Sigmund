﻿using GNetwork;
using System;
using System.Collections.Generic;
using UnityEngine;

public static class CraftingClient
{
    public static CraftingRequest activeRequest = new CraftingRequest();
    private static InventoryItem[] allocatedItems = new InventoryItem[8];
    public static Queue<InventoryItem>[] allocationsPerStock = new Queue<InventoryItem>[] { new Queue<InventoryItem>(), new Queue<InventoryItem>(), new Queue<InventoryItem>(), new Queue<InventoryItem>() };
    private static InventoryItem[] availableItems = new InventoryItem[8];
    public static ushort facilityRating;
    public static bool itemsLoaded = false;
    public static Vector3 location;
    public static uint[] quantities = new uint[4];
    public static int selectedInputIndex = -1;
    public static bool stocksLoaded = false;
    private static InventoryItem[] tempItems = new InventoryItem[8];

    public static void Cancel(int queueIndex, CraftingQueue data)
    {
        GRouting.SendMyMapRpc(GRpcID.CraftingServer_Cancel, new object[] { queueIndex, data.rId, data.upg });
    }

    public static void Earmark(InventoryItem itemStack, uint qty)
    {
        if (selectedInputIndex != -1)
        {
            int num;
            itemStack = InventoryItem.ChangeQuantity(itemStack, 1);
            GetAvailableItems();
            for (num = 0; num < allocationsPerStock[selectedInputIndex].Count; num++)
            {
                if (itemStack.Stackable(allocationsPerStock[selectedInputIndex].Peek()))
                {
                    allocationsPerStock[selectedInputIndex].Enqueue(allocationsPerStock[selectedInputIndex].Dequeue());
                }
            }
            for (num = 0; num < qty; num++)
            {
                allocationsPerStock[selectedInputIndex].Enqueue(itemStack);
            }
            while (allocationsPerStock[selectedInputIndex].Count > quantities[selectedInputIndex])
            {
                allocationsPerStock[selectedInputIndex].Dequeue();
            }
            if (!object.ReferenceEquals(CraftingWindow.singleton, null))
            {
                CraftingWindow.singleton.OnAllocationChange();
            }
        }
    }

    public static InventoryItem[] GetAllAllocatedItems()
    {
        SparseArray.Clear<InventoryItem>(ref allocatedItems, InventoryItem.EMPTY);
        foreach (Queue<InventoryItem> queue in allocationsPerStock)
        {
            foreach (InventoryItem item in queue)
            {
                InventoryItemUtils.AddWithAutoStack(ref allocatedItems, item);
            }
        }
        return allocatedItems;
    }

    public static InventoryItem[] GetAllocatedItems(int inputIndex)
    {
        SparseArray.Clear<InventoryItem>(ref allocatedItems, InventoryItem.EMPTY);
        if (inputIndex != -1)
        {
            foreach (InventoryItem item in allocationsPerStock[inputIndex])
            {
                InventoryItemUtils.AddWithAutoStack(ref allocatedItems, item);
            }
        }
        return allocatedItems;
    }

    public static InventoryItem[] GetAvailableItems()
    {
        int[] itemIdFilter = new int[1];
        SparseArray.Clear<InventoryItem>(ref availableItems, InventoryItem.EMPTY);
        BaseRecipeData recipe = activeRequest.GetRecipe();
        if ((selectedInputIndex != -1) && (recipe != null))
        {
            if (recipe.inputStockIds.Length > selectedInputIndex)
            {
                CraftingItemData.itemIdsByStockId.TryGetValue(recipe.inputStockIds[selectedInputIndex], out itemIdFilter);
            }
            else if (recipe.inputItemIds.Length > selectedInputIndex)
            {
                itemIdFilter[0] = recipe.inputItemIds[selectedInputIndex];
            }
        }
        SparseArray.DeepCopyTo<InventoryItem>(EntityDataClient.owner.playerRecord.inventory, ref availableItems, 0xff, eachItem => Array.IndexOf<int>(itemIdFilter, eachItem.staticItemId) == -1);
        allocatedItems = GetAllAllocatedItems();
        foreach (InventoryItem item in SparseArray.Iterate<InventoryItem>(allocatedItems, InventoryItem.EMPTY_MATCH))
        {
            InventoryItemUtils.ExtractItem(availableItems, item);
        }
        return availableItems;
    }

    public static void OnClientEntityUpdate(Entity entity)
    {
        if ((object.ReferenceEquals(EntityDataClient.owner, entity) && (CraftingWindow.singleton != null)) && CraftingWindow.singleton.IsShowing())
        {
            CraftingWindow.singleton.OnOwnerInvUpdate();
        }
    }

    public static void OnCloseCrafting()
    {
        GRouting.SendMyMapRpc(GRpcID.CraftingServer_OnCloseCrafting, new object[0]);
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void OpenRecipeWindow(IBitBufferRead buffer)
    {
        if (CraftingWindow.singleton != null)
        {
            activeRequest.SetRecipe(0);
            RecipeNameElement.selectedRecipe = null;
            facilityRating = buffer.PopUShort();
            int[] output = null;
            buffer.PopIntArrayDelta(ref output);
            location = EntityDataClient.owner.GetLocalPosition();
            CraftingWindow.singleton.OpenRecipeWindow(output);
            CraftingWindow.singleton.ShowWindow();
            CraftingWindow.singleton.OnOwnerInvUpdate();
        }
    }

    private static void PackQueueRequest(IBitBufferWrite buffer, object unused)
    {
        DataUtilities.SerializeObjectToNetworkBuffer(buffer, 0, activeRequest, null);
    }

    public static void QueueRequest()
    {
        UpdateActiveRequest();
        if (activeRequest.Validate(EntityDataClient.owner) == CraftingRequest.Why.VALID)
        {
            object[] rpcParams = new object[2];
            rpcParams[0] = new UnmanagedRpcSender(CraftingClient.PackQueueRequest);
            GRouting.SendMyMapRpc(GRpcID.CraftingServer_QueueRequest, rpcParams);
        }
    }

    public static bool RecipeReady()
    {
        UpdateActiveRequest();
        return (activeRequest.Validate(EntityDataClient.owner) == CraftingRequest.Why.VALID);
    }

    public static void ResetAllocations(uint[] setQty)
    {
        SparseArray.Clear<uint>(ref quantities, 0);
        Array.Copy(setQty, quantities, setQty.Length);
        for (int i = 0; i < allocationsPerStock.Length; i++)
        {
            allocationsPerStock[i].Clear();
        }
    }

    public static bool SyncFixedUpdate()
    {
        if (((CraftingWindow.singleton != null) && CraftingWindow.singleton.IsShowing()) && (Vector3.SqrMagnitude(location - EntityDataClient.owner.GetLocalPosition()) > 1f))
        {
            CraftingWindow.singleton.HideWindow();
        }
        return true;
    }

    private static void SyncStart()
    {
        StaticDataService.RegisterCallback<ItemDatabase>(new StaticDataService.StaticDataServiceCallback(CraftingClient.UpdateItems));
        StaticDataService.RegisterCallback<StockData>(new StaticDataService.StaticDataServiceCallback(CraftingClient.UpdateStocks));
    }

    private static void UpdateActiveRequest()
    {
        int num = SparseArray.Count<uint>(quantities, x => x == 0);
        for (int i = 0; i < num; i++)
        {
            activeRequest.UpdateInputs(i, allocationsPerStock[i].ToArray());
        }
    }

    private static void UpdateItems(List<DataClass> objects)
    {
        itemsLoaded = true;
        if (itemsLoaded && stocksLoaded)
        {
            CraftingItemData.IndexStocks();
        }
    }

    private static void UpdateStocks(List<DataClass> objects)
    {
        stocksLoaded = true;
        if (itemsLoaded && stocksLoaded)
        {
            CraftingItemData.IndexStocks();
        }
    }

    public static bool ValidRecipe(BaseRecipeData recipe, int[] skillIds, string[] searchArgs)
    {
        CraftingRequest.Why why = CraftingRequest.Validate(recipe, EntityDataClient.owner, null);
        bool flag = SparseArray.Contains<int>(skillIds, recipe.skillId);
        bool flag2 = true;
        string str = recipe.displayName.ToLower();
        for (int i = 0; i < searchArgs.Length; i++)
        {
            if (!str.Contains(searchArgs[i]))
            {
                flag2 = false;
                break;
            }
        }
        return (((why == CraftingRequest.Why.VALID) && flag) && flag2);
    }
}

