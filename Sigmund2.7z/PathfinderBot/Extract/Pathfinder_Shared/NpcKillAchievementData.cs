﻿using System;
using System.Collections.Generic;
using System.Linq;

[LooseDependency(typeof(RaceData)), StrongDependency(typeof(AchievementCounterData)), NoFinalOutput, StrongDependency(typeof(CategoryData))]
public class NpcKillAchievementData : GenericAchievementData
{
    private static readonly string[] _mandatoryColumns = new string[] { "counter name", "counter value", "race" };
    public int raceId;

    protected override void ParseCustomDetails(int rowIndex, ref AdvancementIndexedDataClass _output)
    {
        base.ParseCustomDetails(rowIndex, ref _output);
        NpcKillAchievementData data = (NpcKillAchievementData) _output;
        bool flag = data.TryParseAsSingleCounter(DataClass.columnNamesToIndex["counter name"], rowIndex);
        bool flag2 = data.TryParseAsSingleCounterValue(DataClass.columnNamesToIndex["counter value"], rowIndex);
        if (data.linkedCounterIds.Length == 0)
        {
            DataClass.OutputErrorMessage(DataClass.columnNamesToIndex["counter name"], rowIndex, "Invalid Counter.");
        }
        if (!flag2)
        {
            DataClass.OutputErrorMessage(DataClass.columnNamesToIndex["counter value"], rowIndex, "Counter value out of bounds (1-8000).");
        }
        DataClass.GetIdFromForeignName<RaceData>(DataClass.columnNamesToIndex["race"], rowIndex, out data.raceId);
    }

    protected override IEnumerable<string> GetMandatoryColumns
    {
        get
        {
            return base.GetMandatoryColumns.Concat<string>(_mandatoryColumns);
        }
    }
}

