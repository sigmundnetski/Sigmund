﻿using System;
using System.Collections.Generic;
using System.Linq;

public class AchievementCounterData : AdvancementIndexedDataClass
{
    public static Dictionary<int, AchievementCounterData> countersById = new Dictionary<int, AchievementCounterData>();
    public static Dictionary<int, AchievementCounterData[]> countersByPageId = new Dictionary<int, AchievementCounterData[]>();
    public static Dictionary<string, AchievementCounterData> countersBySlotName = new Dictionary<string, AchievementCounterData>();
    public const ushort MAX_COUNTER_VALUE = 0x1f40;

    public static void OnLoad(List<DataClass> objects)
    {
        AdvancementIndexedDataClass.AssignPageNumbers(objects);
        foreach (AchievementCounterData data in objects)
        {
            countersById[data.id] = data;
            countersBySlotName[data.slotName] = data;
        }
        HashSet<int> set = new HashSet<int>();
        foreach (AchievementCounterData data in objects)
        {
            set.Add(data.pageId);
        }
        using (HashSet<int>.Enumerator enumerator2 = set.GetEnumerator())
        {
            while (enumerator2.MoveNext())
            {
                int eachPageId = enumerator2.Current;
                countersByPageId[eachPageId] = (from each in objects
                    where ((AchievementCounterData) each).pageId == eachPageId
                    select (AchievementCounterData) each).ToArray<AchievementCounterData>();
            }
        }
    }
}

