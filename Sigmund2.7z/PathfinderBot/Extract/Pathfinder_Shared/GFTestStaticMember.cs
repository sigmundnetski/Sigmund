﻿using System;

internal class GFTestStaticMember
{
    public static string staticStr = "Testing Static String";
}

