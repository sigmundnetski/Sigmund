﻿using System;
using System.Collections.Generic;

public class SettlementSync
{
    public uint playerSettlementId = 0;
    public HashSet<uint> playerSettlements = new HashSet<uint>();

    public SettlementSync(uint playerSettlementId_)
    {
        this.playerSettlementId = playerSettlementId_;
    }
}

