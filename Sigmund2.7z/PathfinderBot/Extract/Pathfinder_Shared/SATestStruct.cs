﻿using System;
using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Sequential)]
internal struct SATestStruct : IDataCopyable<SATestStruct>
{
    public const int INVALID = 0;
    public readonly int value;
    public SATestStruct(int value_)
    {
        this.value = value_;
    }

    public bool DataEquals(SATestStruct target, byte syncTargetLevel)
    {
        return (this.value == target.value);
    }

    public void DataCopyTo(ref SATestStruct target, byte syncTargetLevel)
    {
        target = this;
    }
}

