﻿using System;
using UnityEngine;

public class TextureCleanup : MonoBehaviour
{
    public Bounds extents;
    public uint index;
    public Transform xform;

    private void OnDestroy()
    {
        ResourceManager.ReleaseMaterials(this);
    }

    public override string ToString()
    {
        return string.Concat(new object[] { base.name, "_", this.index, "_", base.GetInstanceID() });
    }
}

