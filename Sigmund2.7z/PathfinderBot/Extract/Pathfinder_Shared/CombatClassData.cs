﻿using System;
using System.Collections.Generic;
using System.Linq;

[StrongDependency(typeof(AiClassData)), StrongDependency(typeof(PlayerClassData)), NoExcelData]
public class CombatClassData : DataClass
{
    public int aiLevel;
    public int armorId;
    public byte armorUpgrade;
    public CombatAttackBonus attackBonus;
    public int[] attackFeatIds;
    public byte[] attackFeatLevels;
    public byte attackTier;
    public int baseDamage;
    public static Dictionary<int, CombatClassData> classesById = new Dictionary<int, CombatClassData>();
    public static Dictionary<string, CombatClassData> classesByName = new Dictionary<string, CombatClassData>();
    public string combatAnimSetName;
    public CombatDefense defense;
    public int drawAnimNumber;
    public int effectDefense;
    public int effectPower;
    public int[] expendableFeatIds;
    public byte[] expendableFeatLevels;
    public int hitPoints;
    public string idleAnimSetName;
    public int[] implementIds;
    public byte[] implementUpgrades;
    private static AiClassData INVALID_CLASS = new AiClassData(1);
    public string mainhandModelName;
    public const int MAX_ATTACKS_PER_SET = 6;
    public const int MAX_EXPENDABLES_PER_SET = 6;
    public const int MAX_IMPLEMENT_SETS = 2;
    public const int MAX_REFRESH_FEATS = 2;
    public const int MAX_UTILITY_FEATS = 2;
    public const int MAX_WEAPON_SETS = 2;
    public float moveSpeed;
    public const int NUM_WEAPONS_PER_SET = 2;
    public string offhandModelName;
    public int[] otherPreknownFeatAdvIds;
    public byte[] otherPreknownFeatAdvLevels;
    public int[] passiveFeatIds;
    public int recovery;
    public int[] refreshFeatIds;
    public CombatResistance resistance;
    public Skills skills;
    public int[] upgradeFeatIds;
    public int[] utilityFeatIds;
    public byte[] utilityFeatLevels;
    public int[] weaponIds;
    public byte[] weaponUpgrades;

    public CombatClassData()
    {
        this.Init();
    }

    public CombatClassData(string name) : base(name)
    {
        this.Init();
    }

    public static int ClassIdFromName(string name)
    {
        CombatClassData data;
        if (classesByName.TryGetValue(name.ToLower(), out data))
        {
            return data.id;
        }
        GLog.LogError(new object[] { string.Concat(new object[] { "Invalid combat class: ", name, "\nNum options:", classesByName.Count }) });
        return 0;
    }

    public int[] GetAttackFeatIds()
    {
        int[] dst = null;
        DataSerializerUtils.DataCopyField<int>(this.attackFeatIds, ref dst);
        return dst;
    }

    public byte[] GetAttackFeatLevels()
    {
        byte[] dst = null;
        DataSerializerUtils.DataCopyField<byte>(this.attackFeatLevels, ref dst);
        return dst;
    }

    public static CombatClassData GetClassById(int id)
    {
        if (id != 0)
        {
            return classesById[id];
        }
        GLog.LogError(new object[] { "Assigning INVALID Combat Class to entity." });
        return INVALID_CLASS;
    }

    public static CombatClassData GetClassByName(string name)
    {
        return classesByName[name.ToLower()];
    }

    public int[] GetExpendableFeatIds()
    {
        int[] dst = null;
        DataSerializerUtils.DataCopyField<int>(this.expendableFeatIds, ref dst);
        return dst;
    }

    public byte[] GetExpendableFeatLevels()
    {
        byte[] dst = null;
        DataSerializerUtils.DataCopyField<byte>(this.expendableFeatLevels, ref dst);
        return dst;
    }

    public int[] GetImplementIds()
    {
        int[] dst = null;
        DataSerializerUtils.DataCopyField<int>(this.implementIds, ref dst);
        return dst;
    }

    public byte[] GetImplementUpgrades()
    {
        byte[] dst = null;
        DataSerializerUtils.DataCopyField<byte>(this.implementUpgrades, ref dst);
        return dst;
    }

    public int[] GetOtherPreknownFeatAdvIds()
    {
        int[] dst = null;
        DataSerializerUtils.DataCopyField<int>(this.otherPreknownFeatAdvIds, ref dst);
        return dst;
    }

    public byte[] GetOtherPreknownFeatAdvLevels()
    {
        byte[] dst = null;
        DataSerializerUtils.DataCopyField<byte>(this.otherPreknownFeatAdvLevels, ref dst);
        return dst;
    }

    public int[] GetPassiveFeatIds()
    {
        int[] dst = null;
        DataSerializerUtils.DataCopyField<int>(this.passiveFeatIds, ref dst);
        return dst;
    }

    public int[] GetRefreshFeatIds()
    {
        int[] dst = null;
        DataSerializerUtils.DataCopyField<int>(this.refreshFeatIds, ref dst);
        return dst;
    }

    public int[] GetUpgradeFeatIds()
    {
        int[] dst = null;
        DataSerializerUtils.DataCopyField<int>(this.upgradeFeatIds, ref dst);
        return dst;
    }

    public int[] GetUtilityFeatIds()
    {
        int[] dst = null;
        DataSerializerUtils.DataCopyField<int>(this.utilityFeatIds, ref dst);
        return dst;
    }

    public byte[] GetUtilityFeatLevels()
    {
        byte[] dst = null;
        DataSerializerUtils.DataCopyField<byte>(this.utilityFeatLevels, ref dst);
        return dst;
    }

    public int[] GetWeaponIds()
    {
        int[] dst = null;
        DataSerializerUtils.DataCopyField<int>(this.weaponIds, ref dst);
        return dst;
    }

    public byte[] GetWeaponUpgrades()
    {
        byte[] dst = null;
        DataSerializerUtils.DataCopyField<byte>(this.weaponUpgrades, ref dst);
        return dst;
    }

    private void Init()
    {
        this.hitPoints = 0;
        this.recovery = 0;
        this.defense = new CombatDefense();
        this.resistance = new CombatResistance();
        this.attackBonus = new CombatAttackBonus();
        this.skills = new Skills();
        this.armorId = 0;
        this.armorUpgrade = 0;
        this.weaponIds = new int[4];
        this.weaponUpgrades = new byte[4];
        this.implementIds = new int[2];
        this.implementUpgrades = new byte[2];
        this.attackFeatIds = new int[12];
        this.attackFeatLevels = new byte[12];
        this.expendableFeatIds = new int[12];
        this.expendableFeatLevels = new byte[12];
        this.utilityFeatIds = new int[2];
        this.utilityFeatLevels = new byte[2];
        this.passiveFeatIds = new int[0];
        this.refreshFeatIds = new int[2];
        this.upgradeFeatIds = new int[0];
        this.otherPreknownFeatAdvIds = new int[0];
        this.otherPreknownFeatAdvLevels = new byte[0];
        this.attackTier = 0;
        this.baseDamage = 0;
        this.moveSpeed = 0f;
        this.aiLevel = 0;
        this.effectPower = 0;
        this.effectDefense = 0;
    }

    public override List<DataClass> MergeData()
    {
        List<DataClass> list = new List<DataClass>();
        foreach (CombatClassData data in DataClass.GetData(typeof(PlayerClassData)))
        {
            list.Add(data);
        }
        foreach (CombatClassData data2 in DataClass.GetData(typeof(AiClassData)))
        {
            list.Add(data2);
        }
        return list;
    }

    public static void OnLoad(List<DataClass> objects)
    {
        classesByName.Clear();
        classesById.Clear();
        foreach (CombatClassData data in objects)
        {
            classesByName[data.name] = data;
            classesById[data.id] = data;
        }
    }

    public static void ParseArmor(string source, ref int armorId, ref byte armorUpgrade)
    {
        List<GSStatement> list = GoblinSpec.Parse(source);
        if (list.Count > 1)
        {
            throw new ParseException("Can only have 1 armor. Found " + list.Count);
        }
        GSStatement statement = list[0];
        armorId = CombatArmor.ArmorIdFromName(statement.statement);
        armorUpgrade = CombatModifier.ParseByteParameter(statement);
        CombatArmor armorById = CombatArmor.GetArmorById(armorId);
        if (armorUpgrade > 5)
        {
            throw new ParseException("Combat equipment upgrade level cannot be higher than 5: " + statement.statement);
        }
        if (statement.parameters.Count > 0)
        {
            throw new ParseException("Unknown parameter for equipment: " + statement.statement);
        }
        if (statement.qualifiers.Count > 0)
        {
            throw new ParseException("Unknown qualifier for equipment: " + statement.statement);
        }
    }

    public static void ParseAttackFeats(string[] source, int offset, ref int[] attackFeatIds, ref byte[] attackFeatLevels)
    {
        for (int i = 0; i < source.Length; i++)
        {
            if (string.IsNullOrEmpty(source[i]))
            {
                attackFeatIds[i + offset] = 0;
                attackFeatLevels[i + offset] = 0;
            }
            else
            {
                List<GSStatement> list = GoblinSpec.Parse(source[i]);
                if (list.Count > 1)
                {
                    throw new ParseException("There is more than one attack defined in a cell.");
                }
                GSStatement statement = list[0];
                if ((i + offset) >= attackFeatIds.Length)
                {
                    throw new ParseException("There are more attacks defined than can be saved.");
                }
                attackFeatIds[i + offset] = OffensiveFeatData.AttackIdFromName(statement.statement);
                attackFeatLevels[i + offset] = CombatModifier.ParseByteParameter(statement);
                if (attackFeatLevels[i + offset] == 0)
                {
                    throw new ParseException("Attack feat requires a level: " + statement.statement);
                }
                if (statement.parameters.Count > 0)
                {
                    throw new ParseException("Unknown parameter for attack: " + statement.statement);
                }
                if (statement.qualifiers.Count > 0)
                {
                    throw new ParseException("Unknown qualifier for attack: " + statement.statement);
                }
            }
        }
    }

    protected void ParseAttackSetWithError(int setIndex, string[] attacks)
    {
        try
        {
            if ((attacks != null) && (attacks.Length > 0))
            {
                ParseAttackFeats(attacks, setIndex * 6, ref this.attackFeatIds, ref this.attackFeatLevels);
            }
        }
        catch (ParseException exception)
        {
            string str = "\n";
            object obj2 = str + "  " + base.name + ": GoblinSpec parsing error!\n";
            DataClass.OutputErrorMessage(string.Concat(new object[] { obj2, "     Attack Feat Set ", setIndex + 1, ": ", attacks, "\n" }) + "    >>ERROR: " + exception.Message + "\n");
        }
    }

    public static void ParseWeapons(string source, int offset, ref int[] weaponIds, ref byte[] weaponUpgrades)
    {
        List<GSStatement> list = GoblinSpec.Parse(source);
        for (int i = 0; i < list.Count; i++)
        {
            if ((i + offset) >= weaponIds.Length)
            {
                throw new ParseException("There are more weapons defined than can be saved.");
            }
            weaponIds[i + offset] = CombatWeapon.WeaponIdFromName(list[i].statement);
            weaponUpgrades[i + offset] = CombatModifier.ParseByteParameter(list[i]);
            if (CombatWeapon.GetWeaponById(weaponIds[i + offset]) == null)
            {
                throw new ParseException("CombatWeapon not parsed");
            }
            if (weaponUpgrades[i + offset] > 5)
            {
                throw new ParseException("Weapon upgrade level cannot be higher than 5: " + list[i].statement);
            }
            if (list[i].parameters.Count > 0)
            {
                throw new ParseException("Unknown parameter for attack: " + list[i].statement);
            }
            if (list[i].qualifiers.Count > 0)
            {
                throw new ParseException("Unknown qualifier for attack: " + list[i].statement);
            }
        }
    }

    protected static string ToCSV(params string[] items)
    {
        items = (from str in items
            select str.Trim() into str
            where !string.IsNullOrEmpty(str)
            select str).ToArray<string>();
        return string.Join(",", items);
    }
}

