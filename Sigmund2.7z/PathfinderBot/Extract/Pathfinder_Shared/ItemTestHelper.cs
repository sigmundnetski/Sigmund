﻿using System;
using System.Collections.Generic;
using System.Linq;

public class ItemTestHelper
{
    public static List<DataClass> gearItems = new List<DataClass>();
    private static bool initialized = false;
    public static List<DataClass> wondrousItems = new List<DataClass>();

    public static void AddGear(GearItemData gear)
    {
        gearItems.Add(gear);
    }

    public static void AddWondrous(WondrousItemData wondrous)
    {
        wondrousItems.Add(wondrous);
    }

    private static void AssertInit()
    {
        if (!initialized)
        {
            throw new Exception("CombatTestHelper not set up! Make sure to call SetUp().");
        }
    }

    public static void ClearAllItemStaticData()
    {
        AssertInit();
        SetUp();
        gearItems.Clear();
        wondrousItems.Clear();
        LoadItems();
    }

    public static IEnumerable<DataClass> GetDataOverride(System.Type type)
    {
        if (type == typeof(GearItemData))
        {
            return gearItems;
        }
        if (type == typeof(WondrousItemData))
        {
            return wondrousItems;
        }
        if (type == typeof(CombatArmor))
        {
            return (from each in CombatArmor.armorsById.Values select each);
        }
        if (type == typeof(CombatWeapon))
        {
            return (from each in CombatWeapon.weaponsById.Values select each);
        }
        if (((((type == typeof(CraftingItemData)) || (type == typeof(CraftRecipeItemData))) || ((type == typeof(ExpendableRecipeItemData)) || (type == typeof(SpoilsItemData)))) || (type == typeof(CurrencyItemData))) || (type == typeof(TreasureBoxItemData)))
        {
            return Enumerable.Empty<DataClass>();
        }
        return null;
    }

    public static void LoadItems()
    {
        AssertInit();
        ItemDatabase.OnLoad(new ItemDatabase().MergeData());
    }

    public static void SetUp()
    {
        initialized = true;
        DataClass.GetData = new GetDataCallback(ItemTestHelper.GetDataOverride);
    }
}

