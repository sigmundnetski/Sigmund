﻿using System;
using System.Collections.Generic;
using System.Linq;

[LooseDependency(typeof(ItemDatabase))]
public class SpoilsConversionData : DataClass
{
    public uint coins;
    public int rewardItemId;
    public static Dictionary<int, SpoilsConversionData[]> rewardsBySpoilId = new Dictionary<int, SpoilsConversionData[]>();
    public int spoilItemId;
    public uint spoilsCost;
    public float weight;

    public static SpoilsConversionData MakeUnittestItem(BasicItemData spoilItem, BasicItemData rewardItem)
    {
        SpoilsConversionData data;
        return new SpoilsConversionData { spoilItemId = spoilItem.id, rewardItemId = rewardItem.id, weight = 1f, spoilsCost = 1, coins = 1, name = "SpoilConvert" + data.spoilItemId + data.rewardItemId };
    }

    public static void OnLoad(List<DataClass> allSpoils)
    {
        HashSet<int> set = new HashSet<int>(from each in allSpoils select ((SpoilsConversionData) each).spoilItemId);
        using (HashSet<int>.Enumerator enumerator = set.GetEnumerator())
        {
            while (enumerator.MoveNext())
            {
                int eachSpoilId = enumerator.Current;
                rewardsBySpoilId[eachSpoilId] = (from each in allSpoils
                    where ((SpoilsConversionData) each).spoilItemId == eachSpoilId
                    select (SpoilsConversionData) each).ToArray<SpoilsConversionData>();
            }
        }
    }

    public override DataClass ParseRecord(int rowIndex)
    {
        return ParseRow(rowIndex);
    }

    public static SpoilsConversionData ParseRow(int rowIndex)
    {
        string str;
        BasicItemData data;
        BasicItemData data2;
        if (!DataClass.TryGetLCaseCellValue(1, rowIndex, out str))
        {
            return null;
        }
        if (!ItemDatabase.itemByName.TryGetValue(str, out data2))
        {
            DataClass.OutputErrorMessage(1, rowIndex, "Reward item name does not match an existing item. (" + str + ")");
            return null;
        }
        DataClass.GetLCaseCellValue(2, 1, out str);
        if (!ItemDatabase.itemByName.TryGetValue(str, out data))
        {
            DataClass.OutputErrorMessage(2, 1, "Spoil-type does not exist. (" + str + ")");
            return null;
        }
        SpoilsConversionData data3 = new SpoilsConversionData {
            spoilItemId = data.id,
            rewardItemId = data2.id
        };
        DataClass.GetCellValue(2, rowIndex, out data3.weight);
        DataClass.GetCellValue(3, rowIndex, out data3.spoilsCost);
        DataClass.GetCellValue(4, rowIndex, out data3.coins);
        data3.name = "SpoilConvert" + data3.spoilItemId + data3.rewardItemId;
        return data3;
    }
}

