﻿using System;

internal class PvpConstTest : UUnitTestCase
{
    [UUnitTestMethod]
    private void TestReputationPenalty()
    {
        float targetGameHours = 1000f;
        float targetRep = -7500f;
        float got = PvpConst.ComputeKillReputation(0f, 0, targetRep, targetGameHours);
        UUnitAssert.Equals(0f, got, 0.0001f, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        for (targetRep += 100f; targetRep <= 7500f; targetRep += 100f)
        {
            float num4 = PvpConst.ComputeKillReputation(0f, 0, targetRep, targetGameHours);
            UUnitAssert.True(num4 < got, string.Concat(new object[] { "Rep loss must increase for higher target rep (", targetRep, ":", got, "->", num4, ")" }));
            got = num4;
        }
    }

    [UUnitTestMethod]
    private void TestReputationRegen()
    {
        float gameHours = 1f;
        float num2 = 0f;
        float curRep = 0f;
        Random random = new Random();
        while (gameHours < CombatData.singleton.newPlayerHours)
        {
            float hoursPassed = ((float) random.NextDouble()) / 60f;
            if (hoursPassed >= 0.01)
            {
                gameHours += hoursPassed;
                curRep = PvpConst.ComputeReputationRegen(curRep, gameHours, gameHours, hoursPassed);
                UUnitAssert.True(curRep > num2, string.Concat(new object[] { "Rep did not increase:", curRep, " !> ", num2 }));
                num2 = curRep;
            }
        }
        float num5 = 1000f;
        UUnitAssert.Equals(0f, PvpConst.ComputeReputationRegen(0f, num5, 0.99f, 0.99f), 0.0001f, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(0f, PvpConst.ComputeReputationRegen(0f, num5, 1f, 1f), 0.0001f, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.True(0f < PvpConst.ComputeReputationRegen(0f, num5, 1.01f, 1.01f), "Fail");
        UUnitAssert.Equals(350f, PvpConst.ComputeReputationRegen(0f, num5, 1000f, 1f), 0.0001f, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        for (int i = 1; i <= 60; i++)
        {
            float num7 = ((float) i) / 60f;
            float regenHours = 1f + num7;
            UUnitAssert.Equals((double) (200f * num7), (double) PvpConst.ComputeReputationRegen(0f, num5, regenHours, num7), 0.01, "Regen not expected: {0] != {1}");
        }
    }
}

