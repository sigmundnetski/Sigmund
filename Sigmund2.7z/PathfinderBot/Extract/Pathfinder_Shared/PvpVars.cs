﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;

public class PvpVars : IDataCopyable<PvpVars>
{
    public const float AFK_TIMEOUT_HOURS = 0.03333334f;
    private uint[] aggresseePlayers = new uint[0];
    private byte[] aggresseeStacks = new byte[0];
    public float gameHours;
    [DataRestrict]
    public float killerTraitExpiration;
    public byte killerTraitStacks;
    [DataRestrict]
    private DateTime lastActiveTimestamp = DateTime.MaxValue;
    [DataRestrict]
    private DateTime lastAggressionTimestamp = DateTime.MaxValue;
    [DataRestrict]
    public float lastOffenseTimestamp;
    [DataRestrict]
    public float lastReputationTick;
    [DataRestrict, JsonIgnore]
    private float pastGameHours;
    public PvpFlags pvpFlags = new PvpFlags();
    public float reputation = 4000f;

    private int AggresseeAdd()
    {
        int num;
        for (num = 0; num < this.aggresseePlayers.Length; num++)
        {
            if (this.aggresseePlayers[num] == 0)
            {
                return num;
            }
        }
        int length = this.aggresseePlayers.Length;
        int newSize = 2 * (this.aggresseePlayers.Length + 1);
        Array.Resize<uint>(ref this.aggresseePlayers, newSize);
        Array.Resize<byte>(ref this.aggresseeStacks, newSize);
        for (num = length; num < newSize; num++)
        {
            this.aggresseePlayers[num] = 0;
        }
        return length;
    }

    private void AggresseeRemove(int index)
    {
        this.aggresseePlayers[index] = 0;
    }

    private int AggresseeSearch(uint id)
    {
        for (int i = 0; i < this.aggresseePlayers.Length; i++)
        {
            if (this.aggresseePlayers[i] == id)
            {
                return i;
            }
        }
        return -1;
    }

    public void ClearAggressees()
    {
        if (this.aggresseePlayers.Length >= 8)
        {
            this.aggresseePlayers = new uint[4];
            this.aggresseeStacks = new byte[4];
        }
        else
        {
            SparseArray.Clear<uint>(ref this.aggresseePlayers, 0);
            SparseArray.Clear<byte>(ref this.aggresseeStacks, 0);
        }
    }

    public void DataCopyTo(ref PvpVars target, byte syncTargetLevel)
    {
        DataSerializerUtils.DataCopyField<uint>(this.aggresseePlayers, ref target.aggresseePlayers);
        DataSerializerUtils.DataCopyField<byte>(this.aggresseeStacks, ref target.aggresseeStacks);
        DataSerializerUtils.DataCopyField<PvpFlags>(this.pvpFlags, ref target.pvpFlags, syncTargetLevel);
        target.reputation = this.reputation;
        target.gameHours = this.gameHours;
        target.killerTraitStacks = this.killerTraitStacks;
        target.killerTraitExpiration = this.killerTraitExpiration;
        target.lastOffenseTimestamp = this.lastOffenseTimestamp;
    }

    public bool DataEquals(PvpVars target, byte syncTargetLevel)
    {
        if (object.ReferenceEquals(this, target))
        {
            return true;
        }
        if (object.ReferenceEquals(target, null))
        {
            return false;
        }
        bool flag = true;
        return ((((((((flag && SparseArray.DeepEqualsWithIndex<uint>(this.aggresseePlayers, target.aggresseePlayers)) && SparseArray.DeepEqualsWithIndex<byte>(this.aggresseeStacks, target.aggresseeStacks)) && DataSerializerUtils.DataEquals<PvpFlags>(this.pvpFlags, target.pvpFlags, syncTargetLevel)) && (target.reputation == this.reputation)) && (target.gameHours == this.gameHours)) && (target.killerTraitStacks == this.killerTraitStacks)) && (target.killerTraitExpiration == this.killerTraitExpiration)) && (target.lastOffenseTimestamp == this.lastOffenseTimestamp));
    }

    public List<uint> GetAggressees()
    {
        List<uint> list = new List<uint>();
        for (int i = 0; i < this.aggresseePlayers.Length; i++)
        {
            if (this.aggresseePlayers[i] != 0)
            {
                list.Add(this.aggresseePlayers[i]);
            }
        }
        return list;
    }

    public void InitGameHours()
    {
        this.pastGameHours = this.gameHours;
    }

    public bool IsAggressee(uint id)
    {
        return (this.AggresseeSearch(id) >= 0);
    }

    public void RecentActivityTick()
    {
        if (this.lastActiveTimestamp != DateTime.MaxValue)
        {
            float totalHours = (float) DateTime.UtcNow.Subtract(this.lastActiveTimestamp).TotalHours;
            if (totalHours > 0.03333334f)
            {
                totalHours = 0.03333334f;
            }
            this.pastGameHours += totalHours;
            this.gameHours = this.pastGameHours;
        }
        this.lastActiveTimestamp = DateTime.UtcNow;
    }

    public void ResetAggressee(uint id, byte stacks)
    {
        int index = this.AggresseeSearch(id);
        if (stacks == 0)
        {
            if (index >= 0)
            {
                this.AggresseeRemove(index);
            }
        }
        else
        {
            if (index < 0)
            {
                index = this.AggresseeAdd();
                this.aggresseePlayers[index] = id;
            }
            this.aggresseeStacks[index] = stacks;
        }
    }

    public byte StackAggressee(uint id)
    {
        int index = this.AggresseeSearch(id);
        byte num2 = 0;
        if (index < 0)
        {
            index = this.AggresseeAdd();
            this.aggresseePlayers[index] = id;
        }
        else if (index < this.aggresseeStacks.Length)
        {
            num2 = this.aggresseeStacks[index];
        }
        if (num2 < 0xff)
        {
            num2 = (byte) (num2 + 1);
        }
        if (index < this.aggresseeStacks.Length)
        {
            this.aggresseeStacks[index] = num2;
        }
        return num2;
    }

    public void StackKiller()
    {
        if (this.killerTraitStacks < 0xff)
        {
        }
        this.killerTraitExpiration = this.gameHours + 0f;
    }

    public void TickGameHours()
    {
        if (this.lastActiveTimestamp != DateTime.MaxValue)
        {
            float totalHours = (float) DateTime.UtcNow.Subtract(this.lastActiveTimestamp).TotalHours;
            if (totalHours > 0.03333334f)
            {
                totalHours = 0.03333334f;
                this.lastActiveTimestamp = DateTime.MaxValue;
                this.pastGameHours += totalHours;
                this.gameHours = this.pastGameHours;
            }
            else
            {
                this.gameHours = this.pastGameHours + totalHours;
            }
        }
    }

    public void TickKiller()
    {
        if ((this.killerTraitStacks > 0) && (this.gameHours >= this.killerTraitExpiration))
        {
            this.killerTraitStacks = 0;
        }
    }
}

