﻿using System;
using System.Collections.Generic;

[StrongDependency(typeof(ItemCategoryData))]
public class TreasureBoxItemData : BasicItemData
{
    private static readonly string[] _mandatoryColumns = new string[] { "name", "encumbrance", "description", "display name", "tier", "quality", "icon file name", "category", "loot tables", "account redeem" };
    public int[] lootTableIdOptions;

    public static TreasureBoxItemData NewUnittestItem(string itemName, int lootTableId, string testRedeemName)
    {
        TreasureBoxItemData data;
        data = new TreasureBoxItemData {
            name = itemName.ToLower(),
            id = DataClass.GenerateId(data.name),
            slot = BasicItemData.ItemSlot.NONE,
            encumbrance = 0.01f,
            description = "Some test item",
            displayName = itemName,
            tier = 1,
            baseQuality = 10,
            lootTableIdOptions = new int[] { lootTableId },
            redeemName = testRedeemName
        };
        ItemDatabase.itemById[data.id] = data;
        ItemDatabase.itemByName[data.name] = data;
        return data;
    }

    public override DataClass ParseRecord(int rowIndex)
    {
        string str;
        DataClass.GetLCaseCellValue(DataClass.columnNamesToIndex["name"], rowIndex, out str);
        if (!string.IsNullOrEmpty(str))
        {
            TreasureBoxItemData data = new TreasureBoxItemData {
                name = str,
                slot = BasicItemData.ItemSlot.NONE
            };
            bool flag = true;
            flag &= DataClass.GetCellValue(DataClass.columnNamesToIndex["encumbrance"], rowIndex, out data.encumbrance);
            DataClass.TryGetCellValue(DataClass.columnNamesToIndex["description"], rowIndex, out data.description);
            flag &= DataClass.GetCellValue(DataClass.columnNamesToIndex["display name"], rowIndex, out data.displayName);
            flag &= DataClass.GetCellValue(DataClass.columnNamesToIndex["tier"], rowIndex, out data.tier);
            flag &= DataClass.GetCellValue(DataClass.columnNamesToIndex["quality"], rowIndex, out data.baseQuality);
            DataClass.GetCellValue(DataClass.columnNamesToIndex["icon file name"], rowIndex, out data.icon);
            DataClass.TryGetIdFromForeignName<ItemCategoryData>(DataClass.columnNamesToIndex["category"], rowIndex, out data.categoryId);
            flag &= DataClass.GetIdsFromForeignNames<LootTableData>(DataClass.columnNamesToIndex["loot tables"], rowIndex, out data.lootTableIdOptions);
            DataClass.TryGetCellValue(DataClass.columnNamesToIndex["account redeem"], rowIndex, out data.redeemName);
            data.upgradable = false;
            if ((data.lootTableIdOptions == null) || (data.lootTableIdOptions.Length == 0))
            {
                flag = false;
                DataClass.OutputErrorMessage(DataClass.columnNamesToIndex["loot tables"], rowIndex, "Failed to parse valid loot tables");
            }
            if (flag)
            {
                return data;
            }
        }
        return null;
    }

    protected override IEnumerable<string> GetMandatoryColumns
    {
        get
        {
            return _mandatoryColumns;
        }
    }
}

