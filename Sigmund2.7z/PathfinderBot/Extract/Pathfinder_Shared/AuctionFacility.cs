﻿using System;
using UnityEngine;

public class AuctionFacility : Facility
{
    public override Facility.ActiveFacility MakeRuntime()
    {
        if (base.runtimeDetails == null)
        {
            base.runtimeDetails = new AuctionActiveFacility(base.transform.position, base.staticDetails);
        }
        else
        {
            base.runtimeDetails.position = base.transform.position;
            base.runtimeDetails.isLinked = false;
        }
        return base.runtimeDetails;
    }

    public class AuctionActiveFacility : Facility.ActiveFacility
    {
        public AuctionActiveFacility(Vector3 _pos, string staticDetails) : base(_pos, staticDetails)
        {
        }
    }
}

