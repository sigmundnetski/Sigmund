﻿using System;
using System.Runtime.CompilerServices;

public static class GroupConst
{
    public const float COMPANY_INVITE_TIMEOUT = 172800f;
    public const uint DEFAULT_SETTLEMENT_ID = 0;
    public static Predicate<ulong> EMPTY_COMPANY = i => (i == 0L);
    public static Predicate<uint> EMPTY_SETTLEMENT = i => (i == 0);
    public const ulong INVALID_COMPANY_ID = 0L;
    public const int MAX_COMPANY_MEMBERS = 500;
    public const int MAX_COMPANY_PARTICIPATION = 1;
    public const int MAX_PARTY_MEMBERS = 6;
    public const float PARTY_ACTIVITY_RANGE = 80f;
    public const float PARTY_INVITE_TIMEOUT = 60f;
    public const byte PARTY_RESPONSE_ACCEPT = 2;
    public const byte PARTY_RESPONSE_DECLINE = 1;
    public const byte PARTY_RESPONSE_IGNORE = 0;

    [CompilerGenerated]
    private static bool <.cctor>b__0(uint i)
    {
        return (i == 0);
    }

    [CompilerGenerated]
    private static bool <.cctor>b__1(ulong i)
    {
        return (i == 0L);
    }

    public enum CommandStatus : byte
    {
        NONE = 0,
        PVP_START_INVALID = 1,
        PVP_START_VALID = 2
    }

    public enum SettlementMember : byte
    {
        APPROVE = 2,
        DECLINE = 3,
        KICK = 1,
        NONE = 0
    }
}

