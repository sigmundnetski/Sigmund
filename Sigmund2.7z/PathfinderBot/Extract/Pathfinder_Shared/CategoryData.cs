﻿using System;
using System.Collections.Generic;

public class CategoryData : DataClass
{
    public static Dictionary<int, CategoryData> categoryById = new Dictionary<int, CategoryData>();
    public static Dictionary<string, CategoryData> categoryByName = new Dictionary<string, CategoryData>();
    [DataRestrict]
    public int categoryIndex;
    public string displayName;

    public static void CreateUnittestData(IEnumerable<string> names)
    {
        List<DataClass> objects = new List<DataClass>();
        foreach (string str in names)
        {
            CategoryData data;
            data = new CategoryData {
                name = data.displayName = str,
                id = DataClass.GenerateId(data.name)
            };
            objects.Add(data);
        }
        OnLoad(objects);
    }

    public static void OnLoad(List<DataClass> objects)
    {
        for (int i = 0; i < objects.Count; i++)
        {
            CategoryData data = (CategoryData) objects[i];
            categoryById[objects[i].id] = data;
            categoryByName[objects[i].name] = data;
            data.categoryIndex = i;
        }
    }

    public override DataClass ParseRecord(int rowIndex)
    {
        CategoryData data = new CategoryData();
        DataClass.GetLCaseCellValue(1, rowIndex, out data.name);
        DataClass.GetCellValue(2, rowIndex, out data.displayName);
        return data;
    }
}

