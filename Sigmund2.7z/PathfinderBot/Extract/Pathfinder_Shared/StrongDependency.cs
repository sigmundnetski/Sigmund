﻿using System;

public class StrongDependency : Dependency
{
    public StrongDependency(System.Type input) : base(input, DependencyStrength.STRONG)
    {
    }
}

