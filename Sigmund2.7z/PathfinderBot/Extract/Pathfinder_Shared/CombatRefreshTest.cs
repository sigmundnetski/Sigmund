﻿using System;

internal class CombatRefreshTest : UUnitTestCase
{
    protected override void SetUp()
    {
        CombatTestHelper.SetUp();
        CombatTestHelper.MakeCombatData();
        CombatTestHelper.AddAdminFeat(new AdministrativeFeatData("admin", 1, 1f, 10, 20f, "", "description", 0f));
        CombatTestHelper.AddRefreshFeat(new RefreshFeatData("3 uses", 1, 0f, 0, 0f, "Heal +100 to Self", "desc", "rDesc", 3));
        CombatTestHelper.AddRefreshFeat(new RefreshFeatData("1 use", 1, 0f, 0, 0f, "Heal +100 to Self", "desc", "rDesc", 1));
        CombatTestHelper.LoadNonAttackFeats();
    }

    protected override void TearDown()
    {
        CombatTestHelper.ClearAllCombatStaticData();
    }

    [UUnitTestMethod]
    public void TestAddRefresh()
    {
        CombatRefresh refresh = new CombatRefresh(10, 3, 1, 0);
        NonAttackFeatData featByName = NonAttackFeatData.GetFeatByName("1 use 1");
        refresh.AddRefresh(1);
        UUnitAssert.Equals((ulong) refresh.availableTotal, 2L, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals((ulong) refresh.usedToday, 0L, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.True(refresh.TryUseRefresh(), "Fail");
        refresh.AddRefresh(2);
        UUnitAssert.Equals((ulong) refresh.availableTotal, 3L, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals((ulong) refresh.usedToday, 1L, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.True(refresh.TryUseRefresh(), "Fail");
        UUnitAssert.True(refresh.TryUseRefresh(), "Fail");
        UUnitAssert.False(refresh.TryUseRefresh(), "Fail");
        UUnitAssert.Equals((ulong) refresh.availableTotal, 1L, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals((ulong) refresh.usedToday, (ulong) refresh.MAX_TODAY, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
    }

    [UUnitTestMethod]
    public void TestMultipleDays()
    {
        CombatRefresh refresh = new CombatRefresh(10, 3, 5, 2);
        NonAttackFeatData featByName = NonAttackFeatData.GetFeatByName("1 use 1");
        UUnitAssert.True(refresh.RefreshFeatUsable(featByName.id), "Fail");
        refresh.UseRefreshFeat(featByName.id);
        UUnitAssert.False(refresh.RefreshFeatUsable(featByName.id), "Fail");
        UUnitAssert.True(refresh.TryUseRefresh(), "Fail");
        UUnitAssert.True(refresh.RefreshFeatUsable(featByName.id), "Fail");
        refresh.UseRefreshFeat(featByName.id);
        UUnitAssert.False(refresh.RefreshFeatUsable(featByName.id), "Fail");
        UUnitAssert.False(refresh.TryUseRefresh(), "Fail");
        UUnitAssert.False(refresh.RefreshFeatUsable(featByName.id), "Fail");
        refresh.TickDay();
        UUnitAssert.False(refresh.RefreshFeatUsable(featByName.id), "Fail");
        UUnitAssert.True(refresh.TryUseRefresh(), "Fail");
        UUnitAssert.True(refresh.RefreshFeatUsable(featByName.id), "Fail");
        refresh.UseRefreshFeat(featByName.id);
        UUnitAssert.False(refresh.RefreshFeatUsable(featByName.id), "Fail");
        UUnitAssert.True(refresh.TryUseRefresh(), "Fail");
        UUnitAssert.True(refresh.RefreshFeatUsable(featByName.id), "Fail");
        refresh.UseRefreshFeat(featByName.id);
        UUnitAssert.False(refresh.RefreshFeatUsable(featByName.id), "Fail");
        UUnitAssert.True(refresh.TryUseRefresh(), "Fail");
        UUnitAssert.True(refresh.RefreshFeatUsable(featByName.id), "Fail");
        refresh.UseRefreshFeat(featByName.id);
        UUnitAssert.False(refresh.RefreshFeatUsable(featByName.id), "Fail");
        UUnitAssert.False(refresh.TryUseRefresh(), "Fail");
        UUnitAssert.False(refresh.RefreshFeatUsable(featByName.id), "Fail");
    }

    [UUnitTestMethod]
    public void TestUseFeatToMax()
    {
        CombatRefresh refresh = new CombatRefresh(10, 10, 10, 0);
        NonAttackFeatData featByName = NonAttackFeatData.GetFeatByName("3 uses 1");
        UUnitAssert.True(refresh.RefreshFeatUsable(featByName.id), "Fail");
        refresh.UseRefreshFeat(featByName.id);
        UUnitAssert.True(refresh.RefreshFeatUsable(featByName.id), "Fail");
        refresh.UseRefreshFeat(featByName.id);
        UUnitAssert.True(refresh.RefreshFeatUsable(featByName.id), "Fail");
        refresh.UseRefreshFeat(featByName.id);
        UUnitAssert.False(refresh.RefreshFeatUsable(featByName.id), "Fail");
        NonAttackFeatData data2 = NonAttackFeatData.GetFeatByName("1 use 1");
        UUnitAssert.True(refresh.RefreshFeatUsable(data2.id), "Fail");
        refresh.UseRefreshFeat(data2.id);
        UUnitAssert.False(refresh.RefreshFeatUsable(data2.id), "Fail");
    }

    [UUnitTestMethod]
    public void TestUseRefreshToAvailableToday()
    {
        CombatRefresh refresh = new CombatRefresh(10, 1, 10, 0);
        NonAttackFeatData featByName = NonAttackFeatData.GetFeatByName("1 use 1");
        UUnitAssert.True(refresh.RefreshFeatUsable(featByName.id), "Fail");
        refresh.UseRefreshFeat(featByName.id);
        UUnitAssert.False(refresh.RefreshFeatUsable(featByName.id), "Fail");
        UUnitAssert.True(refresh.TryUseRefresh(), "Fail");
        UUnitAssert.True(refresh.RefreshFeatUsable(featByName.id), "Fail");
        refresh.UseRefreshFeat(featByName.id);
        UUnitAssert.False(refresh.RefreshFeatUsable(featByName.id), "Fail");
        UUnitAssert.False(refresh.TryUseRefresh(), "Fail");
        UUnitAssert.False(refresh.RefreshFeatUsable(featByName.id), "Fail");
    }

    [UUnitTestMethod]
    public void TestUseRefreshToAvailableTotal()
    {
        CombatRefresh refresh = new CombatRefresh(10, 10, 1, 0);
        NonAttackFeatData featByName = NonAttackFeatData.GetFeatByName("1 use 1");
        UUnitAssert.True(refresh.RefreshFeatUsable(featByName.id), "Fail");
        refresh.UseRefreshFeat(featByName.id);
        UUnitAssert.False(refresh.RefreshFeatUsable(featByName.id), "Fail");
        UUnitAssert.True(refresh.TryUseRefresh(), "Fail");
        UUnitAssert.True(refresh.RefreshFeatUsable(featByName.id), "Fail");
        refresh.UseRefreshFeat(featByName.id);
        UUnitAssert.False(refresh.RefreshFeatUsable(featByName.id), "Fail");
        UUnitAssert.False(refresh.TryUseRefresh(), "Fail");
        UUnitAssert.False(refresh.RefreshFeatUsable(featByName.id), "Fail");
        refresh.AddRefresh(1);
        UUnitAssert.False(refresh.RefreshFeatUsable(featByName.id), "Fail");
        UUnitAssert.True(refresh.TryUseRefresh(), "Fail");
        UUnitAssert.True(refresh.RefreshFeatUsable(featByName.id), "Fail");
        refresh.UseRefreshFeat(featByName.id);
        UUnitAssert.False(refresh.RefreshFeatUsable(featByName.id), "Fail");
        UUnitAssert.False(refresh.TryUseRefresh(), "Fail");
        UUnitAssert.False(refresh.RefreshFeatUsable(featByName.id), "Fail");
    }

    [UUnitTestMethod]
    public void TestWrongFeat()
    {
        CombatRefresh refresh = new CombatRefresh(10, 10, 10, 10);
        NonAttackFeatData featByName = NonAttackFeatData.GetFeatByName("admin 1");
        UUnitAssert.False(refresh.RefreshFeatUsable(featByName.id), "Fail");
    }
}

