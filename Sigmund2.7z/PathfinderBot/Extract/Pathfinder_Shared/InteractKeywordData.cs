﻿using System;
using System.Collections.Generic;

public class InteractKeywordData : DataClass
{
    public static Dictionary<int, InteractKeywordData> keywordById = new Dictionary<int, InteractKeywordData>();

    public static InteractKeywordData CreateUnittestKeyword(string name)
    {
        InteractKeywordData data;
        data = new InteractKeywordData {
            name = name.ToLower(),
            id = DataClass.GenerateId(data.name)
        };
        keywordById[data.id] = data;
        return data;
    }

    public static void OnLoad(List<DataClass> objects)
    {
        for (int i = 0; i < objects.Count; i++)
        {
            InteractKeywordData data = (InteractKeywordData) objects[i];
            keywordById[objects[i].id] = data;
        }
    }

    public override DataClass ParseRecord(int rowIndex)
    {
        InteractKeywordData data = new InteractKeywordData();
        DataClass.GetLCaseCellValue(1, rowIndex, out data.name);
        return data;
    }
}

