﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using UnityEngine;

public static class StaticDataService
{
    private static object _synchronizedLock = new object();
    private static Dictionary<string, StaticDataServiceCallback> callbacks = new Dictionary<string, StaticDataServiceCallback>();
    private static Dictionary<string, List<DataClass>> data = new Dictionary<string, List<DataClass>>();
    private static string fallbackWatchDirectory = GUtil.PathCombine(new object[] { GConst.depotDir, "bin", "Data", "Packages" });
    private static string localWatchDirectory = GUtil.PathCombine(new object[] { "Data", "Packages" });
    private static Dictionary<string, string> needsReloading = new Dictionary<string, string>();
    private static string packageFormat = "*.pkg";
    private static PigFile pigFile = null;
    private static bool usingPigFile = false;
    private static string watchDirectory = "";
    private static FileSystemWatcher watcher;

    public static List<DataClass> GetList<T>() where T: DataClass
    {
        if (!data.ContainsKey(typeof(T).ToString()))
        {
            return new List<DataClass>();
        }
        return data[typeof(T).ToString()];
    }

    public static IEnumerable<DataClass> GetValues<T>() where T: DataClass
    {
        if (!data.ContainsKey(typeof(T).ToString()))
        {
            return Enumerable.Empty<DataClass>();
        }
        return data[typeof(T).ToString()];
    }

    [PermissionSet(SecurityAction.Demand, Name="FullTrust")]
    public static bool LoadingTick()
    {
        if ((watcher == null) || !watcher.EnableRaisingEvents)
        {
            if (!usingPigFile)
            {
                watcher = new FileSystemWatcher();
                watcher.Path = watchDirectory;
                watcher.NotifyFilter = NotifyFilters.LastWrite | NotifyFilters.FileName;
                watcher.Filter = packageFormat;
                watcher.IncludeSubdirectories = true;
                watcher.Changed += new FileSystemEventHandler(StaticDataService.OnChanged);
                watcher.Created += new FileSystemEventHandler(StaticDataService.OnChanged);
                watcher.Deleted += new FileSystemEventHandler(StaticDataService.OnChanged);
                watcher.EnableRaisingEvents = true;
            }
            SyncFixedUpdate();
        }
        return true;
    }

    public static void LoadSpecificType<T>(bool isUnity = true)
    {
        if (isUnity)
        {
            SetUnityDirectories();
        }
        string key = typeof(T).ToString();
        List<DataClass> list = null;
        if (!data.TryGetValue(key, out list) || (list.Count <= 0))
        {
            string fileNameWithoutExtension;
            DirectoryInfo info = null;
            if (Directory.Exists(localWatchDirectory))
            {
                info = new DirectoryInfo(localWatchDirectory);
                foreach (FileInfo info2 in info.GetFiles(packageFormat, SearchOption.TopDirectoryOnly))
                {
                    fileNameWithoutExtension = Path.GetFileNameWithoutExtension(info2.Name);
                    if (fileNameWithoutExtension == key)
                    {
                        needsReloading.AddIfMissing<string>(fileNameWithoutExtension, info2.FullName);
                        break;
                    }
                }
            }
            else
            {
                string str3;
                if (GUtil.TryFindDataParent(out str3))
                {
                    info = new DirectoryInfo(GUtil.PathCombine(new object[] { str3, "Data", "Packages" }));
                    foreach (FileInfo info2 in info.GetFiles(packageFormat, SearchOption.TopDirectoryOnly))
                    {
                        fileNameWithoutExtension = Path.GetFileNameWithoutExtension(info2.Name);
                        if (fileNameWithoutExtension == key)
                        {
                            needsReloading.AddIfMissing<string>(fileNameWithoutExtension, info2.FullName);
                            break;
                        }
                    }
                }
                info = new DirectoryInfo(fallbackWatchDirectory);
                foreach (FileInfo info2 in info.GetFiles(packageFormat, SearchOption.TopDirectoryOnly))
                {
                    fileNameWithoutExtension = Path.GetFileNameWithoutExtension(info2.Name);
                    if (fileNameWithoutExtension == key)
                    {
                        needsReloading.AddIfMissing<string>(fileNameWithoutExtension, info2.FullName);
                        break;
                    }
                }
            }
            SyncFixedUpdate();
        }
    }

    private static void OnChanged(object source, FileSystemEventArgs e)
    {
        lock (_synchronizedLock)
        {
            FileInfo info = new FileInfo(e.FullPath);
            string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(info.Name);
            needsReloading.AddIfMissing<string>(fileNameWithoutExtension, info.FullName);
        }
    }

    public static void RegisterCallback<T>(StaticDataServiceCallback cback)
    {
        string key = typeof(T).ToString();
        if (!callbacks.ContainsKey(key))
        {
            callbacks.Add(key, cback);
        }
        else
        {
            Dictionary<string, StaticDataServiceCallback> dictionary;
            string str2;
            (dictionary = callbacks)[str2 = key] = (StaticDataServiceCallback) Delegate.Combine(dictionary[str2], cback);
        }
        if (data.ContainsKey(key))
        {
            cback(data[key]);
        }
    }

    private static void ReloadPackages()
    {
        foreach (KeyValuePair<string, string> pair in needsReloading)
        {
            data.Remove(pair.Key);
            if (File.Exists(pair.Value) || usingPigFile)
            {
                System.Type type = System.Type.GetType(pair.Key);
                if (type == null)
                {
                    GLog.LogError(new object[] { "Unable to load package [" + pair.Key + "] because the C# Type is undefined:  Found [null], Expected [" + pair.Key + "]" });
                }
                else
                {
                    Package package = null;
                    if (usingPigFile)
                    {
                        package = new DataPackage(pigFile.GetFileData(pair.Value), type);
                    }
                    else
                    {
                        package = new DataPackage(pair.Value, type);
                    }
                    if (!package.IsVersionValid)
                    {
                        GLog.LogError(new object[] { "Unable to load package [" + pair.Key + "] due to an invalid version:  Found [" + package.version + "], Expected [" + package.CURRENT_VERSION + "]" });
                    }
                    else
                    {
                        try
                        {
                            package.LoadTableOfContents();
                            package.LoadAllObjects();
                            if ((package.contents != null) && (package.contents.Count > 0))
                            {
                                data.Add(pair.Key, package.contents);
                                MethodInfo method = type.GetMethod("OnLoad", BindingFlags.FlattenHierarchy | BindingFlags.Public | BindingFlags.Static);
                                if (method != null)
                                {
                                    method.Invoke(null, new object[] { package.contents });
                                }
                                if (callbacks.ContainsKey(pair.Key))
                                {
                                    callbacks[pair.Key](package.contents);
                                }
                            }
                        }
                        catch (Exception exception)
                        {
                            GLog.LogError(new object[] { string.Concat(new object[] { "There was a problem loading package [", pair.Key, "]. Using PigFile: ", usingPigFile, "  Exception: ", exception.ToString() }) });
                        }
                        package.Dispose();
                    }
                }
            }
        }
    }

    internal static void SetInitialLoadList(Dictionary<string, string> loadList)
    {
        DirectoryInfo info = null;
        watchDirectory = fallbackWatchDirectory;
        if (usingPigFile)
        {
            string[] containedFileNames = pigFile.GetContainedFileNames();
            foreach (string str in containedFileNames)
            {
                string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(str.Replace('\\', Path.DirectorySeparatorChar));
                loadList.AddIfMissing<string>(fileNameWithoutExtension, str);
            }
        }
        else
        {
            string str3;
            if (Directory.Exists(localWatchDirectory))
            {
                info = new DirectoryInfo(localWatchDirectory);
                foreach (FileInfo info2 in info.GetFiles(packageFormat, SearchOption.TopDirectoryOnly))
                {
                    str3 = Path.GetFileNameWithoutExtension(info2.Name);
                    loadList.AddIfMissing<string>(str3, info2.FullName);
                }
                watchDirectory = localWatchDirectory;
            }
            else
            {
                string str4;
                if (GUtil.TryFindDataParent(out str4))
                {
                    string path = GUtil.PathCombine(new object[] { str4, "Data", "Packages" });
                    info = new DirectoryInfo(path);
                    if (info.Exists)
                    {
                        foreach (FileInfo info2 in info.GetFiles(packageFormat, SearchOption.TopDirectoryOnly))
                        {
                            str3 = Path.GetFileNameWithoutExtension(info2.Name);
                            loadList.AddIfMissing<string>(str3, info2.FullName);
                        }
                    }
                    watchDirectory = path;
                }
                info = new DirectoryInfo(fallbackWatchDirectory);
                if (info.Exists)
                {
                    foreach (FileInfo info2 in info.GetFiles(packageFormat, SearchOption.TopDirectoryOnly))
                    {
                        str3 = Path.GetFileNameWithoutExtension(info2.Name);
                        loadList.AddIfMissing<string>(str3, info2.FullName);
                    }
                }
            }
        }
    }

    private static void SetUnityDirectories()
    {
        localWatchDirectory = GUtil.PathCombine(new object[] { Application.dataPath, "Packages" });
        string path = GUtil.PathCombine(new object[] { Application.dataPath, "Packages.pig" });
        if (File.Exists(path))
        {
            usingPigFile = true;
            pigFile = new PigFile(path);
        }
    }

    public static bool Shutdown()
    {
        if (!usingPigFile)
        {
            watcher.EnableRaisingEvents = false;
            watcher.Dispose();
        }
        return true;
    }

    public static bool SyncFixedUpdate()
    {
        if (needsReloading.Count > 0)
        {
            lock (_synchronizedLock)
            {
                ReloadPackages();
                needsReloading.Clear();
            }
        }
        return true;
    }

    public static void SyncStart(bool isUnity)
    {
        if (isUnity)
        {
            SetUnityDirectories();
        }
        SetInitialLoadList(needsReloading);
    }

    public delegate void StaticDataServiceCallback(List<DataClass> objects);
}

