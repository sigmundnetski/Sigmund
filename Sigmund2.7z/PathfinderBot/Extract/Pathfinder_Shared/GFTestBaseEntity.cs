﻿using System;

internal class GFTestBaseEntity
{
    public int id;
    public GFTestInventory inventory;
}

