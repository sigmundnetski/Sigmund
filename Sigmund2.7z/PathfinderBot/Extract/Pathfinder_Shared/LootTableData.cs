﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

[LooseDependency(typeof(ItemDatabase))]
public class LootTableData : DataClass
{
    private CycleState cycleState = CycleState.UNSEARCHED;
    public string displayName;
    private string invalidMessage = "";
    public PickGroupData[] pickGroups = null;
    public int skillId;
    public int[] subTableIds = null;
    [DataRestrict]
    internal string[] subTableNames = null;
    public static Dictionary<int, LootTableData> tablesById = new Dictionary<int, LootTableData>();
    public static Dictionary<string, LootTableData> tablesByName = new Dictionary<string, LootTableData>();

    private static List<DataClass> _ParseSheet()
    {
        string str;
        BasicItemData data;
        DataClass.GetLCaseCellValue(2, 1, out str);
        if (ItemDatabase.itemByName.TryGetValue(str, out data))
        {
            DataClass.OutputErrorMessage("Cell B1 on " + DataClass.sheetname + ": " + str + " cannot be parsed as a loot table, as that item name is already taken");
            return new List<DataClass>();
        }
        int rowIndex = 4;
        List<PickGroupData> list = new List<PickGroupData>();
        while (rowIndex <= DataClass.MAX_ROW)
        {
            PickGroupData item = PickGroupData.ParsePickGroup(ref rowIndex);
            if (item != null)
            {
                list.Add(item);
            }
        }
        LootTableData data3 = new LootTableData {
            name = str
        };
        DataClass.TryGetCellValue(3, 1, out data3.displayName);
        DataClass.TryGetIdFromForeignName<SkillData>(5, 1, out data3.skillId);
        data3.pickGroups = list.ToArray();
        ParseAllSubTableIds(data3.pickGroups, out data3.subTableIds, out data3.subTableNames);
        return new List<DataClass> { data3 };
    }

    public static void OnLoad(List<DataClass> objects)
    {
        foreach (LootTableData data in objects)
        {
            tablesById[data.id] = data;
            tablesByName[data.name] = data;
        }
        HashSet<int> parentIds = new HashSet<int>();
        foreach (LootTableData data in objects)
        {
            if (data.cycleState == CycleState.UNSEARCHED)
            {
                SetCycleState(ref parentIds, data);
            }
        }
        foreach (LootTableData data in objects)
        {
            if (data.cycleState == CycleState.INVALID)
            {
                tablesById.Remove(data.id);
                tablesByName.Remove(data.name);
                GLog.LogWarning(new object[] { "Invalid Loot Table (", data.name, "):", data.invalidMessage });
            }
        }
    }

    public static void ParseAllSubTableIds(IEnumerable<PickGroupData> groups, out int[] subTableIds, out string[] subTableNames)
    {
        List<int> list = new List<int>();
        List<string> list2 = new List<string>();
        foreach (PickGroupData data in groups)
        {
            list.AddRange(data.GetSubTableIds());
            list2.AddRange(data.GetSubTableNames());
        }
        subTableIds = list.ToArray();
        subTableNames = list2.ToArray();
    }

    public override List<DataClass> ParseSheet()
    {
        return _ParseSheet();
    }

    private static void SetCycleState(ref HashSet<int> parentIds, LootTableData node)
    {
        node.cycleState = CycleState.SEARCHED;
        parentIds.Add(node.id);
        for (int i = 0; i < node.subTableIds.Length; i++)
        {
            LootTableData data;
            int item = node.subTableIds[i];
            string str = (node.subTableNames != null) ? node.subTableNames[i] : "<Unknown>";
            bool flag = parentIds.Contains(item);
            bool flag2 = tablesById.TryGetValue(item, out data);
            if (flag || !flag2)
            {
                node.cycleState = CycleState.INVALID;
                if (flag)
                {
                    node.invalidMessage = "Circular Loot-Table Reference.";
                }
                else
                {
                    node.invalidMessage = "Referenced table does not exist: " + str;
                }
                return;
            }
            if (data.cycleState == CycleState.UNSEARCHED)
            {
                SetCycleState(ref parentIds, data);
            }
            node.cycleState = (CycleState) Math.Max((byte) node.cycleState, (byte) data.cycleState);
        }
        parentIds.Remove(node.id);
    }

    private enum CycleState : byte
    {
        INVALID = 3,
        SEARCHED = 2,
        UNSEARCHED = 1
    }
}

