﻿using GNetwork;
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

public static class SocietySync
{
    public static CompaniesUpdateDelegate CompaniesUpdate = null;
    public static SettlementRecord DEFAULT_SETTLEMENT;
    public static HashSet<ulong> playerCompanyIds = new HashSet<ulong>();
    public static uint playerSettlementId = 0;
    private static Dictionary<ulong, VentureCompanyRecord> recvCompanies;
    private static Dictionary<uint, SettlementRecord> recvSettlements;
    public static SettlementsUpdateDelegate SettlementsUpdate = null;

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void CompaniesReceive(IBitBufferRead buffer)
    {
        int num2;
        playerCompanyIds.Clear();
        uint num = buffer.PopUInt();
        for (num2 = 0; num2 < num; num2++)
        {
            playerCompanyIds.Add(buffer.PopULong());
        }
        uint num3 = buffer.PopUInt();
        for (num2 = 0; num2 < num3; num2++)
        {
            byte targetLevel = buffer.PopByte();
            ulong companyId = buffer.PopULong();
            GConst.DataSyncOperation operation = (GConst.DataSyncOperation) buffer.PopRawByte(2, GConst.BufferErrorCode.ERROR_RAW_BITS);
            bool flag = buffer.PopBool();
            buffer.PopToByteAlignFront();
            try
            {
                switch (operation)
                {
                    case GConst.DataSyncOperation.ADD:
                    {
                        if (flag)
                        {
                            ProcessCompanyAdd(buffer, targetLevel, companyId);
                        }
                        continue;
                    }
                    case GConst.DataSyncOperation.UPDATE:
                    {
                        if (flag)
                        {
                            ProcessCompanyUpdate(buffer, targetLevel, companyId);
                        }
                        continue;
                    }
                    case GConst.DataSyncOperation.REMOVE:
                    {
                        if (recvCompanies.ContainsKey(companyId))
                        {
                            recvCompanies.Remove(companyId);
                        }
                        continue;
                    }
                }
                GLog.LogWarning(new object[] { "Invalid operation for Company Id: " + companyId });
            }
            catch (Exception exception)
            {
                GLog.LogException(exception, "Error while deserializing Company:" + companyId.ToString());
                return;
            }
        }
        if (CompaniesUpdate != null)
        {
            GUtil.FilterExceptions("SocietyData.UpdateCallbacks", CompaniesUpdate.Method, new object[] { playerCompanyIds });
        }
    }

    public static void CompaniesSend(IBitBufferWrite buffer, object dataSyncOperations)
    {
        Dictionary<ulong, GConst.DataSyncOperation> dictionary = (Dictionary<ulong, GConst.DataSyncOperation>) dataSyncOperations;
        uint count = (uint) dictionary.Count;
        buffer.PushUInt((uint) playerCompanyIds.Count);
        foreach (ulong num2 in playerCompanyIds)
        {
            buffer.PushULong(num2);
            if (dictionary.ContainsKey(num2))
            {
                count++;
            }
        }
        buffer.PushUInt(count);
        foreach (KeyValuePair<ulong, GConst.DataSyncOperation> pair in dictionary)
        {
            GetLevelAndPushCompany(buffer, pair.Key, pair.Value);
        }
    }

    private static void GetLevelAndPushCompany(IBitBufferWrite buffer, ulong syncIdToSend, GConst.DataSyncOperation operation)
    {
        SyncTarget target = playerCompanyIds.Contains(syncIdToSend) ? SyncTarget.MEMBER_ONLY : SyncTarget.ALLIES;
        PushCompanyToBuffer(buffer, syncIdToSend, operation, 0);
        if ((target == SyncTarget.MEMBER_ONLY) && (DataSerializerUtils.GetNumberSyncLevels(typeof(VentureCompanyRecord)) > 1))
        {
            PushCompanyToBuffer(buffer, syncIdToSend, operation, 1);
        }
    }

    private static void GetLevelAndPushSettlement(IBitBufferWrite buffer, uint syncIdToSend, GConst.DataSyncOperation operation)
    {
        SyncTarget target = (syncIdToSend == playerSettlementId) ? SyncTarget.MEMBER_ONLY : SyncTarget.ALLIES;
        PushSettlementToBuffer(buffer, syncIdToSend, operation, 0);
        if ((target == SyncTarget.MEMBER_ONLY) && (DataSerializerUtils.GetNumberSyncLevels(typeof(SettlementRecord)) > 1))
        {
            PushSettlementToBuffer(buffer, syncIdToSend, operation, 1);
        }
    }

    public static void LoadingTickFinished()
    {
        DEFAULT_SETTLEMENT = new SettlementRecord("No Settlement", SettlementData.DEFAULT_SETTLEMENT.id, 0);
        DEFAULT_SETTLEMENT.settlementId = 0;
        TimeSpan noPvpStart = SettlementPvpData.singleton.noPvpStart;
        TimeSpan noPvpEnd = SettlementPvpData.singleton.noPvpEnd;
        TimeSpan span3 = TimeSpan.FromDays(1.0);
        DEFAULT_SETTLEMENT.pvpWindowBegin = (uint) noPvpEnd.TotalMinutes;
        TimeSpan span4 = span3 + (noPvpStart - noPvpEnd);
        DEFAULT_SETTLEMENT.pvpWindowDuration = (uint) span4.TotalMinutes;
    }

    private static void ProcessCompanyAdd(IBitBufferRead buffer, byte targetLevel, ulong companyId)
    {
        VentureCompanyRecord record = (VentureCompanyRecord) DataUtilities.DeserializeObjectFromNetwork(buffer, typeof(VentureCompanyRecord), targetLevel, null);
        if (recvCompanies.ContainsKey(companyId))
        {
            VentureCompanyRecord target = recvCompanies[companyId];
            record.DataCopyTo(ref target, targetLevel);
        }
        else
        {
            recvCompanies[companyId] = record;
        }
    }

    private static void ProcessCompanyUpdate(IBitBufferRead buffer, byte targetLevel, ulong companyId)
    {
        bool flag = false;
        VentureCompanyRecord baseObj = null;
        if (recvCompanies.ContainsKey(companyId))
        {
            baseObj = recvCompanies[companyId];
            flag = true;
        }
        else
        {
            baseObj = new VentureCompanyRecord();
        }
        VentureCompanyRecord record2 = (VentureCompanyRecord) DataUtilities.DeserializeObjectFromNetwork(buffer, typeof(VentureCompanyRecord), targetLevel, baseObj);
        recvCompanies[companyId] = record2;
        if (!flag)
        {
            GLog.LogWarning(new object[] { "Received an UPDATE operation for companyId [" + companyId + "] but it was not in the collection.  The delta has been applied to a new empty object." });
        }
    }

    private static void ProcessSettlementAdd(IBitBufferRead buffer, byte targetLevel, uint settlementId)
    {
        SettlementRecord record = (SettlementRecord) DataUtilities.DeserializeObjectFromNetwork(buffer, typeof(SettlementRecord), targetLevel, null);
        if (recvSettlements.ContainsKey(settlementId))
        {
            SettlementRecord target = recvSettlements[settlementId];
            record.DataCopyTo(ref target, targetLevel);
        }
        else
        {
            recvSettlements[settlementId] = record;
        }
    }

    private static void ProcessSettlementUpdate(IBitBufferRead buffer, byte targetLevel, uint settlementId)
    {
        bool flag = false;
        SettlementRecord baseObj = null;
        if (recvSettlements.ContainsKey(settlementId))
        {
            baseObj = recvSettlements[settlementId];
            flag = true;
        }
        else
        {
            baseObj = new SettlementRecord();
        }
        SettlementRecord record2 = (SettlementRecord) DataUtilities.DeserializeObjectFromNetwork(buffer, typeof(SettlementRecord), targetLevel, baseObj);
        recvSettlements[settlementId] = record2;
        if (!flag)
        {
            GLog.LogWarning(new object[] { "Received an UPDATE operation for settlementId [" + settlementId + "] but it was not in the collection.  The delta has been applied to a new empty object." });
        }
    }

    private static void PushCompanyToBuffer(IBitBufferWrite buffer, ulong syncIdToSend, GConst.DataSyncOperation operation, byte targetLevel)
    {
        NetworkSync<ulong, VentureCompanyRecord>.SyncContext syncContext = NetworkSync<ulong, VentureCompanyRecord>.GetSyncContext();
        BitBuffer sourceBuffer = null;
        switch (operation)
        {
            case GConst.DataSyncOperation.INVALID:
                return;

            case GConst.DataSyncOperation.ADD:
                sourceBuffer = syncContext.fullBuffers[syncIdToSend][targetLevel];
                break;

            case GConst.DataSyncOperation.UPDATE:
                sourceBuffer = syncContext.deltaBuffers[syncIdToSend][targetLevel];
                break;

            case GConst.DataSyncOperation.REMOVE:
                break;

            default:
                return;
        }
        buffer.PushByte(targetLevel);
        buffer.PushULong(syncIdToSend);
        buffer.PushRawByte((byte) operation, 2);
        bool flag = (sourceBuffer != null) && (sourceBuffer.lengthBits > 0);
        buffer.PushBool(flag);
        buffer.PushToByteAlignEnd();
        if (flag)
        {
            buffer.CopyBits(sourceBuffer, sourceBuffer.lengthBits);
        }
    }

    private static void PushSettlementToBuffer(IBitBufferWrite buffer, uint syncIdToSend, GConst.DataSyncOperation operation, byte targetLevel)
    {
        NetworkSync<uint, SettlementRecord>.SyncContext syncContext = NetworkSync<uint, SettlementRecord>.GetSyncContext();
        BitBuffer sourceBuffer = null;
        switch (operation)
        {
            case GConst.DataSyncOperation.INVALID:
                return;

            case GConst.DataSyncOperation.ADD:
                sourceBuffer = syncContext.fullBuffers[syncIdToSend][targetLevel];
                break;

            case GConst.DataSyncOperation.UPDATE:
                sourceBuffer = syncContext.deltaBuffers[syncIdToSend][targetLevel];
                break;

            case GConst.DataSyncOperation.REMOVE:
                break;

            default:
                return;
        }
        buffer.PushByte(targetLevel);
        buffer.PushUInt(syncIdToSend);
        buffer.PushRawByte((byte) operation, 2);
        bool flag = (sourceBuffer != null) && (sourceBuffer.lengthBits > 0);
        buffer.PushBool(flag);
        buffer.PushToByteAlignEnd();
        if (flag)
        {
            buffer.CopyBits(sourceBuffer, sourceBuffer.lengthBits);
        }
    }

    [G_RPC(GConst.RpcMode.FROM_SERVER)]
    public static void SettlementsReceive(IBitBufferRead buffer)
    {
        playerSettlementId = buffer.PopUInt();
        uint num = buffer.PopUInt();
        for (int i = 0; i < num; i++)
        {
            byte targetLevel = buffer.PopByte();
            uint settlementId = buffer.PopUInt();
            GConst.DataSyncOperation operation = (GConst.DataSyncOperation) buffer.PopRawByte(2, GConst.BufferErrorCode.ERROR_RAW_BITS);
            bool flag = buffer.PopBool();
            buffer.PopToByteAlignFront();
            try
            {
                switch (operation)
                {
                    case GConst.DataSyncOperation.ADD:
                    {
                        if (flag)
                        {
                            ProcessSettlementAdd(buffer, targetLevel, settlementId);
                        }
                        continue;
                    }
                    case GConst.DataSyncOperation.UPDATE:
                    {
                        if (flag)
                        {
                            ProcessSettlementUpdate(buffer, targetLevel, settlementId);
                        }
                        continue;
                    }
                    case GConst.DataSyncOperation.REMOVE:
                    {
                        if (recvSettlements.ContainsKey(settlementId))
                        {
                            recvSettlements.Remove(settlementId);
                        }
                        continue;
                    }
                }
                GLog.LogWarning(new object[] { "Invalid operation for Settlement Id: " + settlementId });
            }
            catch (Exception exception)
            {
                GLog.LogException(exception, "Error while deserializing Settlement:" + settlementId.ToString());
                return;
            }
        }
        if (SettlementsUpdate != null)
        {
            GUtil.FilterExceptions("SocietyData.UpdateCallbacks", SettlementsUpdate.Method, new object[] { playerSettlementId });
        }
    }

    public static void SettlementsSend(IBitBufferWrite buffer, object dataSyncOperations)
    {
        Dictionary<uint, GConst.DataSyncOperation> dictionary = (Dictionary<uint, GConst.DataSyncOperation>) dataSyncOperations;
        buffer.PushUInt(playerSettlementId);
        uint count = (uint) dictionary.Count;
        if (DataSerializerUtils.GetNumberSyncLevels(typeof(SettlementRecord)) > 1)
        {
            count += dictionary.ContainsKey(playerSettlementId) ? 1 : 0;
        }
        buffer.PushUInt(count);
        foreach (KeyValuePair<uint, GConst.DataSyncOperation> pair in dictionary)
        {
            GetLevelAndPushSettlement(buffer, pair.Key, pair.Value);
        }
    }

    public static void SetUp(Dictionary<uint, SettlementRecord> settlementDict, SettlementsUpdateDelegate settlementCallback, Dictionary<ulong, VentureCompanyRecord> companyDict, CompaniesUpdateDelegate companiesCallback)
    {
        recvSettlements = settlementDict;
        SettlementsUpdate = settlementCallback;
        recvCompanies = companyDict;
        CompaniesUpdate = companiesCallback;
    }

    public static bool SyncToAll(byte syncLevel)
    {
        return ((syncLevel == 0xff) || (syncLevel == 0));
    }

    public static bool SyncToMember(byte syncLevel)
    {
        return ((syncLevel == 0xff) || (syncLevel == 1));
    }

    public delegate void CompaniesUpdateDelegate(HashSet<ulong> myCompanies);

    public delegate void SettlementsUpdateDelegate(uint mySettlementId);

    public enum SyncTarget : byte
    {
        ALLIES = 0,
        MEMBER_ONLY = 1
    }
}

