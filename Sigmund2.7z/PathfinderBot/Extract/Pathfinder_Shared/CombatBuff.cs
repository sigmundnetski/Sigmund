﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.InteropServices;

public class CombatBuff
{
    private static Dictionary<string, CombatBuff> buffImplCache = new Dictionary<string, CombatBuff>();
    public Combat.Channel channel;
    public Combat.EffectType effectType;
    public string name;

    public CombatBuff(string name_, Combat.Channel channel_, Combat.EffectType effectType_)
    {
        this.name = name_;
        this.channel = channel_;
        this.effectType = effectType_;
    }

    public static bool AssertBuff(CombatBuff buffImpl, string method, string className)
    {
        bool flag = buffImpl == null;
        if (flag)
        {
            GLog.LogError(new object[] { method, "No implementation class for", className });
        }
        return flag;
    }

    public static CombatBuffVars CreateBuff(uint combatTick, CombatModifier mod, CombatVars target)
    {
        if (mod.className == string.Empty)
        {
            return null;
        }
        return GetImpl(mod.className).Initialize(combatTick, mod, target, 0);
    }

    public virtual void Expire(CombatBuffVars buffVars, uint combatTick)
    {
        throw new NotImplementedException("Expire() has not been implemented in this subclass.  N:" + this.name + ", C:" + base.GetType().Name);
    }

    public static void Expire(uint combatTick, CombatBuffVars buffVars)
    {
        CombatBuff impl = GetImpl(buffVars.combatMod.className);
        if (!AssertBuff(impl, "Expire", buffVars.combatMod.className))
        {
            impl.Expire(buffVars, combatTick);
        }
    }

    public virtual bool Expired(CombatBuffVars buffVars, uint combatTick)
    {
        throw new NotImplementedException("Expired() has not been implemented in this subclass.  N:" + this.name + ", C:" + base.GetType().Name);
    }

    public static bool Expired(uint combatTick, CombatBuffVars buffVars)
    {
        CombatBuff impl = GetImpl(buffVars.combatMod.className);
        if (!AssertBuff(impl, "Expired", buffVars.combatMod.className))
        {
            return impl.Expired(buffVars, combatTick);
        }
        return true;
    }

    public static CombatBuffVars GetBuff(CombatVars target, CombatConstants.Buff buff)
    {
        return SparseArray.Find<CombatBuffVars>(target.buffs, i => (i.combatMod.type == CombatModifierType.BUFF) && (i.combatMod.buff == buff));
    }

    public static CombatBuffVars GetBuff(CombatVars target, CombatModifier mod)
    {
        return SparseArray.Find<CombatBuffVars>(target.buffs, i => i.combatMod.ModTypeEquals(mod));
    }

    public static CombatBuffVars GetBuff(CombatVars target, string buffName)
    {
        return SparseArray.Find<CombatBuffVars>(target.buffs, i => i.name == buffName);
    }

    public static CombatBuff GetImpl(string className)
    {
        CombatBuff buff;
        if (className == string.Empty)
        {
            return null;
        }
        if (!buffImplCache.TryGetValue(className, out buff))
        {
            MethodInfo method = System.Type.GetType(className).GetMethod("Create");
            Func<CombatBuff> func = (Func<CombatBuff>) Delegate.CreateDelegate(typeof(Func<CombatBuff>), method);
            buff = func();
            buffImplCache.Add(className, buff);
        }
        return buff;
    }

    public static string GetLogString(CombatEffect effect, CombatModifier mod)
    {
        CombatBuff impl = GetImpl(mod.className);
        if (!AssertBuff(impl, "GetLogString", mod.className))
        {
            return impl.GetLogString(mod, effect, 0);
        }
        return string.Empty;
    }

    public virtual string GetLogString(CombatModifier mod, CombatEffect effect, int defenseBonus = 0)
    {
        throw new NotImplementedException("GetLogString() has not been implemented in this subclass.  N:" + this.name + ", C:" + base.GetType().Name);
    }

    public static CombatBuffVars GetStack(CombatVars target, CombatConstants.Stack stack)
    {
        return SparseArray.Find<CombatBuffVars>(target.buffs, i => (i.combatMod.type == CombatModifierType.STACK) && (i.combatMod.stack == stack));
    }

    public static CombatBuffVars GetState(CombatVars target, CombatConstants.State state)
    {
        return SparseArray.Find<CombatBuffVars>(target.buffs, i => ((i != null) && (i.combatMod.type == CombatModifierType.STATE)) && (i.combatMod.state == state));
    }

    public static bool HasBuff(CombatVars target, CombatConstants.Buff buff)
    {
        return (GetBuff(target, buff) != null);
    }

    public static bool HasBuff(CombatVars target, string buffName)
    {
        return (GetBuff(target, buffName) != null);
    }

    public static bool HasStack(CombatVars target, CombatConstants.Stack stack)
    {
        return (GetStack(target, stack) != null);
    }

    public static bool HasState(CombatVars target, CombatConstants.State state)
    {
        return (GetState(target, state) != null);
    }

    public virtual CombatBuffVars Initialize(uint combatTick, CombatModifier mod, CombatVars target, int additionalDefense)
    {
        return new CombatBuffVars(this.name, this.channel, this.effectType, combatTick, mod, target, additionalDefense);
    }

    public virtual void RecalculationPhase(CombatBuffVars buffVars, uint combatTick)
    {
        throw new NotImplementedException("RecalculationPhase() has not been implemented in this subclass.  N:" + this.name + ", C:" + base.GetType().Name);
    }

    public static void RecalculationPhase(uint combatTick, CombatBuffVars buffVars)
    {
        CombatBuff impl = GetImpl(buffVars.combatMod.className);
        if (!AssertBuff(impl, "RecalculationPhase", buffVars.combatMod.className))
        {
            impl.RecalculationPhase(buffVars, combatTick);
        }
    }

    public virtual void ResolutionPhase(CombatBuffVars buffVars, uint combatTick)
    {
        throw new NotImplementedException("ResolutionPhase() has not been implemented in this subclass.  N:" + this.name + ", C:" + base.GetType().Name);
    }

    public static void ResolutionPhase(uint combatTick, CombatBuffVars buffVars)
    {
        CombatBuff impl = GetImpl(buffVars.combatMod.className);
        if (!AssertBuff(impl, "ResolutionPhase", buffVars.combatMod.className))
        {
            impl.ResolutionPhase(buffVars, combatTick);
        }
    }

    public virtual void TimePhase(CombatBuffVars buffVars, uint combatTick)
    {
        throw new NotImplementedException("TimePhase() has not been implemented in this subclass.  N:" + this.name + ", C:" + base.GetType().Name);
    }

    public static void TimePhase(uint combatTick, CombatBuffVars buffVars)
    {
        CombatBuff impl = GetImpl(buffVars.combatMod.className);
        if (!AssertBuff(impl, "TimePhase", buffVars.combatMod.className))
        {
            impl.TimePhase(buffVars, combatTick);
        }
    }

    public virtual void UpdateBuff(CombatBuffVars buffVars, uint combatTick, CombatModifier mod, CombatEffect effect)
    {
        throw new NotImplementedException("UpdateBuff() has not been implemented in this subclass.  N:" + this.name + ", C:" + base.GetType().Name);
    }

    public static void UpdateBuff(uint combatTick, CombatBuffVars buffVars, CombatModifier mod, CombatEffect effect)
    {
        CombatBuff impl = GetImpl(mod.className);
        if (!AssertBuff(impl, "UpdateBuff", mod.className))
        {
            impl.UpdateBuff(buffVars, combatTick, mod, effect);
        }
    }
}

