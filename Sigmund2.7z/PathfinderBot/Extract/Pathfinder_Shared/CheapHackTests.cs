﻿using GNetwork;
using System;

public class CheapHackTests : UUnitTestCase
{
    [UUnitTestMethod]
    public void TestInventoryArray()
    {
        DataSerializer back = null;
        BitBuffer quickBuffer = GUtil.GetQuickBuffer();
        InventoryItem[] itemArray4 = new InventoryItem[] { new InventoryItem(12, 12, 12, 1), InventoryItem.EMPTY, new InventoryItem(12, 12, 12, 1), InventoryItem.EMPTY };
        InventoryItem[] itemArray = itemArray4;
        itemArray4 = new InventoryItem[] { InventoryItem.EMPTY, new InventoryItem(13, 13, 13, 1), new InventoryItem(13, 13, 13, 1), InventoryItem.EMPTY, InventoryItem.EMPTY, new InventoryItem(13, 13, 13, 1), new InventoryItem(13, 13, 13, 1), InventoryItem.EMPTY };
        InventoryItem[] itemArray2 = itemArray4;
        itemArray4 = new InventoryItem[] { new InventoryItem(14, 14, 14, 1), InventoryItem.EMPTY };
        InventoryItem[] itemArray3 = itemArray4;
        Array baseObjArray = new InventoryItem[itemArray.Length];
        CheapHacks.WriteSimpleArray(back, quickBuffer, null, typeof(InventoryItem[]), 0, 0xff, itemArray, null);
        CheapHacks.ReadSimpleArray(quickBuffer, null, typeof(InventoryItem[]), 0, itemArray.Length, ref baseObjArray);
        UUnitAssert.DeepEquals<InventoryItem>(itemArray, baseObjArray as InventoryItem[], 0xff, InventoryItem.EMPTY_MATCH, "Expected equivalent lists:\n{0}\n!=\n{1}");
        baseObjArray = new InventoryItem[itemArray2.Length];
        CheapHacks.WriteSimpleArray(back, quickBuffer, null, typeof(InventoryItem[]), 0, 0xff, itemArray2, itemArray);
        CheapHacks.ReadSimpleArray(quickBuffer, null, typeof(InventoryItem[]), 0, itemArray2.Length, ref baseObjArray);
        UUnitAssert.DeepEquals<InventoryItem>(itemArray2, baseObjArray as InventoryItem[], 0xff, InventoryItem.EMPTY_MATCH, "Expected equivalent lists:\n{0}\n!=\n{1}");
        baseObjArray = new InventoryItem[itemArray3.Length];
        CheapHacks.WriteSimpleArray(back, quickBuffer, null, typeof(InventoryItem[]), 0, 0xff, itemArray3, itemArray2);
        CheapHacks.ReadSimpleArray(quickBuffer, null, typeof(InventoryItem[]), 0, itemArray3.Length, ref baseObjArray);
        UUnitAssert.DeepEquals<InventoryItem>(itemArray3, baseObjArray as InventoryItem[], 0xff, InventoryItem.EMPTY_MATCH, "Expected equivalent lists:\n{0}\n!=\n{1}");
    }
}

