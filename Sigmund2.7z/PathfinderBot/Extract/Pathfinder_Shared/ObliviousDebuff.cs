﻿using System;

public class ObliviousDebuff : CombatStackBuff
{
    public ObliviousDebuff() : base("Oblivious", Combat.Channel.Weakness, Combat.EffectType.Detrimental)
    {
        base.recoveryBonusType = RecoveryType.Oblivious;
    }

    public static ObliviousDebuff Create()
    {
        return new ObliviousDebuff();
    }

    public override CombatBuffVars Initialize(uint combatTick, CombatModifier mod, CombatVars target, int additionalDefense)
    {
        int resistanceBonus = target.GetResistanceBonus(ResistanceType.Physical);
        return base.Initialize(combatTick, mod, target, resistanceBonus);
    }

    public override void RecalculationPhase(CombatBuffVars buff, uint combatTick)
    {
        int num = -buff.stacks;
        int specific = buff.owner.tempAttackBonuses.Channel(base.channel).GetSpecific(AttackType.Base);
        if (num < specific)
        {
            buff.owner.tempAttackBonuses.Channel(base.channel).SetSpecific(AttackType.Base, num);
        }
        int byCodeName = buff.owner.tempSkillBonuses.Channel(base.channel).GetByCodeName(SkillData.CodeSkillName.Perception);
        if (num < byCodeName)
        {
            buff.owner.tempSkillBonuses.Channel(base.channel).SetByCodeName(SkillData.CodeSkillName.Perception, num);
        }
    }
}

