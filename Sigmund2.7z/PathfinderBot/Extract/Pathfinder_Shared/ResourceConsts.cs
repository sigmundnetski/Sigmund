﻿using System;
using UnityEngine;

public static class ResourceConsts
{
    private const string baselineQualityLevel = "fastest";
    public static int DEFAULT_MIP_LEVEL = 4;
    public static float DEFAULT_MIP_SQRDISTANCE = 12100f;
    public static float INTERMEDIATE_MIP_END_SQRDISTANCE = 10000f;
    public static int INTERMEDIATE_MIP_LEVEL = 2;
    public static float INTERMEDIATE_MIP_START_SQRDISTANCE = 2500f;
    public static int MAX_MIP_LEVEL = 0;
    public static float MAX_MIP_SQRDISTANCE = 1600f;
    public static readonly string pigFileName = GUtil.PathCombine(new object[] { Application.dataPath, "Textures.pig" });
    public static readonly string pigFolder = Application.dataPath;
    public static QualitySettingsData qualityData = null;
    public static readonly string RESOURCE_FOLDER_NAME = "RunTime";
    public static readonly string resourceFallbackFolder = GUtil.PathCombine(new object[] { GConst.depotDir, "bin", "Data", "Bundles", RESOURCE_FOLDER_NAME });
    public static readonly string resourceFallbackFormat = GUtil.PathCombine(new object[] { GConst.depotDir, "bin", "Data", resourceRelativeToData });
    public static readonly string resourceFolder = GUtil.PathCombine(new object[] { Application.dataPath, "Bundles", RESOURCE_FOLDER_NAME });
    public static readonly string resourcePigFileFormat = resourceRelativeToData;
    public static readonly string resourceRawFormat = GUtil.PathCombine(new object[] { Application.dataPath, resourceRelativeToData });
    public static readonly string resourceRelativeToData = GUtil.PathCombine(new object[] { "Bundles", RESOURCE_FOLDER_NAME, "{0}" });
    public static readonly string resourceSaveFormat = GUtil.PathCombine(new object[] { GConst.depotDir, "bin", "Data", resourceRelativeToData });
    public static int TEXTURE_THRESHOLD_CALM = -2147483648;
    public static int TEXTURE_THRESHOLD_PANIC = 0x7fffffff;

    static ResourceConsts()
    {
        int qualityLevel = QualitySettings.GetQualityLevel();
        string key = QualitySettings.names[qualityLevel].ToLower();
        qualityData = null;
        if (QualitySettingsData.qualitiesByName.TryGetValue(key, out qualityData) || QualitySettingsData.qualitiesByName.TryGetValue("fastest", out qualityData))
        {
            TEXTURE_THRESHOLD_PANIC = qualityData.thresholdPanic;
            TEXTURE_THRESHOLD_CALM = qualityData.thresholdCalm;
            MAX_MIP_SQRDISTANCE = qualityData.sqrdistanceMaxMip;
            INTERMEDIATE_MIP_START_SQRDISTANCE = qualityData.sqrdistanceIntermediateMipStart;
            INTERMEDIATE_MIP_END_SQRDISTANCE = qualityData.sqrdistanceIntermediateMipEnd;
            DEFAULT_MIP_SQRDISTANCE = qualityData.sqrdistanceDefaultMip;
            MAX_MIP_LEVEL = qualityData.mipMaxLevel;
            INTERMEDIATE_MIP_LEVEL = qualityData.mipIntermediateLevel;
            DEFAULT_MIP_LEVEL = qualityData.mipDefaultLevel;
        }
    }
}

