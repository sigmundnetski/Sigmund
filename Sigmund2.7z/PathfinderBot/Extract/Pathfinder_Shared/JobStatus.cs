﻿using System;
using System.Diagnostics;

public class JobStatus : IDataCopyable<JobStatus>
{
    public bool alive = true;
    public string args;
    public float cpuUsage = 0f;
    public long curMemory = 0L;
    public string fileName;
    public ulong jobId;
    public long maxMemory = 0L;
    [DataRestrict]
    public Process process;
    public int processId;
    public ActivityStatus status;
    public string timeEnded;
    public string timeStarted;

    public void DataCopyTo(ref JobStatus target, byte syncTargetLevel)
    {
        target.processId = this.processId;
        target.jobId = this.jobId;
        target.fileName = this.fileName;
        target.args = this.args;
        target.curMemory = this.curMemory;
        target.maxMemory = this.maxMemory;
        target.cpuUsage = this.cpuUsage;
        target.alive = this.alive;
        target.timeStarted = this.timeStarted;
        target.timeEnded = this.timeEnded;
        target.status = this.status;
    }

    public bool DataEquals(JobStatus target, byte syncTargetLevel)
    {
        if (object.ReferenceEquals(target, null))
        {
            return false;
        }
        bool flag = true;
        return (((((((((((flag && (target.processId == this.processId)) && (target.jobId == this.jobId)) && (target.fileName == this.fileName)) && (target.args == this.args)) && (target.curMemory == this.curMemory)) && (target.maxMemory == this.maxMemory)) && (target.cpuUsage == this.cpuUsage)) && (target.alive == this.alive)) && (target.timeStarted == this.timeStarted)) && (target.timeEnded == this.timeEnded)) && (target.status == this.status));
    }

    public override string ToString()
    {
        string str = "";
        string str3 = str;
        object obj2 = str3 + this.fileName + " " + this.args + Environment.NewLine;
        obj2 = string.Concat(new object[] { obj2, "  Current Memory: ", this.curMemory, Environment.NewLine });
        obj2 = string.Concat(new object[] { obj2, "  Max Memory: ", this.maxMemory, Environment.NewLine });
        str = string.Concat(new object[] { obj2, "  Cpu: ", this.cpuUsage, Environment.NewLine });
        if (!this.alive)
        {
            str = str + "  Process Terminated";
        }
        return str;
    }

    public enum ActivityStatus : byte
    {
        ACTIVE = 0,
        CLOSED = 2,
        CRASHED = 3,
        HANGING = 1
    }
}

