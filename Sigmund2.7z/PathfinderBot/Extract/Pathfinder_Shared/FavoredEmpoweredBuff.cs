﻿using System;

public class FavoredEmpoweredBuff : CombatTimedBuff
{
    private static int[] BASE_ATTACK_BONUS = new int[] { 10, 30 };
    private static int[] BASE_DEFENSE_BONUS = new int[] { 10, 30 };

    public FavoredEmpoweredBuff() : base("FavoredEmpowered", Combat.Channel.Supernatural, Combat.EffectType.Beneficial)
    {
    }

    public static FavoredEmpoweredBuff Create()
    {
        return new FavoredEmpoweredBuff();
    }

    public override string GetLogString(CombatModifier mod, CombatEffect effect, int defenseBonus)
    {
        uint num;
        float num2;
        this.GetDuration(mod, effect, defenseBonus, out num, out num2);
        return GUtil.GetQuickText().Append(this.GetName(mod.buff)).Append(" (").Append(CombatCore.SecondsFromTicks(num)).Append(" seconds)").ToString();
    }

    private string GetName(CombatConstants.Buff buff)
    {
        switch (buff)
        {
            case CombatConstants.Buff.FAVORED:
                return "Favored";

            case CombatConstants.Buff.EMPOWERED:
                return "Empowered";
        }
        return base.name;
    }

    public override CombatBuffVars Initialize(uint combatTick, CombatModifier mod, CombatVars target, int additionalDefense)
    {
        CombatBuffVars vars = base.Initialize(combatTick, mod, target, additionalDefense);
        vars.basicName = this.GetName(mod.buff);
        vars.name = vars.basicName;
        if (mod.buff == CombatConstants.Buff.FAVORED)
        {
            vars.value0 = 0;
            return vars;
        }
        if (mod.buff == CombatConstants.Buff.EMPOWERED)
        {
            vars.value0 = 1;
        }
        return vars;
    }

    public override void RecalculationPhase(CombatBuffVars buff, uint combatTick)
    {
        int specific = buff.owner.tempDefenses.Channel(base.channel).GetSpecific(DefenseType.Base);
        if (BASE_DEFENSE_BONUS[buff.value0] > specific)
        {
            buff.owner.tempDefenses.Channel(base.channel).SetSpecific(DefenseType.Base, BASE_DEFENSE_BONUS[buff.value0]);
        }
        int num2 = buff.owner.tempAttackBonuses.Channel(base.channel).GetSpecific(AttackType.Base);
        if (BASE_ATTACK_BONUS[buff.value0] > num2)
        {
            buff.owner.tempAttackBonuses.Channel(base.channel).SetSpecific(AttackType.Base, BASE_ATTACK_BONUS[buff.value0]);
        }
    }
}

