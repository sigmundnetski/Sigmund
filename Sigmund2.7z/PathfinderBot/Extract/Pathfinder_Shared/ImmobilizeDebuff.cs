﻿using System;

public class ImmobilizeDebuff : CombatTimedBuff
{
    private const string FREEDOM_MOD = "Freedom +14 to Self";
    private static CombatModifier[] freedomCombatMod = CombatModifier.Parse("Freedom +14 to Self");

    public ImmobilizeDebuff() : base("Immobilize", Combat.Channel.Torment, Combat.EffectType.Detrimental)
    {
    }

    public static ImmobilizeDebuff Create()
    {
        return new ImmobilizeDebuff();
    }

    public override CombatBuffVars Initialize(uint combatTick, CombatModifier mod, CombatVars target, int additionalDefense)
    {
        CombatBuffVars stack = CombatBuff.GetStack(target, CombatConstants.Stack.FREEDOM);
        int stacks = 0;
        if (stack != null)
        {
            stacks = stack.stacks;
        }
        return base.Initialize(combatTick, mod, target, stacks);
    }

    public override void RecalculationPhase(CombatBuffVars buff, uint combatTick)
    {
        buff.owner.tempRestrictionType = (CombatVars.RestrictionType) ((byte) (buff.owner.tempRestrictionType | CombatVars.RestrictionType.NoMovement));
    }

    public override void ResolutionPhase(CombatBuffVars buff, uint combatTick)
    {
    }

    public override void UpdateBuff(CombatBuffVars buff, uint combatTick, CombatModifier mod, CombatEffect effect)
    {
        CombatBuffVars stack = CombatBuff.GetStack(buff.owner, CombatConstants.Stack.FREEDOM);
        if (stack != null)
        {
            buff.defenseBonus = Math.Max(stack.stacks, buff.defenseBonus);
        }
        base.UpdateBuff(buff, combatTick, mod, effect);
        CombatEffect item = new CombatEffect(freedomCombatMod, buff.owner, buff.owner, CombatEffect.TargetType.ATTACKER, Combat.EffectType.Neutral);
        buff.owner.combatEffects.Enqueue(item);
        if (CombatCore.restrictMovement != null)
        {
            CombatCore.restrictMovement(buff.owner, CombatConstants.Buff.IMMOBILIZE, CombatVars.RestrictionType.NoMovement, CombatCore.SecondsFromTicks(buff.expirationTick - combatTick));
        }
    }
}

