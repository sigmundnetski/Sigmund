﻿using System;

public enum EntityId : ulong
{
    INVALID_ID = 0L
}

