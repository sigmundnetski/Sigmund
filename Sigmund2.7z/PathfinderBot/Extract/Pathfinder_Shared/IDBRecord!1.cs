﻿using System;

public interface IDBRecord<KeyType>
{
    KeyType GetDBKey();
    void OnDBLoad();
    void OnDBUnload();
    void OnDBWrite();
}

