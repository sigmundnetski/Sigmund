﻿using System;

internal class GFTestByteEnum : IDataCopyable<GFTestByteEnum>
{
    public int id;
    public Status status;

    public void DataCopyTo(ref GFTestByteEnum target, byte syncTargetLevel)
    {
        target.id = this.id;
        target.status = this.status;
    }

    public bool DataEquals(GFTestByteEnum target, byte syncTargetLevel)
    {
        if (object.ReferenceEquals(this, target))
        {
            return true;
        }
        if (object.ReferenceEquals(target, null))
        {
            return false;
        }
        bool flag = true;
        return ((flag && (this.id == target.id)) && (this.status == target.status));
    }

    public enum Status : byte
    {
        Invalid = 1,
        Undefined = 0,
        Valid = 2
    }
}

