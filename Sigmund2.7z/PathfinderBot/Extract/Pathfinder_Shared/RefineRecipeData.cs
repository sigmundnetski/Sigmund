﻿using System;
using System.Collections.Generic;
using System.Linq;

[NoFinalOutput]
public class RefineRecipeData : BaseRecipeData
{
    private static readonly string[] _mandatoryColumns = new string[] { "stock 1", "#1", "stock 2", "#2", "stock 3", "#3", "stock 4", "#4", "upgrade" };

    protected override BaseRecipeData Instantiate()
    {
        return new RefineRecipeData { formula = BaseRecipeData.OutputFormula.REFINING };
    }

    protected override bool ParseInputs(ref BaseRecipeData output, int rowIndex)
    {
        Dictionary<int, uint> dictionary = new Dictionary<int, uint>();
        int num2 = 0;
        List<string> list = new List<string>();
        for (int i = 1; i <= 4; i++)
        {
            int num;
            uint num3;
            string str;
            DataClass.GetCellValue(DataClass.columnNamesToIndex["stock " + i], rowIndex, out str);
            if (DataClass.TryGetIdFromForeignName<StockData>(DataClass.columnNamesToIndex["stock " + i], rowIndex, out num) && DataClass.TryGetCellValue(DataClass.columnNamesToIndex["#" + i], rowIndex, out num3))
            {
                num2++;
                dictionary[num] = num3;
            }
            else if (!string.IsNullOrEmpty(str))
            {
                list.Add(str);
            }
        }
        if (list.Count > 0)
        {
            DataClass.OutputErrorMessage(DataClass.columnNamesToIndex["stock 1"], rowIndex, "These stocks did not parse:\n" + string.Join(", ", list.ToArray()));
        }
        else if (dictionary.Count == 0)
        {
            DataClass.OutputErrorMessage(DataClass.columnNamesToIndex["stock 1"], rowIndex, "Recipe has no input components.");
        }
        else if (dictionary.Count != num2)
        {
            DataClass.OutputErrorMessage(DataClass.columnNamesToIndex["stock 1"], rowIndex, "Duplicate stocks found.");
        }
        output.inputStockIds = dictionary.Keys.ToArray<int>();
        output.inputQtys = dictionary.Values.ToArray<uint>();
        DataClass.GetCellValue(DataClass.columnNamesToIndex["upgrade"], rowIndex, out output.outputUpgrade);
        return (((list.Count == 0) && (dictionary.Count > 0)) && (dictionary.Count == num2));
    }

    protected override IEnumerable<string> GetMandatoryColumns
    {
        get
        {
            return BaseRecipeData._baseMandatoryColumns.Concat<string>(_mandatoryColumns);
        }
    }
}

