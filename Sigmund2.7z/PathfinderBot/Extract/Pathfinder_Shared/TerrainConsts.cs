﻿using System;

public static class TerrainConsts
{
    public const float hexHeight = 665.1075f;
    public const float hexHeightHalf = 332.5537f;
    public const float hexSize = 384f;
    public const float hexSizeHalf = 192f;
    public const float hexSizeSqr = 147456f;
    public const float hexWidth = 768f;
    public const int MAP_ID_OFFSET = 0x80;
    public static readonly int MAX_VALID_HEX_X = 0x7f;
    public static readonly int[] MAX_VALID_HEX_Z = new int[] { 0x7f, 0x7f };
    public static readonly int MIN_VALID_HEX_X = -127;
    public static readonly int[] MIN_VALID_HEX_Z = new int[] { -127, -127 };
    public static readonly int[] neighborOffsetsX = new int[] { 0, 1, 1, 0, -1, -1 };
    public static readonly int[][] neighborOffsetsZ = new int[][] { new int[] { -1, -1, 0, 1, 0, -1 }, new int[] { -1, 0, 1, 1, 1, 0 } };
    public static readonly float[] neighborPositionOffsetsX = new float[] { 0f, 576f, 576f, 0f, -576f, -576f };
    public static readonly float[] neighborPositionOffsetsZ = new float[] { 665.1075f, 332.5537f, -332.5537f, -665.1075f, -332.5537f, 332.5537f };
    public const int NUM_EXTRA_TILES = 1;
    public const int NUM_TILES_PER_ROW = 3;
    public const float PLAYER_TRANSFER_DISTANCE = 15f;
    public const float sqrt3 = 1.732051f;
    public const string TERRAIN_NAME_FORMAT = "Tile[{0}.{1}]";
    public static readonly IntVec2 THORNKEEP = new IntVec2(0, 0);
    public static readonly ushort THORNKEEP_MAPID = TerrainUtils.GetMapIdFromHex(THORNKEEP);
    public const float THORNKEEP_X = 8961.5f;
    public const float THORNKEEP_Z = 2380.5f;
    public const float tileSize = 1024f;
    public const float tileSizeHalf = 512f;
    public const float ZERO_TILE_CENTER_X = 8704f;
    public const float ZERO_TILE_CENTER_Z = 2560f;

    static TerrainConsts()
    {
        string str = StartupParameters.RemoveParameterToProcess("runtimeValidHexRange");
        if (!string.IsNullOrEmpty(str))
        {
            string[] strArray = str.Split(new char[] { ' ' });
            if (strArray.Length != 6)
            {
                GLog.LogError(new object[] { "TerrainConsts: runtimeValidHexRange was supplied without enough parameters.  All 6 values must be supplied." });
            }
            else
            {
                if (!int.TryParse(strArray[0], out MIN_VALID_HEX_X))
                {
                    MIN_VALID_HEX_X = -127;
                }
                if (!int.TryParse(strArray[1], out MAX_VALID_HEX_X))
                {
                    MAX_VALID_HEX_X = 0x7f;
                }
                if (!int.TryParse(strArray[2], out MIN_VALID_HEX_Z[0]))
                {
                    MIN_VALID_HEX_Z[0] = -127;
                }
                if (!int.TryParse(strArray[3], out MIN_VALID_HEX_Z[1]))
                {
                    MIN_VALID_HEX_Z[1] = -127;
                }
                if (!int.TryParse(strArray[4], out MAX_VALID_HEX_Z[0]))
                {
                    MAX_VALID_HEX_Z[0] = 0x7f;
                }
                if (!int.TryParse(strArray[5], out MAX_VALID_HEX_Z[1]))
                {
                    MAX_VALID_HEX_Z[1] = 0x7f;
                }
                GLog.Log(new object[] { "Runtime Valid Hex Range - ", "minX:", MIN_VALID_HEX_X, "maxX:", MAX_VALID_HEX_X, "minZ:", MIN_VALID_HEX_Z, "maxZ:", MAX_VALID_HEX_Z });
            }
        }
    }
}

