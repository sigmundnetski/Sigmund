﻿using System;
using System.IO;
using System.Threading;

public abstract class ResourceLoader
{
    protected Exception ex;
    private Status status;
    public bool stayReadable;

    public ResourceLoader()
    {
        this.CurrentStatus = Status.Loading;
        this.stayReadable = false;
        this.ex = null;
    }

    public ResourceLoader(bool _stayReadable)
    {
        this.CurrentStatus = Status.Loading;
        this.stayReadable = _stayReadable;
        this.ex = null;
    }

    public abstract void FinalizeLoad();
    protected static FileStream GetFileData(string assetName)
    {
        if (ResourceManager.pigFile != null)
        {
            string desiredFileName = string.Format(ResourceConsts.resourcePigFileFormat, assetName);
            if (ResourceManager.pigFile.ContainsFile(desiredFileName))
            {
                return ResourceManager.pigFile.GetFileData(desiredFileName);
            }
            if (!ResourceManager.SERVER_MODE)
            {
                throw new Exception("Could not load file data from pig file for " + assetName);
            }
            return null;
        }
        string path = string.Format(ResourceConsts.resourceRawFormat, assetName);
        if (!File.Exists(path))
        {
            path = string.Format(ResourceConsts.resourceFallbackFormat, assetName);
        }
        if (File.Exists(path))
        {
            return new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
        }
        if (!ResourceManager.SERVER_MODE)
        {
            throw new Exception("Could not load file data for " + assetName);
        }
        return null;
    }

    public abstract void LoadResource();
    public abstract void LoadResource(object state);

    public Status CurrentStatus
    {
        get
        {
            Thread.MemoryBarrier();
            Status status = this.status;
            Thread.MemoryBarrier();
            return status;
        }
        protected set
        {
            Thread.MemoryBarrier();
            this.status = value;
            Thread.MemoryBarrier();
        }
    }

    public enum Status
    {
        Loading,
        Loaded
    }
}

