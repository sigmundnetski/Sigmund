﻿using System;

public class RipostingBuff : CombatTimedBuff
{
    private const int ATTACK_BONUS = 30;

    public RipostingBuff() : base("Riposting", Combat.Channel.Extraordinary, Combat.EffectType.Beneficial)
    {
    }

    public static RipostingBuff Create()
    {
        return new RipostingBuff();
    }

    public override void RecalculationPhase(CombatBuffVars buff, uint combatTick)
    {
        int specific = buff.owner.tempAttackBonuses.Channel(base.channel).GetSpecific(AttackType.HeavyMelee);
        if (30 > specific)
        {
            buff.owner.tempAttackBonuses.Channel(base.channel).SetSpecific(AttackType.HeavyMelee, 30);
        }
        int num2 = buff.owner.tempAttackBonuses.Channel(base.channel).GetSpecific(AttackType.LightMelee);
        if (30 > num2)
        {
            buff.owner.tempAttackBonuses.Channel(base.channel).SetSpecific(AttackType.LightMelee, 30);
        }
    }

    public override void TimePhase(CombatBuffVars buff, uint combatTick)
    {
        if ((combatTick > (buff.updatedTick + 1)) && ((buff.owner.prevAttackInfo.attackType == AttackType.HeavyMelee) || (buff.owner.prevAttackInfo.attackType == AttackType.LightMelee)))
        {
            buff.expirationTick = combatTick;
        }
    }
}

