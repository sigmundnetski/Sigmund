﻿using System;
using System.Runtime.InteropServices;
using UnityEngine;

public class GwEncounterLocation
{
    public string data;
    public Vector3 pos;
    public Quaternion rot;

    public static GwEncounterLocation FromEncounterLocation(EncounterLocation enc, bool validateHierarchy = false)
    {
        if (validateHierarchy)
        {
            Transform parent = enc.transform.parent;
            if ((parent == null) || ((parent != null) && (parent.GetComponent<TerrainDecorations>() == null)))
            {
                throw new InvalidObjectDepthException("Manually placed EncounterLocations must have their immediate parent be a TerrainDecorations object.");
            }
            if (enc.transform.childCount > 0)
            {
                throw new InvalidObjectDepthException("Manually placed EncounterLocations must not have any children.");
            }
        }
        return new GwEncounterLocation { pos = enc.transform.position, rot = enc.transform.rotation, data = enc.staticDetails };
    }

    public static EncounterLocation ToEncounterLocation(GwEncounterLocation gwEnc, Transform parent = null)
    {
        GameObject obj2 = new GameObject("EncounterLocation");
        EncounterLocation location = obj2.AddComponent<EncounterLocation>();
        obj2.transform.parent = parent;
        obj2.transform.localPosition = gwEnc.pos;
        obj2.transform.localRotation = gwEnc.rot;
        location.staticDetails = gwEnc.data;
        return location;
    }
}

