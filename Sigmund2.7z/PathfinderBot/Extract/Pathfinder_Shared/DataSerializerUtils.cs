﻿using GNetwork;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using UnityEngine;

public static class DataSerializerUtils
{
    public const BindingFlags BIND_FLAGS = (BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance);
    [ThreadStatic]
    private static Dictionary<FieldInfo, byte> cachedFields;
    [ThreadStatic]
    private static Dictionary<System.Type, byte> cachedTypes;
    [ThreadStatic]
    private static System.Type[] dataEqualsTypeArray;
    [ThreadStatic]
    private static object[] deltaEqualsObjArray;
    [ThreadStatic]
    private static Dictionary<System.Type, MethodInfo> equalities;
    [ThreadStatic]
    private static object[] equalsObjArray;
    [ThreadStatic]
    private static System.Type[] equalsTypeArray;
    private static FieldInfo[] NO_RESULTS = new FieldInfo[0];
    [ThreadStatic]
    private static Dictionary<System.Type, byte> syncLevels;
    [ThreadStatic]
    private static Dictionary<TypeDefinitionCacheKey, FieldInfo[]> typeDefinitionCache;
    [ThreadStatic]
    private static Dictionary<System.Type, FieldInfo[][]> types;
    public const byte UNDECORATED_LEVEL = 0;

    public static void DataCopyField<T>(T[] src, ref T[] dst) where T: struct
    {
        if (src != null)
        {
            if ((dst == null) || (dst.Length < src.Length))
            {
                dst = new T[src.Length];
            }
            Array.Copy(src, dst, src.Length);
        }
        else
        {
            dst = null;
        }
    }

    public static void DataCopyField<T>(T src, ref T dst, byte syncTargetLevel) where T: class, IDataCopyable<T>
    {
        if (src != null)
        {
            if (((T) dst) == null)
            {
                dst = (T) Activator.CreateInstance(src.GetType());
            }
            src.DataCopyTo(ref dst, syncTargetLevel);
        }
        else
        {
            dst = default(T);
        }
    }

    public static void DataCopyStringArray(string[] src, ref string[] dst)
    {
        if (src != null)
        {
            if ((dst == null) || (dst.Length < src.Length))
            {
                dst = new string[src.Length];
            }
            Array.Copy(src, dst, src.Length);
        }
        else
        {
            dst = null;
        }
    }

    public static bool DataEquals<T>(T a, T b, byte syncTargetLevel) where T: class, IDataCopyable<T>
    {
        if (object.ReferenceEquals(a, null) && object.ReferenceEquals(b, null))
        {
            return true;
        }
        if (object.ReferenceEquals(a, null) || object.ReferenceEquals(b, null))
        {
            return false;
        }
        return a.DataEquals(b, syncTargetLevel);
    }

    public static int[] FirstIndex(Array array)
    {
        if (array.Length == 0)
        {
            return null;
        }
        int rank = array.Rank;
        int[] numArray = new int[rank];
        for (int i = 0; i < rank; i++)
        {
            numArray[i] = array.GetLowerBound(i);
        }
        return numArray;
    }

    public static byte GetDefaultLevel(System.Type type)
    {
        if (cachedTypes == null)
        {
            cachedTypes = new Dictionary<System.Type, byte>();
        }
        byte targetLevel = 0;
        if (!cachedTypes.TryGetValue(type, out targetLevel))
        {
            if (Attribute.IsDefined(type, typeof(DataSyncTo)))
            {
                targetLevel = ((DataSyncTo) Attribute.GetCustomAttribute(type, typeof(DataSyncTo))).TargetLevel;
            }
            cachedTypes[type] = targetLevel;
        }
        return targetLevel;
    }

    public static byte GetDefaultLevel(FieldInfo field, System.Type type)
    {
        if (cachedFields == null)
        {
            cachedFields = new Dictionary<FieldInfo, byte>();
        }
        byte targetLevel = 0;
        if (field == null)
        {
            return GetDefaultLevel(type);
        }
        if (!cachedFields.TryGetValue(field, out targetLevel))
        {
            if (Attribute.IsDefined(field, typeof(DataSyncTo)))
            {
                targetLevel = ((DataSyncTo) Attribute.GetCustomAttribute(field, typeof(DataSyncTo))).TargetLevel;
            }
            else if (Attribute.IsDefined(type, typeof(DataSyncTo)))
            {
                targetLevel = ((DataSyncTo) Attribute.GetCustomAttribute(type, typeof(DataSyncTo))).TargetLevel;
            }
            cachedFields[field] = targetLevel;
        }
        return targetLevel;
    }

    public static byte GetNumberSyncLevels(System.Type type)
    {
        if (syncLevels == null)
        {
            syncLevels = new Dictionary<System.Type, byte>();
        }
        byte num = 0;
        if (!syncLevels.TryGetValue(type, out num))
        {
            ProcessType(null, type, 0);
            num = syncLevels[type];
        }
        return num;
    }

    public static FieldInfo[] GetTypeDefinition(FieldInfo field, System.Type type, byte defaultLevel, byte targetLevel)
    {
        FieldInfo[] infoArray;
        if (types == null)
        {
            types = new Dictionary<System.Type, FieldInfo[][]>();
        }
        if (typeDefinitionCache == null)
        {
            typeDefinitionCache = new Dictionary<TypeDefinitionCacheKey, FieldInfo[]>(TypeDefinitionCacheKeyComparer.Instance);
        }
        TypeDefinitionCacheKey key = new TypeDefinitionCacheKey(field, type, defaultLevel, targetLevel);
        if (!typeDefinitionCache.TryGetValue(key, out infoArray))
        {
            infoArray = NO_RESULTS;
            FieldInfo[][] infoArray2 = null;
            if (!types.TryGetValue(type, out infoArray2))
            {
                ProcessType(field, type, defaultLevel);
                infoArray2 = types[type];
            }
            if ((infoArray2 == null) || (targetLevel < defaultLevel))
            {
                infoArray = NO_RESULTS;
            }
            else
            {
                byte num = GetDefaultLevel(field, type);
                if ((num == 0) && (defaultLevel > num))
                {
                    num = defaultLevel;
                }
                List<FieldInfo> list = new List<FieldInfo>();
                if (((num == targetLevel) && (targetLevel > 0)) && (infoArray2[0] != null))
                {
                    list.AddRange(infoArray2[0]);
                }
                if ((targetLevel < infoArray2.Length) && (infoArray2[targetLevel] != null))
                {
                    list.AddRange(infoArray2[targetLevel]);
                }
                infoArray = typeDefinitionCache[key] = list.ToArray();
            }
        }
        return infoArray;
    }

    public static bool IsArrayEqual(Array obj1, Array obj2, byte syncTargetLevel)
    {
        if ((obj1 != null) || (obj2 != null))
        {
            int arrayRank = 0;
            int num2 = 0;
            if (obj1 != null)
            {
                arrayRank = obj1.GetType().GetArrayRank();
            }
            if (obj2 != null)
            {
                num2 = obj2.GetType().GetArrayRank();
            }
            if (arrayRank != num2)
            {
                return false;
            }
            System.Type elementType = obj1.GetType().GetElementType();
            if ((arrayRank == 1) && CheapHacks.CheckElementType(elementType))
            {
                return CheapHacks.IsArrayEqual(obj1, obj2, elementType, syncTargetLevel);
            }
            GLog.LogWarning(new object[] { "IsArrayEqual is trying to compare an array that is not optimized:" + obj1.GetType().Name });
            for (int i = 0; i < arrayRank; i++)
            {
                if (obj1.GetLength(i) != obj2.GetLength(i))
                {
                    return false;
                }
            }
            for (int[] numArray = FirstIndex(obj1); numArray != null; numArray = NextIndex(obj1, numArray))
            {
                object obj3 = obj1.GetValue(numArray);
                object obj4 = obj2.GetValue(numArray);
                if (!IsEqual(obj3, obj4, elementType, syncTargetLevel))
                {
                    return false;
                }
            }
        }
        return true;
    }

    public static bool IsEqual(object obj1, object obj2, System.Type type, byte syncTargetLevel)
    {
        MethodInfo info;
        if ((obj1 == null) && (obj2 == null))
        {
            return true;
        }
        if ((obj1 == null) || (obj2 == null))
        {
            return false;
        }
        bool flag = false;
        if (type.IsPrimitive || type.IsEnum)
        {
            return object.Equals(obj1, obj2);
        }
        if (type == typeof(string))
        {
            return object.Equals(obj1, obj2);
        }
        if (type == typeof(Vector3))
        {
            return object.Equals(obj1, obj2);
        }
        if (type == typeof(Quaternion))
        {
            return object.Equals(obj1, obj2);
        }
        if (type.IsArray)
        {
            return IsArrayEqual((Array) obj1, (Array) obj2, syncTargetLevel);
        }
        if (SparseArray.Contains<System.Type>(type.GetInterfaces(), typeof(IDictionary)))
        {
            return true;
        }
        if (SparseArray.Contains<System.Type>(type.GetInterfaces(), typeof(IEnumerable)))
        {
            return true;
        }
        if (equalities == null)
        {
            equalities = new Dictionary<System.Type, MethodInfo>();
        }
        bool flag2 = IsIDataCopyable(type);
        equalities.TryGetValue(type, out info);
        if (info == null)
        {
            if (flag2)
            {
                if (dataEqualsTypeArray == null)
                {
                    dataEqualsTypeArray = new System.Type[2];
                }
                dataEqualsTypeArray[0] = type;
                dataEqualsTypeArray[1] = typeof(byte);
                info = type.GetMethod("DataEquals", BindingFlags.Public | BindingFlags.Instance, null, dataEqualsTypeArray, null);
                if (info == null)
                {
                    GLog.LogWarning(new object[] { "Attempting to delta serialize an object which does not implement IDataCopyable<>: " + type.Name + ".  Reverting to default Equals." });
                }
                if (info != null)
                {
                    equalities.Add(type, info);
                }
            }
            else
            {
                if (equalsTypeArray == null)
                {
                    equalsTypeArray = new System.Type[1];
                }
                equalsTypeArray[0] = typeof(object);
                info = type.GetMethod("Equals", BindingFlags.Public | BindingFlags.Instance, null, equalsTypeArray, null);
                if (info == null)
                {
                    GLog.LogWarning(new object[] { "Attempting to delta serialize an object which does not implement IDataCopyable<>: " + type.Name + ".  Reverting to default Equals." });
                }
                if (info != null)
                {
                    equalities.Add(type, info);
                }
            }
        }
        if (info != null)
        {
            TargetInvocationException exception;
            if (flag2)
            {
                if (deltaEqualsObjArray == null)
                {
                    deltaEqualsObjArray = new object[2];
                }
                deltaEqualsObjArray[0] = obj2;
                deltaEqualsObjArray[1] = syncTargetLevel;
                try
                {
                    flag = (bool) info.Invoke(obj1, deltaEqualsObjArray);
                }
                catch (TargetInvocationException exception1)
                {
                    exception = exception1;
                    GLog.LogException(exception.InnerException, null);
                }
                return flag;
            }
            if (equalsObjArray == null)
            {
                equalsObjArray = new object[1];
            }
            equalsObjArray[0] = obj2;
            try
            {
                flag = (bool) info.Invoke(obj1, equalsObjArray);
            }
            catch (TargetInvocationException exception2)
            {
                exception = exception2;
                GLog.LogException(exception.InnerException, null);
            }
        }
        return flag;
    }

    public static bool IsIDataCopyable(System.Type type)
    {
        System.Type[] interfaces = type.GetInterfaces();
        for (int i = 0; i < interfaces.Length; i++)
        {
            if (interfaces[i].Name.Contains("IDataCopyable"))
            {
                return true;
            }
        }
        return false;
    }

    public static bool IsValidIndex(Array array, int[] index)
    {
        for (int i = 0; i < index.Length; i++)
        {
            if ((array.GetType().GetArrayRank() < i) || (index[i] >= array.GetLength(i)))
            {
                return false;
            }
        }
        return true;
    }

    public static int[] NextIndex(Array array, int[] index)
    {
        for (int i = index.Length - 1; i >= 0; i--)
        {
            index[i]++;
            if (index[i] <= array.GetUpperBound(i))
            {
                return index;
            }
            index[i] = array.GetLowerBound(i);
        }
        return null;
    }

    private static byte[] ProcessType(FieldInfo field, System.Type type, byte defaultLevel)
    {
        if (types == null)
        {
            types = new Dictionary<System.Type, FieldInfo[][]>();
        }
        List<byte> list = new List<byte>();
        if (types.ContainsKey(type) && (types[type] == null))
        {
            types.Remove(type);
            throw new NotSupportedException(string.Concat(new object[] { "The type [", field.FieldType, "] for field [", field.Name, "] is circularly nested without declaring the innermost as [DataRestrict]" }));
        }
        byte num = GetDefaultLevel(type);
        if (num == 0)
        {
            num = defaultLevel;
        }
        if (!types.ContainsKey(type))
        {
            types[type] = null;
            Dictionary<byte, List<FieldInfo>> dictionary = new Dictionary<byte, List<FieldInfo>>();
            if (!Attribute.IsDefined(type, typeof(DataRestrict)))
            {
                FieldInfo[] fields = type.GetFields(BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance);
                for (int i = 0; i < fields.Length; i++)
                {
                    List<byte> list2 = new List<byte>();
                    if (!Attribute.IsDefined(fields[i], typeof(DataRestrict)))
                    {
                        if (Attribute.IsDefined(fields[i], typeof(DataSyncTo)))
                        {
                            DataSyncTo customAttribute = (DataSyncTo) Attribute.GetCustomAttribute(fields[i], typeof(DataSyncTo));
                            if (customAttribute.TargetLevel < num)
                            {
                                throw new NotSupportedException(string.Concat(new object[] { "You are not allowed to define a lower DataSyncTo level in a nested class: ", type, "(", num, ")-> ", fields[i].Name, "(", customAttribute.TargetLevel, ")" }));
                            }
                            list2.Add(customAttribute.TargetLevel);
                        }
                        else
                        {
                            list2.Add(0);
                        }
                        System.Type fieldType = fields[i].FieldType;
                        while (fieldType.IsArray)
                        {
                            fieldType = fieldType.GetElementType();
                        }
                        if (!((BitBuffer.IsContainedType(fieldType) || fieldType.IsEnum) || SparseArray.Contains<System.Type>(type.GetInterfaces(), typeof(IEnumerable))))
                        {
                            list2.AddRange(ProcessType(fields[i], fieldType, num));
                        }
                        for (int j = 0; j < list2.Count; j++)
                        {
                            if (!list.Contains(list2[j]))
                            {
                                list.Add(list2[j]);
                            }
                            if (!dictionary.ContainsKey(list2[j]))
                            {
                                dictionary[list2[j]] = new List<FieldInfo>();
                            }
                            dictionary[list2[j]].Add(fields[i]);
                        }
                    }
                }
            }
            byte num4 = 0;
            if (dictionary.Keys.Any<byte>())
            {
                num4 = (byte) (GMath.Max(dictionary.Keys) + 1);
            }
            if (syncLevels == null)
            {
                syncLevels = new Dictionary<System.Type, byte>();
            }
            syncLevels.Add(type, num4);
            types[type] = new FieldInfo[num4][];
            foreach (KeyValuePair<byte, List<FieldInfo>> pair in dictionary)
            {
                pair.Value.Sort((Comparison<FieldInfo>) ((x, y) => string.CompareOrdinal(x.Name, y.Name)));
                types[type][pair.Key] = pair.Value.ToArray();
            }
        }
        else
        {
            for (byte k = num; k < types[type].Length; k = (byte) (k + 1))
            {
                list.Add(k);
            }
        }
        list.Sort();
        list.Remove(0);
        return list.ToArray();
    }
}

