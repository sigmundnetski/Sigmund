﻿using System;
using System.Collections.Generic;

[LooseDependency(typeof(CombatData))]
public class KeywordData : DataClass
{
    public static Dictionary<int, KeywordData> armorKeywords = new Dictionary<int, KeywordData>();
    public int damage;
    public string displayName;
    public GearType gear;
    public static Dictionary<int, KeywordData> gearKeywords = new Dictionary<int, KeywordData>();
    public static Dictionary<int, KeywordData> implementKeywords = new Dictionary<int, KeywordData>();
    public string keyword;
    public KeywordType type;
    public static Dictionary<int, KeywordData> weaponKeywords = new Dictionary<int, KeywordData>();

    public KeywordData()
    {
        this.keyword = string.Empty;
        this.type = KeywordType.BASIC;
        this.gear = GearType.WEAPON;
    }

    public KeywordData(string keyword_, KeywordType type_, GearType gear_) : base(DataClass.GenerateNameLower(new object[] { keyword_, gear_ }))
    {
        this.keyword = keyword_.ToLower();
        this.displayName = keyword_;
        this.type = type_;
        this.gear = gear_;
        this.damage = GetDamage(this.type);
    }

    public static KeywordData Get(GearType gear, int keywordId)
    {
        if (gear == GearType.WEAPON)
        {
            return weaponKeywords[keywordId];
        }
        if (gear == GearType.IMPLEMENT)
        {
            return implementKeywords[keywordId];
        }
        if (gear == GearType.GEAR)
        {
            return gearKeywords[keywordId];
        }
        return null;
    }

    public static int GetDamage(KeywordType type)
    {
        switch (type)
        {
            case KeywordType.BASIC:
                return CombatData.singleton.keywordDamageBasic;

            case KeywordType.ADVANCED:
                return CombatData.singleton.keywordDamageAdvanced;

            case KeywordType.EXPENDABLE:
                return CombatData.singleton.keywordDamageExpendable;

            case KeywordType.SOCIAL:
                return CombatData.singleton.keywordDamageSocial;
        }
        return 0;
    }

    public static int GetDamage(GearType gear, int keywordId)
    {
        if (gear == GearType.WEAPON)
        {
            return weaponKeywords[keywordId].damage;
        }
        if (gear == GearType.IMPLEMENT)
        {
            return implementKeywords[keywordId].damage;
        }
        if (gear == GearType.GEAR)
        {
            return gearKeywords[keywordId].damage;
        }
        return 0;
    }

    public static int GetId(string keyword, GearType gear)
    {
        int key = DataClass.GenerateId(DataClass.GenerateNameLower(new object[] { keyword, gear }));
        if ((gear == GearType.ARMOR) && armorKeywords.ContainsKey(key))
        {
            return key;
        }
        if ((gear == GearType.WEAPON) && weaponKeywords.ContainsKey(key))
        {
            return key;
        }
        if ((gear == GearType.IMPLEMENT) && implementKeywords.ContainsKey(key))
        {
            return key;
        }
        if ((gear == GearType.GEAR) && gearKeywords.ContainsKey(key))
        {
            return key;
        }
        DataClass.OutputErrorMessage(string.Concat(new object[] { "Keyword '", keyword, "' does not exist for type '", gear, "'" }));
        return 0;
    }

    public static KeywordType GetType(GearType gear, int keywordId)
    {
        if (gear == GearType.WEAPON)
        {
            return weaponKeywords[keywordId].type;
        }
        if (gear == GearType.ARMOR)
        {
            return armorKeywords[keywordId].type;
        }
        if (gear == GearType.IMPLEMENT)
        {
            return implementKeywords[keywordId].type;
        }
        if (gear == GearType.GEAR)
        {
            return gearKeywords[keywordId].type;
        }
        return KeywordType.SOCIAL;
    }

    public static void OnLoad(List<DataClass> objects)
    {
        weaponKeywords.Clear();
        armorKeywords.Clear();
        implementKeywords.Clear();
        gearKeywords.Clear();
        foreach (KeywordData data in objects)
        {
            if (data.gear == GearType.WEAPON)
            {
                weaponKeywords[data.id] = data;
            }
            else if (data.gear == GearType.ARMOR)
            {
                armorKeywords[data.id] = data;
            }
            else if (data.gear == GearType.IMPLEMENT)
            {
                implementKeywords[data.id] = data;
            }
            else if (data.gear == GearType.GEAR)
            {
                gearKeywords[data.id] = data;
            }
        }
    }

    public override DataClass ParseRecord(int index)
    {
        string str;
        string str2;
        KeywordData data = new KeywordData();
        if (!DataClass.TryGetCellValue("A", index, out data.displayName))
        {
            return null;
        }
        data.keyword = data.displayName.ToLower();
        DataClass.GetCellValue("B", index, out str);
        string str3 = str.ToLower();
        if (str3 != null)
        {
            if (!(str3 == "advanced"))
            {
                if (str3 == "basic")
                {
                    data.type = KeywordType.BASIC;
                    goto Label_00CC;
                }
                if (str3 == "social")
                {
                    data.type = KeywordType.SOCIAL;
                    goto Label_00CC;
                }
                if (str3 == "expendable")
                {
                    data.type = KeywordType.EXPENDABLE;
                    goto Label_00CC;
                }
            }
            else
            {
                data.type = KeywordType.ADVANCED;
                goto Label_00CC;
            }
        }
        DataClass.OutputErrorMessage("B", index, "\n    ERROR: Unknown keyword value: " + str + "\n      Expected: 'Basic', 'Advanced', 'Expendable', or 'Social'.");
    Label_00CC:
        data.damage = GetDamage(data.type);
        DataClass.GetCellValue("C", index, out str2);
        str3 = str2.ToLower();
        if (str3 != null)
        {
            if (!(str3 == "weapon"))
            {
                if (str3 == "armor")
                {
                    data.gear = GearType.ARMOR;
                    goto Label_0173;
                }
                if (str3 == "implement")
                {
                    data.gear = GearType.IMPLEMENT;
                    goto Label_0173;
                }
                if (str3 == "gear")
                {
                    data.gear = GearType.GEAR;
                    goto Label_0173;
                }
            }
            else
            {
                data.gear = GearType.WEAPON;
                goto Label_0173;
            }
        }
        DataClass.OutputErrorMessage("C", index, "\n    ERROR: Unknown keyword gear: " + str2 + "\n      Expected: 'Weapon', 'Armor', 'Implement', or 'Gear'.\n");
    Label_0173:;
        data.name = DataClass.GenerateNameLower(new object[] { data.keyword, data.gear });
        return data;
    }

    public enum GearType : byte
    {
        ARMOR = 1,
        GEAR = 3,
        IMPLEMENT = 2,
        WEAPON = 0
    }

    public enum KeywordType : byte
    {
        ADVANCED = 1,
        BASIC = 0,
        EXPENDABLE = 2,
        SOCIAL = 3
    }
}

