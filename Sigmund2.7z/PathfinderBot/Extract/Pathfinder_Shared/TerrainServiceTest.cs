﻿using System;
using System.Runtime.InteropServices;
using UnityEngine;

internal class TerrainServiceTest : UUnitTestCase
{
    private readonly IntVec2 NORTH_COORD = new IntVec2(-10, -2);
    private readonly ushort NORTH_MAPID;
    private readonly Vector3 NORTH_VECTOR;
    private readonly Vector3 NORTH_WEST_VECTOR;
    private readonly IntVec2 SOUTH_COORD = new IntVec2(-10, -1);
    private readonly ushort SOUTH_MAPID;
    private readonly Vector3 SOUTH_VECTOR;
    private readonly Vector3 SOUTH_WEST_VECTOR;

    public TerrainServiceTest()
    {
        this.NORTH_MAPID = TerrainUtils.GetMapIdFromHex(this.NORTH_COORD);
        this.SOUTH_MAPID = TerrainUtils.GetMapIdFromHex(this.SOUTH_COORD);
        this.NORTH_VECTOR = GetOffset(HexAdjacentDirection.N);
        this.SOUTH_VECTOR = GetOffset(HexAdjacentDirection.S);
        this.NORTH_WEST_VECTOR = GetOffset(HexAdjacentDirection.NW);
        this.SOUTH_WEST_VECTOR = GetOffset(HexAdjacentDirection.SW);
    }

    public static Vector3 GetOffset(HexAdjacentDirection direction)
    {
        float x = TerrainConsts.neighborPositionOffsetsX[(int) direction];
        return new Vector3(x, 0f, TerrainConsts.neighborPositionOffsetsZ[(int) direction]);
    }

    protected override void SetUp()
    {
        TerrainService.UnitTest_InUse = true;
    }

    protected override void TearDown()
    {
        TerrainService.UnitTest_InUse = false;
        TerrainService.ResetService();
    }

    [UUnitSystemTestMethod]
    private void Test_TranslateLocalToServer_WithMapTransfer()
    {
        TerrainService.LoadHex(this.NORTH_MAPID, false);
        Vector3 zero = Vector3.zero;
        Vector3 wanted = zero;
        Vector3 got = TerrainService.TranslateLocalToServer(this.NORTH_MAPID, zero);
        VectorEquals(wanted, got, 1.0, "Expected equivalent inputs:\n\"{0}\" != \"{1}\"");
        zero = Vector3.zero;
        wanted = zero + this.NORTH_VECTOR;
        got = TerrainService.TranslateLocalToServer(this.SOUTH_MAPID, zero);
        VectorEquals(wanted, got, 1.0, "Expected equivalent inputs:\n\"{0}\" != \"{1}\"");
        TerrainService.OnMapTransfer(this.SOUTH_MAPID);
        zero = Vector3.zero;
        wanted = zero;
        got = TerrainService.TranslateLocalToServer(this.NORTH_MAPID, zero);
        VectorEquals(wanted, got, 1.0, "Expected equivalent inputs:\n\"{0}\" != \"{1}\"");
        zero = Vector3.zero;
        wanted = zero + this.NORTH_VECTOR;
        got = TerrainService.TranslateLocalToServer(this.SOUTH_MAPID, zero);
        VectorEquals(wanted, got, 1.0, "Expected equivalent inputs:\n\"{0}\" != \"{1}\"");
    }

    [UUnitSystemTestMethod]
    private void Test_TranslateServerToLocal_WithMapTransfer()
    {
        TerrainService.LoadHex(this.NORTH_MAPID, false);
        Vector3 zero = Vector3.zero;
        Vector3 wanted = zero;
        Vector3 got = TerrainService.TranslateServerToLocal(this.NORTH_MAPID, zero);
        VectorEquals(wanted, got, 1.0, "Expected equivalent inputs:\n\"{0}\" != \"{1}\"");
        zero = Vector3.zero;
        wanted = zero + this.SOUTH_VECTOR;
        got = TerrainService.TranslateServerToLocal(this.SOUTH_MAPID, zero);
        VectorEquals(wanted, got, 1.0, "Expected equivalent inputs:\n\"{0}\" != \"{1}\"");
        TerrainService.OnMapTransfer(this.SOUTH_MAPID);
        zero = Vector3.zero;
        wanted = zero;
        got = TerrainService.TranslateServerToLocal(this.NORTH_MAPID, zero);
        VectorEquals(wanted, got, 1.0, "Expected equivalent inputs:\n\"{0}\" != \"{1}\"");
        zero = Vector3.zero;
        wanted = zero + this.SOUTH_VECTOR;
        got = TerrainService.TranslateServerToLocal(this.SOUTH_MAPID, zero);
        VectorEquals(wanted, got, 1.0, "Expected equivalent inputs:\n\"{0}\" != \"{1}\"");
    }

    public static void VectorEquals(Vector3 wanted, Vector3 got, double precision = 0.1, string message = "Expected equivalent inputs:\n\"{0}\" != \"{1}\"")
    {
        if (Vector3.Magnitude(wanted - got) > precision)
        {
            if ((message.IndexOf("{0}") != -1) && (message.IndexOf("{1}") != -1))
            {
                message = string.Format(message, wanted, got);
            }
            throw new UUnitAssertException(message);
        }
    }
}

