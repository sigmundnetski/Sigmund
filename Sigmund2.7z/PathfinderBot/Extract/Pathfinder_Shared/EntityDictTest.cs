﻿using System;

internal class EntityDictTest : UUnitTestCase
{
    [UUnitTestMethod]
    private void TestEntityDictInterface()
    {
        bool flag;
        EntityCore.MAP_ID = TerrainUtils.GetMapIdFromHex(new IntVec2(-9, -2));
        Entity key = EntityCore.RequestNewEntity();
        key.Initialize();
        EntityDict<bool> dict = new EntityDict<bool>();
        UUnitAssert.False(dict.ContainsKey(key), "Fail");
        dict[key] = true;
        UUnitAssert.True(dict.ContainsKey(key), "Fail");
        UUnitAssert.True(dict[key], "Fail");
        UUnitAssert.True(dict.TryGetValue(key, out flag) && flag, "Fail");
        UUnitAssert.True(dict.Remove(key), "Fail");
        UUnitAssert.False(dict.ContainsKey(key), "Fail");
        UUnitAssert.False(dict.ContainsKey(key.entityId), "Fail");
        dict[key.entityId] = true;
        UUnitAssert.True(dict.ContainsKey(key.entityId), "Fail");
        UUnitAssert.True(dict[key.entityId], "Fail");
        UUnitAssert.True(dict.TryGetValue(key.entityId, out flag) && flag, "Fail");
        UUnitAssert.True(dict.Remove(key.entityId), "Fail");
        UUnitAssert.False(dict.ContainsKey(key.entityId), "Fail");
        ForeignEntityId foreignId = EntityCore.GetForeignId(key.entityId);
        UUnitAssert.False(dict.ContainsKey(foreignId), "Fail");
        dict[foreignId] = true;
        UUnitAssert.True(dict.ContainsKey(foreignId), "Fail");
        UUnitAssert.True(dict[foreignId], "Fail");
        UUnitAssert.True(dict.TryGetValue(foreignId, out flag) && flag, "Fail");
        UUnitAssert.True(dict.Remove(foreignId), "Fail");
        UUnitAssert.False(dict.ContainsKey(foreignId), "Fail");
    }
}

