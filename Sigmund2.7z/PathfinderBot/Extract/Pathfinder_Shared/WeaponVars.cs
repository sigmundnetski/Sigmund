﻿using GNetwork;
using System;
using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Sequential)]
public struct WeaponVars : IDataCopyable<WeaponVars>, CustomSerializer<WeaponVars>
{
    public static Predicate<WeaponVars> EMPTY_MATCH;
    public static WeaponVars EMPTY;
    public readonly int id;
    public readonly byte upgrade;
    public readonly uint weaponSet;
    public readonly int handIndex;
    public WeaponVars(int id_, byte upgrade_, uint weaponSet_, int handIndex_)
    {
        this.id = id_;
        this.upgrade = upgrade_;
        this.weaponSet = weaponSet_;
        this.handIndex = handIndex_;
    }

    public void DataCopyTo(ref WeaponVars target, byte syncTargetLevel)
    {
        target = this;
    }

    public bool DataEquals(WeaponVars target, byte syncTargetLevel)
    {
        return ((((target.id == this.id) && (target.upgrade == this.upgrade)) && (target.weaponSet == this.weaponSet)) && (target.handIndex == this.handIndex));
    }

    public void Write(IBitBufferWrite buffer, WeaponVars prev)
    {
        buffer.PushInt(this.id);
        buffer.PushByte(this.upgrade);
        buffer.PushUInt(this.weaponSet);
        buffer.PushInt(this.handIndex);
    }

    public void Read(IBitBufferRead buffer, ref WeaponVars prev)
    {
        prev = new WeaponVars(buffer.PopInt(), buffer.PopByte(), buffer.PopUInt(), buffer.PopInt());
    }

    static WeaponVars()
    {
        EMPTY_MATCH = each => each.id == 0;
        EMPTY = new WeaponVars(0, 0, 0, 0);
    }
}

