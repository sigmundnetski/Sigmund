﻿using System;

public class PhysiqueRecord : IDataCopyable<PhysiqueRecord>
{
    public int bodyAssetVariant;
    public int eyeColorId;
    public int faceAssetVariant;
    public byte gender;
    public int hairAssetVariant;
    public int hairColorId;
    public int raceId;
    public int skinColorId;
    public int suitColorId;

    public PhysiqueRecord()
    {
        this.raceId = 0;
        this.gender = 0;
        this.bodyAssetVariant = -1;
        this.faceAssetVariant = -1;
        this.hairAssetVariant = -1;
        this.skinColorId = 0;
        this.hairColorId = 0;
        this.eyeColorId = 0;
        this.suitColorId = 0;
        this.raceId = 0;
        this.gender = 0;
        this.bodyAssetVariant = -1;
        this.faceAssetVariant = -1;
        this.hairAssetVariant = -1;
        this.skinColorId = 0;
        this.hairColorId = 0;
        this.eyeColorId = 0;
        this.suitColorId = 0;
    }

    public PhysiqueRecord(EntityDefnData data)
    {
        this.raceId = 0;
        this.gender = 0;
        this.bodyAssetVariant = -1;
        this.faceAssetVariant = -1;
        this.hairAssetVariant = -1;
        this.skinColorId = 0;
        this.hairColorId = 0;
        this.eyeColorId = 0;
        this.suitColorId = 0;
        RaceData data2 = null;
        if (RaceData.raceById.TryGetValue(data.raceId, out data2))
        {
            int num;
            this.raceId = data.raceId;
            this.gender = data.gender;
            if (data.skinColorId != 0)
            {
                this.skinColorId = data.skinColorId;
            }
            else if ((data2.skinColorIds != null) && (data2.skinColorIds.Length > 0))
            {
                num = GUtil.rng.Generate(0, data2.skinColorIds.Length);
                this.skinColorId = data2.skinColorIds[num];
            }
            if (data.hairColorId != 0)
            {
                this.hairColorId = data.hairColorId;
            }
            else if ((data2.hairColorIds != null) && (data2.hairColorIds.Length > 0))
            {
                num = GUtil.rng.Generate(0, data2.hairColorIds.Length);
                this.hairColorId = data2.hairColorIds[num];
            }
            if (data.eyeColorId != 0)
            {
                this.eyeColorId = data.eyeColorId;
            }
            else if ((data2.eyeColorIds != null) && (data2.eyeColorIds.Length > 0))
            {
                num = GUtil.rng.Generate(0, data2.eyeColorIds.Length);
                this.eyeColorId = data2.eyeColorIds[num];
            }
            if (data.suitColorId != 0)
            {
                this.suitColorId = data.suitColorId;
            }
            else if ((data2.suitColorIds != null) && (data2.suitColorIds.Length > 0))
            {
                num = GUtil.rng.Generate(0, data2.suitColorIds.Length);
                this.suitColorId = data2.suitColorIds[num];
            }
        }
    }

    public PhysiqueRecord(int raceId_, byte gender_, int bodyAssetVariant_, int faceAssetVariant_, int hairAssetVariant_, int skinColorId_, int hairColorId_, int eyeColorId_)
    {
        this.raceId = 0;
        this.gender = 0;
        this.bodyAssetVariant = -1;
        this.faceAssetVariant = -1;
        this.hairAssetVariant = -1;
        this.skinColorId = 0;
        this.hairColorId = 0;
        this.eyeColorId = 0;
        this.suitColorId = 0;
        this.raceId = raceId_;
        this.gender = gender_;
        this.bodyAssetVariant = bodyAssetVariant_;
        this.faceAssetVariant = faceAssetVariant_;
        this.hairAssetVariant = hairAssetVariant_;
        this.skinColorId = skinColorId_;
        this.hairColorId = hairColorId_;
        this.eyeColorId = eyeColorId_;
    }

    public void DataCopyTo(ref PhysiqueRecord target, byte syncTargetLevel)
    {
        target.raceId = this.raceId;
        target.gender = this.gender;
        target.bodyAssetVariant = this.bodyAssetVariant;
        target.faceAssetVariant = this.faceAssetVariant;
        target.hairAssetVariant = this.hairAssetVariant;
        target.skinColorId = this.skinColorId;
        target.hairColorId = this.hairColorId;
        target.eyeColorId = this.eyeColorId;
        target.suitColorId = this.suitColorId;
    }

    public bool DataEquals(PhysiqueRecord target, byte syncTargetLevel)
    {
        if (object.ReferenceEquals(this, target))
        {
            return true;
        }
        if (object.ReferenceEquals(target, null))
        {
            return false;
        }
        return (((((target.raceId == this.raceId) && (target.gender == this.gender)) && ((target.bodyAssetVariant == this.bodyAssetVariant) && (target.faceAssetVariant == this.faceAssetVariant))) && (((target.hairAssetVariant == this.hairAssetVariant) && (target.skinColorId == this.skinColorId)) && ((target.hairColorId == this.hairColorId) && (target.eyeColorId == this.eyeColorId)))) && (target.suitColorId == this.suitColorId));
    }
}

