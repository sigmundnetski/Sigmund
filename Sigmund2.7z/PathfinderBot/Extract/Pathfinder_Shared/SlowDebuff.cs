﻿using System;

public class SlowDebuff : CombatTimedBuff
{
    private const string FREEDOM_MOD = "Freedom +10 to Self";
    private static CombatModifier[] freedomCombatMod = CombatModifier.Parse("Freedom +10 to Self");
    private const float PERCENT_TO_STACKS = 20f;

    public SlowDebuff() : base("Slow", Combat.Channel.Torment, Combat.EffectType.Detrimental)
    {
    }

    public static SlowDebuff Create()
    {
        return new SlowDebuff();
    }

    public override CombatBuffVars Initialize(uint combatTick, CombatModifier mod, CombatVars target, int additionalDefense)
    {
        CombatBuffVars stack = CombatBuff.GetStack(target, CombatConstants.Stack.FREEDOM);
        int stacks = 0;
        if (stack != null)
        {
            stacks = stack.stacks;
        }
        CombatBuffVars vars2 = base.Initialize(combatTick, mod, target, stacks);
        vars2.value0 = (int) (-mod.percentage * 100f);
        vars2.name = vars2.name + " " + mod.percentage.ToString("P0");
        return vars2;
    }

    public override void RecalculationPhase(CombatBuffVars buff, uint combatTick)
    {
        if (buff.value0 < buff.owner.tempSpeedPercent[(int) base.channel])
        {
            buff.owner.tempSpeedPercent[(int) base.channel] = buff.value0;
        }
    }

    public override void UpdateBuff(CombatBuffVars buff, uint combatTick, CombatModifier mod, CombatEffect effect)
    {
        uint expirationTick = buff.expirationTick;
        base.UpdateBuff(buff, combatTick, mod, effect);
        if (buff.expirationTick > expirationTick)
        {
            uint num2 = (uint) CombatCore.RoundToInt((((float) -buff.value0) / 100f) * 20f);
            freedomCombatMod[0].stackAmount = num2;
            CombatEffect item = new CombatEffect(freedomCombatMod, buff.owner, buff.owner, CombatEffect.TargetType.ATTACKER, Combat.EffectType.Neutral);
            buff.owner.combatEffects.Enqueue(item);
        }
    }
}

