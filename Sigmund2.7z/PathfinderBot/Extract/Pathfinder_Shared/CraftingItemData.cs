﻿using System;
using System.Collections.Generic;
using System.Linq;

[StrongDependency(typeof(ItemCategoryData)), NoFinalOutput, StrongDependency(typeof(StockData))]
public class CraftingItemData : BasicItemData
{
    private static readonly string[] _mandatoryColumns = new string[] { "item name", "material", "tier", "quality", "encumbrance", "display name", "code name", "icon file name", "description", "category" };
    public static CraftingItemData[] allCraftingItems;
    public static Dictionary<int, int[]> itemIdsByStockId = new Dictionary<int, int[]>();
    public int itemNameId;
    public CraftingMaterial material;
    public byte minFeatRank = 0;
    public static Dictionary<int, CraftingItemData[]> rawMaterialsByNameId = new Dictionary<int, CraftingItemData[]>();
    public int[] stockIds;
    public CraftingVariety variety;
    public static readonly string[] varietyDisplayName = new string[] { "Invalid", "Chemical", "Herb", "Mineral", "Cloth", "Essence", "Gem", "Leather", "Metal", "Wood" };

    private static void CheckResource(CraftingItemData[] items)
    {
        bool flag = true;
        bool flag2 = true;
        bool flag3 = true;
        bool flag4 = true;
        for (int i = 1; i < items.Length; i++)
        {
            flag &= items[0].minFeatRank == items[i].minFeatRank;
            flag2 &= items[0].variety == items[i].variety;
            flag3 &= items[0].material == items[i].material;
            flag4 &= items[0].stockIds.SequenceEqual<int>(items[i].stockIds);
        }
        if (!flag)
        {
            GLog.LogWarning(new object[] { "Resources must all have the same Min Gather Rank:", items[0].displayName, from each in items select each.minFeatRank });
        }
        if (!flag2)
        {
            GLog.LogWarning(new object[] { "Resources must all have the same Variety:", items[0].displayName, from each in items select each.variety });
        }
        if (!flag3)
        {
            GLog.LogWarning(new object[] { "Resources must all have the same Material:", items[0].displayName, from each in items select each.material });
        }
        if (!flag4)
        {
            GLog.LogWarning(new object[] { "Resources must all have the same Stocks:", items[0].displayName });
        }
    }

    public static void ConstructCommonUnittestData()
    {
        List<CraftingItemData> list = new List<CraftingItemData> {
            UnittestConstructor("Copper", 1, 8, 0),
            UnittestConstructor("Silver", 1, 8, 8),
            UnittestConstructor("Gold", 1, 8, 14),
            UnittestConstructor("Dandelion", 1, 2, 0),
            UnittestConstructor("Rose", 1, 2, 8),
            UnittestConstructor("Shrubbery", 1, 2, 14),
            UnittestConstructor("Mud", 1, 3, 0),
            UnittestConstructor("Acid", 1, 3, 8),
            UnittestConstructor("Water", 1, 3, 14),
            UnittestConstructor("Glass", 1, 6, 0),
            UnittestConstructor("Garnet", 1, 6, 8),
            UnittestConstructor("Diamond", 1, 6, 14),
            UnittestConstructor("Glow", 1, 5, 0),
            UnittestConstructor("Flicker", 1, 5, 8),
            UnittestConstructor("Spark", 1, 5, 14),
            UnittestConstructor("Stick", 1, 9, 0),
            UnittestConstructor("Switch", 1, 9, 8),
            UnittestConstructor("Log", 1, 9, 14)
        };
        foreach (CraftingItemData data in list)
        {
            ItemDatabase.Index(data);
        }
        IndexCraftingMaterials(list.ToArray());
    }

    internal static void IndexCraftingMaterials(CraftingItemData[] setItems)
    {
        allCraftingItems = setItems;
        HashSet<int> set = new HashSet<int>();
        set.UnionWith(from each in setItems
            where each.material == CraftingMaterial.RAW
            select each.itemNameId);
        using (HashSet<int>.Enumerator enumerator = set.GetEnumerator())
        {
            while (enumerator.MoveNext())
            {
                Func<CraftingItemData, bool> func = null;
                int eachItemNameId = enumerator.Current;
                if (func == null)
                {
                    func = each => each.itemNameId == eachItemNameId;
                }
                rawMaterialsByNameId[eachItemNameId] = (from each in Enumerable.Where<CraftingItemData>(setItems, func)
                    orderby each.baseQuality
                    select each).ToArray<CraftingItemData>();
                CheckResource(rawMaterialsByNameId[eachItemNameId]);
            }
        }
    }

    public static void IndexStocks()
    {
        using (Dictionary<int, StockData>.Enumerator enumerator = StockData.stocksById.GetEnumerator())
        {
            while (enumerator.MoveNext())
            {
                KeyValuePair<int, StockData> eachStockPair = enumerator.Current;
                itemIdsByStockId[eachStockPair.Key] = (from each in allCraftingItems
                    where -1 != SparseArray.IndexOf<int>(each.stockIds, x => x == eachStockPair.Key)
                    select each.id).ToArray<int>();
            }
        }
    }

    public override DataClass ParseRecord(int rowIndex)
    {
        string str;
        int num;
        DataClass.GetLCaseCellValue(DataClass.columnNamesToIndex["item name"], rowIndex, out str);
        if (string.IsNullOrEmpty(str))
        {
            return null;
        }
        CraftingItemData data = new CraftingItemData {
            slot = BasicItemData.ItemSlot.NONE,
            itemNameId = DataClass.GenerateId(str)
        };
        DataClass.GetEnumCellValue<CraftingMaterial>(DataClass.columnNamesToIndex["material"], rowIndex, CraftingMaterial.INVALID, out data.material);
        DataClass.GetEnumCellValue<CraftingVariety>(DataClass.columnNamesToIndex["variety"], rowIndex, CraftingVariety.INVALID, out data.variety);
        DataClass.GetCellValue(DataClass.columnNamesToIndex["tier"], rowIndex, out data.tier);
        DataClass.GetCellValue(DataClass.columnNamesToIndex["quality"], rowIndex, out data.baseQuality);
        DataClass.GetCellValue(DataClass.columnNamesToIndex["description"], rowIndex, out data.description);
        DataClass.GetCellValue(DataClass.columnNamesToIndex["encumbrance"], rowIndex, out data.encumbrance);
        DataClass.GetCellValue(DataClass.columnNamesToIndex["display name"], rowIndex, out data.displayName);
        DataClass.TryGetIdFromForeignName<ItemCategoryData>(DataClass.columnNamesToIndex["category"], rowIndex, out data.categoryId);
        if (DataClass.columnNamesToIndex.ContainsKey("min gather rank"))
        {
            DataClass.GetCellValue(DataClass.columnNamesToIndex["min gather rank"], rowIndex, out data.minFeatRank);
        }
        List<int> list = new List<int>();
        if (DataClass.columnNamesToIndex.ContainsKey("stock 1") && DataClass.TryGetIdFromForeignName<StockData>(DataClass.columnNamesToIndex["stock 1"], rowIndex, out num))
        {
            list.Add(num);
        }
        if (DataClass.columnNamesToIndex.ContainsKey("stock 2") && DataClass.TryGetIdFromForeignName<StockData>(DataClass.columnNamesToIndex["stock 2"], rowIndex, out num))
        {
            list.Add(num);
        }
        data.stockIds = list.ToArray();
        DataClass.GetLCaseCellValue(DataClass.columnNamesToIndex["code name"], rowIndex, out data.name);
        DataClass.GetCellValue(DataClass.columnNamesToIndex["icon file name"], rowIndex, out data.icon);
        if (!DataClass.TryGetCellValue(DataClass.columnNamesToIndex["upgradable"], rowIndex, out data.upgradable))
        {
            data.upgradable = true;
        }
        return data;
    }

    private static CraftingItemData UnittestConstructor(string name, CraftingMaterial material, CraftingVariety variety, byte minRank)
    {
        CraftingItemData data;
        return new CraftingItemData { name = name.ToLower(), id = DataClass.GenerateId(data.name), displayName = name, itemNameId = DataClass.GenerateId(data.name), material = material, variety = variety, minFeatRank = minRank };
    }

    protected override IEnumerable<string> GetMandatoryColumns
    {
        get
        {
            return _mandatoryColumns;
        }
    }

    public enum CraftingMaterial : byte
    {
        INVALID = 0,
        RAW = 1,
        RECIPE = 4,
        REFINED = 2,
        SALVAGE = 3
    }

    public enum CraftingVariety : byte
    {
        CHEMICAL = 1,
        CHEMICALHERB = 2,
        CHEMICALMINERAL = 3,
        CLOTH = 4,
        ESSENCE = 5,
        GEM = 6,
        INVALID = 0,
        LEATHER = 7,
        METAL = 8,
        WOOD = 9
    }
}

