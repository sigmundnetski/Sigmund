﻿using System;
using System.Reflection;

public class GetTypeDefinitionTests : UUnitTestCase
{
    private GetTypeDefinition_Top1 t1 = new GetTypeDefinition_Top1();
    private GetTypeDefinition_Top2 t2 = new GetTypeDefinition_Top2();

    [UUnitTestMethod]
    public void GetDefaultLevel()
    {
        FieldInfo field = typeof(GetTypeDefinition_Middle).GetField("bottom");
        UUnitAssert.Equals((int) DataSerializerUtils.GetDefaultLevel(typeof(GetTypeDefinition_Top0).GetField("mid"), typeof(GetTypeDefinition_Top0)), 0, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals((int) DataSerializerUtils.GetDefaultLevel(typeof(GetTypeDefinition_Top1).GetField("mid"), typeof(GetTypeDefinition_Top1)), 1, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals((int) DataSerializerUtils.GetDefaultLevel(typeof(GetTypeDefinition_Top2).GetField("mid"), typeof(GetTypeDefinition_Top2)), 2, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
    }

    [UUnitTestMethod]
    public void GetTypeDefinition()
    {
        FieldInfo field = typeof(GetTypeDefinition_Middle).GetField("bottom");
        byte defaultLevel = DataSerializerUtils.GetDefaultLevel(typeof(GetTypeDefinition_Top0).GetField("mid"), typeof(GetTypeDefinition_Top0));
        UUnitAssert.Equals((int) defaultLevel, 0, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        byte num2 = DataSerializerUtils.GetDefaultLevel(typeof(GetTypeDefinition_Top1).GetField("mid"), typeof(GetTypeDefinition_Top1));
        UUnitAssert.Equals((int) num2, 1, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        byte num3 = DataSerializerUtils.GetDefaultLevel(typeof(GetTypeDefinition_Top2).GetField("mid"), typeof(GetTypeDefinition_Top2));
        UUnitAssert.Equals((int) num3, 2, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        int length = DataSerializerUtils.GetTypeDefinition(field, typeof(GetTypeDefinition_Bottom), defaultLevel, 0).Length;
        UUnitAssert.Equals(1, length, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        int got = DataSerializerUtils.GetTypeDefinition(field, typeof(GetTypeDefinition_Bottom), defaultLevel, 1).Length;
        UUnitAssert.Equals(1, got, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        int num6 = DataSerializerUtils.GetTypeDefinition(field, typeof(GetTypeDefinition_Bottom), defaultLevel, 2).Length;
        UUnitAssert.Equals(1, num6, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        int num7 = DataSerializerUtils.GetTypeDefinition(field, typeof(GetTypeDefinition_Bottom), num2, 0).Length;
        UUnitAssert.Equals(0, num7, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        int num8 = DataSerializerUtils.GetTypeDefinition(field, typeof(GetTypeDefinition_Bottom), num2, 1).Length;
        UUnitAssert.Equals(2, num8, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        int num9 = DataSerializerUtils.GetTypeDefinition(field, typeof(GetTypeDefinition_Bottom), num2, 2).Length;
        UUnitAssert.Equals(1, num9, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        int num10 = DataSerializerUtils.GetTypeDefinition(field, typeof(GetTypeDefinition_Bottom), num3, 0).Length;
        UUnitAssert.Equals(0, num10, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        int num11 = DataSerializerUtils.GetTypeDefinition(field, typeof(GetTypeDefinition_Bottom), num3, 1).Length;
        UUnitAssert.Equals(0, num11, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        int num12 = DataSerializerUtils.GetTypeDefinition(field, typeof(GetTypeDefinition_Bottom), num3, 2).Length;
        UUnitAssert.Equals(2, num12, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
    }

    private class GetTypeDefinition_Bottom
    {
        public int value0 = 10;
        [DataSyncTo(1)]
        public int value1 = 11;
        [DataSyncTo(2)]
        public int value2 = 12;
    }

    private class GetTypeDefinition_Middle
    {
        public GetTypeDefinitionTests.GetTypeDefinition_Bottom bottom = new GetTypeDefinitionTests.GetTypeDefinition_Bottom();
    }

    private class GetTypeDefinition_Top0
    {
        public GetTypeDefinitionTests.GetTypeDefinition_Middle mid = new GetTypeDefinitionTests.GetTypeDefinition_Middle();
    }

    [DataSyncTo(1)]
    private class GetTypeDefinition_Top1
    {
        public GetTypeDefinitionTests.GetTypeDefinition_Middle mid = new GetTypeDefinitionTests.GetTypeDefinition_Middle();
    }

    [DataSyncTo(2)]
    private class GetTypeDefinition_Top2
    {
        public GetTypeDefinitionTests.GetTypeDefinition_Middle mid = new GetTypeDefinitionTests.GetTypeDefinition_Middle();
    }
}

