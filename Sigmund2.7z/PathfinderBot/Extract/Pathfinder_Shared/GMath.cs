﻿using System;
using System.Collections.Generic;

public static class GMath
{
    public static byte Max(IEnumerable<byte> collection)
    {
        byte num = 0;
        foreach (byte num2 in collection)
        {
            if (num2 > num)
            {
                num = num2;
            }
        }
        return num;
    }

    public static short Max(IEnumerable<short> collection)
    {
        short num = -32768;
        foreach (short num2 in collection)
        {
            if (num2 > num)
            {
                num = num2;
            }
        }
        return num;
    }

    public static int Max(IEnumerable<int> collection)
    {
        int num = -2147483648;
        foreach (int num2 in collection)
        {
            if (num2 > num)
            {
                num = num2;
            }
        }
        return num;
    }

    public static ushort Max(IEnumerable<ushort> collection)
    {
        ushort num = 0;
        foreach (ushort num2 in collection)
        {
            if (num2 > num)
            {
                num = num2;
            }
        }
        return num;
    }

    public static uint Max(IEnumerable<uint> collection)
    {
        uint num = 0;
        foreach (uint num2 in collection)
        {
            if (num2 > num)
            {
                num = num2;
            }
        }
        return num;
    }

    public static byte Min(IEnumerable<byte> collection)
    {
        byte num = 0xff;
        foreach (byte num2 in collection)
        {
            if (num2 < num)
            {
                num = num2;
            }
        }
        return num;
    }

    public static short Min(IEnumerable<short> collection)
    {
        short num = 0x7fff;
        foreach (short num2 in collection)
        {
            if (num2 < num)
            {
                num = num2;
            }
        }
        return num;
    }

    public static int Min(IEnumerable<int> collection)
    {
        int num = 0x7fffffff;
        foreach (int num2 in collection)
        {
            if (num2 < num)
            {
                num = num2;
            }
        }
        return num;
    }

    public static ushort Min(IEnumerable<ushort> collection)
    {
        ushort num = 0xffff;
        foreach (ushort num2 in collection)
        {
            if (num2 < num)
            {
                num = num2;
            }
        }
        return num;
    }

    public static uint Min(IEnumerable<uint> collection)
    {
        uint maxValue = uint.MaxValue;
        foreach (uint num2 in collection)
        {
            if (num2 < maxValue)
            {
                maxValue = num2;
            }
        }
        return maxValue;
    }
}

