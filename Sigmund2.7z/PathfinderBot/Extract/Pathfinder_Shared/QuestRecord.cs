﻿using Newtonsoft.Json;
using System;
using System.Runtime.Serialization;

public class QuestRecord : IDataCopyable<QuestRecord>
{
    [DataRestrict, JsonIgnore]
    public object contextObj;
    [JsonIgnore]
    public DateTime endTime;
    [JsonIgnore]
    public int eventId;
    [DataRestrict]
    public int[] i;
    private const int I_RECORD_SIZE = 8;
    [JsonIgnore]
    public int questId;
    [JsonIgnore]
    public EscalationConst.Flow questStatus;
    [JsonIgnore]
    public int stateCounterValue;
    [JsonIgnore]
    public int stateIndex;
    [JsonIgnore]
    public bool timerActive;

    public QuestRecord()
    {
        this.i = new int[8];
        this.contextObj = null;
        this.ClearTimer();
    }

    public QuestRecord(int _eventId, QuestData questData, int _stateIndex, int _stateCounterValue, EscalationConst.Flow _status, DateTime curTime)
    {
        this.i = new int[8];
        this.contextObj = null;
        this.eventId = _eventId;
        this.questId = questData.id;
        this.questStatus = _status;
        this.SetState(questData, _stateIndex, curTime, _status);
        this.stateCounterValue = _stateCounterValue;
    }

    public bool CanAbandon()
    {
        return (QuestData.GetCurrentState(this) != null);
    }

    public void ClearTimer()
    {
        this.timerActive = false;
        this.endTime = DateTime.MinValue;
    }

    public void DataCopyTo(ref QuestRecord target, byte syncTargetLevel)
    {
        if (object.ReferenceEquals(target, null))
        {
            target = new QuestRecord();
        }
        target.eventId = this.eventId;
        target.questId = this.questId;
        target.stateIndex = this.stateIndex;
        target.stateCounterValue = this.stateCounterValue;
        target.questStatus = this.questStatus;
        target.timerActive = this.timerActive;
        target.endTime = this.endTime;
    }

    public bool DataEquals(QuestRecord target, byte syncTargetLevel)
    {
        if (object.ReferenceEquals(this, target))
        {
            return true;
        }
        if (object.ReferenceEquals(target, null))
        {
            return false;
        }
        return (((((target.eventId == this.eventId) && (target.questId == this.questId)) && ((target.stateIndex == this.stateIndex) && (target.stateCounterValue == this.stateCounterValue))) && ((target.questStatus == this.questStatus) && (target.timerActive == this.timerActive))) && (target.endTime == this.endTime));
    }

    public int GetQuestHashCode()
    {
        return ((((((this.eventId + this.questId) + this.stateIndex) + this.stateCounterValue) + ((int) this.questStatus)) + (this.timerActive ? 0x387113 : 0)) + ((int) this.endTime.ToBinary()));
    }

    public bool IsExpired(DateTime curTime)
    {
        if (!this.timerActive)
        {
            return false;
        }
        return (curTime > this.endTime);
    }

    [OnDeserialized]
    internal void OnDeserializedMethod(StreamingContext context)
    {
        this.eventId = RecordUtils.GetInt(this.i, 0);
        this.questId = RecordUtils.GetInt(this.i, 1);
        this.stateIndex = RecordUtils.GetInt(this.i, 2);
        this.stateCounterValue = RecordUtils.GetInt(this.i, 3);
        this.questStatus = (EscalationConst.Flow) RecordUtils.GetByte(this.i, 4);
        this.timerActive = 1 == RecordUtils.GetByte(this.i, 5);
        this.endTime = DateTime.FromBinary(RecordUtils.GetLong(this.i, 6));
    }

    [OnSerializing]
    internal void OnSerializingMethod(StreamingContext context)
    {
        RecordUtils.SetInt(this.i, this.eventId, 0);
        RecordUtils.SetInt(this.i, this.questId, 1);
        RecordUtils.SetInt(this.i, this.stateIndex, 2);
        RecordUtils.SetInt(this.i, this.stateCounterValue, 3);
        RecordUtils.SetByte(this.i, (byte) this.questStatus, 4);
        RecordUtils.SetByte(this.i, this.timerActive ? ((byte) 1) : ((byte) 0), 5);
        RecordUtils.SetLong(this.i, this.endTime.ToBinary(), 6);
    }

    public void ResetTimer(EventTimeLimit timerData, DateTime curTime)
    {
        if (timerData == null)
        {
            this.ClearTimer();
        }
        else
        {
            this.UpdateEndTime(curTime, timerData.duration);
        }
    }

    public void SetState(QuestData questData, int newStateIndex, DateTime curTime, EscalationConst.Flow finalStatus)
    {
        this.contextObj = null;
        bool flag = (((byte) (finalStatus & (EscalationConst.Flow.INCOMPLETE | EscalationConst.Flow.RESTART))) == 0x40) && (newStateIndex >= questData.states.Count);
        this.stateIndex = flag ? 0 : newStateIndex;
        if (flag || (newStateIndex < questData.states.Count))
        {
            this.questStatus = EscalationConst.Flow.INCOMPLETE;
            BaseQuestState state = questData.states[this.stateIndex];
            this.stateCounterValue = 0;
            this.ResetTimer(state.timeLimit, curTime);
        }
        else
        {
            this.questStatus = finalStatus;
            this.stateCounterValue = 0;
        }
    }

    public TimeSpan TimeToExpire(DateTime curTime)
    {
        if (!this.timerActive)
        {
            return TimeSpan.MaxValue;
        }
        return (TimeSpan) (this.endTime - curTime);
    }

    public void UpdateEndTime(DateTime curTime, float duration)
    {
        this.timerActive = true;
        this.endTime = curTime + TimeSpan.FromSeconds((double) duration);
    }
}

