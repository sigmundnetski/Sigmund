﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;

[ExecuteInEditMode]
public class PrefabInstance : MonoBehaviour
{
    private GameObject editTimeInstance = null;
    private Transform editXform = null;
    [NonSerialized]
    public List<MeshComponent> mComponents = new List<MeshComponent>();
    private Transform myXform = null;
    private bool needsRedraw = false;
    public GameObject prefab = null;
    [HideInInspector]
    public string prefabName = null;
    public static bool RenderRealMesh = true;
    private Vector3 scale;

    private void Awake()
    {
        this.needsRedraw = true;
        this.myXform = base.transform;
    }

    private void DrawGizmos(Color col)
    {
        Gizmos.color = col;
        Matrix4x4 localToWorldMatrix = base.transform.localToWorldMatrix;
        foreach (MeshComponent component in this.mComponents)
        {
            Gizmos.matrix = localToWorldMatrix * component.matrix;
            if (null != component.mesh)
            {
                Gizmos.DrawCube(component.mesh.bounds.center, component.mesh.bounds.size);
            }
        }
    }

    private void InstantiatePrefabFromName()
    {
        if ((this.prefabName != null) && BundleService.CheckBundle(BundleConsts.ENVIRONMENT_BUNDLE.bundleName))
        {
            this.prefab = BundleService.Load<GameObject>(BundleConsts.ENVIRONMENT_BUNDLE, this.prefabName);
            if (this.prefab != null)
            {
                this.InstantiatePrefabFromReference(true);
            }
            else
            {
                GLog.LogError(new object[] { "GameObject [" + base.name + "] failed to load prefab: " + this.prefabName });
                UnityEngine.Object.Destroy(base.gameObject);
            }
        }
    }

    private void InstantiatePrefabFromReference(bool replaceThisWithPrefab = false)
    {
        if (this.prefab != null)
        {
            GameObject obj2 = UnityEngine.Object.Instantiate(this.prefab) as GameObject;
            ResourceManager.RegisterForDynamicTextures(obj2);
            int layer = (this.myXform.parent != null) ? this.myXform.parent.gameObject.layer : base.gameObject.layer;
            EntityCore.MoveToLayer(obj2.transform, layer);
            if (replaceThisWithPrefab)
            {
                int num2;
                obj2.transform.parent = this.myXform.parent;
                obj2.transform.position = this.myXform.position;
                obj2.transform.rotation = this.myXform.rotation;
                obj2.transform.localScale = this.myXform.localScale;
                for (num2 = base.transform.childCount - 1; num2 >= 0; num2--)
                {
                    Transform child = base.transform.GetChild(num2);
                    Vector3 position = child.position;
                    Quaternion rotation = child.rotation;
                    Vector3 localScale = child.localScale;
                    child.parent = obj2.transform;
                    child.position = position;
                    child.rotation = rotation;
                    child.localScale = localScale;
                }
                AudioSource[] componentsInChildren = obj2.GetComponentsInChildren<AudioSource>(true);
                for (num2 = 0; num2 < componentsInChildren.Length; num2++)
                {
                    if (componentsInChildren[num2].loop)
                    {
                        componentsInChildren[num2].Play();
                    }
                }
                UnityEngine.Object.Destroy(base.gameObject);
            }
            else
            {
                float x = this.myXform.localScale.x;
                float y = this.myXform.localScale.y;
                float z = this.myXform.localScale.z;
                for (Transform transform2 = this.myXform.parent; transform2 != null; transform2 = transform2.parent)
                {
                    x *= transform2.localScale.x;
                    y *= transform2.localScale.y;
                    z *= transform2.localScale.z;
                }
                this.scale = new Vector3(x, y, z);
                this.editTimeInstance = obj2;
                this.editXform = this.editTimeInstance.transform;
                this.editXform.position = this.myXform.position;
                this.editXform.rotation = this.myXform.rotation;
                this.editXform.localScale = this.scale;
                RecursiveSetHideFlags(this.editTimeInstance, HideFlags.HideAndDontSave);
                this.mComponents.Clear();
                this.Rebuild(this.prefab, Matrix4x4.identity);
            }
        }
    }

    private void OnDestroy()
    {
        if (this.editTimeInstance != 0)
        {
            UnityEngine.Object.DestroyImmediate(this.editTimeInstance);
        }
    }

    private void OnDisable()
    {
        if (this.editTimeInstance != 0)
        {
            this.editTimeInstance.SetActive(false);
        }
    }

    private void OnDrawGizmos()
    {
        this.DrawGizmos(new Color(0f, 0f, 0f, 0f));
        if ((this.editTimeInstance != 0) && ((RenderRealMesh && !this.editTimeInstance.activeSelf) || (!RenderRealMesh && this.editTimeInstance.activeSelf)))
        {
            this.Update();
        }
        if (!RenderRealMesh)
        {
            this.RenderUnlitMesh();
        }
    }

    private void OnDrawGizmosSelected()
    {
        this.DrawGizmos(new Color(0f, 0f, 1f, 0.1f));
    }

    private void OnEnable()
    {
        if (this.editTimeInstance != 0)
        {
            if (RenderRealMesh)
            {
                this.editTimeInstance.SetActive(true);
            }
            else
            {
                this.editTimeInstance.SetActive(false);
            }
        }
    }

    private void OnValidate()
    {
        this.needsRedraw = true;
        if (!Application.isPlaying)
        {
            this.mComponents.Clear();
            this.Rebuild(this.prefab, Matrix4x4.identity);
        }
    }

    private void Rebuild(GameObject source, Matrix4x4 inMatrix)
    {
        if (source != null)
        {
            Matrix4x4 matrixx = inMatrix;
            MeshRenderer renderer = source.GetComponent<MeshRenderer>();
            if (renderer != null)
            {
                MeshComponent item = new MeshComponent {
                    mesh = renderer.GetComponent<MeshFilter>().sharedMesh,
                    matrix = matrixx,
                    materialCount = renderer.sharedMaterials.Length
                };
                this.mComponents.Add(item);
            }
            matrixx = inMatrix * Matrix4x4.TRS(-source.transform.position, Quaternion.Inverse(source.transform.rotation), source.transform.localScale);
            foreach (MeshRenderer renderer2 in source.GetComponentsInChildren<MeshRenderer>(true))
            {
                MeshComponent component2 = new MeshComponent {
                    mesh = renderer2.GetComponent<MeshFilter>().sharedMesh,
                    matrix = matrixx * renderer2.transform.localToWorldMatrix,
                    materialCount = renderer2.sharedMaterials.Length
                };
                this.mComponents.Add(component2);
            }
            foreach (PrefabInstance instance in source.GetComponentsInChildren<PrefabInstance>(true))
            {
                this.Rebuild(instance.prefab, inMatrix * instance.transform.localToWorldMatrix);
            }
        }
    }

    public static void RecursiveSetHideFlags(GameObject go, HideFlags flags)
    {
        for (int i = 0; i < go.transform.childCount; i++)
        {
            RecursiveSetHideFlags(go.transform.GetChild(i).gameObject, flags);
        }
        go.hideFlags = flags;
    }

    private void RenderUnlitMesh()
    {
        Matrix4x4 localToWorldMatrix = base.transform.localToWorldMatrix;
        foreach (MeshComponent component in this.mComponents)
        {
            for (int i = 0; i < component.materialCount; i++)
            {
                if (component.mesh != null)
                {
                    Graphics.DrawMeshNow(component.mesh, localToWorldMatrix * component.matrix, i);
                }
            }
        }
    }

    public void ReplacePrefabWithName()
    {
        this.prefabName = this.prefab.name;
        this.prefab = null;
        if (this.editTimeInstance != 0)
        {
            UnityEngine.Object.DestroyImmediate(this.editTimeInstance);
        }
        this.editTimeInstance = null;
        this.editXform = null;
    }

    private void Start()
    {
        if (!(((this.editTimeInstance != null) || (this.prefab == null)) || Application.isPlaying))
        {
            this.InstantiatePrefabFromReference(false);
        }
    }

    private void Update()
    {
        if ((this.editTimeInstance != null) && (this.editXform != null))
        {
            if (this.editXform.position != this.myXform.position)
            {
                this.editXform.position = this.myXform.position;
            }
            if (this.editXform.rotation != this.myXform.rotation)
            {
                this.editXform.rotation = this.myXform.rotation;
            }
            if (!(!RenderRealMesh || this.editTimeInstance.activeSelf))
            {
                this.editTimeInstance.SetActive(true);
            }
            else if (!(RenderRealMesh || !this.editTimeInstance.activeSelf))
            {
                this.editTimeInstance.SetActive(false);
            }
            if (this.needsRedraw)
            {
                if (!((this.prefab != null) && this.editTimeInstance.name.StartsWith(this.prefab.name)))
                {
                    UnityEngine.Object.DestroyImmediate(this.editTimeInstance);
                    this.editTimeInstance = null;
                    this.editXform = null;
                }
                this.needsRedraw = false;
            }
        }
        if (this.editTimeInstance == null)
        {
            if ((this.prefab != null) && string.IsNullOrEmpty(this.prefabName))
            {
                this.InstantiatePrefabFromReference(Application.isPlaying);
            }
            else if (((this.prefab == null) && !string.IsNullOrEmpty(this.prefabName)) && Application.isPlaying)
            {
                this.InstantiatePrefabFromName();
            }
        }
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct MeshComponent
    {
        public Mesh mesh;
        public Matrix4x4 matrix;
        public int materialCount;
    }
}

