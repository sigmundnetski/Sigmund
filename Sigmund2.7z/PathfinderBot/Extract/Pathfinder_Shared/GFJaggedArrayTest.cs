﻿using System;

internal class GFJaggedArrayTest
{
    public int[][] array;
}

