﻿using System;

public class AdvancementRecord : IDataCopyable<AdvancementRecord>
{
    internal const int NUM_BYTES_PER_ULONG = 8;
    internal const int NUM_FLAGS_PER_ULONG = 0x40;
    internal const int NUM_USHORTS_PER_ULONG = 4;
    public int pageId;
    public ushort pageNumber;
    public ulong[] ulongData;

    public AdvancementRecord()
    {
        this.pageNumber = 0xffff;
        this.ulongData = new ulong[0];
    }

    public AdvancementRecord(int pageId_, ushort pageNumber_)
    {
        this.pageNumber = 0xffff;
        this.pageNumber = pageNumber_;
        this.pageId = pageId_;
        this.ulongData = new ulong[0];
    }

    public void DataCopyTo(ref AdvancementRecord target, byte syncTargetLevel)
    {
        target.pageId = this.pageId;
        target.pageNumber = this.pageNumber;
        DataSerializerUtils.DataCopyField<ulong>(this.ulongData, ref target.ulongData);
    }

    public bool DataEquals(AdvancementRecord other, byte syncTargetLevel)
    {
        return ((SparseArray.DeepEqualsWithIndex<ulong>(this.ulongData, other.ulongData) && (other.pageId == this.pageId)) && (other.pageNumber == this.pageNumber));
    }

    public void DeserializeDb(byte[] input)
    {
        int[] dst = new int[1];
        Buffer.BlockCopy(input, 0, dst, 0, 4);
        this.pageId = dst[0];
        this.ulongData = new ulong[(input.Length - 4) / 8];
        Buffer.BlockCopy(input, 4, this.ulongData, 0, input.Length - 4);
    }

    public bool GetBitIndex(int index)
    {
        return (0L != (this.ulongData[index / 0x40] & (((ulong) 1L) << (index % 0x40))));
    }

    public byte GetByteIndex(int index)
    {
        return Buffer.GetByte(this.ulongData, index);
    }

    public ushort GetUShortIndex(int index)
    {
        ushort @byte = Buffer.GetByte(this.ulongData, index * 2);
        ushort num2 = (ushort) (Buffer.GetByte(this.ulongData, (index * 2) + 1) << 8);
        return (ushort) (@byte + num2);
    }

    public void GrowLength(int length)
    {
        if (this.ulongData.Length < length)
        {
            Array.Resize<ulong>(ref this.ulongData, length);
        }
    }

    public void SerializeDb(ref byte[] output)
    {
        SparseArray.EnsureCapacity<byte>(ref output, (this.ulongData.Length * 8) + 4);
        int[] src = new int[] { this.pageId };
        Buffer.BlockCopy(src, 0, output, 0, 4);
        Buffer.BlockCopy(this.ulongData, 0, output, 4, output.Length - 4);
    }

    public void SetBitIndex(int index, bool value)
    {
        this.ulongData[index / 0x40] |= ((ulong) 1L) << (index % 0x40);
    }

    public void SetByteIndex(int index, byte value)
    {
        Buffer.SetByte(this.ulongData, index, value);
    }

    public void SetUShortIndex(int index, ushort value)
    {
        Buffer.SetByte(this.ulongData, index * 2, (byte) (value & 0xff));
        Buffer.SetByte(this.ulongData, (index * 2) + 1, (byte) (value >> 8));
    }

    public override string ToString()
    {
        return string.Concat(new object[] { "<AdvRec:", this.pageNumber, ", ", this.pageId, ">" });
    }

    public int Length
    {
        get
        {
            return this.ulongData.Length;
        }
    }
}

