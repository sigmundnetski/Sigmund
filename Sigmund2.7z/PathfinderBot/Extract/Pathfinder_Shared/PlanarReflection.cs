﻿using System;
using System.Collections.Generic;
using UnityEngine;

[ExecuteInEditMode, RequireComponent(typeof(WaterBase))]
public class PlanarReflection : MonoBehaviour
{
    public Color clearColor = Color.grey;
    public float clipPlaneOffset = 0.07f;
    private Dictionary<Camera, bool> helperCameras = null;
    private Vector3 oldpos = Vector3.zero;
    private Camera reflectionCamera;
    public LayerMask reflectionMask;
    public string reflectionSampler = "_ReflectionTex";
    public bool reflectSkybox = false;
    private Material sharedMaterial = null;

    private static Matrix4x4 CalculateObliqueMatrix(Matrix4x4 projection, Vector4 clipPlane)
    {
        Vector4 b = (Vector4) (projection.inverse * new Vector4(sgn(clipPlane.x), sgn(clipPlane.y), 1f, 1f));
        Vector4 vector2 = (Vector4) (clipPlane * (2f / Vector4.Dot(clipPlane, b)));
        projection[2] = vector2.x - projection[3];
        projection[6] = vector2.y - projection[7];
        projection[10] = vector2.z - projection[11];
        projection[14] = vector2.w - projection[15];
        return projection;
    }

    private static Matrix4x4 CalculateReflectionMatrix(Matrix4x4 reflectionMat, Vector4 plane)
    {
        reflectionMat.m00 = 1f - ((2f * plane[0]) * plane[0]);
        reflectionMat.m01 = (-2f * plane[0]) * plane[1];
        reflectionMat.m02 = (-2f * plane[0]) * plane[2];
        reflectionMat.m03 = (-2f * plane[3]) * plane[0];
        reflectionMat.m10 = (-2f * plane[1]) * plane[0];
        reflectionMat.m11 = 1f - ((2f * plane[1]) * plane[1]);
        reflectionMat.m12 = (-2f * plane[1]) * plane[2];
        reflectionMat.m13 = (-2f * plane[3]) * plane[1];
        reflectionMat.m20 = (-2f * plane[2]) * plane[0];
        reflectionMat.m21 = (-2f * plane[2]) * plane[1];
        reflectionMat.m22 = 1f - ((2f * plane[2]) * plane[2]);
        reflectionMat.m23 = (-2f * plane[3]) * plane[2];
        reflectionMat.m30 = 0f;
        reflectionMat.m31 = 0f;
        reflectionMat.m32 = 0f;
        reflectionMat.m33 = 1f;
        return reflectionMat;
    }

    private Vector4 CameraSpacePlane(Camera cam, Vector3 pos, Vector3 normal, float sideSign)
    {
        Vector3 v = pos + ((Vector3) (normal * this.clipPlaneOffset));
        Matrix4x4 worldToCameraMatrix = cam.worldToCameraMatrix;
        Vector3 lhs = worldToCameraMatrix.MultiplyPoint(v);
        Vector3 rhs = (Vector3) (worldToCameraMatrix.MultiplyVector(normal).normalized * sideSign);
        return new Vector4(rhs.x, rhs.y, rhs.z, -Vector3.Dot(lhs, rhs));
    }

    private Camera CreateReflectionCameraFor(Camera cam)
    {
        string name = base.gameObject.name + "Reflection" + cam.name;
        GameObject obj2 = GameObject.Find(name);
        if (obj2 == null)
        {
            obj2 = new GameObject(name, new System.Type[] { typeof(Camera) });
        }
        if (obj2.GetComponent(typeof(Camera)) == null)
        {
            obj2.AddComponent(typeof(Camera));
        }
        Camera camera = obj2.camera;
        camera.backgroundColor = this.clearColor;
        camera.clearFlags = this.reflectSkybox ? CameraClearFlags.Skybox : CameraClearFlags.Color;
        this.SetStandardCameraParameter(camera, this.reflectionMask);
        if (camera.targetTexture == null)
        {
            camera.targetTexture = this.CreateTextureFor(cam);
        }
        return camera;
    }

    private RenderTexture CreateTextureFor(Camera cam)
    {
        return new RenderTexture(Mathf.FloorToInt(cam.pixelWidth * 0.5f), Mathf.FloorToInt(cam.pixelHeight * 0.5f), 0x18) { hideFlags = HideFlags.DontSave };
    }

    public void LateUpdate()
    {
        if (null != this.helperCameras)
        {
            this.helperCameras.Clear();
        }
    }

    public void OnDisable()
    {
        Shader.EnableKeyword("WATER_SIMPLE");
        Shader.DisableKeyword("WATER_REFLECTIVE");
    }

    public void OnEnable()
    {
        Shader.EnableKeyword("WATER_REFLECTIVE");
        Shader.DisableKeyword("WATER_SIMPLE");
    }

    public void RenderHelpCameras(Camera currentCam)
    {
        if (null == this.helperCameras)
        {
            this.helperCameras = new Dictionary<Camera, bool>();
        }
        if (!this.helperCameras.ContainsKey(currentCam))
        {
            this.helperCameras.Add(currentCam, false);
        }
        if (!this.helperCameras[currentCam])
        {
            if (this.reflectionCamera == null)
            {
                this.reflectionCamera = this.CreateReflectionCameraFor(currentCam);
            }
            this.RenderReflectionFor(currentCam, this.reflectionCamera);
            this.helperCameras[currentCam] = true;
        }
    }

    private void RenderReflectionFor(Camera cam, Camera reflectCamera)
    {
        if ((reflectCamera != null) && ((this.sharedMaterial == null) || this.sharedMaterial.HasProperty(this.reflectionSampler)))
        {
            reflectCamera.cullingMask = ((int) this.reflectionMask) & ~(((int) 1) << LayerMask.NameToLayer("Water"));
            this.SaneCameraSettings(reflectCamera);
            reflectCamera.backgroundColor = this.clearColor;
            reflectCamera.clearFlags = this.reflectSkybox ? CameraClearFlags.Skybox : CameraClearFlags.Color;
            if (this.reflectSkybox && (cam.gameObject.GetComponent(typeof(Skybox)) != 0))
            {
                Skybox component = (Skybox) reflectCamera.gameObject.GetComponent(typeof(Skybox));
                if (component == null)
                {
                    component = (Skybox) reflectCamera.gameObject.AddComponent(typeof(Skybox));
                }
                component.material = ((Skybox) cam.GetComponent(typeof(Skybox))).material;
            }
            GL.SetRevertBackfacing(true);
            Transform transform = base.transform;
            Vector3 eulerAngles = cam.transform.eulerAngles;
            reflectCamera.transform.eulerAngles = new Vector3(-eulerAngles.x, eulerAngles.y, eulerAngles.z);
            reflectCamera.transform.position = cam.transform.position;
            Vector3 position = transform.transform.position;
            position.y = transform.position.y;
            Vector3 up = transform.transform.up;
            float w = -Vector3.Dot(up, position) - this.clipPlaneOffset;
            Vector4 plane = new Vector4(up.x, up.y, up.z, w);
            Matrix4x4 matrixx = CalculateReflectionMatrix(Matrix4x4.zero, plane);
            this.oldpos = cam.transform.position;
            Vector3 vector5 = matrixx.MultiplyPoint(this.oldpos);
            reflectCamera.worldToCameraMatrix = cam.worldToCameraMatrix * matrixx;
            Vector4 clipPlane = this.CameraSpacePlane(reflectCamera, position, up, 1f);
            Matrix4x4 matrixx2 = CalculateObliqueMatrix(cam.projectionMatrix, clipPlane);
            reflectCamera.projectionMatrix = matrixx2;
            reflectCamera.transform.position = vector5;
            Vector3 vector7 = cam.transform.eulerAngles;
            reflectCamera.transform.eulerAngles = new Vector3(-vector7.x, vector7.y, vector7.z);
            reflectCamera.Render();
            GL.SetRevertBackfacing(false);
        }
    }

    private void SaneCameraSettings(Camera helperCam)
    {
        helperCam.depthTextureMode = DepthTextureMode.None;
        helperCam.backgroundColor = Color.black;
        helperCam.clearFlags = CameraClearFlags.Color;
        helperCam.renderingPath = RenderingPath.Forward;
    }

    private void SetStandardCameraParameter(Camera cam, LayerMask mask)
    {
        cam.cullingMask = ((int) mask) & ~(((int) 1) << LayerMask.NameToLayer("Water"));
        cam.backgroundColor = Color.black;
        cam.enabled = false;
    }

    private static float sgn(float a)
    {
        if (a > 0f)
        {
            return 1f;
        }
        if (a < 0f)
        {
            return -1f;
        }
        return 0f;
    }

    public void Start()
    {
        this.sharedMaterial = ((WaterBase) base.gameObject.GetComponent(typeof(WaterBase))).sharedMaterial;
    }

    public void WaterTileBeingRendered(Transform tr, Camera currentCam)
    {
        this.RenderHelpCameras(currentCam);
        if ((this.reflectionCamera != null) && (this.sharedMaterial != 0))
        {
            this.sharedMaterial.SetTexture(this.reflectionSampler, this.reflectionCamera.targetTexture);
        }
    }
}

