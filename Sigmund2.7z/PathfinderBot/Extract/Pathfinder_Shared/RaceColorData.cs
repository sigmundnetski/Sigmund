﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;

public class RaceColorData : DataClass
{
    protected static readonly string[] _mandatoryColumns = new string[] { "name", "display name", "red mat", "green mat", "blue mat", "red user 1", "green user 1", "blue user 1", "red user 2", "green user 2", "blue user 2" };
    public Color colorMat;
    public static Dictionary<int, RaceColorData> colorsById = new Dictionary<int, RaceColorData>();
    public Color colorUser1;
    public Color colorUser2;
    private static RaceColorData DEFAULT_COLOR;
    public string displayName;
    private static RaceColorData UNKNOWN_COLOR;

    public RaceColorData()
    {
        this.displayName = string.Empty;
        this.colorMat = Color.black;
        this.colorUser1 = Color.black;
        this.colorUser2 = Color.black;
    }

    public RaceColorData(string name, Color mat, Color user1, Color user2) : base(name)
    {
        this.displayName = name;
        this.colorMat = mat;
        this.colorUser1 = user1;
        this.colorUser2 = user2;
    }

    public static RaceColorData GetById(int id)
    {
        RaceColorData data;
        if (colorsById.TryGetValue(id, out data))
        {
            return data;
        }
        GLog.LogWarning(new object[] { "Don't have color for id: '" + id + "'" });
        return UNKNOWN_COLOR;
    }

    public static void OnLoad(List<DataClass> objects)
    {
        colorsById.Clear();
        foreach (RaceColorData data in objects)
        {
            colorsById[data.id] = data;
        }
        Color mat = new Color(1f, 0f, 1f);
        Color color2 = new Color(0f, 0f, 0f);
        UNKNOWN_COLOR = new RaceColorData("<unknown>", mat, mat, mat);
        DEFAULT_COLOR = new RaceColorData("default", color2, color2, color2);
        colorsById[0] = DEFAULT_COLOR;
    }

    public override DataClass ParseRecord(int index)
    {
        int num;
        RaceColorData data = new RaceColorData();
        if (!(DataClass.columnNamesToIndex.TryGetValue("name", out num) && DataClass.TryGetLCaseCellValue(num, index, out data.name)))
        {
            return null;
        }
        if (!(DataClass.columnNamesToIndex.TryGetValue("display name", out num) && DataClass.TryGetCellValue(num, index, out data.displayName)))
        {
            return null;
        }
        if (!this.TryGetColor("mat", index, out data.colorMat))
        {
            return null;
        }
        if (!this.TryGetColor("user 1", index, out data.colorUser1))
        {
            return null;
        }
        if (!this.TryGetColor("user 2", index, out data.colorUser2))
        {
            return null;
        }
        return data;
    }

    private bool TryGetColor(string colorType, int index, out Color color)
    {
        float num;
        float num2;
        float num3;
        color = Color.black;
        if (!((this.TryGetColorValue("red " + colorType, index, out num) && this.TryGetColorValue("green " + colorType, index, out num2)) && this.TryGetColorValue("blue " + colorType, index, out num3)))
        {
            return false;
        }
        color = new Color(num, num2, num3);
        return true;
    }

    private bool TryGetColorValue(string columnName, int index, out float colorValue)
    {
        int num;
        int output = -1;
        if (DataClass.columnNamesToIndex.TryGetValue(columnName, out num))
        {
            DataClass.GetCellValue(num, index, out output);
        }
        if ((output < 0) || (output > 0xff))
        {
            DataClass.OutputErrorMessage(num, index, "RGB value must be between 0 and 255.");
            colorValue = 1f;
            return false;
        }
        colorValue = ((float) output) / 255f;
        return true;
    }

    protected override IEnumerable<string> GetMandatoryColumns
    {
        get
        {
            return _mandatoryColumns;
        }
    }
}

