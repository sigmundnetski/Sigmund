﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

[LooseDependency(typeof(CombatWeapon)), LooseDependency(typeof(CombatArmor)), NoFinalOutput, LooseDependency(typeof(OffensiveFeatData)), LooseDependency(typeof(NonAttackFeatData))]
public class PlayerClassData : CombatClassData
{
    public PlayerClassData()
    {
    }

    public PlayerClassData(string name, int health, int recoveryAmount, string weaponSet1, string weaponSet2, string implement1, string implement2, string armor, string[] passiveFeatNames, string featureFeat, string armorFeat, string[] upgradeFeatNames) : base(name)
    {
        base.hitPoints = health;
        base.recovery = recoveryAmount;
        this.ParseWeaponSet(0, weaponSet1);
        this.ParseWeaponSet(1, weaponSet2);
        this.ParseImplement(0, implement1);
        this.ParseImplement(1, implement2);
        armor = armor.Trim();
        if (!string.IsNullOrEmpty(armor))
        {
            CombatClassData.ParseArmor(armor, ref this.armorId, ref this.armorUpgrade);
        }
        List<int> list = new List<int>();
        if (passiveFeatNames != null)
        {
            foreach (string str in passiveFeatNames)
            {
                list.Add(NonAttackFeatData.FeatIdFromName(str));
            }
        }
        if (!string.IsNullOrEmpty(featureFeat))
        {
            int item = NonAttackFeatData.FeatIdFromName(featureFeat);
            list.Add(item);
        }
        if (!string.IsNullOrEmpty(armorFeat))
        {
            int num2 = NonAttackFeatData.FeatIdFromName(armorFeat);
            list.Add(num2);
        }
        base.passiveFeatIds = list.ToArray();
        List<int> list2 = new List<int>();
        if (upgradeFeatNames != null)
        {
            foreach (string str in upgradeFeatNames)
            {
                list2.Add(NonAttackFeatData.FeatIdFromName(str));
            }
        }
        base.upgradeFeatIds = list2.ToArray();
    }

    protected void ParseExpendableSetWithError(int setIndex, string[] expendables)
    {
        try
        {
            if ((expendables != null) && (expendables.Length > 0))
            {
                CombatClassData.ParseAttackFeats(expendables, setIndex * 6, ref this.expendableFeatIds, ref this.expendableFeatLevels);
            }
        }
        catch (ParseException exception)
        {
            string str = "\n";
            object obj2 = str + "  " + base.name + ": GoblinSpec parsing error!\n";
            DataClass.OutputErrorMessage(string.Concat(new object[] { obj2, "     Expendable Feat Set ", setIndex + 1, ": ", expendables, "\n" }) + "    >>ERROR: " + exception.Message + "\n");
        }
    }

    private void ParseImplement(int setIndex, string implement)
    {
        if (!string.IsNullOrEmpty(implement))
        {
            CombatClassData.ParseWeapons(implement, setIndex, ref this.implementIds, ref this.implementUpgrades);
        }
    }

    private void ParseImplementWithError(int setIndex, string implement)
    {
        try
        {
            this.ParseImplement(setIndex, implement);
        }
        catch (ParseException exception)
        {
            string str = "\n";
            object obj2 = str + "  " + base.name + ": GoblinSpec parsing error!\n";
            DataClass.OutputErrorMessage(string.Concat(new object[] { obj2, "     Implement ", setIndex + 1, ": ", implement, "\n" }) + "    >>ERROR: " + exception.Message + "\n");
        }
    }

    protected void ParseOtherFeatsWithError(string otherFeats)
    {
        if (!string.IsNullOrEmpty(otherFeats.Trim()))
        {
            try
            {
                List<GSStatement> source = GoblinSpec.Parse(otherFeats);
                List<int> list2 = new List<int>();
                List<byte> list3 = new List<byte>();
                for (int i = 0; i < source.Count<GSStatement>(); i++)
                {
                    int num2;
                    GSStatement statement = source[i];
                    if (!DataClass.TryGetIdFromForeignName<FeatAdvancementData>(statement.statement, out num2))
                    {
                        throw new ParseException(statement.statement + " is not a known FeatAdvancementData.");
                    }
                    byte item = CombatModifier.ParseByteParameter(statement);
                    list2.Add(num2);
                    list3.Add(item);
                    if (item == 0)
                    {
                        throw new ParseException("Feat requires a level: " + statement.statement);
                    }
                    if (statement.parameters.Count > 0)
                    {
                        throw new ParseException("Unknown parameter for feat: " + statement.statement);
                    }
                    if (statement.qualifiers.Count > 0)
                    {
                        throw new ParseException("Unknown qualifier for feat: " + statement.statement);
                    }
                }
                base.otherPreknownFeatAdvIds = list2.ToArray();
                base.otherPreknownFeatAdvLevels = list3.ToArray();
            }
            catch (ParseException exception)
            {
                DataClass.OutputErrorMessage((("\n" + "  " + base.name + ": GoblinSpec parsing error!\n") + "     Known Feats: '" + otherFeats + "'\n") + "    >>ERROR: " + exception.Message + "\n");
            }
        }
    }

    public override DataClass ParseRecord(int index)
    {
        int num;
        int num2;
        string str13;
        bool flag;
        PlayerClassData data = new PlayerClassData();
        string key = "name";
        string[] strArray = new string[] { "base attack", "heavy melee", "ranged", "light melee", "arcane", "divine" };
        AttackType[] typeArray3 = new AttackType[6];
        typeArray3[1] = AttackType.HeavyMelee;
        typeArray3[2] = AttackType.Ranged;
        typeArray3[3] = AttackType.LightMelee;
        typeArray3[4] = AttackType.Arcane;
        typeArray3[5] = AttackType.Divine;
        AttackType[] typeArray = typeArray3;
        string[] strArray2 = new string[] { "fortitude", "reflex", "will" };
        DefenseType[] typeArray2 = new DefenseType[] { DefenseType.Fortitude, DefenseType.Reflex, DefenseType.Will };
        string str2 = "hp";
        string str3 = "recovery";
        string format = "main hand {0}";
        string str5 = "off hand {0}";
        string str6 = "implement {0}";
        string str7 = "armor";
        string[] strArray3 = new string[] { "armor passive", "role feature", "reactive 1", "reactive 2", "defensive 1", "defensive 2", "defensive 3" };
        string str8 = "refresh {0}";
        string str9 = "utility {0}";
        string str10 = "set {0} {1}";
        string str11 = "exset {0} {1}";
        string str12 = "other known feats";
        if (!(DataClass.columnNamesToIndex.TryGetValue(key, out num) && DataClass.TryGetLCaseCellValue(num, index, out data.name)))
        {
            return null;
        }
        for (num2 = 0; (num2 < strArray.Length) && (num2 < typeArray.Length); num2++)
        {
            if (DataClass.columnNamesToIndex.TryGetValue(strArray[num2], out num))
            {
                DataClass.GetCellValue(num, index, out data.attackBonus.attackBonus[(int) typeArray[num2]]);
            }
        }
        for (num2 = 0; (num2 < strArray2.Length) && (num2 < typeArray2.Length); num2++)
        {
            if (DataClass.columnNamesToIndex.TryGetValue(strArray2[num2], out num))
            {
                DataClass.GetCellValue(num, index, out data.defense.defense[(int) typeArray2[num2]]);
            }
        }
        if (DataClass.columnNamesToIndex.TryGetValue(str2, out num))
        {
            DataClass.GetCellValue(num, index, out data.hitPoints);
        }
        if (DataClass.columnNamesToIndex.TryGetValue(str3, out num))
        {
            DataClass.GetCellValue(num, index, out data.recovery);
        }
        num2 = 0;
        while (true)
        {
            string str14;
            flag = true;
            if (!(DataClass.columnNamesToIndex.TryGetValue(string.Format(format, num2 + 1), out num) && DataClass.TryGetLCaseCellValue(num, index, out str13)))
            {
                str13 = string.Empty;
            }
            if (!(DataClass.columnNamesToIndex.TryGetValue(string.Format(str5, num2 + 1), out num) && DataClass.TryGetLCaseCellValue(num, index, out str14)))
            {
                str14 = string.Empty;
            }
            if ((str13.Length <= 0) && (str14.Length <= 0))
            {
                num2 = 0;
                break;
            }
            data.ParseWeaponSetWithError(num2, CombatClassData.ToCSV(new string[] { str13, str14 }));
            num2++;
        }
    Label_03A4:
        flag = true;
        if (!DataClass.columnNamesToIndex.TryGetValue(string.Format(str6, num2 + 1), out num) || !DataClass.TryGetLCaseCellValue(num, index, out str13))
        {
            string output = string.Empty;
            if (DataClass.columnNamesToIndex.TryGetValue(str7, out num))
            {
                DataClass.GetCellValue(num, index, out output);
                output = output.Trim();
                if (!string.IsNullOrEmpty(output))
                {
                    try
                    {
                        CombatClassData.ParseArmor(output, ref data.armorId, ref data.armorUpgrade);
                    }
                    catch (ParseException exception)
                    {
                        DataClass.OutputErrorMessage((("\n" + "  " + base.name + ": GoblinSpec parsing error!\n") + "     Armor: " + output + "\n") + "    >>ERROR: " + exception.Message + "\n");
                    }
                }
            }
            data.passiveFeatIds = new int[strArray3.Length];
            for (num2 = 0; num2 < strArray3.Length; num2++)
            {
                if (DataClass.columnNamesToIndex.TryGetValue(strArray3[num2], out num))
                {
                    DataClass.TryGetIdFromForeignName<NonAttackFeatData>(num, index, out data.passiveFeatIds[num2]);
                }
            }
            data.refreshFeatIds = new int[2];
            for (num2 = 0; num2 < 2; num2++)
            {
                if (!DataClass.columnNamesToIndex.TryGetValue(string.Format(str8, num2 + 1), out num))
                {
                    break;
                }
                DataClass.TryGetIdFromForeignName<NonAttackFeatData>(num, index, out data.refreshFeatIds[num2]);
            }
        }
        else
        {
            data.ParseImplementWithError(num2, str13);
            num2++;
            goto Label_03A4;
        }
        List<string> list = new List<string>();
        for (num2 = 0; num2 < 2; num2++)
        {
            string str17;
            if (!DataClass.columnNamesToIndex.TryGetValue(string.Format(str9, num2 + 1), out num))
            {
                break;
            }
            DataClass.GetCellValue(num, index, out str17);
            list.Add(str17);
        }
        if (list.Count > 0)
        {
            data.ParseUtilitiesWithError(list.ToArray());
        }
        if (DataClass.columnNamesToIndex.TryGetValue("Upgrade Feats", out num))
        {
            DataClass.TryGetIdsFromForeignNames<NonAttackFeatData>(num, index, out data.upgradeFeatIds);
        }
        num2 = 0;
    Label_064F:
        flag = true;
        List<string> list2 = new List<string>();
        int num3 = 0;
    Label_061A:
        flag = true;
        if (!DataClass.columnNamesToIndex.TryGetValue(string.Format(str10, num2 + 1, num3 + 1), out num))
        {
            if (list2.Count <= 0)
            {
                num2 = 0;
                goto Label_06EA;
            }
            data.ParseAttackSetWithError(num2, list2.ToArray());
            num2++;
        }
        else
        {
            string str18;
            DataClass.GetCellValue(num, index, out str18);
            list2.Add(str18);
            num3++;
            goto Label_061A;
        }
        goto Label_064F;
    Label_06EA:
        flag = true;
        list2 = new List<string>();
        num3 = 0;
    Label_06B5:
        flag = true;
        if (!DataClass.columnNamesToIndex.TryGetValue(string.Format(str11, num2 + 1, num3 + 1), out num))
        {
            if (list2.Count <= 0)
            {
                if (DataClass.columnNamesToIndex.TryGetValue(str12, out num))
                {
                    string str20;
                    DataClass.GetCellValue(num, index, out str20);
                    data.ParseOtherFeatsWithError(str20);
                    List<string> list3 = new List<string>();
                    for (num2 = 0; num2 < data.otherPreknownFeatAdvIds.Length; num2++)
                    {
                        List<int> list4;
                        if (FeatDatabase.featsByAdvancementId.TryGetValue(data.otherPreknownFeatAdvIds[num2], out list4))
                        {
                            for (num3 = 0; num3 < list4.Count; num3++)
                            {
                                NonAttackFeatData featById = FeatDatabase.GetFeatById(list4[num3]) as NonAttackFeatData;
                                if ((featById != null) && ((featById.channel == Combat.Channel.Racial) && (list3.IndexOf(featById.name) == -1)))
                                {
                                    list3.Add(featById.name);
                                }
                            }
                        }
                    }
                    if (list3.Count > 1)
                    {
                        StringBuilder builder = GUtil.GetQuickText().Append(data.name).Append(" has too many Racial feats: ");
                        for (num2 = 0; num2 < list3.Count; num2++)
                        {
                            builder.Append(list3[num2]);
                            if (num2 < (list3.Count - 1))
                            {
                                builder.Append(", ");
                            }
                        }
                        builder.Append(". Players can have only one Racial upgrade feat.");
                        DataClass.OutputErrorMessage(num, index, builder.ToString());
                    }
                }
                return data;
            }
            data.ParseExpendableSetWithError(num2, list2.ToArray());
            num2++;
        }
        else
        {
            string str19;
            DataClass.GetCellValue(num, index, out str19);
            list2.Add(str19);
            num3++;
            goto Label_06B5;
        }
        goto Label_06EA;
    }

    protected void ParseUtilitiesWithError(string[] utilities)
    {
        try
        {
            if ((utilities != null) && (utilities.Length > 0))
            {
                CombatClassData.ParseAttackFeats(utilities, 0, ref this.utilityFeatIds, ref this.utilityFeatLevels);
            }
        }
        catch (ParseException exception)
        {
            string str = "\n";
            object obj2 = str + "  " + base.name + ": GoblinSpec parsing error!\n";
            DataClass.OutputErrorMessage(string.Concat(new object[] { obj2, "     Utility Feats: ", utilities, "\n" }) + "    >>ERROR: " + exception.Message + "\n");
        }
    }

    private void ParseWeaponSet(int setIndex, string weapons)
    {
        if (!string.IsNullOrEmpty(weapons))
        {
            CombatClassData.ParseWeapons(weapons, setIndex * 2, ref this.weaponIds, ref this.weaponUpgrades);
        }
    }

    private void ParseWeaponSetWithError(int setIndex, string weapons)
    {
        try
        {
            this.ParseWeaponSet(setIndex, weapons);
        }
        catch (ParseException exception)
        {
            string str = "\n";
            object obj2 = str + "  " + base.name + ": GoblinSpec parsing error!\n";
            DataClass.OutputErrorMessage(string.Concat(new object[] { obj2, "     Weapon Set ", setIndex + 1, ": ", weapons, "\n" }) + "    >>ERROR: " + exception.Message + "\n");
        }
    }
}

