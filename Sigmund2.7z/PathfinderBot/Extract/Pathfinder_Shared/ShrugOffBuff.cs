﻿using System;
using System.Collections.Generic;

public class ShrugOffBuff : CombatInstantBuff
{
    public ShrugOffBuff() : base("Shrug Off", Combat.Channel.None, Combat.EffectType.Beneficial)
    {
    }

    private int CompareBySeverity(CombatBuffVars lhs, CombatBuffVars rhs)
    {
        CombatModifierType bUFF = lhs.combatMod.type;
        CombatModifierType type2 = rhs.combatMod.type;
        if ((bUFF == CombatModifierType.STATE) && (lhs.channel != Combat.Channel.State))
        {
            bUFF = CombatModifierType.BUFF;
        }
        if ((type2 == CombatModifierType.STATE) && (rhs.channel != Combat.Channel.State))
        {
            type2 = CombatModifierType.BUFF;
        }
        if (bUFF != type2)
        {
            if (bUFF == CombatModifierType.STACK)
            {
                return -1;
            }
            if (type2 == CombatModifierType.STACK)
            {
                return 1;
            }
            if (bUFF == CombatModifierType.BUFF)
            {
                return -1;
            }
            if (type2 == CombatModifierType.BUFF)
            {
                return 1;
            }
            return 0;
        }
        if (bUFF == CombatModifierType.STACK)
        {
            int stacks = lhs.stacks;
            int num2 = rhs.stacks;
            if (stacks > num2)
            {
                return -1;
            }
            if (stacks < num2)
            {
                return 1;
            }
            return 0;
        }
        if (bUFF == CombatModifierType.BUFF)
        {
            uint expirationTick = lhs.expirationTick;
            uint num4 = rhs.expirationTick;
            if (expirationTick > num4)
            {
                return -1;
            }
            if (expirationTick < num4)
            {
                return 1;
            }
            return 0;
        }
        return 0;
    }

    public static ShrugOffBuff Create()
    {
        return new ShrugOffBuff();
    }

    public override void ResolutionPhase(CombatBuffVars buff, uint combatTick)
    {
        buff.effectApplied = true;
        List<CombatBuffVars> list = new List<CombatBuffVars>();
        foreach (CombatBuffVars vars in buff.owner.buffs)
        {
            if ((vars != null) && ((vars.channel == Combat.Channel.Weakness) || (vars.channel == Combat.Channel.Torment)))
            {
                list.Add(vars);
            }
        }
        if (list.Count != 0)
        {
            list.Sort(new Comparison<CombatBuffVars>(this.CompareBySeverity));
            switch (list[0].combatMod.type)
            {
                case CombatModifierType.STACK:
                {
                    vars = list[0];
                    int recovery = buff.owner.combatClass.data.recovery;
                    if (vars.recoveryBonusType != RecoveryType.NUM_RECOVERY)
                    {
                        recovery = buff.owner.combatClass.recovery.Get(vars.recoveryBonusType);
                    }
                    vars.stacks -= recovery;
                    break;
                }
                case CombatModifierType.BUFF:
                case CombatModifierType.STATE:
                    vars = list[0];
                    if ((vars.expirationTick - combatTick) < CombatData.singleton.roundTimeInTicks)
                    {
                        vars.expirationTick = combatTick;
                    }
                    else
                    {
                        vars.expirationTick -= CombatData.singleton.roundTimeInTicks;
                    }
                    break;
            }
        }
    }
}

