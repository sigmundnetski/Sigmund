﻿using GNetwork;
using System;

public class ActiveCounterInfo : IDataCopyable<ActiveCounterInfo>, CustomSerializer<ActiveCounterInfo>
{
    public int current;
    public int eventId;
    public int max;
    public int questId;

    public void DataCopyTo(ref ActiveCounterInfo target, byte syncTargetLevel)
    {
        target.eventId = this.eventId;
        target.questId = this.questId;
        target.current = this.current;
        target.max = this.max;
    }

    public bool DataEquals(ActiveCounterInfo target, byte syncTargetLevel)
    {
        if (object.ReferenceEquals(this, target))
        {
            return true;
        }
        if (object.ReferenceEquals(target, null))
        {
            return false;
        }
        return ((((target.eventId == this.eventId) && (target.questId == this.questId)) && (target.current == this.current)) && (target.max == this.max));
    }

    public string GenerateHudText()
    {
        EventData data;
        EventCounter counter;
        if (EventData.eventsById.TryGetValue(this.eventId, out data) && data.eventCounters.TryGetValue(this.questId, out counter))
        {
            return counter.hudText;
        }
        return "<Invalid Status>";
    }

    public int GetQuestHashCode()
    {
        return (((this.eventId + this.questId) + this.current) + this.max);
    }

    public void Read(IBitBufferRead buffer, ref ActiveCounterInfo prev)
    {
        if (prev == null)
        {
            prev = new ActiveCounterInfo();
        }
        prev.eventId = buffer.PopInt();
        prev.questId = buffer.PopInt();
        prev.current = buffer.PopInt();
        prev.max = buffer.PopInt();
    }

    public void SetInfo(int _eventId, int _questId, int _current, int _max)
    {
        this.eventId = _eventId;
        this.questId = _questId;
        this.current = _current;
        this.max = _max;
    }

    public void Write(IBitBufferWrite buffer, ActiveCounterInfo prev)
    {
        buffer.PushInt(this.eventId);
        buffer.PushInt(this.questId);
        buffer.PushInt(this.current);
        buffer.PushInt(this.max);
    }
}

