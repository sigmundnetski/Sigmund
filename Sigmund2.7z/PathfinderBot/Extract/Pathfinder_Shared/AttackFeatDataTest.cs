﻿using System;

public class AttackFeatDataTest : UUnitTestCase
{
    private CombatVars albert;
    private CombatVars barry;
    private CombatVars charlie;
    private CombatVars dave;

    protected override void SetUp()
    {
        CombatTestHelper.SetUp();
        CombatTestHelper.MakeCombatData();
        CombatTestHelper.AddKeywordData(new KeywordData("Heavy", KeywordData.KeywordType.BASIC, KeywordData.GearType.ARMOR));
        CombatTestHelper.AddKeywordData(new KeywordData("Military", KeywordData.KeywordType.BASIC, KeywordData.GearType.ARMOR));
        CombatTestHelper.AddKeywordData(new KeywordData("Strengthened", KeywordData.KeywordType.BASIC, KeywordData.GearType.ARMOR));
        CombatTestHelper.AddKeywordData(new KeywordData("Dense", KeywordData.KeywordType.BASIC, KeywordData.GearType.ARMOR));
        CombatTestHelper.AddKeywordData(new KeywordData("Social1", KeywordData.KeywordType.SOCIAL, KeywordData.GearType.ARMOR));
        CombatTestHelper.AddKeywordData(new KeywordData("Social2", KeywordData.KeywordType.SOCIAL, KeywordData.GearType.ARMOR));
        CombatTestHelper.AddKeywordData(new KeywordData("Social3", KeywordData.KeywordType.SOCIAL, KeywordData.GearType.ARMOR));
        CombatTestHelper.AddKeywordData(new KeywordData("Social4", KeywordData.KeywordType.SOCIAL, KeywordData.GearType.ARMOR));
        CombatTestHelper.LoadKeywordData();
        CombatTestHelper.AddKeywordSet(new ArmorKeywordData("Knight", "Military", "Strengthened", "Dense"));
        CombatTestHelper.AddKeywordSet(new ArmorKeywordData("Social", "Social1", "Social2", "Social3"));
        CombatTestHelper.LoadKeywordSet();
        CombatTestHelper.AddArmor(new BasicArmorData("Heavy", 3, 1, 0x1b, 6, 0x20, -100, -0.3333333f, 0.8f, -20, "Heavy"), new ArmorQualityData("Pot Steel Plate", "Heavy", "Knight", 1, "", "", ""));
        CombatTestHelper.AddArmor(new BasicArmorData("Nothing", 0, 0, 0, 0, 0, 0, 0f, 1f, 0, "Social4"), new ArmorQualityData("Armor of Unit Testing", "Nothing", "Social", 0, string.Empty, string.Empty, string.Empty));
        CombatTestHelper.LoadArmor();
        PlayerClassData player = new PlayerClassData("Actual Tester", 0x4b0, 20, "", "", "", "", "Pot Steel Plate +0", null, null, null, null);
        int[] numArray = new int[4];
        numArray[1] = 4;
        numArray[2] = 8;
        player.defense.defense = numArray;
        player.attackBonus.attackBonus = new int[] { 4, 8, 0, 8, 0, 0 };
        PlayerClassData data2 = new PlayerClassData("Zeroed Tester", 0x4b0, 20, "", "", "", "", "Armor of Unit Testing +1", null, null, null, null) {
            defense = { defense = new int[4] },
            attackBonus = { attackBonus = new int[6] }
        };
        CombatTestHelper.AddPlayerClass(player);
        CombatTestHelper.AddPlayerClass(data2);
        CombatTestHelper.LoadCombatClasses();
        this.albert = new CombatVars((EntityId) 1L, 0f);
        this.barry = new CombatVars((EntityId) 2L, 0f);
        this.charlie = new CombatVars((EntityId) 3L, 0f);
        this.dave = new CombatVars((EntityId) 4L, 0f);
        this.albert.LoadStaticCombatClass(CombatClassData.ClassIdFromName("Zeroed Tester"));
        this.barry.LoadStaticCombatClass(CombatClassData.ClassIdFromName("Zeroed Tester"));
        this.charlie.LoadStaticCombatClass(CombatClassData.ClassIdFromName("Zeroed Tester"));
        this.dave.LoadStaticCombatClass(CombatClassData.ClassIdFromName("Zeroed Tester"));
        this.albert.name = "albert";
        this.barry.name = "barry";
        this.charlie.name = "charlie";
        this.dave.name = "dave";
        int num = 0;
        CombatTestHelper.AddAttackFeat(new AttackFeatData("Precise 10", 1.4f, -1f, 0f, 0f, 0f, 20, num, "Precise +10", 0f, "", "", "", "", "", ""));
        CombatTestHelper.AddAttackFeat(new AttackFeatData("Better Crit", 1.4f, -1f, 0f, 0f, 0f, 20, num, "Improved Critical +20", 0f, "", "", "", "", "", ""));
        CombatTestHelper.AddAttackFeat(new AttackFeatData("Rooted Attack", 1.4f, 10f, 0f, 0f, 0f, 20, num, "Stationary", 0f, "", "", "", "", "", ""));
        CombatTestHelper.AddAttackFeat(new AttackFeatData("Long Range", 1.4f, 10f, 0f, 0f, 0f, 20, num, "Long Range", 0f, "", "", "", "", "", ""));
        CombatTestHelper.AddAttackFeat(new AttackFeatData("Reduced Range", 1.4f, 10f, 0f, 0f, 0f, 20, num, "Reduced Range", 0f, "", "", "", "", "", ""));
        CombatTestHelper.AddAttackFeat(new AttackFeatData("Better Damage", 1.4f, 10f, 0f, 0f, 0f, 20, num, "Base Damage +20", 0f, "", "", "", "", "", ""));
        CombatTestHelper.AddAttackFeat(new AttackFeatData("Alt Defense/Resistance", 1.4f, -1f, 0f, 0f, 0f, 20, num, "Targets Fortitude, Fire Damage", 0f, "", "", "", "", "", ""));
        CombatTestHelper.AddAttackFeat(new AttackFeatData("Basic Attack", 1.4f, -1f, 0f, 0f, 0f, 20, num, "", 0f, "", "", "", "", "", ""));
        CombatTestHelper.LoadOffensiveFeats();
    }

    protected override void TearDown()
    {
        CombatTestHelper.ClearAllCombatStaticData();
    }

    [UUnitTestMethod]
    public void TestAltDefenseTarget()
    {
        OffensiveFeatData attackByName = OffensiveFeatData.GetAttackByName("Basic Attack");
        OffensiveFeatData data2 = OffensiveFeatData.GetAttackByName("Alt Defense/Resistance");
        UUnitAssert.True(attackByName.defenseTarget == DefenseType.Reflex, "Fail");
        UUnitAssert.True(data2.defenseTarget == DefenseType.Fortitude, "Fail");
    }

    [UUnitTestMethod]
    public void TestAltResistanceTarget()
    {
        OffensiveFeatData attackByName = OffensiveFeatData.GetAttackByName("Basic Attack");
        OffensiveFeatData data2 = OffensiveFeatData.GetAttackByName("Alt Defense/Resistance");
        UUnitAssert.True(attackByName.resistanceTarget == ResistanceType.Physical, "Fail");
        UUnitAssert.True(data2.resistanceTarget == ResistanceType.Fire, "Fail");
    }

    [UUnitTestMethod]
    public void TestAttackModBaseDamage()
    {
        OffensiveFeatData attackByName = OffensiveFeatData.GetAttackByName("Better Damage");
        UUnitAssert.True(attackByName.GetDamageBonus(0, this.albert, this.barry) == 20f, "Expected 20 bonus damage from Base Damage mod. Got: " + attackByName.GetDamageBonus(0, this.albert, this.barry));
    }

    [UUnitTestMethod]
    public void TestAttackModImprovedCritical()
    {
        OffensiveFeatData attackByName = OffensiveFeatData.GetAttackByName("Better Crit");
        UUnitAssert.True(attackByName.GetCriticalBonus(0, this.albert, this.barry) == 20, new object[] { attackByName.GetCriticalBonus(0, this.albert, this.barry), 20 });
    }

    [UUnitTestMethod]
    public void TestAttackModPrecise()
    {
        OffensiveFeatData attackByName = OffensiveFeatData.GetAttackByName("Precise 10");
        UUnitAssert.True(attackByName.GetAttackBonus(0, this.albert, this.barry) == 10, new object[] { attackByName.GetAttackBonus(0, this.albert, this.barry), 10 });
    }

    [UUnitTestMethod]
    public void TestAttackModRange()
    {
        OffensiveFeatData attackByName = OffensiveFeatData.GetAttackByName("Long Range");
        OffensiveFeatData data2 = OffensiveFeatData.GetAttackByName("Reduced Range");
        UUnitAssert.Equals((double) attackByName.GetRangeModifier(this.albert, this.barry), 1.5, 1E-06, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals((double) data2.GetRangeModifier(this.albert, this.barry), 0.5, 1E-06, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
    }

    [UUnitTestMethod]
    public void TestAttackModStationary()
    {
        UUnitAssert.True(OffensiveFeatData.GetAttackByName("Rooted Attack").rooted, "Expected 'Stationary' attack mod to set rooted flag.");
    }
}

