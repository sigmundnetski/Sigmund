﻿using System;

internal class TestSimpleKalman : UUnitTestCase
{
    [UUnitTestMethod]
    private void AccurateInitialValueAndOutliers()
    {
        double[] numArray = new double[] { 
            20.0, 23.0, 22.0, 21.0, 20.0, 19.0, 18.0, 17.0, 18.0, 19.0, 20.0, 21.0, 22.0, 23.0, 22.0, 21.0, 
            20.0, 19.0, 18.0, 17.0, 18.0, 19.0, 20.0, 21.0, 22.0, 0.0, 23.0, 22.0, 21.0, 20.0, 19.0, 18.0, 
            17.0, 18.0, 19.0, 20.0, 21.0, 22.0, 55.0, 23.0, 22.0, 21.0, 20.0, 19.0, 18.0, 17.0, 18.0, 19.0, 
            20.0, 21.0, 22.0, 0.0, 23.0, 22.0, 21.0, 20.0, 19.0, 18.0, 17.0, 18.0, 19.0, 20.0, 21.0, 22.0
         };
        double[] numArray2 = new double[numArray.Length];
        double expectedEstimate = 20.0;
        double precision = 0.86;
        SimpleKalman kalman = new SimpleKalman(expectedEstimate, 3.0);
        for (int i = 0; i < numArray.Length; i++)
        {
            kalman.Next(numArray[i]);
            numArray2[i] = kalman.Predict();
            if (i > 5)
            {
                UUnitAssert.Equals(expectedEstimate, numArray2[i], precision, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
            }
        }
    }

    [UUnitTestMethod]
    private void BadInitialValue()
    {
        double[] numArray = new double[] { 
            23.0, 22.0, 21.0, 20.0, 19.0, 18.0, 17.0, 18.0, 19.0, 20.0, 21.0, 22.0, 23.0, 22.0, 21.0, 20.0, 
            19.0, 18.0, 17.0, 18.0, 19.0, 20.0, 21.0, 22.0, 23.0, 22.0, 21.0, 20.0, 19.0, 18.0, 17.0, 18.0, 
            19.0, 20.0, 21.0, 22.0, 23.0, 22.0, 21.0, 20.0, 19.0, 18.0, 17.0, 18.0, 19.0, 20.0, 21.0, 22.0, 
            23.0, 22.0, 21.0, 20.0, 19.0, 18.0, 17.0, 18.0, 19.0, 20.0, 21.0, 22.0
         };
        double[] numArray2 = new double[numArray.Length];
        double num = 20.0;
        double expectedEstimate = 200.0;
        SimpleKalman kalman = new SimpleKalman(expectedEstimate, 3.0);
        double num3 = expectedEstimate - num;
        for (int i = 0; i < numArray.Length; i++)
        {
            kalman.Next(numArray[i]);
            numArray2[i] = kalman.Predict();
            UUnitAssert.True(num3 > (numArray2[i] - num), new object[] { "The estimate should converge to expected each step", num3, numArray2[i] - num });
            num3 = numArray2[i] - num;
        }
    }

    [UUnitTestMethod]
    private void LowVariance()
    {
        double[] numArray = new double[] { 
            23.0, 22.0, 21.0, 20.0, 19.0, 18.0, 17.0, 18.0, 19.0, 20.0, 21.0, 22.0, 23.0, 22.0, 21.0, 20.0, 
            19.0, 18.0, 17.0, 18.0, 19.0, 20.0, 21.0, 22.0, 23.0, 22.0, 21.0, 20.0, 19.0, 18.0, 17.0, 18.0, 
            19.0, 20.0, 21.0, 22.0, 23.0, 22.0, 21.0, 20.0, 19.0, 18.0, 17.0, 18.0, 19.0, 20.0, 21.0, 22.0, 
            23.0, 22.0, 21.0, 20.0, 19.0, 18.0, 17.0, 18.0, 19.0, 20.0, 21.0, 22.0
         };
        double[] numArray2 = new double[numArray.Length];
        double expectedEstimate = 20.0;
        double precision = 0.4;
        SimpleKalman kalman = new SimpleKalman(expectedEstimate, 0.1);
        for (int i = 0; i < numArray.Length; i++)
        {
            kalman.Next(numArray[i]);
            numArray2[i] = kalman.Predict();
            if (i > 5)
            {
                UUnitAssert.Equals(expectedEstimate, numArray2[i], precision, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
            }
        }
    }

    [UUnitTestMethod]
    private void RealStdDev()
    {
        double[] values = new double[] { 
            20.0, 23.0, 22.0, 21.0, 20.0, 19.0, 18.0, 17.0, 18.0, 19.0, 20.0, 21.0, 22.0, 23.0, 22.0, 21.0, 
            20.0, 19.0, 18.0, 17.0, 18.0, 19.0, 20.0, 21.0, 22.0, 23.0, 22.0, 21.0, 20.0, 19.0, 18.0, 17.0, 
            18.0, 19.0, 20.0, 21.0, 22.0, 23.0, 22.0, 21.0, 20.0, 19.0, 18.0, 17.0, 18.0, 19.0, 20.0, 21.0, 
            22.0, 23.0, 22.0, 21.0, 20.0, 19.0, 18.0, 17.0, 18.0, 19.0, 20.0, 21.0, 22.0
         };
        double setR = GUtil.CalculateStdDev(values);
        double[] numArray2 = new double[values.Length];
        double expectedEstimate = 20.0;
        double precision = 0.35;
        SimpleKalman kalman = new SimpleKalman(expectedEstimate, setR);
        for (int i = 0; i < values.Length; i++)
        {
            kalman.Next(values[i]);
            numArray2[i] = kalman.Predict();
            if (i > 5)
            {
                UUnitAssert.Equals(expectedEstimate, numArray2[i], precision, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
            }
        }
    }

    [UUnitTestMethod]
    private void WebsiteData()
    {
        double[] numArray = new double[] { 0.39, 0.5, 0.48, 0.29, 0.25, 0.32, 0.34, 0.48, 0.41, 0.45 };
        double[] numArray2 = new double[numArray.Length];
        double[] numArray3 = new double[] { 0.355, 0.424, 0.442, 0.405, 0.375, 0.365, 0.362, 0.377, 0.38, 0.387 };
        SimpleKalman kalman = new SimpleKalman(0.0, 0.1);
        for (int i = 0; i < numArray.Length; i++)
        {
            kalman.Next(numArray[i]);
            numArray2[i] = kalman.Predict();
            UUnitAssert.Equals(numArray3[i], numArray2[i], 0.002, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        }
    }
}

