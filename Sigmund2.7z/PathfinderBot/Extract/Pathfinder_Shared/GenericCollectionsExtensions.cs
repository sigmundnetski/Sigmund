﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

public static class GenericCollectionsExtensions
{
    public static bool AddIfMissing<T>(this Dictionary<T, T> dict, T key, T val)
    {
        bool flag = true;
        if (!dict.ContainsKey(key))
        {
            dict.Add(key, val);
            return flag;
        }
        return false;
    }

    public static bool AddIfMissing<T>(this HashSet<T> hash, T input, IEqualityComparer<T> comp = null)
    {
        bool flag = true;
        if (!hash.Contains<T>(input, comp))
        {
            hash.Add(input);
            return flag;
        }
        return false;
    }

    public static bool AddIfMissing<T>(this List<T> lst, T input, IEqualityComparer<T> comp = null)
    {
        bool flag = true;
        if (!lst.Contains<T>(input, comp))
        {
            lst.Add(input);
            return flag;
        }
        return false;
    }

    public static bool AddIfMissing<T, U>(this Dictionary<T, List<U>> dict, T key, U val, IEqualityComparer<U> comp = null)
    {
        bool flag = true;
        if (!dict.ContainsKey(key))
        {
            dict.Add(key, new List<U>());
        }
        if (!dict[key].Contains<U>(val, comp))
        {
            dict[key].Add(val);
            return flag;
        }
        return false;
    }
}

