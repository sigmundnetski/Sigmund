﻿using System;
using System.Runtime.CompilerServices;
using UnityEngine;

[RequireComponent(typeof(Collider))]
public class LocationTrigger : MonoBehaviour
{
    public static Callback EnterCallback = null;
    [NonSerialized, HideInInspector]
    private int locationId = 0;
    public string locationName;

    public void OnTriggerEnter(Collider other)
    {
        LocationTriggerData data;
        if ((this.locationId == 0) && LocationTriggerData.locationByName.TryGetValue(this.locationName.ToLower(), out data))
        {
            this.locationId = data.id;
        }
        if ((this.locationId != 0) && (EnterCallback != null))
        {
            EnterCallback(other.gameObject, this.locationId);
        }
    }

    public void Start()
    {
        LocationTriggerData data;
        if (null == EnterCallback)
        {
            MeshRenderer renderer = base.GetComponent<MeshRenderer>();
            if (renderer != null)
            {
                renderer.enabled = false;
            }
        }
        Collider component = base.GetComponent<Collider>();
        if (component == null)
        {
            GLog.LogError(new object[] { "LocationTrigger has no collider:", base.gameObject });
        }
        else if (!component.isTrigger)
        {
            GLog.LogError(new object[] { "LocationTrigger must be trigger-volume, not collision volume.", base.gameObject });
        }
        EntityCore.MoveToLayer(base.transform, 2);
        if ((this.locationId == 0) && LocationTriggerData.locationByName.TryGetValue(this.locationName.ToLower(), out data))
        {
            this.locationId = data.id;
        }
    }

    public delegate void Callback(GameObject other, int locationId);
}

