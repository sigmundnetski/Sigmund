﻿using System;
using System.Collections.Generic;

[LooseDependency(typeof(WeaponCategoryData))]
public class AnimationData : DataClass
{
    private static readonly string[] _mandatoryColumns = new string[] { "attack name", "mainhand", "offhand" };
    private static Dictionary<int, AnimationData> animationsById = new Dictionary<int, AnimationData>();
    private static Dictionary<string, AnimationData> animationsByName = new Dictionary<string, AnimationData>();
    public const string DEFAULT_ANIM = "DEFAULT_ANIM";
    private static readonly AnimationData INVALID_ANIM_DATA = new AnimationData(0, 0);
    public int mainhand;
    public int offhand;

    public AnimationData()
    {
        this.mainhand = 0;
        this.offhand = 0;
    }

    public AnimationData(int _mainhand, int _offhand)
    {
        this.mainhand = _mainhand;
        this.offhand = _offhand;
    }

    public static AnimationData GetById(int id)
    {
        if (id == 0)
        {
            GLog.LogWarning(new object[] { "Feat does not have valid animation data." });
            return INVALID_ANIM_DATA;
        }
        return animationsById[id];
    }

    public static AnimationData GetByName(string name)
    {
        AnimationData data;
        if (animationsByName.TryGetValue(name.ToLower(), out data))
        {
            return data;
        }
        GLog.LogWarning(new object[] { "Feat " + name + " does not have valid animation data." });
        return INVALID_ANIM_DATA;
    }

    public static void OnLoad(List<DataClass> objects)
    {
        animationsById.Clear();
        animationsByName.Clear();
        foreach (AnimationData data in objects)
        {
            animationsById.Add(data.id, data);
            animationsByName.Add(data.name, data);
        }
    }

    public override DataClass ParseRecord(int index)
    {
        int num;
        AnimationData data = new AnimationData();
        if (!DataClass.TryGetLCaseCellValue(DataClass.columnNamesToIndex["attack name"], index, out data.name))
        {
            return null;
        }
        DataClass.GetCellValue(DataClass.columnNamesToIndex["mainhand"], index, out data.mainhand);
        data.offhand = -1;
        if (DataClass.TryGetCellValue(DataClass.columnNamesToIndex["offhand"], index, out num))
        {
            data.offhand = num;
        }
        int num2 = -1;
        string output = string.Empty;
        WeaponCategoryData data2 = null;
        if (DataClass.columnNamesToIndex.TryGetValue("weapon category", out num2))
        {
            DataClass.TryGetLCaseCellValue(num2, index, out output);
            WeaponCategoryData.categoriesByName.TryGetValue(output, out data2);
        }
        if ((data2 == null) && !string.IsNullOrEmpty(output))
        {
            GLog.LogWarning(new object[] { "Unknown weapon category for animation [" + data.name + "].  Please change [" + output + "] to a valid weapon category." });
        }
        return data;
    }

    protected override IEnumerable<string> GetMandatoryColumns
    {
        get
        {
            return _mandatoryColumns;
        }
    }
}

