﻿using System;

public class BleedingDebuff : CombatStackBuff
{
    public BleedingDebuff() : base("Bleeding", Combat.Channel.Weakness, Combat.EffectType.Detrimental)
    {
        base.recoveryBonusType = RecoveryType.Bleeding;
    }

    public static BleedingDebuff Create()
    {
        return new BleedingDebuff();
    }

    public override CombatBuffVars Initialize(uint combatTick, CombatModifier mod, CombatVars target, int additionalDefense)
    {
        int resistanceBonus = target.GetResistanceBonus(ResistanceType.Physical);
        return base.Initialize(combatTick, mod, target, resistanceBonus);
    }

    public override void RecalculationPhase(CombatBuffVars buff, uint combatTick)
    {
        int num = -buff.stacks;
        int specific = buff.owner.tempDefenses.Channel(base.channel).GetSpecific(DefenseType.Fortitude);
        if (num < specific)
        {
            buff.owner.tempDefenses.Channel(base.channel).SetSpecific(DefenseType.Fortitude, num);
        }
        buff.owner.hitPointRBCV.SumBonus(base.channel, buff.stacks);
    }

    public override void ResolutionPhase(CombatBuffVars buff, uint combatTick)
    {
        if (combatTick >= buff.resolutionTime)
        {
            buff.resolutionTime += CombatData.singleton.roundTimeInTicks;
            buff.owner.ApplyDamage(CombatStackBuff.GetDotDamage(buff), buff.applierEntityId);
        }
    }
}

