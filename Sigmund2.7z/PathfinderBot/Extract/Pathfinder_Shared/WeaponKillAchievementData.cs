﻿using System;
using System.Collections.Generic;
using System.Linq;

[StrongDependency(typeof(AchievementCounterData)), StrongDependency(typeof(CategoryData)), NoFinalOutput]
public class WeaponKillAchievementData : GenericAchievementData
{
    private static readonly string[] _mandatoryColumns = new string[] { "counter name", "counter value", "weapon proficiency" };
    public int weaponProficiencyId;

    protected override void ParseCustomDetails(int rowIndex, ref AdvancementIndexedDataClass _output)
    {
        base.ParseCustomDetails(rowIndex, ref _output);
        WeaponKillAchievementData data = (WeaponKillAchievementData) _output;
        data.TryParseAsSingleCounter(DataClass.columnNamesToIndex["counter name"], rowIndex);
        bool flag = data.TryParseAsSingleCounterValue(DataClass.columnNamesToIndex["counter value"], rowIndex);
        if (data.linkedCounterIds.Length == 0)
        {
            DataClass.OutputErrorMessage(DataClass.columnNamesToIndex["counter name"], rowIndex, "Invalid Counter Name.");
        }
        if (!flag)
        {
            DataClass.OutputErrorMessage(DataClass.columnNamesToIndex["counter value"], rowIndex, "Counter value out of bounds (1-8000).");
        }
        DataClass.GetIdFromForeignName<WeaponProficiencyData>(DataClass.columnNamesToIndex["weapon proficiency"], rowIndex, out data.weaponProficiencyId);
    }

    protected override IEnumerable<string> GetMandatoryColumns
    {
        get
        {
            return base.GetMandatoryColumns.Concat<string>(_mandatoryColumns);
        }
    }
}

