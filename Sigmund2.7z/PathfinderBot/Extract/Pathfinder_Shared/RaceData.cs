﻿using System;
using System.Collections.Generic;

[StrongDependency(typeof(RaceColorData))]
public class RaceData : DataClass
{
    protected static readonly string[] _mandatoryColumns = new string[] { "race names", "display name", "abbreviation", "playable race?", "tab targetable", "atlasable" };
    public string abbreviation;
    public bool atlasable;
    public string displayName;
    public int[] eyeColorIds;
    public int[] hairColorIds;
    public EntityDefnData.PlayerFlag pcRace;
    public static List<RaceData> playableRaces = new List<RaceData>();
    public static Dictionary<string, RaceData> raceByAbbreviation = new Dictionary<string, RaceData>();
    public static Dictionary<int, RaceData> raceById = new Dictionary<int, RaceData>();
    public static Dictionary<string, RaceData> raceByName = new Dictionary<string, RaceData>();
    public int[] skinColorIds;
    public int[] suitColorIds;
    public bool tabTargetable;

    public static void OnLoad(List<DataClass> objects)
    {
        for (int i = 0; i < objects.Count; i++)
        {
            RaceData item = (RaceData) objects[i];
            raceById[item.id] = item;
            raceByName[item.name] = item;
            if (!string.IsNullOrEmpty(item.abbreviation))
            {
                raceByAbbreviation[item.abbreviation] = item;
            }
            if (item.IsUserPlayable)
            {
                playableRaces.Add(item);
            }
        }
    }

    public override DataClass ParseRecord(int rowIndex)
    {
        int num;
        RaceData data = new RaceData();
        if (!(DataClass.TryGetLCaseCellValue(DataClass.columnNamesToIndex["race names"], rowIndex, out data.name) && !string.IsNullOrEmpty(data.name.Trim())))
        {
            return null;
        }
        DataClass.GetCellValue(DataClass.columnNamesToIndex["display name"], rowIndex, out data.displayName);
        DataClass.GetLCaseCellValue(DataClass.columnNamesToIndex["abbreviation"], rowIndex, out data.abbreviation);
        DataClass.GetEnumCellValue<EntityDefnData.PlayerFlag>(DataClass.columnNamesToIndex["playable race?"], rowIndex, EntityDefnData.PlayerFlag.NOT_PLAYER, out data.pcRace);
        DataClass.TryGetCellValue(DataClass.columnNamesToIndex["atlasable"], rowIndex, out data.atlasable);
        DataClass.TryGetCellValue(DataClass.columnNamesToIndex["tab targetable"], rowIndex, out data.tabTargetable);
        if (DataClass.columnNamesToIndex.TryGetValue("skin colors", out num))
        {
            DataClass.TryGetIdsFromForeignNames<RaceColorData>(num, rowIndex, out data.skinColorIds);
        }
        if (DataClass.columnNamesToIndex.TryGetValue("hair colors", out num))
        {
            DataClass.TryGetIdsFromForeignNames<RaceColorData>(num, rowIndex, out data.hairColorIds);
        }
        if (DataClass.columnNamesToIndex.TryGetValue("eye colors", out num))
        {
            DataClass.TryGetIdsFromForeignNames<RaceColorData>(num, rowIndex, out data.eyeColorIds);
        }
        if (DataClass.columnNamesToIndex.TryGetValue("suit colors", out num))
        {
            DataClass.TryGetIdsFromForeignNames<RaceColorData>(num, rowIndex, out data.suitColorIds);
        }
        return data;
    }

    protected override IEnumerable<string> GetMandatoryColumns
    {
        get
        {
            return _mandatoryColumns;
        }
    }

    public bool IsUserPlayable
    {
        get
        {
            return ((this.pcRace == EntityDefnData.PlayerFlag.PUBLIC_PLAYER) || (GUtil.internalMode && (this.pcRace == EntityDefnData.PlayerFlag.INTERNAL_PLAYER)));
        }
    }
}

