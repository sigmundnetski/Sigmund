﻿using System;
using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Sequential)]
public struct GSQualifier
{
    public string target;
    public string condition;
    public GSQualifierType type;
    public GSQualifier(string aTarget, string aCondition, GSQualifierType aType)
    {
        this.target = aTarget;
        this.condition = aCondition;
        this.type = aType;
    }
}

