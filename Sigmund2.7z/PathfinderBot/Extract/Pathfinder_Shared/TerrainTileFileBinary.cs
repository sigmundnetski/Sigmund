﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class TerrainTileFileBinary
{
    [DataRestrict]
    public float[,,] Alphamaps;
    public int[,] Alphas;
    public GwDetailPrototype[] DetailProtos = null;
    public int[][,] Details;
    public GwEncounterLocation[] Encounters = null;
    public float[,] Heights;
    public float max1;
    public float max2;
    public float max3;
    public GwTileMetadata Meta;
    public GwPrefabInstance[] Prefabs = null;
    public GwSplatPrototype[] Splats = null;
    public TreeInstance[] TreeInstances = null;
    public GwTreePrototype[] TreeProtos = null;

    public void CreateFromTile(TerrainTile tile, TerrainDecorations decoration, Terrain trn, GenerateTextureNameCallback callback)
    {
        if (trn != null)
        {
            TerrainData terrainData = trn.terrainData;
            GwTileMetadata metadata = new GwTileMetadata {
                TileX = tile.TileX,
                TileZ = tile.TileZ,
                size = terrainData.size,
                baseMapResolution = terrainData.baseMapResolution,
                heightmapResolution = terrainData.heightmapResolution,
                alphamapResolution = terrainData.alphamapResolution,
                detailResolution = terrainData.detailResolution,
                matName = trn.materialTemplate.name
            };
            this.Meta = metadata;
            this.Heights = terrainData.GetHeights(0, 0, terrainData.heightmapWidth, terrainData.heightmapHeight);
            this.Alphamaps = terrainData.GetAlphamaps(0, 0, terrainData.alphamapWidth, terrainData.alphamapHeight);
            if (this.Alphamaps.GetLength(2) != 4)
            {
                GLog.LogError(new object[] { "The current alphamap array has too many splatmaps.  The maximum number of splatmaps we are targeting is 4." });
            }
            else
            {
                int num;
                int num2;
                this.max3 = 0f;
                this.max2 = 0f;
                this.max1 = 0f;
                for (num = 0; num < this.Alphamaps.GetLength(1); num++)
                {
                    num2 = 0;
                    while (num2 < this.Alphamaps.GetLength(0))
                    {
                        if (this.Alphamaps[num2, num, 3] > this.max3)
                        {
                            this.max3 = this.Alphamaps[num2, num, 3];
                        }
                        if (this.Alphamaps[num2, num, 2] > this.max2)
                        {
                            this.max2 = this.Alphamaps[num2, num, 2];
                        }
                        if (this.Alphamaps[num2, num, 1] > this.max1)
                        {
                            this.max1 = this.Alphamaps[num2, num, 1];
                        }
                        num2++;
                    }
                }
                this.Alphas = new int[this.Alphamaps.GetLength(0), this.Alphamaps.GetLength(1)];
                for (num = 0; num < this.Alphamaps.GetLength(1); num++)
                {
                    num2 = 0;
                    while (num2 < this.Alphamaps.GetLength(0))
                    {
                        byte num3 = (this.max3 == 0f) ? ((byte) 0f) : ((byte) ((this.Alphamaps[num2, num, 3] / this.max3) * 255f));
                        byte num4 = (this.max2 == 0f) ? ((byte) 0f) : ((byte) ((this.Alphamaps[num2, num, 2] / this.max2) * 255f));
                        byte num5 = (this.max1 == 0f) ? ((byte) 0f) : ((byte) ((this.Alphamaps[num2, num, 1] / this.max1) * 255f));
                        this.Alphas[num2, num] = ((num3 << 0x10) | (num4 << 8)) | num5;
                        num2++;
                    }
                }
                this.Details = new int[terrainData.detailPrototypes.Length][,];
                for (num2 = 0; num2 < terrainData.detailPrototypes.Length; num2++)
                {
                    this.Details[num2] = terrainData.GetDetailLayer(0, 0, terrainData.detailWidth, terrainData.detailHeight, num2);
                }
                this.DetailProtos = (from inst in trn.terrainData.detailPrototypes select GwDetailPrototype.FromDetailPrototype(inst, callback)).ToArray<GwDetailPrototype>();
                this.TreeProtos = (from inst in trn.terrainData.treePrototypes select GwTreePrototype.FromTreePrototype(inst)).ToArray<GwTreePrototype>();
                this.Splats = (from inst in trn.terrainData.splatPrototypes select GwSplatPrototype.FromSplatPrototype(inst, callback)).ToArray<GwSplatPrototype>();
                this.TreeInstances = trn.terrainData.treeInstances;
                List<GwEncounterLocation> list = new List<GwEncounterLocation>(from inst in tile.GetComponentsInChildren<EncounterLocation>(true) select GwEncounterLocation.FromEncounterLocation(inst, false));
                List<GwEncounterLocation> collection = null;
                if (decoration != null)
                {
                    collection = new List<GwEncounterLocation>(from inst in decoration.GetComponentsInChildren<EncounterLocation>(true) select GwEncounterLocation.FromEncounterLocation(inst, true));
                }
                if ((collection != null) && (collection.Count > 0))
                {
                    list.AddRange(collection);
                }
                List<GwPrefabInstance> list3 = new List<GwPrefabInstance>(from inst in tile.GetComponentsInChildren<PrefabInstance>(true) select GwPrefabInstance.FromPrefabInstance(inst, false));
                List<GwPrefabInstance> list4 = null;
                if (decoration != null)
                {
                    list4 = new List<GwPrefabInstance>(from inst in decoration.GetComponentsInChildren<PrefabInstance>(true) select GwPrefabInstance.FromPrefabInstance(inst, true));
                }
                if ((list4 != null) && (list4.Count > 0))
                {
                    list3.AddRange(list4);
                }
                this.Encounters = list.ToArray();
                this.Prefabs = list3.ToArray();
            }
        }
    }

    public void Restore()
    {
        this.Alphamaps = new float[this.Alphas.GetLength(0), this.Alphas.GetLength(1), 4];
        for (int i = 0; i < this.Alphas.GetLength(1); i++)
        {
            for (int j = 0; j < this.Alphas.GetLength(0); j++)
            {
                float a = (((float) ((this.Alphas[j, i] & 0xff0000) >> 0x10)) / 255f) * this.max3;
                float num4 = (((float) ((this.Alphas[j, i] & 0xff00) >> 8)) / 255f) * this.max2;
                float num5 = (((float) (this.Alphas[j, i] & 0xff)) / 255f) * this.max1;
                float b = 1f;
                this.Alphamaps[j, i, 3] = Mathf.Min(a, b);
                b = Mathf.Max((float) 0f, (float) (b - this.Alphamaps[j, i, 3]));
                this.Alphamaps[j, i, 2] = Mathf.Min(num4, b);
                b = Mathf.Max((float) 0f, (float) (b - this.Alphamaps[j, i, 2]));
                this.Alphamaps[j, i, 1] = Mathf.Min(num5, b);
                b = Mathf.Max((float) 0f, (float) (b - this.Alphamaps[j, i, 1]));
                this.Alphamaps[j, i, 0] = b;
            }
        }
    }
}

