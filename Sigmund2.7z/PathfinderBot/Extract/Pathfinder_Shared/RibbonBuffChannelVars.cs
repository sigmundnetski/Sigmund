﻿using GNetwork;
using System;

public class RibbonBuffChannelVars : IDataCopyable<RibbonBuffChannelVars>, CustomSerializer<RibbonBuffChannelVars>
{
    public int buffAlchemical;
    public int buffExtraordinary;
    public int buffSupernatural;
    public int debuffSubmission;
    public int debuffTorment;
    public int debuffWeakness;
    public static readonly Combat.Channel[] RIBBON_CHANNELS;

    static RibbonBuffChannelVars()
    {
        Combat.Channel[] channelArray = new Combat.Channel[6];
        channelArray[1] = Combat.Channel.Extraordinary;
        channelArray[2] = Combat.Channel.Supernatural;
        channelArray[3] = Combat.Channel.Submission;
        channelArray[4] = Combat.Channel.Torment;
        channelArray[5] = Combat.Channel.Weakness;
        RIBBON_CHANNELS = channelArray;
    }

    public void Clear()
    {
        this.buffAlchemical = this.buffExtraordinary = this.buffSupernatural = this.debuffSubmission = this.debuffTorment = this.debuffWeakness = 0;
    }

    public void DataCopyTo(ref RibbonBuffChannelVars target, byte syncTargetLevel)
    {
        target.buffAlchemical = this.buffAlchemical;
        target.buffExtraordinary = this.buffExtraordinary;
        target.buffSupernatural = this.buffSupernatural;
        target.debuffSubmission = this.debuffSubmission;
        target.debuffTorment = this.debuffTorment;
        target.debuffWeakness = this.debuffWeakness;
    }

    public bool DataEquals(RibbonBuffChannelVars other, byte syncTargetLevel)
    {
        return (((((other != null) && (other.buffAlchemical == this.buffAlchemical)) && ((other.buffExtraordinary == this.buffExtraordinary) && (other.buffSupernatural == this.buffSupernatural))) && ((other.debuffSubmission == this.debuffSubmission) && (other.debuffTorment == this.debuffTorment))) && (other.debuffWeakness == this.debuffWeakness));
    }

    public int GetBonus(Combat.Channel channel)
    {
        int num = 0;
        switch (channel)
        {
            case Combat.Channel.Alchemical:
                return this.buffAlchemical;

            case Combat.Channel.Extraordinary:
                return this.buffExtraordinary;

            case Combat.Channel.Supernatural:
                return this.buffSupernatural;

            case Combat.Channel.Morale:
            case Combat.Channel.Intentional:
                return num;

            case Combat.Channel.Submission:
                return this.debuffSubmission;

            case Combat.Channel.Torment:
                return this.debuffTorment;

            case Combat.Channel.Weakness:
                return this.debuffWeakness;
        }
        return num;
    }

    public void Read(IBitBufferRead buffer, ref RibbonBuffChannelVars prev)
    {
        if (prev == null)
        {
            prev = new RibbonBuffChannelVars();
        }
        prev.buffAlchemical = buffer.PopInt();
        prev.buffExtraordinary = buffer.PopInt();
        prev.buffSupernatural = buffer.PopInt();
        prev.debuffSubmission = buffer.PopInt();
        prev.debuffTorment = buffer.PopInt();
        prev.debuffWeakness = buffer.PopInt();
    }

    public void SumBonus(Combat.Channel channel, int value)
    {
        value = Math.Abs(value);
        switch (channel)
        {
            case Combat.Channel.Alchemical:
                this.buffAlchemical += value;
                break;

            case Combat.Channel.Extraordinary:
                this.buffExtraordinary += value;
                break;

            case Combat.Channel.Supernatural:
                this.buffSupernatural += value;
                break;

            case Combat.Channel.Submission:
                this.debuffSubmission += value;
                break;

            case Combat.Channel.Torment:
                this.debuffTorment += value;
                break;

            case Combat.Channel.Weakness:
                this.debuffWeakness += value;
                break;
        }
    }

    public override string ToString()
    {
        return string.Concat(new object[] { "RBCV: (", this.buffAlchemical, ",", this.buffExtraordinary, ",", this.buffSupernatural, ") (", this.debuffSubmission, ",", this.debuffTorment, ",", this.debuffWeakness, ")" });
    }

    public void Write(IBitBufferWrite buffer, RibbonBuffChannelVars prev)
    {
        buffer.PushInt(this.buffAlchemical);
        buffer.PushInt(this.buffExtraordinary);
        buffer.PushInt(this.buffSupernatural);
        buffer.PushInt(this.debuffSubmission);
        buffer.PushInt(this.debuffTorment);
        buffer.PushInt(this.debuffWeakness);
    }
}

