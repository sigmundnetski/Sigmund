﻿using System;

public class InterruptDebuff : CombatInstantBuff
{
    private const uint INTERRUPT_FAILURE_PERCENT = 30;
    private const string MIND_BLANK_MOD = "Mind Blank +10 to Self";
    private static CombatModifier[] mindBlankCombatMod = CombatModifier.Parse("Mind Blank +10 to Self");

    public InterruptDebuff() : base("Interrupt", Combat.Channel.None, Combat.EffectType.Detrimental)
    {
    }

    public static InterruptDebuff Create()
    {
        return new InterruptDebuff();
    }

    public override CombatBuffVars Initialize(uint combatTick, CombatModifier mod, CombatVars target, int additionalDefense)
    {
        CombatBuffVars stack = CombatBuff.GetStack(target, CombatConstants.Stack.MIND_BLANK);
        int stacks = 0;
        if (stack != null)
        {
            stacks = stack.stacks;
        }
        return base.Initialize(combatTick, mod, target, stacks);
    }

    public override void TimePhase(CombatBuffVars buff, uint combatTick)
    {
        buff.effectApplied = true;
        if ((buff.successPercentage > 30) && (buff.owner.featState == CombatVars.FeatState.Interruption))
        {
            buff.owner.CancelFeat(CombatVars.FeatFailure.Interrupted);
        }
        CombatEffect item = new CombatEffect(mindBlankCombatMod, buff.owner, buff.owner, CombatEffect.TargetType.ATTACKER, Combat.EffectType.Neutral);
        buff.owner.combatEffects.Enqueue(item);
    }
}

