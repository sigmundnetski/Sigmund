﻿using System;

public class SourceFileData
{
    public string crc;
    public string filename;
    public string sheetname;

    public SourceFileData()
    {
        this.filename = string.Empty;
        this.crc = string.Empty;
        this.sheetname = string.Empty;
    }

    public SourceFileData(string file, string crchash, string sheet)
    {
        this.filename = file;
        this.crc = crchash;
        this.sheetname = sheet;
    }

    public bool Equals(SourceFileData other)
    {
        if (object.ReferenceEquals(this, other))
        {
            return true;
        }
        if (object.ReferenceEquals(other, null))
        {
            return false;
        }
        bool flag = true;
        return (((flag && (this.filename.ToLower() == other.filename.ToLower())) && (this.crc == other.crc)) && (this.sheetname.ToLower() == other.sheetname.ToLower()));
    }

    public override bool Equals(object obj)
    {
        if (obj == null)
        {
            return false;
        }
        return this.Equals((SourceFileData) obj);
    }

    public override int GetHashCode()
    {
        return base.GetHashCode();
    }

    public static bool operator ==(SourceFileData a, SourceFileData b)
    {
        if (object.ReferenceEquals(a, b))
        {
            return true;
        }
        if (object.ReferenceEquals(a, null) || object.ReferenceEquals(b, null))
        {
            return false;
        }
        return a.Equals(b);
    }

    public static bool operator ==(SourceFileData a, object b)
    {
        if (object.ReferenceEquals(a, b))
        {
            return true;
        }
        if (object.ReferenceEquals(a, null) || object.ReferenceEquals(b, null))
        {
            return false;
        }
        return a.Equals((SourceFileData) b);
    }

    public static bool operator !=(SourceFileData a, SourceFileData b)
    {
        return !a.Equals(b);
    }

    public static bool operator !=(SourceFileData a, object b)
    {
        return !a.Equals((SourceFileData) b);
    }

    public override string ToString()
    {
        return (base.ToString() + "::" + this.filename + "_" + this.crc + "_" + this.sheetname);
    }
}

