﻿using System;
using System.Runtime.InteropServices;

public class AttunedResistantBuff : CombatTimedBuff
{
    private static string[] BUFF_NAMES = new string[] { " Energy Attuned", " Energy Resistant" };
    private static string[] RESIST_NAMES = new string[] { "Physical", "Fire", "Cold", "Electric", "Sonic", "Acid", "Negative", "Holy", "Force", "Psychic", "Critical" };
    private static int[] RESISTANCE_BONUS = new int[] { 4, 12 };

    public AttunedResistantBuff() : base("AttunedResistant", Combat.Channel.Supernatural, Combat.EffectType.Beneficial)
    {
    }

    public static AttunedResistantBuff Create()
    {
        return new AttunedResistantBuff();
    }

    private void GetIndices(CombatConstants.Buff buff, out int index0, out int index1)
    {
        index0 = index1 = 0;
        if ((buff == CombatConstants.Buff.ATTUNED_PHYSICAL) || (buff == CombatConstants.Buff.RESISTANT_PHYSICAL))
        {
            index0 = 0;
        }
        else if ((buff == CombatConstants.Buff.ATTUNED_FIRE) || (buff == CombatConstants.Buff.RESISTANT_FIRE))
        {
            index0 = 1;
        }
        else if ((buff == CombatConstants.Buff.ATTUNED_COLD) || (buff == CombatConstants.Buff.RESISTANT_COLD))
        {
            index0 = 2;
        }
        else if ((buff == CombatConstants.Buff.ATTUNED_ELECTRIC) || (buff == CombatConstants.Buff.RESISTANT_ELECTRIC))
        {
            index0 = 3;
        }
        else if ((buff == CombatConstants.Buff.ATTUNED_SONIC) || (buff == CombatConstants.Buff.RESISTANT_SONIC))
        {
            index0 = 4;
        }
        else if ((buff == CombatConstants.Buff.ATTUNED_ACID) || (buff == CombatConstants.Buff.RESISTANT_ACID))
        {
            index0 = 5;
        }
        else if ((buff == CombatConstants.Buff.ATTUNED_NEGATIVE) || (buff == CombatConstants.Buff.RESISTANT_NEGATIVE))
        {
            index0 = 6;
        }
        else if ((buff == CombatConstants.Buff.ATTUNED_HOLY) || (buff == CombatConstants.Buff.RESISTANT_HOLY))
        {
            index0 = 7;
        }
        else if ((buff == CombatConstants.Buff.ATTUNED_FORCE) || (buff == CombatConstants.Buff.RESISTANT_FORCE))
        {
            index0 = 8;
        }
        else if ((buff == CombatConstants.Buff.ATTUNED_PSYCHIC) || (buff == CombatConstants.Buff.RESISTANT_PSYCHIC))
        {
            index0 = 9;
        }
        else if ((buff == CombatConstants.Buff.ATTUNED_CRITICAL) || (buff == CombatConstants.Buff.RESISTANT_CRITICAL))
        {
            index0 = 10;
        }
        if ((((((buff == CombatConstants.Buff.ATTUNED_PHYSICAL) || (buff == CombatConstants.Buff.ATTUNED_FIRE)) || ((buff == CombatConstants.Buff.ATTUNED_COLD) || (buff == CombatConstants.Buff.ATTUNED_ELECTRIC))) || (((buff == CombatConstants.Buff.ATTUNED_SONIC) || (buff == CombatConstants.Buff.ATTUNED_ACID)) || ((buff == CombatConstants.Buff.ATTUNED_NEGATIVE) || (buff == CombatConstants.Buff.ATTUNED_HOLY)))) || ((buff == CombatConstants.Buff.ATTUNED_FORCE) || (buff == CombatConstants.Buff.ATTUNED_PSYCHIC))) || (buff == CombatConstants.Buff.ATTUNED_CRITICAL))
        {
            index1 = 0;
        }
        else
        {
            index1 = 1;
        }
    }

    public override string GetLogString(CombatModifier mod, CombatEffect effect, int defenseBonus)
    {
        uint num;
        float num2;
        int num3;
        int num4;
        this.GetDuration(mod, effect, defenseBonus, out num, out num2);
        this.GetIndices(mod.buff, out num3, out num4);
        return GUtil.GetQuickText().Append(RESIST_NAMES[num3]).Append(BUFF_NAMES[num4]).Append(" (").Append(CombatCore.SecondsFromTicks(num)).Append(" seconds)").ToString();
    }

    public override CombatBuffVars Initialize(uint combatTick, CombatModifier mod, CombatVars target, int additionalDefense)
    {
        int num;
        int num2;
        CombatBuffVars vars = base.Initialize(combatTick, mod, target, additionalDefense);
        this.GetIndices(mod.buff, out num, out num2);
        vars.value0 = num;
        vars.value1 = num2;
        vars.basicName = RESIST_NAMES[vars.value0] + BUFF_NAMES[vars.value1];
        vars.name = vars.basicName;
        return vars;
    }

    public override void RecalculationPhase(CombatBuffVars buff, uint combatTick)
    {
        int num = buff.owner.tempResistances.Channel(base.channel).Get((ResistanceType) ((byte) buff.value0));
        if (RESISTANCE_BONUS[buff.value1] > num)
        {
            buff.owner.tempResistances.Channel(base.channel).Set((ResistanceType) ((byte) buff.value0), RESISTANCE_BONUS[buff.value1]);
        }
    }
}

