﻿using System;
using System.Collections.Generic;

[NoFinalOutput, StrongDependency(typeof(ItemCategoryData))]
public class CurrencyItemData : BasicItemData
{
    private static readonly string[] _mandatoryColumns = new string[] { "item name", "tier", "quality", "encumbrance", "display name", "code name", "icon file name", "description", "category", "value", "upgradable" };
    public static int[] allCurrencyDataIds;
    public static CurrencyItemData[] sortedHighestToLowest;
    public ulong value;

    internal static void IndexCurrency(CurrencyItemData[] setItems)
    {
        allCurrencyDataIds = new int[setItems.Length];
        for (int i = 0; i < setItems.Length; i++)
        {
            allCurrencyDataIds[i] = setItems[i].id;
        }
        sortedHighestToLowest = new CurrencyItemData[setItems.Length];
        Array.Copy(setItems, sortedHighestToLowest, setItems.Length);
        Array.Sort<CurrencyItemData>(sortedHighestToLowest, new Comparison<CurrencyItemData>(CurrencyItemData.SortDenoms));
    }

    public override DataClass ParseRecord(int rowIndex)
    {
        string str;
        DataClass.GetLCaseCellValue(DataClass.columnNamesToIndex["item name"], rowIndex, out str);
        if (string.IsNullOrEmpty(str))
        {
            return null;
        }
        CurrencyItemData data = new CurrencyItemData {
            slot = BasicItemData.ItemSlot.NONE
        };
        DataClass.GetCellValue(DataClass.columnNamesToIndex["tier"], rowIndex, out data.tier);
        DataClass.GetCellValue(DataClass.columnNamesToIndex["quality"], rowIndex, out data.baseQuality);
        DataClass.GetCellValue(DataClass.columnNamesToIndex["description"], rowIndex, out data.description);
        DataClass.GetCellValue(DataClass.columnNamesToIndex["encumbrance"], rowIndex, out data.encumbrance);
        DataClass.GetCellValue(DataClass.columnNamesToIndex["display name"], rowIndex, out data.displayName);
        DataClass.GetLCaseCellValue(DataClass.columnNamesToIndex["code name"], rowIndex, out data.name);
        DataClass.GetCellValue(DataClass.columnNamesToIndex["icon file name"], rowIndex, out data.icon);
        uint output = 0;
        DataClass.GetCellValue(DataClass.columnNamesToIndex["value"], rowIndex, out output);
        data.value = output;
        if (!DataClass.TryGetCellValue(DataClass.columnNamesToIndex["upgradable"], rowIndex, out data.upgradable))
        {
            data.upgradable = true;
        }
        return data;
    }

    private static int SortDenoms(CurrencyItemData lhs, CurrencyItemData rhs)
    {
        if (lhs.value > rhs.value)
        {
            return -1;
        }
        if (lhs.value < rhs.value)
        {
            return 1;
        }
        return 0;
    }

    protected override IEnumerable<string> GetMandatoryColumns
    {
        get
        {
            return _mandatoryColumns;
        }
    }
}

