﻿using System;

internal class GFTestNestedRestrictionLods2
{
    [DataSyncTo(1)]
    public GFTestNestedRestrictionLodsChild child;
    public int id;
    public GFTestRestrictedClass restrictedChild;
}

