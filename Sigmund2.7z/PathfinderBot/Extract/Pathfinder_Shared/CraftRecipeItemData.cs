﻿using System;
using System.Collections.Generic;

[StrongDependency(typeof(ItemCategoryData))]
public class CraftRecipeItemData : BasicItemData
{
    private static readonly string[] _mandatoryColumns = new string[] { "name", "encumbrance", "description", "display name", "tier", "quality", "linked achievement flag", "feat", "rank", "icon file name", "category", "upgradable" };
    public int achievementFlagId;
    public int requiredFeatAdvId;
    public byte requiredFeatRank;

    public static CraftRecipeItemData NewUnittestItem(string recipeItemName, int flagId, int featAdvId, byte rank)
    {
        CraftRecipeItemData data;
        data = new CraftRecipeItemData {
            name = recipeItemName.ToLower(),
            id = DataClass.GenerateId(data.name),
            slot = BasicItemData.ItemSlot.NONE,
            encumbrance = 0.01f,
            description = "Some test item",
            displayName = recipeItemName,
            tier = 1,
            baseQuality = 10,
            requiredFeatAdvId = featAdvId,
            requiredFeatRank = rank,
            achievementFlagId = flagId
        };
        ItemDatabase.itemById[data.id] = data;
        ItemDatabase.itemByName[data.name] = data;
        return data;
    }

    public override DataClass ParseRecord(int rowIndex)
    {
        string str;
        DataClass.GetLCaseCellValue(DataClass.columnNamesToIndex["name"], rowIndex, out str);
        if (!string.IsNullOrEmpty(str))
        {
            string str2;
            AchievementFlagData data2;
            CraftRecipeItemData data = new CraftRecipeItemData {
                name = str,
                slot = BasicItemData.ItemSlot.NONE
            };
            bool flag = true;
            flag &= DataClass.GetCellValue(DataClass.columnNamesToIndex["encumbrance"], rowIndex, out data.encumbrance);
            DataClass.TryGetCellValue(DataClass.columnNamesToIndex["description"], rowIndex, out data.description);
            flag &= DataClass.GetCellValue(DataClass.columnNamesToIndex["display name"], rowIndex, out data.displayName);
            flag &= DataClass.GetCellValue(DataClass.columnNamesToIndex["tier"], rowIndex, out data.tier);
            flag &= DataClass.GetCellValue(DataClass.columnNamesToIndex["quality"], rowIndex, out data.baseQuality);
            flag &= DataClass.GetIdFromForeignName<FeatAdvancementData>(DataClass.columnNamesToIndex["feat"], rowIndex, out data.requiredFeatAdvId);
            flag &= DataClass.GetCellValue(DataClass.columnNamesToIndex["rank"], rowIndex, out data.requiredFeatRank);
            DataClass.GetCellValue(DataClass.columnNamesToIndex["icon file name"], rowIndex, out data.icon);
            DataClass.TryGetIdFromForeignName<ItemCategoryData>(DataClass.columnNamesToIndex["category"], rowIndex, out data.categoryId);
            DataClass.GetLCaseCellValue(DataClass.columnNamesToIndex["linked achievement flag"], rowIndex, out str2);
            bool flag2 = AchievementFlagData.flagsBySlotName.TryGetValue(str2, out data2);
            data.achievementFlagId = flag2 ? data2.id : 0;
            if (!flag2)
            {
                DataClass.OutputErrorMessage(DataClass.columnNamesToIndex["linked achievement flag"], rowIndex, "Failed to parse flag: " + str2);
            }
            flag &= flag2;
            if (!DataClass.TryGetCellValue(DataClass.columnNamesToIndex["upgradable"], rowIndex, out data.upgradable))
            {
                data.upgradable = true;
            }
            if (flag)
            {
                return data;
            }
        }
        return null;
    }

    protected override IEnumerable<string> GetMandatoryColumns
    {
        get
        {
            return _mandatoryColumns;
        }
    }
}

