﻿using System;
using System.Collections.Generic;
using System.Linq;

[LooseDependency(typeof(KeywordData)), NoFinalOutput, LooseDependency(typeof(OffensiveFeatData))]
public class WondrousItemData : GearItemData
{
    protected static readonly string[] _mandatoryWondrousColumns = new string[] { "base feat", "prerequisite", "stack limit", "destroy on use" };
    private int abilityScoreId;
    private byte abilityScoreLevel;
    public bool destroyOnUse;
    public int featId;
    public byte stackLimit;

    public WondrousItemData()
    {
    }

    public WondrousItemData(string name_, string[] keywords, string featName, byte stackLimit_, bool destroy, byte tier_) : base(name_, BasicItemData.ItemSlot.WONDROUS, keywords)
    {
        this.featId = OffensiveFeatData.AttackIdFromName(featName);
        this.stackLimit = stackLimit_;
        this.destroyOnUse = destroy;
        base.tier = tier_;
    }

    public bool Equippable(Entity entity)
    {
        AbilityScoreData data;
        return (!AbilityScoreData.scoreById.TryGetValue(this.abilityScoreId, out data) || (entity.advancementVars.GetAbilityScore(data.scoreIndex) >= this.abilityScoreLevel));
    }

    public override bool HasDurability()
    {
        return !this.destroyOnUse;
    }

    private void ParseAbilityPrereq(string source)
    {
        AbilityScoreData data;
        List<GSStatement> list = GoblinSpec.Parse(source);
        if (list.Count != 1)
        {
            throw new ParseException("Can only have 1 prerequisite. Found " + list.Count);
        }
        GSStatement statement = list[0];
        if (!AbilityScoreData.scoreByName.TryGetValue(statement.statement, out data))
        {
            throw new ParseException("Could not find ability in AbilityScoreData: " + statement.statement);
        }
        this.abilityScoreId = data.id;
        this.abilityScoreLevel = CombatModifier.ParseByteParameter(statement);
        if (this.abilityScoreLevel > data.maxValue)
        {
            throw new ParseException(string.Concat(new object[] { "Ability prerequisite for ", statement.statement, " cannot be higher than ", data.maxValue }));
        }
        if (statement.parameters.Count > 0)
        {
            throw new ParseException("Unknown parameter for prerequisite: " + statement.statement);
        }
        if (statement.qualifiers.Count > 0)
        {
            throw new ParseException("Unknown qualifier for prerequisite: " + statement.statement);
        }
    }

    private void ParseAbilityPrereqWithError(string prereq)
    {
        try
        {
            if (!string.IsNullOrEmpty(prereq))
            {
                this.ParseAbilityPrereq(prereq);
            }
        }
        catch (ParseException exception)
        {
            DataClass.OutputErrorMessage((("\n" + "  " + base.name + ": GoblinSpec parsing error!\n") + "     Prerequisite: " + prereq + "\n") + "    >>ERROR: " + exception.Message + "\n");
        }
    }

    public override DataClass ParseRecord(int index)
    {
        int num;
        GearItemData data = new WondrousItemData();
        base.ParseRecord(ref data, index);
        if (data == null)
        {
            return null;
        }
        WondrousItemData data2 = (WondrousItemData) data;
        if (DataClass.columnNamesToIndex.TryGetValue("base feat", out num))
        {
            string str;
            DataClass.GetCellValue(num, index, out str);
            data2.featId = OffensiveFeatData.AttackIdFromName(str);
            OffensiveFeatData attackById = OffensiveFeatData.GetAttackById(data2.featId);
            if (attackById == null)
            {
                DataClass.OutputErrorMessage(num, index, "Unknown feat: '" + str + "'");
            }
            else if (attackById.form != FeatData.FeatForm.Wondrous)
            {
                DataClass.OutputErrorMessage(num, index, str + " has invalid feat form. Change it to Wondrous.");
            }
            else
            {
                data2.featId = attackById.id;
            }
        }
        if (DataClass.columnNamesToIndex.TryGetValue("stack limit", out num))
        {
            DataClass.GetCellValue(num, index, out data2.stackLimit);
        }
        if (DataClass.columnNamesToIndex.TryGetValue("destroy on use", out num))
        {
            DataClass.GetCellValue(num, index, out data2.destroyOnUse);
        }
        if (!data2.destroyOnUse)
        {
            if (DataClass.columnNamesToIndex.TryGetValue("durability", out num))
            {
                DataClass.GetCellValue(num, index, out data2.durability);
            }
            else
            {
                DataClass.OutputErrorMessage(num, index, string.Concat(new object[] { "Durability cannot be zero: ", data2.name, ", ", data2.slot }));
            }
        }
        if (DataClass.columnNamesToIndex.TryGetValue("prerequisite", out num))
        {
            string str2;
            DataClass.GetCellValue(num, index, out str2);
            data2.ParseAbilityPrereqWithError(str2);
        }
        return data2;
    }

    protected override IEnumerable<string> GetMandatoryColumns
    {
        get
        {
            return GearItemData._mandatoryColumns.Concat<string>(_mandatoryWondrousColumns);
        }
    }
}

