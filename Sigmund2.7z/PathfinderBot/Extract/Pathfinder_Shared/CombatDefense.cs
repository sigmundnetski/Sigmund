﻿using System;

public class CombatDefense : IDataCopyable<CombatDefense>
{
    public int[] defense = new int[4];

    public void Clear()
    {
        for (int i = 0; i < this.defense.Length; i++)
        {
            this.defense[i] = 0;
        }
    }

    public void DataCopyTo(ref CombatDefense target, byte syncTargetLevel)
    {
        if (object.ReferenceEquals(target, null))
        {
            target = new CombatDefense();
        }
        DataSerializerUtils.DataCopyField<int>(this.defense, ref target.defense);
    }

    public bool DataEquals(CombatDefense target, byte syncTargetLevel)
    {
        if (object.ReferenceEquals(target, null))
        {
            return false;
        }
        return SparseArray.DeepEqualsWithIndex<int>(target.defense, this.defense);
    }

    public int GetSpecific(DefenseType defenseType)
    {
        return this.defense[(int) defenseType];
    }

    public int GetTotal(DefenseType defenseType)
    {
        int num = this.defense[0];
        if (defenseType == DefenseType.Base)
        {
            return num;
        }
        return (num + this.defense[(int) defenseType]);
    }

    public void SetSpecific(DefenseType defenseType, int value)
    {
        this.defense[(int) defenseType] = value;
    }
}

