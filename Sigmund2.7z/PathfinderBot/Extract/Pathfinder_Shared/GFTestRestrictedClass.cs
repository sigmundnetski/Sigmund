﻿using System;

[DataRestrict]
internal class GFTestRestrictedClass
{
    public int id;
}

