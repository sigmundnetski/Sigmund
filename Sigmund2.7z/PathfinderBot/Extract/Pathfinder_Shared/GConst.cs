﻿using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

public class GConst
{
    private static string _loggingFolder = "logs";
    public static readonly int[] aBunchOfPrimes = new int[] { 
        0x1b7bd, 0x2d245, 0xe8cf9, 0x2bf21, 0x4c567, 0x1bfa1, 0x18737, 0x1b20f, 0xf3fa3, 0x18af3, 0x20047, 0xc90fb, 0xf3a67, 0x2f5a5, 0xa3271, 0x1db3d, 
        0x33115, 0x2382b, 0x2f1f5, 0x1a16d, 0x22f03, 0xd7135, 0x72217, 0x4ef05, 0x1d539, 0x5a655, 0xc91f7, 0x268eb, 0x32693, 0x1e241, 0x39131, 0x1a951, 
        0xd04db, 0x40e01, 0x1ebf5, 0xb17ed, 0x18af7, 0x4a1e9, 0x5b9b7, 0x2e525, 0x7c513, 0x2399f, 0x18e29, 0x4ee33, 0x296db, 0x87d19, 0x1babd, 0x61a9f, 
        0x4aecd, 0xdcbb5
     };
    public const ushort ACCOUNT_CHARACTER_LIMIT = 3;
    public const AutorunType AUTORUN = AutorunType.FORWARD;
    public const float BAD_FPS = 10f;
    public static readonly int BORDER_THRESHOLD = 80;
    public const ushort CHAT_AUTHORITY_ID = 1;
    public const float CLICK_TARGET_DISTANCE = float.PositiveInfinity;
    public const int CLIENT_INTERNAL_PORT_MAX = 0x906;
    public const int CLIENT_PORT_MAX = 0x95f;
    public const int CLIENT_PORT_MIN = 0x8fd;
    public const int COLLISIONLESS_NPC_LAYER = 11;
    public const float COMBAT_DISTANCE = 30f;
    public static readonly string defaultGuiSceneName = "-9,2";
    public static readonly List<string> defaultSceneList = new List<string>();
    public static readonly string depotDir = GUtil.FindBinParent();
    public static readonly string depotUrlFormat = depotDir.Replace('\\', '/');
    public const string DEV_MODE_VERSION_ID = "DEV_MODE";
    public const float ENTITY_VIS_DIST_INNER = 79f;
    public const float ENTITY_VIS_DIST_OUTER = 80f;
    public const float ENTITY_VIS_DIST_OUTER_SQ = 6400f;
    public const ushort ESCALATION_AUTHORITY_ID = 2;
    public const float FACILITY_DOOR_MAX_DISTANCE_SQ = 25f;
    public const float GOOD_FPS = 30f;
    public const ushort GROUP_AUTHORITY_ID = 4;
    public const int hashCodePrime = 0xfb;
    public const int IGNORE_RAYCAST_LAYER = 2;
    public const BindingFlags INSTANCE_FLAGS = (BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance);
    public const float INTERACT_DISTANCE = 10f;
    public const float INTERACT_DISTANCE_SQ = 100f;
    public const ushort INVALID_MAP_ID = 0;
    public const ushort LOGIN_AUTHORITY_ID = 5;
    public const int LOGIN_SERVER_PORT = 0x8fc;
    public const ushort MASTER_CONTROL_PROGRAM_ID = 3;
    public const ushort MASTER_LAUNCHER_ID = 1;
    public const ushort MASTER_ROUTER_ID = 1;
    public static readonly int MAX_PLAYERS_PER_MAP = 100;
    public static MouselookType MOUSELOOK_TYPE = MouselookType.CHARACTER_FOLLOWS_CAMERA;
    public static readonly TimeSpan MOVEMENT_SYNC_DELTA = TimeSpan.FromMilliseconds(100.0);
    public const int NGUI_LAYER = 8;
    public const int NPC_LAYER = 9;
    public const double ONE_MONTH_SEC = 2592000.0;
    public static bool OUTPUT_LOGS = true;
    public const int PATCHER_PORT = 0x960;
    public const int PERCENT_DIE_MAX = 0x65;
    public const int PERCENT_DIE_MIN = 1;
    public const float PLAYER_DISCONNECT_TIMER = 10f;
    public const int PLAYER_LAYER = 10;
    public const float playerColliderRadius = 0.3f;
    public const string PrefsKey_AmbientVolume = "ambient_volume";
    public const string PrefsKey_Character = "character";
    public const string PrefsKey_ChatSettings = "chat";
    public const string PrefsKey_Level = "level";
    public const string PrefsKey_MusicVolume = "music_volume";
    public const string PrefsKey_Player = "player";
    public const string PrefsKey_Port = "port";
    public const string PrefsKey_Server = "server";
    public const string PrefsKey_Username = "username";
    public const int SERVER_LAUNCHER_PORT = 0x3070;
    public const int SERVER_PORT_MAX = 0x306f;
    public const int SERVER_PORT_MIN = 0x300c;
    public const int SERVER_ROUTER_PORT = 0x3071;
    public const int serverTargetFrameRate = 20;
    public const int serverTickReducedFrequency = 10;
    public const float spawnRandomizationDistanceMax = 10f;
    public const float spawnRandomizationDistanceMin = 2f;
    public const int spawnRandomizationTries = 5;
    public const BindingFlags STATIC_FLAGS = (BindingFlags.InvokeMethod | BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Static);
    public const int SYSTEM_TEST_PORT = 0x32c8;
    public const float TAB_TARGET_DISTANCE = 40f;
    public const ushort TERRITORY_AUTHORITY_ID = 6;
    public const int TIER_DIE_MAX = 0xc9;
    public const int TIER_DIE_MIN = 1;
    public static readonly Vector3 VECTOR3_INVALID = new Vector3(float.MaxValue, float.MaxValue, float.MaxValue);
    public const string VERSION_ID_FILE = "build_num.txt";
    public const ushort WORLD_SPACE_MAP_ID = 0;

    static GConst()
    {
        defaultSceneList.Add(defaultGuiSceneName);
        defaultSceneList.Add("5,0");
        defaultSceneList.Add("-7,1");
        defaultSceneList.Add("-10,0");
        defaultSceneList.Add("TestArena");
        if (!int.TryParse(StartupParameters.RemoveParameterToProcess("loginCap"), out MAX_PLAYERS_PER_MAP))
        {
            MAX_PLAYERS_PER_MAP = 80;
        }
        if (!int.TryParse(StartupParameters.RemoveParameterToProcess("wallCap"), out BORDER_THRESHOLD))
        {
            BORDER_THRESHOLD = 70;
        }
    }

    public static void SetLoggingFolder(string newFolder)
    {
        _loggingFolder = newFolder;
    }

    public static string LOGGING_FOLDER
    {
        get
        {
            return _loggingFolder;
        }
    }

    public enum AutorunType
    {
        ALL_AXES = 7,
        FORWARD = 1,
        FORWARD_ONLY = 1,
        FORWARD_ROTATE = 3,
        NO_AUTORUN = 0,
        ROTATE = 2,
        STRAFE = 4
    }

    public enum BufferErrorCode
    {
        NO_ERROR,
        ERROR_RAW_BITS,
        ERROR_TYPE_BOOL,
        ERROR_TYPE_BYTE,
        ERROR_TYPE_DOUBLE,
        ERROR_TYPE_FLOAT,
        ERROR_TYPE_INT,
        ERROR_TYPE_LONG,
        ERROR_TYPE_SHORT,
        ERROR_TYPE_STRING,
        ERROR_TYPE_UINT,
        ERROR_TYPE_ULONG,
        ERROR_TYPE_USHORT,
        ERROR_TYPE_TIME,
        ERROR_TYPE_VECTOR2,
        ERROR_TYPE_VECTOR3,
        ERROR_TYPE_VECTOR4,
        ERROR_TYPE_QUATERNION,
        ERROR_TYPE_ENTITYID,
        ERROR_TYPE_COLOR,
        ERROR_TYPE_MATRIX4X4,
        ERROR_BUFFER_SIZE_MISMATCH,
        ERROR_UNKNOWN_RPC,
        ERROR_SETPOSITION_INVALID
    }

    public enum BugCategory : byte
    {
        BUG = 0,
        GAME_QUESTION = 3,
        GM_ASSISTANCE = 2,
        REPORT_PLAYER = 1
    }

    public enum CreateType : byte
    {
        COLLISIONLESS_NPC = 4,
        NPC = 1,
        PLAYER = 2,
        PLAYER_PROXY = 3,
        TEST_EMPTY_ENTITY = 0
    }

    public enum DataSyncOperation : byte
    {
        ADD = 1,
        INVALID = 0,
        REMOVE = 3,
        UPDATE = 2
    }

    public enum MouselookType
    {
        CHARACTER_FOLLOWS_CAMERA,
        CHARACTER_LOCKED_TO_CAMERA
    }

    public enum RoshamboEmotes
    {
        ACCEPT,
        ROCK,
        PAPER,
        SCISSORS,
        VICTORY,
        DEFEAT
    }

    public enum RoshamboOptions
    {
        END = 3,
        PAPER = 1,
        ROCK = 0,
        SCISSORS = 2,
        START = 0
    }

    public enum RpcMode
    {
        FROM_UNAUTHORIZED,
        FROM_CLIENT,
        FROM_SERVER,
        NETWORK_MANAGEMENT,
        UNITTEST_ONLY
    }

    public enum TeleportStatus
    {
        InvalidCommand,
        NoPointFound,
        ValidTeleport
    }

    public enum TimeUnit : byte
    {
        HOURS = 2,
        MINUTES = 1,
        SECONDS = 0
    }
}

