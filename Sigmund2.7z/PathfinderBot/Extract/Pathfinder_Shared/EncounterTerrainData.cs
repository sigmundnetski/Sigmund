﻿using System;
using System.Collections.Generic;
using System.Linq;

[StrongDependency(typeof(GenericEncounterData)), LooseDependency(typeof(HexTerrainData)), NoExcelData, StrongDependency(typeof(GenericEnemyData))]
public class EncounterTerrainData : DataClass
{
    public GenericEncounterData[] encounters;
    public GenericEnemyData[] enemies;
    private static Dictionary<int, EncounterTerrainData> genericByTerrain = new Dictionary<int, EncounterTerrainData>();
    public int terrainDataId;

    public static GenericEncounterData[] GetEncountersByMapId(ushort mapId)
    {
        HexTerrainData data;
        HexData data3;
        EncounterTerrainData data4;
        HexTerrainData defaultTerrain = HexTerrainData.defaultTerrain;
        if (HexData.dataByMapId.TryGetValue(mapId, out data3) && HexTerrainData.terrainById.TryGetValue(data3.terrainDataId, out data))
        {
            defaultTerrain = data;
        }
        if (genericByTerrain.TryGetValue(defaultTerrain.id, out data4))
        {
            return data4.encounters;
        }
        GLog.LogWarning(new object[] { "No terrain encounters loaded" });
        return new GenericEncounterData[0];
    }

    public static GenericEnemyData[] GetEnemiesByMapId(ushort mapId)
    {
        HexTerrainData data;
        HexData data3;
        EncounterTerrainData data4;
        HexTerrainData defaultTerrain = HexTerrainData.defaultTerrain;
        if (HexData.dataByMapId.TryGetValue(mapId, out data3) && HexTerrainData.terrainById.TryGetValue(data3.terrainDataId, out data))
        {
            defaultTerrain = data;
        }
        if (genericByTerrain.TryGetValue(defaultTerrain.id, out data4))
        {
            return data4.enemies;
        }
        GLog.LogWarning(new object[] { "No terrain enemies loaded" });
        return new GenericEnemyData[0];
    }

    public override List<DataClass> MergeData()
    {
        Dictionary<string, List<GenericEncounterData>> dictionary = new Dictionary<string, List<GenericEncounterData>>();
        Dictionary<string, List<GenericEnemyData>> dictionary2 = new Dictionary<string, List<GenericEnemyData>>();
        foreach (GenericEncounterData data in DataClass.GetData(typeof(GenericEncounterData)))
        {
            if (!dictionary.ContainsKey(data.fileName))
            {
                dictionary[data.fileName] = new List<GenericEncounterData>();
            }
            dictionary[data.fileName].Add(data);
        }
        foreach (GenericEnemyData data2 in DataClass.GetData(typeof(GenericEnemyData)))
        {
            if (!dictionary2.ContainsKey(data2.fileName))
            {
                dictionary2[data2.fileName] = new List<GenericEnemyData>();
            }
            dictionary2[data2.fileName].Add(data2);
        }
        List<DataClass> list = new List<DataClass>();
        IEnumerable<DataClass> source = DataClass.GetData(typeof(HexTerrainData));
        if (source.Count<DataClass>() == 0)
        {
            GLog.LogError(new object[] { "No TerrainData was loaded." });
        }
        foreach (HexTerrainData data3 in source)
        {
            string name = data3.name;
            if (!(dictionary.ContainsKey(name) && dictionary2.ContainsKey(name)))
            {
                GLog.LogWarning(new object[] { "Defaults not defined for terrain:", data3.name, "\nEncounters:", dictionary.ContainsKey(name), "\nEnemies:", dictionary2.ContainsKey(name) });
            }
            else
            {
                EncounterTerrainData item = new EncounterTerrainData {
                    name = name,
                    terrainDataId = data3.id,
                    encounters = dictionary[name].ToArray(),
                    enemies = dictionary2[name].ToArray()
                };
                list.Add(item);
            }
        }
        return list;
    }

    public static void OnLoad(List<DataClass> objects)
    {
        foreach (EncounterTerrainData data in objects)
        {
            if (data.terrainDataId != 0)
            {
                genericByTerrain[data.terrainDataId] = data;
            }
        }
    }
}

