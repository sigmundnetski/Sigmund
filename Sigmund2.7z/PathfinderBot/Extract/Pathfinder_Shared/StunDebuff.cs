﻿using System;

public class StunDebuff : CombatTimedBuff
{
    private const string FREEDOM_MOD = "Freedom +20 to Self";
    private static CombatModifier[] freedomCombatMod = CombatModifier.Parse("Freedom +20 to Self");
    private const string IMMOBILIZE_MOD = "Immobilize (1 round) to Self";
    private static CombatModifier[] immobilizeCombatMod = CombatModifier.Parse("Immobilize (1 round) to Self");
    private const uint STUN_FAILURE_PERCENTAGE = 30;

    public StunDebuff() : base("Stun", Combat.Channel.Weakness, Combat.EffectType.Detrimental)
    {
    }

    public static StunDebuff Create()
    {
        return new StunDebuff();
    }

    public override CombatBuffVars Initialize(uint combatTick, CombatModifier mod, CombatVars target, int additionalDefense)
    {
        CombatBuffVars stack = CombatBuff.GetStack(target, CombatConstants.Stack.FREEDOM);
        int stacks = 0;
        if (stack != null)
        {
            stacks = stack.stacks;
        }
        CombatBuffVars vars2 = base.Initialize(combatTick, mod, target, stacks);
        vars2.effectApplied = false;
        return vars2;
    }

    public override void RecalculationPhase(CombatBuffVars buff, uint combatTick)
    {
        if ((CombatVars.RestrictionType.NoAction | CombatVars.RestrictionType.NoMovement) > buff.owner.tempRestrictionType)
        {
            buff.owner.tempRestrictionType = CombatVars.RestrictionType.NoAction | CombatVars.RestrictionType.NoMovement;
        }
    }

    public override void ResolutionPhase(CombatBuffVars buff, uint combatTick)
    {
        if ((!buff.effectApplied && (combatTick < buff.expirationTick)) && (CombatCore.restrictMovement != null))
        {
            if ((buff.owner.featState == CombatVars.FeatState.Validation) || (buff.owner.featState == CombatVars.FeatState.Interruption))
            {
                buff.owner.CancelFeat(CombatVars.FeatFailure.Interrupted);
            }
            CombatCore.restrictMovement(buff.owner, CombatConstants.Buff.STUN, CombatVars.RestrictionType.NoAction | CombatVars.RestrictionType.NoMovement, CombatCore.SecondsFromTicks(buff.expirationTick - buff.startTick));
            buff.effectApplied = true;
        }
    }

    public override void UpdateBuff(CombatBuffVars buff, uint combatTick, CombatModifier mod, CombatEffect effect)
    {
        uint expirationTick = buff.expirationTick;
        base.UpdateBuff(buff, combatTick, mod, effect);
        if (buff.expirationTick > expirationTick)
        {
            CombatEffect effect2;
            if (buff.successPercentage <= 30)
            {
                buff.displayOnClient = false;
                base.Expire(buff, combatTick);
                buff.effectApplied = true;
                immobilizeCombatMod[0].tickDuration = mod.tickDuration;
                effect2 = new CombatEffect(immobilizeCombatMod, buff.owner, buff.owner, CombatEffect.TargetType.ATTACKER, Combat.EffectType.Neutral);
                buff.owner.combatEffects.Enqueue(effect2);
            }
            else
            {
                effect2 = new CombatEffect(freedomCombatMod, buff.owner, buff.owner, CombatEffect.TargetType.ATTACKER, Combat.EffectType.Neutral);
                buff.owner.combatEffects.Enqueue(effect2);
            }
        }
    }
}

