﻿using System;
using System.Collections.Generic;

public class WeaponProficiencyData : DataClass
{
    private string displayName;
    public static Dictionary<string, WeaponProficiencyData> profsByName = new Dictionary<string, WeaponProficiencyData>();

    public WeaponProficiencyData()
    {
        this.displayName = string.Empty;
    }

    public WeaponProficiencyData(string name_) : base(name_.ToLower())
    {
        this.displayName = name_;
    }

    public static void OnLoad(List<DataClass> objects)
    {
        profsByName.Clear();
        foreach (WeaponProficiencyData data in objects)
        {
            profsByName[data.name] = data;
        }
    }

    public override DataClass ParseRecord(int index)
    {
        WeaponProficiencyData data = new WeaponProficiencyData();
        if (!DataClass.TryGetCellValue("A", index, out data.displayName))
        {
            return null;
        }
        data.name = data.displayName.ToLower();
        return data;
    }
}

