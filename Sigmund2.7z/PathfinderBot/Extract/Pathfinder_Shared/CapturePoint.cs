﻿using System;
using UnityEngine;

public class CapturePoint
{
    public float maxRadius;
    public Vector3 position;

    public void Set(Vector3 _pos, float _radius)
    {
        this.position = _pos;
        this.maxRadius = _radius;
    }

    public override string ToString()
    {
        return string.Concat(new object[] { "<CapturePoint", this.position, " ", this.maxRadius, ">" });
    }
}

