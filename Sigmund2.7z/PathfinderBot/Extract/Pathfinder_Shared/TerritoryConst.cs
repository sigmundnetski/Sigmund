﻿using System;

public static class TerritoryConst
{
    public const double MAX_POINTS_TICK = 30.0;
    public const double PLAYER_CONTRIBUTION = 1.0;
    public static readonly TimeSpan TICK_DURATION = TimeSpan.FromSeconds(5.0);
    public const double VICTORY_SCORE = 1000.0;

    public enum PvpStatus : byte
    {
        PVP_ACTIVE = 1,
        PVP_FINISHED = 2,
        PVP_PENDING = 0
    }
}

