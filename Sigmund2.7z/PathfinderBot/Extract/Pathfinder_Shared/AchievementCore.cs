﻿using System;
using System.Collections.Generic;

public static class AchievementCore
{
    public static Dictionary<int, int> pageLengthByPageId = new Dictionary<int, int>();
    public static Dictionary<int, ushort> pageNumberByPageId = new Dictionary<int, ushort>();

    public static void SetupPageInfo()
    {
        int num;
        foreach (KeyValuePair<int, GenericAchievementData[]> pair in MergedAchievementData.achievementsByPageId)
        {
            num = 0;
            foreach (GenericAchievementData data in pair.Value)
            {
                num = Math.Max(num, data.pageIndex);
            }
            pageLengthByPageId[pair.Key] = num / 0x40;
            pageNumberByPageId[pair.Key] = pair.Value[0].pageNumber;
        }
        foreach (KeyValuePair<int, AchievementCounterData[]> pair2 in AchievementCounterData.countersByPageId)
        {
            num = 0;
            foreach (AchievementCounterData data2 in pair2.Value)
            {
                num = Math.Max(num, data2.pageIndex);
            }
            pageLengthByPageId[pair2.Key] = num / 4;
            pageNumberByPageId[pair2.Key] = pair2.Value[0].pageNumber;
        }
        foreach (KeyValuePair<int, AchievementFlagData[]> pair3 in AchievementFlagData.flagsByPageId)
        {
            num = 0;
            foreach (AchievementFlagData data3 in pair3.Value)
            {
                num = Math.Max(num, data3.pageIndex);
            }
            pageLengthByPageId[pair3.Key] = num / 0x40;
            pageNumberByPageId[pair3.Key] = pair3.Value[0].pageNumber;
        }
        foreach (KeyValuePair<int, FeatAdvancementData[]> pair4 in FeatAdvancementData.dataByPageId)
        {
            num = 0;
            foreach (FeatAdvancementData data4 in pair4.Value)
            {
                num = Math.Max(num, data4.pageIndex);
            }
            pageLengthByPageId[pair4.Key] = num / 8;
            pageNumberByPageId[pair4.Key] = pair4.Value[0].pageNumber;
        }
    }

    public static void TearDownPageInfo()
    {
        pageLengthByPageId.Clear();
        pageNumberByPageId.Clear();
    }
}

