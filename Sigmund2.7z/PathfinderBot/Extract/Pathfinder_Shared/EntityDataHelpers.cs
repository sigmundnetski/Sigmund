﻿using System;

public static class EntityDataHelpers
{
    public static bool SyncToAll(byte syncLevel)
    {
        return ((syncLevel == 0xff) || (syncLevel == 0));
    }

    public static bool SyncToOwner(byte syncLevel)
    {
        return ((syncLevel == 0xff) || (syncLevel == 2));
    }

    public static bool SyncToParty(byte syncLevel)
    {
        return ((syncLevel == 0xff) || (syncLevel == 1));
    }
}

