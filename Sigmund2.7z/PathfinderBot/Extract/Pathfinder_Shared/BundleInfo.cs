﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

public class BundleInfo
{
    public static List<BundleInfo> allBundleInfos = new List<BundleInfo>();
    public string bundleName;
    public string bundleResourcePath;
    public System.Type[] bundleTypes;
    public bool hasServerSpecific;
    public bool onDemandLoading;
    public bool tryResourcesFirst;

    public BundleInfo(string name, string resourcePath, System.Type[] types, bool resourcesFirst = true, bool demandLoading = false, bool _hasServerSpecific = false)
    {
        this.bundleName = name;
        this.bundleResourcePath = resourcePath;
        this.bundleTypes = types;
        this.tryResourcesFirst = resourcesFirst;
        this.onDemandLoading = demandLoading;
        this.hasServerSpecific = _hasServerSpecific;
        allBundleInfos.Add(this);
    }
}

