﻿using System;
using System.Collections.Generic;
using System.IO;

public class PigFile
{
    private Index contents = null;
    private static Dictionary<string, Index> loadedHeaders = new Dictionary<string, Index>();
    private string name = null;

    public PigFile(string fileName)
    {
        if (!loadedHeaders.ContainsKey(fileName))
        {
            if (!File.Exists(fileName))
            {
                throw new Exception("Could not find file '" + fileName + "'");
            }
            using (FileStream stream = new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                int numBytes = BitConverter.ToInt32(GUtil.ReadBytesFromStream(stream, 4), 0);
                PigFileHeader header = (PigFileHeader) DataUtilities.DeserializeObjectFromDisk(GUtil.ReadBytesFromStream(stream, numBytes), typeof(PigFileHeader));
                Index index = new Index(header, (long) (numBytes + 4));
                loadedHeaders.Add(fileName, index);
            }
        }
        this.name = fileName;
        this.contents = loadedHeaders[this.name];
    }

    public bool ContainsFile(string desiredFileName)
    {
        return this.contents.fileIndex.ContainsKey(this.ConvertDirCharacters(desiredFileName));
    }

    private string ConvertDirCharacters(string fileName)
    {
        return fileName.Replace(Path.DirectorySeparatorChar, '\\');
    }

    public static void CreatePigFile(string[] fileNames, string outputName)
    {
        PigFileHeader header = PigFileHeader.CreateHeaderForFiles(fileNames);
        if (header.fileNames.Length != header.fileInfo.Length)
        {
            throw new Exception(string.Concat(new object[] { "Number of filenames does not match number of index entries.(", header.fileNames.Length, " != ", header.fileInfo.Length, ")" }));
        }
        byte[] buffer = DataUtilities.SerializeObjectToDisk(header);
        int length = buffer.Length;
        using (FileStream stream = File.OpenWrite(outputName))
        {
            byte[] bytes = BitConverter.GetBytes(length);
            long num2 = 0L;
            GLog.Log(new object[] { "Total Header Size: " + length });
            GLog.Log(new object[] { "Contained Files:" });
            GLog.Log(new object[] { "  " + GUtil.PrettyPrint(header.fileNames, "\n  ", null) });
            stream.Write(bytes, 0, bytes.Length);
            num2 += bytes.Length;
            stream.Write(buffer, 0, length);
            num2 += length;
            long num3 = num2;
            for (int i = 0; i < header.fileNames.Length; i++)
            {
                string path = header.fileNames[i];
                PigFileHeader.IndexedFileInfo info = header.fileInfo[i];
                byte[] buffer3 = File.ReadAllBytes(path);
                if (buffer3.Length != info.fileSize)
                {
                    throw new Exception("File size mismatch! The length of " + path + " has changed since this process has started.");
                }
                long num5 = num2 - num3;
                if (num5 != info.dataOffset)
                {
                    throw new Exception(string.Concat(new object[] { "Header offset not accurate! The header states ", path, " should start at offset ", info.dataOffset, "but actually starts at offset", num5, "." }));
                }
                stream.Write(buffer3, 0, buffer3.Length);
                num2 += buffer3.Length;
            }
        }
    }

    private string DeconvertDirCharacters(string fileName)
    {
        return fileName.Replace('\\', Path.DirectorySeparatorChar);
    }

    public string[] GetContainedFileNames()
    {
        string[] array = new string[this.contents.fileIndex.Count];
        this.contents.fileIndex.Keys.CopyTo(array, 0);
        for (int i = 0; i < array.Length; i++)
        {
            array[i] = this.DeconvertDirCharacters(array[i]);
        }
        return array;
    }

    public PigFileStream GetFileData(string desiredFileName)
    {
        desiredFileName = this.ConvertDirCharacters(desiredFileName);
        if (!this.contents.fileIndex.ContainsKey(desiredFileName))
        {
            GLog.LogError(new object[] { desiredFileName + " is not contained within " + this.name + "." });
            return null;
        }
        return new PigFileStream(this.name, this.contents.fileIndex[desiredFileName]);
    }

    private class Index
    {
        public Dictionary<string, PigFileHeader.IndexedFileInfo> fileIndex = new Dictionary<string, PigFileHeader.IndexedFileInfo>();
        public long headerSize;

        public Index(PigFileHeader header, long headerSize)
        {
            for (int i = 0; i < header.fileNames.Length; i++)
            {
                PigFileHeader.IndexedFileInfo info1 = header.fileInfo[i];
                info1.dataOffset += headerSize;
                this.fileIndex.Add(header.fileNames[i], header.fileInfo[i]);
            }
            this.headerSize = headerSize;
        }
    }
}

