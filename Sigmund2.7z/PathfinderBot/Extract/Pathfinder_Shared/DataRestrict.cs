﻿using System;

public class DataRestrict : Attribute
{
}

