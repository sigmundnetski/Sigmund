﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using UnityEngine;

public class UUnitAssert
{
    public const double DEFAULT_DOUBLE_PRECISION = 1E-06;
    public const float DEFAULT_FLOAT_PRECISION = 0.0001f;

    private UUnitAssert()
    {
    }

    public static void ColorEquals(Color wanted, Color got, float precision = 0.0001f, string message = "Expected equivalent inputs: \"{0}\" != \"{1}\"")
    {
        if (((Math.Abs((float) (wanted.r - got.r)) > precision) || (Math.Abs((float) (wanted.g - got.g)) > precision)) || (Math.Abs((float) (wanted.b - got.b)) > precision))
        {
            if ((message.IndexOf("{0}") != -1) && (message.IndexOf("{1}") != -1))
            {
                message = string.Format(message, wanted, got);
            }
            throw new UUnitAssertException(message);
        }
    }

    public static void Contains<T>(IEnumerable<T> enumerable, T element, string message = "Expected element in list: {0} in\n{1}")
    {
        if (!enumerable.Contains<T>(element))
        {
            if ((message.IndexOf("{0}") != -1) && (message.IndexOf("{1}") != -1))
            {
                message = string.Format(message, element, GUtil.PrettyPrint(enumerable, ", ", "[]"));
            }
            throw new UUnitAssertException(message);
        }
    }

    public static void DataEquals<T>(T wanted, T got, byte syncTargetLevel, string message = "Expected equivalent objects:\n{0}\n!=\n{1}") where T: IDataCopyable<T>
    {
        bool flag = object.ReferenceEquals(wanted, null);
        bool flag2 = object.ReferenceEquals(got, null);
        if (!object.ReferenceEquals(wanted, got) && (((flag && !flag2) || (!flag && flag2)) || !wanted.DataEquals(got, syncTargetLevel)))
        {
            if ((message.IndexOf("{0}") != -1) && (message.IndexOf("{1}") != -1))
            {
                message = string.Format(message, wanted, got);
            }
            throw new UUnitAssertException(message);
        }
    }

    public static void DeepEquals<T>(T[] wanted, T[] got, byte syncTargetLevel, string message = "Expected equivalent lists:\n{0}\n!=\n{1}") where T: class, IDataCopyable<T>
    {
        if (!object.ReferenceEquals(wanted, got) && !SparseArray.DeepEqualsWithIndex<T>(wanted, got, syncTargetLevel))
        {
            if ((message.IndexOf("{0}") != -1) && (message.IndexOf("{1}") != -1))
            {
                message = string.Format(message, GUtil.PrettyPrint(wanted, ", ", "[]"), GUtil.PrettyPrint(got, ", ", "[]"));
            }
            throw new UUnitAssertException(message);
        }
    }

    public static void DeepEquals<T>(T[] wanted, T[] got, byte syncTargetLevel, Predicate<T> emptyMatch, string message = "Expected equivalent lists:\n{0}\n!=\n{1}") where T: struct, IDataCopyable<T>
    {
        if (!object.ReferenceEquals(wanted, got) && !SparseArray.DeepEqualsWithIndex<T>(wanted, got, syncTargetLevel, emptyMatch))
        {
            if ((message.IndexOf("{0}") != -1) && (message.IndexOf("{1}") != -1))
            {
                message = string.Format(message, GUtil.PrettyPrint(wanted, ", ", "[]"), GUtil.PrettyPrint(got, ", ", "[]"));
            }
            throw new UUnitAssertException(message);
        }
    }

    public static void Equals(char wanted, char got, string message = "Expected equivalent inputs: \"{0}\" != \"{1}\"")
    {
        if (wanted != got)
        {
            if ((message.IndexOf("{0}") != -1) && (message.IndexOf("{1}") != -1))
            {
                message = string.Format(message, wanted, got);
            }
            throw new UUnitAssertException(message);
        }
    }

    public static void Equals(char wanted, char got, params object[] messageObjs)
    {
        if (wanted != got)
        {
            throw new UUnitAssertException(messageObjs);
        }
    }

    public static void Equals(int wanted, int got, string message = "Expected equivalent inputs: \"{0}\" != \"{1}\"")
    {
        if (wanted != got)
        {
            if ((message.IndexOf("{0}") != -1) && (message.IndexOf("{1}") != -1))
            {
                message = string.Format(message, wanted, got);
            }
            throw new UUnitAssertException(message);
        }
    }

    public static void Equals(int wanted, int got, params object[] messageObjs)
    {
        if (wanted != got)
        {
            throw new UUnitAssertException(messageObjs);
        }
    }

    public static void Equals(object wanted, object got, string message = "Expected equivalent inputs: \"{0}\" != \"{1}\"")
    {
        if (!object.Equals(wanted, got))
        {
            if ((message.IndexOf("{0}") != -1) && (message.IndexOf("{1}") != -1))
            {
                message = string.Format(message, wanted, got);
            }
            throw new UUnitAssertException(message);
        }
    }

    public static void Equals(object wanted, object got, params object[] messageObjs)
    {
        if (wanted != got)
        {
            throw new UUnitAssertException(messageObjs);
        }
    }

    public static void Equals(string wanted, string got, string message = "Expected equivalent inputs: \"{0}\" != \"{1}\"")
    {
        if (wanted != got)
        {
            if ((message.IndexOf("{0}") != -1) && (message.IndexOf("{1}") != -1))
            {
                message = string.Format(message, wanted, got);
            }
            throw new UUnitAssertException(message);
        }
    }

    public static void Equals(string wanted, string got, params object[] messageObjs)
    {
        if (!(wanted == got))
        {
            throw new UUnitAssertException(messageObjs);
        }
    }

    public static void Equals(ulong wanted, ulong got, string message = "Expected equivalent inputs: \"{0}\" != \"{1}\"")
    {
        if (wanted != got)
        {
            if ((message.IndexOf("{0}") != -1) && (message.IndexOf("{1}") != -1))
            {
                message = string.Format(message, wanted, got);
            }
            throw new UUnitAssertException(message);
        }
    }

    public static void Equals(double wanted, double got, double precision = 1E-06, string message = "Expected equivalent inputs: \"{0}\" != \"{1}\"")
    {
        if (Math.Abs((double) (wanted - got)) > precision)
        {
            if ((message.IndexOf("{0}") != -1) && (message.IndexOf("{1}") != -1))
            {
                message = string.Format(message, wanted, got);
            }
            throw new UUnitAssertException(message);
        }
    }

    public static void Equals(float wanted, float got, float precision = 0.0001f, string message = "Expected equivalent inputs: \"{0}\" != \"{1}\"")
    {
        if (Math.Abs((float) (wanted - got)) > precision)
        {
            if ((message.IndexOf("{0}") != -1) && (message.IndexOf("{1}") != -1))
            {
                message = string.Format(message, wanted, got);
            }
            throw new UUnitAssertException(message);
        }
    }

    public static void Fail(string message = "Fail")
    {
        throw new UUnitAssertException(message);
    }

    public static void Fail(params object[] messageObjs)
    {
        throw new UUnitAssertException(messageObjs);
    }

    public static void False(bool boolean, string message = "Fail")
    {
        if (boolean)
        {
            throw new UUnitAssertException(message);
        }
    }

    public static void False(bool boolean, params object[] messageObjs)
    {
        if (boolean)
        {
            throw new UUnitAssertException(messageObjs);
        }
    }

    public static void NotNull(object something, string message = "Null object not expected.")
    {
        if (something == null)
        {
            throw new UUnitAssertException(message);
        }
    }

    public static void NotNull(object something, params object[] messageObjs)
    {
        if (something == null)
        {
            throw new UUnitAssertException(messageObjs);
        }
    }

    public static void Null(object something, string message = "Expected null object.")
    {
        if (something != null)
        {
            throw new UUnitAssertException(message);
        }
    }

    public static void Null(object something, params object[] messageObjs)
    {
        if (something != null)
        {
            throw new UUnitAssertException(messageObjs);
        }
    }

    public static void Raises(UUnitAssertFunction func, System.Type expected, params object[] messageObjs)
    {
        try
        {
            func();
            throw new UUnitAssertException(messageObjs);
        }
        catch (Exception exception)
        {
            if (!(exception.GetType() == expected))
            {
                throw new UUnitAssertException(messageObjs);
            }
        }
    }

    public static void SequenceEqual<T>(IEnumerable<T> wanted, IEnumerable<T> got, string message = "Expected equivalent lists:\n{0}\n!=\n{1}")
    {
        if (!object.ReferenceEquals(wanted, got) && !wanted.SequenceEqual<T>(got))
        {
            if ((message.IndexOf("{0}") != -1) && (message.IndexOf("{1}") != -1))
            {
                message = string.Format(message, GUtil.PrettyPrint(wanted, ", ", "[]"), GUtil.PrettyPrint(got, ", ", "[]"));
            }
            throw new UUnitAssertException(message);
        }
    }

    public static void True(bool boolean, string message = "Fail")
    {
        if (!boolean)
        {
            throw new UUnitAssertException(message);
        }
    }

    public static void True(bool boolean, params object[] messageObjs)
    {
        if (!boolean)
        {
            throw new UUnitAssertException(messageObjs);
        }
    }
}

