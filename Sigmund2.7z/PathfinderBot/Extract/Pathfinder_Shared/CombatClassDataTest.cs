﻿using System;
using System.Collections.Generic;
using System.Linq;

internal class CombatClassDataTest : UUnitTestCase
{
    private BasicArmorData[] basicArmor;
    private BasicWeaponData[] basicWeapons;
    private ArmorQualityData[] qualityArmor;
    private WeaponQualityData[] qualityWeapons;

    private IEnumerable<DataClass> GetDataOverride(System.Type type)
    {
        if (type == typeof(BasicWeaponData))
        {
            return this.basicWeapons;
        }
        if (type == typeof(WeaponQualityData))
        {
            return this.qualityWeapons;
        }
        if (type == typeof(BasicArmorData))
        {
            return this.basicArmor;
        }
        if (type == typeof(ArmorQualityData))
        {
            return this.qualityArmor;
        }
        return null;
    }

    protected override void SetUp()
    {
        DataClass.GetData = new GetDataCallback(this.GetDataOverride);
        List<DataClass> objects = new List<DataClass> {
            new KeywordData("Slashing", 0, 0),
            new KeywordData("Sharp", 0, 0),
            new KeywordData("Balanced", 0, 0),
            new KeywordData("Razored", 0, 0),
            new KeywordData("Medium", 0, 1),
            new KeywordData("Supple", 0, 1),
            new KeywordData("Flexible", 0, 1),
            new KeywordData("Quiet", 0, 1),
            new KeywordData("Infused", 0, 1),
            new KeywordData("Masterwork", 1, 1),
            new KeywordData("Dragonskin", 1, 1)
        };
        KeywordData.OnLoad(objects);
        List<DataClass> list2 = new List<DataClass> {
            new WeaponProficiencyData("Heavy Blade")
        };
        WeaponProficiencyData.OnLoad(list2);
        List<DataClass> list3 = new List<DataClass> {
            new BasicWeaponData("Longsword", 1, 1.5f, 1, "Heavy Blade", "Slashing", "Sharp", "Balanced", "Razored")
        };
        BasicWeaponData.OnLoad(list3);
        this.basicWeapons = (from each in list3 select (BasicWeaponData) each).ToArray<BasicWeaponData>();
        this.qualityWeapons = new WeaponQualityData[] { new WeaponQualityData("Bronze", "Longsword", 1, "", "", "") };
        CombatWeapon.OnLoad(new CombatWeapon().MergeData());
        List<DataClass> list4 = new List<DataClass> {
            new ArmorKeywordData("Brave", "Supple", "Flexible", "Quiet")
        };
        ArmorKeywordData.OnLoad(list4);
        this.basicArmor = new BasicArmorData[] { new BasicArmorData("Medium", 2, 0, 0x12, 0, 0x10, -60, -0.1666667f, 0.9f, -10, "Medium") };
        this.qualityArmor = new ArmorQualityData[] { new ArmorQualityData("Fine Dragonscale", "Medium", "Brave", 3, "Dragonskin", "Masterwork", "Infused") };
        CombatArmor.OnLoad(new CombatArmor().MergeData());
    }

    [UUnitTestMethod]
    public void TestParseArmor()
    {
        int id = 0;
        byte upgrade = 0;
        CombatClassData.ParseArmor("Fine Dragonscale +3", ref id, ref upgrade);
        UUnitAssert.Equals(id, CombatArmor.GetArmorByName("Fine Dragonscale").id, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals((int) upgrade, 3, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Raises(() => CombatClassData.ParseArmor("Fine Dragonscale +2, Fine Dragonscale +1", ref id, ref upgrade), typeof(ParseException), new object[] { "Equipment requires only one armor" });
        UUnitAssert.Raises(() => CombatClassData.ParseArmor("Fine Dragonscale +5 (1 second)", ref id, ref upgrade), typeof(ParseException), new object[] { "Equipment does not allow seconds parameter" });
        UUnitAssert.Raises(() => CombatClassData.ParseArmor("Fine Dragonscale (1 second) to Self", ref id, ref upgrade), typeof(ParseException), new object[] { "Equipment does not allow qualifiers" });
    }

    [UUnitTestMethod]
    public void TestParseWeapon()
    {
        int[] weaponIds = new int[2];
        byte[] weaponUpgrades = new byte[2];
        CombatClassData.ParseWeapons("Bronze Longsword +4, Bronze Longsword +2", 0, ref weaponIds, ref weaponUpgrades);
        UUnitAssert.False(weaponIds.Contains<int>(0), "Fail");
        UUnitAssert.Equals(weaponIds[0], CombatWeapon.GetWeaponByName("Bronze Longsword").id, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals((int) weaponUpgrades[0], 4, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(weaponIds[1], CombatWeapon.GetWeaponByName("Bronze Longsword").id, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals((int) weaponUpgrades[1], 2, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        CombatClassData.ParseWeapons("Bronze Longsword", 0, ref weaponIds, ref weaponUpgrades);
        UUnitAssert.Equals(weaponIds[0], CombatWeapon.GetWeaponByName("Bronze Longsword").id, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals((int) weaponUpgrades[0], 0, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Raises(() => CombatClassData.ParseWeapons("Bronze Longsword +5 (1 second)", 0, ref weaponIds, ref weaponUpgrades), typeof(ParseException), new object[] { "Equipment does not allow seconds parameter" });
        UUnitAssert.Raises(() => CombatClassData.ParseWeapons("Bronze Longsword +5 to Self", 0, ref weaponIds, ref weaponUpgrades), typeof(ParseException), new object[] { "Equipment does not allow qualifiers" });
    }
}

