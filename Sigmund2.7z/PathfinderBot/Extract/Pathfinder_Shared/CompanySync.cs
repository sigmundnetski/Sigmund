﻿using System;
using System.Collections.Generic;

public class CompanySync
{
    public HashSet<ulong> allCompanies = new HashSet<ulong>();
    public HashSet<ulong> playerCompanies = new HashSet<ulong>();
}

