﻿using System;

public enum GSKeyword
{
    TO,
    IF,
    HAS,
    DOESNT,
    HAVE,
    SECOND,
    ROUND,
    METER,
    CHANCE,
    COMMA,
    OPEN_PAREN,
    CLOSE_PAREN
}

