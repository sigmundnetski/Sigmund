﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;

public class IniFile
{
    private const string BACKUP_EXT = ".bak";
    private const string COMMENT = ";";
    private Dictionary<string, Dictionary<string, string>> iniContents;
    private static readonly string[] PROPERTY_SEPARATOR = new string[] { "=" };
    private const string ROOT_SECTION = "root";
    private const string SECTION_HEADER_END = "]";
    private const string SECTION_HEADER_START = "[";

    public IniFile()
    {
        this.iniContents = new Dictionary<string, Dictionary<string, string>>();
    }

    public IniFile(string pathToFile)
    {
        this.iniContents = new Dictionary<string, Dictionary<string, string>>();
        if (File.Exists(pathToFile))
        {
            this.ProcessFile(this.ReadFile(pathToFile));
        }
    }

    public string BuildNewFile()
    {
        StringBuilder fileContents = new StringBuilder();
        if (this.iniContents.ContainsKey("root"))
        {
            this.BuildNewSection("root", fileContents);
        }
        foreach (KeyValuePair<string, Dictionary<string, string>> pair in this.iniContents)
        {
            if (pair.Key != "root")
            {
                this.BuildNewSection(pair.Key, fileContents);
            }
        }
        return fileContents.ToString();
    }

    private void BuildNewSection(string section, StringBuilder fileContents)
    {
        if (section != "root")
        {
            fileContents.AppendLine("[" + section + "]");
        }
        foreach (KeyValuePair<string, string> pair in this.EnumerateSection(section))
        {
            fileContents.AppendLine(pair.Key + " = " + pair.Value);
        }
        fileContents.AppendLine();
    }

    public IEnumerable<KeyValuePair<string, string>> EnumerateSection(string section = "root")
    {
        if (this.iniContents.ContainsKey(section))
        {
            return this.iniContents[section];
        }
        return Enumerable.Empty<KeyValuePair<string, string>>();
    }

    public string Get(string property, string section = "root")
    {
        string str;
        if (string.IsNullOrEmpty(section))
        {
            throw new ArgumentException("Need a valid section. Leave as ROOT_SECTION if none is desired.");
        }
        if (string.IsNullOrEmpty(property))
        {
            throw new ArgumentException("Need a valid property name.");
        }
        if (!this.iniContents.ContainsKey(section))
        {
            return null;
        }
        this.iniContents[section].TryGetValue(property, out str);
        return str;
    }

    private string[] GetPropertyKeyValue(string trimmedLine)
    {
        string[] strArray = trimmedLine.Split(PROPERTY_SEPARATOR, StringSplitOptions.RemoveEmptyEntries);
        if (strArray.Length != 2)
        {
            return null;
        }
        for (int i = 0; i < strArray.Length; i++)
        {
            strArray[i] = strArray[i].Trim();
        }
        return strArray;
    }

    private string GetSectionName(string sectionLine)
    {
        return sectionLine.Replace("[", string.Empty).Replace("]", string.Empty).Trim();
    }

    private bool IsCommentLine(string line)
    {
        return line.StartsWith(";");
    }

    private bool IsIgnorableLine(string line)
    {
        return (string.IsNullOrEmpty(line) || line.StartsWith(";"));
    }

    private bool IsSection(string trimmedLine)
    {
        return (trimmedLine.StartsWith("[") && trimmedLine.EndsWith("]"));
    }

    public string MergeIntoExistingFile(string existingFile)
    {
        StringBuilder fileContents = new StringBuilder();
        existingFile = existingFile.Replace("\r", string.Empty);
        string[] existingLines = existingFile.Split(new string[] { "\n" }, StringSplitOptions.None);
        HashSet<string> existingSections = new HashSet<string>();
        bool flag = false;
        foreach (string str in existingLines)
        {
            string trimmedLine = this.TrimIniLine(str);
            if ((existingSections.Count == 0) && (this.GetPropertyKeyValue(trimmedLine) != null))
            {
                flag = true;
            }
            if (this.IsSection(trimmedLine))
            {
                existingSections.Add(this.GetSectionName(trimmedLine));
            }
        }
        int existingIndex = 0;
        if (!(flag || !this.iniContents.ContainsKey("root")))
        {
            this.MergeNewRoot(fileContents, existingLines, existingSections, ref existingIndex);
        }
        string currentSection = null;
        bool validSection = true;
        HashSet<string> visitedProperties = new HashSet<string>();
        StringBuilder ignoredLinesBuffer = new StringBuilder();
        bool flag3 = false;
        while (existingIndex < existingLines.Length)
        {
            string rawLine = existingLines[existingIndex];
            string line = this.TrimIniLine(rawLine);
            if (this.IsIgnorableLine(line))
            {
                if (existingIndex != (existingLines.Length - 1))
                {
                    ignoredLinesBuffer.AppendLine(rawLine);
                    flag3 = string.IsNullOrEmpty(line);
                }
            }
            else if (this.IsSection(line))
            {
                this.MergeSection(fileContents, ref currentSection, ref validSection, visitedProperties, ignoredLinesBuffer, rawLine, line);
            }
            else
            {
                this.MergeProperty(fileContents, existingSections, ref currentSection, validSection, visitedProperties, ignoredLinesBuffer, rawLine, line);
            }
            existingIndex++;
        }
        if ((currentSection != null) && this.iniContents.ContainsKey(currentSection))
        {
            Dictionary<string, string> dictionary = this.iniContents[currentSection];
            IEnumerable<string> enumerable = dictionary.Keys.Except<string>(visitedProperties);
            foreach (string str6 in enumerable)
            {
                fileContents.AppendLine(str6 + " = " + dictionary[str6]);
            }
        }
        IEnumerable<string> source = this.iniContents.Keys.Except<string>(existingSections);
        int num2 = source.Count<string>();
        if (ignoredLinesBuffer.Length > 0)
        {
            fileContents.Append(ignoredLinesBuffer.ToString());
            ignoredLinesBuffer.Length = 0;
            if (!(flag3 || (num2 <= 0)))
            {
                fileContents.AppendLine();
            }
        }
        else if (num2 > 0)
        {
            fileContents.AppendLine();
        }
        foreach (string str7 in source)
        {
            this.BuildNewSection(str7, fileContents);
        }
        return fileContents.ToString();
    }

    private void MergeNewRoot(StringBuilder fileContents, string[] existingLines, HashSet<string> existingSections, ref int existingIndex)
    {
        bool flag = false;
        while (existingIndex < existingLines.Length)
        {
            string line = this.TrimIniLine(existingLines[existingIndex]);
            if (!this.IsCommentLine(line))
            {
                if (string.IsNullOrEmpty(line))
                {
                    flag = true;
                }
                break;
            }
            existingIndex++;
        }
        if (flag)
        {
            for (int i = 0; i < existingIndex; i++)
            {
                fileContents.AppendLine(existingLines[i]);
            }
            fileContents.AppendLine();
        }
        this.BuildNewSection("root", fileContents);
        existingSections.Add("root");
        if (!flag)
        {
            existingIndex = 0;
        }
        else
        {
            existingIndex++;
        }
    }

    private void MergeProperty(StringBuilder fileContents, HashSet<string> existingSections, ref string currentSection, bool validSection, HashSet<string> visitedProperties, StringBuilder ignoredLinesBuffer, string rawLine, string trimmedLine)
    {
        if (ignoredLinesBuffer.Length > 0)
        {
            fileContents.Append(ignoredLinesBuffer.ToString());
            ignoredLinesBuffer.Length = 0;
        }
        string[] propertyKeyValue = this.GetPropertyKeyValue(trimmedLine);
        if (propertyKeyValue == null)
        {
            fileContents.AppendLine("; UNKNOWN LINE (ignoring): " + rawLine);
        }
        else if (!validSection)
        {
            fileContents.AppendLine("; INVALID SECTION (ignoring): " + rawLine);
        }
        else
        {
            visitedProperties.Add(propertyKeyValue[0]);
            if (currentSection == null)
            {
                currentSection = "root";
                existingSections.Add("root");
            }
            if (this.iniContents.ContainsKey(currentSection))
            {
                string str;
                Dictionary<string, string> dictionary = this.iniContents[currentSection];
                if (dictionary.TryGetValue(propertyKeyValue[0], out str) && (str != propertyKeyValue[1]))
                {
                    string[] strArray2 = rawLine.Split(PROPERTY_SEPARATOR, StringSplitOptions.RemoveEmptyEntries);
                    string str2 = strArray2[0].Trim();
                    string str3 = string.Empty;
                    if (strArray2[1].Contains(";"))
                    {
                        int index = strArray2[1].IndexOf(";");
                        str3 = strArray2[1].Substring(index, strArray2[1].Length - index);
                    }
                    fileContents.AppendLine(str2 + " = " + str + (string.IsNullOrEmpty(str3) ? string.Empty : (" " + str3)));
                }
                else
                {
                    fileContents.AppendLine(rawLine);
                }
            }
            else
            {
                fileContents.AppendLine(rawLine);
            }
        }
    }

    private void MergeSection(StringBuilder fileContents, ref string currentSection, ref bool validSection, HashSet<string> visitedProperties, StringBuilder ignoredLinesBuffer, string rawLine, string trimmedLine)
    {
        if ((currentSection != null) && this.iniContents.ContainsKey(currentSection))
        {
            Dictionary<string, string> dictionary = this.iniContents[currentSection];
            IEnumerable<string> enumerable = dictionary.Keys.Except<string>(visitedProperties);
            foreach (string str in enumerable)
            {
                fileContents.AppendLine(str + " = " + dictionary[str]);
            }
        }
        if (ignoredLinesBuffer.Length > 0)
        {
            fileContents.Append(ignoredLinesBuffer.ToString());
            ignoredLinesBuffer.Length = 0;
        }
        string sectionName = this.GetSectionName(trimmedLine);
        if (string.IsNullOrEmpty(sectionName))
        {
            validSection = false;
            GLog.LogError(new object[] { "Ignoring invalid section '" + trimmedLine + "' and all properties in it." });
            fileContents.AppendLine("; INVALID SECTION (ignoring): " + rawLine);
        }
        else
        {
            currentSection = sectionName;
            validSection = true;
            fileContents.AppendLine(rawLine);
        }
    }

    public void ProcessFile(string entireFile)
    {
        string key = null;
        bool flag = true;
        string[] propertyKeyValue = null;
        string[] strArray2 = entireFile.Split(new string[] { "\n" }, StringSplitOptions.RemoveEmptyEntries);
        foreach (string str2 in strArray2)
        {
            string line = this.TrimIniLine(str2);
            if (!this.IsIgnorableLine(line))
            {
                if (this.IsSection(line))
                {
                    string sectionName = this.GetSectionName(line);
                    if (string.IsNullOrEmpty(sectionName))
                    {
                        flag = false;
                        GLog.LogError(new object[] { "Ignoring invalid section '" + line + "' and all properties in it." });
                    }
                    else
                    {
                        key = sectionName;
                        flag = true;
                        if (!this.iniContents.ContainsKey(key))
                        {
                            this.iniContents[key] = new Dictionary<string, string>();
                        }
                    }
                }
                else if (flag)
                {
                    propertyKeyValue = this.GetPropertyKeyValue(line);
                    if (propertyKeyValue != null)
                    {
                        if (key == null)
                        {
                            key = "root";
                            this.iniContents[key] = new Dictionary<string, string>();
                        }
                        Dictionary<string, string> dictionary = this.iniContents[key];
                        if (dictionary.ContainsKey(propertyKeyValue[0]))
                        {
                            GLog.LogWarning(new object[] { propertyKeyValue[0] + " in " + key + " section is already defined! Ignoring this definition: " + line });
                        }
                        else
                        {
                            dictionary[propertyKeyValue[0]] = propertyKeyValue[1];
                        }
                    }
                }
            }
        }
    }

    private string ReadFile(string pathToFile)
    {
        using (TextReader reader = new StreamReader(pathToFile))
        {
            return reader.ReadToEnd();
        }
    }

    public void Remove(string property, string section = "root")
    {
        if (string.IsNullOrEmpty(section))
        {
            throw new ArgumentException("Need a valid section. Leave as ROOT_SECTION if none is desired.");
        }
        if (string.IsNullOrEmpty(property))
        {
            throw new ArgumentException("Need a valid property name.");
        }
        section = section.ToLower();
        property = property.ToLower();
        if (this.iniContents.ContainsKey(section))
        {
            Dictionary<string, string> dictionary = this.iniContents[section];
            dictionary.Remove(property);
            if (dictionary.Count == 0)
            {
                this.iniContents.Remove(section);
            }
        }
    }

    public string SectionToString(string section)
    {
        if (!this.iniContents.ContainsKey(section))
        {
            return string.Empty;
        }
        StringBuilder fileContents = new StringBuilder();
        this.BuildNewSection(section, fileContents);
        return fileContents.ToString();
    }

    public void Set(string value, string property, string section = "root")
    {
        if (string.IsNullOrEmpty(section))
        {
            throw new ArgumentException("Need a valid section. Leave as ROOT_SECTION if none is desired.");
        }
        if (string.IsNullOrEmpty(property))
        {
            throw new ArgumentException("Need a valid property name.");
        }
        if (string.IsNullOrEmpty(section))
        {
            throw new ArgumentException("Need a valid value name.");
        }
        section = section.ToLower();
        property = property.ToLower();
        value = value.ToLower();
        if (!this.iniContents.ContainsKey(section))
        {
            this.iniContents[section] = new Dictionary<string, string>();
        }
        Dictionary<string, string> dictionary = this.iniContents[section];
        dictionary[property] = value;
    }

    private string TrimIniLine(string rawLine)
    {
        string str = rawLine.Trim();
        if (!(str.StartsWith(";") || !str.Contains(";")))
        {
            str = str.Substring(0, str.IndexOf(";") - 1).Trim();
        }
        return str.ToLower();
    }

    public void Write(string pathToFile, WriteOptions option)
    {
        string str = string.Empty;
        bool flag = File.Exists(pathToFile);
        if ((option == WriteOptions.BACKUP_AND_TRUNCATE) && flag)
        {
            if (File.Exists(pathToFile + ".bak"))
            {
                File.Delete(pathToFile + ".bak");
            }
            File.Move(pathToFile, pathToFile + ".bak");
        }
        if (!(flag && (option == WriteOptions.MERGE)))
        {
            str = this.BuildNewFile();
        }
        else if (option == WriteOptions.MERGE)
        {
            str = this.MergeIntoExistingFile(this.ReadFile(pathToFile));
        }
        using (TextWriter writer = new StreamWriter(pathToFile))
        {
            writer.Write(str);
        }
    }

    public enum WriteOptions
    {
        TRUNCATE,
        MERGE,
        BACKUP_AND_TRUNCATE
    }
}

