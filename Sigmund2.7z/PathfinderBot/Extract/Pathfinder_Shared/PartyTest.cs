﻿using System;

internal class PartyTest : UUnitTestCase
{
    private void TestInviteList(Party pt, uint[] expected)
    {
        int index = 0;
        string str = "";
        foreach (Party.PartyMember member in pt.GetInvites())
        {
            if (str.Length > 0)
            {
                str = str + ", ";
            }
            object obj2 = str;
            str = string.Concat(new object[] { obj2, expected[index], " == ", member.playerId });
            if (member.playerId != expected[index])
            {
                UUnitAssert.Fail("Invite order incorrect: " + str);
            }
            index++;
        }
        if (index != expected.Length)
        {
            UUnitAssert.Fail("Invite list is the wrong size");
        }
    }

    private void TestMemberList(Party pt, uint[] expected)
    {
        int index = 0;
        string str = "";
        foreach (Party.PartyMember member in pt.GetMembers())
        {
            if (str.Length > 0)
            {
                str = str + ", ";
            }
            object obj2 = str;
            str = string.Concat(new object[] { obj2, expected[index], " == ", member.playerId });
            if (member.playerId != expected[index])
            {
                UUnitAssert.Fail("Member order incorrect: " + str);
            }
            index++;
        }
        if (index != expected.Length)
        {
            UUnitAssert.Fail("Member list is the wrong size");
        }
    }

    [UUnitTestMethod]
    private void TestPartyMembership()
    {
        int num;
        uint[] numArray = new uint[10];
        for (num = 0; num < numArray.Length; num++)
        {
            numArray[num] = (uint) (num + 1);
        }
        Party pt = new Party();
        pt.AddMember(numArray[0], "TestPlayer");
        pt.TransferOwnership(numArray[0]);
        pt.TransferOwnership(numArray[1]);
        for (num = 1; (num < numArray.Length) && !pt.IsFull(); num++)
        {
            pt.AddInvite(numArray[num], "TestPlayer");
        }
        pt.TransferOwnership(numArray[1]);
        pt.RemoveInvite(numArray[8]);
        pt.RemoveMember(numArray[8], true);
        this.TestMemberList(pt, new uint[] { 1 });
        for (num = 5; num > 0; num--)
        {
            pt.AddMember(numArray[num], "TestPlayer");
            pt.RemoveInvite(numArray[num]);
        }
        this.TestMemberList(pt, new uint[] { 1, 6, 5, 4, 3, 2 });
        pt.TransferOwnership(numArray[2]);
        pt.RemoveMember(numArray[4], true);
        this.TestMemberList(pt, new uint[] { 3, 1, 6, 4, 2 });
        pt.Disband();
        this.TestMemberList(pt, new uint[0]);
        this.TestInviteList(pt, new uint[0]);
    }
}

