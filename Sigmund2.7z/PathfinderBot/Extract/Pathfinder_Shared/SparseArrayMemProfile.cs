﻿using System;
using System.Runtime.CompilerServices;

internal class SparseArrayMemProfile : UUnitTestCase
{
    private const int ARRAY_SIZE = 8;
    private static Predicate<EntityId> ENTITY_ID_EMPTY_MATCH = id => (id == EntityId.INVALID_ID);
    private SATestClass[] objArray1 = new SATestClass[8];
    private SATestClass[] objArray2 = new SATestClass[8];
    private EntityId[] primitiveArray1 = new EntityId[8];
    private EntityId[] primitiveArray2 = new EntityId[8];

    [CompilerGenerated]
    private static bool <.cctor>b__0(EntityId id)
    {
        return (id == EntityId.INVALID_ID);
    }

    [UUnitTestMethod]
    private void DeepEqualIgnoreIndex()
    {
        UUnitAssert.True(SparseArray.DeepEqualsIgnoreIndex<SATestClass>(this.objArray1, this.objArray2, 0xff), "Fail");
        this.objArray1[0] = null;
        UUnitAssert.False(SparseArray.DeepEqualsIgnoreIndex<SATestClass>(this.objArray1, this.objArray2, 0xff), "Fail");
        this.objArray2[1] = null;
        UUnitAssert.True(SparseArray.DeepEqualsIgnoreIndex<SATestClass>(this.objArray1, this.objArray2, 0xff), "Fail");
    }

    [UUnitTestMethod]
    private void DeepEqualsWithIndex()
    {
        UUnitAssert.True(SparseArray.DeepEqualsWithIndex<EntityId>(this.primitiveArray1, this.primitiveArray2), "Fail");
        this.primitiveArray1[0] = EntityId.INVALID_ID;
        UUnitAssert.False(SparseArray.DeepEqualsWithIndex<EntityId>(this.primitiveArray1, this.primitiveArray2), "Fail");
        this.primitiveArray2[0] = EntityId.INVALID_ID;
        UUnitAssert.True(SparseArray.DeepEqualsWithIndex<EntityId>(this.primitiveArray1, this.primitiveArray2), "Fail");
    }

    protected override void SetUp()
    {
        this.primitiveArray1[0] = (EntityId) 12L;
        this.primitiveArray2[0] = (EntityId) 12L;
        this.objArray1[0] = new SATestClass(12);
        this.objArray2[1] = new SATestClass(12);
    }
}

