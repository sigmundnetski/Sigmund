﻿using System;
using System.Collections.Generic;

public class CapturePointVars : IDataCopyable<CapturePointVars>
{
    public TerritoryConst.PvpStatus captureGameState = TerritoryConst.PvpStatus.PVP_PENDING;
    public ulong[] companyIds;
    public string[] companyNames;
    public ulong companyOwnerId;
    public string companyOwnerName;
    public double[] companyScores;
    public TimeSpan duration;
    [DataRestrict]
    private int insertIndex = 0;
    [DataRestrict]
    public bool pvpSet = false;
    public TimeSpan pvpTimeOfDay;
    public uint[] settlementIds;
    public uint settlementOwnerId;
    public string settlementOwnerName;
    private static List<CapturePointScore> sortedScores = new List<CapturePointScore>();

    public void AddScore(VentureCompanyRecord company, double score)
    {
        SparseArray.EnsureCapacity<ulong>(ref this.companyIds, this.insertIndex + 1);
        SparseArray.EnsureCapacity<string>(ref this.companyNames, this.insertIndex + 1);
        SparseArray.EnsureCapacity<uint>(ref this.settlementIds, this.insertIndex + 1);
        SparseArray.EnsureCapacity<double>(ref this.companyScores, this.insertIndex + 1);
        this.companyIds[this.insertIndex] = (company != null) ? company.companyId : ((ulong) 0L);
        this.companyNames[this.insertIndex] = (company != null) ? company.vcName : "<Invalid Company>";
        this.settlementIds[this.insertIndex] = (company != null) ? company.settlementId : 0;
        this.companyScores[this.insertIndex] = score;
        this.insertIndex++;
    }

    public void Capture(VentureCompanyRecord companyRecord)
    {
        this.companyOwnerId = (companyRecord != null) ? companyRecord.companyId : ((ulong) 0L);
        this.companyOwnerName = (companyRecord != null) ? companyRecord.vcName : "Unclaimed";
        this.settlementOwnerId = 0;
        this.settlementOwnerName = "";
        this.pvpTimeOfDay = SettlementPvpData.singleton.noPvpEnd;
        this.duration = (SettlementPvpData.singleton.noPvpStart - SettlementPvpData.singleton.noPvpEnd) + TimeSpan.FromDays(1.0);
    }

    public void ClearScores()
    {
        SparseArray.Clear<ulong>(ref this.companyIds, 0L);
        SparseArray.Clear<string>(ref this.companyNames, null);
        SparseArray.Clear<uint>(ref this.settlementIds, 0);
        SparseArray.Clear<double>(ref this.companyScores, 0.0);
        this.insertIndex = 0;
    }

    public void DataCopyTo(ref CapturePointVars target, byte syncTargetLevel)
    {
        target.captureGameState = this.captureGameState;
        target.pvpTimeOfDay = this.pvpTimeOfDay;
        target.duration = this.duration;
        target.companyOwnerId = this.companyOwnerId;
        target.companyOwnerName = this.companyOwnerName;
        target.settlementOwnerId = this.settlementOwnerId;
        target.settlementOwnerName = this.settlementOwnerName;
        DataSerializerUtils.DataCopyField<ulong>(this.companyIds, ref target.companyIds);
        DataSerializerUtils.DataCopyStringArray(this.companyNames, ref target.companyNames);
        DataSerializerUtils.DataCopyField<uint>(this.settlementIds, ref target.settlementIds);
        DataSerializerUtils.DataCopyField<double>(this.companyScores, ref target.companyScores);
    }

    public bool DataEquals(CapturePointVars target, byte syncTargetLevel)
    {
        return ((((((target.captureGameState == this.captureGameState) && (target.pvpTimeOfDay == this.pvpTimeOfDay)) && ((target.duration == this.duration) && (target.companyOwnerId == this.companyOwnerId))) && (((target.companyOwnerName == this.companyOwnerName) && (target.settlementOwnerId == this.settlementOwnerId)) && ((target.settlementOwnerName == this.settlementOwnerName) && SparseArray.DeepEqualsWithIndex<ulong>(this.companyIds, target.companyIds)))) && (SparseArray.StringEqualsWithIndex(this.companyNames, target.companyNames) && SparseArray.DeepEqualsWithIndex<uint>(this.settlementIds, target.settlementIds))) && SparseArray.DeepEqualsWithIndex<double>(this.companyScores, target.companyScores));
    }

    public int GetCaptureHash()
    {
        int num = 0;
        num += (int) (this.captureGameState * ((TerritoryConst.PvpStatus) 0x9707b));
        num += (int) this.pvpTimeOfDay.TotalMinutes;
        num += (int) this.duration.TotalMinutes;
        num += this.companyOwnerName.GetHashCode();
        num += this.settlementOwnerName.GetHashCode();
        if (this.companyScores != null)
        {
            num += this.companyScores.Length;
            for (int i = 0; i < this.companyScores.Length; i++)
            {
                num += (int) this.companyScores[i];
            }
        }
        return num;
    }

    public List<CapturePointScore> GetSortedScores()
    {
        sortedScores.Clear();
        for (int i = 0; i < this.companyNames.Length; i++)
        {
            if (this.companyNames[i] != null)
            {
                sortedScores.Add(new CapturePointScore(this.companyIds[i], this.companyNames[i], this.settlementIds[i], this.companyScores[i]));
            }
        }
        sortedScores.Sort();
        return sortedScores;
    }

    public void Set(ulong companyId, VentureCompanyRecord companyRecord, uint settlementId, SettlementRecord settlementRecord, TimeSpan timeOfDay, TimeSpan _duration)
    {
        this.pvpSet = true;
        this.captureGameState = TerritoryConst.PvpStatus.PVP_PENDING;
        this.companyOwnerId = companyId;
        this.companyOwnerName = (companyRecord != null) ? companyRecord.vcName : "Unclaimed";
        this.settlementOwnerId = settlementId;
        this.settlementOwnerName = ((settlementRecord != null) && (this.settlementOwnerId != 0)) ? settlementRecord.settlementName : "";
        this.pvpTimeOfDay = timeOfDay;
        this.duration = _duration;
        this.ClearScores();
    }

    public override string ToString()
    {
        return string.Concat(new object[] { "<CapturePointVars: ", this.pvpSet, " ", this.captureGameState, " ", GUtil.PrettyPrint(this.companyIds, ", ", "[]"), GUtil.PrettyPrint(this.companyNames, ", ", "[]"), GUtil.PrettyPrint(this.settlementIds, ", ", "[]"), GUtil.PrettyPrint(this.companyScores, ", ", "[]"), this.pvpTimeOfDay, ", ", this.duration, ">" });
    }
}

