﻿using System;
using System.Collections.Generic;
using System.Linq;

[StrongDependency(typeof(UpgradeFeatData)), StrongDependency(typeof(FeatureFeatData)), StrongDependency(typeof(ReactiveFeatData)), StrongDependency(typeof(DefensiveFeatData)), StrongDependency(typeof(AdministrativeFeatData)), StrongDependency(typeof(ArmorFeatData)), StrongDependency(typeof(RefreshFeatData)), LooseDependency(typeof(FeatAdvancementData)), LooseDependency(typeof(RoleData)), LooseDependency(typeof(AnimationData)), NoExcelData]
public class NonAttackFeatData : FeatData
{
    protected static readonly string[] _mandatoryColumns = new string[] { "feat name", "level", "role", "variable a", "variable b", "variable c", "variable d", "variable e", "effect", "description", "icon" };
    public Combat.Channel channel;
    public CombatModifier[] combatMods;
    public string description;
    public float durationSec;
    public string effects;
    public static Dictionary<int, int> featAdvIdToFeatId = new Dictionary<int, int>();
    public static Dictionary<int, NonAttackFeatData> featsById = new Dictionary<int, NonAttackFeatData>();
    public static Dictionary<string, NonAttackFeatData> featsByName = new Dictionary<string, NonAttackFeatData>();
    public int[] keywordIds;
    public CombatModifier[] keywordMods;
    public byte level;
    public string refreshDescription;
    public int usesPerRefresh;

    public NonAttackFeatData()
    {
        base.type = Combat.FeatType.None;
        base.generalType = Combat.FeatType.None;
        base.displayName = string.Empty;
        this.level = 0;
        base.roleId = 0;
        base.featAdvancementId = 0;
        this.effects = string.Empty;
        this.combatMods = null;
        this.description = string.Empty;
        base.icon = "hud_hotbar_icon_questionmark";
        base.animationId = 0;
        base.usableInStealth = false;
        this.channel = Combat.Channel.Passive;
        this.durationSec = 0f;
        base.stamina = 0;
        base.range = 0f;
        this.refreshDescription = string.Empty;
        this.usesPerRefresh = 0;
        this.keywordIds = null;
        this.keywordMods = null;
    }

    public NonAttackFeatData(string name_, byte level_, string effects_) : base(DataClass.GenerateNameLower(new object[] { name_, level_ }))
    {
        base.displayName = name_;
        this.level = level_;
        this.effects = effects_;
        if (this.effects.Trim() != string.Empty)
        {
            this.combatMods = CombatModifier.Parse(this.effects);
        }
        base.ParseEffectType(this.combatMods);
    }

    private static NonAttackFeatData _AdjustForLevel(NonAttackFeatData source, byte level, byte maxLevel)
    {
        byte num = Math.Min(level, maxLevel);
        foreach (KeyValuePair<int, NonAttackFeatData> pair in featsById)
        {
            if ((pair.Value.featAdvancementId == source.featAdvancementId) && (pair.Value.level == num))
            {
                return pair.Value;
            }
        }
        return null;
    }

    public static void AdjustForLevel(ref int[] sourceFeatIds, AdvancementVars advancementVars)
    {
        for (int i = 0; i < sourceFeatIds.Length; i++)
        {
            NonAttackFeatData data;
            if (featsById.TryGetValue(sourceFeatIds[i], out data))
            {
                FeatData featById = FeatDatabase.GetFeatById(sourceFeatIds[i]);
                byte featLevelByFeatAdvancementId = advancementVars.GetFeatLevelByFeatAdvancementId(featById.featAdvancementId);
                if (featLevelByFeatAdvancementId == 0)
                {
                    sourceFeatIds[i] = 0;
                }
                else
                {
                    byte maxLevel = advancementVars.ignoreSupport ? ((byte) 0xff) : TrainerData2.GetSupportLevel(advancementVars.settlementDataId, advancementVars.maxTrainerLevel, featById.featAdvancementId);
                    NonAttackFeatData data3 = _AdjustForLevel(data, featLevelByFeatAdvancementId, maxLevel);
                    sourceFeatIds[i] = (data3 == null) ? sourceFeatIds[i] : data3.id;
                }
            }
        }
    }

    public static int FeatIdFromName(string name)
    {
        NonAttackFeatData data;
        if (featsByName.TryGetValue(name.ToLower(), out data))
        {
            return data.id;
        }
        DataClass.OutputErrorMessage("Invalid non-attack feat: " + name);
        return 0;
    }

    protected DataClass GenericParse(NonAttackFeatData obj, int index)
    {
        string str;
        int num;
        int num2;
        int num3;
        int num4;
        int num5;
        ParseException exception;
        if (!DataClass.TryGetCellValue(DataClass.columnNamesToIndex["feat name"], index, out obj.displayName))
        {
            return null;
        }
        DataClass.GetCellValue(DataClass.columnNamesToIndex["level"], index, out obj.level);
        obj.name = DataClass.GenerateNameLower(new object[] { obj.displayName, obj.level });
        if (!((!DataClass.columnNamesToIndex.ContainsKey("feat xp cost link") || !DataClass.GetCellValue(DataClass.columnNamesToIndex["feat xp cost link"], index, out str)) || string.IsNullOrEmpty(str)))
        {
            DataClass.GetIdFromForeignName<FeatAdvancementData>(DataClass.columnNamesToIndex["feat xp cost link"], index, out obj.featAdvancementId);
        }
        DataClass.GetIdFromForeignName<RoleData>(DataClass.columnNamesToIndex["role"], index, out obj.roleId);
        DataClass.TryGetCellValue(DataClass.columnNamesToIndex["variable a"], index, out num);
        DataClass.TryGetCellValue(DataClass.columnNamesToIndex["variable b"], index, out num2);
        DataClass.TryGetCellValue(DataClass.columnNamesToIndex["variable c"], index, out num3);
        DataClass.TryGetCellValue(DataClass.columnNamesToIndex["variable d"], index, out num4);
        DataClass.TryGetCellValue(DataClass.columnNamesToIndex["variable e"], index, out num5);
        DataClass.TryGetCellValue(DataClass.columnNamesToIndex["effect"], index, out obj.effects);
        DataClass.GetCellValue(DataClass.columnNamesToIndex["description"], index, out obj.description);
        if (DataClass.columnNamesToIndex.ContainsKey("seconds"))
        {
            DataClass.GetCellValue(DataClass.columnNamesToIndex["seconds"], index, out obj.durationSec);
        }
        if (DataClass.columnNamesToIndex.ContainsKey("stamina"))
        {
            DataClass.GetCellValue(DataClass.columnNamesToIndex["stamina"], index, out obj.stamina);
        }
        if (DataClass.columnNamesToIndex.ContainsKey("range"))
        {
            DataClass.TryGetCellValue(DataClass.columnNamesToIndex["range"], index, out obj.range);
        }
        string output = null;
        if (DataClass.columnNamesToIndex.ContainsKey("uses per refresh"))
        {
            DataClass.TryGetCellValue(DataClass.columnNamesToIndex["uses per refresh"], index, out output);
        }
        if (DataClass.columnNamesToIndex.ContainsKey("refresh description"))
        {
            DataClass.GetCellValue(DataClass.columnNamesToIndex["refresh description"], index, out obj.refreshDescription);
        }
        if (DataClass.columnNamesToIndex.ContainsKey("animation"))
        {
            str = null;
            DataClass.GetCellValue(DataClass.columnNamesToIndex["animation"], index, out str);
            if (!(string.IsNullOrEmpty(str.Trim()) || DataClass.TryGetIdFromForeignName<AnimationData>(DataClass.columnNamesToIndex["animation"], index, out obj.animationId)))
            {
                obj.animationId = AnimationData.GetByName("DEFAULT_ANIM").id;
            }
        }
        if (DataClass.columnNamesToIndex.ContainsKey("usable while stealthed?"))
        {
            DataClass.GetCellValue(DataClass.columnNamesToIndex["usable while stealthed?"], index, out obj.usableInStealth);
        }
        string str3 = string.Empty;
        if (DataClass.columnNamesToIndex.ContainsKey("keyword effect"))
        {
            DataClass.GetCellValue(DataClass.columnNamesToIndex["keyword effect"], index, out str3);
        }
        if (DataClass.columnNamesToIndex.ContainsKey("cooldown"))
        {
            DataClass.TryGetCellValue(DataClass.columnNamesToIndex["cooldown"], index, out obj.durationCooldown);
        }
        if (DataClass.columnNamesToIndex.ContainsKey("channel"))
        {
            DataClass.TryGetEnumCellValue<Combat.Channel>(DataClass.columnNamesToIndex["channel"], index, Combat.Channel.Passive, out obj.channel);
        }
        DataClass.GetCellValue(DataClass.columnNamesToIndex["icon"], index, out obj.icon);
        if (string.IsNullOrEmpty(obj.icon))
        {
            obj.icon = "hud_hotbar_icon_questionmark";
        }
        ParseVariables(ref output, num, num2, num3, num4, num5);
        if (!string.IsNullOrEmpty(output))
        {
            obj.usesPerRefresh = int.Parse(output);
        }
        ParseVariables(ref obj.effects, num, num2, num3, num4, num5);
        ParseVariables(ref obj.description, num, num2, num3, num4, num5);
        ParseVariables(ref obj.refreshDescription, num, num2, num3, num4, num5);
        ParseVariables(ref str3, num, num2, num3, num4, num5);
        try
        {
            if (obj.effects.Trim() != string.Empty)
            {
                obj.combatMods = CombatModifier.Parse(obj.effects);
            }
        }
        catch (ParseException exception1)
        {
            exception = exception1;
            DataClass.OutputErrorMessage((("\n" + "  " + obj.name + ": GoblinSpec parsing error!\n") + "     effects:      " + obj.effects + "\n") + "    >>ERROR: " + exception.Message + "\n");
        }
        try
        {
            if (str3.Trim() != string.Empty)
            {
                obj.keywordMods = CombatModifier.Parse(str3);
            }
        }
        catch (ParseException exception2)
        {
            exception = exception2;
            DataClass.OutputErrorMessage((("\n" + "  " + obj.name + ": GoblinSpec parsing error!\n") + "     keyword effects:      " + str3 + "\n") + "    >>ERROR: " + exception.Message + "\n");
        }
        obj.ParseEffectType(obj.combatMods);
        return obj;
    }

    public static IEnumerable<NonAttackFeatData> GetAvailableFeats(Entity playerEntity, AdvancementVars playerAdvancementVars)
    {
        return (from eachfeat in featsById.Values
            where playerAdvancementVars.GetFeatLevelByFeatId(eachfeat.id) == eachfeat.level
            orderby eachfeat.displayName descending
            select eachfeat);
    }

    public static NonAttackFeatData GetFeatById(int id)
    {
        if (id != 0)
        {
            NonAttackFeatData data;
            if (featsById.TryGetValue(id, out data))
            {
                return data;
            }
            DataClass.OutputErrorMessage("Invalid non-attack feat: " + id);
        }
        return null;
    }

    public static NonAttackFeatData GetFeatByName(string name)
    {
        return featsByName[name.ToLower()];
    }

    public override List<DataClass> MergeData()
    {
        List<DataClass> retVal = new List<DataClass>();
        foreach (NonAttackFeatData data in DataClass.GetData(typeof(RefreshFeatData)))
        {
            retVal.Add(data);
        }
        foreach (NonAttackFeatData data2 in DataClass.GetData(typeof(FeatureFeatData)))
        {
            retVal.Add(data2);
        }
        foreach (NonAttackFeatData data3 in DataClass.GetData(typeof(ReactiveFeatData)))
        {
            retVal.Add(data3);
        }
        foreach (NonAttackFeatData data4 in DataClass.GetData(typeof(DefensiveFeatData)))
        {
            retVal.Add(data4);
        }
        foreach (NonAttackFeatData data5 in DataClass.GetData(typeof(AdministrativeFeatData)))
        {
            retVal.Add(data5);
        }
        foreach (NonAttackFeatData data6 in DataClass.GetData(typeof(ArmorFeatData)))
        {
            retVal.Add(data6);
        }
        foreach (NonAttackFeatData data7 in DataClass.GetData(typeof(UpgradeFeatData)))
        {
            retVal.Add(data7);
        }
        Dictionary<int, bool> cachedResults = new Dictionary<int, bool>();
        cachedResults[0] = true;
        List<DataClass> list = new List<DataClass>(from each in retVal
            where ValidateLevelSequence(ref cachedResults, ((NonAttackFeatData) each).featAdvancementId, retVal)
            select each);
        IEnumerable<string> source = from each in retVal
            where !cachedResults[((NonAttackFeatData) each).featAdvancementId]
            select each.name;
        if (source.Count<string>() > 0)
        {
            DataClass.OutputErrorMessage("NonAttackFeats with out-of-sequence levels:" + GUtil.PrettyPrint(source, ", ", "[]"));
        }
        return list;
    }

    public static void OnLoad(List<DataClass> objects)
    {
        featsByName.Clear();
        featsById.Clear();
        foreach (NonAttackFeatData data in objects)
        {
            featsByName[data.name] = data;
            featsById[data.id] = data;
            featAdvIdToFeatId[data.featAdvancementId] = data.id;
        }
    }

    protected static void ParseVariables(ref string input, int a, int b, int c, int d, int e)
    {
        if (!string.IsNullOrEmpty(input))
        {
            input = input.Replace("{A}", a.ToString());
            input = input.Replace("{B}", b.ToString());
            input = input.Replace("{C}", c.ToString());
            input = input.Replace("{D}", d.ToString());
            input = input.Replace("{E}", e.ToString());
        }
    }

    private static bool ValidateLevelSequence(ref Dictionary<int, bool> cachedResults, int eachFeatAdvancementId, IEnumerable<DataClass> allFeats)
    {
        if (cachedResults.ContainsKey(eachFeatAdvancementId))
        {
            return cachedResults[eachFeatAdvancementId];
        }
        bool flag = true;
        int num = 1;
        foreach (NonAttackFeatData data in from each in allFeats
            where ((NonAttackFeatData) each).featAdvancementId == eachFeatAdvancementId
            orderby ((NonAttackFeatData) each).level
            select each)
        {
            if (num != data.level)
            {
                flag = false;
            }
            num++;
        }
        cachedResults[eachFeatAdvancementId] = flag;
        return flag;
    }

    protected override IEnumerable<string> GetMandatoryColumns
    {
        get
        {
            return _mandatoryColumns;
        }
    }
}

