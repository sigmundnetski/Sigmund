﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

internal class DataSerializerProfile : UUnitTestCase
{
    private BindingFlags BIND_FLAGS = BindingFlags.Default;
    private System.Type type = null;

    [UUnitProfileMethod]
    public void ProfileArrayLinqToArray()
    {
        uint[] numArray = new uint[0x3e8];
        for (uint i = 0; i < numArray.Length; i++)
        {
            numArray[i] = i;
        }
        for (int j = 0; j < 0x3e8; j++)
        {
            uint[] numArray2 = (from num in numArray
                where (num % 2) == 0
                select num).ToArray<uint>();
        }
    }

    [UUnitProfileMethod]
    public void ProfileArrayLinqToList()
    {
        uint[] numArray = new uint[0x3e8];
        for (uint i = 0; i < numArray.Length; i++)
        {
            numArray[i] = i;
        }
        for (int j = 0; j < 0x3e8; j++)
        {
            List<uint> list = (from num in numArray
                where (num % 2) == 0
                select num).ToList<uint>();
        }
    }

    [UUnitProfileMethod]
    public void ProfileCheckForAttributeFromStatic()
    {
        bool flag = false;
        for (int i = 0; i < 0x2710; i++)
        {
            flag = Attribute.IsDefined(this.type, typeof(DataRestrict), true);
        }
    }

    [UUnitProfileMethod]
    public void ProfileCheckForAttributeFromType()
    {
        bool flag = false;
        DataRestrict restrict = new DataRestrict();
        for (int i = 0; i < 0x2710; i++)
        {
            flag = this.type.GetCustomAttributes(typeof(DataRestrict), true).Contains<object>(restrict);
        }
    }

    [UUnitProfileMethod]
    public void ProfileGetAttributeFromStatic()
    {
        for (int i = 0; i < 0x2710; i++)
        {
            DataRestrict restrict = (DataRestrict) Attribute.GetCustomAttribute(this.type, typeof(DataRestrict), true);
        }
    }

    [UUnitProfileMethod]
    public void ProfileGetAttributeFromType()
    {
        for (int i = 0; i < 0x2710; i++)
        {
            DataRestrict restrict = (DataRestrict) this.type.GetCustomAttributes(typeof(DataRestrict), true).FirstOrDefault<object>();
        }
    }

    [UUnitProfileMethod]
    public void ProfileGetValue()
    {
        GFTestClass class2 = new GFTestClass(5, "hello");
        FieldInfo field = typeof(GFTestClass).GetField("id", BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance);
        FieldInfo info2 = typeof(GFTestClass).GetField("text", BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance);
        FieldInfo info3 = typeof(GFTestClass).GetField("str", BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance);
        FieldInfo info4 = typeof(GFTestClass).GetField("cls", BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance);
        for (int i = 0; i < 0x186a0; i++)
        {
            int num2 = (int) field.GetValue(class2);
            string str = (string) info2.GetValue(class2);
            GFTestSubStruct struct2 = (GFTestSubStruct) info3.GetValue(class2);
            GFTestSubClass class3 = (GFTestSubClass) info4.GetValue(class2);
        }
    }

    [UUnitProfileMethod]
    public void ProfileGetValueDirect()
    {
        GFTestClass target = new GFTestClass(5, "hello");
        FieldInfo field = typeof(GFTestClass).GetField("id", BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance);
        FieldInfo fld = typeof(GFTestClass).GetField("text", BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance);
        FieldInfo info3 = typeof(GFTestClass).GetField("str", BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance);
        FieldInfo info4 = typeof(GFTestClass).GetField("cls", BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance);
        DataSerializer.GetValueDirectDelegate<int> cachedGetValueDirectDelegate = DataSerializer.GetCachedGetValueDirectDelegate<int>(field);
        DataSerializer.GetValueDirectDelegate<string> delegate3 = DataSerializer.GetCachedGetValueDirectDelegate<string>(fld);
        DataSerializer.GetValueDirectDelegate<object> delegate4 = DataSerializer.GetCachedGetValueDirectDelegate<object>(info3);
        DataSerializer.GetValueDirectDelegate<object> delegate5 = DataSerializer.GetCachedGetValueDirectDelegate<object>(info4);
        for (int i = 0; i < 0x186a0; i++)
        {
            int num2 = cachedGetValueDirectDelegate(target);
            string str = delegate3(target);
            GFTestSubStruct struct2 = (GFTestSubStruct) delegate4(target);
            GFTestSubClass class3 = (GFTestSubClass) delegate5(target);
        }
    }

    [UUnitProfileMethod]
    public void ProfileLinqForeachLoop()
    {
        List<FieldInfo> list = new List<FieldInfo>();
        for (int i = 0; i < 0x3e8; i++)
        {
            list.Clear();
            foreach (FieldInfo info in this.type.GetFields(this.BIND_FLAGS))
            {
                if (!Attribute.IsDefined(info, typeof(DataRestrict)))
                {
                    list.Add(info);
                }
            }
        }
    }

    [UUnitProfileMethod]
    public void ProfileLinqForLoop()
    {
        List<FieldInfo> list = new List<FieldInfo>();
        FieldInfo[] fields = new FieldInfo[1];
        for (int i = 0; i < 0x3e8; i++)
        {
            list.Clear();
            fields = this.type.GetFields(this.BIND_FLAGS);
            for (int j = 0; j < fields.Length; j++)
            {
                if (!Attribute.IsDefined(fields[j], typeof(DataRestrict)))
                {
                    list.Add(fields[j]);
                }
            }
        }
    }

    [UUnitProfileMethod]
    public void ProfileLinqKeywords()
    {
        for (int i = 0; i < 0x3e8; i++)
        {
            IOrderedEnumerable<FieldInfo> enumerable = from field in this.type.GetFields(this.BIND_FLAGS)
                where !Attribute.IsDefined(field, typeof(DataRestrict))
                orderby field.Name
                select field;
            enumerable = null;
        }
    }

    [UUnitProfileMethod]
    public void ProfileLinqListMembers()
    {
        for (int i = 0; i < 0x3e8; i++)
        {
            IOrderedEnumerable<FieldInfo> enumerable = from x in this.type.GetFields(this.BIND_FLAGS)
                where !Attribute.IsDefined(x, typeof(DataRestrict))
                orderby x.Name
                select x;
            enumerable = null;
        }
    }

    [UUnitProfileMethod]
    public void ProfileLinqListMembersManualToList()
    {
        List<FieldInfo> list = new List<FieldInfo>();
        for (int i = 0; i < 0x3e8; i++)
        {
            IOrderedEnumerable<FieldInfo> enumerable = from x in this.type.GetFields(this.BIND_FLAGS)
                where !Attribute.IsDefined(x, typeof(DataRestrict))
                orderby x.Name
                select x;
            foreach (FieldInfo info in enumerable)
            {
                list.Add(info);
            }
            enumerable = null;
        }
    }

    [UUnitProfileMethod]
    public void ProfileLinqListMembersToArray()
    {
        for (int i = 0; i < 0x3e8; i++)
        {
            FieldInfo[] infoArray = (from x in this.type.GetFields(this.BIND_FLAGS)
                where !Attribute.IsDefined(x, typeof(DataRestrict))
                orderby x.Name
                select x).ToArray<FieldInfo>();
            infoArray = null;
        }
    }

    [UUnitProfileMethod]
    public void ProfileLinqListMembersToList()
    {
        for (int i = 0; i < 0x3e8; i++)
        {
            List<FieldInfo> list = (from x in this.type.GetFields(this.BIND_FLAGS)
                where !Attribute.IsDefined(x, typeof(DataRestrict))
                orderby x.Name
                select x).ToList<FieldInfo>();
            list = null;
        }
    }

    [UUnitProfileMethod]
    public void ProfileListLinqToArray()
    {
        List<uint> list = new List<uint>(0x3e8);
        for (uint i = 0; i < 0x3e8; i++)
        {
            list.Add(i);
        }
        for (int j = 0; j < 0x3e8; j++)
        {
            uint[] numArray = (from num in list
                where (num % 2) == 0
                select num).ToArray<uint>();
        }
    }

    [UUnitProfileMethod]
    public void ProfileListLinqToList()
    {
        List<uint> list = new List<uint>(0x3e8);
        for (uint i = 0; i < 0x3e8; i++)
        {
            list.Add(i);
        }
        for (int j = 0; j < 0x3e8; j++)
        {
            List<uint> list2 = (from num in list
                where (num % 2) == 0
                select num).ToList<uint>();
        }
    }

    [UUnitProfileMethod]
    public void ProfileMaxRestrictionLod()
    {
        FieldInfo[] fields = new FieldInfo[1];
        for (int i = 0; i < 0x3e8; i++)
        {
            byte targetLevel = 0;
            fields = this.type.GetFields(this.BIND_FLAGS);
            for (int j = 0; j < fields.Length; j++)
            {
                if (Attribute.IsDefined(fields[j], typeof(DataSyncTo)))
                {
                    DataSyncTo customAttribute = (DataSyncTo) Attribute.GetCustomAttribute(fields[j], typeof(DataSyncTo));
                    if (customAttribute.TargetLevel > targetLevel)
                    {
                        targetLevel = customAttribute.TargetLevel;
                    }
                }
            }
        }
    }

    [UUnitProfileMethod]
    public void ProfileMaxRestrictionLodLinq()
    {
        for (int i = 0; i < 0x3e8; i++)
        {
            byte targetLevel = 0;
            FieldInfo element = (from x in this.type.GetFields(this.BIND_FLAGS)
                where Attribute.IsDefined(x, typeof(DataSyncTo))
                orderby ((DataSyncTo) Attribute.GetCustomAttribute(x, typeof(DataSyncTo))).TargetLevel descending
                select x).FirstOrDefault<FieldInfo>();
            if (element != null)
            {
                targetLevel = ((DataSyncTo) Attribute.GetCustomAttribute(element, typeof(DataSyncTo))).TargetLevel;
            }
            else
            {
                targetLevel = 0;
            }
        }
    }

    [UUnitProfileMethod]
    public void ProfileMaxRestrictionLodLinqKeywords()
    {
        for (int i = 0; i < 0x3e8; i++)
        {
            byte targetLevel;
            IEnumerable<DataSyncTo> source = from t in this.type.GetFields(this.BIND_FLAGS)
                where Attribute.IsDefined(t, typeof(DataSyncTo))
                let attr = (DataSyncTo) Attribute.GetCustomAttribute(t, typeof(DataSyncTo))
                orderby attr.TargetLevel descending
                select attr;
            if (source.Any<DataSyncTo>())
            {
                targetLevel = source.First<DataSyncTo>().TargetLevel;
            }
            else
            {
                targetLevel = 0;
            }
        }
    }

    [UUnitProfileMethod]
    public void ProfileMaxRestrictionLodLinqKeywordsMax()
    {
        for (int i = 0; i < 0x3e8; i++)
        {
            byte num;
            IEnumerable<DataSyncTo> source = from field in this.type.GetFields(this.BIND_FLAGS)
                where Attribute.IsDefined(field, typeof(DataSyncTo))
                let attr = (DataSyncTo) Attribute.GetCustomAttribute(field, typeof(DataSyncTo))
                select attr;
            if (source.Any<DataSyncTo>())
            {
                num = Enumerable.Max<DataSyncTo, byte>(source, (Func<DataSyncTo, byte>) (x => x.TargetLevel));
            }
            else
            {
                num = 0;
            }
        }
    }

    [UUnitProfileMethod]
    public void ProfileMaxRestrictionLodLinqKeywordsToUIntMax()
    {
        for (int i = 0; i < 0x3e8; i++)
        {
            byte num;
            IEnumerable<byte> source = from field in this.type.GetFields(this.BIND_FLAGS)
                where Attribute.IsDefined(field, typeof(DataSyncTo))
                let attr = (DataSyncTo) Attribute.GetCustomAttribute(field, typeof(DataSyncTo))
                select attr.TargetLevel;
            if (source.Any<byte>())
            {
                num = source.Max<byte>();
            }
            else
            {
                num = 0;
            }
        }
    }

    [UUnitProfileMethod]
    public void ProfileMaxRestrictionLodLinqKeywordsToUIntMaxNoLet()
    {
        for (int i = 0; i < 0x3e8; i++)
        {
            byte num;
            IEnumerable<byte> source = from field in this.type.GetFields(this.BIND_FLAGS)
                where Attribute.IsDefined(field, typeof(DataSyncTo))
                select ((DataSyncTo) Attribute.GetCustomAttribute(field, typeof(DataSyncTo))).TargetLevel;
            if (source.Any<byte>())
            {
                num = source.Max<byte>();
            }
            else
            {
                num = 0;
            }
        }
    }

    [UUnitProfileMethod]
    public void ProfileMaxRestrictionLodLinqMax()
    {
        for (int i = 0; i < 0x3e8; i++)
        {
            byte num = 0;
            IEnumerable<FieldInfo> source = from x in this.type.GetFields(this.BIND_FLAGS)
                where Attribute.IsDefined(x, typeof(DataSyncTo))
                select x;
            if (source.Any<FieldInfo>())
            {
                num = Enumerable.Max<FieldInfo, byte>(source, (Func<FieldInfo, byte>) (x => ((DataSyncTo) Attribute.GetCustomAttribute(x, typeof(DataSyncTo))).TargetLevel));
            }
            else
            {
                num = 0;
            }
        }
    }

    [UUnitProfileMethod]
    public void ProfileMaxRestrictionLodLinqMix()
    {
        for (int i = 0; i < 0x3e8; i++)
        {
            byte targetLevel = 0;
            IEnumerable<FieldInfo> enumerable = from x in this.type.GetFields(this.BIND_FLAGS)
                where Attribute.IsDefined(x, typeof(DataSyncTo))
                select x;
            foreach (FieldInfo info in enumerable)
            {
                DataSyncTo customAttribute = (DataSyncTo) Attribute.GetCustomAttribute(info, typeof(DataSyncTo));
                if (customAttribute.TargetLevel > targetLevel)
                {
                    targetLevel = customAttribute.TargetLevel;
                }
            }
        }
    }

    [UUnitProfileMethod]
    public void ProfileMaxRestrictionLodNoCheck()
    {
        FieldInfo[] fields = new FieldInfo[1];
        for (int i = 0; i < 0x3e8; i++)
        {
            byte targetLevel = 0;
            fields = this.type.GetFields(this.BIND_FLAGS);
            for (int j = 0; j < fields.Length; j++)
            {
                DataSyncTo customAttribute = (DataSyncTo) Attribute.GetCustomAttribute(fields[j], typeof(DataSyncTo));
                if ((customAttribute != null) && (customAttribute.TargetLevel > targetLevel))
                {
                    targetLevel = customAttribute.TargetLevel;
                }
            }
        }
    }

    [UUnitProfileMethod]
    public void ProfileReuseLinqInExcept()
    {
        uint[] numArray = new uint[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 0 };
        uint[] first = new uint[] { 1, 3, 0, 5, 6, 8 };
        uint[] numArray3 = new uint[] { 2, 1, 4, 5, 9, 8, 3 };
        uint[] second = new uint[] { 1, 3, 5 };
        uint[] numArray5 = new uint[] { 1, 5, 9, 3 };
        IEnumerable<uint> enumerable = from num in numArray
            where (num % 2) == 0
            select num;
        UUnitAssert.True(first.Except<uint>(enumerable).SequenceEqual<uint>(second), "Fail");
        UUnitAssert.True(numArray3.Except<uint>(enumerable).SequenceEqual<uint>(numArray5), "Fail");
    }

    [UUnitProfileMethod]
    public void ProfileSetValue()
    {
        GFTestClass class2 = new GFTestClass(5, "hello");
        FieldInfo field = typeof(GFTestClass).GetField("id", BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance);
        FieldInfo info2 = typeof(GFTestClass).GetField("text", BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance);
        FieldInfo info3 = typeof(GFTestClass).GetField("str", BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance);
        FieldInfo info4 = typeof(GFTestClass).GetField("cls", BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance);
        GFTestSubStruct struct2 = new GFTestSubStruct(20, "howwego");
        GFTestSubClass class3 = new GFTestSubClass(15, "whatitdo");
        for (int i = 0; i < 0x186a0; i++)
        {
            field.SetValue(class2, 10);
            info2.SetValue(class2, "newworld");
            info3.SetValue(class2, struct2);
            info4.SetValue(class2, class3);
        }
    }

    [UUnitProfileMethod]
    public void ProfileSetValueDirect()
    {
        GFTestClass class2 = new GFTestClass(5, "hello");
        FieldInfo field = typeof(GFTestClass).GetField("id", BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance);
        FieldInfo fld = typeof(GFTestClass).GetField("text", BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance);
        FieldInfo info3 = typeof(GFTestClass).GetField("str", BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance);
        FieldInfo info4 = typeof(GFTestClass).GetField("cls", BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance);
        DataSerializer.SetValueDirectDelegate<int> cachedSetValueDirectDelegate = DataSerializer.GetCachedSetValueDirectDelegate<int>(field);
        DataSerializer.SetValueDirectDelegate<string> delegate3 = DataSerializer.GetCachedSetValueDirectDelegate<string>(fld);
        DataSerializer.SetValueDirectDelegate<object> delegate4 = DataSerializer.GetCachedSetValueDirectDelegate<object>(info3);
        DataSerializer.SetValueDirectDelegate<object> delegate5 = DataSerializer.GetCachedSetValueDirectDelegate<object>(info4);
        GFTestSubStruct struct2 = new GFTestSubStruct(20, "howwego");
        GFTestSubClass class3 = new GFTestSubClass(15, "whatitdo");
        object target = class2;
        for (int i = 0; i < 0x186a0; i++)
        {
            cachedSetValueDirectDelegate(ref target, 10);
            delegate3(ref target, "newworld");
            delegate4(ref target, struct2);
            delegate5(ref target, class3);
        }
    }

    protected override void SetUp()
    {
        this.type = typeof(CombatVars);
        this.type.GetFields(this.BIND_FLAGS);
        this.BIND_FLAGS = BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance;
    }
}

