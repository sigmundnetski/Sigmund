﻿using System;

internal class GFTestDerivedClass2 : GFTestBaseClass
{
    public float derived2Obj = 2f;
}

