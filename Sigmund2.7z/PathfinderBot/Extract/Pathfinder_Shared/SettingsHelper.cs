﻿using System;
using System.Linq;
using System.Runtime.InteropServices;
using UnityEngine;

public static class SettingsHelper
{
    private static string[] FALSE_STRINGS = new string[] { "false", "f", "n", "no" };
    private static string[] TRUE_STRINGS = new string[] { "true", "t", "y", "yes" };

    public static GwResolution[] GetResolutions()
    {
        int resolutionsLength = GwRes.GetResolutionsLength();
        if (resolutionsLength == 0)
        {
            return GetUnityResolutions();
        }
        GwResolution[] resolutionArray = new GwResolution[resolutionsLength];
        IntPtr resolutions = Marshal.AllocCoTaskMem(resolutionsLength * Marshal.SizeOf(typeof(GwResolution)));
        GwRes.GetAllResolutions(resolutions);
        IntPtr ptr = new IntPtr(resolutions.ToInt64());
        for (int i = 0; i < resolutionsLength; i++)
        {
            resolutionArray[i] = (GwResolution) Marshal.PtrToStructure(ptr, typeof(GwResolution));
            ptr = new IntPtr(ptr.ToInt64() + Marshal.SizeOf(typeof(GwResolution)));
        }
        Marshal.FreeCoTaskMem(resolutions);
        return resolutionArray;
    }

    private static GwResolution[] GetUnityResolutions()
    {
        Resolution[] resolutions = Screen.resolutions;
        GwResolution[] resolutionArray2 = new GwResolution[resolutions.Length];
        for (int i = 0; i < resolutions.Length; i++)
        {
            resolutionArray2[i].monId = 0;
            resolutionArray2[i].width = (ushort) resolutions[i].width;
            resolutionArray2[i].height = (ushort) resolutions[i].height;
        }
        return resolutionArray2;
    }

    private static bool ParseResolution(string resolution, out uint width, out uint height)
    {
        width = 0;
        height = 0;
        if (string.IsNullOrEmpty(resolution))
        {
            return false;
        }
        string[] strArray = resolution.ToLower().Split(new char[] { 'x' });
        if (!(((strArray.Length == 2) && uint.TryParse(strArray[0], out width)) && uint.TryParse(strArray[1], out height)))
        {
            return false;
        }
        return true;
    }

    private static bool ParseWindowed(string windowedStr, out bool windowed)
    {
        windowed = true;
        if (!string.IsNullOrEmpty(windowedStr))
        {
            windowedStr = windowedStr.ToLower();
            if (TRUE_STRINGS.Contains<string>(windowedStr))
            {
                windowed = true;
                goto Label_004F;
            }
            if (FALSE_STRINGS.Contains<string>(windowedStr))
            {
                windowed = false;
                goto Label_004F;
            }
        }
        return false;
    Label_004F:
        return true;
    }

    public static void SetQuality(string qualityStr)
    {
        if (!string.IsNullOrEmpty(qualityStr))
        {
            qualityStr = qualityStr.ToLower();
            uint index = 0;
            while (index < QualitySettings.names.Length)
            {
                if (QualitySettings.names[index].ToLower() == qualityStr)
                {
                    break;
                }
                index++;
            }
            if (index < QualitySettings.names.Length)
            {
                SetQuality(index);
            }
        }
    }

    public static void SetQuality(uint quality)
    {
        QualitySettings.SetQualityLevel((int) quality);
    }

    public static void SetResolution(string resolution, string windowedStr)
    {
        uint width = 0;
        uint height = 0;
        bool windowed = true;
        bool flag2 = ParseResolution(resolution, out width, out height);
        bool flag3 = ParseWindowed(windowedStr, out windowed);
        if (!(!flag2 || flag3))
        {
            SetResolution(width, height);
        }
        else if (!(flag2 || !flag3))
        {
            SetWindowed(windowed);
        }
        else if (flag2 && flag3)
        {
            SetResolution(width, height, !windowed);
        }
    }

    public static void SetResolution(uint width, uint height)
    {
        SetResolution(width, height, Screen.fullScreen);
    }

    public static void SetResolution(uint width, uint height, bool isFullscreen)
    {
        bool flag = true;
        if (isFullscreen)
        {
            flag = false;
            for (int i = 0; i < Screen.resolutions.Length; i++)
            {
                if ((Screen.resolutions[i].width == width) && (Screen.resolutions[i].height == height))
                {
                    flag = true;
                    break;
                }
            }
        }
        if (flag)
        {
            Screen.SetResolution((int) width, (int) height, isFullscreen);
        }
        else
        {
            GLog.LogError(new object[] { string.Concat(new object[] { "Unsupported fullscreen resolution requested - ignoring ", width, "x", height }) });
        }
    }

    public static void SetWindowed(bool windowed)
    {
        Screen.fullScreen = !windowed;
    }

    private static class GwRes
    {
        [DllImport("RenderingPlugin")]
        public static extern void GetAllResolutions(IntPtr resolutions);
        [DllImport("RenderingPlugin")]
        public static extern int GetResolutionsLength();
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct GwResolution
    {
        public byte monId;
        public ushort width;
        public ushort height;
        private GwResolution(byte _monId, ushort _width, ushort _height)
        {
            this.monId = _monId;
            this.width = _width;
            this.height = _height;
        }
    }
}

