﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

public static class CommandCore
{
    public static readonly char[] COMMAND_SPLIT = new char[] { ';' };
    public static FallbackDelegate commandFallback = null;
    private static Dictionary<string, Command> commands = new Dictionary<string, Command>();
    public static PermissionLevelDelegate getPlayerPermission = null;
    public static bool initialized = false;
    public static CommandLogDelegate logCommand = null;
    public static readonly char[] SPACE_SPLIT = new char[] { ' ' };

    private static void AssertInit()
    {
        if (!initialized)
        {
            throw new Exception("CommandCore not initialized yet.");
        }
    }

    public static void ExecuteAllCommands(string commaSeparatedCommands, EntityId playerEntityId)
    {
        string[] strArray = commaSeparatedCommands.Split(COMMAND_SPLIT, StringSplitOptions.RemoveEmptyEntries);
        foreach (string str in strArray)
        {
            ExecuteCommand(str, playerEntityId);
        }
    }

    public static void ExecuteCommand(string command, EntityId playerEntityId)
    {
        AssertInit();
        try
        {
            if (!string.IsNullOrEmpty(command))
            {
                Command command2;
                int index = command.IndexOf(' ');
                string key = ((index > 0) ? command.Substring(0, index) : command).ToLower();
                if (commands.TryGetValue(key, out command2))
                {
                    PermissionLevel playerPerm = getPlayerPermission(playerEntityId);
                    if (playerPerm >= command2.minPermission)
                    {
                        bool flag = ((byte) (command2.options & (Options.NONE | Options.RAW_COMMAND_STRING))) == 8;
                        string[] args = null;
                        if (flag)
                        {
                            args = new string[] { command };
                        }
                        else if (((byte) (command2.options & (Options.NONE | Options.PRESERVE_ARG_CASE))) == 4)
                        {
                            args = command.Split(SPACE_SPLIT, StringSplitOptions.RemoveEmptyEntries);
                        }
                        else
                        {
                            args = command.ToLower().Split(SPACE_SPLIT, StringSplitOptions.RemoveEmptyEntries);
                        }
                        if (logCommand != null)
                        {
                            logCommand(playerEntityId, command2.minPermission, playerPerm, command2.name, args);
                        }
                        command2.callback(args, playerEntityId);
                    }
                }
                else if (commandFallback != null)
                {
                    commandFallback(command, playerEntityId);
                }
            }
        }
        catch (Exception exception)
        {
            GLog.LogError(new object[] { "command '" + command + "' failed!", "Exception:", exception.Message, "\n", exception.StackTrace });
        }
    }

    public static bool ExtractLongParam(ref string args, out string param)
    {
        param = null;
        int index = args.IndexOf(',');
        if (index < 1)
        {
            param = args.Trim();
            args = null;
        }
        else
        {
            param = args.Substring(0, index).Trim();
            index++;
            args = args.Substring(index, args.Length - index).Trim();
        }
        return !string.IsNullOrEmpty(param);
    }

    public static List<string> GetAutoComplete(string autoCompleteBase, PermissionLevel userPermission)
    {
        autoCompleteBase = autoCompleteBase.ToLower();
        List<string> list = new List<string>();
        foreach (KeyValuePair<string, Command> pair in commands)
        {
            if (((((byte) (pair.Value.options & Options.AUTO_COMPLETE)) == 1) && (userPermission >= pair.Value.minPermission)) && pair.Key.StartsWith(autoCompleteBase))
            {
                list.Add(pair.Value.name);
            }
        }
        list.Sort();
        return list;
    }

    public static bool IsCommandCallable(string command, EntityId playerEntityId)
    {
        Command command2;
        string[] strArray = command.ToLower().Split(SPACE_SPLIT, StringSplitOptions.RemoveEmptyEntries);
        if (strArray.Length == 0)
        {
            return false;
        }
        return (commands.TryGetValue(strArray[0], out command2) && (getPlayerPermission(playerEntityId) >= command2.minPermission));
    }

    public static void RegisterCommand(string commandName, CommandDelegate callback, PermissionLevel minPermission, Options options = 1, string[] subCommands = null)
    {
        AssertInit();
        Command command = new Command(commandName, callback, options, minPermission, subCommands);
        string key = commandName.ToLower();
        if ((((byte) (options & (Options.NONE | Options.OVERWRITE))) != 2) && commands.ContainsKey(key))
        {
            GLog.LogError(new object[] { "Command '" + commandName + "' has attempted to register multiple times. Ignoring duplicates." });
        }
        else
        {
            commands[key] = command;
        }
    }

    public static bool RemoveCommandFromString(ref string args)
    {
        int index = args.IndexOf(' ');
        if (index < 1)
        {
            return false;
        }
        index++;
        args = args.Substring(index, args.Length - index).Trim();
        return true;
    }

    public static void Reset()
    {
        commands.Clear();
    }

    public delegate List<string> AutoCompleteDelegate(string autoCompleteBase);

    public delegate void AutoCompleteNotifier(string[] autoCompleteOptions);

    public class Command
    {
        public CommandCore.CommandDelegate callback;
        public CommandCore.PermissionLevel minPermission;
        public string name;
        public CommandCore.Options options;
        public string[] subCommands = null;

        public Command(string name_, CommandCore.CommandDelegate callback_, CommandCore.Options options_, CommandCore.PermissionLevel minPermission_, string[] subCommands_)
        {
            this.name = name_;
            this.callback = callback_;
            this.options = options_;
            this.minPermission = minPermission_;
            this.subCommands = subCommands_;
        }
    }

    public delegate void CommandDelegate(string[] args, EntityId playerEntityId);

    public delegate void CommandLogDelegate(EntityId playerEntityId, CommandCore.PermissionLevel cmdPerm, CommandCore.PermissionLevel playerPerm, string command, string[] args);

    public delegate void FallbackDelegate(string command, EntityId playerEntityId);

    [Flags]
    public enum Options : byte
    {
        AUTO_COMPLETE = 1,
        NONE = 0,
        OVERWRITE = 2,
        PRESERVE_ARG_CASE = 4,
        RAW_COMMAND_STRING = 8
    }

    public enum PermissionLevel : byte
    {
        DEBUG = 3,
        GM = 1,
        TESTING = 2,
        USER = 0
    }

    public delegate CommandCore.PermissionLevel PermissionLevelDelegate(EntityId playerEntityId);
}

