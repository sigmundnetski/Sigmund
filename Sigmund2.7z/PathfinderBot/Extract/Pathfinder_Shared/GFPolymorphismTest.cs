﻿using System;

internal class GFPolymorphismTest
{
    public GFTestBaseClass obj;
}

