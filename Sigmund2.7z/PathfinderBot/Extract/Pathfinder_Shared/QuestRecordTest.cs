﻿using Newtonsoft.Json;
using System;

internal class QuestRecordTest : UUnitTestCase
{
    [UUnitTestMethod]
    private void TestRecordJson()
    {
        QuestData questData = EscalationDataUnitHelper.NewQuest("testQuest", EscalationConst.StateType.Interact, 0, 1, EscalationConst.Flow.INCOMPLETE | EscalationConst.Flow.NEXT | EscalationConst.Flow.SUCCESS);
        QuestRecord record = new QuestRecord(12, questData, 13, 14, EscalationConst.Flow.INCOMPLETE, DateTime.UtcNow);
        QuestRecord got = JsonConvert.DeserializeObject<QuestRecord>(JsonConvert.SerializeObject(record));
        UUnitAssert.DataEquals<QuestRecord>(record, got, 0, "Expected equivalent objects:\n{0}\n!=\n{1}");
    }
}

