﻿using System;
using System.Runtime.InteropServices;

public class InCombatState : TimedStateBuff
{
    public const string OPPORTUNITY_MOD = "Opportunity (1 second) to Self";
    private static CombatModifier[] opportunityCombatMod = CombatModifier.Parse("Opportunity (1 second) to Self");

    public InCombatState() : base("In Combat", Combat.Channel.State, Combat.EffectType.Detrimental)
    {
    }

    public static InCombatState Create()
    {
        return new InCombatState();
    }

    public override bool Expired(CombatBuffVars buff, uint combatTick)
    {
        bool flag = base.Expired(buff, combatTick);
        if (flag)
        {
            buff.owner.refresh.CombatEnded();
        }
        return flag;
    }

    protected override void GetDuration(CombatModifier mod, CombatEffect effect, int defenseBonus, out uint duration, out float successModifier)
    {
        successModifier = 1f;
        duration = (uint) CombatCore.RoundToInt((float) mod.tickDuration);
    }

    public override CombatBuffVars Initialize(uint combatTick, CombatModifier mod, CombatVars target, int additionalDefense)
    {
        CombatBuffVars vars = base.Initialize(combatTick, mod, target, additionalDefense);
        vars.displayOnClient = false;
        return vars;
    }

    public override void RecalculationPhase(CombatBuffVars buff, uint combatTick)
    {
        buff.owner.inCombat = true;
        if (((buff.owner.movementType == CombatVars.MovementType.HUSTLE) || (buff.owner.movementType == CombatVars.MovementType.RUN)) || (buff.owner.jumpType == CombatVars.JumpType.JUMPING))
        {
            CombatEffect item = new CombatEffect(opportunityCombatMod, buff.owner, buff.owner, CombatEffect.TargetType.ATTACKER, Combat.EffectType.Neutral);
            buff.owner.combatEffects.Enqueue(item);
        }
    }

    public override void UpdateBuff(CombatBuffVars buff, uint combatTick, CombatModifier mod, CombatEffect effect)
    {
        base.UpdateBuff(buff, combatTick, mod, effect);
    }
}

