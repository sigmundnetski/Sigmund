﻿using System;

internal class ExpectedException : Exception
{
    public ExpectedException(string message) : base(message)
    {
    }
}

