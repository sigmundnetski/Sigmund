﻿using System;
using System.Collections.Generic;
using System.Reflection;

public static class ServiceList
{
    private const string SERVICE_START_METHOD = "SyncStart";
    private static HashSet<System.Type> startedServices = new HashSet<System.Type>();

    public static void StartOnce(System.Type serviceType, params object[] args)
    {
        if (!startedServices.Contains(serviceType))
        {
            startedServices.Add(serviceType);
            try
            {
                serviceType.InvokeMember("SyncStart", BindingFlags.InvokeMethod | BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Static, null, null, args);
            }
            catch (TargetInvocationException exception)
            {
                GLog.LogError(new object[] { "Cannot start:", serviceType.Name });
                throw exception.InnerException;
            }
        }
    }
}

