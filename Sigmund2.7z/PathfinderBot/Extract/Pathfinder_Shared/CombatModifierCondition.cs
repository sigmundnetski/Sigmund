﻿using System;

public class CombatModifierCondition : IDataCopyable<CombatModifierCondition>
{
    public CombatConstants.AttackState attackState;
    public CombatConstants.Buff buff;
    public bool shouldHave;
    public CombatConstants.Stack stack;
    public CombatConstants.State state;
    public CombatConstants.Target target;
    public CombatModifierType type;
    public int weaponProficiencyId;

    public void DataCopyTo(ref CombatModifierCondition target, byte syncTargetLevel)
    {
        target.target = this.target;
        target.shouldHave = this.shouldHave;
        target.type = this.type;
        target.state = this.state;
        target.buff = this.buff;
        target.stack = this.stack;
        target.weaponProficiencyId = this.weaponProficiencyId;
        target.attackState = this.attackState;
    }

    public bool DataEquals(CombatModifierCondition target, byte syncTargetLevel)
    {
        if (object.ReferenceEquals(this, target))
        {
            return true;
        }
        if (object.ReferenceEquals(target, null))
        {
            return false;
        }
        bool flag = true;
        return ((((((((flag && (target.target == this.target)) && (target.shouldHave == this.shouldHave)) && (target.type == this.type)) && (target.state == this.state)) && (target.buff == this.buff)) && (target.stack == this.stack)) && (target.weaponProficiencyId == this.weaponProficiencyId)) && (target.attackState == this.attackState));
    }
}

