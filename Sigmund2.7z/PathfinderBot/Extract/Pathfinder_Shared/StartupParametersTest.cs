﻿using System;
using System.Collections.Generic;

internal class StartupParametersTest : UUnitTestCase
{
    [UUnitTestMethod]
    private void TestNegativeHexCoords()
    {
        Dictionary<string, string> dictionary = StartupParameters.ParseParameters(new string[] { "exename", "-hexX", "-9", "-hexZ", "-2", "-solo1", "-solo2", "-CAPS", "capsValue", "-path", "//var/goblinweb", "-inner", "--dash-value" });
        string[] wanted = new string[] { "hexx", "hexz", "solo1", "solo2", "caps", "path", "inner" };
        UUnitAssert.SequenceEqual<string>(wanted, dictionary.Keys, "Expected equivalent lists:\n{0}\n!=\n{1}");
        string[] strArray3 = new string[] { "-9", "-2", "", "", "capsValue", "/var/goblinweb", "-dash-value" };
        UUnitAssert.SequenceEqual<string>(strArray3, dictionary.Values, "Expected equivalent lists:\n{0}\n!=\n{1}");
    }
}

