﻿using System;

internal class GFTestKillState : GFTestBaseState
{
    public float damage;
    public string helpText;
}

