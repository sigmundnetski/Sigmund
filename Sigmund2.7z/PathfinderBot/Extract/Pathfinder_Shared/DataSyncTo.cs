﻿using System;

public class DataSyncTo : Attribute
{
    private byte targetLevel;

    public DataSyncTo(byte _targetLevel)
    {
        if (_targetLevel == 0)
        {
            throw new NotSupportedException("DataSyncTo(0) is not permitted.  The lowest user-specified sync target level is 1.");
        }
        this.targetLevel = _targetLevel;
    }

    public byte TargetLevel
    {
        get
        {
            return this.targetLevel;
        }
    }
}

