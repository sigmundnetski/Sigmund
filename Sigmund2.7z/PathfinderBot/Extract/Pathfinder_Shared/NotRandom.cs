﻿using System;

public class NotRandom : IRandomGenerator
{
    public Source dataSource;
    public int index;
    public int[] numbers;
    public double theRandomDouble;
    public int theRandomInt;

    public NotRandom(int[] numbers_)
    {
        this.dataSource = Source.ARRAY;
        this.numbers = numbers_;
        this.index = 0;
    }

    public NotRandom(double theRandomDouble_)
    {
        this.dataSource = Source.CONSTANT;
        this.theRandomDouble = theRandomDouble_;
    }

    public NotRandom(int theRandomNumber_)
    {
        this.dataSource = Source.CONSTANT;
        this.theRandomInt = theRandomNumber_;
    }

    public int Generate(int min, int max)
    {
        int theRandomInt = this.theRandomInt;
        if (this.dataSource == Source.ARRAY)
        {
            theRandomInt = this.numbers[this.index];
            this.index++;
        }
        return Math.Min(Math.Max(min, theRandomInt), max);
    }

    public double NextDouble()
    {
        return this.theRandomDouble;
    }

    public float Range(float min, float max)
    {
        return (float) this.theRandomDouble;
    }

    public enum Source
    {
        ARRAY,
        CONSTANT
    }
}

