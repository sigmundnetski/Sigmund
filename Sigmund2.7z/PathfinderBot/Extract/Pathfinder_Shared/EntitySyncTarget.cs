﻿using System;

public enum EntitySyncTarget : byte
{
    ALL = 0,
    OWNER_ONLY = 2,
    PARTY_ONLY = 1
}

