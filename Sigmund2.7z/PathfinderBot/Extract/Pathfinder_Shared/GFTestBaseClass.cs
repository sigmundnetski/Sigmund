﻿using System;

internal class GFTestBaseClass
{
}

