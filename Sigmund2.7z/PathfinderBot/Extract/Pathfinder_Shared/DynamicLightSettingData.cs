﻿using System;
using System.Collections.Generic;
using System.Linq;

[NoExcelData, StrongDependency(typeof(DynamicLightData))]
public class DynamicLightSettingData : DataClass
{
    public Dictionary<string, DynamicLightData[]> lightDataByTarget = new Dictionary<string, DynamicLightData[]>();
    public static Dictionary<int, DynamicLightSettingData> settingById = new Dictionary<int, DynamicLightSettingData>();
    public static Dictionary<string, DynamicLightSettingData> settingByName = new Dictionary<string, DynamicLightSettingData>();

    public override List<DataClass> MergeData()
    {
        IEnumerable<DynamicLightData> enumerable = from each in DataClass.GetData(typeof(DynamicLightData)) select (DynamicLightData) each;
        HashSet<string> set = new HashSet<string>(from each in enumerable select each.settingName);
        List<DataClass> list = new List<DataClass>();
        Dictionary<string, DynamicLightData[]> dictionary = new Dictionary<string, DynamicLightData[]>();
        using (HashSet<string>.Enumerator enumerator = set.GetEnumerator())
        {
            while (enumerator.MoveNext())
            {
                Func<DynamicLightData, bool> func = null;
                string settingName = enumerator.Current;
                if (func == null)
                {
                    func = each => each.settingName == settingName;
                }
                DynamicLightData[] dataArray = Enumerable.Where<DynamicLightData>(enumerable, func).ToArray<DynamicLightData>();
                HashSet<string> set2 = new HashSet<string>(from each in dataArray select each.target);
                DynamicLightSettingData item = new DynamicLightSettingData {
                    name = settingName.ToLower()
                };
                using (HashSet<string>.Enumerator enumerator2 = set2.GetEnumerator())
                {
                    while (enumerator2.MoveNext())
                    {
                        string eachTargetName = enumerator2.Current;
                        item.lightDataByTarget[eachTargetName] = (from each in dataArray
                            where each.target == eachTargetName
                            select each).ToArray<DynamicLightData>();
                    }
                }
                list.Add(item);
            }
        }
        return list;
    }

    public static void OnLoad(List<DataClass> objects)
    {
        foreach (DynamicLightSettingData data in objects)
        {
            settingById[data.id] = data;
            settingByName[data.name] = data;
        }
    }
}

