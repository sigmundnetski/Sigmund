﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;

public class NaturalTokenizer
{
    private Regex identifierRegex;
    private Dictionary<string, uint> keywords;
    private Regex numberRegex;
    private uint operatorBaseId;
    private Regex operatorRegex;
    private string operators;
    private Regex splitRegex;

    public NaturalTokenizer(Dictionary<string, uint> aKeywords = null, string aOperators = null, uint aOperatorBaseId = 0)
    {
        this.keywords = aKeywords;
        this.operators = aOperators;
        this.operatorBaseId = aOperatorBaseId;
        string pattern = @"[\+\-]?\d+\.?\d*%?";
        this.numberRegex = new Regex(pattern);
        this.identifierRegex = new Regex("^[a-zA-Z][a-zA-Z'-]*$");
        string str2 = "";
        if (this.operators != null)
        {
            str2 = "[";
            foreach (char ch in this.operators.ToCharArray())
            {
                str2 = str2 + @"\" + ch;
            }
            str2 = str2 + "]";
            this.operatorRegex = new Regex(str2);
        }
        this.splitRegex = new Regex(@"\s|\t|(" + pattern + ")" + ((this.operators != null) ? ("|(" + str2 + ")") : ""));
    }

    public Token CreateNumberToken(string numberString)
    {
        TokenFlags aFlags = 0;
        if (numberString[numberString.Length - 1] == '%')
        {
            numberString = numberString.TrimEnd(new char[] { '%' });
            aFlags |= TokenFlags.PERCENTAGE;
        }
        if (numberString.IndexOf('.') >= 0)
        {
            try
            {
                return new Token(TokenType.NUMBER_FLOAT, aFlags, null, 0, float.Parse(numberString), 0);
            }
            catch (Exception)
            {
                return new Token(TokenType.INVALID, 0, numberString, 0, 0f, 0);
            }
        }
        try
        {
            return new Token(TokenType.NUMBER_INT, aFlags, null, int.Parse(numberString), 0f, 0);
        }
        catch (Exception)
        {
            return new Token(TokenType.INVALID, 0, numberString, 0, 0f, 0);
        }
    }

    public Token[] Tokenize(string toparse, TokenTransform transform = null)
    {
        string[] strArray = this.splitRegex.Split(toparse);
        List<Token> list = new List<Token>();
        string aStringValue = "";
        foreach (string str2 in strArray)
        {
            if (str2 != "")
            {
                Token item = new Token(TokenType.NULL, 0, "", 0, 0f, 0);
                if (this.numberRegex.IsMatch(str2))
                {
                    item = this.CreateNumberToken(str2);
                }
                else if ((this.keywords != null) && this.keywords.ContainsKey(str2.ToLower()))
                {
                    item = new Token(TokenType.KEYWORD, 0, null, 0, 0f, this.keywords[str2.ToLower()]);
                }
                else if ((this.operators != null) && this.operatorRegex.IsMatch(str2))
                {
                    item = new Token(TokenType.OPERATOR, 0, null, 0, 0f, ((uint) this.operators.IndexOf(str2[0])) + this.operatorBaseId);
                }
                else if (!this.identifierRegex.IsMatch(str2))
                {
                    item = new Token(TokenType.INVALID, 0, str2, 0, 0f, 0);
                }
                if (item.type != TokenType.NULL)
                {
                    if (aStringValue.Length > 0)
                    {
                        list.Add(new Token(TokenType.IDENTIFIER, 0, aStringValue, 0, 0f, 0));
                        aStringValue = "";
                    }
                    list.Add(item);
                }
                else if (aStringValue.Length > 0)
                {
                    aStringValue = aStringValue + " " + str2;
                }
                else
                {
                    aStringValue = str2;
                }
            }
        }
        if (aStringValue.Length > 0)
        {
            list.Add(new Token(TokenType.IDENTIFIER, 0, aStringValue, 0, 0f, 0));
            aStringValue = "";
        }
        Token[] tokenArray = list.ToArray();
        if (transform != null)
        {
            for (int i = 0; i < tokenArray.Length; i++)
            {
                transform(ref tokenArray[i]);
            }
        }
        return tokenArray;
    }
}

