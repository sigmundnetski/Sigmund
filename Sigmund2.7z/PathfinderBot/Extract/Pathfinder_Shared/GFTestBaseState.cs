﻿using System;

internal class GFTestBaseState
{
    public int id = 0;
    public string name = "";
}

