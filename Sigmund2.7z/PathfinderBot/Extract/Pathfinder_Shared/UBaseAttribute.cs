﻿using System;

public class UBaseAttribute : Attribute
{
    public bool active;

    public UBaseAttribute()
    {
        this.active = true;
    }

    public UBaseAttribute(bool setActive)
    {
        this.active = setActive;
    }
}

