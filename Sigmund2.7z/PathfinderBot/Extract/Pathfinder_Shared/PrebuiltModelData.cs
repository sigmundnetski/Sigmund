﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

public class PrebuiltModelData : DataClass
{
    public string[] assetList;
    private const int GENDER_INDEX = 4;
    public static PrebuiltModelData gmOverride = null;
    private const int RACE_INDEX = 3;
    public string skeletonName;
    private const int SLOT_INDEX = 6;
    private const int UPGRADE_INDEX = 5;
    private const int VARIANT_INDEX = 2;

    public static bool ExtractFromName(string assetName, out int variant, out string race, out string gender, out int upgrade, out string slot)
    {
        string str3;
        race = (string) (str3 = null);
        gender = slot = str3;
        variant = upgrade = 0;
        if (assetName == null)
        {
            return false;
        }
        string[] strArray = assetName.ToLower().Split(new char[] { '_' });
        if (strArray.Length != 7)
        {
            return false;
        }
        race = strArray[3];
        gender = strArray[4];
        slot = strArray[6];
        string str = strArray[2];
        if (str.Length > 1)
        {
            int.TryParse(str.Substring(1), out variant);
        }
        string str2 = strArray[5];
        if (str2.Length > 3)
        {
            int.TryParse(str2.Substring(3), out upgrade);
        }
        return true;
    }

    public static void OnLoad(List<DataClass> objects)
    {
        foreach (PrebuiltModelData data in objects)
        {
            if (data.name == "gm override")
            {
                gmOverride = data;
            }
        }
    }

    public override DataClass ParseRecord(int rowIndex)
    {
        return ParseRow(rowIndex);
    }

    private static PrebuiltModelData ParseRow(int rowIndex)
    {
        PrebuiltModelData data = new PrebuiltModelData();
        bool flag = true;
        flag &= DataClass.GetLCaseCellValue(1, rowIndex, out data.name);
        flag &= DataClass.GetLCaseCellValue(2, rowIndex, out data.skeletonName);
        if (flag)
        {
            List<string> list = new List<string>();
            for (int i = 3; i <= DataClass.MAX_COL; i++)
            {
                string str;
                DataClass.GetLCaseCellValue(i, rowIndex, out str);
                if (!string.IsNullOrEmpty(str))
                {
                    list.Add(str);
                }
            }
            data.assetList = list.ToArray();
        }
        return (flag ? data : null);
    }
}

