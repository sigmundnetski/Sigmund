﻿using System;
using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Sequential)]
public struct EventCounter
{
    public int questId;
    public int goal;
    public string hudText;
}

