﻿using System;
using System.Collections.Generic;

public class AbilityScoreData : DataClass
{
    public string displayName;
    public float initialValue;
    public float maxValue;
    public static Dictionary<int, AbilityScoreData> scoreById = new Dictionary<int, AbilityScoreData>();
    public static Dictionary<string, AbilityScoreData> scoreByName = new Dictionary<string, AbilityScoreData>();
    [DataRestrict]
    public int scoreIndex;

    public static void ClearUnittestData()
    {
        scoreById.Clear();
        scoreByName.Clear();
    }

    public static void CreateUnittestData(float initValue, float maxValue, params string[] names)
    {
        List<DataClass> objects = new List<DataClass>();
        foreach (string str in names)
        {
            AbilityScoreData data;
            data = new AbilityScoreData {
                name = data.displayName = str,
                id = DataClass.GenerateId(data.name),
                initialValue = initValue,
                maxValue = maxValue
            };
            objects.Add(data);
        }
        OnLoad(objects);
    }

    public static void OnLoad(List<DataClass> objects)
    {
        for (int i = 0; i < objects.Count; i++)
        {
            AbilityScoreData data = (AbilityScoreData) objects[i];
            scoreById[objects[i].id] = data;
            scoreByName[objects[i].name] = data;
            data.scoreIndex = i;
        }
    }

    public override DataClass ParseRecord(int rowIndex)
    {
        AbilityScoreData data = new AbilityScoreData();
        DataClass.GetLCaseCellValue(1, rowIndex, out data.name);
        DataClass.GetCellValue(2, rowIndex, out data.displayName);
        DataClass.GetCellValue(3, rowIndex, out data.initialValue);
        DataClass.GetCellValue(4, rowIndex, out data.maxValue);
        return data;
    }
}

