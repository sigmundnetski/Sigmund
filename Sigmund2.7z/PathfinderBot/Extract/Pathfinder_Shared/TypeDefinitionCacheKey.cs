﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Sequential)]
internal struct TypeDefinitionCacheKey
{
    private FieldInfo field;
    private System.Type type;
    private byte defaultLevel;
    private byte targetLevel;
    public TypeDefinitionCacheKey(FieldInfo field, System.Type type, byte defaultLevel, byte targetLevel)
    {
        this.field = field;
        this.type = type;
        this.defaultLevel = defaultLevel;
        this.targetLevel = targetLevel;
    }

    public override int GetHashCode()
    {
        return (((((this.field != null) ? (this.field.GetHashCode() * GConst.aBunchOfPrimes[0]) : 0) + ((this.type != null) ? (this.type.GetHashCode() * GConst.aBunchOfPrimes[1]) : 0)) + (this.defaultLevel * GConst.aBunchOfPrimes[2])) + (this.targetLevel * GConst.aBunchOfPrimes[3]));
    }

    public override bool Equals(object obj)
    {
        if (!(obj is TypeDefinitionCacheKey))
        {
            return false;
        }
        TypeDefinitionCacheKey key = (TypeDefinitionCacheKey) obj;
        return ((((this.field == key.field) && (this.type == key.type)) && (this.defaultLevel == key.defaultLevel)) && (this.targetLevel == key.targetLevel));
    }

    public bool Equals(TypeDefinitionCacheKey otherKey)
    {
        return ((((this.field == otherKey.field) && (this.type == otherKey.type)) && (this.defaultLevel == otherKey.defaultLevel)) && (this.targetLevel == otherKey.targetLevel));
    }
}

