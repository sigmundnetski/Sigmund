﻿using GNetwork;
using System;

public class VentureCompanyInvite : IDataCopyable<VentureCompanyInvite>
{
    public uint inviteeId;
    public string inviteeName;
    public uint inviterId;
    public long inviteTime;

    public VentureCompanyInvite()
    {
    }

    public VentureCompanyInvite(uint inviterPlayer, uint inviteePlayer, string inviteeName)
    {
        this.inviterId = inviterPlayer;
        this.inviteeId = inviteePlayer;
        this.inviteeName = inviteeName;
        this.inviteTime = DateTime.UtcNow.ToBinary();
    }

    public void DataCopyTo(ref VentureCompanyInvite target, byte syncTargetLevel)
    {
        target.inviterId = this.inviterId;
        target.inviteeId = this.inviteeId;
        target.inviteeName = this.inviteeName;
        target.inviteTime = this.inviteTime;
    }

    public bool DataEquals(VentureCompanyInvite target, byte syncTargetLevel)
    {
        if (object.ReferenceEquals(target, null))
        {
            return false;
        }
        bool flag = true;
        return ((((flag && (target.inviterId == this.inviterId)) && (target.inviteeId == this.inviteeId)) && (target.inviteeName == this.inviteeName)) && (target.inviteTime == this.inviteTime));
    }

    public static VentureCompanyInvite PopFromBuffer(IBitBufferRead buffer)
    {
        return new VentureCompanyInvite { inviterId = buffer.PopUInt(), inviteeId = buffer.PopUInt(), inviteeName = buffer.PopString(), inviteTime = buffer.PopLong() };
    }

    public void PushToBuffer(IBitBufferWrite buffer)
    {
        buffer.PushUInt(this.inviterId);
        buffer.PushUInt(this.inviteeId);
        buffer.PushString(this.inviteeName);
        buffer.PushLong(this.inviteTime);
        GLog.Log(new object[] { "   ", this.inviteeName, DateTime.FromBinary(this.inviteTime) });
    }

    public override string ToString()
    {
        return string.Concat(new object[] { "<VCI ", this.inviteeId, ", ", this.inviteeName, ">" });
    }

    public InviteType TypeOfInvite()
    {
        return ((this.inviterId == this.inviteeId) ? InviteType.APPLICANT : InviteType.INVITED);
    }

    public enum InviteType
    {
        APPLICANT,
        INVITED
    }
}

