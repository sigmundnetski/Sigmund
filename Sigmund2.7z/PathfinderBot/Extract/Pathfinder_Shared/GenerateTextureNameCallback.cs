﻿using System;
using System.Runtime.CompilerServices;
using UnityEngine;

public delegate string GenerateTextureNameCallback(Texture tex);

