﻿using System;
using System.Runtime.InteropServices;
using UnityEngine;

public class WondrousWeapon : CombatWeapon
{
    public override void GetDamageAndEffectPower(OffensiveFeatData attack, byte weaponUpgrade, uint attackLevel, NonAttackFeatData featureFeat, CombatVars attacker, byte itemUpgrade, out int weaponDamage, out int bonusDamage, out int effectPower)
    {
        weaponDamage = 0;
        bonusDamage = 0;
        effectPower = 0;
        if (attack.type != Combat.FeatType.Expendable)
        {
            GLog.LogError(new object[] { "Wondrous items need Expendable feats!", attack.name, attack.type });
        }
        else
        {
            weaponDamage = CombatData.singleton.weaponDamageMartial;
            int num = (int) ((attackLevel - CombatData.singleton.wondrousItemUpgradeCenter) + itemUpgrade);
            num = Math.Max(num, 0);
            bonusDamage += num * CombatData.singleton.keywordDamageExpendable;
            float f = num * 1.4f;
            effectPower = Mathf.FloorToInt(f);
        }
    }

    public override byte GetTier(int itemId)
    {
        BasicItemData data;
        return (ItemDatabase.itemById.TryGetValue(itemId, out data) ? data.tier : ((byte) 0));
    }
}

