﻿using System;
using System.Collections.Generic;

public class AnimSuiteData : DataClass
{
    private static readonly string[] _mandatoryColumns = new string[] { "mainhand", "offhand", "anim set name", "draw anim number" };
    public int drawAnimNumber;
    private static AnimSuiteData INVALID_ANIM_DATA = null;
    public const string INVALID_SUITE = "DEFAULT_SUITE+";
    public string mainhand;
    private const string nameFormat = "{0}+{1}";
    public static AnimSuiteData NON_COMBAT_DATA = null;
    public const string NON_COMBAT_SUITE = "Non-Combat+";
    public string offhand;
    public string setName;
    private static Dictionary<int, AnimSuiteData> suiteById = new Dictionary<int, AnimSuiteData>();
    private static Dictionary<string, AnimSuiteData> suiteByName = new Dictionary<string, AnimSuiteData>();

    public AnimSuiteData()
    {
        this.setName = string.Empty;
    }

    public AnimSuiteData(string _mainhand, string _offhand)
    {
        this.mainhand = _mainhand;
        this.offhand = _offhand;
        this.setName = string.Format("{0}+{1}", _mainhand, _offhand);
    }

    public static AnimSuiteData GetById(int id)
    {
        if (id == 0)
        {
            GLog.LogWarning(new object[] { "Weapon does not have valid animation suite." });
            return INVALID_ANIM_DATA;
        }
        return suiteById[id];
    }

    public static AnimSuiteData GetByNames(string mainhand, string offhand)
    {
        AnimSuiteData data;
        string key = string.Format("{0}+{1}", mainhand, offhand);
        if (suiteByName.TryGetValue(key, out data))
        {
            return data;
        }
        GLog.LogWarning(new object[] { key, "is not a valid animation suite." });
        return INVALID_ANIM_DATA;
    }

    public static void OnLoad(List<DataClass> objects)
    {
        suiteById.Clear();
        suiteByName.Clear();
        foreach (AnimSuiteData data in objects)
        {
            suiteById.Add(data.id, data);
            suiteByName.Add(data.name, data);
        }
        INVALID_ANIM_DATA = suiteByName["DEFAULT_SUITE+".ToLower()];
        NON_COMBAT_DATA = suiteByName["Non-Combat+".ToLower()];
    }

    public override DataClass ParseRecord(int index)
    {
        AnimSuiteData data = new AnimSuiteData();
        if (!DataClass.TryGetLCaseCellValue(DataClass.columnNamesToIndex["mainhand"], index, out data.mainhand))
        {
            return null;
        }
        DataClass.TryGetLCaseCellValue(DataClass.columnNamesToIndex["offhand"], index, out data.offhand);
        data.name = string.Format("{0}+{1}", data.mainhand, data.offhand);
        DataClass.GetCellValue(DataClass.columnNamesToIndex["anim set name"], index, out data.setName);
        DataClass.GetCellValue(DataClass.columnNamesToIndex["draw anim number"], index, out data.drawAnimNumber);
        return data;
    }

    public override string ToString()
    {
        return ("<" + string.Format("{0}+{1}", this.mainhand, this.offhand) + " -> " + this.setName + ">");
    }

    protected override IEnumerable<string> GetMandatoryColumns
    {
        get
        {
            return _mandatoryColumns;
        }
    }
}

