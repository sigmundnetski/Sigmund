﻿using System;

public class DefendingBuff : CombatTimedBuff
{
    private const int REFLEX_BONUS = 10;
    private const string REPLYING_MOD = "Replying (1 round) to Self";
    private static CombatModifier[] replyingCombatMod = CombatModifier.Parse("Replying (1 round) to Self");

    public DefendingBuff() : base("Defending", Combat.Channel.Extraordinary, Combat.EffectType.Beneficial)
    {
    }

    public static DefendingBuff Create()
    {
        return new DefendingBuff();
    }

    public override void RecalculationPhase(CombatBuffVars buff, uint combatTick)
    {
        int specific = buff.owner.tempDefenses.Channel(base.channel).GetSpecific(DefenseType.Reflex);
        if (10 > specific)
        {
            buff.owner.tempDefenses.Channel(base.channel).SetSpecific(DefenseType.Reflex, 10);
        }
    }

    public override void TimePhase(CombatBuffVars buff, uint combatTick)
    {
        if (buff.owner.attackReceivedTypes.Contains(AttackType.HeavyMelee) || buff.owner.attackReceivedTypes.Contains(AttackType.LightMelee))
        {
            buff.expirationTick = combatTick;
            CombatEffect item = new CombatEffect(replyingCombatMod, buff.owner, buff.owner, CombatEffect.TargetType.ATTACKER, Combat.EffectType.Neutral);
            buff.owner.combatEffects.Enqueue(item);
        }
    }
}

