﻿using System;
using System.Collections.Generic;
using System.Linq;

[LooseDependency(typeof(CategoryData))]
public class FeatAdvancementData : AdvancementIndexedDataClass
{
    private static readonly string[] _mandatoryColumns = new string[] { "exp lv1" };
    public static Dictionary<int, FeatAdvancementData> dataByFeatAdvancementId = new Dictionary<int, FeatAdvancementData>();
    public static Dictionary<int, FeatAdvancementData[]> dataByPageId = new Dictionary<int, FeatAdvancementData[]>();
    public static Dictionary<string, FeatAdvancementData> dataBySlotName = new Dictionary<string, FeatAdvancementData>();
    public const float MAX_STAT_PER_ACHIEVEMENT = 1f;
    private static string[] OR_KEYWORD = new string[] { " or " };
    private FeatAdvancementDetails[] perLevelDetails;

    public void AppendUnittestDetails(FeatAdvancementDetails each)
    {
        SparseArray.InefficientAppendToArray<FeatAdvancementDetails>(ref this.perLevelDetails, each);
    }

    public FeatAdvancementDetails GetDetailsForLevel(byte level)
    {
        if (this.perLevelDetails.Length > (level - 1))
        {
            return this.perLevelDetails[level - 1];
        }
        return null;
    }

    public static void OnLoad(List<DataClass> objects)
    {
        AdvancementIndexedDataClass.AssignPageNumbers(objects);
        foreach (FeatAdvancementData data in objects)
        {
            dataByFeatAdvancementId[data.id] = data;
            dataBySlotName[data.slotName] = data;
        }
        HashSet<int> set = new HashSet<int>(from each in objects select ((FeatAdvancementData) each).pageId);
        using (HashSet<int>.Enumerator enumerator2 = set.GetEnumerator())
        {
            while (enumerator2.MoveNext())
            {
                int eachPageId = enumerator2.Current;
                dataByPageId[eachPageId] = (from each in objects
                    where ((FeatAdvancementData) each).pageId == eachPageId
                    select (FeatAdvancementData) each).ToArray<FeatAdvancementData>();
            }
        }
    }

    protected override void ParseCustomDetails(int rowIndex, ref AdvancementIndexedDataClass _output)
    {
        FeatAdvancementData data = (FeatAdvancementData) _output;
        List<FeatAdvancementDetails> list = new List<FeatAdvancementDetails>();
        List<string> failedFeats = new List<string>();
        List<string> failedAchievements = new List<string>();
        List<string> failedCategories = new List<string>();
        List<string> failedAbilities = new List<string>();
        List<string> list6 = new List<string>();
        List<List<int>> achievementIdList = new List<List<int>>();
        List<List<int>> featIdList = new List<List<int>>();
        List<List<int>> categoryIdList = new List<List<int>>();
        List<List<int>> abilityIdList = new List<List<int>>();
        List<int> list11 = new List<int>();
        List<List<byte>> featLevelList = new List<List<byte>>();
        List<List<ushort>> categoryReqList = new List<List<ushort>>();
        List<List<float>> valueList = new List<List<float>>();
        List<float> list15 = new List<float>();
        int num3 = 1;
        while (true)
        {
            uint num;
            int num2;
            string str7;
            string key = "exp lv" + num3;
            string str2 = "feat lv" + num3;
            string str3 = "achievement lv" + num3;
            string str4 = "category lv" + num3;
            string str5 = "abilityreq lv" + num3;
            string str6 = "abilitybonus lv" + num3;
            failedFeats.Clear();
            failedAchievements.Clear();
            failedCategories.Clear();
            failedAbilities.Clear();
            list6.Clear();
            achievementIdList.Clear();
            featIdList.Clear();
            categoryIdList.Clear();
            featLevelList.Clear();
            categoryReqList.Clear();
            abilityIdList.Clear();
            valueList.Clear();
            list11.Clear();
            list15.Clear();
            if (!(DataClass.columnNamesToIndex.TryGetValue(key, out num2) && DataClass.TryGetCellValue(DataClass.columnNamesToIndex[key], rowIndex, out num)))
            {
                if (list.Count == 0)
                {
                    DataClass.OutputErrorMessage(DataClass.columnNamesToIndex["exp lv1"], rowIndex, "There must be at least 1 level defined for feat advancement");
                }
                data.perLevelDetails = list.ToArray();
                data.name = data.slotName;
                return;
            }
            if (DataClass.columnNamesToIndex.TryGetValue(str2, out num2))
            {
                DataClass.GetLCaseCellValue(DataClass.columnNamesToIndex[str2], rowIndex, out str7);
                ParseSubstringAsFeat(ref featIdList, ref featLevelList, ref failedFeats, str7.Split(new char[] { ',' }));
                if (failedFeats.Count > 0)
                {
                    DataClass.OutputErrorMessage(DataClass.columnNamesToIndex[str2], rowIndex, string.Join(",\n", failedFeats.ToArray()));
                }
            }
            if (DataClass.columnNamesToIndex.TryGetValue(str3, out num2))
            {
                DataClass.GetLCaseCellValue(DataClass.columnNamesToIndex[str3], rowIndex, out str7);
                ParseSubstringAsAchievement(ref achievementIdList, ref failedAchievements, str7.Split(new char[] { ',' }));
                if (failedAchievements.Count > 0)
                {
                    DataClass.OutputErrorMessage(DataClass.columnNamesToIndex[str3], rowIndex, string.Join(",\n", failedAchievements.ToArray()));
                }
            }
            if (DataClass.columnNamesToIndex.TryGetValue(str4, out num2))
            {
                DataClass.GetLCaseCellValue(DataClass.columnNamesToIndex[str4], rowIndex, out str7);
                ParseSubstringAsCategory(ref categoryIdList, ref categoryReqList, ref failedCategories, str7.Split(new char[] { ',' }));
                if (failedCategories.Count > 0)
                {
                    DataClass.OutputErrorMessage(DataClass.columnNamesToIndex[str4], rowIndex, string.Join(",\n", failedCategories.ToArray()));
                }
            }
            if (DataClass.columnNamesToIndex.TryGetValue(str5, out num2))
            {
                DataClass.GetLCaseCellValue(DataClass.columnNamesToIndex[str5], rowIndex, out str7);
                ParseSubstringAsAbility(ref abilityIdList, ref valueList, ref failedAbilities, str7.Split(new char[] { ',' }));
                if (failedAbilities.Count > 0)
                {
                    DataClass.OutputErrorMessage(DataClass.columnNamesToIndex[str5], rowIndex, string.Join(",\n", failedAbilities.ToArray()));
                }
            }
            if (DataClass.columnNamesToIndex.TryGetValue(str6, out num2))
            {
                DataClass.GetLCaseCellValue(DataClass.columnNamesToIndex[str6], rowIndex, out str7);
                ParseSubstringAsAbility(ref list11, ref list15, ref list6, str7.Split(new char[] { ',' }));
                if (list6.Count > 0)
                {
                    DataClass.OutputErrorMessage(DataClass.columnNamesToIndex[str6], rowIndex, string.Join(",\n", list6.ToArray()));
                }
            }
            list.Add(new FeatAdvancementDetails(num, achievementIdList, featIdList, featLevelList, categoryIdList, categoryReqList, abilityIdList, valueList, list11, list15));
            num3++;
        }
    }

    private static void ParseSubstringAsAbility(ref List<List<int>> abilityIdList, ref List<List<float>> valueList, ref List<string> failedAbilities, string[] substringList)
    {
        foreach (string str in substringList)
        {
            if (!string.IsNullOrEmpty(str))
            {
                List<int> item = new List<int>();
                List<float> list2 = new List<float>();
                string[] strArray = str.Split(OR_KEYWORD, StringSplitOptions.RemoveEmptyEntries);
                foreach (string str2 in strArray)
                {
                    AbilityScoreData data;
                    float num;
                    string[] strArray2 = str2.Split(new char[] { '=' });
                    if (((strArray2.Length == 2) && AbilityScoreData.scoreByName.TryGetValue(strArray2[0].Trim(), out data)) && float.TryParse(strArray2[1].Trim(), out num))
                    {
                        item.Add(data.id);
                        list2.Add(num);
                    }
                    else
                    {
                        failedAbilities.Add(str2);
                    }
                }
                if (item.Count > 0)
                {
                    abilityIdList.Add(item);
                    valueList.Add(list2);
                }
            }
        }
    }

    private static void ParseSubstringAsAbility(ref List<int> abilityIdList, ref List<float> valueList, ref List<string> failedAbilities, string[] substringList)
    {
        foreach (string str in substringList)
        {
            if (!string.IsNullOrEmpty(str))
            {
                AbilityScoreData data;
                float num;
                string[] strArray = str.Split(new char[] { '=' });
                if ((AbilityScoreData.scoreByName.TryGetValue(strArray[0].Trim(), out data) && float.TryParse(strArray[1].Trim(), out num)) && (num < 1f))
                {
                    abilityIdList.Add(data.id);
                    valueList.Add(num);
                }
                else
                {
                    failedAbilities.Add(str);
                }
            }
        }
    }

    private static void ParseSubstringAsAchievement(ref List<List<int>> achievementIdList, ref List<string> failedAchievements, string[] substringList)
    {
        foreach (string str in substringList)
        {
            if (!string.IsNullOrEmpty(str))
            {
                List<int> item = new List<int>();
                string[] strArray = str.Split(OR_KEYWORD, StringSplitOptions.RemoveEmptyEntries);
                foreach (string str2 in strArray)
                {
                    GenericAchievementData data;
                    byte num;
                    string[] strArray2 = str2.Split(new char[] { '=' });
                    if (((strArray2.Length == 2) && byte.TryParse(strArray2[1].Trim(), out num)) && MergedAchievementData.TryGet(strArray2[0].Trim(), num, out data))
                    {
                        item.Add(data.id);
                    }
                    else
                    {
                        failedAchievements.Add(str2);
                    }
                }
                if (item.Count > 0)
                {
                    achievementIdList.Add(item);
                }
            }
        }
    }

    private static void ParseSubstringAsCategory(ref List<List<int>> categoryIdList, ref List<List<ushort>> categoryReqList, ref List<string> failedCategories, string[] substringList)
    {
        foreach (string str in substringList)
        {
            if (!string.IsNullOrEmpty(str))
            {
                List<int> item = new List<int>();
                List<ushort> list2 = new List<ushort>();
                string[] strArray = str.Split(OR_KEYWORD, StringSplitOptions.RemoveEmptyEntries);
                foreach (string str2 in strArray)
                {
                    CategoryData data;
                    ushort num;
                    string[] strArray2 = str2.Split(new char[] { '=' });
                    if (((strArray2.Length == 2) && CategoryData.categoryByName.TryGetValue(strArray2[0].Trim(), out data)) && ushort.TryParse(strArray2[1].Trim(), out num))
                    {
                        item.Add(data.id);
                        list2.Add(num);
                    }
                    else
                    {
                        failedCategories.Add(str2);
                    }
                }
                if (item.Count > 0)
                {
                    categoryIdList.Add(item);
                    categoryReqList.Add(list2);
                }
            }
        }
    }

    private static void ParseSubstringAsFeat(ref List<List<int>> featIdList, ref List<List<byte>> featLevelList, ref List<string> failedFeats, string[] substringList)
    {
        foreach (string str in substringList)
        {
            if (!string.IsNullOrEmpty(str))
            {
                List<int> item = new List<int>();
                List<byte> list2 = new List<byte>();
                string[] strArray = str.Split(OR_KEYWORD, StringSplitOptions.RemoveEmptyEntries);
                foreach (string str2 in strArray)
                {
                    FeatAdvancementData data;
                    byte num;
                    string[] strArray2 = str2.Split(new char[] { '=' });
                    if (((strArray2.Length == 2) && dataBySlotName.TryGetValue(strArray2[0].Trim(), out data)) && byte.TryParse(strArray2[1].Trim(), out num))
                    {
                        item.Add(data.id);
                        list2.Add(num);
                    }
                    else
                    {
                        failedFeats.Add(str2);
                    }
                }
                if (item.Count > 0)
                {
                    featIdList.Add(item);
                    featLevelList.Add(list2);
                }
            }
        }
    }

    protected override IEnumerable<string> GetMandatoryColumns
    {
        get
        {
            return base.GetMandatoryColumns.Concat<string>(_mandatoryColumns);
        }
    }
}

