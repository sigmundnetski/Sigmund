﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

public class CombatData : DataClass
{
    public int advancedKeywordMultiplier;
    public float aoeDegreesLongBlast;
    public float aoeDegreesLongBlastMelee;
    public float aoeDegreesShortBlast;
    public float aoeDegreesShortBlastMelee;
    public float aoeRadiusArea;
    public float aoeRadiusBurst;
    public float aoeRadiusSplash;
    public float aoeWidthStreak;
    public int armorDefenseTier1;
    public int armorDefenseTier2;
    public int armorDefenseTier3;
    public int baseBuffStackReduction;
    public float baseMoveSpeed;
    public int basePower;
    public float closeRange;
    public int deathHitpointThreshold;
    public float dotDamageMultiplier;
    public short friendlyRepThreshold;
    public short helpfulRepThreshold;
    public ushort huskDespawnDelay;
    public ushort huskLootChannelDuration;
    public float hustleSpeed;
    public float implementCooldownTime;
    public uint implementCooldownTimeInTicks;
    public short indifferentRepThreshold;
    public float initialReputation;
    public int keywordDamageAdvanced;
    public int keywordDamageBasic;
    public int keywordDamageExpendable;
    public int keywordDamageSocial;
    public float longRangeModifier;
    public int maxBuffStacks;
    public int maxEncumbrance;
    public float newPlayerHours;
    public float newPlayerRepMultiplier;
    public float partialHitMultiplier;
    public float rangeForgiveness;
    public float reducedRangeModifier;
    public float regenAmountInCombat;
    public float regenAmountOutOfCombat;
    public float regenTime;
    public uint regenTimeInTicks;
    public float roundTime;
    public uint roundTimeInTicks;
    public float runSpeed;
    public int staminaLimit;
    public int staminaRegenAmount;
    public float stealthSpeed;
    public int unconsciousBleed;
    public float unconsciousEnmity;
    public short unfriendlyRepThreshold;
    public float walkBackSpeed;
    public float walkSpeed;
    public int weaponDamageExotic;
    public int weaponDamageMartial;
    public int weaponDamageSimple;
    public byte wondrousItemUpgradeCenter;

    public CombatData()
    {
        this.huskLootChannelDuration = 5;
        this.huskDespawnDelay = 30;
        this.newPlayerHours = 20f;
        this.initialReputation = 5000f;
        this.newPlayerRepMultiplier = 1f;
        this.helpfulRepThreshold = 0x1388;
        this.friendlyRepThreshold = 0x7d0;
        this.indifferentRepThreshold = -2000;
        this.unfriendlyRepThreshold = -5000;
        this.staminaLimit = 0;
        this.staminaRegenAmount = 0;
        this.roundTime = 0f;
        this.closeRange = 0f;
        this.rangeForgiveness = 0f;
        this.regenTime = 0f;
        this.regenAmountOutOfCombat = 0f;
        this.regenAmountInCombat = 0f;
        this.deathHitpointThreshold = 0;
        this.unconsciousEnmity = 0f;
        this.unconsciousBleed = 0;
        this.baseMoveSpeed = 0f;
        this.walkSpeed = 0f;
        this.hustleSpeed = 0f;
        this.runSpeed = 0f;
        this.walkBackSpeed = 0f;
        this.stealthSpeed = 0f;
        this.maxEncumbrance = 0;
        this.partialHitMultiplier = 0f;
        this.implementCooldownTime = 0f;
        this.implementCooldownTimeInTicks = 0;
        this.advancedKeywordMultiplier = 0;
        this.longRangeModifier = 0f;
        this.reducedRangeModifier = 0f;
        this.keywordDamageBasic = 0;
        this.keywordDamageAdvanced = 0;
        this.keywordDamageSocial = 0;
        this.keywordDamageExpendable = 0;
        this.weaponDamageSimple = 0;
        this.weaponDamageMartial = 0;
        this.weaponDamageExotic = 0;
        this.armorDefenseTier1 = 0;
        this.armorDefenseTier2 = 0;
        this.armorDefenseTier3 = 0;
        this.baseBuffStackReduction = 0;
        this.basePower = 0;
        this.aoeRadiusSplash = 0f;
        this.aoeRadiusBurst = 0f;
        this.aoeRadiusArea = 0f;
        this.aoeWidthStreak = 0f;
        this.aoeDegreesShortBlast = 0f;
        this.aoeDegreesShortBlastMelee = 0f;
        this.aoeDegreesLongBlast = 0f;
        this.aoeDegreesLongBlastMelee = 0f;
        this.maxBuffStacks = 0;
        this.dotDamageMultiplier = 0f;
        this.wondrousItemUpgradeCenter = 0;
    }

    public CombatData(int staminaLimit_, int staminaRegenAmount_, float roundTime_, float closeRange_, float rangeForgiveness_, float regenTime_, float regenAmountOutOfCombat_, float regenAmountInCombat_, int deathHitpointThreshold_, float unconsciousEnmity_, int unconsciousBleed_, float baseMoveSpeed_, float walkSpeed_, float hustleSpeed_, float runSpeed_, float walkBackSpeed_, float stealthSpeed_, int maxEncumbrance_, float partialHitMultiplier_, float implementCooldownTime_, int advancedKeywordMultiplier_)
    {
        this.huskLootChannelDuration = 5;
        this.huskDespawnDelay = 30;
        this.newPlayerHours = 20f;
        this.initialReputation = 5000f;
        this.newPlayerRepMultiplier = 1f;
        this.helpfulRepThreshold = 0x1388;
        this.friendlyRepThreshold = 0x7d0;
        this.indifferentRepThreshold = -2000;
        this.unfriendlyRepThreshold = -5000;
        this.staminaLimit = staminaLimit_;
        this.staminaRegenAmount = staminaRegenAmount_;
        this.roundTime = roundTime_;
        this.roundTimeInTicks = CombatCore.TicksFromSeconds(this.roundTime);
        this.closeRange = closeRange_;
        this.rangeForgiveness = rangeForgiveness_;
        this.regenTime = regenTime_;
        this.regenTimeInTicks = CombatCore.TicksFromSeconds(this.regenTime);
        this.regenAmountOutOfCombat = regenAmountOutOfCombat_;
        this.regenAmountInCombat = regenAmountInCombat_;
        this.deathHitpointThreshold = deathHitpointThreshold_;
        this.unconsciousEnmity = unconsciousEnmity_;
        this.unconsciousBleed = unconsciousBleed_;
        this.baseMoveSpeed = baseMoveSpeed_;
        this.walkSpeed = walkSpeed_;
        this.hustleSpeed = hustleSpeed_;
        this.runSpeed = runSpeed_;
        this.walkBackSpeed = walkBackSpeed_;
        this.stealthSpeed = stealthSpeed_;
        this.maxEncumbrance = maxEncumbrance_;
        this.partialHitMultiplier = partialHitMultiplier_;
        this.implementCooldownTime = implementCooldownTime_;
        this.implementCooldownTimeInTicks = CombatCore.TicksFromSeconds(this.implementCooldownTime);
        this.advancedKeywordMultiplier = advancedKeywordMultiplier_;
        this.longRangeModifier = 1.5f;
        this.reducedRangeModifier = 0.5f;
        this.keywordDamageBasic = 5;
        this.keywordDamageAdvanced = 20;
        this.keywordDamageSocial = 0;
        this.keywordDamageExpendable = 7;
        this.weaponDamageSimple = 30;
        this.weaponDamageMartial = 40;
        this.weaponDamageExotic = 50;
        this.armorDefenseTier1 = 50;
        this.armorDefenseTier2 = 100;
        this.armorDefenseTier3 = 150;
        this.baseBuffStackReduction = 5;
        this.basePower = 40;
        this.aoeRadiusSplash = this.closeRange;
        this.aoeRadiusBurst = 6f;
        this.aoeRadiusArea = 12f;
        this.aoeWidthStreak = 0.5f;
        this.aoeDegreesShortBlast = 60f;
        this.aoeDegreesShortBlastMelee = 60f;
        this.aoeDegreesLongBlast = 40f;
        this.aoeDegreesLongBlastMelee = 120f;
        this.maxBuffStacks = 100;
        this.dotDamageMultiplier = 0.001f;
        this.wondrousItemUpgradeCenter = 3;
    }

    public static void OnLoad(List<DataClass> objects)
    {
        singleton = (CombatData) objects[0];
    }

    public override void ParseRecord(ref DataClass obj, int index)
    {
        CombatData data = (CombatData) obj;
        if (data == null)
        {
            data = new CombatData();
        }
        string output = string.Empty;
        string str2 = string.Empty;
        if (DataClass.TryGetLCaseCellValue("A", index, out output))
        {
            DataClass.GetCellValue("B", index, out str2);
            switch (output)
            {
                case "stamina limit":
                    int.TryParse(str2, out data.staminaLimit);
                    break;

                case "stamina regen amount":
                    int.TryParse(str2, out data.staminaRegenAmount);
                    break;

                case "round time":
                    float.TryParse(str2, out data.roundTime);
                    data.roundTimeInTicks = CombatCore.TicksFromSeconds(data.roundTime);
                    break;

                case "melee range":
                    float.TryParse(str2, out data.closeRange);
                    break;

                case "range forgiveness":
                    float.TryParse(str2, out data.rangeForgiveness);
                    break;

                case "regeneration time":
                    float.TryParse(str2, out data.regenTime);
                    data.regenTimeInTicks = CombatCore.TicksFromSeconds(data.regenTime);
                    break;

                case "regeneration out of combat":
                    float.TryParse(str2, out data.regenAmountOutOfCombat);
                    break;

                case "regeneration in combat":
                    float.TryParse(str2, out data.regenAmountInCombat);
                    break;

                case "death threshold":
                    int.TryParse(str2, out data.deathHitpointThreshold);
                    break;

                case "unconscious threat reduction":
                    float.TryParse(str2, out data.unconsciousEnmity);
                    break;

                case "unconscious bleed amount":
                    int.TryParse(str2, out data.unconsciousBleed);
                    break;

                case "base move speed":
                    float.TryParse(str2, out data.baseMoveSpeed);
                    break;

                case "walk backward speed":
                    float.TryParse(str2, out data.walkBackSpeed);
                    break;

                case "walk speed":
                    float.TryParse(str2, out data.walkSpeed);
                    break;

                case "hustle speed":
                    float.TryParse(str2, out data.hustleSpeed);
                    break;

                case "run speed":
                    float.TryParse(str2, out data.runSpeed);
                    break;

                case "stealth speed":
                    float.TryParse(str2, out data.stealthSpeed);
                    break;

                case "max encumbrance":
                    int.TryParse(str2, out data.maxEncumbrance);
                    break;

                case "partial hit multiplier":
                    float.TryParse(str2, out data.partialHitMultiplier);
                    break;

                case "implement global cooldown time":
                    float.TryParse(str2, out data.implementCooldownTime);
                    data.implementCooldownTimeInTicks = CombatCore.TicksFromSeconds(data.implementCooldownTime);
                    break;

                case "default advanced keyword multiplier":
                    int.TryParse(str2, out data.advancedKeywordMultiplier);
                    break;

                case "long range multiplier":
                    float.TryParse(str2, out data.longRangeModifier);
                    break;

                case "reduced range multiplier":
                    float.TryParse(str2, out data.reducedRangeModifier);
                    break;

                case "basic keyword damage":
                    int.TryParse(str2, out data.keywordDamageBasic);
                    break;

                case "advanced keyword damage":
                    int.TryParse(str2, out data.keywordDamageAdvanced);
                    break;

                case "social keyword damage":
                    int.TryParse(str2, out data.keywordDamageSocial);
                    break;

                case "expendable keyword damage":
                    int.TryParse(str2, out data.keywordDamageExpendable);
                    break;

                case "simple weapon damage":
                    int.TryParse(str2, out data.weaponDamageSimple);
                    break;

                case "martial weapon damage":
                    int.TryParse(str2, out data.weaponDamageMartial);
                    break;

                case "exotic weapon damage":
                    int.TryParse(str2, out data.weaponDamageExotic);
                    break;

                case "armor defense tier 1":
                    int.TryParse(str2, out data.armorDefenseTier1);
                    break;

                case "armor defense tier 2":
                    int.TryParse(str2, out data.armorDefenseTier2);
                    break;

                case "armor defense tier 3":
                    int.TryParse(str2, out data.armorDefenseTier3);
                    break;

                case "beneficial buff base stack loss":
                    int.TryParse(str2, out data.baseBuffStackReduction);
                    break;

                case "base power":
                    int.TryParse(str2, out data.basePower);
                    break;

                case "aoe radius splash":
                    float.TryParse(str2, out data.aoeRadiusSplash);
                    break;

                case "aoe radius burst":
                    float.TryParse(str2, out data.aoeRadiusBurst);
                    break;

                case "aoe radius area":
                    float.TryParse(str2, out data.aoeRadiusArea);
                    break;

                case "aoe width streak":
                    float.TryParse(str2, out data.aoeWidthStreak);
                    break;

                case "aoe degrees short blast":
                    float.TryParse(str2, out data.aoeDegreesShortBlast);
                    break;

                case "aoe degrees short blast melee":
                    float.TryParse(str2, out data.aoeDegreesShortBlastMelee);
                    break;

                case "aoe degrees long blast":
                    float.TryParse(str2, out data.aoeDegreesLongBlast);
                    break;

                case "aoe degrees long blast melee":
                    float.TryParse(str2, out data.aoeDegreesLongBlastMelee);
                    break;

                case "max buff stacks":
                    int.TryParse(str2, out data.maxBuffStacks);
                    break;

                case "dot damage multiplier":
                    float.TryParse(str2, out data.dotDamageMultiplier);
                    break;

                case "wondrous item upgrade center":
                    byte.TryParse(str2, out data.wondrousItemUpgradeCenter);
                    break;

                case "husk loot channel duration":
                    ushort.TryParse(str2, out data.huskLootChannelDuration);
                    break;

                case "husk despawn delay":
                    ushort.TryParse(str2, out data.huskDespawnDelay);
                    break;

                case "new player hours":
                    float.TryParse(str2, out data.newPlayerHours);
                    break;

                case "initial reputation":
                    float.TryParse(str2, out data.initialReputation);
                    break;

                case "new player rep regen multiplier":
                    float.TryParse(str2, out data.newPlayerRepMultiplier);
                    break;

                case "helpful rep threshold":
                    short.TryParse(str2, out data.helpfulRepThreshold);
                    break;

                case "friendly rep threshold":
                    short.TryParse(str2, out data.friendlyRepThreshold);
                    break;

                case "indifferent rep threshold":
                    short.TryParse(str2, out data.indifferentRepThreshold);
                    break;

                case "unfriendly rep threshold":
                    short.TryParse(str2, out data.unfriendlyRepThreshold);
                    break;

                default:
                    DataClass.OutputErrorMessage("A", index, "Unknown key: " + output);
                    break;
            }
            obj = data;
        }
    }

    public override List<DataClass> ParseSheet()
    {
        List<DataClass> list = new List<DataClass>();
        DataClass class2 = null;
        for (int i = 4; i <= DataClass.data.GetLength(0); i++)
        {
            this.ParseRecord(ref class2, i);
        }
        if (class2 != null)
        {
            list.Add(class2);
        }
        return list;
    }

    public static CombatData singleton
    {
        [CompilerGenerated]
        get
        {
            return <singleton>k__BackingField;
        }
        [CompilerGenerated]
        protected set
        {
            <singleton>k__BackingField = value;
        }
    }
}

