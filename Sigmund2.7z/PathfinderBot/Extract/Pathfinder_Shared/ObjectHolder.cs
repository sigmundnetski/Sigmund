﻿using System.Collections.Generic;
using UnityEngine;

public class ObjectHolder : MonoBehaviour
{
    public Dictionary<string, Object> objectMap;
    public Object[] objects;
}

