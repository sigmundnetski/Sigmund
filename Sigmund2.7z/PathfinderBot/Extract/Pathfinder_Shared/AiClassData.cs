﻿using System;
using System.Collections.Generic;

[LooseDependency(typeof(OffensiveFeatData)), NoFinalOutput]
public class AiClassData : CombatClassData
{
    private static readonly string[] _mandatoryColumns = new string[] { 
        "name", "attack tier", "total attack", "fortitude", "reflex", "will", "hit points", "recovery", "base damage", "physical", "fire", "cold", "electric", "acid", "sonic", "negative", 
        "holy", "force", "psychic", "crit resist", "initiation", "primary", "secondary", "monster level", "move speed", "stealth", "perception", "sense motive", "effect power", "effect defense"
     };
    public const int INITIATION_ATTACKS_INDEX = 1;
    private const int MAX_LEVEL = 0x19;
    private const int MIN_LEVEL = 0;
    public const int STANDARD_ATTACKS_INDEX = 0;

    public AiClassData()
    {
    }

    public AiClassData(int hitPoints_)
    {
        base.hitPoints = hitPoints_;
    }

    public AiClassData(string name, int health, byte tier, int recoveryAmount, int baseDamageAmount, int effectPower_, int effectDefense_) : base(name)
    {
        base.hitPoints = health;
        base.recovery = recoveryAmount;
        base.baseDamage = baseDamageAmount;
        base.attackTier = tier;
        base.effectPower = effectPower_;
        base.effectDefense = effectDefense_;
    }

    public override DataClass ParseRecord(int index)
    {
        int num;
        int num3;
        AiClassData data = new AiClassData();
        string key = "name";
        string str2 = "attack tier";
        string str3 = "total attack";
        string[] strArray = new string[] { "fortitude", "reflex", "will" };
        DefenseType[] typeArray = new DefenseType[] { DefenseType.Fortitude, DefenseType.Reflex, DefenseType.Will };
        string str4 = "hit points";
        string str5 = "recovery";
        string str6 = "base damage";
        string[] strArray2 = new string[] { "physical", "fire", "cold", "electric", "acid", "sonic", "negative", "holy", "force", "psychic", "crit resist" };
        ResistanceType[] typeArray4 = new ResistanceType[11];
        typeArray4[1] = ResistanceType.Fire;
        typeArray4[2] = ResistanceType.Cold;
        typeArray4[3] = ResistanceType.Electric;
        typeArray4[4] = ResistanceType.Acid;
        typeArray4[5] = ResistanceType.Sonic;
        typeArray4[6] = ResistanceType.Negative;
        typeArray4[7] = ResistanceType.Holy;
        typeArray4[8] = ResistanceType.Force;
        typeArray4[9] = ResistanceType.Psychic;
        typeArray4[10] = ResistanceType.Critical;
        ResistanceType[] typeArray2 = typeArray4;
        string str7 = "initiation";
        string str8 = "primary";
        string str9 = "secondary";
        string str10 = "monster level";
        string str11 = "move speed";
        string[] strArray3 = new string[] { "stealth", "perception", "sense motive" };
        SkillData.CodeSkillName[] nameArray = new SkillData.CodeSkillName[] { SkillData.CodeSkillName.Stealth, SkillData.CodeSkillName.Perception, SkillData.CodeSkillName.SenseMotive };
        if (!(DataClass.columnNamesToIndex.TryGetValue(key, out num) && DataClass.TryGetLCaseCellValue(num, index, out data.name)))
        {
            return null;
        }
        if (DataClass.columnNamesToIndex.TryGetValue(str2, out num))
        {
            DataClass.GetCellValue(num, index, out data.attackTier);
        }
        int output = 0;
        if (DataClass.columnNamesToIndex.TryGetValue(str3, out num))
        {
            DataClass.GetCellValue(num, index, out output);
        }
        data.attackBonus.attackBonus[0] = output;
        data.attackBonus.attackBonus[1] = output;
        data.attackBonus.attackBonus[3] = output;
        data.attackBonus.attackBonus[2] = output;
        data.attackBonus.attackBonus[5] = output;
        data.attackBonus.attackBonus[4] = output;
        for (num3 = 0; (num3 < strArray.Length) && (num3 < typeArray.Length); num3++)
        {
            if (DataClass.columnNamesToIndex.TryGetValue(strArray[num3], out num))
            {
                DataClass.GetCellValue(num, index, out data.defense.defense[(int) typeArray[num3]]);
            }
        }
        if (DataClass.columnNamesToIndex.TryGetValue(str4, out num))
        {
            DataClass.GetCellValue(num, index, out data.hitPoints);
        }
        if (DataClass.columnNamesToIndex.TryGetValue(str5, out num))
        {
            DataClass.GetCellValue(num, index, out data.recovery);
        }
        if (DataClass.columnNamesToIndex.TryGetValue(str6, out num))
        {
            DataClass.GetCellValue(num, index, out data.baseDamage);
        }
        for (num3 = 0; (num3 < strArray2.Length) && (num3 < typeArray2.Length); num3++)
        {
            if (DataClass.columnNamesToIndex.TryGetValue(strArray2[num3], out num))
            {
                DataClass.GetCellValue(num, index, out data.resistance.resistance[(int) typeArray2[num3]]);
            }
        }
        data.idleAnimSetName = string.Empty;
        data.combatAnimSetName = string.Empty;
        data.drawAnimNumber = -1;
        if (DataClass.columnNamesToIndex.TryGetValue("idle animset", out num))
        {
            DataClass.GetLCaseCellValue(num, index, out data.idleAnimSetName);
        }
        if (DataClass.columnNamesToIndex.TryGetValue("combat animset", out num))
        {
            DataClass.GetLCaseCellValue(num, index, out data.combatAnimSetName);
        }
        if (DataClass.columnNamesToIndex.TryGetValue("draw anim number", out num))
        {
            DataClass.TryGetCellValue(num, index, out data.drawAnimNumber);
        }
        if (DataClass.columnNamesToIndex.TryGetValue("mainhand model", out num))
        {
            DataClass.TryGetLCaseCellValue(num, index, out data.mainhandModelName);
        }
        if (DataClass.columnNamesToIndex.TryGetValue("offhand model", out num))
        {
            DataClass.TryGetLCaseCellValue(num, index, out data.offhandModelName);
        }
        string str12 = string.Empty;
        string str13 = string.Empty;
        if (DataClass.columnNamesToIndex.TryGetValue(str8, out num))
        {
            DataClass.GetCellValue(num, index, out str12);
        }
        if (DataClass.columnNamesToIndex.TryGetValue(str9, out num))
        {
            DataClass.GetCellValue(num, index, out str13);
        }
        data.ParseAttackSetWithError(0, new string[] { str12, str13 });
        string str14 = string.Empty;
        if (DataClass.columnNamesToIndex.TryGetValue(str7, out num))
        {
            DataClass.GetCellValue(num, index, out str14);
        }
        data.ParseAttackSetWithError(1, new string[] { str14 });
        if (DataClass.columnNamesToIndex.TryGetValue(str10, out num))
        {
            DataClass.GetCellValue(num, index, out data.aiLevel);
        }
        if ((data.aiLevel < 0) || (data.aiLevel > 0x19))
        {
            DataClass.OutputErrorMessage(str10, index, string.Concat(new object[] { "Invalid level: ", data.aiLevel, ". Must be between ", 0, " and ", 0x19, "." }));
        }
        if (DataClass.columnNamesToIndex.TryGetValue(str11, out num))
        {
            DataClass.GetCellValue(num, index, out data.moveSpeed);
        }
        for (num3 = 0; (num3 < strArray3.Length) && (num3 < nameArray.Length); num3++)
        {
            if (DataClass.columnNamesToIndex.TryGetValue(strArray3[num3], out num))
            {
                DataClass.GetCellValue(num, index, out data.skills.skills[(int) nameArray[num3]]);
            }
        }
        if (DataClass.columnNamesToIndex.TryGetValue("effect power", out num))
        {
            DataClass.GetCellValue(num, index, out data.effectPower);
        }
        if (DataClass.columnNamesToIndex.TryGetValue("effect defense", out num))
        {
            DataClass.GetCellValue(num, index, out data.effectDefense);
        }
        return data;
    }

    protected override IEnumerable<string> GetMandatoryColumns
    {
        get
        {
            return _mandatoryColumns;
        }
    }
}

