﻿using System;
using System.Collections.Generic;
using System.IO;

public class PigFileHeader
{
    public IndexedFileInfo[] fileInfo = null;
    public string[] fileNames = null;

    public static PigFileHeader CreateHeaderForFiles(string[] files)
    {
        PigFileHeader header = new PigFileHeader();
        long num = 0L;
        List<string> list = new List<string>();
        List<IndexedFileInfo> list2 = new List<IndexedFileInfo>();
        foreach (string str in files)
        {
            if (File.Exists(GUtil.PathCombine(new object[] { str })))
            {
                FileInfo info = new FileInfo(str);
                IndexedFileInfo item = new IndexedFileInfo {
                    fileSize = info.Length,
                    dataOffset = num
                };
                num += item.fileSize;
                list.Add(str);
                list2.Add(item);
            }
        }
        header.fileNames = list.ToArray();
        header.fileInfo = list2.ToArray();
        return header;
    }

    public class IndexedFileInfo
    {
        public long dataOffset;
        public long fileSize;
    }
}

