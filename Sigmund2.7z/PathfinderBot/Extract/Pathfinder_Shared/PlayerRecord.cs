﻿using GSerialize;
using Map;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;

[DataContract]
public class PlayerRecord : IDataCopyable<PlayerRecord>, IDBRecord<uint>
{
    [JsonIgnore]
    public QuestRecord[] abandonedQuests;
    [DataMember, DataRestrict]
    public uint accountId;
    [DataRestrict, DataMember]
    public string accountName;
    [DataMember, DataRestrict]
    public byte[][] advancementRecords;
    [DataRestrict, DataMember]
    public int[] attackFeatIds;
    [DataMember]
    public ulong bankCopper;
    public long baseCraftBinary;
    [DataMember]
    public InventoryItem[] bodySlots;
    [DataMember]
    public uint bonusExp;
    public CraftingQueue[] craftingQueue;
    [DataRestrict, DataMember]
    public long creationDate;
    [DataMember, DataRestrict]
    public bool deleted;
    [DataRestrict, DataMember]
    public int[] expendableFeatIds;
    [DataRestrict, DataMember]
    public FeatSelectionCache[] featSelectionCache;
    [DataMember]
    public EntityFlags flags;
    [DataMember]
    public DateTime huskExpiration;
    [DataMember]
    public ushort huskMapId = 0;
    [DataMember, DataRestrict]
    public float[] huskRaw = new float[3];
    [DataMember]
    public HuskVars.LastKnownState huskState = HuskVars.LastKnownState.UNKNOWN;
    public const uint INVALID_ID = 0;
    [DataMember]
    public InventoryItem[] inventory;
    [DataRestrict]
    public string jsonCombat;
    [DataRestrict, DataMember]
    public string keybinds;
    [DataRestrict, DataMember]
    public int level;
    [DataMember, DataRestrict]
    public ushort mapId;
    [DataMember]
    public MapPlace[] mapPlaces = null;
    public static OnWritePlayerHandler onLoadPlayer = null;
    public static OnWritePlayerHandler onWritePlayer = null;
    [DataMember, DataRestrict]
    public int[] passiveFeatIds;
    [DataRestrict, DataMember]
    public CommandCore.PermissionLevel permissions;
    [DataMember, DataRestrict]
    public PhysiqueRecord physique;
    [DataMember, DataRestrict]
    public int playerDefnId;
    [DataMember(Name="id", EmitDefaultValue=false)]
    public uint playerId;
    [DataMember]
    public string playerName;
    [DataMember, DataRestrict]
    public float posX;
    [DataMember, DataRestrict]
    public float posY;
    [DataRestrict, DataMember]
    public float posZ;
    [DataMember, DataRestrict]
    public PvpVars pvp;
    [DataMember]
    public QuestRecord[] quests;
    [DataMember, DataRestrict]
    public int[] refreshFeatIds;
    [DataMember, DataRestrict]
    public bool respawning;
    [DataRestrict, DataMember]
    public float rotW = 1f;
    [DataMember, DataRestrict]
    public float rotX;
    [DataMember, DataRestrict]
    public float rotY;
    [DataMember, DataRestrict]
    public float rotZ;
    [DataMember]
    public uint spentExp;
    [DataMember, DataRestrict]
    public InventoryItem[] tempContainer;
    [DataRestrict]
    public EntityId tempContainerEntityId = EntityId.INVALID_ID;
    [JsonIgnore]
    public InventoryItem[] trashContainer;
    [JsonIgnore]
    public Vector3 trashPos;
    [DataRestrict, DataMember]
    public int[] utilityFeatIds;

    public void AddWithAutoStack(InventoryItem newItem)
    {
        InventoryItemUtils.AddWithAutoStack(ref this.inventory, newItem);
    }

    public void AddWithAutoStack(IEnumerable<InventoryItem> newItems)
    {
        InventoryItemUtils.AddWithAutoStack(ref this.inventory, newItems);
    }

    public void CompressInventory()
    {
        SparseArray.Collapse<InventoryItem>(ref this.inventory, InventoryItem.EMPTY_MATCH, 12);
        SparseArray.Collapse<InventoryItem>(ref this.tempContainer, InventoryItem.EMPTY_MATCH, 0);
    }

    public void DataCopyTo(ref PlayerRecord target, byte syncTargetLevel)
    {
        target.playerId = this.playerId;
        target.flags = this.flags;
        target.playerName = this.playerName;
        target.bankCopper = this.bankCopper;
        target.spentExp = this.spentExp;
        target.bonusExp = this.bonusExp;
        target.baseCraftBinary = this.baseCraftBinary;
        target.trashPos = this.trashPos;
        target.huskExpiration = this.huskExpiration;
        target.huskMapId = this.huskMapId;
        target.huskState = this.huskState;
        SparseArray.DeepCopyTo<InventoryItem>(this.bodySlots, ref target.bodySlots, syncTargetLevel, InventoryItem.EMPTY_MATCH);
        SparseArray.DeepCopyTo<InventoryItem>(this.inventory, ref target.inventory, syncTargetLevel, InventoryItem.EMPTY_MATCH);
        SparseArray.DeepCopyTo<InventoryItem>(this.trashContainer, ref target.trashContainer, syncTargetLevel, InventoryItem.EMPTY_MATCH);
        SparseArray.DeepCopyTo<CraftingQueue>(this.craftingQueue, ref target.craftingQueue, syncTargetLevel, CraftingQueue.EMPTY_MATCH);
        SparseArray.DeepCopyTo<QuestRecord>(this.quests, ref target.quests, syncTargetLevel, null);
        SparseArray.DeepCopyTo<QuestRecord>(this.abandonedQuests, ref target.abandonedQuests, syncTargetLevel, null);
        SparseArray.DeepCopyTo<MapPlace>(this.mapPlaces, ref target.mapPlaces, syncTargetLevel, null);
        DataSerializerUtils.DataCopyField<float>(this.huskRaw, ref target.huskRaw);
    }

    public bool DataEquals(PlayerRecord target, byte syncTargetLevel)
    {
        if (object.ReferenceEquals(this, target))
        {
            return true;
        }
        if (object.ReferenceEquals(target, null))
        {
            return false;
        }
        bool flag = true;
        return (((((((((((((((((((flag && (this.playerId == target.playerId)) && (this.flags == target.flags)) && (this.playerName == target.playerName)) && (this.bankCopper == target.bankCopper)) && (this.spentExp == target.spentExp)) && (this.bonusExp == target.bonusExp)) && (this.baseCraftBinary == target.baseCraftBinary)) && ((this.trashPos - target.trashPos).sqrMagnitude < 1f)) && (target.huskExpiration == this.huskExpiration)) && (target.huskMapId == this.huskMapId)) && (target.huskState == this.huskState)) && SparseArray.DeepEqualsWithIndex<InventoryItem>(this.bodySlots, target.bodySlots, syncTargetLevel, InventoryItem.EMPTY_MATCH)) && SparseArray.DeepEqualsWithIndex<InventoryItem>(this.inventory, target.inventory, syncTargetLevel, InventoryItem.EMPTY_MATCH)) && SparseArray.DeepEqualsWithIndex<InventoryItem>(this.trashContainer, target.trashContainer, syncTargetLevel, InventoryItem.EMPTY_MATCH)) && SparseArray.DeepEqualsWithIndex<CraftingQueue>(this.craftingQueue, target.craftingQueue, syncTargetLevel, CraftingQueue.EMPTY_MATCH)) && SparseArray.DeepEqualsWithIndex<QuestRecord>(this.quests, target.quests, syncTargetLevel)) && SparseArray.DeepEqualsWithIndex<QuestRecord>(this.abandonedQuests, target.abandonedQuests, syncTargetLevel)) && SparseArray.DeepEqualsWithIndex<MapPlace>(this.mapPlaces, target.mapPlaces, syncTargetLevel)) && SparseArray.DeepEqualsWithIndex<float>(this.huskRaw, target.huskRaw));
    }

    public PlayerInfo GenerateInfo(bool isTraining)
    {
        return new PlayerInfo(this.playerId, this.playerName, this.deleted, isTraining, this.playerDefnId, this.flags, this.permissions, this.physique, this.level, this.bodySlots);
    }

    public IEnumerable<QuestRecord> GetActiveQuests()
    {
        if (this.quests == null)
        {
            this.quests = new QuestRecord[1];
        }
        return SparseArray.Iterate<QuestRecord>(this.quests);
    }

    public int GetAdvancementHashCode()
    {
        int num = 0;
        for (int i = 0; i < this.advancementRecords.Length; i++)
        {
            num += RecordUtils.ByteArrayHash(this.advancementRecords[i]);
        }
        return num;
    }

    public uint GetDBKey()
    {
        return this.playerId;
    }

    public QuestRecord GetQuest(int questId)
    {
        return SparseArray.Find<QuestRecord>(this.quests, a => a.questId == questId);
    }

    public int GetQuestHashCode()
    {
        int num = 0;
        if (this.quests != null)
        {
            foreach (QuestRecord record in SparseArray.Iterate<QuestRecord>(this.quests))
            {
                num += record.GetQuestHashCode();
            }
        }
        if (this.abandonedQuests != null)
        {
            foreach (QuestRecord record in SparseArray.Iterate<QuestRecord>(this.abandonedQuests))
            {
                num += record.GetQuestHashCode();
            }
        }
        return num;
    }

    public void InitInventory()
    {
        this.bodySlots = new InventoryItem[0x11];
        this.trashPos = GConst.VECTOR3_INVALID;
    }

    public void LoadBodySlots(PlayerGear playerGear)
    {
        if ((this.bodySlots == null) || (this.bodySlots.Length != 0x11))
        {
            InventoryItemUtils.AddWithAutoStack(ref this.inventory, this.bodySlots);
            this.bodySlots = new InventoryItem[0x11];
        }
        playerGear.bodySlots = this.bodySlots;
    }

    public void LoadInventoryStats(CombatClassVars combatClassVars, AdvancementVars advancementVars)
    {
        combatClassVars.LoadInventoryStats(this.bodySlots, advancementVars);
    }

    public void OnDBLoad()
    {
        if (onLoadPlayer != null)
        {
            onLoadPlayer(this);
        }
    }

    public void OnDBUnload()
    {
    }

    public void OnDBWrite()
    {
        if (onWritePlayer != null)
        {
            onWritePlayer(this);
        }
    }

    public void RemoveQuest(QuestRecord questRecord, bool isAbandon)
    {
        int index = SparseArray.IndexOf<QuestRecord>(this.quests, a => a.questId == questRecord.questId);
        if (index > -1)
        {
            if (isAbandon)
            {
                SparseArray.Add<QuestRecord>(ref this.abandonedQuests, this.quests[index]);
            }
            this.quests[index] = null;
        }
    }

    public void ResetTempContainer(EntityId entityId, InventoryItem[] newItems)
    {
        this.tempContainerEntityId = entityId;
        if ((this.tempContainer == null) || (newItems.Length > this.tempContainer.Length))
        {
            Array.Resize<InventoryItem>(ref this.tempContainer, newItems.Length);
        }
        Array.Copy(newItems, this.tempContainer, newItems.Length);
        for (int i = newItems.Length; i < this.tempContainer.Length; i++)
        {
            this.tempContainer[i] = InventoryItem.EMPTY;
        }
    }

    public void SetHuskInfo(DateTime setExpire, Vector3 setPos, ushort setMapId, HuskVars.LastKnownState setState)
    {
        this.huskExpiration = setExpire;
        this.huskRaw[0] = setPos.x;
        this.huskRaw[1] = setPos.y;
        this.huskRaw[2] = setPos.z;
        this.huskMapId = setMapId;
        this.huskState = setState;
        this.UpdateHuskIcon(setState);
    }

    public void SetQuest(QuestRecord questRecord)
    {
        this.abandonedQuests = null;
        QuestRecord record = SparseArray.Find<QuestRecord>(this.quests, a => a.questId == questRecord.questId);
        if (record == null)
        {
            record = new QuestRecord();
            SparseArray.Add<QuestRecord>(ref this.quests, record);
        }
        questRecord.DataCopyTo(ref record, 0xff);
    }

    public void UndoQuestAbandons()
    {
        if (this.abandonedQuests != null)
        {
            uint probableIndex = 0;
            for (int i = 0; i < this.abandonedQuests.Length; i++)
            {
                if (this.abandonedQuests[i] != null)
                {
                    probableIndex = SparseArray.Add<QuestRecord>(ref this.quests, this.abandonedQuests[i], probableIndex);
                }
            }
            this.abandonedQuests = null;
        }
    }

    public void UpdateHuskIcon(HuskVars.LastKnownState setState)
    {
        this.huskState = setState;
        MapPlace.ClearType(ref this.mapPlaces, PlaceType.PLAYER_HUSK);
        if (setState != HuskVars.LastKnownState.INVALID)
        {
            SparseArray.Add<MapPlace>(ref this.mapPlaces, new MapPlace(IconType.PLACE, PlaceType.PLAYER_HUSK, (ulong) this.playerId, this.huskMapId, this.huskPos, HuskVars.HOVER_TEXT[setState]));
        }
    }

    [JsonIgnore]
    public Vector3 huskPos
    {
        get
        {
            if (this.huskRaw == null)
            {
                this.huskRaw = new float[3];
            }
            return new Vector3(this.huskRaw[0], this.huskRaw[1], this.huskRaw[2]);
        }
    }

    [JsonIgnore]
    public Vector3 position
    {
        get
        {
            return new Vector3(this.posX, this.posY, this.posZ);
        }
        set
        {
            this.posX = value.x;
            this.posY = value.y;
            this.posZ = value.z;
        }
    }

    [JsonIgnore]
    public Quaternion rotation
    {
        get
        {
            return new Quaternion(this.rotX, this.rotY, this.rotZ, this.rotW);
        }
        set
        {
            this.rotX = value.x;
            this.rotY = value.y;
            this.rotZ = value.z;
            this.rotW = value.w;
        }
    }

    public delegate void OnWritePlayerHandler(PlayerRecord record);
}

