﻿using System;
using UnityEngine;

public class ShaderHolder : MonoBehaviour
{
    public TextAsset materialDictionary;
    public Material[] materials;
    public Shader[] shaders;

    private void Awake()
    {
        ResourceManager.RegisterMaterials(this, true);
    }
}

