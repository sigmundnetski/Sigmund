﻿using System;

[AttributeUsage(AttributeTargets.Method, AllowMultiple=false)]
public class UUnitSystemTestMethod : UBaseAttribute
{
    public UUnitSystemTestMethod()
    {
    }

    public UUnitSystemTestMethod(bool setActive) : base(setActive)
    {
    }
}

