﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;

[StrongDependency(typeof(LocationTriggerData)), LooseDependency(typeof(TextBlobData)), StrongDependency(typeof(InteractKeywordData)), LooseDependency(typeof(GlobalActorData))]
public class QuestData : DataClass
{
    public HashSet<int> allActorIds = new HashSet<int>();
    public string displayName = "";
    public bool eventQuest = false;
    public string failureHudText = "";
    private static char[] FLOW_IGNORE_CHARS = new char[] { ' ', ',' };
    public string longDescription = "";
    public int lootTableId = 0;
    public int offeredByActorId = 0;
    public static Dictionary<int, QuestData> questById = new Dictionary<int, QuestData>();
    public static Dictionary<string, QuestData> questByName = new Dictionary<string, QuestData>();
    public string shortDescription = "";
    public List<BaseQuestState> states = new List<BaseQuestState>();
    public string successHudText = "";
    private static HashSet<string> tempMissingBlobs = new HashSet<string>();
    private static HashSet<int> tempQuestIds = new HashSet<int>();

    public static void AppendObjective(StringBuilder quickText, QuestRecord qRecord, bool longStateText)
    {
        QuestData data;
        if ((qRecord != null) && questById.TryGetValue(qRecord.questId, out data))
        {
            BaseQuestState currentState = GetCurrentState(qRecord);
            if (currentState == null)
            {
                quickText.Append((qRecord.questStatus == (EscalationConst.Flow.INCOMPLETE | EscalationConst.Flow.SUCCESS)) ? data.successHudText : data.failureHudText);
            }
            else
            {
                quickText.Append((longStateText && !string.IsNullOrEmpty(currentState.description)) ? currentState.description : currentState.hudText);
                if (currentState.goal > 1)
                {
                    quickText.Append(" (");
                    quickText.Append(qRecord.stateCounterValue);
                    quickText.Append("/");
                    quickText.Append(currentState.goal);
                    quickText.Append(")");
                }
            }
        }
    }

    public static BaseQuestState GetCurrentState(QuestRecord qRecord)
    {
        QuestData data;
        if ((((qRecord != null) && questById.TryGetValue(qRecord.questId, out data)) && (0 <= qRecord.stateIndex)) && (qRecord.stateIndex < data.states.Count))
        {
            return data.states[qRecord.stateIndex];
        }
        return null;
    }

    public static string GetObjective(QuestRecord qRecord, bool longStateText)
    {
        QuestData data;
        if ((qRecord != null) && questById.TryGetValue(qRecord.questId, out data))
        {
            switch (qRecord.questStatus)
            {
                case (EscalationConst.Flow.INCOMPLETE | EscalationConst.Flow.SUCCESS):
                    return data.successHudText;

                case EscalationConst.Flow.FAILURE:
                    return data.failureHudText;
            }
            if ((0 <= qRecord.stateIndex) && (qRecord.stateIndex < data.states.Count))
            {
                BaseQuestState state = data.states[qRecord.stateIndex];
                return ((longStateText && !string.IsNullOrEmpty(state.description)) ? state.description : state.hudText);
            }
        }
        return null;
    }

    public static void OnLoad(List<DataClass> objects)
    {
        foreach (QuestData data in objects)
        {
            if (data.Validate(true))
            {
                questById[data.id] = data;
                questByName[data.name] = data;
            }
        }
    }

    private static void ParseFailure(ref int curRow, ref QuestData eachQuest)
    {
        DataClass.GetCellValue(2, curRow, out eachQuest.failureHudText);
        if (string.IsNullOrEmpty(eachQuest.successHudText))
        {
            DataClass.OutputErrorMessage(2, curRow, "Failure text must be defined (even as a placeholder if failure can't happen), for Quest: " + eachQuest.name);
        }
    }

    private static void ParseFlavorText(ref int curRow, ref BaseQuestState curState, ref QuestData eachQuest)
    {
        string str;
        string str2;
        DataClass.GetLCaseCellValue(2, curRow, out str2);
        DataClass.GetCellValue(3, curRow, out str);
        int key = DataClass.GenerateId(str2);
        if (string.IsNullOrEmpty(str2))
        {
            DataClass.OutputErrorMessage(2, curRow, "FlavorText has no actor, in state:" + curState);
        }
        else if ((key == curState.actorId) || curState.flavorTexts.ContainsKey(key))
        {
            DataClass.OutputErrorMessage(2, curRow, "An actor can only be defined once per state.");
        }
        else
        {
            curState.flavorTexts.Add(key, str);
            eachQuest.allActorIds.Add(key);
        }
    }

    private static void ParseFlow(out EscalationConst.Flow flow, string cellContents, int column, int row)
    {
        flow = EscalationConst.Flow.INCOMPLETE;
        List<GSStatement> list = null;
        if (!string.IsNullOrEmpty(cellContents.Trim()))
        {
            try
            {
                list = GoblinSpec.Parse(cellContents);
            }
            catch (ParseException)
            {
                DataClass.OutputErrorMessage(column, row, "The following is not properly formatted GoblinSpec language:" + cellContents);
            }
        }
        if (list != null)
        {
            foreach (GSStatement statement in list)
            {
                switch (statement.statement)
                {
                    case "success":
                        flow = (EscalationConst.Flow) ((byte) (flow | (EscalationConst.Flow.INCOMPLETE | EscalationConst.Flow.SUCCESS)));
                        flow = (EscalationConst.Flow) ((byte) (((int) flow) & 0xfd));
                        break;

                    case "failure":
                        flow = (EscalationConst.Flow) ((byte) (flow | EscalationConst.Flow.FAILURE));
                        flow = (EscalationConst.Flow) ((byte) (((int) flow) & 0xfe));
                        break;

                    case "reward":
                        DataClass.OutputErrorMessage(column, row, "Reward is no longer a keyword, it is automatic");
                        break;

                    case "previous":
                        flow = (EscalationConst.Flow) ((byte) (flow | (EscalationConst.Flow.INCOMPLETE | EscalationConst.Flow.PREVIOUS)));
                        flow = (EscalationConst.Flow) ((byte) (((int) flow) & 0xdf));
                        flow = (EscalationConst.Flow) ((byte) (((int) flow) & 0xbf));
                        break;

                    case "next":
                        flow = (EscalationConst.Flow) ((byte) (flow | (EscalationConst.Flow.INCOMPLETE | EscalationConst.Flow.NEXT)));
                        flow = (EscalationConst.Flow) ((byte) (((int) flow) & 0xef));
                        flow = (EscalationConst.Flow) ((byte) (((int) flow) & 0xbf));
                        break;

                    case "restart":
                        flow = (EscalationConst.Flow) ((byte) (flow | (EscalationConst.Flow.INCOMPLETE | EscalationConst.Flow.RESTART)));
                        flow = (EscalationConst.Flow) ((byte) (((int) flow) & 0xef));
                        flow = (EscalationConst.Flow) ((byte) (((int) flow) & 0xdf));
                        break;

                    default:
                        DataClass.OutputErrorMessage(column, row, "The following identifier is not known:" + statement.statement);
                        break;
                }
            }
        }
        if (((byte) (flow & (EscalationConst.Flow.FAILURE | EscalationConst.Flow.SUCCESS))) == 0)
        {
            flow = (EscalationConst.Flow) ((byte) (flow | (EscalationConst.Flow.INCOMPLETE | EscalationConst.Flow.SUCCESS)));
        }
        if (((byte) (flow & (EscalationConst.Flow.INCOMPLETE | EscalationConst.Flow.NEXT | EscalationConst.Flow.PREVIOUS | EscalationConst.Flow.RESTART))) == 0)
        {
            flow = (EscalationConst.Flow) ((byte) (flow | (EscalationConst.Flow.INCOMPLETE | EscalationConst.Flow.NEXT)));
        }
    }

    private static void ParseQuest(ref int curRow, ref QuestData eachQuest)
    {
        string str;
        DataClass.GetLCaseCellValue(2, curRow, out eachQuest.name);
        DataClass.GetLCaseCellValue(3, curRow, out str);
        if (str.Contains("eventquest"))
        {
            eachQuest.eventQuest = true;
        }
        curRow++;
    }

    public override List<DataClass> ParseSheet()
    {
        QuestData eachQuest = new QuestData();
        bool flag = false;
        int row = 4;
        int num2 = row - 1;
        BaseQuestState curState = null;
        while (row <= DataClass.MAX_ROW)
        {
            string str;
            if (num2 == row)
            {
                row++;
            }
            num2 = row;
            if (!DataClass.TryGetLCaseCellValue(1, row, out str))
            {
                continue;
            }
            switch (str)
            {
                case "quest":
                    if (flag)
                    {
                        break;
                    }
                    ParseQuest(ref row, ref eachQuest);
                    goto Label_01C1;

                case "displayname":
                {
                    DataClass.GetCellValue(2, row, out eachQuest.displayName);
                    continue;
                }
                case "shortdescription":
                {
                    DataClass.GetCellValue(2, row, out eachQuest.shortDescription);
                    continue;
                }
                case "longdescription":
                {
                    DataClass.GetCellValue(2, row, out eachQuest.longDescription);
                    continue;
                }
                case "success":
                {
                    ParseSuccess(ref row, ref eachQuest);
                    continue;
                }
                case "reward":
                {
                    DataClass.TryGetIdFromForeignName<LootTableData>(2, row, out eachQuest.lootTableId);
                    continue;
                }
                case "failure":
                {
                    ParseFailure(ref row, ref eachQuest);
                    continue;
                }
                case "offeredby":
                {
                    DataClass.GetIdFromForeignName<GlobalActorData>(2, row, out eachQuest.offeredByActorId);
                    continue;
                }
                case "loottable":
                {
                    if (curState != null)
                    {
                        DataClass.GetIdFromForeignName<LootTableData>(2, row, out curState.rewardTableId);
                    }
                    continue;
                }
                case "flavortext":
                {
                    if (curState != null)
                    {
                        ParseFlavorText(ref row, ref curState, ref eachQuest);
                    }
                    continue;
                }
                case "timelimit":
                {
                    if (curState != null)
                    {
                        ParseTimeLimit(ref row, ref curState);
                    }
                    continue;
                }
                case "statecomplete":
                {
                    if (curState != null)
                    {
                        ParseStateComplete(ref row, ref curState);
                    }
                    continue;
                }
                case "stateoptions":
                {
                    if (curState != null)
                    {
                        curState.ParseStateOptions(ref row);
                    }
                    continue;
                }
                case "interactkeywords":
                {
                    if (curState != null)
                    {
                        DataClass.GetIdsFromForeignNames<InteractKeywordData>(2, row, out curState.interactKeywordIds);
                    }
                    continue;
                }
                case "incrementevent":
                {
                    if (curState != null)
                    {
                        DataClass.GetCellValue(2, row, out curState.incrementEvent);
                        if (curState.incrementEvent <= 0)
                        {
                            DataClass.OutputErrorMessage(2, row, "Must be a positive integer.");
                        }
                    }
                    continue;
                }
                case "blobtext":
                {
                    if (curState != null)
                    {
                        DataClass.GetCellValue(2, row, out curState.autoDisplayBlob);
                        DataClass.GetIdFromForeignName<TextBlobData>(3, row, out curState.blobId);
                    }
                    continue;
                }
                case "startquest":
                {
                    if (curState != null)
                    {
                        DataClass.GetIdsFromForeignNames<QuestData>(2, row, out curState.dependentQuests);
                        if (curState.dependentQuests.Length == 0)
                        {
                            DataClass.OutputErrorMessage(2, row, "No valid dependent quests defined");
                        }
                    }
                    continue;
                }
                default:
                {
                    ParseStateType(ref eachQuest, ref row, str, ref curState);
                    continue;
                }
            }
            DataClass.OutputErrorMessage(1, row, "Only 1 quest allowed per page");
        Label_01C1:
            flag = true;
        }
        List<DataClass> list = new List<DataClass>();
        if (eachQuest.Validate(true))
        {
            list.Add(eachQuest);
        }
        return list;
    }

    private static void ParseStateComplete(ref int curRow, ref BaseQuestState curState)
    {
        string str;
        DataClass.GetCellValue(2, curRow, out str);
        ParseFlow(out curState.flow, str, 2, curRow);
    }

    private static void ParseStateType(ref QuestData outputQuest, ref int curRow, string keyword, ref BaseQuestState curState)
    {
        EscalationConst.StateType type;
        if (GUtil.TryParseEnum<EscalationConst.StateType>(keyword, EscalationConst.StateType.INVALID, out type))
        {
            curState = new BaseQuestState();
            curState.stateType = type;
            switch (type)
            {
                case EscalationConst.StateType.Goto:
                    curState.ParseStateDetails(ref curRow, ref outputQuest, -1, -1, -1, 3, 4, 2, -1);
                    break;

                case EscalationConst.StateType.Interact:
                    curState.ParseStateDetails(ref curRow, ref outputQuest, 2, 3, 4, 5, 6, -1, -1);
                    break;

                case EscalationConst.StateType.InteractKeyword:
                    curState.ParseStateDetails(ref curRow, ref outputQuest, -1, 3, -1, 4, 5, -1, 2);
                    break;

                case EscalationConst.StateType.Kill:
                    curState.ParseStateDetails(ref curRow, ref outputQuest, 2, 3, -1, 4, 5, -1, -1);
                    break;

                case EscalationConst.StateType.AttackTarget:
                    curState.ParseStateDetails(ref curRow, ref outputQuest, 2, 3, -1, 4, 5, -1, -1);
                    break;

                case EscalationConst.StateType.BeginCraft:
                    curState.ParseStateDetails(ref curRow, ref outputQuest, -1, -1, -1, 2, 3, -1, -1);
                    break;

                case EscalationConst.StateType.BuyFeat:
                    curState.ParseStateDetails(ref curRow, ref outputQuest, -1, -1, -1, 2, 3, -1, -1);
                    break;

                case EscalationConst.StateType.HotBarFeatSet:
                    curState.ParseStateDetails(ref curRow, ref outputQuest, -1, -1, -1, 2, 3, -1, -1);
                    break;

                case EscalationConst.StateType.Move:
                    curState.ParseStateDetails(ref curRow, ref outputQuest, -1, -1, -1, 2, 3, -1, -1);
                    break;

                case EscalationConst.StateType.PassiveFeatSet:
                    curState.ParseStateDetails(ref curRow, ref outputQuest, -1, -1, -1, 2, 3, -1, -1);
                    break;

                case EscalationConst.StateType.SetRun:
                    curState.ParseStateDetails(ref curRow, ref outputQuest, -1, -1, -1, 2, 3, -1, -1);
                    break;

                case EscalationConst.StateType.SetStealth:
                    curState.ParseStateDetails(ref curRow, ref outputQuest, -1, -1, -1, 2, 3, -1, -1);
                    break;

                case EscalationConst.StateType.SetWalk:
                    curState.ParseStateDetails(ref curRow, ref outputQuest, -1, -1, -1, 2, 3, -1, -1);
                    break;
            }
        }
        else
        {
            DataClass.OutputErrorMessage(1, curRow, "Unknown keyword: " + keyword + ".  State Options are: " + GUtil.PrettyPrint(Enum.GetNames(typeof(EscalationConst.StateType)), ", ", "[]"));
        }
    }

    private static void ParseSuccess(ref int curRow, ref QuestData eachQuest)
    {
        DataClass.GetCellValue(2, curRow, out eachQuest.successHudText);
        if (string.IsNullOrEmpty(eachQuest.successHudText))
        {
            DataClass.OutputErrorMessage(2, curRow, "Success text must be defined, for Quest: " + eachQuest.name);
        }
    }

    private static void ParseTimeLimit(ref int curRow, ref BaseQuestState curState)
    {
        string str;
        curState.timeLimit = new EventTimeLimit();
        DataClass.GetTimeValue(2, curRow, 3, curRow, out curState.timeLimit.duration);
        DataClass.GetCellValue(4, curRow, out str);
        ParseFlow(out curState.timeLimit.flow, str, 4, curRow);
        curRow++;
    }

    public override string ToString()
    {
        return string.Format("QuestData({0},{1},\"{2}\")", base.id, this.states.Count, base.name);
    }

    public bool Validate(bool logErrors)
    {
        bool flag = true;
        flag = this.Validate_ZeroStates(logErrors) && flag;
        flag = this.Validate_FirstStateFlow(logErrors) && flag;
        flag = this.Validate_EventQuest(logErrors) && flag;
        flag = this.Validate_PersonalQuest(logErrors) && flag;
        flag = this.Validate_Blobs(logErrors) && flag;
        return (this.Validate_Texts(logErrors) && flag);
    }

    private bool Validate_Blobs(bool logErrors)
    {
        int num = 0;
        tempMissingBlobs.Clear();
        foreach (BaseQuestState state in this.states)
        {
            if (state.blobId == 0)
            {
                tempMissingBlobs.Add(state.hudText);
            }
            else
            {
                num++;
            }
        }
        bool flag = (num == 0) || (num == this.states.Count);
        if (!(!logErrors || flag))
        {
            DataClass.OutputErrorMessage("Missing blob-texts in these states:" + GUtil.PrettyPrint(tempMissingBlobs, ", ", "[]"));
        }
        return flag;
    }

    private bool Validate_EventQuest(bool logErrors)
    {
        int num = 0;
        foreach (BaseQuestState state in this.states)
        {
            num += state.incrementEvent;
        }
        if (this.eventQuest != (num > 0))
        {
            DataClass.OutputErrorMessage("An Event Quest must \"IncrementEvent\" in at least one state.");
        }
        bool flag = true;
        if ((this.states.Count > 0) && this.eventQuest)
        {
            BaseQuestState state2 = this.states[this.states.Count - 1];
            flag &= this.Validate_FinalEventFlow(logErrors, state2.flow);
            if (state2.timeLimit != null)
            {
                flag &= this.Validate_FinalEventFlow(logErrors, state2.timeLimit.flow);
            }
        }
        return (flag && (this.eventQuest == (num > 0)));
    }

    private bool Validate_FinalEventFlow(bool logErrors, EscalationConst.Flow testFlow)
    {
        bool flag = ((byte) (testFlow & (EscalationConst.Flow.INCOMPLETE | EscalationConst.Flow.NEXT))) == 0x20;
        bool flag2 = ((byte) (testFlow & (EscalationConst.Flow.INCOMPLETE | EscalationConst.Flow.PREVIOUS))) == 0x10;
        bool flag3 = ((byte) (testFlow & (EscalationConst.Flow.INCOMPLETE | EscalationConst.Flow.RESTART))) == 0x40;
        if (logErrors && (flag || (!flag2 && !flag3)))
        {
            DataClass.OutputErrorMessage(base.name + " is an event quest, so it must cycle or restart: " + testFlow);
        }
        return (!flag && (flag2 || flag3));
    }

    private bool Validate_FirstStateFlow(bool logErrors)
    {
        if (this.states.Count == 0)
        {
            return true;
        }
        bool flag = ((byte) (this.states[0].flow & (EscalationConst.Flow.INCOMPLETE | EscalationConst.Flow.PREVIOUS))) == 0x10;
        if (logErrors && flag)
        {
            DataClass.OutputErrorMessage(string.Concat(new object[] { "The first state cannot transition backwards:", base.name, ",\n", this.states[0], "\n" }));
        }
        bool flag2 = false;
        if (this.states[0].timeLimit != null)
        {
            flag2 = ((byte) (this.states[0].timeLimit.flow & (EscalationConst.Flow.INCOMPLETE | EscalationConst.Flow.PREVIOUS))) == 0x10;
            if (logErrors && flag2)
            {
                DataClass.OutputErrorMessage(string.Concat(new object[] { "The first state timer cannot transition backwards:", base.name, ",\n", this.states[0], "\n" }));
            }
        }
        return (!flag && !flag2);
    }

    private bool Validate_PersonalQuest(bool logErrors)
    {
        bool flag = this.eventQuest == (this.offeredByActorId == 0);
        if (!(!logErrors || flag))
        {
            DataClass.OutputErrorMessage("Personal quests must provide a valid \"OfferedBy\" actor field.");
        }
        bool flag2 = true;
        tempQuestIds.Clear();
        foreach (BaseQuestState state in this.states)
        {
            if (state.dependentQuests != null)
            {
                tempQuestIds.UnionWith(state.dependentQuests);
            }
        }
        foreach (int num in tempQuestIds)
        {
            QuestData data;
            if (questById.TryGetValue(num, out data))
            {
                flag2 &= !data.eventQuest;
                if (logErrors && data.eventQuest)
                {
                    DataClass.OutputErrorMessage(this.displayName + " cannot start event quests as dependent quests.");
                }
            }
        }
        if (this.eventQuest && (tempQuestIds.Count > 0))
        {
            flag2 = false;
            if (logErrors)
            {
                DataClass.OutputErrorMessage("Event quests cannot start personal quests");
            }
        }
        return (flag && flag2);
    }

    private bool Validate_Texts(bool logErrors)
    {
        bool flag = false;
        flag |= !this.eventQuest && string.IsNullOrEmpty(this.displayName);
        if (!(this.eventQuest || !string.IsNullOrEmpty(this.displayName)))
        {
            DataClass.OutputErrorMessage(base.name + " must have a displayName");
        }
        flag |= !this.eventQuest && string.IsNullOrEmpty(this.shortDescription);
        if (!(this.eventQuest || !string.IsNullOrEmpty(this.shortDescription)))
        {
            DataClass.OutputErrorMessage(base.name + " must have a short description");
        }
        flag |= !this.eventQuest && string.IsNullOrEmpty(this.longDescription);
        if (!(this.eventQuest || !string.IsNullOrEmpty(this.longDescription)))
        {
            DataClass.OutputErrorMessage(base.name + " must have a long description");
        }
        return !flag;
    }

    private bool Validate_ZeroStates(bool logErrors)
    {
        bool flag = this.states.Count > 0;
        if (!(!logErrors || flag))
        {
            DataClass.OutputErrorMessage("A quest must have at least one state.");
        }
        return flag;
    }
}

