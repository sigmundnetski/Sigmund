﻿using GNetwork;
using GSerialize;
using System;

[DataContract]
public class VentureCompanyMember : IDataCopyable<VentureCompanyMember>
{
    [DataMember]
    public MemberPermission permissions;
    [DataMember]
    public uint playerId;
    [DataMember]
    public string playerName;
    [DataMember]
    public byte priority;

    public VentureCompanyMember()
    {
        this.playerId = 0;
    }

    public VentureCompanyMember(uint playerId, string playerName)
    {
        this.playerId = playerId;
        this.playerName = playerName;
        this.permissions = MemberPermission.NONE;
    }

    public void DataCopyTo(ref VentureCompanyMember target, byte syncTargetLevel)
    {
        target.playerId = this.playerId;
        target.playerName = this.playerName;
        target.permissions = this.permissions;
        target.priority = this.priority;
    }

    public bool DataEquals(VentureCompanyMember target, byte syncTargetLevel)
    {
        if (object.ReferenceEquals(target, null))
        {
            return false;
        }
        bool flag = true;
        return ((((flag && (target.playerId == this.playerId)) && (target.playerName == this.playerName)) && (target.permissions == this.permissions)) && (target.priority == this.priority));
    }

    public bool HasPermission(MemberPermission flag)
    {
        return (((ushort) (this.permissions & flag)) == flag);
    }

    public bool IsLeader()
    {
        return (((int) this.permissions) == 0xffff);
    }

    public static VentureCompanyMember PopFromBuffer(IBitBufferRead buffer)
    {
        return new VentureCompanyMember { playerId = buffer.PopUInt(), playerName = buffer.PopString(), permissions = (MemberPermission) buffer.PopUShort(), priority = buffer.PopByte() };
    }

    public void PushToBuffer(IBitBufferWrite buffer)
    {
        buffer.PushUInt(this.playerId);
        buffer.PushString(this.playerName);
        buffer.PushUShort((ushort) this.permissions);
        buffer.PushByte(this.priority);
    }

    public override string ToString()
    {
        return string.Concat(new object[] { "<VCM ", this.playerId, ", ", this.playerName, ", ", this.permissions, ">" });
    }

    [Flags]
    public enum MemberPermission : ushort
    {
        ALLY_INVITE = 0x20,
        ALLY_KICK = 0x40,
        EDIT = 8,
        FULL = 0xffff,
        INVITE = 1,
        KICK = 4,
        NONE = 0,
        PROMOTE = 2,
        PVP = 0x10
    }
}

