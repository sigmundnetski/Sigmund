﻿using System;
using System.Collections.Generic;

public class AiData : DataClass
{
    public float chaseDistance = 0f;
    public float damageToEnmityConversion = 0f;
    public float destinationErrorRange = 0f;
    public float enmityDecay = 0f;
    public float entityInRangeEnmity = 0f;
    public float frustrationDuration = 0f;
    public float groupDistance = 0f;
    public float repathFrequency = 0f;

    public override void ParseRecord(ref DataClass obj, int index)
    {
        AiData data = (AiData) obj;
        if (data == null)
        {
            data = new AiData();
        }
        string output = string.Empty;
        string str2 = string.Empty;
        if (DataClass.TryGetCellValue("A", index, out output))
        {
            DataClass.GetCellValue("B", index, out str2);
            switch (output)
            {
                case "Damge Converted to Enmity":
                    float.TryParse(str2, out data.damageToEnmityConversion);
                    break;

                case "Enmity Decay":
                    float.TryParse(str2, out data.enmityDecay);
                    break;

                case "Entity in Range Enmity":
                    float.TryParse(str2, out data.entityInRangeEnmity);
                    break;

                case "Chase Distance":
                    float.TryParse(str2, out data.chaseDistance);
                    break;

                case "Grouping Distance":
                    float.TryParse(str2, out data.groupDistance);
                    break;

                case "Frustration Duration":
                    float.TryParse(str2, out data.frustrationDuration);
                    break;

                case "Repath Frequency":
                    float.TryParse(str2, out data.repathFrequency);
                    break;

                case "Destination Error Range":
                    float.TryParse(str2, out data.destinationErrorRange);
                    break;
            }
            obj = data;
        }
    }

    public override List<DataClass> ParseSheet()
    {
        List<DataClass> list = new List<DataClass>();
        DataClass class2 = null;
        for (int i = 4; i <= DataClass.data.GetLength(0); i++)
        {
            this.ParseRecord(ref class2, i);
        }
        if (class2 != null)
        {
            list.Add(class2);
        }
        return list;
    }

    public enum AiType : byte
    {
        AiGrunt = 1,
        AiGuard = 2,
        NONE = 0
    }
}

