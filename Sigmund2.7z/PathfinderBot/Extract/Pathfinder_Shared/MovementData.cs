﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

public class MovementData : DataClass
{
    private float fastestJog = 0f;
    private float fastestRun = 0f;
    private float fastestRunStrafe = 0f;
    private float fastestWalk = 0f;
    private float fastestWalkBack = 0f;
    private float fastestWalkStrafe = 0f;
    private float jogAnimSpeed = 0f;
    public float jumpGravity = 0f;
    public float jumpImpulse = 0f;
    public float jumpToFallTime = 0f;
    public float jumpToLandTransition = 0f;
    public float jumpToSuperFallTime = 0f;
    public float maxBackwardSpeed = 0f;
    public float maxForwardSpeed = 0f;
    public float maxStrafeSpeed = 0f;
    public float minBackwardSpeed = 0f;
    public float minForwardSpeed = 0f;
    public float minStrafeSpeed = 0f;
    public float normalGravity = 0f;
    public float rotateSpeed = 0f;
    private float runAnimSpeed = 0f;
    public float runRotateSpeed = 0f;
    private float runStrafeAnimSpeed = 0f;
    public float slideSpeed;
    public int slopeLimit;
    private float slowestJog = 0f;
    private float slowestRun = 0f;
    private float slowestRunStrafe = 0f;
    private float slowestWalk = 0f;
    private float slowestWalkBack = 0f;
    private float slowestWalkStrafe = 0f;
    public float terminalVelocity = 0f;
    private float walkAnimSpeed = 0f;
    private float walkBackAnimSpeed = 0f;
    private float walkStrafeAnimSpeed = 0f;

    public static void OnLoad(List<DataClass> objects)
    {
        singleton = (MovementData) objects[0];
    }

    public override void ParseRecord(ref DataClass obj, int index)
    {
        MovementData data = (MovementData) obj;
        if (data == null)
        {
            data = new MovementData();
        }
        string output = string.Empty;
        string str2 = string.Empty;
        if (DataClass.TryGetCellValue("A", index, out output))
        {
            DataClass.GetCellValue("B", index, out str2);
            switch (output.Trim().ToLower())
            {
                case "walk anim speed":
                    float.TryParse(str2, out data.walkAnimSpeed);
                    break;

                case "slowest walk":
                    float.TryParse(str2, out data.slowestWalk);
                    break;

                case "fastest walk":
                    float.TryParse(str2, out data.fastestWalk);
                    break;

                case "jog anim speed":
                    float.TryParse(str2, out data.jogAnimSpeed);
                    break;

                case "slowest jog":
                    float.TryParse(str2, out data.slowestJog);
                    break;

                case "fastest jog":
                    float.TryParse(str2, out data.fastestJog);
                    break;

                case "run anim speed":
                    float.TryParse(str2, out data.runAnimSpeed);
                    break;

                case "slowest run":
                    float.TryParse(str2, out data.slowestRun);
                    break;

                case "fastest run":
                    float.TryParse(str2, out data.fastestRun);
                    break;

                case "walk back anim speed":
                    float.TryParse(str2, out data.walkBackAnimSpeed);
                    break;

                case "slowest walk back":
                    float.TryParse(str2, out data.slowestWalkBack);
                    break;

                case "fastest walk back":
                    float.TryParse(str2, out data.fastestWalkBack);
                    break;

                case "walk strafe anim speed":
                    float.TryParse(str2, out data.walkStrafeAnimSpeed);
                    break;

                case "slowest walk strafe":
                    float.TryParse(str2, out data.slowestWalkStrafe);
                    break;

                case "fastest walk strafe":
                    float.TryParse(str2, out data.fastestWalkStrafe);
                    break;

                case "run strafe anim speed":
                    float.TryParse(str2, out data.runStrafeAnimSpeed);
                    break;

                case "slowest run strafe":
                    float.TryParse(str2, out data.slowestRunStrafe);
                    break;

                case "fastest run strafe":
                    float.TryParse(str2, out data.fastestRunStrafe);
                    break;

                case "rotate speed":
                    float.TryParse(str2, out data.rotateSpeed);
                    break;

                case "run rotate speed":
                    float.TryParse(str2, out data.runRotateSpeed);
                    break;

                case "jump to fall time":
                    float.TryParse(str2, out data.jumpToFallTime);
                    break;

                case "jump to terminal fall time":
                    float.TryParse(str2, out data.jumpToSuperFallTime);
                    break;

                case "jump impulse":
                    float.TryParse(str2, out data.jumpImpulse);
                    break;

                case "jump gravity":
                    float.TryParse(str2, out data.jumpGravity);
                    break;

                case "normal gravity":
                    float.TryParse(str2, out data.normalGravity);
                    break;

                case "terminal velocity":
                    float.TryParse(str2, out data.terminalVelocity);
                    break;

                case "jump land transition":
                    float.TryParse(str2, out data.jumpToLandTransition);
                    break;

                case "max walk slope":
                    int.TryParse(str2, out data.slopeLimit);
                    break;

                case "downhill slide speed":
                    float.TryParse(str2, out data.slideSpeed);
                    break;

                default:
                    DataClass.OutputErrorMessage("A", index, "Unknown entry: " + output);
                    break;
            }
            obj = data;
        }
    }

    public override List<DataClass> ParseSheet()
    {
        List<DataClass> list = new List<DataClass>();
        DataClass class2 = null;
        for (int i = 4; i <= DataClass.data.GetLength(0); i++)
        {
            this.ParseRecord(ref class2, i);
        }
        if (class2 != null)
        {
            MovementData data = (MovementData) class2;
            data.minForwardSpeed = data.walkAnimSpeed * data.slowestWalk;
            data.maxForwardSpeed = data.runAnimSpeed * data.fastestRun;
            data.minBackwardSpeed = data.walkBackAnimSpeed * data.slowestWalkBack;
            data.maxBackwardSpeed = data.walkBackAnimSpeed * data.fastestWalkBack;
            data.minStrafeSpeed = data.walkStrafeAnimSpeed * data.slowestWalkStrafe;
            data.maxStrafeSpeed = data.runStrafeAnimSpeed * data.slowestRunStrafe;
            list.Add(class2);
        }
        return list;
    }

    public static MovementData singleton
    {
        [CompilerGenerated]
        get
        {
            return <singleton>k__BackingField;
        }
        [CompilerGenerated]
        protected set
        {
            <singleton>k__BackingField = value;
        }
    }
}

