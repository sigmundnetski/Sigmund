﻿using System;
using System.Runtime.InteropServices;
using UnityEngine;

public class NguiColorFormatter
{
    private const string NGUI_FORMAT = "[{0}{1}{2}]";
    private const float USERNAME_MULT = 0.8f;

    public static string ToHexString(float colorChannel, StringType colorAdjustment)
    {
        float num = (colorAdjustment == StringType.USERNAME) ? 0.8f : 1f;
        int num2 = (int) ((colorChannel * 255f) * num);
        return num2.ToString("X2");
    }

    public static string ToNguiString(Color color_, StringType colorAdjustment = 0)
    {
        return string.Format("[{0}{1}{2}]", ToHexString(color_.r, colorAdjustment), ToHexString(color_.g, colorAdjustment), ToHexString(color_.b, colorAdjustment));
    }

    public enum StringType : byte
    {
        DEFAULT = 0,
        USERNAME = 1
    }
}

