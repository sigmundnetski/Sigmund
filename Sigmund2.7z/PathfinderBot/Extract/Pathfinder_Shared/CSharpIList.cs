﻿using System;
using System.Collections.Generic;

public class CSharpIList : UUnitTestCase
{
    private IList<object> testArray;
    private IList<object> testList;
    private object testThing;

    private void InterfaceHelper(IList<object> things)
    {
        if (!things.IsReadOnly)
        {
            things.Add(this.testThing);
            things.Remove(this.testThing);
            things.Add(this.testThing);
            things.Clear();
            things.Insert(0, this.testThing);
            things.RemoveAt(0);
            things.Add(null);
        }
        things[0] = this.testThing;
        things.IndexOf(this.testThing);
        things[0] = null;
        int count = things.Count;
    }

    protected override void SetUp()
    {
        this.testThing = new object();
        this.testArray = new object[4];
        this.testList = new List<object>(1);
    }

    [UUnitProfileMethod]
    private void TestArray()
    {
        this.InterfaceHelper(this.testArray);
    }

    [UUnitProfileMethod]
    private void TestList()
    {
        this.InterfaceHelper(this.testList);
    }
}

