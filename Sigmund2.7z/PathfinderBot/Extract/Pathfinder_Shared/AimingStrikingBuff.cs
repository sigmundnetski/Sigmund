﻿using System;

public class AimingStrikingBuff : CombatTimedBuff
{
    private static int[] ATTACK_BONUS = new int[] { 15, 30 };

    public AimingStrikingBuff() : base("AimingStriking", Combat.Channel.Extraordinary, Combat.EffectType.Beneficial)
    {
    }

    public static AimingStrikingBuff Create()
    {
        return new AimingStrikingBuff();
    }

    public override CombatBuffVars Initialize(uint combatTick, CombatModifier mod, CombatVars target, int additionalDefense)
    {
        CombatBuffVars vars = base.Initialize(combatTick, mod, target, additionalDefense);
        if (mod.buff == CombatConstants.Buff.AIMING)
        {
            vars.basicName = "Aiming";
            vars.name = "Aiming";
            vars.value0 = 0;
            return vars;
        }
        if (mod.buff == CombatConstants.Buff.STRIKING)
        {
            vars.basicName = "Striking";
            vars.name = "Striking";
            vars.value0 = 1;
        }
        return vars;
    }

    public override void RecalculationPhase(CombatBuffVars buff, uint combatTick)
    {
        int specific = buff.owner.tempAttackBonuses.Channel(base.channel).GetSpecific(AttackType.Ranged);
        if (ATTACK_BONUS[buff.value0] > specific)
        {
            buff.owner.tempAttackBonuses.Channel(base.channel).SetSpecific(AttackType.Ranged, ATTACK_BONUS[buff.value0]);
        }
        int num2 = buff.owner.tempAttackBonuses.Channel(base.channel).GetSpecific(AttackType.Arcane);
        if (ATTACK_BONUS[buff.value0] > num2)
        {
            buff.owner.tempAttackBonuses.Channel(base.channel).SetSpecific(AttackType.Arcane, ATTACK_BONUS[buff.value0]);
        }
        int num3 = buff.owner.tempAttackBonuses.Channel(base.channel).GetSpecific(AttackType.Divine);
        if (ATTACK_BONUS[buff.value0] > num3)
        {
            buff.owner.tempAttackBonuses.Channel(base.channel).SetSpecific(AttackType.Divine, ATTACK_BONUS[buff.value0]);
        }
    }

    public override void TimePhase(CombatBuffVars buff, uint combatTick)
    {
        if ((combatTick > (buff.updatedTick + 1)) && (((buff.owner.prevAttackInfo.attackType == AttackType.Ranged) || (buff.owner.prevAttackInfo.attackType == AttackType.Divine)) || (buff.owner.prevAttackInfo.attackType == AttackType.Arcane)))
        {
            buff.expirationTick = combatTick;
        }
    }

    private enum Index
    {
        AIMING,
        STRIKING,
        NUM_BUFFS
    }
}

