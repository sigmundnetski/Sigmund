﻿using System;
using System.Collections.Generic;
using System.Net;

public class GServerRouteInfo : IDataCopyable<GServerRouteInfo>
{
    public IPAddress clientIpAddr;
    public int clientIpPort;
    public uint[] connectedClients = new uint[10];
    public uint serverId;
    public IPAddress serverIpAddr;
    public int serverIpPort;
    public GRoute.RouteType serverType;

    public HashSet<GRoute> allRoutes()
    {
        HashSet<GRoute> set = new HashSet<GRoute> {
            new GRoute(this.serverType, this.serverId)
        };
        foreach (uint num in this.connectedClients)
        {
            if (num > 0)
            {
                set.Add(new GRoute(GRoute.RouteType.PLAYER, num));
            }
        }
        return set;
    }

    public uint connectedClientCount()
    {
        uint num = 0;
        foreach (uint num2 in this.connectedClients)
        {
            if (num2 > 0)
            {
                num++;
            }
        }
        return num;
    }

    public void DataCopyTo(ref GServerRouteInfo target, byte syncTargetLevel)
    {
        target.serverType = this.serverType;
        target.serverId = this.serverId;
        target.connectedClients = new uint[this.connectedClients.Length];
        this.connectedClients.CopyTo(target.connectedClients, 0);
        target.serverIpAddr = this.serverIpAddr;
        target.serverIpPort = this.serverIpPort;
        target.clientIpAddr = this.clientIpAddr;
        target.clientIpPort = this.clientIpPort;
    }

    public bool DataEquals(GServerRouteInfo target, byte syncTargetLevel)
    {
        if (target == null)
        {
            return false;
        }
        if (target.connectedClients.Length != this.connectedClients.Length)
        {
            return false;
        }
        for (int i = 0; i < this.connectedClients.Length; i++)
        {
            if (target.connectedClients[i] != this.connectedClients[i])
            {
                return false;
            }
        }
        return (((((target.serverType == this.serverType) && (target.serverId == this.serverId)) && (target.serverIpAddr.Equals(this.serverIpAddr) && (target.serverIpPort == this.serverIpPort))) && target.clientIpAddr.Equals(this.clientIpAddr)) && (target.clientIpPort == this.clientIpPort));
    }
}

