﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

[LooseDependency(typeof(FeatAdvancementData))]
public class TrainerData2 : DataClass
{
    private const string BUILDING_LEVEL_MARK = "building level";
    private const string COMMENT_ROW = "ignorerow";
    private const string FEAT_START = "feats";
    public static List<TrainerData2> groups = new List<TrainerData2>();
    private TrainerLevel[] levels;
    private const string LOGICAL_LEVEL_MARK = "logical level";
    private const string MEMBER_START = "member";
    private TrainerMember[] members;
    private static List<TrainerLevel> returnCacheCTL = new List<TrainerLevel>();
    private const string TRAINER_START = "trainer";
    public static Dictionary<int, TrainerData2> trainersById = new Dictionary<int, TrainerData2>();
    public static Dictionary<string, TrainerData2> trainersByName = new Dictionary<string, TrainerData2>();
    public Type type;

    public static void AppendUnittestLevels(ref TrainerData2 trainerData, int[] featAdvIds, byte[] levels)
    {
        TrainerLevel newItem = new TrainerLevel {
            buildingLevel = (byte) (trainerData.levels.Length + 1),
            featAdvancementIds = featAdvIds,
            featLevels = levels
        };
        SparseArray.InefficientAppendToArray<TrainerLevel>(ref trainerData.levels, newItem);
    }

    public bool CanTrain(byte trainerLevel, int featAdvId, byte featLevel)
    {
        List<TrainerLevel> list = this.CompleteTrainerLevels(trainerLevel);
        foreach (TrainerLevel level in list)
        {
            for (int i = 0; i < level.featAdvancementIds.Length; i++)
            {
                if (level.featAdvancementIds[i] == featAdvId)
                {
                    return (level.featLevels[i] >= featLevel);
                }
            }
        }
        return false;
    }

    public List<TrainerLevel> CompleteTrainerLevels(byte buildingLevel)
    {
        returnCacheCTL.Clear();
        TrainerLevel item = this.GetLevel(buildingLevel, false);
        if (item == null)
        {
            return null;
        }
        byte logicalLevel = item.logicalLevel;
        returnCacheCTL.Add(item);
        foreach (TrainerData2 data in groups)
        {
            for (int i = 0; i < data.members.Length; i++)
            {
                if (data.members[i].memberId == base.id)
                {
                    byte level = (byte) Math.Floor((double) (logicalLevel * data.members[i].levelMult));
                    TrainerLevel level2 = data.GetLevel(level, true);
                    if (level2 != null)
                    {
                        returnCacheCTL.Add(level2);
                    }
                    break;
                }
            }
        }
        return returnCacheCTL;
    }

    public TrainerLevel GetLevel(byte level, bool logicalLevel = true)
    {
        for (int i = this.levels.Length - 1; i >= 0; i--)
        {
            byte num2 = logicalLevel ? this.levels[i].logicalLevel : this.levels[i].buildingLevel;
            if (num2 <= level)
            {
                return this.levels[i];
            }
        }
        return null;
    }

    public static byte GetSupportLevel(int settlementDataId, byte trainerLevel, int featAdvId)
    {
        byte num = 1;
        SettlementData byId = SettlementData.GetById(settlementDataId);
        foreach (int num2 in byId.supportTrainerIds)
        {
            TrainerData2 data2;
            if (trainersById.TryGetValue(num2, out data2) && (data2.type == Type.Basic))
            {
                foreach (TrainerLevel level in data2.CompleteTrainerLevels(trainerLevel))
                {
                    if (level.buildingLevel <= trainerLevel)
                    {
                        for (int i = 0; i < level.featAdvancementIds.Length; i++)
                        {
                            if (level.featAdvancementIds[i] == featAdvId)
                            {
                                num = Math.Max(num, level.featLevels[i]);
                            }
                        }
                    }
                }
            }
        }
        return num;
    }

    public static TrainerData2 GetTrainer(int id)
    {
        TrainerData2 data;
        if (trainersById.TryGetValue(id, out data))
        {
            return data;
        }
        return null;
    }

    public static TrainerData2 GetTrainer(string name)
    {
        TrainerData2 data;
        if (trainersByName.TryGetValue(name.ToLower(), out data))
        {
            return data;
        }
        return null;
    }

    private void LoadInit()
    {
        if (this.type == Type.Group)
        {
            for (int i = 0; i < this.members.Length; i++)
            {
                TrainerData2 trainer = GetTrainer(this.members[i].name);
                if (trainer != null)
                {
                    this.members[i].memberId = trainer.id;
                }
                else
                {
                    GLog.LogError(new object[] { "Invalid group trainer member name: ", this.members[i].name });
                }
            }
        }
    }

    public static TrainerData2 NewUnittestTrainer(string name)
    {
        TrainerData2 data;
        data = new TrainerData2 {
            name = name.ToLower(),
            id = DataClass.GenerateId(data.name),
            levels = new TrainerLevel[0]
        };
        trainersById[data.id] = data;
        trainersByName[data.name] = data;
        return data;
    }

    public static void OnLoad(List<DataClass> objects)
    {
        foreach (TrainerData2 data in objects)
        {
            trainersById[data.id] = data;
            trainersByName[data.name] = data;
            if (data.type == Type.Group)
            {
                groups.Add(data);
            }
        }
        foreach (TrainerData2 data in objects)
        {
            data.LoadInit();
        }
    }

    private bool ParseFeat(string feat, TrainerLevel level)
    {
        byte num;
        FeatAdvancementData data;
        string[] strArray = feat.Split(new char[] { '=' });
        if ((((strArray.Length == 2) && FeatAdvancementData.dataBySlotName.TryGetValue(strArray[0].Trim(), out data)) && byte.TryParse(strArray[1].Trim(), out num)) && (data.GetDetailsForLevel(num) != null))
        {
            SparseArray.Add<int>(ref level.featAdvancementIds, data.id, SparseArray.INT_ZERO, 0);
            SparseArray.Add<byte>(ref level.featLevels, num, SparseArray.BYTE_ZERO, 0);
            return true;
        }
        return false;
    }

    private bool ParseFeatLine(int row, TrainerData2 trainer)
    {
        if (trainer.levels == null)
        {
            trainer.levels = new TrainerLevel[] { new TrainerLevel() };
            trainer.levels[0].logicalLevel = 1;
            trainer.levels[0].buildingLevel = 1;
            trainer.levels[0].featAdvancementIds = new int[10];
            trainer.levels[0].featLevels = new byte[10];
        }
        for (int i = 0; i < trainer.levels.Length; i++)
        {
            string str;
            if (DataClass.GetLCaseCellValue((int) (2 + i), row, out str) && !this.ParseFeat(str, trainer.levels[i]))
            {
                DataClass.OutputErrorMessage((int) (2 + i), row, "Couldn't understand feat: " + str);
                return false;
            }
        }
        return true;
    }

    private bool ParseLevelLine(int row, TrainerData2 trainer, bool buildingLevel)
    {
        int num4;
        int num = 0;
        List<byte> list = new List<byte>();
        for (int i = 2; i <= DataClass.MAX_COL; i++)
        {
            byte num3;
            if (!DataClass.TryGetCellValue(i, row, out num3))
            {
                break;
            }
            if (num3 <= num)
            {
                DataClass.OutputErrorMessage(i, row, "Levels must always be increasing");
                return false;
            }
            num = num3;
            list.Add(num3);
        }
        if (list.Count == 0)
        {
            DataClass.OutputErrorMessage(2, row, "No levels listed after levels keyword");
            return false;
        }
        if ((trainer.levels != null) && (trainer.levels.Length != list.Count))
        {
            DataClass.OutputErrorMessage(2, row, "Levels listed on this line disagree with other line");
            return false;
        }
        if ((trainer.levels != null) && (trainer.levels.Length == list.Count))
        {
            for (num4 = 0; num4 < list.Count; num4++)
            {
                if (buildingLevel)
                {
                    trainer.levels[num4].buildingLevel = list[num4];
                }
                else
                {
                    trainer.levels[num4].logicalLevel = list[num4];
                }
            }
        }
        else
        {
            trainer.levels = new TrainerLevel[list.Count];
            for (num4 = 0; num4 < list.Count; num4++)
            {
                trainer.levels[num4] = new TrainerLevel();
                trainer.levels[num4].featAdvancementIds = new int[10];
                trainer.levels[num4].featLevels = new byte[10];
                if (buildingLevel)
                {
                    trainer.levels[num4].buildingLevel = list[num4];
                }
                else
                {
                    trainer.levels[num4].logicalLevel = list[num4];
                }
            }
        }
        return true;
    }

    private bool ParseMemberLine(int row, TrainerData2 trainer)
    {
        bool flag = true;
        TrainerMember member = new TrainerMember();
        if (!DataClass.TryGetLCaseCellValue(2, row, out member.name))
        {
            DataClass.OutputErrorMessage(2, row, "No member name given");
            flag = false;
        }
        if (!DataClass.TryGetCellValue(3, row, out member.levelMult))
        {
            DataClass.OutputErrorMessage(3, row, "Invalid level multiplier");
            flag = false;
        }
        row++;
        SparseArray.Add<TrainerMember>(ref trainer.members, member);
        return flag;
    }

    public override List<DataClass> ParseSheet()
    {
        string str;
        List<DataClass> list = new List<DataClass>();
        int row = 0;
        row = 2;
        while (row <= DataClass.MAX_ROW)
        {
            if (DataClass.TryGetLCaseCellValue(1, row, out str))
            {
                if (str.Equals("trainer"))
                {
                    break;
                }
                DataClass.OutputErrorMessage(1, row, "unrecognized row marker: " + str);
            }
            row++;
        }
        if (row > DataClass.MAX_ROW)
        {
            DataClass.OutputErrorMessage("No trainers defined in sheet");
            return null;
        }
        while (row <= DataClass.MAX_ROW)
        {
            bool flag = false;
            TrainerData2 trainer = new TrainerData2();
            if (DataClass.TryGetLCaseCellValue(2, row, out trainer.name))
            {
                trainer.id = DataClass.GenerateId(trainer.name);
            }
            else
            {
                DataClass.OutputErrorMessage(2, row, "No trainer name given");
                flag = true;
            }
            if (!DataClass.TryGetEnumCellValue<Type>(3, row, Type.Basic, out trainer.type))
            {
                DataClass.OutputErrorMessage(3, row, "Invalid trainer type");
                flag = true;
            }
            row++;
            if (trainer.type == Type.Group)
            {
                trainer.members = new TrainerMember[10];
                DataClass.GetLCaseCellValue(1, row, out str);
                if (!str.Equals("member"))
                {
                    DataClass.OutputErrorMessage(1, row, "Group contacts required to have member section at top");
                    flag = true;
                }
                else
                {
                    while (row <= DataClass.MAX_ROW)
                    {
                        DataClass.GetLCaseCellValue(1, row, out str);
                        if (!str.Equals("member") && !string.IsNullOrEmpty(str))
                        {
                            break;
                        }
                        if (!this.ParseMemberLine(row, trainer))
                        {
                            flag = true;
                        }
                        row++;
                    }
                }
            }
            while (row <= DataClass.MAX_ROW)
            {
                DataClass.GetLCaseCellValue(1, row, out str);
                if (str.Equals("logical level"))
                {
                    if (!this.ParseLevelLine(row, trainer, false))
                    {
                        flag = true;
                    }
                }
                else if (str.Equals("building level"))
                {
                    if (!this.ParseLevelLine(row, trainer, true))
                    {
                        flag = true;
                    }
                }
                else
                {
                    if (str.Equals("trainer"))
                    {
                        flag = true;
                        break;
                    }
                    if (str.Equals("feats"))
                    {
                        break;
                    }
                    DataClass.OutputErrorMessage(1, row, "Invalid header marker");
                    flag = true;
                }
                row++;
            }
            if (row > DataClass.MAX_ROW)
            {
                DataClass.OutputErrorMessage("No feats defined for final trainer");
                flag = true;
            }
            while (row <= DataClass.MAX_ROW)
            {
                DataClass.GetLCaseCellValue(1, row, out str);
                if (str.Equals("feats") || string.IsNullOrEmpty(str))
                {
                    if (!flag)
                    {
                        this.ParseFeatLine(row, trainer);
                    }
                }
                else if (!str.Equals("ignorerow"))
                {
                    if (str.Equals("trainer"))
                    {
                        break;
                    }
                    DataClass.OutputErrorMessage(1, row, "Invalid row marker: " + str);
                    flag = true;
                }
                row++;
            }
            if (!flag)
            {
                this.TrimFeats(trainer);
                this.TrimMembers(trainer);
                list.Add(trainer);
            }
        }
        return list;
    }

    private void TrimFeats(TrainerData2 trainer)
    {
        for (int i = 0; i < trainer.levels.Length; i++)
        {
            int newSize = SparseArray.Count<int>(trainer.levels[i].featAdvancementIds, SparseArray.INT_ZERO);
            Array.Resize<int>(ref trainer.levels[i].featAdvancementIds, newSize);
            Array.Resize<byte>(ref trainer.levels[i].featLevels, newSize);
        }
    }

    private void TrimMembers(TrainerData2 trainer)
    {
        if (trainer.members != null)
        {
            int newSize = SparseArray.Count<TrainerMember>(trainer.members);
            Array.Resize<TrainerMember>(ref trainer.members, newSize);
        }
    }

    public static void UnittestClear()
    {
        trainersById.Clear();
        trainersByName.Clear();
        groups.Clear();
    }

    public enum Type : byte
    {
        Basic = 0,
        Group = 1,
        NoSupport = 2
    }
}

