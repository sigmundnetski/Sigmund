﻿using System;
using System.Collections.Generic;
using System.IO;

public class DataPackage : Package
{
    protected List<SourceFileData> sourceFiles;
    private const string versionNumber = "0006";
    private const string versionType = "PKG.";

    public DataPackage(string file) : base(file, "PKG.", "0006")
    {
        this.sourceFiles = new List<SourceFileData>();
        base.tableOfContents = new DataTableOfContents();
    }

    public DataPackage(FileStream fileStream, System.Type type) : base(fileStream, type, "PKG.", "0006")
    {
        this.sourceFiles = new List<SourceFileData>();
        base.tableOfContents = new DataTableOfContents();
    }

    public DataPackage(string file, System.Type type) : base(file, type, "PKG.", "0006")
    {
        this.sourceFiles = new List<SourceFileData>();
        base.tableOfContents = new DataTableOfContents();
    }

    public override void AddSourceFile(string sourceFile, string crc, string sheetName)
    {
        SourceFileData item = new SourceFileData(sourceFile, crc, sheetName);
        if (!this.sourceFiles.Contains(item))
        {
            this.sourceFiles.Add(item);
        }
        ((DataTableOfContents) base.tableOfContents).sourceFiles = this.sourceFiles.ToArray();
    }

    public override IEnumerable<SourceFileData> GetSourceFiles()
    {
        return this.sourceFiles;
    }
}

