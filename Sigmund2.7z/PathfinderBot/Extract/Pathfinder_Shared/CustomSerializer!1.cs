﻿using GNetwork;
using System;

public interface CustomSerializer<T>
{
    void Read(IBitBufferRead buffer, ref T prev);
    void Write(IBitBufferWrite buffer, T prev);
}

