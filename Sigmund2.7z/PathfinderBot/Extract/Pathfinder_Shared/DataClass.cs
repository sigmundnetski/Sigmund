﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using UnityEngine;

public class DataClass
{
    protected static Dictionary<string, int> columnNamesToIndex;
    protected static object[,] data;
    protected static string filename;
    protected const int FIRST_ROW = 4;
    public static GetDataCallback GetData;
    protected const int HEADER_ROW = 3;
    public int id;
    public const int INVALID_ID = 0;
    private const string LOGICAL_CELL_REFERENCE = "B1";
    public string name;
    protected static string sheetname;
    private const string TYPE_CELL_REFERENCE = "A1";

    public DataClass()
    {
        this.id = 0;
        this.name = string.Empty;
    }

    public DataClass(string iName)
    {
        this.name = iName.ToLower();
        this.id = GenerateId(this.name);
    }

    protected static int ConvertColumnToIndex(string columnString)
    {
        char[] array = columnString.ToUpper().ToCharArray();
        Array.Reverse(array);
        int num = 0;
        for (int i = 0; i < array.Length; i++)
        {
            num += ((int) Math.Pow(26.0, (double) i)) * (array[i] - '@');
        }
        return num;
    }

    protected static string ConvertIndexToColumn(int index)
    {
        string str = string.Empty;
        while (index > 0)
        {
            int num = (index - 1) % 0x1a;
            str = str + ((char) (num + 0x41));
            index = (index - num) / 0x1a;
        }
        char[] array = str.ToUpper().ToCharArray();
        Array.Reverse(array);
        return new string(array);
    }

    public bool Equals(DataClass other)
    {
        if (object.ReferenceEquals(this, other))
        {
            return true;
        }
        if (object.ReferenceEquals(other, null))
        {
            return false;
        }
        bool flag = true;
        return ((flag && (this.id == other.id)) && (this.name == other.name));
    }

    public override bool Equals(object obj)
    {
        if (object.ReferenceEquals(this, obj))
        {
            return true;
        }
        if (object.ReferenceEquals(obj, null))
        {
            return false;
        }
        return this.Equals(obj as DataClass);
    }

    private static bool GenerateColumnIndices(IEnumerable<string> mandatoryColumns)
    {
        HashSet<string> items = new HashSet<string>();
        columnNamesToIndex = new Dictionary<string, int>();
        for (int i = 1; i <= MAX_COL; i++)
        {
            string str;
            if (TryGetLCaseCellValue(i, 3, out str))
            {
                str = str.Trim();
                if (!string.IsNullOrEmpty(str))
                {
                    if (columnNamesToIndex.ContainsKey(str))
                    {
                        items.Add(str);
                    }
                    else
                    {
                        columnNamesToIndex[str] = i;
                    }
                }
            }
        }
        bool flag = true;
        if (mandatoryColumns == null)
        {
            return flag;
        }
        IOrderedEnumerable<string> source = from eachName in mandatoryColumns
            where !columnNamesToIndex.ContainsKey(eachName)
            orderby eachName
            select eachName;
        if (source.Count<string>() != 0)
        {
            OutputErrorMessage("All mandatory columns must be defined.  Missing: " + GUtil.PrettyPrint(source, ", ", ""));
        }
        if (items.Count != 0)
        {
            OutputErrorMessage("Cannot define duplicate names.  Duplicates: " + GUtil.PrettyPrint(items, ", ", ""));
        }
        return ((source.Count<string>() == 0) && (items.Count == 0));
    }

    public static string GenerateDisplayName(params object[] args)
    {
        return GenerateName(args);
    }

    public static unsafe int GenerateId(string _name)
    {
        _name = _name.ToLower();
        fixed (char* str = ((char*) _name))
        {
            char* chPtr = str;
            int num = 0x15051505;
            int num2 = num;
            int* numPtr = (int*) chPtr;
            int length = _name.Length;
            while (length > 2)
            {
                num = (((num << 5) + num) + (num >> 0x1b)) ^ numPtr[0];
                num2 = (((num2 << 5) + num2) + (num2 >> 0x1b)) ^ numPtr[1];
                numPtr += 2;
                length -= 4;
            }
            if (length > 0)
            {
                num = (((num << 5) + num) + (num >> 0x1b)) ^ numPtr[0];
            }
            return (num + (num2 * 0x5d588b65));
        }
    }

    private static string GenerateName(params object[] args)
    {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < args.Length; i++)
        {
            if (i != 0)
            {
                builder.Append(" ");
            }
            builder.Append(args[i].ToString());
        }
        return builder.ToString();
    }

    public static string GenerateNameLower(params object[] args)
    {
        return GenerateName(args).ToLower();
    }

    protected static bool GetAsForeignName<DT>(int column, int row, out string foreignName) where DT: DataClass
    {
        bool flag = TryGetAsForeignName<DT>(column, row, out foreignName);
        if (!flag)
        {
            OutputErrorMessage(column, row, "Cannot be converted into foreign key for:" + typeof(DT));
        }
        return flag;
    }

    protected static bool GetAsForeignName<DT>(string columnString, int row, out string foreignName) where DT: DataClass
    {
        return GetAsForeignName<DT>(ConvertColumnToIndex(columnString), row, out foreignName);
    }

    private static string GetCellValue(int column, int row)
    {
        object obj2 = null;
        if (((data != null) && (data.GetLength(0) >= row)) && (data.GetLength(1) >= column))
        {
            obj2 = data[row, column];
        }
        string str = (obj2 == null) ? string.Empty : obj2.ToString();
        return str.Replace('\x00a0', ' ');
    }

    private static void GetCellValue(string addressName, out string output)
    {
        string columnString = string.Empty;
        string rowString = string.Empty;
        SplitCellReference(addressName, out columnString, out rowString);
        int column = ConvertColumnToIndex(columnString);
        int row = int.Parse(rowString);
        output = GetCellValue(column, row);
    }

    protected static bool GetCellValue(int column, int row, out bool output)
    {
        bool flag = TryGetCellValue(column, row, out output);
        if (!flag)
        {
            OutputErrorMessage(column, row, ((bool) output).GetType());
        }
        return flag;
    }

    protected static bool GetCellValue(int column, int row, out byte output)
    {
        bool flag = TryGetCellValue(column, row, out output);
        if (!flag)
        {
            OutputErrorMessage(column, row, ((byte) output).GetType());
        }
        return flag;
    }

    protected static bool GetCellValue(int column, int row, out double output)
    {
        bool flag = TryGetCellValue(column, row, out output);
        if (!flag)
        {
            OutputErrorMessage(column, row, ((double) output).GetType());
        }
        return flag;
    }

    protected static bool GetCellValue(int column, int row, out short output)
    {
        bool flag = TryGetCellValue(column, row, out output);
        if (!flag)
        {
            OutputErrorMessage(column, row, ((short) output).GetType());
        }
        return flag;
    }

    protected static bool GetCellValue(int column, int row, out int output)
    {
        bool flag = TryGetCellValue(column, row, out output);
        if (!flag)
        {
            OutputErrorMessage(column, row, ((int) output).GetType());
        }
        return flag;
    }

    protected static bool GetCellValue(int column, int row, out float output)
    {
        bool flag = TryGetCellValue(column, row, out output);
        if (!flag)
        {
            OutputErrorMessage(column, row, ((float) output).GetType());
        }
        return flag;
    }

    protected static bool GetCellValue(int column, int row, out string output)
    {
        return TryGetCellValue(column, row, out output);
    }

    protected static bool GetCellValue(int column, int row, out ushort output)
    {
        bool flag = TryGetCellValue(column, row, out output);
        if (!flag)
        {
            OutputErrorMessage(column, row, ((ushort) output).GetType());
        }
        return flag;
    }

    protected static bool GetCellValue(int column, int row, out uint output)
    {
        bool flag = TryGetCellValue(column, row, out output);
        if (!flag)
        {
            OutputErrorMessage(column, row, ((uint) output).GetType());
        }
        return flag;
    }

    protected static bool GetCellValue(int column, int row, out Color output)
    {
        bool flag = TryGetCellValue(column, row, out output);
        if (!flag)
        {
            OutputErrorMessage(column, row, ((Color) output).GetType());
        }
        return flag;
    }

    protected static bool GetCellValue(int column, int row, out Vector3 output)
    {
        bool flag = TryGetCellValue(column, row, out output);
        if (!flag)
        {
            OutputErrorMessage(column, row, ((Vector3) output).GetType());
        }
        return flag;
    }

    protected static bool GetCellValue(string columnString, int row, out bool output)
    {
        return GetCellValue(ConvertColumnToIndex(columnString), row, out output);
    }

    protected static bool GetCellValue(string columnString, int row, out byte output)
    {
        return GetCellValue(ConvertColumnToIndex(columnString), row, out output);
    }

    protected static bool GetCellValue(string columnString, int row, out double output)
    {
        return GetCellValue(ConvertColumnToIndex(columnString), row, out output);
    }

    protected static bool GetCellValue(string columnString, int row, out short output)
    {
        return GetCellValue(ConvertColumnToIndex(columnString), row, out output);
    }

    protected static bool GetCellValue(string columnString, int row, out int output)
    {
        return GetCellValue(ConvertColumnToIndex(columnString), row, out output);
    }

    protected static bool GetCellValue(string columnString, int row, out float output)
    {
        return GetCellValue(ConvertColumnToIndex(columnString), row, out output);
    }

    protected static bool GetCellValue(string columnString, int row, out string output)
    {
        return TryGetCellValue(ConvertColumnToIndex(columnString), row, out output);
    }

    protected static bool GetCellValue(string columnString, int row, out ushort output)
    {
        return GetCellValue(ConvertColumnToIndex(columnString), row, out output);
    }

    protected static bool GetCellValue(string columnString, int row, out uint output)
    {
        return GetCellValue(ConvertColumnToIndex(columnString), row, out output);
    }

    protected static bool GetCellValue(string columnString, int row, out Color output)
    {
        return GetCellValue(ConvertColumnToIndex(columnString), row, out output);
    }

    protected static bool GetCellValue(string columnString, int row, out Vector3 output)
    {
        return GetCellValue(ConvertColumnToIndex(columnString), row, out output);
    }

    protected static bool GetEnumCellValue<ET>(int column, int row, out ET[] output) where ET: struct, IConvertible
    {
        bool flag = TryGetEnumCellValue<ET>(column, row, out output);
        if (!flag)
        {
            OutputErrorMessage(column, row, typeof(ET));
        }
        return flag;
    }

    protected static bool GetEnumCellValue<ET>(string columnString, int row, out ET[] output) where ET: struct, IConvertible
    {
        return GetEnumCellValue<ET>(ConvertColumnToIndex(columnString), row, out output);
    }

    protected static bool GetEnumCellValue<ET>(int column, int row, ET defaultValue, out ET output) where ET: struct, IConvertible
    {
        bool flag = TryGetEnumCellValue<ET>(column, row, defaultValue, out output);
        if (!flag)
        {
            OutputErrorMessage(column, row, typeof(ET));
        }
        return flag;
    }

    protected static bool GetEnumCellValue<ET>(string columnString, int row, ET defaultValue, out ET output) where ET: struct, IConvertible
    {
        return GetEnumCellValue<ET>(ConvertColumnToIndex(columnString), row, defaultValue, out output);
    }

    public override int GetHashCode()
    {
        return base.GetHashCode();
    }

    protected static bool GetIdFromForeignName<DT>(int column, int row, out int foreignId) where DT: DataClass
    {
        bool flag = TryGetIdFromForeignName<DT>(column, row, out foreignId);
        if (!flag)
        {
            OutputErrorMessage(column, row, string.Concat(new object[] { "\"", GetCellValue(column, row), "\" cannot be converted into foreign key for: ", typeof(DT) }));
        }
        return flag;
    }

    protected static bool GetIdFromForeignName<DT>(string columnString, int row, out int foreignId) where DT: DataClass
    {
        return GetIdFromForeignName<DT>(ConvertColumnToIndex(columnString), row, out foreignId);
    }

    protected static bool GetIdsFromForeignNames<DT>(int column, int row, out int[] foreignIds) where DT: DataClass
    {
        IEnumerable<DataClass> source = GetData(typeof(DT));
        if (source.Count<DataClass>() == 0)
        {
            GLog.LogError(new object[] { typeof(DT).Name, "has no data to match foreign keys.  (Did a programmer forget a Dependency-Attribute?)" });
        }
        Dictionary<string, int> dictionary = new Dictionary<string, int>();
        foreach (DT local in source)
        {
            dictionary[local.name] = local.id;
        }
        List<string> items = new List<string>();
        List<int> list2 = new List<int>();
        string[] strArray = GetCellValue(column, row).ToLower().Split(new char[] { ',' });
        for (int i = 0; i < strArray.Length; i++)
        {
            int num;
            if (dictionary.TryGetValue(strArray[i].Trim(), out num))
            {
                list2.Add(num);
            }
            else
            {
                items.Add(strArray[i].Trim());
            }
        }
        foreignIds = list2.ToArray();
        if (items.Count > 0)
        {
            OutputErrorMessage(column, row, "These could not be parsed into keys for type " + typeof(DT).Name + ":" + GUtil.PrettyPrint(items, ", ", "[]"));
        }
        return (items.Count == 0);
    }

    protected static bool GetIdsFromForeignNames<DT>(string columnString, int row, out int[] foreignIds) where DT: DataClass
    {
        return GetIdsFromForeignNames<DT>(ConvertColumnToIndex(columnString), row, out foreignIds);
    }

    protected static bool GetLCaseCellValue(int column, int row, out string output)
    {
        return TryGetLCaseCellValue(column, row, out output);
    }

    protected static bool GetLCaseCellValue(string columnString, int row, out string output)
    {
        return TryGetLCaseCellValue(ConvertColumnToIndex(columnString), row, out output);
    }

    protected static void GetLCaseLogicalCellValue(out string output)
    {
        GetCellValue("B1", out output);
        output = output.ToLower();
    }

    public static void GetSheetType(object[,] input, out string type, out string logical)
    {
        data = input;
        GetCellValue("A1", out type);
        GetCellValue("B1", out logical);
    }

    protected static bool GetTimeValue(int numCol, int numRow, int unitCol, int unitRow, out float output)
    {
        bool flag = TryGetTimeValue(numCol, numRow, unitCol, unitRow, out output);
        if (!flag)
        {
            OutputErrorMessage(numCol, numRow, "Cannot parse time value");
            OutputErrorMessage(unitCol, unitRow, "Cannot parse time unit");
        }
        return flag;
    }

    protected static bool GetTimeValue(int numCol, int numRow, int unitCol, int unitRow, out TimeSpan output)
    {
        bool flag = TryGetTimeValue(numCol, numRow, unitCol, unitRow, out output);
        if (!flag)
        {
            OutputErrorMessage(numCol, numRow, "Cannot parse time value");
            OutputErrorMessage(unitCol, unitRow, "Cannot parse time unit");
        }
        return flag;
    }

    protected static bool GetTimeValue(string numColString, int numRow, string unitColString, int unitRow, out float output)
    {
        return GetTimeValue(ConvertColumnToIndex(numColString), numRow, ConvertColumnToIndex(unitColString), unitRow, out output);
    }

    protected static bool GetTimeValue(string numColString, int numRow, string unitColString, int unitRow, out TimeSpan output)
    {
        return GetTimeValue(ConvertColumnToIndex(numColString), numRow, ConvertColumnToIndex(unitColString), unitRow, out output);
    }

    public List<DataClass> InitializeAndParseSheet(string file, string sheet, object[,] input)
    {
        filename = file;
        sheetname = sheet;
        data = input;
        if (!GenerateColumnIndices(this.GetMandatoryColumns))
        {
            return new List<DataClass>();
        }
        return this.ParseSheet();
    }

    public virtual List<DataClass> MergeData()
    {
        throw new NotImplementedException("Contact a programmer.  MergeData must be implemented when NoExcelData attribute is used.");
    }

    public static void OnLoad(List<DataClass> objects)
    {
    }

    public static bool operator ==(DataClass a, DataClass b)
    {
        if (object.ReferenceEquals(a, b))
        {
            return true;
        }
        if (object.ReferenceEquals(a, null) || object.ReferenceEquals(b, null))
        {
            return false;
        }
        return a.Equals(b);
    }

    public static bool operator ==(DataClass a, object b)
    {
        if (object.ReferenceEquals(a, b))
        {
            return true;
        }
        if (object.ReferenceEquals(a, null) || object.ReferenceEquals(b, null))
        {
            return false;
        }
        return a.Equals((DataClass) b);
    }

    public static bool operator !=(DataClass a, DataClass b)
    {
        return !(a == b);
    }

    public static bool operator !=(DataClass a, object b)
    {
        return (a != b);
    }

    protected static void OutputErrorMessage(string message)
    {
        GLog.LogWarning(new object[] { "There was a problem parsing on sheet [" + sheetname + "] in file [" + filename + "]:\n" + message + "\n" });
    }

    protected static void OutputErrorMessage(int column, int row, string message)
    {
        string fileName = Path.GetFileName(filename);
        string str2 = ConvertIndexToColumn(column);
        GLog.LogWarning(new object[] { string.Concat(new object[] { "Parsing error in [", fileName, "|", sheetname, "] in cell [", str2, row, "]:\n", message, "\n" }) });
    }

    protected static void OutputErrorMessage(int column, int row, System.Type type)
    {
        string str = ConvertIndexToColumn(column);
        GLog.LogWarning(new object[] { string.Concat(new object[] { "There was a problem parsing cell [", str, row, "] as a(n) ", type.ToString(), " on sheet [", sheetname, "] in file [", filename, "]" }) });
    }

    protected static void OutputErrorMessage(string column, int row, string message)
    {
        string fileName = Path.GetFileName(filename);
        GLog.LogWarning(new object[] { string.Concat(new object[] { "Parsing error in [", fileName, "|", sheetname, "] in cell [", column, row, "]:\n", message, "\n" }) });
    }

    public virtual DataClass ParseRecord(int index)
    {
        return null;
    }

    public virtual void ParseRecord(ref DataClass obj, int index)
    {
    }

    public virtual List<DataClass> ParseSheet()
    {
        List<DataClass> list = new List<DataClass>();
        for (int i = 4; i <= data.GetLength(0); i++)
        {
            DataClass item = this.ParseRecord(i);
            if (item != null)
            {
                list.Add(item);
            }
        }
        return list;
    }

    protected static void SplitCellReference(string cell, out int colIndex, out int rowIndex)
    {
        string str;
        string str2;
        SplitCellReference(cell, out str, out str2);
        colIndex = ConvertColumnToIndex(str);
        rowIndex = int.Parse(str2);
    }

    protected static void SplitCellReference(string cell, out string columnString, out string rowString)
    {
        columnString = string.Empty;
        rowString = string.Empty;
        cell = cell.ToUpper();
        for (int i = 0; i < cell.Length; i++)
        {
            int num2 = cell[i];
            if ((num2 > 0x40) && (num2 < 0x5b))
            {
                columnString = columnString + ((char) num2);
            }
            else if ((num2 > 0x2f) && (num2 < 0x3a))
            {
                rowString = rowString + ((char) num2);
            }
        }
    }

    public override string ToString()
    {
        return string.Concat(new object[] { base.ToString(), "::", this.id, "_", this.name });
    }

    protected static bool TryGetAsForeignName<DT>(int column, int row, out string foreignName) where DT: DataClass
    {
        string cellValue = GetCellValue(column, row).ToLower();
        IEnumerable<DataClass> source = GetData(typeof(DT));
        if (source.Count<DataClass>() == 0)
        {
            GLog.Log(new object[] { typeof(DT).Name, "has no data to match foreign keys." });
        }
        string[] strArray = (from each in source
            where each.name.ToLower() == cellValue
            select each.name).ToArray<string>();
        foreignName = (strArray.Length == 1) ? strArray[0] : "";
        return (strArray.Length == 1);
    }

    protected static bool TryGetAsForeignName<DT>(string columnString, int row, out string foreignName) where DT: DataClass
    {
        return TryGetAsForeignName<DT>(ConvertColumnToIndex(columnString), row, out foreignName);
    }

    protected static bool TryGetCellValue(int column, int row, out bool output)
    {
        bool flag = true;
        string str = GetCellValue(column, row).ToLower();
        if (bool.TryParse(str, out output))
        {
            return flag;
        }
        switch (str)
        {
            case "yes":
            case "y":
            case "t":
            case "1":
                output = true;
                return flag;

            case "no":
            case "n":
            case "f":
            case "0":
                output = false;
                return flag;
        }
        return false;
    }

    protected static bool TryGetCellValue(int column, int row, out byte output)
    {
        return byte.TryParse(GetCellValue(column, row), out output);
    }

    protected static bool TryGetCellValue(int column, int row, out double output)
    {
        return double.TryParse(GetCellValue(column, row), out output);
    }

    protected static bool TryGetCellValue(int column, int row, out short output)
    {
        return short.TryParse(GetCellValue(column, row), out output);
    }

    protected static bool TryGetCellValue(int column, int row, out int output)
    {
        return int.TryParse(GetCellValue(column, row), out output);
    }

    protected static bool TryGetCellValue(int column, int row, out float output)
    {
        return float.TryParse(GetCellValue(column, row), out output);
    }

    protected static bool TryGetCellValue(int column, int row, out string output)
    {
        output = GetCellValue(column, row);
        return !string.IsNullOrEmpty(output);
    }

    protected static bool TryGetCellValue(int column, int row, out ushort output)
    {
        return ushort.TryParse(GetCellValue(column, row), out output);
    }

    protected static bool TryGetCellValue(int column, int row, out uint output)
    {
        return uint.TryParse(GetCellValue(column, row), out output);
    }

    protected static bool TryGetCellValue(int column, int row, out Color output)
    {
        string str;
        output = new Color();
        if (!TryGetCellValue(column, row, out str))
        {
            return false;
        }
        string[] strArray = str.Split(new char[] { ',' });
        if (strArray.Length != 3)
        {
            return false;
        }
        char[] trimChars = new char[] { ' ', '[', ']', '(', ')', '{', '}', '<', '>' };
        bool flag = (float.TryParse(strArray[0].Trim(trimChars), out output.r) && float.TryParse(strArray[1].Trim(trimChars), out output.g)) && float.TryParse(strArray[2].Trim(trimChars), out output.b);
        if (((output.r > 1.0) || (output.g > 1.0)) || (output.b > 1.0))
        {
            output.r /= 255f;
            output.g /= 255f;
            output.b /= 255f;
        }
        return flag;
    }

    protected static bool TryGetCellValue(int column, int row, out Vector3 output)
    {
        string str;
        output = new Vector3();
        if (!TryGetCellValue(column, row, out str))
        {
            return false;
        }
        string[] strArray = str.Split(new char[] { ',' });
        if (strArray.Length != 3)
        {
            return false;
        }
        char[] trimChars = new char[] { ' ', '[', ']', '(', ')', '{', '}', '<', '>' };
        return ((float.TryParse(strArray[0].Trim(trimChars), out output.x) && float.TryParse(strArray[1].Trim(trimChars), out output.y)) && float.TryParse(strArray[2].Trim(trimChars), out output.z));
    }

    protected static bool TryGetCellValue(string columnString, int row, out bool output)
    {
        return TryGetCellValue(ConvertColumnToIndex(columnString), row, out output);
    }

    protected static bool TryGetCellValue(string columnString, int row, out byte output)
    {
        return TryGetCellValue(ConvertColumnToIndex(columnString), row, out output);
    }

    protected static bool TryGetCellValue(string columnString, int row, out double output)
    {
        return TryGetCellValue(ConvertColumnToIndex(columnString), row, out output);
    }

    protected static bool TryGetCellValue(string columnString, int row, out short output)
    {
        return TryGetCellValue(ConvertColumnToIndex(columnString), row, out output);
    }

    protected static bool TryGetCellValue(string columnString, int row, out int output)
    {
        return TryGetCellValue(ConvertColumnToIndex(columnString), row, out output);
    }

    protected static bool TryGetCellValue(string columnString, int row, out float output)
    {
        return TryGetCellValue(ConvertColumnToIndex(columnString), row, out output);
    }

    protected static bool TryGetCellValue(string columnString, int row, out string output)
    {
        return TryGetCellValue(ConvertColumnToIndex(columnString), row, out output);
    }

    protected static bool TryGetCellValue(string columnString, int row, out ushort output)
    {
        return TryGetCellValue(ConvertColumnToIndex(columnString), row, out output);
    }

    protected static bool TryGetCellValue(string columnString, int row, out uint output)
    {
        return TryGetCellValue(ConvertColumnToIndex(columnString), row, out output);
    }

    protected static bool TryGetCellValue(string columnString, int row, out Color output)
    {
        return TryGetCellValue(ConvertColumnToIndex(columnString), row, out output);
    }

    protected static bool TryGetCellValue(string columnString, int row, out Vector3 output)
    {
        return TryGetCellValue(ConvertColumnToIndex(columnString), row, out output);
    }

    protected static bool TryGetEnumCellValue<ET>(int column, int row, out ET[] output) where ET: struct, IConvertible
    {
        if (!typeof(ET).IsEnum)
        {
            throw new ArgumentException("ET must be an enumerated type");
        }
        string[] strArray = GetCellValue(column, row).Split(new char[] { ',' });
        List<ET> list = new List<ET>();
        List<string> items = new List<string>();
        foreach (string str in strArray)
        {
            if (str.Trim().Length != 0)
            {
                try
                {
                    list.Add((ET) Enum.Parse(typeof(ET), str.Trim(), true));
                }
                catch (ArgumentException)
                {
                    items.Add(str.Trim());
                }
            }
        }
        if (items.Count > 0)
        {
            OutputErrorMessage(column, row, "Failed to parse: " + GUtil.PrettyPrint(items, ", ", "[]") + ", each must be one of: " + GUtil.PrettyPrint(Enum.GetValues(typeof(ET)), ", ", ""));
        }
        output = list.ToArray();
        return (items.Count == 0);
    }

    protected static bool TryGetEnumCellValue<ET>(string columnString, int row, out ET[] output) where ET: struct, IConvertible
    {
        return TryGetEnumCellValue<ET>(ConvertColumnToIndex(columnString), row, out output);
    }

    protected static bool TryGetEnumCellValue<ET>(int column, int row, ET failValue, out ET output) where ET: struct, IConvertible
    {
        if (!typeof(ET).IsEnum)
        {
            throw new ArgumentException("T must be an enumerated type");
        }
        string cellValue = GetCellValue(column, row);
        output = failValue;
        if (cellValue.Trim().Length != 0)
        {
            try
            {
                output = (ET) Enum.Parse(typeof(ET), cellValue, true);
                return true;
            }
            catch (ArgumentException)
            {
                OutputErrorMessage(column, row, "INVALID: \"" + cellValue + "\", must be one of: " + GUtil.PrettyPrint(Enum.GetValues(typeof(ET)), ", ", ""));
            }
        }
        return false;
    }

    protected static bool TryGetEnumCellValue<ET>(string columnString, int row, ET failValue, out ET output) where ET: struct, IConvertible
    {
        return TryGetEnumCellValue<ET>(ConvertColumnToIndex(columnString), row, failValue, out output);
    }

    protected static bool TryGetIdFromForeignName<DT>(string foreignName, out int foreignId) where DT: DataClass
    {
        IEnumerable<DataClass> source = GetData(typeof(DT));
        if (source.Count<DataClass>() == 0)
        {
            GLog.LogError(new object[] { typeof(DT).Name, "has no data to match foreign keys.  (Did a programmer forget a Dependency-Attribute?)" });
        }
        int[] numArray = (from each in source
            where (each.name != null) && (each.name.ToLower() == foreignName)
            select each.id).ToArray<int>();
        foreignId = (numArray.Length == 1) ? numArray[0] : 0;
        return (numArray.Length == 1);
    }

    protected static bool TryGetIdFromForeignName<DT>(int column, int row, out int foreignId) where DT: DataClass
    {
        return TryGetIdFromForeignName<DT>(GetCellValue(column, row).ToLower(), out foreignId);
    }

    protected static bool TryGetIdFromForeignName<DT>(string columnString, int row, out int foreignId) where DT: DataClass
    {
        return TryGetIdFromForeignName<DT>(GetCellValue(ConvertColumnToIndex(columnString), row).ToLower(), out foreignId);
    }

    protected static bool TryGetIdsFromForeignNames<DT>(int column, int row, out int[] foreignIds) where DT: DataClass
    {
        IEnumerable<DataClass> source = GetData(typeof(DT));
        if (source.Count<DataClass>() == 0)
        {
            GLog.LogError(new object[] { typeof(DT).Name, "has no data to match foreign keys.  (Did a programmer forget a Dependency-Attribute?)" });
        }
        Dictionary<string, int> dictionary = new Dictionary<string, int>();
        foreach (DT local in source)
        {
            dictionary[local.name] = local.id;
        }
        List<int> list = new List<int>();
        string[] strArray = GetCellValue(column, row).ToLower().Split(new char[] { ',' });
        for (int i = 0; i < strArray.Length; i++)
        {
            int num;
            if (dictionary.TryGetValue(strArray[i].Trim(), out num))
            {
                list.Add(num);
            }
        }
        foreignIds = list.ToArray();
        return (foreignIds.Length == strArray.Length);
    }

    protected static bool TryGetIdsFromForeignNames<DT>(string columnString, int row, out int[] foreignIds) where DT: DataClass
    {
        return TryGetIdsFromForeignNames<DT>(ConvertColumnToIndex(columnString), row, out foreignIds);
    }

    protected static bool TryGetLCaseCellValue(int column, int row, out string output)
    {
        output = GetCellValue(column, row);
        bool flag = string.IsNullOrEmpty(output);
        if (!flag)
        {
            output = output.ToLower();
        }
        return !flag;
    }

    protected static bool TryGetLCaseCellValue(string columnString, int row, out string output)
    {
        return TryGetLCaseCellValue(ConvertColumnToIndex(columnString), row, out output);
    }

    protected static bool TryGetTimeValue(int numCol, int numRow, int unitCol, int unitRow, out float output)
    {
        GConst.TimeUnit unit;
        output = 0f;
        if (TryGetCellValue(numCol, numRow, out output) && TryGetEnumCellValue<GConst.TimeUnit>(unitCol, unitRow, GConst.TimeUnit.HOURS, out unit))
        {
            switch (unit)
            {
                case GConst.TimeUnit.SECONDS:
                    goto Label_0060;

                case GConst.TimeUnit.MINUTES:
                    output *= 60f;
                    goto Label_0060;

                case GConst.TimeUnit.HOURS:
                    output *= 3600f;
                    goto Label_0060;
            }
        }
        return false;
    Label_0060:
        return true;
    }

    protected static bool TryGetTimeValue(int numCol, int numRow, int unitCol, int unitRow, out TimeSpan output)
    {
        float num;
        output = TimeSpan.Zero;
        if (!TryGetTimeValue(numCol, numRow, unitCol, unitRow, out num))
        {
            return false;
        }
        output = TimeSpan.FromSeconds((double) num);
        return true;
    }

    protected static bool TryGetTimeValue(string numColString, int numRow, string unitColString, int unitRow, out float output)
    {
        return TryGetTimeValue(ConvertColumnToIndex(numColString), numRow, ConvertColumnToIndex(unitColString), unitRow, out output);
    }

    protected static bool TryGetTimeValue(string numColString, int numRow, string unitColString, int unitRow, out TimeSpan output)
    {
        float num;
        output = TimeSpan.Zero;
        if (!TryGetTimeValue(ConvertColumnToIndex(numColString), numRow, ConvertColumnToIndex(unitColString), unitRow, out num))
        {
            return false;
        }
        output = TimeSpan.FromSeconds((double) num);
        return true;
    }

    protected virtual IEnumerable<string> GetMandatoryColumns
    {
        get
        {
            return null;
        }
    }

    protected static int MAX_COL
    {
        get
        {
            return ((data != null) ? data.GetLength(1) : 0);
        }
    }

    protected static int MAX_ROW
    {
        get
        {
            return ((data != null) ? data.GetLength(0) : 0);
        }
    }
}

