﻿using Map;
using Newtonsoft.Json;
using System;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;
using UnityEngine;

public class MapPlace : IDataCopyable<MapPlace>
{
    public static Predicate<MapPlace> EMPTY_MATCH = i => (i == null);
    [DataRestrict]
    public int[] i;
    private const int I_RECORD_SIZE = 9;
    [JsonIgnore]
    public int iconId;
    public const int INITIAL_SIZE = 5;
    [JsonIgnore]
    public ushort mapId;
    [JsonIgnore]
    public IconUniqueKey mapKey;
    public string popupText;
    [JsonIgnore]
    public Vector3 position;

    public MapPlace()
    {
        this.i = new int[9];
        this.mapKey = new IconUniqueKey(IconType.ENTITY, PlaceType.INVALID, 0L);
        this.mapId = 0;
        this.position = GConst.VECTOR3_INVALID;
        this.iconId = 0;
        this.popupText = string.Empty;
    }

    public MapPlace(IconType iconType_, PlaceType placeType_, ulong uniqueId, ushort mapId_, Vector3 position_, string popupText_)
    {
        this.i = new int[9];
        this.mapKey = new IconUniqueKey(iconType_, placeType_, uniqueId);
        this.position = position_;
        this.mapId = mapId_;
        this.iconId = this.GetIconId(placeType_);
        this.popupText = popupText_;
    }

    [CompilerGenerated]
    private static bool <.cctor>b__0(MapPlace i)
    {
        return (i == null);
    }

    public static void ClearType(ref MapPlace[] mapPlaces, PlaceType placeType)
    {
        if (mapPlaces != null)
        {
            for (int i = 0; i < mapPlaces.Length; i++)
            {
                if ((mapPlaces[i] != null) && (mapPlaces[i].mapKey.placeType == placeType))
                {
                    mapPlaces[i] = null;
                }
            }
        }
    }

    public static void CopyContents(MapPlace[] src, ref MapPlace[] dest)
    {
        uint probableIndex = 0;
        for (int i = 0; i < src.Length; i++)
        {
            if (src[i] != null)
            {
                probableIndex = SparseArray.Add<MapPlace>(ref dest, src[i], probableIndex);
            }
        }
    }

    public void DataCopyTo(ref MapPlace target, byte syncTargetLevel)
    {
        target.mapKey = this.mapKey;
        target.position = this.position;
        target.iconId = this.iconId;
        target.popupText = this.popupText;
        target.mapId = this.mapId;
    }

    public bool DataEquals(MapPlace target, byte syncTargetLevel)
    {
        if (object.ReferenceEquals(this, target))
        {
            return true;
        }
        if (object.ReferenceEquals(target, null))
        {
            return false;
        }
        bool flag = true;
        return (((((flag && this.mapKey.DataEquals(target.mapKey, syncTargetLevel)) && (this.position == target.position)) && (this.iconId == target.iconId)) && (this.popupText == target.popupText)) && (this.mapId == target.mapId));
    }

    public int GetIconId(PlaceType iconType)
    {
        switch (iconType)
        {
            case PlaceType.EVENT:
                return ImageData.MapIconIdFromName("quest");

            case PlaceType.PLAYER_MAP_PIN:
                return ImageData.MapIconIdFromName("player_pin");

            case PlaceType.PLAYER_HUSK:
                return ImageData.MapIconIdFromName("player_husk");
        }
        return ImageData.MapIconIdFromName("unknown");
    }

    public static int MapHash(MapPlace[] mapPlaces)
    {
        int num = 0;
        if (mapPlaces != null)
        {
            num += mapPlaces.Length;
            for (int i = 0; i < mapPlaces.Length; i++)
            {
                num += mapPlaces[i].iconId * GConst.aBunchOfPrimes[i % GConst.aBunchOfPrimes.Length];
                num += mapPlaces[i].mapId;
                num += mapPlaces[i].position.GetHashCode();
                num += mapPlaces[i].popupText.GetHashCode();
                num += (int) mapPlaces[i].mapKey.iconType;
                num += (int) mapPlaces[i].mapKey.placeType;
                num += (int) mapPlaces[i].mapKey.uniqueId;
            }
        }
        return num;
    }

    [OnDeserialized]
    internal void OnDeserializedMethod(StreamingContext context)
    {
        int index = 0;
        this.mapKey = new IconUniqueKey((IconType) RecordUtils.GetByte(this.i, 0), (PlaceType) RecordUtils.GetByte(this.i, 1), RecordUtils.GetULong(this.i, 2));
        index += 4;
        this.mapId = RecordUtils.GetUShort(this.i, index);
        index++;
        this.position.x = RecordUtils.GetFloat(this.i, index);
        index++;
        this.position.y = RecordUtils.GetFloat(this.i, index);
        index++;
        this.position.z = RecordUtils.GetFloat(this.i, index);
        index++;
        this.iconId = RecordUtils.GetInt(this.i, index);
        index++;
    }

    [OnSerializing]
    internal void OnSerializingMethod(StreamingContext context)
    {
        int index = 0;
        RecordUtils.SetByte(this.i, (byte) this.mapKey.iconType, index);
        index++;
        RecordUtils.SetByte(this.i, (byte) this.mapKey.placeType, index);
        index++;
        RecordUtils.SetULong(this.i, this.mapKey.uniqueId, index);
        index += 2;
        RecordUtils.SetUShort(this.i, this.mapId, index);
        index++;
        RecordUtils.SetFloat(this.i, this.position.x, index);
        index++;
        RecordUtils.SetFloat(this.i, this.position.y, index);
        index++;
        RecordUtils.SetFloat(this.i, this.position.z, index);
        index++;
        RecordUtils.SetInt(this.i, this.iconId, index);
        index += index++;
    }
}

