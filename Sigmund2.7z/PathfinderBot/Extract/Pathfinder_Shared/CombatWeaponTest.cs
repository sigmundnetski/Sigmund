﻿using System;
using System.Linq;
using UnityEngine;

internal class CombatWeaponTest : UUnitTestCase
{
    private string ArrayToString(int[] items)
    {
        string str = "[";
        for (int i = 0; i < items.Length; i++)
        {
            str = str + items[i].ToString() + ((i < (items.Length - 1)) ? ", " : "");
        }
        object obj2 = str;
        return string.Concat(new object[] { obj2, "] (", items.Length, " items)" });
    }

    protected override void SetUp()
    {
        CombatTestHelper.SetUp();
        CombatTestHelper.MakeCombatData();
        CombatTestHelper.AddKeywordData(new KeywordData("Slashing", KeywordData.KeywordType.BASIC, KeywordData.GearType.WEAPON));
        CombatTestHelper.AddKeywordData(new KeywordData("Sharp", KeywordData.KeywordType.BASIC, KeywordData.GearType.WEAPON));
        CombatTestHelper.AddKeywordData(new KeywordData("Balanced", KeywordData.KeywordType.BASIC, KeywordData.GearType.WEAPON));
        CombatTestHelper.AddKeywordData(new KeywordData("Razored", KeywordData.KeywordType.BASIC, KeywordData.GearType.WEAPON));
        CombatTestHelper.AddKeywordData(new KeywordData("Heavy", KeywordData.KeywordType.BASIC, KeywordData.GearType.WEAPON));
        CombatTestHelper.AddKeywordData(new KeywordData("Bludgeoning", KeywordData.KeywordType.BASIC, KeywordData.GearType.WEAPON));
        CombatTestHelper.AddKeywordData(new KeywordData("Weighted", KeywordData.KeywordType.BASIC, KeywordData.GearType.WEAPON));
        CombatTestHelper.AddKeywordData(new KeywordData("Impact", KeywordData.KeywordType.BASIC, KeywordData.GearType.WEAPON));
        CombatTestHelper.AddKeywordData(new KeywordData("Silver", KeywordData.KeywordType.BASIC, KeywordData.GearType.WEAPON));
        CombatTestHelper.AddKeywordData(new KeywordData("Cold Iron", KeywordData.KeywordType.BASIC, KeywordData.GearType.WEAPON));
        CombatTestHelper.AddKeywordData(new KeywordData("Organic", KeywordData.KeywordType.BASIC, KeywordData.GearType.WEAPON));
        CombatTestHelper.AddKeywordData(new KeywordData("Piercing", KeywordData.KeywordType.BASIC, KeywordData.GearType.WEAPON));
        CombatTestHelper.AddKeywordData(new KeywordData("Light", KeywordData.KeywordType.BASIC, KeywordData.GearType.WEAPON));
        CombatTestHelper.AddKeywordData(new KeywordData("Precise", KeywordData.KeywordType.BASIC, KeywordData.GearType.WEAPON));
        CombatTestHelper.AddKeywordData(new KeywordData("Artifact", KeywordData.KeywordType.ADVANCED, KeywordData.GearType.WEAPON));
        CombatTestHelper.AddKeywordData(new KeywordData("Masterwork", KeywordData.KeywordType.ADVANCED, KeywordData.GearType.WEAPON));
        CombatTestHelper.AddKeywordData(new KeywordData("Vorpal", KeywordData.KeywordType.ADVANCED, KeywordData.GearType.WEAPON));
        CombatTestHelper.AddKeywordData(new KeywordData("Unstoppable", KeywordData.KeywordType.ADVANCED, KeywordData.GearType.WEAPON));
        CombatTestHelper.AddKeywordData(new KeywordData("Slashing", KeywordData.KeywordType.EXPENDABLE, KeywordData.GearType.IMPLEMENT));
        CombatTestHelper.AddKeywordData(new KeywordData("Sharp", KeywordData.KeywordType.EXPENDABLE, KeywordData.GearType.IMPLEMENT));
        CombatTestHelper.AddKeywordData(new KeywordData("Balanced", KeywordData.KeywordType.EXPENDABLE, KeywordData.GearType.IMPLEMENT));
        CombatTestHelper.AddKeywordData(new KeywordData("Razored", KeywordData.KeywordType.EXPENDABLE, KeywordData.GearType.IMPLEMENT));
        CombatTestHelper.AddKeywordData(new KeywordData("Heavy", KeywordData.KeywordType.EXPENDABLE, KeywordData.GearType.IMPLEMENT));
        CombatTestHelper.AddKeywordData(new KeywordData("Bludgeoning", KeywordData.KeywordType.EXPENDABLE, KeywordData.GearType.IMPLEMENT));
        CombatTestHelper.AddKeywordData(new KeywordData("Weighted", KeywordData.KeywordType.EXPENDABLE, KeywordData.GearType.IMPLEMENT));
        CombatTestHelper.AddKeywordData(new KeywordData("Impact", KeywordData.KeywordType.EXPENDABLE, KeywordData.GearType.IMPLEMENT));
        CombatTestHelper.AddKeywordData(new KeywordData("Silver", KeywordData.KeywordType.EXPENDABLE, KeywordData.GearType.IMPLEMENT));
        CombatTestHelper.LoadKeywordData();
        CombatTestHelper.AddWeaponProficiency(new WeaponProficiencyData("Heavy Blade"));
        CombatTestHelper.AddWeaponProficiency(new WeaponProficiencyData("Hammer"));
        CombatTestHelper.AddWeaponProficiency(new WeaponProficiencyData("Spellbook"));
        CombatTestHelper.LoadWeaponProficiency();
        CombatTestHelper.AddBasicWeapon(new BasicWeaponData("Longsword", CombatWeapon.Complexity.MARTIAL, 1.5f, AttackType.HeavyMelee, "Heavy Blade", "Slashing", "Sharp", "Balanced", "Razored"));
        CombatTestHelper.AddBasicWeapon(new BasicWeaponData("Club", CombatWeapon.Complexity.SIMPLE, 1.1f, AttackType.LightMelee, "Hammer", "Bludgeoning", "Weighted", "Balanced", "Impact"));
        CombatTestHelper.AddBasicWeapon(new BasicWeaponData("Aldori Sword", CombatWeapon.Complexity.EXOTIC, 2.3f, AttackType.HeavyMelee, "Heavy Blade", "Slashing", "Sharp", "Heavy", "Razored"));
        CombatTestHelper.AddBasicWeapon(new BasicWeaponData("Spellbook", CombatWeapon.Complexity.MARTIAL, 2.3f, "Spellbook"));
        CombatTestHelper.LoadBasicWeapon();
        CombatTestHelper.AddWeaponQuality(new WeaponQualityData("Bronze", "Longsword", 1, "", "", ""));
        CombatTestHelper.AddWeaponQuality(new WeaponQualityData("Silvered Steel", "Longsword", 2, "Masterwork", "Silver", ""));
        CombatTestHelper.AddWeaponQuality(new WeaponQualityData("Truesilver", "Longsword", 3, "Vorpal", "Masterwork", "Silver"));
        CombatTestHelper.AddWeaponQuality(new WeaponQualityData("Softwood", "Club", 1, "Organic", "", ""));
        CombatTestHelper.AddWeaponQuality(new WeaponQualityData("Hardwood", "Club", 2, "Masterwork", "Organic", ""));
        CombatTestHelper.AddWeaponQuality(new WeaponQualityData("Darkwood", "Club", 3, "Unstoppable", "Masterwork", "Organic"));
        CombatTestHelper.AddWeaponQuality(new WeaponQualityData("Cold Iron", "Aldori Sword", 1, "Cold Iron", "", ""));
        CombatTestHelper.AddWeaponQuality(new WeaponQualityData("Steel", "Aldori Sword", 2, "Masterwork", "", ""));
        CombatTestHelper.AddWeaponQuality(new WeaponQualityData("Adamantine", "Aldori Sword", 3, "Vorpal", "Masterwork", ""));
        CombatTestHelper.AddWeaponQuality(new WeaponQualityData("Sage", "Spellbook", 3, 8, 0x15, 3));
        CombatTestHelper.LoadCombatWeapon();
        int num = 0;
        CombatTestHelper.AddAttackFeat(new AttackFeatData("Strike", 1.4f, -1f, 0f, 0f, 0f, 20, num, "", 0f, "", "Slashing, Bludgeoning, Piercing", "Light, Heavy, Balanced", "Masterwork", "Sharp, Weighted, Precise", "Artifact"));
        CombatTestHelper.AddAttackFeat(new AttackFeatData("Slash", 1.15f, -1f, 0.2f, 0.2f, 0.6f, 20, num, "", 0f, "Slashing", "Sharp", "Balanced", "Masterwork", "Razored", "Vorpal, Artifact"));
        CombatTestHelper.AddAttackFeat(new AttackFeatData("Thwack", 0.76f, -1f, 0.3f, 0f, 1.2f, 15, num, "", 0f, "Bludgeoning", "Weighted", "Balanced", "Masterwork", "Impact", "Unstoppable, Artifact"));
        CombatTestHelper.LoadOffensiveFeats();
    }

    protected override void TearDown()
    {
        CombatTestHelper.ClearAllCombatStaticData();
    }

    [UUnitTestMethod]
    public void TestBuildWeapons()
    {
        UUnitAssert.True(CombatTestHelper.qualityWeapons.Count == CombatWeapon.weaponsByName.Count, string.Concat(new object[] { "Number of weapons should be same as number of WeaponQualityData objects.", CombatTestHelper.qualityWeapons.Count, " != ", CombatWeapon.weaponsByName.Count }));
        CombatWeapon weaponByName = CombatWeapon.GetWeaponByName("Bronze Longsword");
        UUnitAssert.True(weaponByName.name == "bronze longsword", "Bronze Longsword's name should be 'bronze longsword' instead of '" + weaponByName.name + "'");
        UUnitAssert.True(weaponByName.displayName == "Bronze Longsword", "Bronze Longsword's display name should be 'Bronze Longsword' instead of '" + weaponByName.displayName + "'");
        UUnitAssert.True(weaponByName.baseDamage == CombatData.singleton.weaponDamageMartial, string.Concat(new object[] { "Expected ", CombatData.singleton.weaponDamageMartial, " got ", weaponByName.baseDamage }));
        UUnitAssert.True(weaponByName.tier == 1, string.Concat(new object[] { "Expected ", 1, " got ", weaponByName.tier }));
        UUnitAssert.True(weaponByName.GetKeywordIds(0).Length == 1, string.Concat(new object[] { "Expected ", 1, " got ", weaponByName.GetKeywordIds(0).Length }));
        UUnitAssert.True(weaponByName.GetKeywordIds(1).Length == 2, string.Concat(new object[] { "Expected ", 2, " got ", weaponByName.GetKeywordIds(1).Length }));
        UUnitAssert.True(weaponByName.GetKeywordIds(2).Length == 3, string.Concat(new object[] { "Expected ", 3, " got ", weaponByName.GetKeywordIds(2).Length }));
        UUnitAssert.True(weaponByName.GetKeywordIds(3).Length == 4, string.Concat(new object[] { "Expected ", 4, " got ", weaponByName.GetKeywordIds(3).Length }));
        weaponByName = CombatWeapon.GetWeaponByName("Truesilver Longsword");
        UUnitAssert.True(weaponByName.GetKeywordIds(0).Length == 4, string.Concat(new object[] { "Expected ", 4, " got ", weaponByName.GetKeywordIds(0).Length }));
        UUnitAssert.True(weaponByName.GetKeywordIds(1).Length == 5, string.Concat(new object[] { "Expected ", 5, " got ", weaponByName.GetKeywordIds(1).Length }));
        UUnitAssert.True(weaponByName.GetKeywordIds(2).Length == 6, string.Concat(new object[] { "Expected ", 6, " got ", weaponByName.GetKeywordIds(2).Length }));
        UUnitAssert.True(weaponByName.GetKeywordIds(3).Length == 7, string.Concat(new object[] { "Expected ", 7, " got ", weaponByName.GetKeywordIds(3).Length }));
        int[] first = new int[] { KeywordData.GetId("Slashing", KeywordData.GearType.WEAPON), KeywordData.GetId("Vorpal", KeywordData.GearType.WEAPON), KeywordData.GetId("Masterwork", KeywordData.GearType.WEAPON), KeywordData.GetId("Silver", KeywordData.GearType.WEAPON) };
        int[] items = first.Intersect<int>(weaponByName.GetKeywordIds(0)).ToArray<int>();
        UUnitAssert.True(first.Length == items.Length, "Expected " + this.ArrayToString(first) + " keywords to match " + this.ArrayToString(weaponByName.GetKeywordIds(0)) + ". Got: " + this.ArrayToString(items));
        first = new int[] { KeywordData.GetId("Slashing", KeywordData.GearType.WEAPON), KeywordData.GetId("Sharp", KeywordData.GearType.WEAPON), KeywordData.GetId("Balanced", KeywordData.GearType.WEAPON), KeywordData.GetId("Razored", KeywordData.GearType.WEAPON), KeywordData.GetId("Vorpal", KeywordData.GearType.WEAPON), KeywordData.GetId("Masterwork", KeywordData.GearType.WEAPON), KeywordData.GetId("Silver", KeywordData.GearType.WEAPON) };
        items = first.Intersect<int>(weaponByName.GetKeywordIds(3)).ToArray<int>();
        UUnitAssert.True(first.Length == items.Length, "Expected " + this.ArrayToString(first) + " keywords to match " + this.ArrayToString(weaponByName.GetKeywordIds(3)) + ". Got: " + this.ArrayToString(items));
    }

    [UUnitTestMethod]
    public void TestExpendableDamage()
    {
        int num = 0;
        CombatWeapon weaponByName = CombatWeapon.GetWeaponByName("Sage Spellbook");
        ExpendableFeatData attack = new ExpendableFeatData("Bleeding Hands", 3.56f, -1f, 0f, 0f, 0f, 20, 20, 1, false, num, AttackType.Arcane, "", "Slashing", "Sharp", "Balanced", "Bludgeoning", "Razored", "Heavy", "Weighted", "Impact", "Silver");
        FeatureFeatData featureFeat = new FeatureFeatData("Base Damage", 9, "Base Damage +5 with Heavy Blade", "Slashing, Sharp, Balanced, Bludgeoning, Razored, Heavy, Weighted, Impact, Silver");
        uint attackLevel = 9;
        uint num3 = 40 + (7 * attackLevel);
        uint num4 = (uint) Mathf.FloorToInt(1.4f * attackLevel);
        int weaponDamage = 0;
        int bonusDamage = 0;
        int effectPower = 0;
        weaponByName.GetExpendableDamage(attack, attackLevel, featureFeat, out weaponDamage, out bonusDamage, out effectPower);
        int num8 = weaponDamage + bonusDamage;
        UUnitAssert.True(num8 == num3, string.Concat(new object[] { weaponByName.name, " with ", attack.name, " ", attackLevel, " does ", num8, " damage. EXPECTED ", num3, " damage." }));
        UUnitAssert.True(effectPower == num4, string.Concat(new object[] { weaponByName.name, " with ", attack.name, " ", attackLevel, " has ", effectPower, " effect power. EXPECTED ", num4, " effect power." }));
        attackLevel = 1;
        num3 = 40 + (7 * attackLevel);
        num4 = (uint) Mathf.FloorToInt(1.4f * attackLevel);
        weaponDamage = 0;
        bonusDamage = 0;
        effectPower = 0;
        weaponByName.GetExpendableDamage(attack, attackLevel, featureFeat, out weaponDamage, out bonusDamage, out effectPower);
        num8 = weaponDamage + bonusDamage;
        UUnitAssert.True(num8 == num3, string.Concat(new object[] { weaponByName.name, " with ", attack.name, " ", attackLevel, " does ", num8, " damage. EXPECTED ", num3, " damage." }));
        UUnitAssert.True(effectPower == num4, string.Concat(new object[] { weaponByName.name, " with ", attack.name, " ", attackLevel, " has ", effectPower, " effect power. EXPECTED ", num4, " effect power." }));
    }

    [UUnitTestMethod]
    public void TestExpendablesValidity()
    {
        int num = 0;
        ExpendableFeatData data = new ExpendableFeatData("Bleeding Hands", 3.56f, -1f, 0f, 0f, 0f, 20, 20, 1, false, num, AttackType.Arcane, "", "", "", "", "", "", "", "", "", "");
        ExpendableFeatData data2 = new ExpendableFeatData("Power Overwhelming", 3.56f, -1f, 0f, 0f, 0f, 20, 20, 9, false, num, AttackType.Arcane, "", "", "", "", "", "", "", "", "", "");
        ExpendableFeatData data3 = new ExpendableFeatData("Power Whelming", 3.56f, -1f, 0f, 0f, 0f, 20, 20, 8, false, num, AttackType.Arcane, "", "", "", "", "", "", "", "", "", "");
        AttackFeatData data4 = new AttackFeatData("Slash", 1.15f, -1f, 0.2f, 0.2f, 0.6f, 20, num, "", 0f, "Slashing", "Sharp", "Balanced", "Masterwork", "Razored", "Vorpal, Artifact");
        OffensiveFeatData[] expendables = new OffensiveFeatData[] { data, data3, data3 };
        OffensiveFeatData[] dataArray2 = new OffensiveFeatData[] { data, data3, data2 };
        OffensiveFeatData[] dataArray3 = new OffensiveFeatData[] { data, data3, data3, data3 };
        OffensiveFeatData[] dataArray4 = new OffensiveFeatData[] { data, data3, data4 };
        CombatWeapon weaponByName = CombatWeapon.GetWeaponByName("Sage Spellbook");
        CombatWeapon.ExpendableVerification verification = weaponByName.VerifyExpendables(expendables, 0);
        UUnitAssert.True(verification == CombatWeapon.ExpendableVerification.VALID, string.Concat(new object[] { "expected: ", CombatWeapon.ExpendableVerification.VALID, " got: ", verification }));
        verification = weaponByName.VerifyExpendables(dataArray2, 0);
        UUnitAssert.True(verification == CombatWeapon.ExpendableVerification.OVER_MAX_LEVEL, string.Concat(new object[] { "expected: ", CombatWeapon.ExpendableVerification.OVER_MAX_LEVEL, " got: ", verification }));
        verification = weaponByName.VerifyExpendables(dataArray3, 0);
        UUnitAssert.True(verification == CombatWeapon.ExpendableVerification.OVER_TOTAL_LEVELS, string.Concat(new object[] { "expected: ", CombatWeapon.ExpendableVerification.OVER_TOTAL_LEVELS, " got: ", verification }));
        verification = weaponByName.VerifyExpendables(dataArray4, 0);
        UUnitAssert.True(verification == CombatWeapon.ExpendableVerification.NOT_AN_EXPENDABLE, string.Concat(new object[] { "expected: ", CombatWeapon.ExpendableVerification.NOT_AN_EXPENDABLE, " got: ", verification }));
        verification = weaponByName.VerifyExpendables(dataArray3, 3);
        UUnitAssert.True(verification == CombatWeapon.ExpendableVerification.VALID, string.Concat(new object[] { "expected: ", CombatWeapon.ExpendableVerification.VALID, " got: ", verification }));
        verification = CombatWeapon.GetWeaponByName("Adamantine Aldori Sword").VerifyExpendables(expendables, 0);
        UUnitAssert.True(verification == CombatWeapon.ExpendableVerification.NOT_AN_IMPLEMENT, string.Concat(new object[] { "expected: ", CombatWeapon.ExpendableVerification.NOT_AN_IMPLEMENT, " got: ", verification }));
    }

    [UUnitTestMethod]
    public void TestWeaponDamageExotic()
    {
        CombatWeapon weaponByName = CombatWeapon.GetWeaponByName("Adamantine Aldori Sword");
        byte weaponUpgrade = 3;
        uint attackLevel = 6;
        OffensiveFeatData attackByName = OffensiveFeatData.GetAttackByName("Strike");
        int num3 = 0x55;
        int num4 = 3 + CombatData.singleton.advancedKeywordMultiplier;
        int weaponDamage = 0;
        int bonusDamage = 0;
        int effectPower = 0;
        weaponByName.GetAttackDamage(attackByName, weaponUpgrade, attackLevel, out weaponDamage, out bonusDamage, out effectPower);
        int num8 = weaponDamage + bonusDamage;
        UUnitAssert.True(num8 == num3, string.Concat(new object[] { weaponByName.name, " ", weaponUpgrade, " with ", attackByName.name, " ", attackLevel, " does ", num8, " damage. EXPECTED ", num3, " damage." }));
        UUnitAssert.True(effectPower == num4, string.Concat(new object[] { weaponByName.name, " ", weaponUpgrade, " with ", attackByName.name, " ", attackLevel, " has ", effectPower, " effect power. EXPECTED ", num4, " effect power." }));
    }

    [UUnitTestMethod]
    public void TestWeaponDamageMartial()
    {
        CombatWeapon weaponByName = CombatWeapon.GetWeaponByName("Truesilver Longsword");
        byte weaponUpgrade = 3;
        uint attackLevel = 6;
        OffensiveFeatData attackByName = OffensiveFeatData.GetAttackByName("Slash");
        int num3 = 100;
        int num4 = 4 + (2 * CombatData.singleton.advancedKeywordMultiplier);
        int weaponDamage = 0;
        int bonusDamage = 0;
        int effectPower = 0;
        weaponByName.GetAttackDamage(attackByName, weaponUpgrade, attackLevel, out weaponDamage, out bonusDamage, out effectPower);
        int num8 = weaponDamage + bonusDamage;
        UUnitAssert.True(num8 == num3, string.Concat(new object[] { weaponByName.name, " ", weaponUpgrade, " with ", attackByName.name, " ", attackLevel, " does ", num8, " damage. EXPECTED ", num3, " damage." }));
        UUnitAssert.True(effectPower == num4, string.Concat(new object[] { weaponByName.name, " ", weaponUpgrade, " with ", attackByName.name, " ", attackLevel, " has ", effectPower, " effect power. EXPECTED ", num4, " effect power." }));
        weaponUpgrade = 3;
        attackLevel = 1;
        num3 = 0x2d;
        num4 = 1;
        weaponDamage = 0;
        bonusDamage = 0;
        effectPower = 0;
        weaponByName.GetAttackDamage(attackByName, weaponUpgrade, attackLevel, out weaponDamage, out bonusDamage, out effectPower);
        num8 = weaponDamage + bonusDamage;
        UUnitAssert.True(num8 == num3, string.Concat(new object[] { weaponByName.name, " ", weaponUpgrade, " with ", attackByName.name, " ", attackLevel, " does ", num8, " damage. EXPECTED ", num3, " damage." }));
        UUnitAssert.True(effectPower == num4, string.Concat(new object[] { weaponByName.name, " ", weaponUpgrade, " with ", attackByName.name, " ", attackLevel, " has ", effectPower, " effect power. EXPECTED ", num4, " effect power." }));
        weaponUpgrade = 0;
        attackLevel = 4;
        num3 = 0x41;
        num4 = 1 + CombatData.singleton.advancedKeywordMultiplier;
        weaponDamage = 0;
        bonusDamage = 0;
        effectPower = 0;
        weaponByName.GetAttackDamage(attackByName, weaponUpgrade, attackLevel, out weaponDamage, out bonusDamage, out effectPower);
        num8 = weaponDamage + bonusDamage;
        UUnitAssert.True(num8 == num3, string.Concat(new object[] { weaponByName.name, " ", weaponUpgrade, " with ", attackByName.name, " ", attackLevel, " does ", num8, " damage. EXPECTED ", num3, " damage." }));
        UUnitAssert.True(effectPower == num4, string.Concat(new object[] { weaponByName.name, " ", weaponUpgrade, " with ", attackByName.name, " ", attackLevel, " has ", effectPower, " effect power. EXPECTED ", num4, " effect power." }));
    }

    [UUnitTestMethod]
    public void TestWeaponDamageSimple()
    {
        CombatWeapon weaponByName = CombatWeapon.GetWeaponByName("Softwood Club");
        byte weaponUpgrade = 3;
        uint attackLevel = 6;
        OffensiveFeatData attackByName = OffensiveFeatData.GetAttackByName("Thwack");
        int num3 = 50;
        int num4 = 4;
        int weaponDamage = 0;
        int bonusDamage = 0;
        int effectPower = 0;
        weaponByName.GetAttackDamage(attackByName, weaponUpgrade, attackLevel, out weaponDamage, out bonusDamage, out effectPower);
        int num8 = weaponDamage + bonusDamage;
        UUnitAssert.True(num8 == num3, string.Concat(new object[] { weaponByName.name, " ", weaponUpgrade, " with ", attackByName.name, " ", attackLevel, " does ", num8, " damage. EXPECTED ", num3, " damage." }));
        UUnitAssert.True(effectPower == num4, string.Concat(new object[] { weaponByName.name, " ", weaponUpgrade, " with ", attackByName.name, " ", attackLevel, " has ", effectPower, " effect power. EXPECTED ", num4, " effect power." }));
        weaponUpgrade = 3;
        attackLevel = 1;
        num3 = 0x23;
        num4 = 1;
        weaponDamage = 0;
        bonusDamage = 0;
        effectPower = 0;
        weaponByName.GetAttackDamage(attackByName, weaponUpgrade, attackLevel, out weaponDamage, out bonusDamage, out effectPower);
        num8 = weaponDamage + bonusDamage;
        UUnitAssert.True(num8 == num3, string.Concat(new object[] { weaponByName.name, " ", weaponUpgrade, " with ", attackByName.name, " ", attackLevel, " does ", num8, " damage. EXPECTED ", num3, " damage." }));
        UUnitAssert.True(effectPower == num4, string.Concat(new object[] { weaponByName.name, " ", weaponUpgrade, " with ", attackByName.name, " ", attackLevel, " has ", effectPower, " effect power. EXPECTED ", num4, " effect power." }));
        weaponUpgrade = 0;
        attackLevel = 6;
        num3 = 0x23;
        num4 = 1;
        weaponDamage = 0;
        bonusDamage = 0;
        effectPower = 0;
        weaponByName.GetAttackDamage(attackByName, weaponUpgrade, attackLevel, out weaponDamage, out bonusDamage, out effectPower);
        num8 = weaponDamage + bonusDamage;
        UUnitAssert.True(num8 == num3, string.Concat(new object[] { weaponByName.name, " ", weaponUpgrade, " with ", attackByName.name, " ", attackLevel, " does ", num8, " damage. EXPECTED ", num3, " damage." }));
        UUnitAssert.True(effectPower == num4, string.Concat(new object[] { weaponByName.name, " ", weaponUpgrade, " with ", attackByName.name, " ", attackLevel, " has ", effectPower, " effect power. EXPECTED ", num4, " effect power." }));
    }
}

