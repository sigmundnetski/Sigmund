﻿using System;

public enum HexAdjacentDirection : byte
{
    N = 0,
    NE = 1,
    NUM_DIRECTIONS = 6,
    NW = 5,
    S = 3,
    SE = 2,
    SW = 4
}

