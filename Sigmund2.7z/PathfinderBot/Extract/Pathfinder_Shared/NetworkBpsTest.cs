﻿using GNetwork;
using System;

public class NetworkBpsTest : UUnitTestCase
{
    [UUnitTestMethod]
    private void TestBPS()
    {
        DateTime utcNow = DateTime.UtcNow;
        TestBpsBuffer buffer = new TestBpsBuffer();
        UUnitAssert.Equals(0, buffer.AccumulateBytes(), "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        buffer.testAccumBPS = 0x4e20;
        UUnitAssert.Equals(0x4e20, buffer.AccumulateBytes(), "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(0, buffer.AccumulateBytes(), "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        buffer.testAccumBPS = 0x7530;
        UUnitAssert.Equals(0x7530, buffer.AccumulateBytes(), "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(0, buffer.AccumulateBytes(), "Expected equivalent inputs: \"{0}\" != \"{1}\"");
    }

    private class TestBpsBuffer : BaseBuffer
    {
        public int testAccumBPS
        {
            get
            {
                return base._accumulateBPS;
            }
            set
            {
                base._accumulateBPS = value;
            }
        }

        public long testTotal
        {
            get
            {
                return base._totalBytesEver;
            }
            set
            {
                base._totalBytesEver = value;
            }
        }
    }
}

