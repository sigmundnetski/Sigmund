﻿using System;

public class MaterialInfoArray
{
    public MaterialInfo[] array;
}

