﻿using System;
using System.Collections.Generic;

public class EmoteData : DataClass
{
    public static Dictionary<string, EmoteData> emoteByCommand = new Dictionary<string, EmoteData>();
    public static Dictionary<int, EmoteData> emoteById = new Dictionary<int, EmoteData>();
    public string otherTargetedResponse;
    public string otherUntargetedResponse;
    public string receiverResponse;
    public string selfTargetedResponse;
    public string selfUntargetedResponse;

    public static void OnLoad(List<DataClass> objects)
    {
        foreach (EmoteData data in objects)
        {
            emoteById[data.id] = data;
            emoteByCommand[data.name] = data;
        }
    }

    public override DataClass ParseRecord(int rowIndex)
    {
        EmoteData data = new EmoteData();
        DataClass.GetLCaseCellValue(DataClass.columnNamesToIndex["command"], rowIndex, out data.name);
        DataClass.GetCellValue(DataClass.columnNamesToIndex["self untargeted response"], rowIndex, out data.selfUntargetedResponse);
        DataClass.GetCellValue(DataClass.columnNamesToIndex["self targeted response"], rowIndex, out data.selfTargetedResponse);
        DataClass.GetCellValue(DataClass.columnNamesToIndex["other untargeted response"], rowIndex, out data.otherUntargetedResponse);
        DataClass.GetCellValue(DataClass.columnNamesToIndex["other targeted response"], rowIndex, out data.otherTargetedResponse);
        DataClass.GetCellValue(DataClass.columnNamesToIndex["receiver response"], rowIndex, out data.receiverResponse);
        return data;
    }

    protected override IEnumerable<string> GetMandatoryColumns
    {
        get
        {
            return new string[] { "command", "self untargeted response", "self targeted response", "other untargeted response", "other targeted response", "receiver response" };
        }
    }
}

