﻿using System;

public class FatigueDebuff : CombatStackBuff
{
    private uint FATIGUE_RECOVERY_TICKS;

    public FatigueDebuff() : base("Fatigue", Combat.Channel.None, Combat.EffectType.Detrimental)
    {
        this.FATIGUE_RECOVERY_TICKS = CombatCore.TicksFromSeconds(30f);
    }

    public static FatigueDebuff Create()
    {
        return new FatigueDebuff();
    }

    public override void RecalculationPhase(CombatBuffVars buff, uint combatTick)
    {
        buff.owner.tempStaminaPenalty = Math.Min(buff.owner.tempStaminaPenalty + buff.stacks, CombatData.singleton.staminaLimit);
    }

    public override void TimePhase(CombatBuffVars buff, uint combatTick)
    {
        if (combatTick >= buff.stackLossTime)
        {
            this.UpdateStackLossTime(buff, combatTick);
            buff.stacks--;
        }
    }

    public override void UpdateBuff(CombatBuffVars buff, uint combatTick, CombatModifier mod, CombatEffect effect)
    {
        if (buff.stackLossTime == 0)
        {
            this.UpdateStackLossTime(buff, combatTick);
            buff.resolutionTime = combatTick;
        }
        buff.stacks += (int) mod.stackAmount;
    }

    private void UpdateStackLossTime(CombatBuffVars buff, uint combatTick)
    {
        uint num = (uint) CombatCore.RoundToInt(((float) this.FATIGUE_RECOVERY_TICKS) / ((float) buff.owner.combatClass.recovery.Get(RecoveryType.Fatigued)));
        buff.stackLossTime = combatTick + num;
    }
}

