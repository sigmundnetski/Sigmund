﻿using System;

public abstract class FeatData : DataClass
{
    public int animationId;
    public Combat.FeatType baseType;
    public string displayName;
    public float durationCooldown;
    public Combat.EffectType effectType;
    public int featAdvancementId;
    public FeatForm form;
    public const int FORM_PRIMARY_HOTBAR_MAX = 2;
    public const int FORM_SECONDARY_HOTBAR_MIN = 3;
    public Combat.FeatType generalType;
    public string icon;
    public float range;
    public int roleId;
    public int stamina;
    public Combat.FeatType type;
    public bool usableInStealth;

    public FeatData()
    {
        this.effectType = Combat.EffectType.Detrimental;
        this.form = FeatForm.Universal;
    }

    public FeatData(string name_) : base(name_)
    {
        this.effectType = Combat.EffectType.Detrimental;
        this.form = FeatForm.Universal;
    }

    protected void ParseEffectType(CombatModifier[] mods)
    {
        if (mods != null)
        {
            for (int i = 0; i < mods.Length; i++)
            {
                if ((mods[i].type == CombatModifierType.ATTACK_MODIFIER) && (mods[i].attackMod == CombatConstants.AttackMod.BENEFICIAL))
                {
                    this.effectType = Combat.EffectType.Beneficial;
                    break;
                }
            }
        }
    }

    public enum FeatForm : byte
    {
        Primary = 1,
        Secondary = 2,
        Universal = 0,
        Utility = 3,
        Wondrous = 4
    }
}

