﻿using System;

public class TimerStatus : IDataCopyable<TimerStatus>
{
    private DateTime endTime;
    private bool timerActive;

    public TimerStatus()
    {
        this.Clear();
    }

    public TimerStatus(EventTimeLimit timerData, DateTime curTime)
    {
        this.Reset(timerData, curTime);
    }

    public void Clear()
    {
        this.timerActive = false;
        this.endTime = DateTime.MinValue;
    }

    public void DataCopyTo(ref TimerStatus target, byte syncTargetLevel)
    {
        target.endTime = this.endTime;
        target.timerActive = this.timerActive;
    }

    public bool DataEquals(TimerStatus target, byte syncTargetLevel)
    {
        if (object.ReferenceEquals(this, target))
        {
            return true;
        }
        if (object.ReferenceEquals(target, null))
        {
            return false;
        }
        return ((target.endTime == this.endTime) && (target.timerActive == this.timerActive));
    }

    public bool IsExpired(DateTime curTime)
    {
        if (!this.timerActive)
        {
            return false;
        }
        return (curTime > this.endTime);
    }

    public void Reset(EventTimeLimit timerData, DateTime curTime)
    {
        if (timerData == null)
        {
            this.Clear();
        }
        else
        {
            this.UpdateEndTime(curTime, timerData.duration);
        }
    }

    public TimeSpan TimeToExpire(DateTime curTime)
    {
        if (!this.timerActive)
        {
            return TimeSpan.MaxValue;
        }
        return (TimeSpan) (this.endTime - curTime);
    }

    public void UpdateEndTime(DateTime curTime, float duration)
    {
        this.timerActive = true;
        this.endTime = curTime + TimeSpan.FromSeconds((double) duration);
    }
}

