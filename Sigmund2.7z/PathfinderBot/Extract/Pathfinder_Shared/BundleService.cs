﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using UnityEngine;

public static class BundleService
{
    private static HashSet<string> bypassedBundles = new HashSet<string>();
    private static Dictionary<string, Dictionary<string, UnityEngine.Object>> objects = new Dictionary<string, Dictionary<string, UnityEngine.Object>>();
    private static Dictionary<string, AssetBundle> readyBundles = new Dictionary<string, AssetBundle>();
    private static bool useFallbackPaths = false;

    private static void _LoadBundleByName(string bundleFolder, string bundleName, bool onDemandLoaded, bool useServerSpecific = false)
    {
        if (!readyBundles.ContainsKey(bundleName))
        {
            string str = useServerSpecific ? (bundleName + "-Server") : bundleName;
            if (!IsValidBundle(bundleFolder, str, "unity3d"))
            {
                Debug.LogWarning("Unable to load bundle " + bundleName + " because it could not be found in the default or fallback locations.");
            }
            else
            {
                string str4;
                string str2 = "unity3d";
                string path = string.Format(BundleConsts.bundleRawFormat, new object[] { Application.dataPath, bundleFolder, str, str2 });
                if (!(useFallbackPaths || File.Exists(path)))
                {
                    Debug.LogWarning("Loading the bundles from default path failed, switching to fallback location");
                    useFallbackPaths = true;
                }
                if (useFallbackPaths)
                {
                    str4 = string.Format(BundleConsts.bundleRawFallbackFormat, bundleFolder, str, str2);
                }
                else
                {
                    str4 = string.Format(BundleConsts.bundleRawFormat, new object[] { Application.dataPath, bundleFolder, str, str2 });
                }
                AssetBundle bundle = AssetBundle.CreateFromFile(str4);
                readyBundles[bundleName] = bundle;
                if (onDemandLoaded)
                {
                    int num;
                    UnityEngine.Object[] objArray = bundle.LoadAll(typeof(ShaderHolder));
                    for (num = 0; num < objArray.Length; num++)
                    {
                        ResourceManager.RegisterMaterials((ShaderHolder) objArray[num], false);
                    }
                    UnityEngine.Object[] objArray2 = bundle.LoadAll(typeof(GameObject));
                    if (objArray2 != null)
                    {
                        objects[bundleName] = new Dictionary<string, UnityEngine.Object>();
                        for (num = 0; num < objArray2.Length; num++)
                        {
                            objects[bundleName][objArray2[num].name] = objArray2[num];
                        }
                    }
                    objArray2 = bundle.LoadAll(typeof(Material));
                    if (objArray2 != null)
                    {
                        for (num = 0; num < objArray2.Length; num++)
                        {
                            objects[bundleName][objArray2[num].name] = objArray2[num];
                        }
                    }
                }
            }
        }
    }

    public static bool CheckBundle(string bundleName)
    {
        if (!bypassedBundles.Contains(bundleName) && !readyBundles.ContainsKey(bundleName))
        {
            throw new BundleFailureException("A bundle must be loaded before you can check it: " + bundleName);
        }
        return true;
    }

    public static bool IsValidBundle(string bundleFolder, string bundleName, string extension = "unity3d")
    {
        return (File.Exists(string.Format(BundleConsts.bundleRawFormat, new object[] { Application.dataPath, bundleFolder, bundleName, extension })) || File.Exists(string.Format(BundleConsts.bundleRawFallbackFormat, bundleFolder, bundleName, extension)));
    }

    public static T Load<T>(BundleInfo bundleInfo, string name) where T: UnityEngine.Object
    {
        Func<UnityEngine.Object, bool> func = null;
        T local = default(T);
        if (bundleInfo.tryResourcesFirst)
        {
            if (func == null)
            {
                func = each => each.name == name;
            }
            return (Enumerable.Where<UnityEngine.Object>(Resources.LoadAll(bundleInfo.bundleResourcePath, typeof(T)), func).FirstOrDefault<UnityEngine.Object>() as T);
        }
        AssetBundle bundle = null;
        if (!readyBundles.TryGetValue(bundleInfo.bundleName, out bundle))
        {
            return local;
        }
        if (bundleInfo.onDemandLoading)
        {
            UnityEngine.Object obj2 = null;
            if (objects.ContainsKey(bundleInfo.bundleName))
            {
                objects[bundleInfo.bundleName].TryGetValue(name, out obj2);
                local = obj2 as T;
            }
            return local;
        }
        return (bundle.Load(name, typeof(T)) as T);
    }

    public static IEnumerable<T> LoadAll<T>(BundleInfo bundleInfo) where T: UnityEngine.Object
    {
        Func<UnityEngine.Object, T> func = null;
        Func<UnityEngine.Object, T> func2 = null;
        if (bundleInfo.tryResourcesFirst)
        {
            if (func == null)
            {
                func = each => (T) each;
            }
            return Enumerable.Select<UnityEngine.Object, T>(Resources.LoadAll(bundleInfo.bundleResourcePath, typeof(T)), func);
        }
        AssetBundle bundle = null;
        if (readyBundles.TryGetValue(bundleInfo.bundleName, out bundle))
        {
            if (func2 == null)
            {
                func2 = each => (T) each;
            }
            return Enumerable.Select<UnityEngine.Object, T>(bundle.LoadAll(typeof(T)), func2);
        }
        return Enumerable.Empty<T>();
    }

    public static void StartLoadingBundle(BundleInfo bundleInfo, bool useServerSpecific = false)
    {
        TestObjectResource(bundleInfo);
        if (!bundleInfo.tryResourcesFirst)
        {
            _LoadBundleByName("Prefabs", bundleInfo.bundleName, bundleInfo.onDemandLoading, bundleInfo.hasServerSpecific ? useServerSpecific : false);
        }
        else
        {
            bypassedBundles.Add(bundleInfo.bundleName);
        }
    }

    public static void StartLoadingSceneBundle(string bundleName, string sceneName)
    {
        if (!TestSceneResource(bundleName, sceneName))
        {
            _LoadBundleByName("Scenes", bundleName, false, false);
        }
        else
        {
            bypassedBundles.Add(bundleName);
        }
    }

    public static bool SyncFixedUpdate()
    {
        return true;
    }

    private static void SyncStart()
    {
        if (StartupParameters.RemoveParameterToProcess("noLocalResources") != null)
        {
            foreach (BundleInfo info in BundleInfo.allBundleInfos)
            {
                info.tryResourcesFirst = false;
            }
        }
    }

    private static void TestObjectResource(BundleInfo bundleInfo)
    {
        if (bundleInfo.tryResourcesFirst)
        {
            UnityEngine.Object[] objArray = Resources.LoadAll(bundleInfo.bundleResourcePath, bundleInfo.bundleTypes[0]);
            bundleInfo.tryResourcesFirst = objArray.Length > 0;
            if (bundleInfo.tryResourcesFirst)
            {
                GLog.Log(new object[] { "Resource bypass for:", bundleInfo.bundleName, bundleInfo.bundleResourcePath, objArray.Length, bundleInfo.bundleTypes[0] });
            }
        }
    }

    private static bool TestSceneResource(string bundleName, string sceneName)
    {
        string[] strArray = Directory.GetFiles(Application.dataPath, "*.unity", SearchOption.AllDirectories);
        foreach (string str in strArray)
        {
            string[] strArray2 = str.Split(new char[] { '\\' });
            if (strArray2[strArray2.Length - 1].Contains(sceneName))
            {
                return true;
            }
        }
        return false;
    }

    public static void UnloadBundle(string bundleName, bool fullUnload)
    {
        if (readyBundles.ContainsKey(bundleName))
        {
            readyBundles[bundleName].Unload(fullUnload);
            readyBundles.Remove(bundleName);
        }
        if (objects.ContainsKey(bundleName))
        {
            objects.Remove(bundleName);
        }
    }
}

