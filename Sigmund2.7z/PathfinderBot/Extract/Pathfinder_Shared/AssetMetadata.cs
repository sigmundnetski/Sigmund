﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;

public class AssetMetadata : MonoBehaviour
{
    [NonSerialized]
    private Dictionary<string, string> deserialized = null;
    public string json;

    public AssetMetadata(string data)
    {
        this.json = data;
    }

    public string GetData(string key)
    {
        if (this.deserialized == null)
        {
            this.deserialized = JsonConvert.DeserializeObject<Dictionary<string, string>>(this.json);
        }
        string str = null;
        this.deserialized.TryGetValue(key, out str);
        return str;
    }

    public void SetData(Dictionary<string, string> input)
    {
        this.deserialized = null;
        this.json = JsonConvert.SerializeObject(input);
    }

    public bool TryGetData(string key, out string result)
    {
        if (this.deserialized == null)
        {
            this.deserialized = JsonConvert.DeserializeObject<Dictionary<string, string>>(this.json);
        }
        return this.deserialized.TryGetValue(key, out result);
    }
}

