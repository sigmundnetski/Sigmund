﻿using System;
using System.Collections.Generic;

public class RoleData : DataClass
{
    public string displayName;
    public static Dictionary<int, RoleData> roleById = new Dictionary<int, RoleData>();

    public static void OnLoad(List<DataClass> objects)
    {
        for (int i = 0; i < objects.Count; i++)
        {
            RoleData data = (RoleData) objects[i];
            roleById[objects[i].id] = data;
        }
    }

    public override DataClass ParseRecord(int rowIndex)
    {
        RoleData data = new RoleData();
        DataClass.GetLCaseCellValue(1, rowIndex, out data.name);
        DataClass.GetCellValue(2, rowIndex, out data.displayName);
        return data;
    }
}

