﻿using System;
using UnityEngine;

public class EncounterPrefab : MonoBehaviour
{
    public bool allow15M;
    public bool allow30M;
    public bool allow5M;
    public bool allowUneven;
    public bool isGeneric;
}

