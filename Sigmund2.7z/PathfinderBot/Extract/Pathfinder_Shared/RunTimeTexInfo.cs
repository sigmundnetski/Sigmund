﻿using System;
using UnityEngine;

public class RunTimeTexInfo
{
    public Texture baselineTex;
    public int currentMipLevel;
    public int dataSize;
    public FilterMode filterMode;
    public TextureFormat format;
    public int height;
    public int index;
    public bool isDowngradable;
    public bool isReadable;
    private static bool mode;
    public string name;
    public static readonly RunTimeTexInfo NO_TEX = new RunTimeTexInfo(string.Empty);
    private TextureReference[] references;
    private float sqrdistanceA;
    private float sqrdistanceB;
    public Texture tex;
    public byte[] texData;
    public int width;
    public TextureWrapMode wrapMode;

    static RunTimeTexInfo()
    {
        NO_TEX.currentMipLevel = 0x7fffffff;
        NO_TEX.tex = null;
        NO_TEX.baselineTex = null;
        NO_TEX.dataSize = 0;
        NO_TEX.isReadable = false;
        NO_TEX.isDowngradable = true;
        NO_TEX.wrapMode = TextureWrapMode.Clamp;
        NO_TEX.filterMode = FilterMode.Point;
        NO_TEX.width = 0;
        NO_TEX.height = 0;
        NO_TEX.format = TextureFormat.Alpha8;
        NO_TEX.sqrdistanceA = 0f;
        NO_TEX.sqrdistanceB = 0f;
    }

    public RunTimeTexInfo(string _name)
    {
        this.name = _name;
        this.isDowngradable = true;
        this.sqrdistanceA = float.MaxValue;
        this.sqrdistanceB = float.MaxValue;
        this.references = new TextureReference[0];
    }

    public void AddRef(string texId, Material mat)
    {
        int index = SparseArray.IndexOf<TextureReference>(this.references, x => (x.textureId == texId) && (x.material == mat));
        if (index < 0)
        {
            index = (int) SparseArray.Add<TextureReference>(ref this.references, new TextureReference(texId, mat));
        }
        TextureReference reference1 = this.references[index];
        reference1.count++;
        Texture texture = (this.tex != null) ? this.tex : this.baselineTex;
        mat.SetTexture(texId, texture);
    }

    public static void ChangeMode()
    {
        mode = !mode;
    }

    public void DelRef(string texId, Material mat)
    {
        int index = SparseArray.IndexOf<TextureReference>(this.references, x => (x.textureId == texId) && (x.material == mat));
        if (index >= 0)
        {
            TextureReference reference1 = this.references[index];
            reference1.count--;
            if (this.references[index].count == 0)
            {
                this.references[index] = null;
            }
        }
        if ((SparseArray.Count<TextureReference>(this.references) == 0) && (this.tex != null))
        {
            UnityEngine.Object.Destroy(this.tex);
            this.tex = null;
        }
        Texture texture = (this.tex != null) ? this.tex : this.baselineTex;
        mat.SetTexture(texId, texture);
    }

    public float GetSqrDistance()
    {
        if (mode)
        {
            return this.sqrdistanceB;
        }
        return this.sqrdistanceA;
    }

    public long RemoveTexture()
    {
        return this.SwapTexture(NO_TEX);
    }

    public void ResetSqrDistance()
    {
        if (mode)
        {
            this.sqrdistanceB = float.MaxValue;
        }
        else
        {
            this.sqrdistanceA = float.MaxValue;
        }
    }

    public void SetSqrDistance(float input)
    {
        if (mode && (this.sqrdistanceA > input))
        {
            this.sqrdistanceA = input;
        }
        else if (!(mode || (this.sqrdistanceB <= input)))
        {
            this.sqrdistanceB = input;
        }
    }

    public long SwapTexture(RunTimeTexInfo info)
    {
        if ((info != NO_TEX) && (this.name != info.name))
        {
            throw new Exception("Unable to swap textures because they are not the same texture.");
        }
        Texture tex = this.tex;
        long num = info.dataSize - this.dataSize;
        this.tex = info.tex;
        this.currentMipLevel = info.currentMipLevel;
        this.dataSize = info.dataSize;
        this.isReadable = info.isReadable;
        this.wrapMode = info.wrapMode;
        this.filterMode = info.filterMode;
        this.width = info.width;
        this.height = info.height;
        this.format = info.format;
        if (!info.isDowngradable)
        {
            this.isDowngradable = info.isDowngradable;
        }
        if (tex != null)
        {
            UnityEngine.Object.Destroy(tex);
        }
        this.UpdateReferencedMaterials();
        return num;
    }

    public override string ToString()
    {
        return string.Concat(new object[] { 
            this.name, "_", this.tex != null, "_", this.baselineTex != null, "_", this.currentMipLevel, "_", this.dataSize, "_", this.sqrdistanceA, "_", this.sqrdistanceB, "_", this.index, "_", 
            this.references.Length
         });
    }

    public void UpdateReferencedMaterials()
    {
        Texture texture = (this.tex != null) ? this.tex : this.baselineTex;
        for (int i = 0; i < this.references.Length; i++)
        {
            if ((this.references[i] != null) && (this.references[i].material != null))
            {
                this.references[i].material.SetTexture(this.references[i].textureId, texture);
            }
        }
    }

    private class TextureReference
    {
        public int count;
        public readonly Material material;
        public readonly string textureId;

        public TextureReference(string _textureId, Material _material)
        {
            this.textureId = _textureId;
            this.material = _material;
            this.count = 0;
        }

        public override string ToString()
        {
            return string.Concat(new object[] { this.textureId, "|", this.material, "|", this.count });
        }
    }
}

