﻿using System;

internal class GFTestRestrictionLods
{
    [DataSyncTo(1)]
    public int id;
    [DataSyncTo(2)]
    public string name;
    public string nondecorated;
    [DataSyncTo(3)]
    public float speed;
}

