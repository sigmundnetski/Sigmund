﻿using System;

public class CombatAttackBonus : IDataCopyable<CombatAttackBonus>
{
    public int[] attackBonus = new int[6];

    public void Clear()
    {
        for (int i = 0; i < this.attackBonus.Length; i++)
        {
            this.attackBonus[i] = 0;
        }
    }

    public void DataCopyTo(ref CombatAttackBonus target, byte syncTargetLevel)
    {
        if (object.ReferenceEquals(target, null))
        {
            target = new CombatAttackBonus();
        }
        DataSerializerUtils.DataCopyField<int>(this.attackBonus, ref target.attackBonus);
    }

    public bool DataEquals(CombatAttackBonus target, byte syncTargetLevel)
    {
        if (object.ReferenceEquals(target, null))
        {
            return false;
        }
        return SparseArray.DeepEqualsWithIndex<int>(target.attackBonus, this.attackBonus);
    }

    public int GetSpecific(AttackType attackBonusType)
    {
        return this.attackBonus[(int) attackBonusType];
    }

    public int GetTotal(AttackType attackBonusType)
    {
        int num = this.attackBonus[0];
        if (attackBonusType == AttackType.Base)
        {
            return num;
        }
        return (num + this.attackBonus[(int) attackBonusType]);
    }

    public void SetSpecific(AttackType attackBonusType, int value)
    {
        this.attackBonus[(int) attackBonusType] = value;
    }
}

