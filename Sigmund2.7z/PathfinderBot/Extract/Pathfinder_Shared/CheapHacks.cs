﻿using GNetwork;
using System;
using System.Collections.Generic;
using System.Reflection;

public static class CheapHacks
{
    public static readonly HashSet<System.Type> CHEAP_TYPES = new HashSet<System.Type> { 
        typeof(byte), typeof(double), typeof(float), typeof(int), typeof(long), typeof(short), typeof(uint), typeof(ulong), typeof(ushort), typeof(EntityId), typeof(AttackFeatVars), typeof(CombatCooldowns.FeatCooldown), typeof(CombatRefresh.FeatUsed), typeof(CraftingQueue), typeof(InventoryItem), typeof(WeaponVars), 
        typeof(ActiveCounterInfo), typeof(ActiveEventInfo), typeof(AdvancementRecord), typeof(CombatBuffVars), typeof(CombatEffect), typeof(CombatModifier), typeof(CombatModifierCondition), typeof(Entity), typeof(MapPlace), typeof(Party.PartyInvite), typeof(Party.PartyMember), typeof(QuestRecord), typeof(RibbonBuffChannelVars), typeof(Skills), typeof(string), typeof(VentureCompanyMember)
     };

    public static bool CheckElementType(System.Type elementType)
    {
        return CHEAP_TYPES.Contains(elementType);
    }

    private static T[] CustomClassReadHelper<T>(IBitBufferRead buffer, int length, T[] baseObjArray) where T: class, CustomSerializer<T>
    {
        SparseArray.EnsureCapacity<T>(ref baseObjArray, length);
        int index = 0;
        while (index < length)
        {
            if (buffer.PopBool())
            {
                T local = default(T);
                baseObjArray[index] = local;
            }
            else if (!buffer.PopBool())
            {
                if (baseObjArray[index] == null)
                {
                    baseObjArray[index] = (T) Activator.CreateInstance(typeof(T));
                }
                baseObjArray[index].Read(buffer, ref baseObjArray[index]);
            }
            index++;
        }
        while (index < baseObjArray.Length)
        {
            baseObjArray[index] = default(T);
            index++;
        }
        return baseObjArray;
    }

    private static void CustomClassWriteHelper<T>(IBitBufferWrite buffer, Array obj, Array baseObj, byte syncTargetLevel) where T: class, IDataCopyable<T>, CustomSerializer<T>
    {
        T[] localArray = obj as T[];
        T[] localArray2 = baseObj as T[];
        for (int i = 0; i < localArray.Length; i++)
        {
            bool flag = object.ReferenceEquals(localArray[i], null);
            buffer.PushBool(flag);
            if (!flag)
            {
                bool flag2 = false;
                T target = default(T);
                if ((localArray2 != null) && (localArray2.Length > i))
                {
                    target = localArray2[i];
                    flag2 = localArray[i].DataEquals(target, syncTargetLevel);
                }
                buffer.PushBool(flag2);
                if (!flag2)
                {
                    localArray[i].Write(buffer, target);
                }
            }
        }
    }

    private static T[] CustomStructReadHelper<T>(IBitBufferRead buffer, int length, T[] baseObjArray, T fastDefault) where T: struct, CustomSerializer<T>
    {
        SparseArray.EnsureCapacity<T>(ref baseObjArray, length);
        int index = 0;
        while (index < length)
        {
            if (!buffer.PopBool())
            {
                baseObjArray[index].Read(buffer, ref baseObjArray[index]);
            }
            index++;
        }
        while (index < baseObjArray.Length)
        {
            baseObjArray[index] = fastDefault;
            index++;
        }
        return baseObjArray;
    }

    private static void CustomStructWriteHelper<T>(IBitBufferWrite buffer, Array obj, Array baseObj, T fastDefault, byte syncTargetLevel) where T: struct, IDataCopyable<T>, CustomSerializer<T>
    {
        T[] localArray = obj as T[];
        T[] localArray2 = baseObj as T[];
        for (int i = 0; i < localArray.Length; i++)
        {
            bool flag = false;
            T target = fastDefault;
            if ((localArray2 != null) && (localArray2.Length > i))
            {
                target = localArray2[i];
                flag = localArray[i].DataEquals(target, syncTargetLevel);
            }
            buffer.PushBool(flag);
            if (!flag)
            {
                localArray[i].Write(buffer, target);
            }
        }
    }

    public static bool IsArrayEqual(Array obj1, Array obj2, System.Type elementType, byte syncTargetLevel)
    {
        if (elementType == typeof(byte))
        {
            return SparseArray.DeepEqualsWithIndex<byte>((byte[]) obj1, (byte[]) obj2);
        }
        if (elementType == typeof(double))
        {
            return SparseArray.DeepEqualsWithIndex<double>((double[]) obj1, (double[]) obj2);
        }
        if (elementType == typeof(float))
        {
            return SparseArray.DeepEqualsWithIndex<float>((float[]) obj1, (float[]) obj2);
        }
        if (elementType == typeof(int))
        {
            return SparseArray.DeepEqualsWithIndex<int>((int[]) obj1, (int[]) obj2);
        }
        if (elementType == typeof(long))
        {
            return SparseArray.DeepEqualsWithIndex<long>((long[]) obj1, (long[]) obj2);
        }
        if (elementType == typeof(short))
        {
            return SparseArray.DeepEqualsWithIndex<short>((short[]) obj1, (short[]) obj2);
        }
        if (elementType == typeof(uint))
        {
            return SparseArray.DeepEqualsWithIndex<uint>((uint[]) obj1, (uint[]) obj2);
        }
        if (elementType == typeof(ulong))
        {
            return SparseArray.DeepEqualsWithIndex<ulong>((ulong[]) obj1, (ulong[]) obj2);
        }
        if (elementType == typeof(ushort))
        {
            return SparseArray.DeepEqualsWithIndex<ushort>((ushort[]) obj1, (ushort[]) obj2);
        }
        if (elementType == typeof(EntityId))
        {
            return SparseArray.DeepEqualsWithIndex<EntityId>((EntityId[]) obj1, (EntityId[]) obj2);
        }
        if (elementType == typeof(AttackFeatVars))
        {
            return SparseArray.DeepEqualsWithIndex<AttackFeatVars>((AttackFeatVars[]) obj1, (AttackFeatVars[]) obj2, syncTargetLevel, AttackFeatVars.EMPTY_MATCH);
        }
        if (elementType == typeof(CombatCooldowns.FeatCooldown))
        {
            return SparseArray.DeepEqualsWithIndex<CombatCooldowns.FeatCooldown>((CombatCooldowns.FeatCooldown[]) obj1, (CombatCooldowns.FeatCooldown[]) obj2, syncTargetLevel, CombatCooldowns.FeatCooldown.EMPTY_MATCH);
        }
        if (elementType == typeof(CombatRefresh.FeatUsed))
        {
            return SparseArray.DeepEqualsWithIndex<CombatRefresh.FeatUsed>((CombatRefresh.FeatUsed[]) obj1, (CombatRefresh.FeatUsed[]) obj2, syncTargetLevel, CombatRefresh.FeatUsed.EMPTY_MATCH);
        }
        if (elementType == typeof(CraftingQueue))
        {
            return SparseArray.DeepEqualsWithIndex<CraftingQueue>((CraftingQueue[]) obj1, (CraftingQueue[]) obj2, syncTargetLevel, CraftingQueue.EMPTY_MATCH);
        }
        if (elementType == typeof(InventoryItem))
        {
            return SparseArray.DeepEqualsWithIndex<InventoryItem>((InventoryItem[]) obj1, (InventoryItem[]) obj2, syncTargetLevel, InventoryItem.EMPTY_MATCH);
        }
        if (elementType == typeof(WeaponVars))
        {
            return SparseArray.DeepEqualsWithIndex<WeaponVars>((WeaponVars[]) obj1, (WeaponVars[]) obj2, syncTargetLevel, WeaponVars.EMPTY_MATCH);
        }
        if (elementType == typeof(ActiveCounterInfo))
        {
            return SparseArray.DeepEqualsWithIndex<ActiveCounterInfo>((ActiveCounterInfo[]) obj1, (ActiveCounterInfo[]) obj2, syncTargetLevel);
        }
        if (elementType == typeof(ActiveEventInfo))
        {
            return SparseArray.DeepEqualsWithIndex<ActiveEventInfo>((ActiveEventInfo[]) obj1, (ActiveEventInfo[]) obj2, syncTargetLevel);
        }
        if (elementType == typeof(AdvancementRecord))
        {
            return SparseArray.DeepEqualsWithIndex<AdvancementRecord>((AdvancementRecord[]) obj1, (AdvancementRecord[]) obj2, syncTargetLevel);
        }
        if (elementType == typeof(CombatBuffVars))
        {
            return SparseArray.DeepEqualsWithIndex<CombatBuffVars>((CombatBuffVars[]) obj1, (CombatBuffVars[]) obj2, syncTargetLevel);
        }
        if (elementType == typeof(CombatEffect))
        {
            return SparseArray.DeepEqualsWithIndex<CombatEffect>((CombatEffect[]) obj1, (CombatEffect[]) obj2, syncTargetLevel);
        }
        if (elementType == typeof(CombatModifier))
        {
            return SparseArray.DeepEqualsWithIndex<CombatModifier>((CombatModifier[]) obj1, (CombatModifier[]) obj2, syncTargetLevel);
        }
        if (elementType == typeof(CombatModifierCondition))
        {
            return SparseArray.DeepEqualsWithIndex<CombatModifierCondition>((CombatModifierCondition[]) obj1, (CombatModifierCondition[]) obj2, syncTargetLevel);
        }
        if (elementType == typeof(Entity))
        {
            return SparseArray.DeepEqualsWithIndex<Entity>((Entity[]) obj1, (Entity[]) obj2, syncTargetLevel);
        }
        if (elementType == typeof(MapPlace))
        {
            return SparseArray.DeepEqualsWithIndex<MapPlace>((MapPlace[]) obj1, (MapPlace[]) obj2, syncTargetLevel);
        }
        if (elementType == typeof(Party.PartyInvite))
        {
            return SparseArray.DeepEqualsWithIndex<Party.PartyInvite>((Party.PartyInvite[]) obj1, (Party.PartyInvite[]) obj2, syncTargetLevel);
        }
        if (elementType == typeof(Party.PartyMember))
        {
            return SparseArray.DeepEqualsWithIndex<Party.PartyMember>((Party.PartyMember[]) obj1, (Party.PartyMember[]) obj2, syncTargetLevel);
        }
        if (elementType == typeof(QuestRecord))
        {
            return SparseArray.DeepEqualsWithIndex<QuestRecord>((QuestRecord[]) obj1, (QuestRecord[]) obj2, syncTargetLevel);
        }
        if (elementType == typeof(RibbonBuffChannelVars))
        {
            return SparseArray.DeepEqualsWithIndex<RibbonBuffChannelVars>((RibbonBuffChannelVars[]) obj1, (RibbonBuffChannelVars[]) obj2, syncTargetLevel);
        }
        if (elementType == typeof(Skills))
        {
            return SparseArray.DeepEqualsWithIndex<Skills>((Skills[]) obj1, (Skills[]) obj2, syncTargetLevel);
        }
        if (elementType == typeof(string))
        {
            return SparseArray.StringEqualsWithIndex((string[]) obj1, (string[]) obj2);
        }
        if (elementType != typeof(VentureCompanyMember))
        {
            throw new NotImplementedException("Not a valid elementType.  Only call this if CheckElementType() returns true.");
        }
        return SparseArray.DeepEqualsWithIndex<VentureCompanyMember>((VentureCompanyMember[]) obj1, (VentureCompanyMember[]) obj2, syncTargetLevel);
    }

    public static bool ReadSimpleArray(IBitBufferRead buffer, FieldInfo field, System.Type type, byte defaultLevel, int length, ref Array baseObjArray)
    {
        bool flag = true;
        if (type == typeof(ActiveCounterInfo[]))
        {
            baseObjArray = CustomClassReadHelper<ActiveCounterInfo>(buffer, length, (ActiveCounterInfo[]) baseObjArray);
            return flag;
        }
        if (type == typeof(AttackFeatVars[]))
        {
            baseObjArray = CustomStructReadHelper<AttackFeatVars>(buffer, length, (AttackFeatVars[]) baseObjArray, AttackFeatVars.EMPTY);
            return flag;
        }
        if (type == typeof(CombatRefresh.FeatUsed[]))
        {
            baseObjArray = CustomStructReadHelper<CombatRefresh.FeatUsed>(buffer, length, (CombatRefresh.FeatUsed[]) baseObjArray, CombatRefresh.FeatUsed.EMPTY);
            return flag;
        }
        if (type == typeof(CombatCooldowns.FeatCooldown[]))
        {
            baseObjArray = CustomStructReadHelper<CombatCooldowns.FeatCooldown>(buffer, length, (CombatCooldowns.FeatCooldown[]) baseObjArray, CombatCooldowns.FeatCooldown.EMPTY);
            return flag;
        }
        if (type == typeof(InventoryItem[]))
        {
            baseObjArray = CustomStructReadHelper<InventoryItem>(buffer, length, (InventoryItem[]) baseObjArray, InventoryItem.EMPTY);
            return flag;
        }
        if (type == typeof(RibbonBuffChannelVars[]))
        {
            baseObjArray = CustomClassReadHelper<RibbonBuffChannelVars>(buffer, length, (RibbonBuffChannelVars[]) baseObjArray);
            return flag;
        }
        if (type == typeof(Skills[]))
        {
            baseObjArray = CustomClassReadHelper<Skills>(buffer, length, (Skills[]) baseObjArray);
            return flag;
        }
        if (type == typeof(WeaponVars[]))
        {
            baseObjArray = CustomStructReadHelper<WeaponVars>(buffer, length, (WeaponVars[]) baseObjArray, WeaponVars.EMPTY);
            return flag;
        }
        return false;
    }

    public static bool WriteSimpleArray(DataSerializer back, IBitBufferWrite buffer, FieldInfo field, System.Type type, byte defaultLevel, byte targetLevel, Array obj, Array baseObj)
    {
        bool flag = true;
        if (type == typeof(ActiveCounterInfo[]))
        {
            CustomClassWriteHelper<ActiveCounterInfo>(buffer, obj, baseObj, targetLevel);
            return flag;
        }
        if (type == typeof(AttackFeatVars[]))
        {
            CustomStructWriteHelper<AttackFeatVars>(buffer, obj, baseObj, AttackFeatVars.EMPTY, targetLevel);
            return flag;
        }
        if (type == typeof(CombatRefresh.FeatUsed[]))
        {
            CustomStructWriteHelper<CombatRefresh.FeatUsed>(buffer, obj, baseObj, CombatRefresh.FeatUsed.EMPTY, targetLevel);
            return flag;
        }
        if (type == typeof(CombatCooldowns.FeatCooldown[]))
        {
            CustomStructWriteHelper<CombatCooldowns.FeatCooldown>(buffer, obj, baseObj, CombatCooldowns.FeatCooldown.EMPTY, targetLevel);
            return flag;
        }
        if (type == typeof(InventoryItem[]))
        {
            CustomStructWriteHelper<InventoryItem>(buffer, obj, baseObj, InventoryItem.EMPTY, targetLevel);
            return flag;
        }
        if (type == typeof(RibbonBuffChannelVars[]))
        {
            CustomClassWriteHelper<RibbonBuffChannelVars>(buffer, obj, baseObj, targetLevel);
            return flag;
        }
        if (type == typeof(Skills[]))
        {
            CustomClassWriteHelper<Skills>(buffer, obj, baseObj, targetLevel);
            return flag;
        }
        if (type == typeof(WeaponVars[]))
        {
            CustomStructWriteHelper<WeaponVars>(buffer, obj, baseObj, WeaponVars.EMPTY, targetLevel);
            return flag;
        }
        if (type == typeof(AttackFeatVars[]))
        {
            WriteSimpleArrayHelper<AttackFeatVars>(back, buffer, field, typeof(AttackFeatVars), defaultLevel, (AttackFeatVars[]) obj, (AttackFeatVars[]) baseObj);
            return flag;
        }
        if (type == typeof(CombatCooldowns.FeatCooldown[]))
        {
            WriteSimpleArrayHelper<CombatCooldowns.FeatCooldown>(back, buffer, field, typeof(CombatCooldowns.FeatCooldown), defaultLevel, (CombatCooldowns.FeatCooldown[]) obj, (CombatCooldowns.FeatCooldown[]) baseObj);
            return flag;
        }
        if (type == typeof(CombatRefresh.FeatUsed[]))
        {
            WriteSimpleArrayHelper<CombatRefresh.FeatUsed>(back, buffer, field, typeof(CombatRefresh.FeatUsed), defaultLevel, (CombatRefresh.FeatUsed[]) obj, (CombatRefresh.FeatUsed[]) baseObj);
            return flag;
        }
        if (type == typeof(CraftingQueue[]))
        {
            WriteSimpleArrayHelper<CraftingQueue>(back, buffer, field, typeof(CraftingQueue), defaultLevel, (CraftingQueue[]) obj, (CraftingQueue[]) baseObj);
            return flag;
        }
        if (type == typeof(WeaponVars[]))
        {
            WriteSimpleArrayHelper<WeaponVars>(back, buffer, field, typeof(WeaponVars), defaultLevel, (WeaponVars[]) obj, (WeaponVars[]) baseObj);
            return flag;
        }
        if (type == typeof(ActiveEventInfo[]))
        {
            WriteSimpleArrayHelper<ActiveEventInfo>(back, buffer, field, typeof(ActiveEventInfo), defaultLevel, (ActiveEventInfo[]) obj, (ActiveEventInfo[]) baseObj);
            return flag;
        }
        if (type == typeof(AdvancementRecord[]))
        {
            WriteSimpleArrayHelper<AdvancementRecord>(back, buffer, field, typeof(AdvancementRecord), defaultLevel, (AdvancementRecord[]) obj, (AdvancementRecord[]) baseObj);
            return flag;
        }
        if (type == typeof(CombatBuffVars[]))
        {
            WriteSimpleArrayHelper<CombatBuffVars>(back, buffer, field, typeof(CombatBuffVars), defaultLevel, (CombatBuffVars[]) obj, (CombatBuffVars[]) baseObj);
            return flag;
        }
        if (type == typeof(CombatEffect[]))
        {
            WriteSimpleArrayHelper<CombatEffect>(back, buffer, field, typeof(CombatEffect), defaultLevel, (CombatEffect[]) obj, (CombatEffect[]) baseObj);
            return flag;
        }
        if (type == typeof(CombatModifier[]))
        {
            WriteSimpleArrayHelper<CombatModifier>(back, buffer, field, typeof(CombatModifier), defaultLevel, (CombatModifier[]) obj, (CombatModifier[]) baseObj);
            return flag;
        }
        if (type == typeof(CombatModifierCondition[]))
        {
            WriteSimpleArrayHelper<CombatModifierCondition>(back, buffer, field, typeof(CombatModifierCondition), defaultLevel, (CombatModifierCondition[]) obj, (CombatModifierCondition[]) baseObj);
            return flag;
        }
        if (type == typeof(Entity[]))
        {
            WriteSimpleArrayHelper<Entity>(back, buffer, field, typeof(Entity), defaultLevel, (Entity[]) obj, (Entity[]) baseObj);
            return flag;
        }
        if (type == typeof(MapPlace[]))
        {
            WriteSimpleArrayHelper<MapPlace>(back, buffer, field, typeof(MapPlace), defaultLevel, (MapPlace[]) obj, (MapPlace[]) baseObj);
            return flag;
        }
        if (type == typeof(Party.PartyInvite[]))
        {
            WriteSimpleArrayHelper<Party.PartyInvite>(back, buffer, field, typeof(Party.PartyInvite), defaultLevel, (Party.PartyInvite[]) obj, (Party.PartyInvite[]) baseObj);
            return flag;
        }
        if (type == typeof(Party.PartyMember[]))
        {
            WriteSimpleArrayHelper<Party.PartyMember>(back, buffer, field, typeof(Party.PartyMember), defaultLevel, (Party.PartyMember[]) obj, (Party.PartyMember[]) baseObj);
            return flag;
        }
        if (type == typeof(QuestRecord[]))
        {
            WriteSimpleArrayHelper<QuestRecord>(back, buffer, field, typeof(QuestRecord), defaultLevel, (QuestRecord[]) obj, (QuestRecord[]) baseObj);
            return flag;
        }
        if (type == typeof(string[]))
        {
            WriteSimpleArrayHelper<string>(back, buffer, field, typeof(string), defaultLevel, (string[]) obj, (string[]) baseObj);
            return flag;
        }
        if (type == typeof(VentureCompanyMember[]))
        {
            WriteSimpleArrayHelper<VentureCompanyMember>(back, buffer, field, typeof(VentureCompanyMember), defaultLevel, (VentureCompanyMember[]) obj, (VentureCompanyMember[]) baseObj);
            return flag;
        }
        return false;
    }

    private static void WriteSimpleArrayHelper<T>(DataSerializer back, IBitBufferWrite buffer, FieldInfo field, System.Type elementType, byte defaultLevel, T[] obj, T[] baseObj)
    {
        for (int i = 0; i < obj.Length; i++)
        {
            object baseValue = null;
            if ((baseObj != null) && (baseObj.Length > i))
            {
                baseValue = baseObj[i];
            }
            object currentValue = obj[i];
            back.WriteCplxArrayIndex(buffer, field, elementType, defaultLevel, currentValue, baseValue, null, null);
        }
    }
}

