﻿using System;

public enum CombatModifierType : byte
{
    AOE = 7,
    ATTACK_BONUS = 13,
    ATTACK_MODIFIER = 2,
    ATTACK_STATE = 3,
    BUFF = 0,
    DEFENSE = 10,
    DEFENSE_TARGET = 0x10,
    DISTANCE = 6,
    HITPOINTS = 11,
    INSTANT = 5,
    KEYWORD = 15,
    MAX_ENCUMBRANCE = 12,
    POWER = 0x15,
    RECOVERY = 9,
    REGENERATION = 20,
    RESISTANCE = 0x12,
    RESISTANCE_TARGET = 0x11,
    SKILL = 14,
    SPEED = 0x13,
    STACK = 1,
    STATE = 4,
    WEAPON = 8
}

