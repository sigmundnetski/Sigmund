﻿using System;
using System.Runtime.InteropServices;
using UnityEngine;

public class CombatEffect : IDataCopyable<CombatEffect>
{
    public int attackFeatId;
    public int attackMarginOfSuccess;
    public CombatConstants.AttackState attackState;
    public CombatModifier[] combatMods;
    public float distance;
    public uint effectModifier;
    public Combat.EffectType effectType;
    public int hitPointChange;
    public int itemId;
    public byte itemUpgrade;
    public Vector3 originPosition;
    public EntityId sourceEntityId;
    public EntityId targetEntityId;
    public TargetType targetType;
    public Type type;
    public EntityId utilityFeatTargetEntityId;
    public bool wasCriticalHit;

    public CombatEffect()
    {
    }

    public CombatEffect(CombatEffect sourceEffect, TargetType targetType_)
    {
        this.targetType = targetType_;
        this.type = sourceEffect.type;
        this.sourceEntityId = sourceEffect.sourceEntityId;
        this.targetEntityId = sourceEffect.targetEntityId;
        this.hitPointChange = sourceEffect.hitPointChange;
        this.originPosition = sourceEffect.originPosition;
        this.attackFeatId = sourceEffect.attackFeatId;
        this.distance = sourceEffect.distance;
        this.attackState = sourceEffect.attackState;
        this.wasCriticalHit = sourceEffect.wasCriticalHit;
        this.attackMarginOfSuccess = sourceEffect.attackMarginOfSuccess;
        this.utilityFeatTargetEntityId = (sourceEffect.utilityFeatTarget != null) ? sourceEffect.utilityFeatTarget.entityId : EntityId.INVALID_ID;
        this.effectType = sourceEffect.effectType;
        this.effectModifier = sourceEffect.effectModifier;
        this.itemId = sourceEffect.itemId;
        this.itemUpgrade = sourceEffect.itemUpgrade;
    }

    public CombatEffect(int healAmount, CombatEffect sourceEffect)
    {
        this.type = Type.HEAL;
        this.hitPointChange = healAmount;
        this.attackState = sourceEffect.attackState;
        this.targetType = sourceEffect.targetType;
        this.sourceEntityId = sourceEffect.sourceEntityId;
        this.targetEntityId = sourceEffect.targetEntityId;
        this.utilityFeatTargetEntityId = (sourceEffect.utilityFeatTarget != null) ? sourceEffect.utilityFeatTarget.entityId : EntityId.INVALID_ID;
        this.originPosition = sourceEffect.originPosition;
        this.attackFeatId = sourceEffect.attackFeatId;
        this.distance = sourceEffect.distance;
        this.attackMarginOfSuccess = sourceEffect.attackMarginOfSuccess;
        this.effectType = sourceEffect.effectType;
        this.effectModifier = sourceEffect.effectModifier;
        this.itemId = sourceEffect.itemId;
        this.itemUpgrade = sourceEffect.itemUpgrade;
    }

    public CombatEffect(CombatVars source_, CombatVars target_, Combat.EffectType effectType_, CombatVars utilityFeatTarget_, TargetType targetType_ = 0)
    {
        this.attackState = CombatConstants.AttackState.NONE;
        this.type = Type.FEAT;
        this.targetType = targetType_;
        this.sourceEntityId = (source_ != null) ? source_.entityId : EntityId.INVALID_ID;
        this.targetEntityId = (target_ != null) ? target_.entityId : EntityId.INVALID_ID;
        this.utilityFeatTargetEntityId = (utilityFeatTarget_ != null) ? utilityFeatTarget_.entityId : EntityId.INVALID_ID;
        this.originPosition = CombatCore.getPosition(source_.entityId);
        this.effectType = effectType_;
        this.hitPointChange = 0;
        this.attackFeatId = 0;
        this.distance = 0f;
        this.attackMarginOfSuccess = 0;
        this.effectModifier = 100;
        this.itemId = 0;
        this.itemUpgrade = 0;
    }

    public CombatEffect(CombatModifier[] combatMods_, CombatVars source_, CombatVars target_, TargetType targetType_, Combat.EffectType effectType_)
    {
        this.attackState = CombatConstants.AttackState.NONE;
        this.type = Type.COMBAT_MODIFIER;
        this.targetType = targetType_;
        this.combatMods = combatMods_;
        this.sourceEntityId = (source_ != null) ? source_.entityId : EntityId.INVALID_ID;
        this.targetEntityId = (target_ != null) ? target_.entityId : EntityId.INVALID_ID;
        this.originPosition = CombatCore.getPosition(source_.entityId);
        this.effectType = effectType_;
        this.hitPointChange = 0;
        this.attackFeatId = 0;
        this.distance = 0f;
        this.attackMarginOfSuccess = 0;
        this.effectModifier = 100;
        this.utilityFeatTargetEntityId = EntityId.INVALID_ID;
        this.itemId = 0;
        this.itemUpgrade = 0;
    }

    public CombatEffect(OffensiveFeatData attack_, CombatVars source_, CombatVars target_, float dist_, TargetType targetType_, int itemId_, byte itemUpgrade_)
    {
        this.attackState = CombatConstants.AttackState.NONE;
        this.type = Type.ATTACK;
        this.targetType = targetType_;
        this.attackFeatId = attack_.id;
        this.sourceEntityId = (source_ != null) ? source_.entityId : EntityId.INVALID_ID;
        this.targetEntityId = (target_ != null) ? target_.entityId : EntityId.INVALID_ID;
        this.distance = dist_;
        this.attackMarginOfSuccess = 0;
        this.originPosition = CombatCore.getPosition(source_.entityId);
        this.hitPointChange = 0;
        this.wasCriticalHit = false;
        this.effectType = attack_.effectType;
        this.itemId = itemId_;
        this.itemUpgrade = itemUpgrade_;
        this.utilityFeatTargetEntityId = EntityId.INVALID_ID;
    }

    public void AddCombatMod(CombatModifier mod)
    {
        if (this.combatMods == null)
        {
            this.combatMods = new CombatModifier[10];
        }
        SparseArray.Add<CombatModifier>(ref this.combatMods, mod);
    }

    public void AddCombatMods(CombatModifier[] mods)
    {
        if (this.combatMods == null)
        {
            this.combatMods = new CombatModifier[10];
        }
        for (int i = 0; i < mods.Length; i++)
        {
            SparseArray.Add<CombatModifier>(ref this.combatMods, mods[i]);
        }
    }

    public void DataCopyTo(ref CombatEffect target, byte syncTargetLevel)
    {
        target.type = this.type;
        target.targetType = this.targetType;
        target.effectType = this.effectType;
        target.sourceEntityId = this.sourceEntityId;
        target.targetEntityId = this.targetEntityId;
        target.utilityFeatTargetEntityId = this.utilityFeatTargetEntityId;
        target.hitPointChange = this.hitPointChange;
        target.originPosition = this.originPosition;
        target.attackFeatId = this.attackFeatId;
        target.distance = this.distance;
        target.attackState = this.attackState;
        target.wasCriticalHit = this.wasCriticalHit;
        target.itemId = this.itemId;
        target.itemUpgrade = this.itemUpgrade;
        target.attackMarginOfSuccess = this.attackMarginOfSuccess;
        target.effectModifier = this.effectModifier;
        SparseArray.DeepCopyTo<CombatModifier>(this.combatMods, ref target.combatMods, syncTargetLevel, null);
    }

    public bool DataEquals(CombatEffect target, byte syncTargetLevel)
    {
        bool flag = true;
        flag &= target.type == this.type;
        flag &= target.targetType == this.targetType;
        flag &= target.effectType == this.effectType;
        flag &= target.sourceEntityId == this.sourceEntityId;
        flag &= target.targetEntityId == this.targetEntityId;
        flag &= target.utilityFeatTargetEntityId == this.utilityFeatTargetEntityId;
        flag &= target.hitPointChange == this.hitPointChange;
        flag &= target.originPosition == this.originPosition;
        flag &= target.attackFeatId == this.attackFeatId;
        flag &= target.distance == this.distance;
        flag &= target.attackState == this.attackState;
        flag &= target.wasCriticalHit == this.wasCriticalHit;
        flag &= target.itemId == this.itemId;
        flag &= target.itemUpgrade == this.itemUpgrade;
        flag &= target.attackMarginOfSuccess == this.attackMarginOfSuccess;
        flag &= target.effectModifier == this.effectModifier;
        return (flag & SparseArray.DeepEqualsWithIndex<CombatModifier>(this.combatMods, target.combatMods, syncTargetLevel));
    }

    public OffensiveFeatData attack
    {
        get
        {
            OffensiveFeatData data;
            OffensiveFeatData.featsById.TryGetValue(this.attackFeatId, out data);
            return data;
        }
    }

    public CombatVars source
    {
        get
        {
            CombatVars vars;
            CombatCore.allCombatVars.TryGetValue(this.sourceEntityId, out vars);
            return vars;
        }
    }

    public CombatVars target
    {
        get
        {
            CombatVars vars;
            CombatCore.allCombatVars.TryGetValue(this.targetEntityId, out vars);
            return vars;
        }
    }

    public CombatVars utilityFeatTarget
    {
        get
        {
            CombatVars vars;
            CombatCore.allCombatVars.TryGetValue(this.utilityFeatTargetEntityId, out vars);
            return vars;
        }
    }

    public enum TargetType : byte
    {
        ATTACKER = 2,
        PRIMARY = 0,
        SECONDARY = 1
    }

    public enum Type : byte
    {
        ATTACK = 0,
        COMBAT_MODIFIER = 1,
        FEAT = 2,
        HEAL = 3
    }
}

