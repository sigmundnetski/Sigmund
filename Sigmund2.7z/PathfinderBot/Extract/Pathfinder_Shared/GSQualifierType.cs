﻿using System;

public enum GSQualifierType
{
    TARGET,
    CONDITION,
    EQUIVALENCE,
    NONEQUIVALENCE
}

