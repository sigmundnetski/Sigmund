﻿using System;
using System.Collections.Generic;

internal class TypeDefinitionCacheKeyComparer : IEqualityComparer<TypeDefinitionCacheKey>
{
    public static readonly TypeDefinitionCacheKeyComparer Instance = new TypeDefinitionCacheKeyComparer();

    public bool Equals(TypeDefinitionCacheKey x, TypeDefinitionCacheKey y)
    {
        return x.Equals(y);
    }

    public int GetHashCode(TypeDefinitionCacheKey obj)
    {
        return obj.GetHashCode();
    }
}

