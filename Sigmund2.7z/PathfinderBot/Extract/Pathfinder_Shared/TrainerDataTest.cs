﻿using System;
using System.Collections.Generic;

public class TrainerDataTest : UUnitTestCase
{
    [UUnitSystemTestMethod]
    public void CheckForInvalidNulls()
    {
        byte num = 0;
        for (byte i = 1; i == (num + 1); i = (byte) (i + 1))
        {
            foreach (KeyValuePair<int, TrainerData2> pair in TrainerData2.trainersById)
            {
                foreach (TrainerLevel level in pair.Value.CompleteTrainerLevels(i))
                {
                    UUnitAssert.NotNull(level, "Null object not expected.");
                    num = Math.Max(num, level.buildingLevel);
                }
            }
        }
    }

    [UUnitSystemTestMethod]
    public void GetSupportLevel()
    {
        FeatData data = null;
        byte num3;
        int settlementDataId = 0;
        int id = 0;
        foreach (KeyValuePair<string, SettlementData> pair in SettlementData.settlementsByName)
        {
            if (pair.Key.Contains("craft"))
            {
                settlementDataId = pair.Value.id;
            }
            if (pair.Key.Contains("wiz"))
            {
                id = pair.Value.id;
            }
        }
        foreach (KeyValuePair<int, FeatData> pair2 in FeatDatabase.allFeatsById)
        {
            if (pair2.Value.name.Contains("alchemist"))
            {
                data = pair2.Value;
            }
        }
        for (num3 = 1; num3 < 20; num3 = (byte) (num3 + 1))
        {
            UUnitAssert.Equals((int) num3, (int) TrainerData2.GetSupportLevel(settlementDataId, num3, data.featAdvancementId), "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        }
        foreach (KeyValuePair<int, FeatData> pair2 in FeatDatabase.allFeatsById)
        {
            if (pair2.Value.name.Contains("power"))
            {
                data = pair2.Value;
            }
        }
        for (num3 = 1; num3 < 20; num3 = (byte) (num3 + 1))
        {
            UUnitAssert.Equals((int) (num3 * 2), (int) TrainerData2.GetSupportLevel(id, num3, data.featAdvancementId), "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        }
    }

    public void SettlementSupport()
    {
        foreach (KeyValuePair<int, FeatAdvancementData> pair in FeatAdvancementData.dataByFeatAdvancementId)
        {
            byte num = 0xff;
            byte num2 = 0;
            foreach (KeyValuePair<int, SettlementData> pair2 in SettlementData.settlementsByDataId)
            {
                byte num3 = TrainerData2.GetSupportLevel(pair2.Key, 15, pair.Key);
                num = Math.Min(num, num3);
                num2 = Math.Max(num2, num3);
            }
            if (((num != 0xff) && (num2 != 0)) && (num != num2))
            {
                return;
            }
        }
        UUnitAssert.Fail("Error: Every settlement is providing identical support for every skill - This should not happen");
    }

    protected override void SetUp()
    {
        UUnitTestCase.LoadRealStaticData();
    }
}

