﻿using System;
using System.Collections.Generic;
using System.Linq;

public class UUnitConsoleRunner
{
    private static KeyValuePair<string, string> GetClassAndMethodName(string arg)
    {
        arg = arg.ToLower();
        string[] strArray = (from each in arg.Split(new char[] { ':' })
            where !string.IsNullOrEmpty(each)
            select each).ToArray<string>();
        string key = (strArray.Length > 0) ? strArray[0] : string.Empty;
        return new KeyValuePair<string, string>(key, (strArray.Length > 1) ? strArray[1] : string.Empty);
    }

    public static bool Run()
    {
        bool pause = StartupParameters.RemoveParameterToProcess("pause") != null;
        bool teamCityOutput = StartupParameters.RemoveParameterToProcess("teamcityoutput") != null;
        bool flag3 = RunTests<UUnitTestMethod>(StartupParameters.RemoveParameterToProcess("unittest"), pause, teamCityOutput);
        bool flag4 = RunTests<UUnitProfileMethod>(StartupParameters.RemoveParameterToProcess("unitprofile"), pause, teamCityOutput);
        bool flag5 = RunTests<UUnitProfileMethod>(StartupParameters.RemoveParameterToProcess("profiletest"), pause, teamCityOutput);
        bool flag6 = RunTests<UUnitSystemTestMethod>(StartupParameters.RemoveParameterToProcess("systemtest"), pause, teamCityOutput);
        return (((flag3 || flag4) || flag5) || flag6);
    }

    public static bool RunTests<AttrType>(string commandArg, bool pause, bool teamCityOutput) where AttrType: UBaseAttribute
    {
        List<KeyValuePair<string, string>> classAndMethodNames = null;
        if (commandArg == null)
        {
            return false;
        }
        if (!(commandArg == string.Empty))
        {
            classAndMethodNames = new List<KeyValuePair<string, string>>();
            foreach (string str in commandArg.Split(new char[] { ' ' }))
            {
                classAndMethodNames.Add(GetClassAndMethodName(str));
            }
            if (classAndMethodNames.Count == 0)
            {
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.WriteLine("Couldn't parse method name, performing all tests");
                classAndMethodNames = null;
            }
        }
        GLog.LogDestination logDestination = GLog.logDestination;
        GLog.SetLogDestination(GLog.LogDestination.NOWHERE);
        UUnitTestSuite suite = new UUnitTestSuite();
        suite.FindAndAddAllTestCases<AttrType>(classAndMethodNames);
        Console.Out.WriteLine("Running " + typeof(AttrType).Name);
        UUnitTestResult result = suite.RunAll();
        List<string> list2 = null;
        if (teamCityOutput)
        {
            list2 = result.TeamCitySummary();
        }
        else
        {
            list2 = result.Summary();
        }
        foreach (string str2 in list2)
        {
            if (str2.Contains(" - FAILURE"))
            {
                Console.ForegroundColor = ConsoleColor.Red;
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Gray;
            }
            Console.Write(str2 + "\n");
        }
        if (pause)
        {
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine("Press return.");
            Console.ReadLine();
        }
        GLog.SetLogDestination(logDestination);
        Console.ForegroundColor = ConsoleColor.Gray;
        return true;
    }
}

