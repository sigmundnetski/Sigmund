﻿using GNetwork;
using Newtonsoft.Json;
using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

[StructLayout(LayoutKind.Sequential)]
public struct InventoryItem : IDataCopyable<InventoryItem>, CustomSerializer<InventoryItem>
{
    private const int I_RECORD_SIZE = 7;
    public static InventoryItem EMPTY;
    public static Predicate<InventoryItem> EMPTY_MATCH;
    [DataRestrict]
    public int[] i;
    [DataRestrict, JsonIgnore]
    private BasicItemData itemData;
    [JsonIgnore]
    public int staticItemId;
    [JsonIgnore]
    public uint quantity;
    [JsonIgnore]
    public byte upgrade;
    [JsonIgnore]
    public byte durability;
    [JsonIgnore]
    public int userColorId1;
    [JsonIgnore]
    public int userColorId2;
    [JsonIgnore]
    public int materialColorId;
    public string GetName()
    {
        if (!((this.itemData != null) || ItemDatabase.itemById.TryGetValue(this.staticItemId, out this.itemData)))
        {
            return "<INVALID>";
        }
        return this.itemData.name;
    }

    public string GetDisplayName(bool displayDurability = true)
    {
        if (!((this.itemData != null) || ItemDatabase.itemById.TryGetValue(this.staticItemId, out this.itemData)))
        {
            return "<INVALID>";
        }
        return this.itemData.GetDisplayName(this.upgrade, this.quantity, this.durability, displayDurability);
    }

    public string GetDescription()
    {
        if (!((this.itemData != null) || ItemDatabase.itemById.TryGetValue(this.staticItemId, out this.itemData)))
        {
            return "<INVALID>";
        }
        return this.itemData.description;
    }

    public ushort GetQuality()
    {
        if (!((this.itemData != null) || ItemDatabase.itemById.TryGetValue(this.staticItemId, out this.itemData)))
        {
            return 0;
        }
        return this.itemData.GetQuality(this.upgrade);
    }

    public float GetEncumbrance()
    {
        if (!((this.itemData != null) || ItemDatabase.itemById.TryGetValue(this.staticItemId, out this.itemData)))
        {
            return 0f;
        }
        return (this.itemData.encumbrance * this.quantity);
    }

    public byte GetTier()
    {
        if (!((this.itemData != null) || ItemDatabase.itemById.TryGetValue(this.staticItemId, out this.itemData)))
        {
            return 0;
        }
        return this.itemData.tier;
    }

    public InventoryItem(int setItemId, uint setQuantity, byte setUpgrade, byte setDurability)
    {
        this.staticItemId = setItemId;
        ItemDatabase.itemById.TryGetValue(this.staticItemId, out this.itemData);
        this.quantity = setQuantity;
        this.upgrade = setUpgrade;
        this.durability = setDurability;
        this.userColorId1 = this.userColorId2 = this.materialColorId = 0;
        this.i = new int[7];
    }

    public InventoryItem(int setItemId, uint setQuantity, byte setUpgrade, byte setDurability, int usr1, int usr2, int mat)
    {
        this.staticItemId = setItemId;
        ItemDatabase.itemById.TryGetValue(this.staticItemId, out this.itemData);
        this.quantity = setQuantity;
        this.upgrade = setUpgrade;
        this.durability = setDurability;
        this.userColorId1 = usr1;
        this.userColorId2 = usr2;
        this.materialColorId = mat;
        this.i = new int[7];
    }

    public bool Stackable(InventoryItem other)
    {
        return (((((this.staticItemId != 0) && (this.staticItemId == other.staticItemId)) && ((this.upgrade == other.upgrade) && (this.durability == other.durability))) && ((this.materialColorId == other.materialColorId) && (this.userColorId1 == other.userColorId1))) && (this.userColorId2 == other.userColorId2));
    }

    public static InventoryItem ChangeQuantity(InventoryItem src, uint newQty)
    {
        return new InventoryItem(src.staticItemId, newQty, src.upgrade, src.durability, src.userColorId1, src.userColorId2, src.materialColorId);
    }

    public static InventoryItem ChangeDurability(InventoryItem src, byte newDurability)
    {
        return new InventoryItem(src.staticItemId, src.quantity, src.upgrade, newDurability, src.userColorId1, src.userColorId2, src.materialColorId);
    }

    public static InventoryItem Recolor(InventoryItem src, int newColor, bool isPrimary)
    {
        if (isPrimary)
        {
            return new InventoryItem(src.staticItemId, src.quantity, src.upgrade, src.durability, newColor, src.userColorId2, src.materialColorId);
        }
        return new InventoryItem(src.staticItemId, src.quantity, src.upgrade, src.durability, src.userColorId1, newColor, src.materialColorId);
    }

    public void DataCopyTo(ref InventoryItem target, byte syncTargetLevel)
    {
        target = ChangeQuantity(this, this.quantity);
    }

    public bool DataEquals(InventoryItem other, byte syncTargetLevel)
    {
        return (((((this.staticItemId == other.staticItemId) && (this.quantity == other.quantity)) && ((this.upgrade == other.upgrade) && (this.durability == other.durability))) && ((this.userColorId1 == other.userColorId1) && (this.userColorId2 == other.userColorId2))) && (this.materialColorId == other.materialColorId));
    }

    public bool DataEqualsIgnoreQuantity(InventoryItem other)
    {
        return (((((this.staticItemId == other.staticItemId) && (this.upgrade == other.upgrade)) && ((this.durability == other.durability) && (this.userColorId1 == other.userColorId1))) && (this.userColorId2 == other.userColorId2)) && (this.materialColorId == other.materialColorId));
    }

    [OnSerializing]
    internal void OnSerializingMethod(StreamingContext context)
    {
        if (this.i == null)
        {
            this.i = new int[7];
        }
        RecordUtils.SetInt(this.i, this.staticItemId, 0);
        RecordUtils.SetUInt(this.i, this.quantity, 1);
        RecordUtils.SetByte(this.i, this.upgrade, 2);
        RecordUtils.SetByte(this.i, this.durability, 3);
        RecordUtils.SetInt(this.i, this.userColorId1, 4);
        RecordUtils.SetInt(this.i, this.userColorId2, 5);
        RecordUtils.SetInt(this.i, this.materialColorId, 6);
    }

    [OnDeserialized]
    internal void OnDeserializedMethod(StreamingContext context)
    {
        if (this.i == null)
        {
            this.i = new int[7];
        }
        this.staticItemId = RecordUtils.GetInt(this.i, 0);
        this.quantity = RecordUtils.GetUInt(this.i, 1);
        this.upgrade = RecordUtils.GetByte(this.i, 2);
        this.durability = RecordUtils.GetByte(this.i, 3);
        this.userColorId1 = RecordUtils.GetInt(this.i, 4);
        this.userColorId2 = RecordUtils.GetInt(this.i, 5);
        this.materialColorId = RecordUtils.GetInt(this.i, 6);
    }

    public override bool Equals(object obj)
    {
        return (((obj != null) && (obj is InventoryItem)) && this.DataEquals((InventoryItem) obj, 0xff));
    }

    public override int GetHashCode()
    {
        return base.GetHashCode();
    }

    public void Write(IBitBufferWrite buffer, InventoryItem prev)
    {
        buffer.PushInt(this.staticItemId);
        buffer.PushUInt(this.quantity);
        buffer.PushByte(this.upgrade);
        buffer.PushByte(this.durability);
        buffer.PushInt(this.userColorId1);
        buffer.PushInt(this.userColorId2);
        buffer.PushInt(this.materialColorId);
    }

    public void Read(IBitBufferRead buffer, ref InventoryItem prev)
    {
        prev = new InventoryItem(buffer.PopInt(), buffer.PopUInt(), buffer.PopByte(), buffer.PopByte(), buffer.PopInt(), buffer.PopInt(), buffer.PopInt());
    }

    public override string ToString()
    {
        return string.Concat(new object[] { "<InventoryItem: ", this.GetName(), " +", this.upgrade, " (", this.quantity, ") [", this.staticItemId, "]>" });
    }

    static InventoryItem()
    {
        EMPTY = new InventoryItem();
        EMPTY_MATCH = each => each.staticItemId == 0;
    }
}

