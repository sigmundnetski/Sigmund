﻿using GNetwork;
using GNGUI;
using System;
using UnityEngine;

public class FpsGui : MonoBehaviour
{
    private float accum = 0f;
    private UISlicedSprite background;
    private float bgAlpha = 1f;
    private Color color = Color.white;
    private int frames = 0;
    public float frequency = 0.5f;
    private UILabel label;
    public int nbDecimal = 1;
    private string sFPS = "";
    public static FpsGui singleton;
    private float timeSinceUpdate = 0f;
    public bool updateColor = true;

    public void Awake()
    {
        singleton = this;
    }

    private void FixedUpdate()
    {
        this.timeSinceUpdate += Time.fixedDeltaTime;
        if (this.timeSinceUpdate >= this.frequency)
        {
            float num = this.accum / ((float) this.frames);
            this.sFPS = num.ToString("f" + Mathf.Clamp(this.nbDecimal, 0, 10));
            this.color = (num >= 30f) ? Color.green : ((num < 10f) ? Color.red : Color.yellow);
            this.color.a = this.bgAlpha;
            this.accum = 0f;
            this.frames = 0;
            this.timeSinceUpdate = 0f;
            this.label.text = string.Concat(new object[] { this.sFPS, " FPS, ", GNetworkService.totalSendBPS, "/", GNetworkService.totalReceiveBPS, " Net - BPS" });
            this.background.color = this.updateColor ? this.color : Color.white;
        }
    }

    public static void GuiAssertNotNull(string message, params object[] nullChecks)
    {
        for (int i = 0; i < nullChecks.Length; i++)
        {
            if (nullChecks[i] == null)
            {
                throw new Exception(message + "\n  >> index of first null object: " + i);
            }
        }
    }

    public void HidePanel()
    {
        NGUITools.SetActive(base.gameObject, false);
    }

    public bool IsShowing()
    {
        return NGUITools.GetActive(base.gameObject);
    }

    public void OnDestroy()
    {
        singleton = null;
    }

    public void ShowPanel()
    {
        NGUITools.SetActive(base.gameObject, true);
    }

    private void Start()
    {
        this.label = base.GetComponentInChildren<UILabel>();
        this.background = base.GetComponentInChildren<UISlicedSprite>();
        GuiAssertNotNull("Could not find needed child objects.", new object[] { this.label, this.background });
        this.bgAlpha = this.background.color.a;
        if (!GUtil.internalMode)
        {
            NGUITools.SetActive(base.gameObject, false);
        }
    }

    public void TogglePanel()
    {
        if (this.IsShowing())
        {
            this.HidePanel();
        }
        else
        {
            this.ShowPanel();
        }
    }

    private void Update()
    {
        this.accum += Time.timeScale / Time.deltaTime;
        this.frames++;
    }
}

