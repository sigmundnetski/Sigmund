﻿using System;
using System.Collections.Generic;

[LooseDependency(typeof(AchievementFlagData)), StrongDependency(typeof(CraftRecipeData)), NoExcelData, StrongDependency(typeof(RefineRecipeData))]
public class BaseRecipeData : DataClass
{
    protected static readonly string[] _baseMandatoryColumns;
    public int advFlagId;
    public double baseCraftDuration;
    public string craftingKeyword;
    private const string DEFAULT_OVERRIDE = "default";
    public string displayName;
    public int featAdvancementId;
    public byte featLevel;
    protected OutputFormula formula;
    public int[] inputItemIds = new int[0];
    public uint[] inputQtys;
    public int[] inputStockIds = new int[0];
    private const double MAX_SKILL_UPGRADE_BONUS = 0.8;
    public int outputItemId;
    public uint outputQty;
    public byte outputUpgrade;
    public static Dictionary<int, BaseRecipeData> recipeById;
    public static Dictionary<string, BaseRecipeData> recipeByName;
    public int skillId;
    public byte tier;
    private static readonly float[] TIERED_SKILL_ADJUSTMENT;

    static BaseRecipeData()
    {
        float[] numArray = new float[4];
        numArray[2] = 80f;
        numArray[3] = 140f;
        TIERED_SKILL_ADJUSTMENT = numArray;
        recipeById = new Dictionary<int, BaseRecipeData>();
        recipeByName = new Dictionary<string, BaseRecipeData>();
        _baseMandatoryColumns = new string[] { "recipe name", "display name", "achievement keyword", "feat name", "feat rank", "achievement flag link", "tier", "seconds", "quality", "output", "#" };
    }

    private InventoryItem GenerateCraftingOutput(Entity playerEntity, float avgInputUpgrade)
    {
        BasicItemData data;
        if (ItemDatabase.itemById.TryGetValue(this.outputItemId, out data))
        {
            return new InventoryItem(data.id, 1, (byte) Math.Floor((double) (avgInputUpgrade + this.GetSkillUpgradeAdjustment(playerEntity))), data.durability);
        }
        return InventoryItem.EMPTY;
    }

    public InventoryItem GenerateOutput(Entity playerEntity, float avgInputUpgrade, bool isClient)
    {
        switch (this.formula)
        {
            case OutputFormula.REFINING:
                return this.GenerateRefiningOutput(playerEntity, isClient);

            case OutputFormula.CRAFTING:
                return this.GenerateCraftingOutput(playerEntity, avgInputUpgrade);
        }
        throw new NotImplementedException("Recipe does not define which output formula to use");
    }

    private InventoryItem GenerateRefiningOutput(Entity playerEntity, bool isClient)
    {
        BasicItemData data;
        if (ItemDatabase.itemById.TryGetValue(this.outputItemId, out data))
        {
            if (isClient)
            {
                return new InventoryItem(data.id, 1, this.outputUpgrade, data.durability);
            }
            return new InventoryItem(data.id, 1, RollRefiningUpgrade(playerEntity, this.skillId, this.tier, this.outputUpgrade), data.durability);
        }
        return InventoryItem.EMPTY;
    }

    public double GetSkillUpgradeAdjustment(Entity playerEntity)
    {
        return Math.Max((double) ((((double) (playerEntity.combat.GetSkillTotalBySkillId(this.skillId) - TIERED_SKILL_ADJUSTMENT[this.tier])) / 300.0) * 0.8), (double) 0.0);
    }

    protected virtual BaseRecipeData Instantiate()
    {
        throw new NotImplementedException("Subclasses should implement this to return an instance of the specific subclass");
    }

    public override List<DataClass> MergeData()
    {
        List<DataClass> list = new List<DataClass>();
        list.AddRange(DataClass.GetData(typeof(RefineRecipeData)));
        list.AddRange(DataClass.GetData(typeof(CraftRecipeData)));
        return list;
    }

    public static void OnLoad(List<DataClass> objects)
    {
        foreach (BaseRecipeData data in objects)
        {
            recipeById[data.id] = data;
            recipeByName[data.name] = data;
        }
    }

    protected virtual bool ParseInputs(ref BaseRecipeData output, int rowIndex)
    {
        throw new NotImplementedException("Subclasses should parse their own inputs.");
    }

    public override DataClass ParseRecord(int rowIndex)
    {
        string str;
        if (DataClass.TryGetLCaseCellValue(DataClass.columnNamesToIndex["recipe name"], rowIndex, out str))
        {
            string str2;
            string str3;
            BaseRecipeData output = this.Instantiate();
            output.name = str;
            DataClass.GetCellValue(DataClass.columnNamesToIndex["display name"], rowIndex, out output.displayName);
            DataClass.TryGetLCaseCellValue(DataClass.columnNamesToIndex["achievement keyword"], rowIndex, out output.craftingKeyword);
            DataClass.GetIdFromForeignName<FeatAdvancementData>(DataClass.columnNamesToIndex["feat name"], rowIndex, out output.featAdvancementId);
            DataClass.GetCellValue(DataClass.columnNamesToIndex["feat rank"], rowIndex, out output.featLevel);
            DataClass.GetIdFromForeignName<SkillData>(DataClass.columnNamesToIndex["feat name"], rowIndex, out output.skillId);
            output.advFlagId = 0;
            if (DataClass.GetLCaseCellValue(DataClass.columnNamesToIndex["achievement flag link"], rowIndex, out str2) && (str2 != "default"))
            {
                AchievementFlagData data2;
                if (AchievementFlagData.flagsBySlotName.TryGetValue(str2, out data2))
                {
                    output.advFlagId = data2.id;
                }
                else
                {
                    DataClass.OutputErrorMessage(DataClass.columnNamesToIndex["achievement flag link"], rowIndex, "Failed to parse flag: " + str2);
                }
            }
            DataClass.GetCellValue(DataClass.columnNamesToIndex["tier"], rowIndex, out output.tier);
            DataClass.GetCellValue(DataClass.columnNamesToIndex["seconds"], rowIndex, out output.baseCraftDuration);
            if (output.baseCraftDuration <= 0.0)
            {
                DataClass.OutputErrorMessage(DataClass.columnNamesToIndex["seconds"], rowIndex, "Crafting time must be positive.  Got: " + output.baseCraftDuration);
            }
            else if (output.baseCraftDuration > 5184000.0)
            {
                DataClass.OutputErrorMessage(DataClass.columnNamesToIndex["seconds"], rowIndex, "Warning: Crafting time exceeds 2 months.  Months: " + (output.baseCraftDuration / 2592000.0));
            }
            if (DataClass.GetLCaseCellValue(DataClass.columnNamesToIndex["output"], rowIndex, out str3))
            {
                BasicItemData data3;
                if (ItemDatabase.itemByName.TryGetValue(str3, out data3))
                {
                    output.outputItemId = data3.id;
                }
                else
                {
                    DataClass.OutputErrorMessage(DataClass.columnNamesToIndex["output"], rowIndex, "Output item does not exist: " + str3);
                }
            }
            DataClass.GetCellValue(DataClass.columnNamesToIndex["#"], rowIndex, out output.outputQty);
            if (output.outputQty == 0)
            {
                DataClass.OutputErrorMessage(DataClass.columnNamesToIndex["#"], rowIndex, "Quantity must be greater than 0.");
            }
            bool flag = this.ParseInputs(ref output, rowIndex);
            ValidState state = output.Validate();
            if (flag && (state == ValidState.VALID))
            {
                return output;
            }
            DataClass.OutputErrorMessage(1, rowIndex, output.name + " is not a valid recipe: " + state);
        }
        return null;
    }

    public static byte RollRefiningUpgrade(Entity playerEntity, int skillId, byte tier, byte baseUpgrade)
    {
        int skillTotalBySkillId = playerEntity.combat.GetSkillTotalBySkillId(skillId);
        byte[] items = new byte[] { baseUpgrade, baseUpgrade = (byte) (baseUpgrade + 1), baseUpgrade = (byte) (baseUpgrade + 1) };
        float[] numArray2 = new float[3];
        numArray2[1] = (Math.Max((float) 0f, (float) (skillTotalBySkillId - TIERED_SKILL_ADJUSTMENT[tier])) * 0.18f) / (300f - TIERED_SKILL_ADJUSTMENT[tier]);
        numArray2[2] = (Math.Max((float) 0f, (float) (skillTotalBySkillId - TIERED_SKILL_ADJUSTMENT[tier])) * 0.01f) / (300f - TIERED_SKILL_ADJUSTMENT[tier]);
        float[] weights = numArray2;
        weights[0] = (1f - weights[1]) - weights[2];
        return GUtil.WeightedChoice<byte>(weights, items);
    }

    public void UnittestSetData(int _outputItemId, int _inputItemId, int _featAdvId, byte _featLevel, int _skillId, double _duration)
    {
        this.inputItemIds = new int[] { _inputItemId };
        this.inputQtys = new uint[] { 1 };
        this.outputItemId = _outputItemId;
        this.outputQty = 1;
        this.formula = OutputFormula.REFINING;
        this.featAdvancementId = _featAdvId;
        this.featLevel = _featLevel;
        this.skillId = _skillId;
        this.baseCraftDuration = _duration;
    }

    public ValidState Validate()
    {
        if (this.inputQtys.Length == 0)
        {
            return ValidState.INPUT_QTY_UNDEF;
        }
        if ((this.inputStockIds.Length == 0) && (this.inputItemIds.Length == 0))
        {
            return ValidState.INPUT_TYPE_UNDEF;
        }
        if (((this.inputStockIds.Length > 0) ? this.inputStockIds.Length : this.inputItemIds.Length) != this.inputQtys.Length)
        {
            return ValidState.INPUT_TYPE_QTY_MISMATCH;
        }
        if (this.outputItemId == 0)
        {
            return ValidState.NO_OUTPUT;
        }
        if (this.formula == OutputFormula.INVALID)
        {
            return ValidState.INVALID_FORMULA;
        }
        if (this.featAdvancementId == 0)
        {
            return ValidState.INVALID_FEAT;
        }
        if (this.skillId == 0)
        {
            return ValidState.INVALID_SKILL;
        }
        if ((this.baseCraftDuration <= 0.0) || (5184000.0 < this.baseCraftDuration))
        {
            return ValidState.DURATION_OOB;
        }
        return ValidState.VALID;
    }

    public CraftingRequest.Why ValidateRequestInput(int inputIndex, InventoryItem[] items)
    {
        int num;
        if (this.inputStockIds.Length > inputIndex)
        {
            for (num = 0; num < items.Length; num++)
            {
                if (!InventoryItem.EMPTY_MATCH(items[num]))
                {
                    int[] numArray;
                    if (!CraftingItemData.itemIdsByStockId.TryGetValue(this.inputStockIds[inputIndex], out numArray))
                    {
                        return CraftingRequest.Why.BAD_STOCK_IN_RECIPE;
                    }
                    if (Array.IndexOf<int>(numArray, items[num].staticItemId) == -1)
                    {
                        return CraftingRequest.Why.INPUT_WRONG_STOCK;
                    }
                }
            }
            if (this.inputQtys[inputIndex] != InventoryItemUtils.TotalItemCount(items))
            {
                return CraftingRequest.Why.INPUT_QTY;
            }
            return CraftingRequest.Why.VALID;
        }
        if (this.inputItemIds.Length > inputIndex)
        {
            for (num = 0; num < items.Length; num++)
            {
                if (!InventoryItem.EMPTY_MATCH(items[num]) && (this.inputItemIds[inputIndex] != items[num].staticItemId))
                {
                    return CraftingRequest.Why.INPUT_WRONG_REFINED_INPUT;
                }
            }
            if (this.inputQtys[inputIndex] != InventoryItemUtils.TotalItemCount(items))
            {
                return CraftingRequest.Why.INPUT_QTY;
            }
            return CraftingRequest.Why.VALID;
        }
        return CraftingRequest.Why.OTHER;
    }

    protected enum OutputFormula : byte
    {
        CRAFTING = 2,
        INVALID = 0,
        REFINING = 1
    }

    public enum ValidState
    {
        VALID,
        INPUT_QTY_UNDEF,
        INPUT_TYPE_UNDEF,
        INPUT_TYPE_QTY_MISMATCH,
        NO_OUTPUT,
        INVALID_FORMULA,
        INVALID_FEAT,
        INVALID_SKILL,
        DURATION_OOB
    }
}

