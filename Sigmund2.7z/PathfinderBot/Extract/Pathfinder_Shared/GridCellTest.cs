﻿using System;

internal class GridCellTest : UUnitTestCase
{
    [UUnitTestMethod]
    public void AddRemoveEntIds()
    {
        EntityId entityId = (EntityId) 1L;
        EntityId id2 = (EntityId) 2L;
        ProximityGrid grid = new ProximityGrid(1f, 0f, 0f, 1f, 1f);
        UUnitAssert.False(grid.CellContainsEntId(0, 0, entityId), "Fail");
        UUnitAssert.Equals((ulong) grid.CellNumEntries(0, 0), 0L, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        grid.CellAddEntId(0, 0, entityId);
        UUnitAssert.True(grid.CellContainsEntId(0, 0, entityId), "Fail");
        UUnitAssert.Equals((ulong) grid.CellNumEntries(0, 0), 1L, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        grid.CellAddEntId(0, 0, id2);
        UUnitAssert.True(grid.CellContainsEntId(0, 0, entityId), "Fail");
        UUnitAssert.True(grid.CellContainsEntId(0, 0, id2), "Fail");
        UUnitAssert.Equals((ulong) grid.CellNumEntries(0, 0), 2L, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        grid.CellRemoveEntId(0, 0, entityId);
        UUnitAssert.False(grid.CellContainsEntId(0, 0, entityId), "Fail");
        UUnitAssert.True(grid.CellContainsEntId(0, 0, id2), "Fail");
        UUnitAssert.Equals((ulong) grid.CellNumEntries(0, 0), 1L, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
    }

    [UUnitTestMethod]
    public void AllocFreeNewGridCell()
    {
        uint num;
        ProximityGrid grid = new ProximityGrid(1f, 0f, 0f, 1f, 1f);
        for (num = 1; num <= 0xb7; num++)
        {
            grid.CellAddEntId(0, 0, (EntityId) num);
        }
        UUnitAssert.Equals((ulong) grid.CellNumEntries(0, 0), 0xb7L, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals((ulong) grid.CellNumCells(0, 0), 3L, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals((ulong) grid.CellFreeListSize(), 0L, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        for (num = 0x3e; num <= 0x7a; num++)
        {
            grid.CellRemoveEntId(0, 0, (EntityId) num);
        }
        UUnitAssert.Equals((ulong) grid.CellNumEntries(0, 0), 0x7aL, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals((ulong) grid.CellNumCells(0, 0), 2L, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        for (num = 1; num <= 0x3d; num++)
        {
            grid.CellRemoveEntId(0, 0, (EntityId) num);
        }
        UUnitAssert.Equals((ulong) grid.CellNumEntries(0, 0), 0x3dL, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals((ulong) grid.CellNumCells(0, 0), 2L, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        for (num = 0x7b; num <= 0xb7; num++)
        {
            grid.CellRemoveEntId(0, 0, (EntityId) num);
        }
        UUnitAssert.Equals((ulong) grid.CellNumEntries(0, 0), 0L, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals((ulong) grid.CellNumCells(0, 0), 1L, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals((ulong) grid.CellFreeListSize(), 2L, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        for (num = 1; num <= 0x7a; num++)
        {
            grid.CellAddEntId(0, 0, (EntityId) num);
        }
        UUnitAssert.Equals((ulong) grid.CellNumEntries(0, 0), 0x7aL, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals((ulong) grid.CellNumCells(0, 0), 2L, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals((ulong) grid.CellFreeListSize(), 1L, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
    }

    [UUnitTestMethod]
    public void BlanksReused()
    {
        ProximityGrid grid = new ProximityGrid(1f, 0f, 0f, 1f, 1f);
        for (uint i = 1; i <= 0x3d; i++)
        {
            grid.CellAddEntId(0, 0, (EntityId) i);
        }
        grid.CellRemoveEntId(0, 0, (EntityId) 4L);
        grid.CellRemoveEntId(0, 0, (EntityId) 8L);
        grid.CellRemoveEntId(0, 0, (EntityId) 12L);
        UUnitAssert.Equals((ulong) grid.CellNumEntries(0, 0), 0x3aL, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals((ulong) grid.CellNumCells(0, 0), 1L, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        grid.CellAddEntId(0, 0, (EntityId) 0x3e8L);
        grid.CellAddEntId(0, 0, (EntityId) 0x3e9L);
        grid.CellAddEntId(0, 0, (EntityId) 0x3eaL);
        UUnitAssert.Equals((ulong) grid.CellNumEntries(0, 0), 0x3dL, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals((ulong) grid.CellNumCells(0, 0), 1L, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.True(grid.CellContainsEntId(0, 0, (EntityId) 0x3e8L), "Fail");
        UUnitAssert.True(grid.CellContainsEntId(0, 0, (EntityId) 0x3e9L), "Fail");
        UUnitAssert.True(grid.CellContainsEntId(0, 0, (EntityId) 0x3eaL), "Fail");
        UUnitAssert.False(grid.CellContainsEntId(0, 0, (EntityId) 4L), "Fail");
        UUnitAssert.False(grid.CellContainsEntId(0, 0, (EntityId) 8L), "Fail");
        UUnitAssert.False(grid.CellContainsEntId(0, 0, (EntityId) 12L), "Fail");
    }

    [UUnitTestMethod]
    public void TestStructSize()
    {
        UUnitAssert.Contains<int>(new int[] { 0x1f8, 0x1fc }, sizeof(GridCell), "Expected element in list: {0} in\n{1}");
    }
}

