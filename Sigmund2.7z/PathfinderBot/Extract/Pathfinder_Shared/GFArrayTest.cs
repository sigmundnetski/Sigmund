﻿using System;

internal class GFArrayTest
{
    public int[] array;
}

