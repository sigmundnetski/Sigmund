﻿using System;

public static class PfoUiConsts
{
    public const string BLANK_HOTBAR_ICON = "hud_hotbar_icon_blank";
    public const string UNKNOWN_HOTBAR_ICON = "hud_hotbar_icon_questionmark";
    public const string UNKNOWN_IMPLEMENT_ICON = "icon_hud_implement_unknown";
    public const string UNKNOWN_WEAPON_ICON = "icon_hud_weapon_unknown";
}

