﻿using System;
using System.Collections.Generic;

public class WeaponCategoryData : DataClass
{
    public static Dictionary<int, WeaponCategoryData> categoriesById = new Dictionary<int, WeaponCategoryData>();
    public static Dictionary<string, WeaponCategoryData> categoriesByName = new Dictionary<string, WeaponCategoryData>();
    public string displayName;
    public AssetHand mainhand;

    public WeaponCategoryData()
    {
        this.displayName = string.Empty;
    }

    public WeaponCategoryData(string name_) : base(name_.ToLower())
    {
        this.displayName = name_;
    }

    public static void OnLoad(List<DataClass> objects)
    {
        categoriesById.Clear();
        categoriesByName.Clear();
        foreach (WeaponCategoryData data in objects)
        {
            categoriesById[data.id] = data;
            categoriesByName[data.name] = data;
        }
    }

    public override DataClass ParseRecord(int index)
    {
        WeaponCategoryData data = new WeaponCategoryData();
        if (!DataClass.TryGetCellValue("A", index, out data.displayName))
        {
            return null;
        }
        data.name = data.displayName.ToLower();
        int num = -1;
        if (DataClass.columnNamesToIndex.TryGetValue("mainhand", out num))
        {
            DataClass.TryGetEnumCellValue<AssetHand>(num, index, AssetHand.RIGHT, out data.mainhand);
        }
        return data;
    }

    public enum AssetHand : byte
    {
        LEFT = 1,
        RIGHT = 0
    }
}

