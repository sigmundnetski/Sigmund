﻿using System;
using System.Runtime.CompilerServices;
using UnityEngine;

public class CapturePointMono : MonoBehaviour
{
    public float radius;
    public static RegisterCapturePointDelegate RegisterCapturePoint;
    [NonSerialized]
    private CapturePoint runtimeDetails;

    public void Start()
    {
        MeshRenderer component = base.GetComponent<MeshRenderer>();
        if (component != 0)
        {
            UnityEngine.Object.Destroy(component);
        }
        MeshFilter filter = base.GetComponent<MeshFilter>();
        if (filter != 0)
        {
            UnityEngine.Object.Destroy(filter);
        }
        if (RegisterCapturePoint != null)
        {
            if (this.runtimeDetails == null)
            {
                this.runtimeDetails = new CapturePoint();
                RegisterCapturePoint(this.runtimeDetails);
            }
            this.runtimeDetails.Set(base.transform.position, this.radius);
        }
    }

    public delegate void RegisterCapturePointDelegate(CapturePoint capturePoint);
}

