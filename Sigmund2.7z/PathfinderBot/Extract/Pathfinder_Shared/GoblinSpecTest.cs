﻿using System;
using System.Collections.Generic;

internal class GoblinSpecTest : UUnitTestCase
{
    public void PrintTokens(Queue<Token> tokens)
    {
        foreach (Token token in tokens)
        {
            if (token.intValue != 0)
            {
                Console.Out.WriteLine(token.type.ToString() + ": " + token.intValue);
            }
            else if (!(token.floatValue == 0f))
            {
                Console.Out.WriteLine(token.type.ToString() + ": " + token.floatValue);
            }
            else if (token.userData != 0)
            {
                Console.Out.WriteLine(token.type.ToString() + ": " + token.userData);
            }
            else
            {
                Console.Out.WriteLine(token.type.ToString() + ": '" + token.stringValue + "'");
            }
        }
    }

    [UUnitTestMethod]
    public void TestChance()
    {
        GSStatement statement = GoblinSpec.Statement(GoblinSpec.Tokenize("Immobilize (50% chance)"));
        UUnitAssert.Equals(statement.statement, "immobilize", "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(statement.parameters.Count, 1, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(statement.parameters[0].value, 50, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(statement.parameters[0].unit, GSParamUnit.PERCENTAGE_CHANCE, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
    }

    [UUnitTestMethod]
    public void TestCompleteParse()
    {
        List<GSStatement> list = GoblinSpec.Parse("-5 Base Defense, Blood 10 on Sneak Attack, Slows 10% (1 round, 20% chance) if Target is Distressed");
        UUnitAssert.Equals(list.Count, 3, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(list[0].statement, "base defense", "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(list[0].parameters.Count, 1, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(list[0].parameters[0].value, -5, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(list[1].statement, "blood", "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(list[1].parameters.Count, 1, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(list[1].parameters[0].value, 10, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(list[1].qualifiers.Count, 1, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(list[1].qualifiers[0].type, GSQualifierType.CONDITION, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(list[1].qualifiers[0].condition, "sneak attack", "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(list[2].statement, "slows", "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(list[2].parameters.Count, 3, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(list[2].parameters[0].value, 10, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(list[2].parameters[0].unit, GSParamUnit.PERCENTAGE, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(list[2].parameters[1].value, 1, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(list[2].parameters[1].unit, GSParamUnit.ROUND, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(list[2].parameters[2].value, 20, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(list[2].parameters[2].unit, GSParamUnit.PERCENTAGE_CHANCE, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(list[2].qualifiers.Count, 1, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(list[2].qualifiers[0].type, GSQualifierType.EQUIVALENCE, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(list[2].qualifiers[0].target, "target", "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(list[2].qualifiers[0].condition, "distressed", "Expected equivalent inputs: \"{0}\" != \"{1}\"");
    }

    [UUnitTestMethod]
    public void TestConditionalQualifier()
    {
        Queue<Token> tokens = GoblinSpec.Tokenize("on Sneak Attack");
        GSQualifier qualifier = GoblinSpec.Qualifier(tokens);
        UUnitAssert.Equals(qualifier.type, GSQualifierType.CONDITION, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(qualifier.condition, "sneak attack", "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        tokens = GoblinSpec.Tokenize("if Target has Opportunity");
        qualifier = GoblinSpec.Qualifier(tokens);
        UUnitAssert.Equals(qualifier.type, GSQualifierType.EQUIVALENCE, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(qualifier.target, "target", "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(qualifier.condition, "opportunity", "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        tokens = GoblinSpec.Tokenize("if Target doesn't have Opportunity");
        qualifier = GoblinSpec.Qualifier(tokens);
        UUnitAssert.Equals(qualifier.type, GSQualifierType.NONEQUIVALENCE, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(qualifier.target, "target", "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(qualifier.condition, "opportunity", "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        tokens = GoblinSpec.Tokenize("if Target has");
        UUnitAssert.Raises(() => GoblinSpec.Qualifier(tokens), typeof(ParseException), new object[] { "should raise error on missing condition" });
    }

    [UUnitTestMethod]
    public void TestIntParam()
    {
        Queue<Token> tokens = GoblinSpec.Tokenize("24 100%");
        GSParam param = GoblinSpec.IntParam(tokens);
        UUnitAssert.Equals(param.value, 0x18, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(param.unit, GSParamUnit.NONE, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        param = GoblinSpec.IntParam(tokens);
        UUnitAssert.Equals(param.value, 100, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(param.unit, GSParamUnit.PERCENTAGE, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
    }

    [UUnitTestMethod]
    public void TestParamList()
    {
        Queue<Token> tokens = GoblinSpec.Tokenize("(2 seconds, 1 round)");
        List<GSParam> parameters = new List<GSParam>();
        GoblinSpec.ParamList(tokens, parameters);
        UUnitAssert.Equals(parameters.Count, 2, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(parameters[0].unit, GSParamUnit.SECOND, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(parameters[0].value, 2, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(parameters[1].unit, GSParamUnit.ROUND, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(parameters[1].value, 1, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        tokens = GoblinSpec.Tokenize("(6 meters)");
        parameters = new List<GSParam>();
        GoblinSpec.ParamList(tokens, parameters);
        UUnitAssert.Equals(parameters.Count, 1, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(parameters[0].unit, GSParamUnit.METER, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(parameters[0].value, 6, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        tokens = GoblinSpec.Tokenize("(2)");
        UUnitAssert.Raises(() => GoblinSpec.ParamList(tokens, parameters), typeof(ParseException), new object[] { "should raise error on missing time qualifier" });
        tokens = GoblinSpec.Tokenize("()");
        UUnitAssert.Raises(() => GoblinSpec.ParamList(tokens, parameters), typeof(ParseException), new object[] { "should raise error on missing parameter" });
        tokens = GoblinSpec.Tokenize("(2 seconds");
        UUnitAssert.Raises(() => GoblinSpec.ParamList(tokens, parameters), typeof(ParseException), new object[] { "should raise error on missing close paren" });
        tokens = GoblinSpec.Tokenize("(2 seconds,)");
        UUnitAssert.Raises(() => GoblinSpec.ParamList(tokens, parameters), typeof(ParseException), new object[] { "should raise error on missing second parameter" });
    }

    [UUnitTestMethod]
    public void TestStatement()
    {
        Queue<Token> tokens = GoblinSpec.Tokenize("Immobilize (2 seconds) to All Targets with Opportunity");
        GSStatement statement = GoblinSpec.Statement(tokens);
        UUnitAssert.Equals(statement.statement, "immobilize", "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(statement.parameters.Count, 1, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(statement.parameters[0].value, 2, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(statement.parameters[0].unit, GSParamUnit.SECOND, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(statement.qualifiers.Count, 2, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(statement.qualifiers[0].target, "all targets", "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(statement.qualifiers[0].type, GSQualifierType.TARGET, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(statement.qualifiers[1].condition, "opportunity", "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(statement.qualifiers[1].type, GSQualifierType.CONDITION, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        tokens = GoblinSpec.Tokenize("10 -5 Base Defense");
        UUnitAssert.Raises(() => GoblinSpec.Statement(tokens), typeof(ParseException), new object[] { "should raise error on extra integer" });
        tokens = GoblinSpec.Tokenize("if Sneak Attack Base Defense");
        UUnitAssert.Raises(() => GoblinSpec.Statement(tokens), typeof(ParseException), new object[] { "should raise error on keyword" });
    }

    [UUnitTestMethod]
    public void TestTargetQualifer()
    {
        Queue<Token> tokens = GoblinSpec.Tokenize("to Self");
        GSQualifier qualifier = GoblinSpec.Qualifier(tokens);
        UUnitAssert.Equals(qualifier.type, GSQualifierType.TARGET, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(qualifier.target, "self", "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        tokens = GoblinSpec.Tokenize("to");
        UUnitAssert.Raises(() => GoblinSpec.Qualifier(tokens), typeof(ParseException), new object[] { "should raise error on missing target" });
    }
}

