﻿using System;
using System.Collections.Generic;

public class TowerPvpData : DataClass
{
    private static readonly string[] _mandatoryColumns = new string[] { "tower range", "minutes per tower" };
    public const uint MAX_PVP_DURATION = 0x564;
    public uint minRange;
    public uint minutesPerTower;
    private static TowerPvpData[] sortedHighestToLowest;

    public TowerPvpData()
    {
        this.minRange = 0;
        this.minutesPerTower = 0;
    }

    public TowerPvpData(uint minRange_, uint minutesPerTower_)
    {
        this.minRange = minRange_;
        this.minutesPerTower = minutesPerTower_;
    }

    public static uint GetPvpDuration(uint numTowers)
    {
        uint num = 0;
        for (uint i = numTowers; i > 0; i--)
        {
            for (int j = 0; j < sortedHighestToLowest.Length; j++)
            {
                if (sortedHighestToLowest[j].minRange <= i)
                {
                    num += sortedHighestToLowest[j].minutesPerTower;
                    break;
                }
            }
        }
        return Math.Min(num, 0x564);
    }

    public static void OnLoad(List<DataClass> objects)
    {
        sortedHighestToLowest = new TowerPvpData[objects.Count];
        for (int i = 0; i < sortedHighestToLowest.Length; i++)
        {
            sortedHighestToLowest[i] = objects[i] as TowerPvpData;
        }
        Array.Sort<TowerPvpData>(sortedHighestToLowest, new Comparison<TowerPvpData>(TowerPvpData.Sort));
    }

    public static void OnUnload()
    {
        sortedHighestToLowest = new TowerPvpData[0];
    }

    public override DataClass ParseRecord(int index)
    {
        TowerPvpData data = new TowerPvpData();
        DataClass.GetLCaseCellValue(DataClass.columnNamesToIndex["tower range"], index, out data.name);
        if (string.IsNullOrEmpty(data.name))
        {
            return null;
        }
        DataClass.GetCellValue(DataClass.columnNamesToIndex["tower range"], index, out data.minRange);
        DataClass.GetCellValue(DataClass.columnNamesToIndex["minutes per tower"], index, out data.minutesPerTower);
        return data;
    }

    private static int Sort(TowerPvpData lhs, TowerPvpData rhs)
    {
        if (lhs.minRange > rhs.minRange)
        {
            return -1;
        }
        if (lhs.minRange < rhs.minRange)
        {
            return 1;
        }
        return 0;
    }

    protected override IEnumerable<string> GetMandatoryColumns
    {
        get
        {
            return _mandatoryColumns;
        }
    }
}

