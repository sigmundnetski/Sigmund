﻿using System;
using System.Collections.Generic;

public class NpcQuestVars
{
    public readonly HashSet<int> actorIds;

    public NpcQuestVars(params int[] _actorIds)
    {
        this.actorIds = null;
        this.actorIds = new HashSet<int>(_actorIds);
    }

    public NpcQuestVars(HashSet<int> _actorIds)
    {
        this.actorIds = null;
        this.actorIds = _actorIds;
    }

    public static NpcQuestVars GetGlobalActor(Entity entity, ActiveSpawnPoint spawnPoint)
    {
        HashSet<int> globalActors = GlobalActorData.GetGlobalActors(entity, spawnPoint);
        if (globalActors.Count == 0)
        {
            return null;
        }
        return new NpcQuestVars(globalActors);
    }

    public bool IsActor(int actorId)
    {
        return this.actorIds.Contains(actorId);
    }
}

