﻿using System;
using System.Collections.Generic;
using System.Linq;

public class LootTableTest : UUnitTestCase
{
    private PickGroupData[] groups = new PickGroupData[11];
    private int[] tableIds = new int[11];

    protected override void SetUp()
    {
        LootTableUnitHelper.ClearLootTables(false);
        for (int i = 0; i < 11; i++)
        {
            this.tableIds[i] = LootTableUnitHelper.MakeLootTable("node" + i, 0);
            this.groups[i] = LootTableUnitHelper.MakePickGroup(this.tableIds[i], 1f);
        }
        LootTableUnitHelper.LinkSubTable(this.groups[0], this.tableIds[1]);
        LootTableUnitHelper.LinkSubTable(this.groups[0], this.tableIds[2]);
        LootTableUnitHelper.LinkSubTable(this.groups[1], this.tableIds[3]);
        LootTableUnitHelper.LinkSubTable(this.groups[1], this.tableIds[4]);
        LootTableUnitHelper.LinkSubTable(this.groups[2], this.tableIds[5]);
        LootTableUnitHelper.LinkSubTable(this.groups[2], this.tableIds[6]);
        LootTableUnitHelper.LinkSubTable(this.groups[3], this.tableIds[7]);
        LootTableUnitHelper.LinkSubTable(this.groups[4], this.tableIds[7]);
        LootTableUnitHelper.LinkSubTable(this.groups[5], this.tableIds[8]);
        LootTableUnitHelper.LinkSubTable(this.groups[6], this.tableIds[9]);
        LootTableUnitHelper.LinkSubTable(this.groups[8], this.tableIds[5]);
        LootTableUnitHelper.LinkSubTable(this.groups[10], this.tableIds[6]);
        foreach (KeyValuePair<int, LootTableData> pair in LootTableData.tablesById)
        {
            LootTableData.ParseAllSubTableIds(pair.Value.pickGroups, out pair.Value.subTableIds, out pair.Value.subTableNames);
        }
    }

    protected override void TearDown()
    {
        LootTableUnitHelper.ClearLootTables(false);
    }

    [UUnitTestMethod]
    private void TestPrereqs()
    {
        UUnitAssert.SequenceEqual<int>(LootTableData.tablesById[this.tableIds[0]].subTableIds, new int[] { this.tableIds[1], this.tableIds[2] }, "Expected equivalent lists:\n{0}\n!=\n{1}");
        UUnitAssert.SequenceEqual<int>(LootTableData.tablesById[this.tableIds[1]].subTableIds, new int[] { this.tableIds[3], this.tableIds[4] }, "Expected equivalent lists:\n{0}\n!=\n{1}");
        UUnitAssert.SequenceEqual<int>(LootTableData.tablesById[this.tableIds[2]].subTableIds, new int[] { this.tableIds[5], this.tableIds[6] }, "Expected equivalent lists:\n{0}\n!=\n{1}");
        UUnitAssert.SequenceEqual<int>(LootTableData.tablesById[this.tableIds[3]].subTableIds, new int[] { this.tableIds[7] }, "Expected equivalent lists:\n{0}\n!=\n{1}");
        UUnitAssert.SequenceEqual<int>(LootTableData.tablesById[this.tableIds[4]].subTableIds, new int[] { this.tableIds[7] }, "Expected equivalent lists:\n{0}\n!=\n{1}");
        UUnitAssert.SequenceEqual<int>(LootTableData.tablesById[this.tableIds[5]].subTableIds, new int[] { this.tableIds[8] }, "Expected equivalent lists:\n{0}\n!=\n{1}");
        UUnitAssert.SequenceEqual<int>(LootTableData.tablesById[this.tableIds[6]].subTableIds, new int[] { this.tableIds[9] }, "Expected equivalent lists:\n{0}\n!=\n{1}");
        UUnitAssert.SequenceEqual<int>(LootTableData.tablesById[this.tableIds[7]].subTableIds, new int[0], "Expected equivalent lists:\n{0}\n!=\n{1}");
        UUnitAssert.SequenceEqual<int>(LootTableData.tablesById[this.tableIds[8]].subTableIds, new int[] { this.tableIds[5] }, "Expected equivalent lists:\n{0}\n!=\n{1}");
        UUnitAssert.SequenceEqual<int>(LootTableData.tablesById[this.tableIds[9]].subTableIds, new int[0], "Expected equivalent lists:\n{0}\n!=\n{1}");
        UUnitAssert.SequenceEqual<int>(LootTableData.tablesById[this.tableIds[10]].subTableIds, new int[] { this.tableIds[6] }, "Expected equivalent lists:\n{0}\n!=\n{1}");
    }

    [UUnitTestMethod]
    private void TestValidity()
    {
        List<DataClass> objects = new List<DataClass>(from each in LootTableData.tablesById select each.Value);
        LootTableData.OnLoad(objects);
        int[] first = new int[] { this.tableIds[1], this.tableIds[3], this.tableIds[4], this.tableIds[6], this.tableIds[7], this.tableIds[9], this.tableIds[10] };
        IEnumerable<int> second = from each in LootTableData.tablesById select each.Key;
        UUnitAssert.True(first.SequenceEqual<int>(second), "Fail");
    }
}

