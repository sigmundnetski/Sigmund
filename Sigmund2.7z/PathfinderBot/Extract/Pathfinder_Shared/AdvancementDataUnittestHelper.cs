﻿using System;
using System.Collections.Generic;
using System.Linq;

public static class AdvancementDataUnittestHelper
{
    public static Dictionary<string, GenericAchievementData> allTestAchievements = new Dictionary<string, GenericAchievementData>();
    public static Dictionary<string, AchievementCounterData> allTestCounters = new Dictionary<string, AchievementCounterData>();
    public static Dictionary<string, FeatAdvancementData> allTestFeatAdvancement = new Dictionary<string, FeatAdvancementData>();
    public static Dictionary<string, AchievementFlagData> allTestFlags = new Dictionary<string, AchievementFlagData>();
    private static bool canCreateData = true;

    public static void AddExpLevel(ref FeatAdvancementData newFeatAdv, uint expCost, int[] achievementIds, int[] featIds, int[] categoryIds, ushort categoryReq, int[] abilityReqIds, float abilityReq, int[] abilityBonusIds, float abilityBonus)
    {
        FeatAdvancementDetails details = new FeatAdvancementDetails();
        newFeatAdv.AppendUnittestDetails(details);
        details.expCost = expCost;
        details.achievementIds = (from each in achievementIds select new int[] { each }).ToArray<int[]>();
        details.featAdvIds = (from each in featIds select new int[] { each }).ToArray<int[]>();
        details.featLevels = (from each in featIds
            select 1 into each_outer
            select new byte[] { each_outer }).ToArray<byte[]>();
        details.categoryIds = (from each in categoryIds select new int[] { each }).ToArray<int[]>();
        details.categoryReqs = (from each in categoryIds
            select categoryReq into each_outer
            select new ushort[] { each_outer }).ToArray<ushort[]>();
        details.abilityReqIds = (from each in abilityReqIds select new int[] { each }).ToArray<int[]>();
        details.abilityReqValues = (from each in abilityReqIds
            select abilityReq into each_outer
            select new float[] { each_outer }).ToArray<float[]>();
        details.abilityBonusIds = abilityBonusIds;
        details.abilityBonusValues = (from each in abilityBonusIds select abilityBonus).ToArray<float>();
    }

    public static void CleanAllData()
    {
        MergedAchievementData.achievementsByPageId.Clear();
        MergedAchievementData.achievementsByTypeName.Clear();
        MergedAchievementData.dataById.Clear();
        AchievementFlagData.flagsById.Clear();
        AchievementFlagData.flagsByPageId.Clear();
        AchievementCounterData.countersById.Clear();
        AchievementCounterData.countersByPageId.Clear();
        FeatAdvancementData.dataByFeatAdvancementId.Clear();
        FeatAdvancementData.dataBySlotName.Clear();
        FeatAdvancementData.dataByPageId.Clear();
        AdvancementIndexedDataClass.ResetPageNumbers();
        allTestAchievements.Clear();
        allTestCounters.Clear();
        allTestFlags.Clear();
        allTestFeatAdvancement.Clear();
        canCreateData = true;
        AchievementCore.TearDownPageInfo();
    }

    public static T MakeAchievement<T>(ushort index, string slotName, byte level) where T: GenericAchievementData, new()
    {
        if (!canCreateData)
        {
            throw new Exception("This utility can only create data in a specific sequence.");
        }
        AdvancementIndexedDataClass.ResetPageNumbers();
        System.Type type = typeof(T);
        string str = type.Name.ToLower();
        T local = Activator.CreateInstance<T>();
        local.pageId = DataClass.GenerateId(str);
        local.pageIndex = index;
        local.slotName = slotName.ToLower();
        local.slotId = DataClass.GenerateId(slotName.ToLower());
        local.name = str + index;
        local.id = DataClass.GenerateId(local.name);
        local.level = level;
        local.displayName = slotName + index;
        local.categoryIds = new int[0];
        local.categoryPoints = new ushort[0];
        allTestAchievements.Add(slotName, local);
        return local;
    }

    public static int MakeCounter(string pageName, ushort index, string slotName)
    {
        AchievementCounterData data;
        if (!canCreateData)
        {
            throw new Exception("This utility can only create data in a specific sequence.");
        }
        AdvancementIndexedDataClass.ResetPageNumbers();
        data = new AchievementCounterData {
            pageId = DataClass.GenerateId(pageName),
            pageIndex = index,
            slotName = slotName.ToLower(),
            slotId = DataClass.GenerateId(slotName),
            name = pageName.ToLower() + index,
            id = DataClass.GenerateId(data.name)
        };
        AchievementCounterData.countersById.Add(data.id, data);
        if (!AchievementCounterData.countersByPageId.ContainsKey(data.pageId))
        {
            AchievementCounterData.countersByPageId[data.pageId] = new AchievementCounterData[0];
        }
        AchievementCounterData[] array = AchievementCounterData.countersByPageId[data.pageId];
        Array.Resize<AchievementCounterData>(ref array, array.Length + 1);
        array[array.Length - 1] = data;
        AchievementCounterData.countersByPageId[data.pageId] = array;
        allTestCounters.Add(slotName, data);
        return data.id;
    }

    public static FeatAdvancementData MakeFeatAdvancement(string pageName, ushort index, string slotName, uint expCost, int[] achievementIds, int[] featIds, int[] categoryIds, ushort categoryReq, int[] abilityReqIds, float abilityReq, int[] abilityBonusIds, float abilityBonus)
    {
        FeatAdvancementData data;
        if (!canCreateData)
        {
            throw new Exception("This utility can only create data in a specific sequence.");
        }
        data = new FeatAdvancementData {
            slotName = slotName,
            slotId = DataClass.GenerateId(slotName),
            pageId = DataClass.GenerateId(pageName),
            pageIndex = index,
            name = string.Concat(new object[] { slotName, data.slotId, data.pageId, data.pageIndex }),
            id = DataClass.GenerateId(data.name)
        };
        AddExpLevel(ref data, expCost, achievementIds, featIds, categoryIds, categoryReq, abilityReqIds, abilityReq, abilityBonusIds, abilityBonus);
        allTestFeatAdvancement.Add(data.name, data);
        return data;
    }

    public static FeatAdvancementData MakeFeatAdvancement(string pageName, ushort index, string slotName, uint expCost, int[][] achievementIds, int[][] featIds, int[][] categoryIds, ushort categoryReq, int[][] abilityReqIds, float abilityReq, int[] abilityBonusIds, float abilityBonus)
    {
        FeatAdvancementData data;
        if (!canCreateData)
        {
            throw new Exception("This utility can only create data in a specific sequence.");
        }
        data = new FeatAdvancementData {
            slotName = slotName,
            slotId = DataClass.GenerateId(slotName),
            pageId = DataClass.GenerateId(pageName),
            pageIndex = index,
            name = string.Concat(new object[] { slotName, data.slotId, data.pageId, data.pageIndex }),
            id = DataClass.GenerateId(data.name)
        };
        FeatAdvancementDetails details = new FeatAdvancementDetails();
        data.AppendUnittestDetails(details);
        details.expCost = expCost;
        details.achievementIds = achievementIds;
        details.featAdvIds = featIds;
        details.featLevels = (from each in featIds select (from each_inner in each select 1).ToArray<byte>()).ToArray<byte[]>();
        details.categoryIds = categoryIds;
        details.categoryReqs = (from each in categoryIds select (from each_inner in each select categoryReq).ToArray<ushort>()).ToArray<ushort[]>();
        details.abilityReqIds = abilityReqIds;
        details.abilityReqValues = (from each in abilityReqIds select (from each_inner in each select abilityReq).ToArray<float>()).ToArray<float[]>();
        details.abilityBonusIds = abilityBonusIds;
        details.abilityBonusValues = (from each in abilityBonusIds select abilityBonus).ToArray<float>();
        allTestFeatAdvancement.Add(data.name, data);
        return data;
    }

    public static AchievementFlagData MakeFlag(string pageName, ushort index, string slotName)
    {
        AchievementFlagData data;
        if (!canCreateData)
        {
            throw new Exception("This utility can only create data in a specific sequence.");
        }
        AdvancementIndexedDataClass.ResetPageNumbers();
        data = new AchievementFlagData {
            pageId = DataClass.GenerateId(pageName),
            pageIndex = index,
            slotName = slotName.ToLower(),
            slotId = DataClass.GenerateId(slotName),
            name = pageName.ToLower() + index,
            id = DataClass.GenerateId(data.name)
        };
        AchievementFlagData.flagsById.Add(data.id, data);
        if (!AchievementFlagData.flagsByPageId.ContainsKey(data.pageId))
        {
            AchievementFlagData.flagsByPageId[data.pageId] = new AchievementFlagData[0];
        }
        AchievementFlagData[] array = AchievementFlagData.flagsByPageId[data.pageId];
        Array.Resize<AchievementFlagData>(ref array, array.Length + 1);
        array[array.Length - 1] = data;
        AchievementFlagData.flagsByPageId[data.pageId] = array;
        allTestFlags.Add(slotName, data);
        return data;
    }

    public static void SimulateOnLoadForData()
    {
        MergedAchievementData.achievementsByPageId.Clear();
        MergedAchievementData.achievementsByTypeName.Clear();
        MergedAchievementData.dataById.Clear();
        FeatAdvancementData.dataByFeatAdvancementId.Clear();
        FeatAdvancementData.dataBySlotName.Clear();
        FeatAdvancementData.dataByPageId.Clear();
        MergedAchievementData data = new MergedAchievementData {
            _allAchievements = allTestAchievements.Values.ToArray<GenericAchievementData>()
        };
        MergedAchievementData.OnLoad(new List<DataClass> { data });
        AchievementCounterData.OnLoad(new List<DataClass>(from each in allTestCounters.Values select each));
        AchievementFlagData.OnLoad(new List<DataClass>(from each in allTestFlags.Values select each));
        FeatAdvancementData.OnLoad(new List<DataClass>(from each in allTestFeatAdvancement.Values select each));
        canCreateData = false;
        AchievementCore.SetupPageInfo();
    }
}

