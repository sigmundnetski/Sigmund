﻿using System;
using System.Runtime.InteropServices;
using System.Text;

public abstract class BasicItemData : DataClass
{
    public ushort baseQuality;
    public int categoryId;
    public string description;
    public string displayName;
    private static StringBuilder displayNameOutput = new StringBuilder();
    public byte durability;
    public float encumbrance;
    public string icon;
    public const ItemSlot LAST_ARMOR_SLOT = ItemSlot.BACK;
    public const ItemSlot LAST_BODY_SLOT = ItemSlot.WONDROUS_2;
    public string model;
    public string redeemName;
    public ItemSlot slot;
    public byte tier;
    public bool upgradable;

    public BasicItemData()
    {
    }

    public BasicItemData(string name_) : base(DataClass.GenerateNameLower(new object[] { name_ }))
    {
    }

    public string GetDisplayName(byte upgrade, uint qty, byte curDurability, bool displayDurability = true)
    {
        displayNameOutput.Length = 0;
        displayNameOutput.Append(this.displayName);
        if (this.upgradable && (upgrade > 0))
        {
            displayNameOutput.Append(" +");
            displayNameOutput.Append(upgrade);
        }
        if (qty > 1)
        {
            displayNameOutput.Append(" (");
            displayNameOutput.Append(qty);
            displayNameOutput.Append(")");
        }
        if (displayDurability && (this.durability != 0))
        {
            displayNameOutput.Append(" [");
            displayNameOutput.Append(curDurability);
            displayNameOutput.Append("/");
            displayNameOutput.Append(this.durability);
            displayNameOutput.Append("]");
        }
        return displayNameOutput.ToString();
    }

    public ushort GetQuality(byte upgrade)
    {
        return (ushort) (((((this.tier * 100) - this.baseQuality) * upgrade) / 5) + this.baseQuality);
    }

    public virtual bool HasDurability()
    {
        return true;
    }

    public static bool SlotAccepts(ItemSlot bodySlot, ItemSlot itemAttribute)
    {
        if (bodySlot == itemAttribute)
        {
            return true;
        }
        if ((bodySlot == ItemSlot.FINGER_1) || (bodySlot == ItemSlot.FINGER_2))
        {
            return (itemAttribute == ItemSlot.FINGER);
        }
        if ((bodySlot == ItemSlot.WONDROUS_1) || (bodySlot == ItemSlot.WONDROUS_2))
        {
            return (itemAttribute == ItemSlot.WONDROUS);
        }
        if ((bodySlot == ItemSlot.WEAPON_SET_1_MAIN_HAND) || (bodySlot == ItemSlot.WEAPON_SET_2_MAIN_HAND))
        {
            return (((itemAttribute == ItemSlot.WEAPON_MAIN) || (itemAttribute == ItemSlot.WEAPON_EITHER)) || (itemAttribute == ItemSlot.WEAPON_BOTH));
        }
        if ((bodySlot == ItemSlot.WEAPON_SET_1_OFF_HAND) || (bodySlot == ItemSlot.WEAPON_SET_2_OFF_HAND))
        {
            return ((itemAttribute == ItemSlot.WEAPON_OFFHAND) || (itemAttribute == ItemSlot.WEAPON_EITHER));
        }
        return (((bodySlot == ItemSlot.IMPLEMENT_1) || (bodySlot == ItemSlot.IMPLEMENT_2)) && (itemAttribute == ItemSlot.IMPLEMENT));
    }

    public static string SlotToString(ItemSlot slot)
    {
        switch (slot)
        {
            case ItemSlot.ARMOR:
                return "suit";

            case ItemSlot.HEAD:
                return "head";

            case ItemSlot.FEET:
                return "boot";

            case ItemSlot.HANDS:
                return "glove";

            case ItemSlot.BACK:
                return "back";

            case ItemSlot.WEAPON_SET_1_MAIN_HAND:
            case ItemSlot.WEAPON_SET_1_OFF_HAND:
            case ItemSlot.WEAPON_SET_2_MAIN_HAND:
            case ItemSlot.WEAPON_SET_2_OFF_HAND:
            case ItemSlot.IMPLEMENT_1:
            case ItemSlot.IMPLEMENT_2:
            case ItemSlot.WONDROUS_1:
            case ItemSlot.WONDROUS_2:
            case ItemSlot.WEAPON_MAIN:
            case ItemSlot.WEAPON_OFFHAND:
            case ItemSlot.WEAPON_EITHER:
            case ItemSlot.WEAPON_BOTH:
            case ItemSlot.IMPLEMENT:
            case ItemSlot.WONDROUS:
                return "weapon";
        }
        return string.Empty;
    }

    public static BasicItemData UnittestItem<T>(string name) where T: BasicItemData, new()
    {
        T each = Activator.CreateInstance<T>();
        each.name = name.ToLower();
        each.id = DataClass.GenerateId(each.name);
        ItemDatabase.Index(each);
        return each;
    }

    public enum ItemSlot : byte
    {
        ARMOR = 0,
        BACK = 6,
        FEET = 3,
        FINGER = 0x12,
        FINGER_1 = 7,
        FINGER_2 = 8,
        HANDS = 4,
        HEAD = 2,
        IMPLEMENT = 0x17,
        IMPLEMENT_1 = 13,
        IMPLEMENT_2 = 14,
        NECK = 5,
        NONE = 0x11,
        WAIST = 1,
        WEAPON_BOTH = 0x16,
        WEAPON_EITHER = 0x15,
        WEAPON_MAIN = 0x13,
        WEAPON_OFFHAND = 20,
        WEAPON_SET_1_MAIN_HAND = 9,
        WEAPON_SET_1_OFF_HAND = 10,
        WEAPON_SET_2_MAIN_HAND = 11,
        WEAPON_SET_2_OFF_HAND = 12,
        WONDROUS = 0x18,
        WONDROUS_1 = 15,
        WONDROUS_2 = 0x10
    }
}

