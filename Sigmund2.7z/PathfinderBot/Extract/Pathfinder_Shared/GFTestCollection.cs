﻿using System;
using System.Collections.Generic;

internal class GFTestCollection
{
    public List<int> vals;
}

