﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;

public class ColorData : DataClass
{
    public Color color = Color.white;
    private static Dictionary<int, ColorData> colorsById = new Dictionary<int, ColorData>();
    private static Dictionary<string, ColorData> colorsByName = new Dictionary<string, ColorData>();
    private static ColorData DEFAULT_COLOR;
    [DataRestrict]
    public string nguiColorCode;
    public static ColorData UNKNOWN_COLOR;

    public static Color GetColorById(int id)
    {
        ColorData data;
        if (colorsById.TryGetValue(id, out data))
        {
            return data.color;
        }
        Debug.LogWarning("Don't have color for id: '" + id + "'");
        return UNKNOWN_COLOR.color;
    }

    public static Color GetColorByName(string name, bool logError = true)
    {
        ColorData data;
        if (colorsByName.TryGetValue(name.ToLower(), out data))
        {
            return data.color;
        }
        if (logError)
        {
            GLog.LogWarning(new object[] { "Don't have color for name: '" + name + "'" });
        }
        return UNKNOWN_COLOR.color;
    }

    public static ColorData GetColorDataById(int id)
    {
        ColorData data;
        if (colorsById.TryGetValue(id, out data))
        {
            return data;
        }
        Debug.LogWarning("Don't have color for id: '" + id + "'");
        return UNKNOWN_COLOR;
    }

    public static ColorData GetColorDataByName(string name)
    {
        ColorData data;
        if (colorsByName.TryGetValue(name.ToLower(), out data))
        {
            return data;
        }
        Debug.LogWarning("Don't have color for name: '" + name + "'");
        return UNKNOWN_COLOR;
    }

    public static void OnLoad(List<DataClass> objects)
    {
        colorsByName.Clear();
        colorsById.Clear();
        foreach (ColorData data in objects)
        {
            colorsByName[data.name] = data;
            colorsById[data.id] = data;
            data.nguiColorCode = NguiColorFormatter.ToNguiString(data.color, NguiColorFormatter.StringType.DEFAULT);
        }
        UNKNOWN_COLOR = new ColorData();
        UNKNOWN_COLOR.color = new Color(1f, 0f, 1f);
        UNKNOWN_COLOR.nguiColorCode = NguiColorFormatter.ToNguiString(UNKNOWN_COLOR.color, NguiColorFormatter.StringType.DEFAULT);
        DEFAULT_COLOR = new ColorData();
        DEFAULT_COLOR.color = new Color(0f, 0f, 0f);
        DEFAULT_COLOR.nguiColorCode = NguiColorFormatter.ToNguiString(DEFAULT_COLOR.color, NguiColorFormatter.StringType.DEFAULT);
        colorsById[0] = DEFAULT_COLOR;
    }

    public override DataClass ParseRecord(int index)
    {
        float num;
        float num2;
        float num3;
        float num4;
        ColorData data = new ColorData();
        if (!DataClass.TryGetLCaseCellValue("A", index, out data.name))
        {
            return null;
        }
        if (!((this.TryGetColorValue("B", index, out num) && this.TryGetColorValue("C", index, out num2)) && this.TryGetColorValue("D", index, out num3)))
        {
            return null;
        }
        if (!DataClass.TryGetCellValue("E", index, out num4))
        {
            num4 = 1f;
        }
        else if ((num4 < 0f) || (num4 > 1f))
        {
            DataClass.OutputErrorMessage("E", index, "Alpha value must be between 0.0 and 1.0");
            return null;
        }
        data.color = new Color(num, num2, num3, num4);
        return data;
    }

    public bool TryGetColorValue(string column, int index, out float colorValue)
    {
        int num;
        DataClass.GetCellValue(column, index, out num);
        if ((num < 0) || (num > 0xff))
        {
            DataClass.OutputErrorMessage(column, index, "RGB value must be between 0 and 255.");
            colorValue = 1f;
            return false;
        }
        colorValue = ((float) num) / 255f;
        return true;
    }
}

