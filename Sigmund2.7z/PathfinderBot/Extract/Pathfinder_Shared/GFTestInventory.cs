﻿using System;

internal class GFTestInventory
{
    public GFTestInventoryItem[] body;
    [DataRestrict]
    public GFTestInventoryItem[] equipped;
    [DataSyncTo(2)]
    public GFTestInventoryItem[] inventory;
    public GFTestInventoryItem[] temp;
}

