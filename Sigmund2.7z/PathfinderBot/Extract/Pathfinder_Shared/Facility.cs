﻿using System;
using System.Runtime.CompilerServices;
using UnityEngine;

public abstract class Facility : MonoBehaviour
{
    public static AddFacilityDelegate AddFacility;
    [NonSerialized]
    public ActiveFacility runtimeDetails = null;
    public string staticDetails = "";

    protected Facility()
    {
    }

    public abstract ActiveFacility MakeRuntime();
    public virtual void Start()
    {
        MeshRenderer component = base.GetComponent<MeshRenderer>();
        if (component != 0)
        {
            UnityEngine.Object.Destroy(component);
        }
        MeshFilter filter = base.GetComponent<MeshFilter>();
        if (filter != 0)
        {
            UnityEngine.Object.Destroy(filter);
        }
        if (AddFacility != null)
        {
            AddFacility(this.MakeRuntime());
        }
    }

    public class ActiveFacility
    {
        private static uint _makeFacilityId = 0;
        public readonly uint facilityId;
        public Facility.PlayerInteract interactCallback = null;
        public bool isLinked = false;
        public Vector3 position;

        public ActiveFacility(Vector3 _pos, string staticDetails)
        {
            _makeFacilityId++;
            this.facilityId = _makeFacilityId;
            this.position = _pos;
        }
    }

    public delegate void AddFacilityDelegate(Facility.ActiveFacility facilityPoint);

    public delegate void PlayerInteract(Entity playerEntity, Facility.ActiveFacility facility);
}

