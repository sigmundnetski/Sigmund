﻿using System;

internal class DstItemArrayTest
{
    public InventoryItem[] items;

    public DstItemArrayTest(InventoryItem[] setItems)
    {
        this.items = setItems;
    }
}

