﻿using System;
using System.Runtime.CompilerServices;
using UnityEngine;

public class ActiveSpawnPoint
{
    public static SpawnPointDelegate AddSpawnPoint;
    private NpcSpawnPoint component;
    public readonly GConst.CreateType createFlags;
    public EntityDefnData customDefn;
    public string customName;
    private DateTime delayUntil;
    public readonly EscalationConst.EnemyTag enemyTag;
    public Entity[] entities;
    public EntityDefnData eventDefn;
    public string eventDisplayName;
    public GameObject gameObject;
    public string genericDisplayName;
    public EntityDefnData genericEntityDefn;
    public static SpawnPointDelegate HackDespawn;
    public Vector3 position;
    public readonly TimeSpan respawnDelay;
    public Quaternion rotation;
    public readonly string spawnName;
    public Status status;
    private Transform transform;

    public ActiveSpawnPoint(GConst.CreateType _flags, EscalationConst.EnemyTag _tag, EntityDefnData _customDefn, string _name, TimeSpan _respawnDelay, NpcSpawnPoint _component, Vector3 _pos, Quaternion _rot)
    {
        this.genericEntityDefn = EntityDefnData.DEFAULT_SPAWN_DEFN;
        this.genericDisplayName = null;
        this.eventDefn = null;
        this.eventDisplayName = null;
        this.customDefn = null;
        this.customName = null;
        this.component = null;
        this.gameObject = null;
        this.transform = null;
        this.status = Status.READY;
        this.delayUntil = DateTime.MinValue;
        this.entities = new Entity[1];
        this.createFlags = _flags;
        this.enemyTag = _tag;
        this.spawnName = _name.ToLower();
        this.respawnDelay = _respawnDelay;
        this.position = _pos;
        this.rotation = _rot;
        if (this.enemyTag == EscalationConst.EnemyTag.CUSTOM)
        {
            this.customDefn = _customDefn;
        }
        this.component = _component;
        if (!object.ReferenceEquals(_component, null))
        {
            this.InitUnityObjs(_component);
        }
    }

    public ActiveSpawnPoint(GConst.CreateType _flags, EscalationConst.EnemyTag _tag, string _customDefnName, string _name, TimeSpan _respawnDelay, NpcSpawnPoint _component, Vector3 _pos, Quaternion _rot)
    {
        this.genericEntityDefn = EntityDefnData.DEFAULT_SPAWN_DEFN;
        this.genericDisplayName = null;
        this.eventDefn = null;
        this.eventDisplayName = null;
        this.customDefn = null;
        this.customName = null;
        this.component = null;
        this.gameObject = null;
        this.transform = null;
        this.status = Status.READY;
        this.delayUntil = DateTime.MinValue;
        this.entities = new Entity[1];
        this.createFlags = _flags;
        this.enemyTag = _tag;
        this.spawnName = _name.ToLower();
        this.respawnDelay = _respawnDelay;
        this.position = _pos;
        this.rotation = _rot;
        if (!((this.enemyTag != EscalationConst.EnemyTag.CUSTOM) || string.IsNullOrEmpty(_customDefnName)))
        {
            EntityDefnData.defnByName.TryGetValue(_customDefnName, out this.customDefn);
        }
        this.component = _component;
        if (!object.ReferenceEquals(_component, null))
        {
            this.InitUnityObjs(_component);
        }
    }

    private void _DestroyUnity()
    {
        this.transform.parent = null;
        UnityEngine.Object.Destroy(this.gameObject);
        this.transform = null;
        this.gameObject = null;
        this.component = null;
    }

    public void AttachEntity(Entity newEntity)
    {
        SparseArray.Add<Entity>(ref this.entities, newEntity);
        if (!object.ReferenceEquals(newEntity.gameObject, null))
        {
            SetUnityParent(newEntity, this.transform);
        }
        newEntity.spawnPoint = this;
        this.status = Status.FULL;
    }

    public bool CanSpawn(DateTime curTime)
    {
        return ((this.GetNumActiveNpcs() == 0) && ((this.status == Status.READY) || ((this.status == Status.DELAYED) && (this.delayUntil <= curTime))));
    }

    private void ClearSpawnUnityParent()
    {
        this.transform.parent = null;
    }

    public void DestroyUnity()
    {
        this.status = Status.DISABLED;
        if (!object.ReferenceEquals(this.component, null))
        {
            this._DestroyUnity();
        }
    }

    public void DetachEntity(Entity entity, DateTime curTime)
    {
        int index = SparseArray.IndexOf<Entity>(this.entities, entity);
        if (index != -1)
        {
            if (!object.ReferenceEquals(entity.gameObject, null))
            {
                SetUnityParent(entity, null);
            }
            this.entities[index] = null;
            entity.spawnPoint = null;
        }
        if (this.status != Status.DISABLED)
        {
            this.status = (this.respawnDelay == TimeSpan.Zero) ? Status.DISABLED : Status.DELAYED;
        }
        this.delayUntil = curTime + this.respawnDelay;
    }

    public void DetachFromEncounter()
    {
        this.status = Status.DISABLED;
        if (!object.ReferenceEquals(this.component, null))
        {
            this.ClearSpawnUnityParent();
        }
    }

    public EntityDefnData GetEntityDefn()
    {
        return ((this.customDefn != null) ? this.customDefn : ((this.eventDefn != null) ? this.eventDefn : this.genericEntityDefn));
    }

    public string GetEntityName()
    {
        if (!string.IsNullOrEmpty(this.customName))
        {
            return this.customName;
        }
        if (this.customDefn != null)
        {
            return this.customDefn.displayName;
        }
        if (!string.IsNullOrEmpty(this.eventDisplayName))
        {
            return this.eventDisplayName;
        }
        if (this.eventDefn != null)
        {
            return this.eventDefn.displayName;
        }
        if (!string.IsNullOrEmpty(this.genericDisplayName))
        {
            return this.genericDisplayName;
        }
        return this.genericEntityDefn.displayName;
    }

    public int GetNumActiveNpcs()
    {
        int num = 0;
        for (int i = 0; i < this.entities.Length; i++)
        {
            if (!(((this.entities[i] == null) || (this.entities[i].isValid != Entity.EntityStatus.VALID)) || this.entities[i].dead))
            {
                num++;
            }
        }
        return num;
    }

    private void InitUnityObjs(NpcSpawnPoint _component)
    {
        this.gameObject = _component.gameObject;
        this.transform = _component.transform;
    }

    private static void SetUnityParent(Entity newEntity, Transform newParent)
    {
        newEntity.gameObject.transform.parent = newParent;
    }

    public bool ShouldDestroy()
    {
        return ((this.status == Status.DISABLED) || ((SparseArray.Count<Entity>(this.entities) == 0) && (this.respawnDelay == TimeSpan.Zero)));
    }

    public delegate bool SpawnPointDelegate(ActiveSpawnPoint spawnPoint);

    public enum Status : byte
    {
        DELAYED = 1,
        DISABLED = 0,
        FULL = 3,
        READY = 2
    }
}

