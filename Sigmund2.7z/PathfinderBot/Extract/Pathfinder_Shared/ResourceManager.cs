﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using UnityEngine;

public static class ResourceManager
{
    private static TextureLoader activeLoader = null;
    private static bool cleanupFinished = false;
    private static TextureCleanup[] cleanupsArray = new TextureCleanup[0x400];
    private static Dictionary<Material, Material> copiedMaterials = new Dictionary<Material, Material>();
    private static PanicMode currentPanicState = PanicMode.NeverPanicked;
    private static bool initialized = false;
    private static Dictionary<Material, List<Material>> materialCopies = new Dictionary<Material, List<Material>>();
    private static Material[] materialsArray = new Material[0x400];
    private static Dictionary<Material, RunTimeMaterialInfo> materialsToInfo = new Dictionary<Material, RunTimeMaterialInfo>();
    private const int MAX_PER_UPDATE = 500;
    private static int panicFrequency = 800;
    private static int panicTick = 0;
    public static PigFile pigFile;
    private static Texture PLACEHOLDER = new Texture2D(1, 1);
    private static int previousCleanupIndex = 0;
    private static int previousTextureIndex = 0;
    private static HashSet<int> queuedIndexes = new HashSet<int>();
    private static List<TextureLoader> queuedRequests = new List<TextureLoader>();
    public static Transform referenceXform = null;
    private static Dictionary<TextureCleanup, List<Material>> registeredCleanups = new Dictionary<TextureCleanup, List<Material>>();
    public static bool SERVER_MODE = false;
    private static RunTimeTexInfo[] texInfosArray = new RunTimeTexInfo[0x400];
    private static bool textureFinished = false;
    private static Dictionary<string, RunTimeTexInfo> texturesToInfo = new Dictionary<string, RunTimeTexInfo>();
    private static long totalBytes = 0L;

    private static void _InternalMaterialRegistration(GameObject obj, bool loadTextures, bool blockedLoad, bool stayReadable = false)
    {
        foreach (Transform transform in obj.transform)
        {
            _InternalMaterialRegistration(transform.gameObject, loadTextures, blockedLoad, stayReadable);
        }
        if (obj.renderer != null)
        {
            Material[] sharedMaterials = obj.renderer.sharedMaterials;
            TextureCleanup component = obj.GetComponent<TextureCleanup>();
            if (component == null)
            {
                component = obj.AddComponent<TextureCleanup>();
                component.xform = obj.transform;
                component.extents = obj.renderer.bounds;
            }
            float maxValue = float.MaxValue;
            if (referenceXform != null)
            {
                Transform xform = component.xform;
                component.extents.center = xform.position;
                maxValue = component.extents.SqrDistance(referenceXform.position);
            }
            uint num2 = SparseArray.Add<TextureCleanup>(ref cleanupsArray, component);
            component.index = num2;
            for (int i = 0; i < sharedMaterials.Length; i++)
            {
                if (sharedMaterials[i] != null)
                {
                    registeredCleanups.AddIfMissing<TextureCleanup, Material>(component, sharedMaterials[i], null);
                    RunTimeMaterialInfo materialInfo = GetMaterialInfo(sharedMaterials[i]);
                    if (materialInfo == null)
                    {
                        break;
                    }
                    for (int j = 0; j < materialInfo.constructionData.assetNames.Length; j++)
                    {
                        string texId = materialInfo.constructionData.textureIds[j];
                        string key = materialInfo.constructionData.assetNames[j];
                        RunTimeTexInfo info2 = null;
                        if (!texturesToInfo.TryGetValue(key, out info2))
                        {
                            throw new KeyNotFoundException("Runtime Texture " + key + " was not found.  Requested by: " + obj.name);
                        }
                        info2.AddRef(texId, sharedMaterials[i]);
                        if (loadTextures)
                        {
                            LoadTexture(info2, blockedLoad, stayReadable, maxValue, ResourceConsts.MAX_MIP_LEVEL);
                        }
                    }
                }
            }
        }
    }

    public static Material CopyMaterial(Material material)
    {
        Material item = (Material) UnityEngine.Object.Instantiate(material);
        RunTimeMaterialInfo info = null;
        if (materialsToInfo.TryGetValue(material, out info))
        {
            copiedMaterials[item] = material;
            if (!materialCopies.ContainsKey(material))
            {
                materialCopies[material] = new List<Material>();
            }
            materialCopies[material].Add(item);
            for (int i = 0; i < info.constructionData.textureIds.Length; i++)
            {
                string texId = info.constructionData.textureIds[i];
                string str2 = info.constructionData.assetNames[i];
                texturesToInfo[str2].AddRef(texId, item);
            }
        }
        return item;
    }

    private static int ExpectedMipLevel(float sqrdistance)
    {
        int num = ResourceConsts.DEFAULT_MIP_LEVEL;
        if (sqrdistance <= ResourceConsts.MAX_MIP_SQRDISTANCE)
        {
            return ResourceConsts.MAX_MIP_LEVEL;
        }
        if (sqrdistance <= ResourceConsts.INTERMEDIATE_MIP_START_SQRDISTANCE)
        {
            return -1;
        }
        if (sqrdistance <= ResourceConsts.INTERMEDIATE_MIP_END_SQRDISTANCE)
        {
            return ResourceConsts.INTERMEDIATE_MIP_LEVEL;
        }
        if (sqrdistance <= ResourceConsts.DEFAULT_MIP_SQRDISTANCE)
        {
            return -1;
        }
        return ResourceConsts.DEFAULT_MIP_LEVEL;
    }

    private static string[] GetAllTextureNames()
    {
        if (pigFile != null)
        {
            return pigFile.GetContainedFileNames();
        }
        if (Directory.Exists(ResourceConsts.resourceFolder))
        {
            return Directory.GetFiles(ResourceConsts.resourceFolder, "*.dds", SearchOption.AllDirectories);
        }
        if (Directory.Exists(ResourceConsts.resourceFallbackFolder))
        {
            return Directory.GetFiles(ResourceConsts.resourceFallbackFolder, "*.dds", SearchOption.AllDirectories);
        }
        return null;
    }

    public static Material GetMaterial(Material material, bool stayReadable, bool materialInUse = false)
    {
        RunTimeMaterialInfo info = null;
        if (!materialsToInfo.TryGetValue(material, out info))
        {
            if (!SERVER_MODE)
            {
                GLog.LogWarning(new object[] { "ResourceManager was passed a material(" + material.ToString() + "). This material is not owned by the ResourceManager, this may be indicitive of an error." });
            }
            return material;
        }
        Material material2 = null;
        if (info.constructed)
        {
            material2 = material;
        }
        else if (materialInUse)
        {
            material2 = LoadMaterial(material, stayReadable, ResourceConsts.MAX_MIP_LEVEL);
        }
        else
        {
            material2 = LoadMaterial(material, stayReadable, ResourceConsts.DEFAULT_MIP_LEVEL);
        }
        return material2;
    }

    private static RunTimeMaterialInfo GetMaterialInfo(Material mat)
    {
        if (mat == null)
        {
            return null;
        }
        RunTimeMaterialInfo info = null;
        if (!materialsToInfo.TryGetValue(mat, out info))
        {
            Material material = null;
            if (copiedMaterials.TryGetValue(mat, out material))
            {
                materialsToInfo.TryGetValue(material, out info);
            }
        }
        return info;
    }

    public static Texture GetTexture(string textureName, bool stayReadable, int mipLevel)
    {
        RunTimeTexInfo info = null;
        if (!texturesToInfo.TryGetValue(textureName, out info))
        {
            return PLACEHOLDER;
        }
        if ((mipLevel != ResourceConsts.DEFAULT_MIP_LEVEL) && IsLoadRequired(info, false, stayReadable, mipLevel))
        {
            TextureLoader loader = new TextureLoader(textureName, info.index, stayReadable, mipLevel, 0f, false);
            loader.LoadResource();
            loader.FinalizeLoad();
            totalBytes += info.SwapTexture(loader.texInfo);
            return info.tex;
        }
        if (info.tex != null)
        {
            return info.tex;
        }
        return info.baselineTex;
    }

    public static string GetTextureStatistics()
    {
        StringBuilder quickText = GUtil.GetQuickText();
        quickText.Append("-- ResourceManager Statistics:");
        quickText.Append(GUtil.PrettyPrint(new object[] { 
            "\ntextures:", texturesToInfo.Count, texturesToInfo.Keys, "\ntexInfos:", texInfosArray.Length, texInfosArray, "\nmaterials:", materialsToInfo.Count, materialsToInfo.Keys, "\ncopiedMaterials:", copiedMaterials.Count, copiedMaterials.Keys, "\nmaterialCopies:", materialCopies.Count, materialCopies.Keys, "\nregisteredCleanups:", 
            registeredCleanups.Count, registeredCleanups.Keys, "\nmaterialsArray:", materialsArray.Length, SparseArray.Count<Material>(materialsArray), "\ncleanupsArray:", cleanupsArray.Length, SparseArray.Count<TextureCleanup>(cleanupsArray), "\nqueuedRequests:", queuedRequests.Count, "\n\nPanic Values:", "\nCurrent Bytes:", totalBytes, "\nPanic Mode:", currentPanicState, "\n\nResourceConsts Values:", 
            "\nTEXTURE_THRESHOLD_PANIC", ResourceConsts.TEXTURE_THRESHOLD_PANIC, "\nTEXTURE_THRESHOLD_CALM", ResourceConsts.TEXTURE_THRESHOLD_CALM, "\nMAX_MIP_SQRDISTANCE", ResourceConsts.MAX_MIP_SQRDISTANCE, "\nINTERMEDIATE_MIP_START_SQRDISTANCE", ResourceConsts.INTERMEDIATE_MIP_START_SQRDISTANCE, "\nINTERMEDIATE_MIP_END_SQRDISTANCE", ResourceConsts.INTERMEDIATE_MIP_END_SQRDISTANCE, "\nDEFAULT_MIP_SQRDISTANCE", ResourceConsts.DEFAULT_MIP_SQRDISTANCE, "\nMAX_MIP_LEVEL", ResourceConsts.MAX_MIP_LEVEL, "\nINTERMEDIATE_MIP_LEVEL", ResourceConsts.INTERMEDIATE_MIP_LEVEL, 
            "\nDEFAULT_MIP_LEVEL", ResourceConsts.DEFAULT_MIP_LEVEL
         }, " ", null));
        return quickText.ToString();
    }

    private static bool IsLoadRequired(RunTimeTexInfo texInfo, bool isDowngradable, bool stayReadable, int desiredMipLevel)
    {
        return (((texInfo.tex == null) && (desiredMipLevel != ResourceConsts.DEFAULT_MIP_LEVEL)) || (!(isDowngradable || !texInfo.isDowngradable) || (!(!stayReadable || texInfo.isReadable) || (desiredMipLevel != texInfo.currentMipLevel))));
    }

    public static bool IsMaterialUpgraded(Material material, int desiredMipLevel)
    {
        RunTimeMaterialInfo materialInfo = GetMaterialInfo(material);
        if (materialInfo != null)
        {
            for (int i = 0; i < materialInfo.constructionData.assetNames.Length; i++)
            {
                string key = materialInfo.constructionData.assetNames[i];
                RunTimeTexInfo info2 = null;
                if (!texturesToInfo.TryGetValue(key, out info2))
                {
                    return false;
                }
                if (info2.currentMipLevel > desiredMipLevel)
                {
                    return false;
                }
            }
        }
        return true;
    }

    public static bool LoadingTick()
    {
        if (!initialized)
        {
            if (File.Exists(ResourceConsts.pigFileName))
            {
                pigFile = new PigFile(ResourceConsts.pigFileName);
            }
            string[] allTextureNames = GetAllTextureNames();
            if (allTextureNames != null)
            {
                texInfosArray = new RunTimeTexInfo[allTextureNames.Length];
                for (int i = 0; i < allTextureNames.Length; i++)
                {
                    string fileName = Path.GetFileName(allTextureNames[i]);
                    TextureLoader loader = new TextureLoader(fileName, i, false, ResourceConsts.DEFAULT_MIP_LEVEL, float.MaxValue, true);
                    loader.LoadResource();
                    loader.FinalizeLoad();
                    texturesToInfo[fileName] = loader.texInfo;
                    texInfosArray[i] = loader.texInfo;
                    totalBytes += loader.texInfo.dataSize;
                }
            }
            initialized = true;
        }
        return true;
    }

    private static Material LoadMaterial(Material material, bool stayReadable, int mipMapLevel)
    {
        RunTimeMaterialInfo materialInfo = GetMaterialInfo(material);
        if (materialInfo != null)
        {
            for (int i = 0; i < materialInfo.constructionData.textureIds.Length; i++)
            {
                string texId = materialInfo.constructionData.textureIds[i];
                string key = materialInfo.constructionData.assetNames[i];
                RunTimeTexInfo info2 = null;
                if (texturesToInfo.TryGetValue(key, out info2))
                {
                    info2.AddRef(texId, material);
                    if (mipMapLevel != ResourceConsts.DEFAULT_MIP_LEVEL)
                    {
                        TextureLoader loader = new TextureLoader(key, info2.index, stayReadable, mipMapLevel, 0f, false);
                        loader.LoadResource();
                        loader.FinalizeLoad();
                        totalBytes += info2.SwapTexture(loader.texInfo);
                    }
                }
            }
            materialInfo.constructed = true;
        }
        return material;
    }

    private static void LoadTexture(RunTimeTexInfo texInfo, bool blockedLoad, bool stayReadable, float sqrdistance, int desiredMipLevel)
    {
        if (IsLoadRequired(texInfo, false, stayReadable, desiredMipLevel))
        {
            TextureLoader item = new TextureLoader(texInfo.name, texInfo.index, stayReadable, desiredMipLevel, sqrdistance, false);
            if (blockedLoad || (referenceXform == null))
            {
                item.LoadResource();
                item.FinalizeLoad();
                totalBytes += texInfo.SwapTexture(item.texInfo);
            }
            else
            {
                queuedRequests.Add(item);
                queuedIndexes.Add(texInfo.index);
            }
        }
    }

    public static void RegisterForDynamicTextures(GameObject obj)
    {
        if ((obj != null) && !SERVER_MODE)
        {
            _InternalMaterialRegistration(obj, false, false, false);
            if (queuedRequests.Count > 0)
            {
                queuedRequests.Sort(new Comparison<TextureLoader>(ResourceManager.SortByLeastDistance));
            }
        }
    }

    public static void RegisterForNondynamicTextures(GameObject obj, bool blockedLoad, bool stayReadable = false)
    {
        if ((obj != null) && !SERVER_MODE)
        {
            _InternalMaterialRegistration(obj, true, blockedLoad, stayReadable);
            if (queuedRequests.Count > 0)
            {
                queuedRequests.Sort(new Comparison<TextureLoader>(ResourceManager.SortByLeastDistance));
            }
        }
    }

    public static void RegisterMaterials(ShaderHolder shaderHolder, bool materialsInUse = false)
    {
        MaterialInfoArray array = (MaterialInfoArray) DataUtilities.DeserializeObjectFromDisk(shaderHolder.materialDictionary.bytes, typeof(MaterialInfoArray));
        if (array != null)
        {
            if (shaderHolder.materials.Length != array.array.Length)
            {
                GLog.LogError(new object[] { string.Concat(new object[] { "Number of materials in bundle(", shaderHolder.materials.Length, ") does not match number of material info objects(", array.array.Length, ")\n" }), "Materials:", shaderHolder.materials, "\nMaterialInfos:", array.array });
            }
            else
            {
                uint probableIndex = 0;
                for (int i = 0; i < array.array.Length; i++)
                {
                    MaterialInfo info = array.array[i];
                    Material material = shaderHolder.materials[i];
                    materialsToInfo[material] = new RunTimeMaterialInfo(info);
                    probableIndex = SparseArray.Add<Material>(ref materialsArray, material, probableIndex);
                    GetMaterial(material, false, materialsInUse);
                }
            }
        }
    }

    public static void ReleaseMaterial(Material inputMat, TextureCleanup cleanup = null)
    {
        if (inputMat != null)
        {
            bool flag = false;
            Material material = null;
            if (copiedMaterials.TryGetValue(inputMat, out material))
            {
                flag = true;
            }
            else
            {
                material = inputMat;
            }
            List<Material> list = null;
            if ((cleanup != null) && registeredCleanups.TryGetValue(cleanup, out list))
            {
                list.Remove(inputMat);
                if (list.Count == 0)
                {
                    registeredCleanups.Remove(cleanup);
                    cleanupsArray[cleanup.index] = null;
                }
            }
            RunTimeMaterialInfo info = null;
            if (materialsToInfo.TryGetValue(material, out info))
            {
                string[] assetNames = info.constructionData.assetNames;
                string[] textureIds = info.constructionData.textureIds;
                for (int i = 0; i < assetNames.Length; i++)
                {
                    RunTimeTexInfo info2 = null;
                    if (texturesToInfo.TryGetValue(assetNames[i], out info2))
                    {
                        info2.DelRef(textureIds[i], inputMat);
                    }
                }
            }
            if (flag)
            {
                list = null;
                if (materialCopies.TryGetValue(material, out list))
                {
                    list.Remove(inputMat);
                    if (list.Count == 0)
                    {
                        materialCopies.Remove(material);
                    }
                }
                copiedMaterials.Remove(inputMat);
                UnityEngine.Object.Destroy(inputMat);
            }
        }
    }

    public static void ReleaseMaterials(TextureCleanup cleanup)
    {
        if (cleanup.renderer != null)
        {
            Material[] sharedMaterials = cleanup.renderer.sharedMaterials;
            for (int i = 0; i < sharedMaterials.Length; i++)
            {
                ReleaseMaterial(sharedMaterials[i], cleanup);
            }
        }
        registeredCleanups.Remove(cleanup);
        cleanupsArray[cleanup.index] = null;
    }

    private static int SortByLeastDistance(TextureLoader obj1, TextureLoader obj2)
    {
        if (obj1.sqrdistance < obj2.sqrdistance)
        {
            return -1;
        }
        if (obj1.sqrdistance > obj2.sqrdistance)
        {
            return 1;
        }
        if (obj1.sqrdistance == obj2.sqrdistance)
        {
            return 0;
        }
        if (!float.IsNaN(obj1.sqrdistance))
        {
            return 1;
        }
        return (!float.IsNaN(obj2.sqrdistance) ? -1 : 0);
    }

    public static bool SyncUpdate()
    {
        RunTimeTexInfo info;
        if ((activeLoader != null) && (activeLoader.CurrentStatus == ResourceLoader.Status.Loaded))
        {
            activeLoader.FinalizeLoad();
            info = texturesToInfo[activeLoader.texName];
            totalBytes += info.SwapTexture(activeLoader.texInfo);
            activeLoader = null;
        }
        if ((activeLoader == null) && (queuedRequests.Count > 0))
        {
            int num = 0;
            bool flag = false;
            do
            {
                TextureLoader loader = queuedRequests[0];
                queuedRequests.RemoveAt(0);
                queuedIndexes.Remove(loader.index);
                info = texturesToInfo[loader.texName];
                if (IsLoadRequired(info, loader.isDowngradable, loader.stayReadable, loader.mipLevel))
                {
                    activeLoader = loader;
                    ThreadPool.QueueUserWorkItem(new WaitCallback(activeLoader.LoadResource));
                }
                else
                {
                    info.UpdateReferencedMaterials();
                    num++;
                }
            }
            while ((!flag && (queuedRequests.Count > 0)) && (num < 500));
        }
        if (referenceXform != null)
        {
            UpdateDistances();
        }
        return true;
    }

    public static void TextureStatistics(string[] args, EntityId playerEntityId)
    {
        GLog.LogWarning(new object[] { GetTextureStatistics() });
    }

    public static void UpdateDistances()
    {
        int num2;
        RunTimeTexInfo info2;
        if ((currentPanicState == PanicMode.NeverPanicked) && (totalBytes > ResourceConsts.TEXTURE_THRESHOLD_PANIC))
        {
            currentPanicState = PanicMode.Decreasing;
        }
        if (currentPanicState != PanicMode.NeverPanicked)
        {
            if (panicTick == 0)
            {
                if (((currentPanicState == PanicMode.None) || (currentPanicState == PanicMode.Maximum)) && (totalBytes > ResourceConsts.TEXTURE_THRESHOLD_PANIC))
                {
                    currentPanicState = PanicMode.Decreasing;
                }
                else if (((currentPanicState == PanicMode.None) || (currentPanicState == PanicMode.Minimum)) && (totalBytes < ResourceConsts.TEXTURE_THRESHOLD_CALM))
                {
                    currentPanicState = PanicMode.Increasing;
                }
                else if (((currentPanicState == PanicMode.Decreasing) && (totalBytes < ResourceConsts.TEXTURE_THRESHOLD_PANIC)) || ((currentPanicState == PanicMode.Increasing) && (totalBytes > ResourceConsts.TEXTURE_THRESHOLD_CALM)))
                {
                    currentPanicState = PanicMode.None;
                }
                if ((currentPanicState == PanicMode.Increasing) || (currentPanicState == PanicMode.Decreasing))
                {
                    float num = (currentPanicState == PanicMode.Increasing) ? ResourceConsts.qualityData.increasingMultiplier : ResourceConsts.qualityData.decreasingMultiplier;
                    ResourceConsts.MAX_MIP_SQRDISTANCE = Mathf.Clamp(ResourceConsts.MAX_MIP_SQRDISTANCE * num, ResourceConsts.qualityData.minSqrdistanceMaxMip, ResourceConsts.qualityData.maxSqrdistanceMaxMip);
                    ResourceConsts.INTERMEDIATE_MIP_START_SQRDISTANCE = Mathf.Clamp(ResourceConsts.INTERMEDIATE_MIP_START_SQRDISTANCE * num, ResourceConsts.qualityData.minSqrdistanceIntermediateMipStart, ResourceConsts.qualityData.maxSqrdistanceIntermediateMipStart);
                    ResourceConsts.INTERMEDIATE_MIP_END_SQRDISTANCE = Mathf.Clamp(ResourceConsts.INTERMEDIATE_MIP_END_SQRDISTANCE * num, ResourceConsts.qualityData.minSqrdistanceIntermediateMipEnd, ResourceConsts.qualityData.maxSqrdistanceIntermediateMipEnd);
                    ResourceConsts.DEFAULT_MIP_SQRDISTANCE = Mathf.Clamp(ResourceConsts.DEFAULT_MIP_SQRDISTANCE * num, ResourceConsts.qualityData.minSqrdistanceDefaultMip, ResourceConsts.qualityData.maxSqrdistanceDefaultMip);
                    if ((((ResourceConsts.MAX_MIP_SQRDISTANCE == ResourceConsts.qualityData.maxSqrdistanceMaxMip) && (ResourceConsts.INTERMEDIATE_MIP_START_SQRDISTANCE == ResourceConsts.qualityData.maxSqrdistanceIntermediateMipStart)) && (ResourceConsts.INTERMEDIATE_MIP_END_SQRDISTANCE == ResourceConsts.qualityData.maxSqrdistanceIntermediateMipEnd)) && (ResourceConsts.DEFAULT_MIP_SQRDISTANCE == ResourceConsts.qualityData.maxSqrdistanceDefaultMip))
                    {
                        currentPanicState = PanicMode.Maximum;
                    }
                    else if ((((ResourceConsts.MAX_MIP_SQRDISTANCE == ResourceConsts.qualityData.minSqrdistanceMaxMip) && (ResourceConsts.INTERMEDIATE_MIP_START_SQRDISTANCE == ResourceConsts.qualityData.minSqrdistanceIntermediateMipStart)) && (ResourceConsts.INTERMEDIATE_MIP_END_SQRDISTANCE == ResourceConsts.qualityData.minSqrdistanceIntermediateMipEnd)) && (ResourceConsts.DEFAULT_MIP_SQRDISTANCE == ResourceConsts.qualityData.minSqrdistanceDefaultMip))
                    {
                        currentPanicState = PanicMode.Minimum;
                    }
                }
            }
            panicTick = (panicTick + 1) % panicFrequency;
        }
        if (cleanupFinished && textureFinished)
        {
            RunTimeTexInfo.ChangeMode();
            previousCleanupIndex = 0;
            previousTextureIndex = 0;
            cleanupFinished = false;
            textureFinished = false;
        }
        for (num2 = previousCleanupIndex; (num2 < (previousCleanupIndex + 500)) && (num2 < cleanupsArray.Length); num2++)
        {
            if (cleanupsArray[num2] != null)
            {
                Transform xform = cleanupsArray[num2].xform;
                cleanupsArray[num2].extents.center = xform.position;
                float input = cleanupsArray[num2].extents.SqrDistance(referenceXform.position);
                TextureCleanup cleanup = cleanupsArray[num2];
                List<Material> list = registeredCleanups[cleanup];
                foreach (Material material in list)
                {
                    RunTimeMaterialInfo materialInfo = GetMaterialInfo(material);
                    if (materialInfo != null)
                    {
                        for (int i = 0; i < materialInfo.constructionData.assetNames.Length; i++)
                        {
                            info2 = null;
                            if (texturesToInfo.TryGetValue(materialInfo.constructionData.assetNames[i], out info2))
                            {
                                info2.SetSqrDistance(input);
                            }
                        }
                    }
                }
            }
        }
        previousCleanupIndex += 500;
        if (previousCleanupIndex >= cleanupsArray.Length)
        {
            cleanupFinished = true;
        }
        for (num2 = previousTextureIndex; (num2 < (previousTextureIndex + 500)) && (num2 < texInfosArray.Length); num2++)
        {
            if (texInfosArray[num2] != null)
            {
                info2 = texInfosArray[num2];
                if (info2.isDowngradable)
                {
                    float sqrDistance = info2.GetSqrDistance();
                    if ((info2.tex != null) && (sqrDistance == float.MaxValue))
                    {
                        totalBytes += info2.RemoveTexture();
                    }
                    else
                    {
                        info2.ResetSqrDistance();
                        int num6 = ExpectedMipLevel(sqrDistance);
                        if ((num6 != -1) && (num6 != info2.currentMipLevel))
                        {
                            if (num6 < ResourceConsts.DEFAULT_MIP_LEVEL)
                            {
                                if (!queuedIndexes.Contains(num2))
                                {
                                    TextureLoader item = new TextureLoader(info2.name, num2, false, num6, sqrDistance, true);
                                    queuedRequests.Add(item);
                                    queuedIndexes.Add(num2);
                                }
                            }
                            else if (info2.tex != null)
                            {
                                totalBytes += info2.RemoveTexture();
                            }
                        }
                    }
                }
            }
        }
        previousTextureIndex += 500;
        if (previousTextureIndex >= texInfosArray.Length)
        {
            textureFinished = true;
        }
        if (queuedRequests.Count > 0)
        {
            queuedRequests.Sort(new Comparison<TextureLoader>(ResourceManager.SortByLeastDistance));
        }
    }

    private enum PanicMode
    {
        NeverPanicked,
        None,
        Increasing,
        Decreasing,
        Maximum,
        Minimum
    }
}

