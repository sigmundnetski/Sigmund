﻿using System;

public class InfoTableOfContents : TableOfContents
{
    public InfoTableOfContents()
    {
    }

    public InfoTableOfContents(string inType, uint[] inOffsets) : base(inType, inOffsets)
    {
    }
}

