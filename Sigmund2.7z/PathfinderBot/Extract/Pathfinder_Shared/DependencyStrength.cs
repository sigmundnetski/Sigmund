﻿using System;

public enum DependencyStrength
{
    INVALID,
    LOOSE,
    STRONG
}

