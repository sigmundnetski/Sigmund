﻿using GNetwork;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

internal class DataSerializerTest : UUnitTestCase
{
    [UUnitTestMethod]
    public void Array()
    {
        int[] numArray = new int[] { 1, 2, 3, 4, 5 };
        GFArrayTest test = new GFArrayTest {
            array = numArray
        };
        byte[] bytes = DataUtilities.SerializeObjectToDisk(test);
        object obj2 = DataUtilities.DeserializeObjectFromDisk(bytes, typeof(GFArrayTest));
        byte[] second = DataUtilities.SerializeObjectToDisk(obj2);
        UUnitAssert.True(bytes.SequenceEqual<byte>(second), "Fail");
        GFArrayTest test2 = (GFArrayTest) obj2;
        UUnitAssert.Equals(test.array.Length, test2.array.Length, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        for (int i = 0; i < test.array.Length; i++)
        {
            UUnitAssert.Equals(test.array[i], test2.array[i], "The elements are not equal at index: [" + i + "]");
        }
    }

    [UUnitTestMethod]
    public void ArrayDelta()
    {
        int num;
        int[] objA = new int[] { 1, 3, 5, 7, 8, 6, 4 };
        int[] numArray2 = new int[] { 1, 5, 3, 7, 9, 8, 6, 4, 2 };
        GFTestArrayDelta delta = new GFTestArrayDelta {
            array = objA
        };
        GFTestArrayDelta delta2 = new GFTestArrayDelta {
            array = numArray2
        };
        byte[] bytes = DataUtilities.SerializeObjectToNetwork(0, delta, null);
        byte[] buffer2 = DataUtilities.SerializeObjectToNetwork(0, delta2, null);
        byte[] buffer3 = DataUtilities.SerializeObjectToNetwork(0, delta2, delta);
        GFTestArrayDelta something = (GFTestArrayDelta) DataUtilities.DeserializeObjectFromNetwork(bytes, typeof(GFTestArrayDelta), 0, null);
        GFTestArrayDelta delta4 = (GFTestArrayDelta) DataUtilities.DeserializeObjectFromNetwork(buffer3, typeof(GFTestArrayDelta), 0, delta);
        UUnitAssert.True(bytes.Length < buffer2.Length, "The two full serialized lengths are incorrect.");
        UUnitAssert.True(buffer3.Length < buffer2.Length, "The delta length is not shorter than the full length.");
        UUnitAssert.NotNull(something, "Null object not expected.");
        for (num = 0; num < objA.Length; num++)
        {
            UUnitAssert.Equals(something.array[num], objA[num], "int values at index [" + num + "] are not equivalent");
        }
        UUnitAssert.NotNull(delta4, "Null object not expected.");
        for (num = 0; num < numArray2.Length; num++)
        {
            UUnitAssert.Equals(delta4.array[num], numArray2[num], "int values at index [" + num + "] are not equivalent");
        }
        UUnitAssert.False(object.ReferenceEquals(objA, delta.array), "Fail");
        UUnitAssert.False(object.ReferenceEquals(objA, delta4.array), "Fail");
        UUnitAssert.True(object.ReferenceEquals(delta, delta4), "Fail");
    }

    [UUnitTestMethod]
    public void ByteEnum()
    {
        GFTestIntEnum testIntEnumObject = new GFTestIntEnum {
            id = 1,
            status = GFTestIntEnum.Status.Valid
        };
        UUnitAssert.Raises(() => DataUtilities.SerializeObjectToDisk(testIntEnumObject), typeof(NotSupportedException), new object[0]);
        UUnitAssert.Raises(() => DataUtilities.SerializeObjectToNetwork(0, testIntEnumObject, null), typeof(NotSupportedException), new object[0]);
        GFTestByteEnum enum2 = new GFTestByteEnum {
            id = 1,
            status = GFTestByteEnum.Status.Valid
        };
        byte[] serializedByteEnumObjectDisk = DataUtilities.SerializeObjectToDisk(enum2);
        GFTestByteEnum target = (GFTestByteEnum) DataUtilities.DeserializeObjectFromDisk(serializedByteEnumObjectDisk, typeof(GFTestByteEnum));
        UUnitAssert.True(enum2.DataEquals(target, 0xff), "Fail");
        UUnitAssert.Raises(() => DataUtilities.DeserializeObjectFromDisk(serializedByteEnumObjectDisk, typeof(GFTestIntEnum)), typeof(NotSupportedException), new object[0]);
        byte[] serializedByteEnumObjectNetwork = DataUtilities.SerializeObjectToNetwork(0, enum2, null);
        GFTestByteEnum enum4 = (GFTestByteEnum) DataUtilities.DeserializeObjectFromNetwork(serializedByteEnumObjectNetwork, typeof(GFTestByteEnum), 0, null);
        UUnitAssert.True(enum2.DataEquals(enum4, 0xff), "Fail");
        UUnitAssert.Raises(() => DataUtilities.DeserializeObjectFromDisk(serializedByteEnumObjectNetwork, typeof(GFTestIntEnum)), typeof(NotSupportedException), new object[0]);
    }

    [UUnitTestMethod]
    public void ClassDataTest()
    {
        string tName = "TestDataClass Test Object";
        int tInt = 5;
        float tFloat = 1.532f;
        bool tBool = true;
        string[] tStrings = new string[] { "1", "2", "3", "4", "5" };
        TestDataClass class2 = new TestDataClass(tName, tInt, tFloat, tBool, tStrings);
        byte[] bytes = DataUtilities.SerializeObjectToDisk(class2);
        object obj2 = DataUtilities.DeserializeObjectFromDisk(bytes, typeof(TestDataClass));
        byte[] second = DataUtilities.SerializeObjectToDisk(obj2);
        UUnitAssert.True(bytes.SequenceEqual<byte>(second), "The serialized and reserialized byte arrays are not equivalent");
        UUnitAssert.Equals(class2, obj2, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        TestDataClass class3 = (TestDataClass) obj2;
        UUnitAssert.Equals(class3.id, DataClass.GenerateId(tName), "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(class3.name, tName.ToLower(), "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(class3.testInt, tInt, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(class3.testFloat, tFloat, 0.0001f, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(class3.testBool, tBool, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(class3.testStrings.Length, tStrings.Length, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        for (int i = 0; i < tStrings.Length; i++)
        {
            UUnitAssert.Equals(class3.testStrings[i], tStrings[i], "testStrings are not equal at index [" + i + "]");
        }
    }

    [UUnitTestMethod]
    public void CollectionObject()
    {
        int num;
        Random random = new Random();
        GFTestQuest quest = new GFTestQuest {
            states = new List<GFTestBaseState>()
        };
        for (num = 0; num < 10; num++)
        {
            int num2 = random.Next(0, 3);
            GFTestBaseState item = null;
            switch (num2)
            {
                case 0:
                    item = new GFTestBaseState {
                        id = 5,
                        name = "base_name"
                    };
                    break;

                case 1:
                    item = new GFTestInteractState();
                    ((GFTestInteractState) item).id = 10;
                    ((GFTestInteractState) item).name = "interact_name";
                    ((GFTestInteractState) item).responseText = "interact_response";
                    ((GFTestInteractState) item).despawn = true;
                    break;

                case 2:
                    item = new GFTestKillState();
                    ((GFTestKillState) item).id = 15;
                    ((GFTestKillState) item).name = "kill_name";
                    ((GFTestKillState) item).helpText = "kill_help";
                    ((GFTestKillState) item).damage = 2f;
                    break;
            }
            quest.states.Add(item);
        }
        byte[] bytes = DataUtilities.SerializeObjectToDisk(quest);
        object obj2 = DataUtilities.DeserializeObjectFromDisk(bytes, typeof(GFTestQuest));
        byte[] second = DataUtilities.SerializeObjectToDisk(obj2);
        UUnitAssert.True(bytes.SequenceEqual<byte>(second), "Fail");
        GFTestQuest something = (GFTestQuest) obj2;
        UUnitAssert.NotNull(something, "Null object not expected.");
        UUnitAssert.NotNull(something.states, "Null object not expected.");
        for (num = 0; num < something.states.Count; num++)
        {
            GFTestKillState state4;
            UUnitAssert.Equals(quest.states[num].GetType(), something.states[num].GetType(), "The values aren't equal for index [" + num + "].");
            UUnitAssert.Equals(quest.states[num].id, something.states[num].id, "The values aren't equal for id @ index [" + num + "].");
            UUnitAssert.Equals(quest.states[num].name, something.states[num].name, "The values aren't equal for name @ index [" + num + "].");
            string str2 = quest.states[num].GetType().ToString();
            if (str2 != null)
            {
                if (!(str2 == "GFTestInteractState"))
                {
                    if (str2 == "GFTestKillState")
                    {
                        goto Label_0309;
                    }
                }
                else
                {
                    GFTestInteractState state2 = (GFTestInteractState) quest.states[num];
                    GFTestInteractState state3 = (GFTestInteractState) something.states[num];
                    UUnitAssert.Equals(state2.responseText, state3.responseText, "The values aren't equal for responseText @ index [" + num + "].");
                    UUnitAssert.Equals(state2.despawn, state3.despawn, "The values aren't equal for despawn @ index [" + num + "].");
                }
            }
            continue;
        Label_0309:
            state4 = (GFTestKillState) quest.states[num];
            GFTestKillState state5 = (GFTestKillState) something.states[num];
            UUnitAssert.Equals(state4.helpText, state5.helpText, "The values aren't equal for helpText @ index [" + num + "].");
            UUnitAssert.Equals(state4.damage, state5.damage, "The values aren't equal for damage @ index [" + num + "].");
        }
    }

    [UUnitTestMethod]
    public void CollectionPrimitive()
    {
        int num;
        GFTestCollection tests = new GFTestCollection {
            vals = new List<int>()
        };
        for (num = 0; num < 10; num++)
        {
            tests.vals.Add(num * 100);
        }
        byte[] bytes = DataUtilities.SerializeObjectToDisk(tests);
        object obj2 = DataUtilities.DeserializeObjectFromDisk(bytes, typeof(GFTestCollection));
        byte[] second = DataUtilities.SerializeObjectToDisk(obj2);
        UUnitAssert.True(bytes.SequenceEqual<byte>(second), "Fail");
        GFTestCollection something = (GFTestCollection) obj2;
        UUnitAssert.NotNull(something, "Null object not expected.");
        UUnitAssert.NotNull(something.vals, "Null object not expected.");
        for (num = 0; num < something.vals.Count; num++)
        {
            UUnitAssert.True(tests.vals[num] == something.vals[num], "The values aren't equal for index [" + num + "].");
        }
    }

    [UUnitTestMethod]
    public void CombatClassData()
    {
        int num2;
        string str = "New Player";
        int num = 100;
        CombatDefense defense = new CombatDefense();
        for (num2 = 0; num2 < defense.defense.Length; num2++)
        {
            defense.defense[num2] = num2;
        }
        CombatResistance resistance = new CombatResistance();
        for (num2 = 0; num2 < resistance.resistance.Length; num2++)
        {
            resistance.resistance[num2] = num2;
        }
        CombatAttackBonus bonus = new CombatAttackBonus();
        for (num2 = 0; num2 < bonus.attackBonus.Length; num2++)
        {
            bonus.attackBonus[num2] = num2;
        }
        TestDataSerializerSimpleClass[][] classArray = new TestDataSerializerSimpleClass[3][];
        for (num2 = 0; num2 < 3; num2++)
        {
            classArray[num2] = new TestDataSerializerSimpleClass[2];
        }
        classArray[0][0] = new TestDataSerializerSimpleClass(TestDataSerializerSimpleClass.TestSerializeEnum.ONE, 0x2a, 300, 0);
        TestDataSerializerSimpleClass class2 = new TestDataSerializerSimpleClass(TestDataSerializerSimpleClass.TestSerializeEnum.TWO, 0x2329, 120, 0);
        int[] numArray = new int[] { 2, 4, 8 };
        TestDataSerializerComplexClass class3 = new TestDataSerializerComplexClass(str, num, defense, resistance, bonus, classArray, class2, numArray);
        byte[] bytes = DataUtilities.SerializeObjectToDisk(class3);
        object obj2 = DataUtilities.DeserializeObjectFromDisk(bytes, typeof(TestDataSerializerComplexClass));
        byte[] second = DataUtilities.SerializeObjectToDisk(obj2);
        UUnitAssert.True(bytes.SequenceEqual<byte>(second), "The serialized and reserialized byte arrays are not equivalent");
        TestDataSerializerComplexClass class4 = (TestDataSerializerComplexClass) obj2;
        UUnitAssert.Equals(class4.name, class3.name, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(class4.testInt1, class3.testInt1, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(class4.weaponItemSets[0][0].testInt, class3.weaponItemSets[0][0].testInt, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(class4.weaponItemSets[1].Length, class3.weaponItemSets[1].Length, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(class4.weaponItemSets[2].Length, class3.weaponItemSets[2].Length, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(class4.armorItem.testInt, class3.armorItem.testInt, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.True(class4.passiveFeatIds.SequenceEqual<int>(class3.passiveFeatIds), "The serialized and reserialized passive feat arrays are not equivalent");
    }

    [UUnitTestMethod]
    public void ConstMember()
    {
        GFTestConstMember member = new GFTestConstMember();
        byte[] bytes = DataUtilities.SerializeObjectToDisk(member);
        byte[] second = DataUtilities.SerializeObjectToDisk(DataUtilities.DeserializeObjectFromDisk(bytes, typeof(GFTestConstMember)));
        UUnitAssert.True(bytes.SequenceEqual<byte>(second), "Fail");
        UUnitAssert.True(bytes.Length < "Testing Const String".Length, "Fail");
    }

    [UUnitTestMethod]
    public void Delta()
    {
        GFTestDelta delta = new GFTestDelta {
            id = 5,
            name = "Player 1"
        };
        GFTestDelta delta2 = new GFTestDelta {
            id = 5,
            name = "Player 2"
        };
        byte[] buffer = DataUtilities.SerializeObjectToNetwork(0, delta, null);
        GFTestDelta something = (GFTestDelta) DataUtilities.DeserializeObjectFromNetwork(DataUtilities.SerializeObjectToNetwork(0, delta2, delta), typeof(GFTestDelta), 0, delta);
        UUnitAssert.NotNull(something, "Null object not expected.");
        UUnitAssert.Equals(something.id, delta2.id, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(something.name, delta2.name, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.True(object.ReferenceEquals(delta, something), "Fail");
    }

    [UUnitTestMethod]
    public void DifferentLevelsWithDelta()
    {
        GFTestBaseEntity entity = new GFTestBaseEntity {
            id = 1,
            inventory = new GFTestInventory()
        };
        entity.inventory.equipped = new GFTestInventoryItem[] { new GFTestInventoryItem(1, "test1"), new GFTestInventoryItem(2, "test2"), new GFTestInventoryItem(3, "test3"), new GFTestInventoryItem(4, "test4"), new GFTestInventoryItem(5, "test5"), new GFTestInventoryItem(6, "test6") };
        entity.inventory.body = new GFTestInventoryItem[] { new GFTestInventoryItem(1, "test1"), new GFTestInventoryItem(2, "test2"), new GFTestInventoryItem(3, "test3"), new GFTestInventoryItem(4, "test4"), new GFTestInventoryItem(5, "test5"), new GFTestInventoryItem(6, "test6") };
        entity.inventory.inventory = new GFTestInventoryItem[] { new GFTestInventoryItem(1, "test1"), new GFTestInventoryItem(2, "test2"), new GFTestInventoryItem(3, "test3"), new GFTestInventoryItem(4, "test4"), new GFTestInventoryItem(5, "test5"), new GFTestInventoryItem(6, "test6") };
        entity.inventory.temp = new GFTestInventoryItem[] { new GFTestInventoryItem(1, "test1"), new GFTestInventoryItem(2, "test2"), new GFTestInventoryItem(3, "test3"), new GFTestInventoryItem(4, "test4"), new GFTestInventoryItem(5, "test5"), new GFTestInventoryItem(6, "test6") };
        byte[] bytes = DataUtilities.SerializeObjectToNetwork(0, entity, null);
        byte[] buffer2 = DataUtilities.SerializeObjectToNetwork(0, entity, null);
        byte[] buffer3 = DataUtilities.SerializeObjectToNetwork(2, entity, null);
        byte[] buffer4 = DataUtilities.SerializeObjectToNetwork(2, entity, null);
        object obj2 = DataUtilities.DeserializeObjectFromNetwork(bytes, typeof(GFTestBaseEntity), 0, null);
        object obj3 = DataUtilities.DeserializeObjectFromNetwork(buffer2, typeof(GFTestBaseEntity), 0, null);
        GFTestBaseEntity entity2 = obj2 as GFTestBaseEntity;
        GFTestBaseEntity baseObj = obj3 as GFTestBaseEntity;
        object obj4 = DataUtilities.DeserializeObjectFromNetwork(buffer3, typeof(GFTestBaseEntity), 2, null);
        object obj5 = DataUtilities.DeserializeObjectFromNetwork(buffer4, typeof(GFTestBaseEntity), 2, baseObj);
        GFTestBaseEntity entity4 = obj2 as GFTestBaseEntity;
        GFTestBaseEntity entity5 = obj3 as GFTestBaseEntity;
        GFTestBaseEntity entity6 = obj4 as GFTestBaseEntity;
        GFTestBaseEntity entity7 = obj5 as GFTestBaseEntity;
        UUnitAssert.True(entity4 != null, "Fail");
        UUnitAssert.True(entity5 != null, "Fail");
        UUnitAssert.True(entity6 != null, "Fail");
        UUnitAssert.True(entity7 != null, "Fail");
        UUnitAssert.True(entity6.id != entity.id, "Fail");
        UUnitAssert.True(entity6.inventory != null, "Fail");
        UUnitAssert.True(entity6.inventory.equipped == null, "Fail");
        UUnitAssert.True(entity6.inventory.body == null, "Fail");
        UUnitAssert.True(entity6.inventory.inventory != null, "Fail");
        UUnitAssert.True(entity6.inventory.temp == null, "Fail");
        UUnitAssert.SequenceEqual<GFTestInventoryItem>(entity6.inventory.inventory, entity.inventory.inventory, "Expected equivalent lists:\n{0}\n!=\n{1}");
        UUnitAssert.True(entity7.id == entity.id, "Fail");
        UUnitAssert.True(entity7.inventory != null, "Fail");
        UUnitAssert.True(entity7.inventory.equipped == null, "Fail");
        UUnitAssert.True(entity7.inventory.body != null, "Fail");
        UUnitAssert.True(entity7.inventory.inventory != null, "Fail");
        UUnitAssert.True(entity7.inventory.temp != null, "Fail");
        UUnitAssert.SequenceEqual<GFTestInventoryItem>(entity7.inventory.body, entity.inventory.body, "Expected equivalent lists:\n{0}\n!=\n{1}");
        UUnitAssert.SequenceEqual<GFTestInventoryItem>(entity7.inventory.inventory, entity.inventory.inventory, "Expected equivalent lists:\n{0}\n!=\n{1}");
        UUnitAssert.SequenceEqual<GFTestInventoryItem>(entity7.inventory.temp, entity.inventory.temp, "Expected equivalent lists:\n{0}\n!=\n{1}");
        for (int i = 2; i < 12; i++)
        {
            GFTestBaseEntity entity8 = new GFTestBaseEntity {
                id = i,
                inventory = entity.inventory
            };
            byte[] buffer5 = DataUtilities.SerializeObjectToNetwork(0, entity8, entity);
            byte[] buffer6 = DataUtilities.SerializeObjectToNetwork(2, entity8, entity);
            object obj6 = DataUtilities.DeserializeObjectFromNetwork(buffer5, typeof(GFTestBaseEntity), 0, baseObj);
            GFTestBaseEntity entity9 = obj6 as GFTestBaseEntity;
            object obj7 = DataUtilities.DeserializeObjectFromNetwork(buffer6, typeof(GFTestBaseEntity), 2, entity9);
            GFTestBaseEntity entity10 = obj6 as GFTestBaseEntity;
            GFTestBaseEntity entity11 = obj7 as GFTestBaseEntity;
            UUnitAssert.True(entity10 != null, "Fail");
            UUnitAssert.True(entity11 != null, "Fail");
            UUnitAssert.True(entity11.id != entity.id, "Fail");
            UUnitAssert.True(entity11.id == entity8.id, "Fail");
            UUnitAssert.True(entity11.inventory != null, "Fail");
            UUnitAssert.True(entity11.inventory.equipped == null, "Fail");
            UUnitAssert.True(entity11.inventory.body != null, "Fail");
            UUnitAssert.True(entity11.inventory.inventory != null, "Fail");
            UUnitAssert.True(entity11.inventory.temp != null, "Fail");
            UUnitAssert.SequenceEqual<GFTestInventoryItem>(entity11.inventory.body, entity.inventory.body, "Expected equivalent lists:\n{0}\n!=\n{1}");
            UUnitAssert.SequenceEqual<GFTestInventoryItem>(entity11.inventory.inventory, entity.inventory.inventory, "Expected equivalent lists:\n{0}\n!=\n{1}");
            UUnitAssert.SequenceEqual<GFTestInventoryItem>(entity11.inventory.temp, entity.inventory.temp, "Expected equivalent lists:\n{0}\n!=\n{1}");
        }
    }

    [UUnitTestMethod]
    public void EmptyDelta()
    {
        GFTestDelta delta = new GFTestDelta {
            id = 5,
            name = "Player 1"
        };
        GFTestDelta delta2 = new GFTestDelta {
            id = 5,
            name = "Player 1"
        };
        byte[] buffer = DataUtilities.SerializeObjectToNetwork(0, delta, null);
        byte[] bytes = DataUtilities.SerializeObjectToNetwork(0, delta2, delta);
        object obj2 = DataUtilities.DeserializeObjectFromNetwork(bytes, typeof(GFTestDelta), 0, delta);
        UUnitAssert.Equals(bytes.Length, 0, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.True(buffer.Length > bytes.Length, "The base object's serialization should be longer than an empty delta.");
        GFTestDelta something = (GFTestDelta) obj2;
        UUnitAssert.NotNull(something, "Null object not expected.");
        UUnitAssert.Equals(something.id, delta2.id, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(something.name, delta2.name, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.True(object.ReferenceEquals(delta, something), "Fail");
    }

    [UUnitTestMethod]
    public void EmptyString()
    {
        string str = string.Empty;
        GFStringTest test = new GFStringTest {
            str = str
        };
        byte[] bytes = DataUtilities.SerializeObjectToDisk(test);
        object obj2 = DataUtilities.DeserializeObjectFromDisk(bytes, typeof(GFStringTest));
        byte[] second = DataUtilities.SerializeObjectToDisk(obj2);
        UUnitAssert.True(bytes.SequenceEqual<byte>(second), "Fail");
        GFStringTest test2 = (GFStringTest) obj2;
        UUnitAssert.Equals(test2.str, test.str, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(test2.str, string.Empty, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
    }

    [UUnitTestMethod]
    public void ExcludedRestrictionLod()
    {
        GFTestExcludedRestrictionLods lods = new GFTestExcludedRestrictionLods {
            nondecorated = "nondecorated",
            id = 5,
            name = "tester",
            speed = 3.4f
        };
        byte targetLevel = 0;
        GFTestExcludedRestrictionLods lods2 = (GFTestExcludedRestrictionLods) DataUtilities.DeserializeObjectFromNetwork(DataUtilities.SerializeObjectToNetwork(targetLevel, lods, null), typeof(GFTestExcludedRestrictionLods), targetLevel, null);
        UUnitAssert.False(lods2.nondecorated == lods.nondecorated, "Fail");
        UUnitAssert.False(lods2.id == lods.id, "Fail");
        UUnitAssert.False(lods2.name == lods.name, "Fail");
        UUnitAssert.False(lods2.speed == lods.speed, "Fail");
    }

    [UUnitTestMethod]
    public void FullDeltas()
    {
        for (int i = 1; i < 0x18; i++)
        {
            this.TestFullDelta(i);
        }
    }

    [UUnitTestMethod]
    public void GetDefaultLevelCache()
    {
        System.Type type = typeof(DstTestClass1);
        System.Type type2 = typeof(DstTestClass2);
        UUnitAssert.Equals(1, (int) DataSerializerUtils.GetDefaultLevel(type), "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(2, (int) DataSerializerUtils.GetDefaultLevel(type2), "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(1, (int) DataSerializerUtils.GetDefaultLevel(type.GetField("testIntA"), type), "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(2, (int) DataSerializerUtils.GetDefaultLevel(type2.GetField("testIntA"), type2), "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(11, (int) DataSerializerUtils.GetDefaultLevel(type.GetField("testIntB"), type), "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(12, (int) DataSerializerUtils.GetDefaultLevel(type2.GetField("testIntB"), type2), "Expected equivalent inputs: \"{0}\" != \"{1}\"");
    }

    [UUnitTestMethod]
    public void InventoryArray()
    {
        BitBuffer quickBuffer = GUtil.GetQuickBuffer();
        InventoryItem[] setItems = new InventoryItem[] { new InventoryItem(12, 12, 12, 1), new InventoryItem(12, 12, 12, 1), new InventoryItem(12, 12, 12, 1), new InventoryItem(12, 12, 12, 1), new InventoryItem(12, 12, 12, 1), new InventoryItem(12, 12, 12, 1), new InventoryItem(12, 12, 12, 1), new InventoryItem(12, 12, 12, 1) };
        DstItemArrayTest test = new DstItemArrayTest(setItems);
        DstItemArrayTest baseObj = new DstItemArrayTest(new InventoryItem[4]);
        DataSerializerNetwork network = new DataSerializerNetwork();
        network.Serialize(quickBuffer, 0, test, null);
        baseObj = network.Deserialize(quickBuffer, typeof(DstItemArrayTest), 0, baseObj) as DstItemArrayTest;
        UUnitAssert.SequenceEqual<InventoryItem>(test.items, baseObj.items, "Expected equivalent lists:\n{0}\n!=\n{1}");
    }

    [UUnitTestMethod]
    public void JaggedArray()
    {
        int[][] numArray = new int[][] { new int[] { 1, 2, 3 }, new int[] { 4, 5 }, new int[] { 6, 7, 8, 9 } };
        GFJaggedArrayTest test = new GFJaggedArrayTest {
            array = numArray
        };
        byte[] bytes = DataUtilities.SerializeObjectToDisk(test);
        object obj2 = DataUtilities.DeserializeObjectFromDisk(bytes, typeof(GFJaggedArrayTest));
        byte[] second = DataUtilities.SerializeObjectToDisk(obj2);
        UUnitAssert.True(bytes.SequenceEqual<byte>(second), "Fail");
        GFJaggedArrayTest test2 = (GFJaggedArrayTest) obj2;
        UUnitAssert.Equals(test.array.Length, test2.array.Length, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        for (int i = 0; i < test.array.Length; i++)
        {
            UUnitAssert.Equals(test.array[i].Length, test2.array[i].Length, "The inner array lengths are not equal at index: [" + i + "]");
            for (int j = 0; j < test.array[i].Length; j++)
            {
                UUnitAssert.Equals(test.array[i][j], test2.array[i][j], string.Concat(new object[] { "The elements are not equal at indices: [", i, "][", j, "]" }));
            }
        }
    }

    [UUnitTestMethod]
    public void MultidimensionalArray()
    {
        int[,,] numArray = new int[,,] { { { 1 }, { 2 }, { 3 } }, { { 4 }, { 5 }, { 6 } }, { { 7 }, { 8 }, { 9 } } };
        GFMultidimensionalArrayTest test = new GFMultidimensionalArrayTest {
            array = numArray
        };
        byte[] bytes = DataUtilities.SerializeObjectToDisk(test);
        object obj2 = DataUtilities.DeserializeObjectFromDisk(bytes, typeof(GFMultidimensionalArrayTest));
        byte[] second = DataUtilities.SerializeObjectToDisk(obj2);
        UUnitAssert.True(bytes.SequenceEqual<byte>(second), "Fail");
        GFMultidimensionalArrayTest test2 = (GFMultidimensionalArrayTest) obj2;
        UUnitAssert.Equals(test.array.GetLength(0), test2.array.GetLength(0), "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(test.array.GetLength(1), test2.array.GetLength(1), "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(test.array.GetLength(2), test2.array.GetLength(2), "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        for (int i = 0; i < test.array.GetLength(0); i++)
        {
            for (int j = 0; j < test.array.GetLength(1); j++)
            {
                for (int k = 0; k < test.array.GetLength(2); k++)
                {
                    UUnitAssert.Equals(test.array[i, j, k], test2.array[i, j, k], string.Concat(new object[] { "The elements are not equal at indices: [", i, ", ", j, ", ", k, "]" }));
                }
            }
        }
    }

    [UUnitTestMethod]
    public void NestedDefault()
    {
        GFTestNestedDefault default2 = new GFTestNestedDefault {
            id = 8,
            child = new GFTestNestedDefaultChild()
        };
        default2.child.id = 5;
        byte targetLevel = 0;
        GFTestNestedDefault default3 = (GFTestNestedDefault) DataUtilities.DeserializeObjectFromNetwork(DataUtilities.SerializeObjectToNetwork(targetLevel, default2, null), typeof(GFTestNestedDefault), targetLevel, null);
        UUnitAssert.True(default3.id == default2.id, "Fail");
        UUnitAssert.Null(default3.child, "Expected null object.");
        targetLevel = 1;
        GFTestNestedDefault default4 = (GFTestNestedDefault) DataUtilities.DeserializeObjectFromNetwork(DataUtilities.SerializeObjectToNetwork(targetLevel, default2, null), typeof(GFTestNestedDefault), targetLevel, null);
        UUnitAssert.False(default4.id == default2.id, "Fail");
        UUnitAssert.NotNull(default4.child, "Null object not expected.");
        UUnitAssert.True(default4.child.id == default2.child.id, "Fail");
    }

    [UUnitTestMethod]
    public void NestedDelta()
    {
        GFTestNestedDelta delta = new GFTestNestedDelta {
            percent = 3.5f,
            child = new GFTestDelta()
        };
        delta.child.id = 5;
        delta.child.name = "Player 1";
        GFTestNestedDelta delta2 = new GFTestNestedDelta {
            percent = 3.5f,
            child = new GFTestDelta()
        };
        delta2.child.id = 1;
        delta2.child.name = "Player 1";
        byte[] buffer = DataUtilities.SerializeObjectToNetwork(0, delta, null);
        GFTestNestedDelta something = (GFTestNestedDelta) DataUtilities.DeserializeObjectFromNetwork(DataUtilities.SerializeObjectToNetwork(0, delta2, delta), typeof(GFTestNestedDelta), 0, delta);
        UUnitAssert.NotNull(something, "Null object not expected.");
        UUnitAssert.Equals(something.percent, delta2.percent, 0.0001f, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.NotNull(something.child, "Null object not expected.");
        UUnitAssert.Equals(something.child.id, delta2.child.id, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(something.child.name, delta2.child.name, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.True(object.ReferenceEquals(delta, something), "Fail");
    }

    [UUnitTestMethod]
    public void NestedRestrictionLod()
    {
        GFTestNestedRestrictionLods lods = new GFTestNestedRestrictionLods {
            nondecorated = "nondecorated",
            child = new GFTestNestedRestrictionLodsChild()
        };
        lods.child.id = 5;
        byte targetLevel = 0;
        GFTestNestedRestrictionLods lods2 = (GFTestNestedRestrictionLods) DataUtilities.DeserializeObjectFromNetwork(DataUtilities.SerializeObjectToNetwork(targetLevel, lods, null), typeof(GFTestNestedRestrictionLods), targetLevel, null);
        UUnitAssert.True(lods2.nondecorated == lods.nondecorated, "Fail");
        UUnitAssert.NotNull(lods2.child, "Null object not expected.");
        UUnitAssert.False(lods2.child.id == lods.child.id, "Fail");
        targetLevel = 1;
        GFTestNestedRestrictionLods lods3 = (GFTestNestedRestrictionLods) DataUtilities.DeserializeObjectFromNetwork(DataUtilities.SerializeObjectToNetwork(targetLevel, lods, null), typeof(GFTestNestedRestrictionLods), targetLevel, null);
        UUnitAssert.False(lods3.nondecorated == lods.nondecorated, "Fail");
        UUnitAssert.Null(lods3.child, "Expected null object.");
        targetLevel = 2;
        GFTestNestedRestrictionLods lods4 = (GFTestNestedRestrictionLods) DataUtilities.DeserializeObjectFromNetwork(DataUtilities.SerializeObjectToNetwork(targetLevel, lods, null), typeof(GFTestNestedRestrictionLods), targetLevel, null);
        UUnitAssert.False(lods4.nondecorated == lods.nondecorated, "Fail");
        UUnitAssert.NotNull(lods4.child, "Null object not expected.");
        UUnitAssert.True(lods4.child.id == lods.child.id, "Fail");
    }

    [UUnitTestMethod]
    public void NestedRestrictionLodAtNonstandardLevel()
    {
        GFTestNestedRestrictionLods2 lods = new GFTestNestedRestrictionLods2 {
            id = 10,
            child = new GFTestNestedRestrictionLodsChild()
        };
        lods.child.id = 5;
        lods.restrictedChild = new GFTestRestrictedClass();
        lods.restrictedChild.id = 7;
        byte targetLevel = 0;
        GFTestNestedRestrictionLods2 lods2 = (GFTestNestedRestrictionLods2) DataUtilities.DeserializeObjectFromNetwork(DataUtilities.SerializeObjectToNetwork(targetLevel, lods, null), typeof(GFTestNestedRestrictionLods2), targetLevel, null);
        UUnitAssert.True(lods2.id == lods.id, "Fail");
        UUnitAssert.Null(lods2.child, "Expected null object.");
        UUnitAssert.NotNull(lods2.restrictedChild, "Null object not expected.");
        UUnitAssert.False(lods2.restrictedChild.id == lods.restrictedChild.id, "Fail");
        targetLevel = 1;
        GFTestNestedRestrictionLods2 lods3 = (GFTestNestedRestrictionLods2) DataUtilities.DeserializeObjectFromNetwork(DataUtilities.SerializeObjectToNetwork(targetLevel, lods, null), typeof(GFTestNestedRestrictionLods2), targetLevel, null);
        UUnitAssert.False(lods3.id == lods.id, "Fail");
        UUnitAssert.NotNull(lods3.child, "Null object not expected.");
        UUnitAssert.False(lods3.child.id == lods.child.id, "Fail");
        UUnitAssert.Null(lods3.restrictedChild, "Expected null object.");
        targetLevel = 2;
        GFTestNestedRestrictionLods2 lods4 = (GFTestNestedRestrictionLods2) DataUtilities.DeserializeObjectFromNetwork(DataUtilities.SerializeObjectToNetwork(targetLevel, lods, null), typeof(GFTestNestedRestrictionLods2), targetLevel, null);
        UUnitAssert.False(lods4.id == lods.id, "Fail");
        UUnitAssert.NotNull(lods4.child, "Null object not expected.");
        UUnitAssert.True(lods4.child.id == lods.child.id, "Fail");
        UUnitAssert.Null(lods4.restrictedChild, "Expected null object.");
    }

    [UUnitTestMethod]
    public void NoDefinedRestrictionLods()
    {
        TestDataSerializerSimpleClass class2 = new TestDataSerializerSimpleClass {
            type = TestDataSerializerSimpleClass.TestSerializeEnum.ONE,
            testInt = 5,
            testUShort = 10,
            testByte = 3
        };
        byte targetLevel = 0;
        TestDataSerializerSimpleClass class3 = (TestDataSerializerSimpleClass) DataUtilities.DeserializeObjectFromNetwork(DataUtilities.SerializeObjectToNetwork(targetLevel, class2, null), typeof(TestDataSerializerSimpleClass), targetLevel, null);
        UUnitAssert.True(class3.type == class2.type, "Fail");
        UUnitAssert.True(class3.testInt == class2.testInt, "Fail");
        UUnitAssert.True(class3.testUShort == class2.testUShort, "Fail");
        UUnitAssert.True(class3.testByte == class2.testByte, "Fail");
        targetLevel = 1;
        TestDataSerializerSimpleClass class4 = (TestDataSerializerSimpleClass) DataUtilities.DeserializeObjectFromNetwork(DataUtilities.SerializeObjectToNetwork(targetLevel, class2, null), typeof(TestDataSerializerSimpleClass), targetLevel, null);
        UUnitAssert.False(class4.type == class2.type, "Fail");
        UUnitAssert.False(class4.testInt == class2.testInt, "Fail");
        UUnitAssert.False(class4.testUShort == class2.testUShort, "Fail");
        UUnitAssert.False(class4.testByte == class2.testByte, "Fail");
    }

    [UUnitTestMethod]
    public void NullBaseArrayDelta()
    {
        GFTestDelta[] objA = null;
        GFTestDelta[] deltaArray3 = new GFTestDelta[3];
        GFTestDelta delta4 = new GFTestDelta {
            id = 1,
            name = "Player 1"
        };
        deltaArray3[0] = delta4;
        GFTestDelta delta5 = new GFTestDelta {
            id = 3,
            name = "Player 3"
        };
        deltaArray3[1] = delta5;
        GFTestDelta[] deltaArray2 = deltaArray3;
        GFTestObjectArrayDelta baseObj = new GFTestObjectArrayDelta {
            array = objA
        };
        GFTestObjectArrayDelta delta2 = new GFTestObjectArrayDelta {
            array = deltaArray2
        };
        GFTestObjectArrayDelta something = (GFTestObjectArrayDelta) DataUtilities.DeserializeObjectFromNetwork(DataUtilities.SerializeObjectToNetwork(0, delta2, baseObj), typeof(GFTestObjectArrayDelta), 0, baseObj);
        UUnitAssert.NotNull(something, "Null object not expected.");
        UUnitAssert.NotNull(something.array, "Null object not expected.");
        UUnitAssert.False(object.ReferenceEquals(objA, baseObj.array), "Fail");
        UUnitAssert.False(object.ReferenceEquals(objA, something.array), "Fail");
        UUnitAssert.True(object.ReferenceEquals(baseObj, something), "Fail");
    }

    [UUnitTestMethod]
    public void NullString()
    {
        string str = null;
        GFStringTest test = new GFStringTest {
            str = str
        };
        byte[] bytes = DataUtilities.SerializeObjectToDisk(test);
        object obj2 = DataUtilities.DeserializeObjectFromDisk(bytes, typeof(GFStringTest));
        byte[] second = DataUtilities.SerializeObjectToDisk(obj2);
        UUnitAssert.True(bytes.SequenceEqual<byte>(second), "Fail");
        GFStringTest test2 = (GFStringTest) obj2;
        UUnitAssert.Equals(test2.str, test.str, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(test2.str, (string) null, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
    }

    [UUnitTestMethod]
    public void ObjectArrayDelta()
    {
        GFTestDelta[] deltaArray3 = new GFTestDelta[5];
        GFTestDelta delta4 = new GFTestDelta {
            id = 1,
            name = "Player 1"
        };
        deltaArray3[0] = delta4;
        GFTestDelta delta5 = new GFTestDelta {
            id = 2,
            name = "Player 2"
        };
        deltaArray3[1] = delta5;
        GFTestDelta delta6 = new GFTestDelta {
            id = 3,
            name = "Player 3"
        };
        deltaArray3[2] = delta6;
        GFTestDelta delta7 = new GFTestDelta {
            id = 4,
            name = "Player 4"
        };
        deltaArray3[3] = delta7;
        GFTestDelta delta8 = new GFTestDelta {
            id = 5,
            name = "Player 5"
        };
        deltaArray3[4] = delta8;
        GFTestDelta[] objA = deltaArray3;
        deltaArray3 = new GFTestDelta[5];
        GFTestDelta delta9 = new GFTestDelta {
            id = 1,
            name = "Player 1"
        };
        deltaArray3[0] = delta9;
        GFTestDelta delta10 = new GFTestDelta {
            id = 3,
            name = "Player 3"
        };
        deltaArray3[1] = delta10;
        GFTestDelta delta11 = new GFTestDelta {
            id = 2,
            name = "Player 2"
        };
        deltaArray3[2] = delta11;
        GFTestDelta delta12 = new GFTestDelta {
            id = 4,
            name = "Player 4"
        };
        deltaArray3[3] = delta12;
        GFTestDelta delta13 = new GFTestDelta {
            id = 5,
            name = "Player 5"
        };
        deltaArray3[4] = delta13;
        GFTestDelta[] deltaArray2 = deltaArray3;
        GFTestObjectArrayDelta delta = new GFTestObjectArrayDelta {
            array = objA
        };
        GFTestObjectArrayDelta delta2 = new GFTestObjectArrayDelta {
            array = deltaArray2
        };
        byte[] buffer = DataUtilities.SerializeObjectToNetwork(0, delta, null);
        GFTestObjectArrayDelta something = (GFTestObjectArrayDelta) DataUtilities.DeserializeObjectFromNetwork(DataUtilities.SerializeObjectToNetwork(0, delta2, delta), typeof(GFTestObjectArrayDelta), 0, delta);
        UUnitAssert.NotNull(something, "Null object not expected.");
        for (int i = 0; i < delta2.array.Length; i++)
        {
            UUnitAssert.Equals(something.array[i].id, delta2.array[i].id, "id values at index [" + i + "] are not equivalent");
            UUnitAssert.Equals(something.array[i].name, delta2.array[i].name, "name values at index [" + i + "] are not equivalent");
        }
        UUnitAssert.True(object.ReferenceEquals(objA, delta.array), "Fail");
        UUnitAssert.True(object.ReferenceEquals(objA, something.array), "Fail");
        UUnitAssert.True(object.ReferenceEquals(delta, something), "Fail");
    }

    [UUnitTestMethod]
    public void ObjectArrayResizeDelta()
    {
        GFTestDelta[] deltaArray3 = new GFTestDelta[2];
        GFTestDelta delta4 = new GFTestDelta {
            id = 1,
            name = "Player 1"
        };
        deltaArray3[0] = delta4;
        GFTestDelta delta5 = new GFTestDelta {
            id = 2,
            name = "Player 2"
        };
        deltaArray3[1] = delta5;
        GFTestDelta[] objA = deltaArray3;
        deltaArray3 = new GFTestDelta[3];
        GFTestDelta delta6 = new GFTestDelta {
            id = 1,
            name = "Player 1"
        };
        deltaArray3[0] = delta6;
        GFTestDelta delta7 = new GFTestDelta {
            id = 3,
            name = "Player 3"
        };
        deltaArray3[1] = delta7;
        GFTestDelta[] deltaArray2 = deltaArray3;
        GFTestObjectArrayDelta delta = new GFTestObjectArrayDelta {
            array = objA
        };
        GFTestObjectArrayDelta delta2 = new GFTestObjectArrayDelta {
            array = deltaArray2
        };
        byte[] buffer = DataUtilities.SerializeObjectToNetwork(0, delta, null);
        GFTestObjectArrayDelta something = (GFTestObjectArrayDelta) DataUtilities.DeserializeObjectFromNetwork(DataUtilities.SerializeObjectToNetwork(0, delta2, delta), typeof(GFTestObjectArrayDelta), 0, delta);
        UUnitAssert.NotNull(something, "Null object not expected.");
        for (int i = 0; i < delta2.array.Length; i++)
        {
            if (delta2.array[i] == null)
            {
                UUnitAssert.Equals(something.array[i], delta2.array[i], "object values at index [" + i + "] are not equivalent");
            }
            else
            {
                UUnitAssert.Equals(something.array[i].id, delta2.array[i].id, "id values at index [" + i + "] are not equivalent");
                UUnitAssert.Equals(something.array[i].name, delta2.array[i].name, "name values at index [" + i + "] are not equivalent");
            }
        }
        UUnitAssert.False(object.ReferenceEquals(objA, delta.array), "Fail");
        UUnitAssert.False(object.ReferenceEquals(objA, something.array), "Fail");
        UUnitAssert.True(object.ReferenceEquals(delta, something), "Fail");
    }

    [UUnitTestMethod]
    public void Polymorphism()
    {
        GFPolymorphismTest test = new GFPolymorphismTest {
            obj = new GFTestDerivedClass1()
        };
        ((GFTestDerivedClass1) test.obj).derived1Obj = 10f;
        byte[] bytes = DataUtilities.SerializeObjectToDisk(test);
        object obj2 = DataUtilities.DeserializeObjectFromDisk(bytes, typeof(GFPolymorphismTest));
        byte[] second = DataUtilities.SerializeObjectToDisk(obj2);
        UUnitAssert.True(bytes.SequenceEqual<byte>(second), "Fail");
        GFPolymorphismTest test2 = (GFPolymorphismTest) obj2;
        UUnitAssert.NotNull(test2.obj, "Null object not expected.");
        UUnitAssert.True(test2.obj.GetType() == typeof(GFTestDerivedClass1), "Fail");
        UUnitAssert.False(test2.obj.GetType() == typeof(GFTestDerivedClass2), "Fail");
    }

    [UUnitTestMethod]
    public void Primitive()
    {
        int num = 1;
        byte[] bytes = DataUtilities.SerializeObjectToDisk(num);
        object obj2 = DataUtilities.DeserializeObjectFromDisk(bytes, typeof(int));
        byte[] second = DataUtilities.SerializeObjectToDisk(obj2);
        UUnitAssert.True(bytes.SequenceEqual<byte>(second), "Fail");
        UUnitAssert.Equals(bytes.Length, 0, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(second.Length, 0, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Null(obj2, "Expected null object.");
    }

    [UUnitTestMethod]
    public void PrivateMember()
    {
        GFTestPrivateMember member = new GFTestPrivateMember {
            Id = 5
        };
        byte[] bytes = DataUtilities.SerializeObjectToDisk(member);
        object obj2 = DataUtilities.DeserializeObjectFromDisk(bytes, typeof(GFTestPrivateMember));
        byte[] second = DataUtilities.SerializeObjectToDisk(obj2);
        UUnitAssert.True(bytes.SequenceEqual<byte>(second), "Fail");
        GFTestPrivateMember member2 = (GFTestPrivateMember) obj2;
        UUnitAssert.True(member2.Id == member.Id, "Fail");
    }

    [UUnitTestMethod]
    public void ReceiverProcessDelta()
    {
        GFTestDelta delta = new GFTestDelta {
            id = 5,
            name = "Player 1"
        };
        GFTestDelta delta2 = new GFTestDelta {
            id = 5,
            name = "Player 2"
        };
        byte[] buffer = DataUtilities.SerializeObjectToNetwork(0, delta, null);
        GFTestDelta something = (GFTestDelta) DataUtilities.DeserializeObjectFromNetwork(DataUtilities.SerializeObjectToNetwork(0, delta2, null), typeof(GFTestDelta), 0, delta);
        UUnitAssert.NotNull(something, "Null object not expected.");
        UUnitAssert.Equals(something.id, delta2.id, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(something.name, delta2.name, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.True(object.ReferenceEquals(delta, something), "Fail");
    }

    [UUnitTestMethod]
    public void RestrictionLods()
    {
        GFTestRestrictionLods lods = new GFTestRestrictionLods {
            nondecorated = "nondecorated",
            id = 5,
            name = "tester",
            speed = 3.4f
        };
        byte targetLevel = 0;
        GFTestRestrictionLods lods2 = (GFTestRestrictionLods) DataUtilities.DeserializeObjectFromNetwork(DataUtilities.SerializeObjectToNetwork(targetLevel, lods, null), typeof(GFTestRestrictionLods), targetLevel, null);
        UUnitAssert.True(lods2.nondecorated == lods.nondecorated, "Fail");
        UUnitAssert.False(lods2.id == lods.id, "Fail");
        UUnitAssert.False(lods2.name == lods.name, "Fail");
        UUnitAssert.False(lods2.speed == lods.speed, "Fail");
        targetLevel = 1;
        GFTestRestrictionLods lods3 = (GFTestRestrictionLods) DataUtilities.DeserializeObjectFromNetwork(DataUtilities.SerializeObjectToNetwork(targetLevel, lods, null), typeof(GFTestRestrictionLods), targetLevel, null);
        UUnitAssert.False(lods3.nondecorated == lods.nondecorated, "Fail");
        UUnitAssert.True(lods3.id == lods.id, "Fail");
        UUnitAssert.False(lods3.name == lods.name, "Fail");
        UUnitAssert.False(lods3.speed == lods.speed, "Fail");
        targetLevel = 2;
        GFTestRestrictionLods lods4 = (GFTestRestrictionLods) DataUtilities.DeserializeObjectFromNetwork(DataUtilities.SerializeObjectToNetwork(targetLevel, lods, null), typeof(GFTestRestrictionLods), targetLevel, null);
        UUnitAssert.False(lods4.nondecorated == lods.nondecorated, "Fail");
        UUnitAssert.False(lods4.id == lods.id, "Fail");
        UUnitAssert.True(lods4.name == lods.name, "Fail");
        UUnitAssert.False(lods4.speed == lods.speed, "Fail");
        targetLevel = 3;
        GFTestRestrictionLods lods5 = (GFTestRestrictionLods) DataUtilities.DeserializeObjectFromNetwork(DataUtilities.SerializeObjectToNetwork(targetLevel, lods, null), typeof(GFTestRestrictionLods), targetLevel, null);
        UUnitAssert.False(lods5.nondecorated == lods.nondecorated, "Fail");
        UUnitAssert.False(lods5.id == lods.id, "Fail");
        UUnitAssert.False(lods5.name == lods.name, "Fail");
        UUnitAssert.True(lods5.speed == lods.speed, "Fail");
    }

    [UUnitTestMethod]
    public void SequenceEqualsLength()
    {
        int[] first = new int[] { 12, 12, 12, 12, 12, 12, 12, 12, 12, 12 };
        int[] second = new int[] { 12, 12, 12, 12, 12, 12, 12 };
        UUnitAssert.False(first.SequenceEqual<int>(second), "Fail");
        UUnitAssert.False(second.SequenceEqual<int>(first), "Fail");
    }

    [UUnitTestMethod]
    public void StaticMember()
    {
        GFTestStaticMember member = new GFTestStaticMember();
        byte[] bytes = DataUtilities.SerializeObjectToDisk(member);
        byte[] second = DataUtilities.SerializeObjectToDisk(DataUtilities.DeserializeObjectFromDisk(bytes, typeof(GFTestStaticMember)));
        UUnitAssert.True(bytes.SequenceEqual<byte>(second), "Fail");
        UUnitAssert.True(bytes.Length < GFTestStaticMember.staticStr.Length, "Fail");
    }

    [UUnitTestMethod]
    public void StringArray()
    {
        BitBuffer quickBuffer = GUtil.GetQuickBuffer();
        string[] setItems = new string[5];
        setItems[0] = "This";
        setItems[1] = "is";
        setItems[2] = "";
        setItems[4] = "only a test";
        DstStringArrayTest test = new DstStringArrayTest(setItems);
        DstStringArrayTest baseObj = new DstStringArrayTest(new string[4]);
        DataSerializerNetwork network = new DataSerializerNetwork();
        network.Serialize(quickBuffer, 0, test, null);
        baseObj = network.Deserialize(quickBuffer, typeof(DstStringArrayTest), 0, baseObj) as DstStringArrayTest;
        UUnitAssert.SequenceEqual<string>(test.items, baseObj.items, "Expected equivalent lists:\n{0}\n!=\n{1}");
    }

    [UUnitTestMethod]
    public void TableOfContents()
    {
        string inType = typeof(TestDataClass).ToString();
        uint[] inOffsets = new uint[1];
        SourceFileData[] iSourceFiles = new SourceFileData[] { new SourceFileData("file1", "hash1", "sheet1") };
        DataTableOfContents contents = new DataTableOfContents(inType, inOffsets, iSourceFiles);
        byte[] bytes = DataUtilities.SerializeObjectToDisk(contents);
        object obj2 = DataUtilities.DeserializeObjectFromDisk(bytes, typeof(DataTableOfContents));
        byte[] second = DataUtilities.SerializeObjectToDisk(obj2);
        UUnitAssert.True(bytes.SequenceEqual<byte>(second), "The serialized and reserialized byte arrays are not equivalent");
        DataTableOfContents contents2 = (DataTableOfContents) obj2;
        UUnitAssert.Equals(contents2.type, inType, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(contents2.offsets.Length, inOffsets.Length, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals((ulong) contents2.offsets[0], (ulong) inOffsets[0], "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(contents2.sourceFiles.Length, iSourceFiles.Length, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(contents2.sourceFiles[0], iSourceFiles[0], "Expected equivalent inputs: \"{0}\" != \"{1}\"");
    }

    [UUnitTestMethod]
    public void Test3DFloatArray()
    {
        int num;
        int num2;
        int num3;
        GFTest3DFloatClass class2 = new GFTest3DFloatClass {
            data = new float[5, 5, 5]
        };
        for (num = 0; num < 5; num++)
        {
            num2 = 0;
            while (num2 < 5)
            {
                num3 = 0;
                while (num3 < 5)
                {
                    class2.data[num3, num2, num] = num3;
                    num3++;
                }
                num2++;
            }
        }
        object obj2 = DataUtilities.DeserializeObjectFromDisk(DataUtilities.SerializeObjectToDisk(class2), typeof(GFTest3DFloatClass));
        object obj3 = DataUtilities.DeserializeObjectFromDisk(DataUtilities.SerializeObjectToDisk(obj2), typeof(GFTest3DFloatClass));
        GFTest3DFloatClass class3 = (GFTest3DFloatClass) obj2;
        GFTest3DFloatClass class4 = (GFTest3DFloatClass) obj3;
        for (num = 0; num < 5; num++)
        {
            for (num2 = 0; num2 < 5; num2++)
            {
                for (num3 = 0; num3 < 5; num3++)
                {
                    UUnitAssert.Equals(class2.data[num3, num2, num], class3.data[num3, num2, num], 0.0001f, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
                    UUnitAssert.Equals(class2.data[num3, num2, num], class4.data[num3, num2, num], 0.0001f, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
                }
            }
        }
    }

    public void TestFullDelta(int input)
    {
        int num;
        int[] objA = new int[input];
        int[] numArray2 = new int[input];
        for (num = 0; num < input; num++)
        {
            objA[num] = 0;
            numArray2[num] = 1;
        }
        GFTestArrayDelta delta = new GFTestArrayDelta {
            array = objA
        };
        GFTestArrayDelta delta2 = new GFTestArrayDelta {
            array = numArray2
        };
        byte[] buffer = DataUtilities.SerializeObjectToNetwork(0, delta, null);
        GFTestArrayDelta something = (GFTestArrayDelta) DataUtilities.DeserializeObjectFromNetwork(DataUtilities.SerializeObjectToNetwork(0, delta2, delta), typeof(GFTestArrayDelta), 0, delta);
        UUnitAssert.NotNull(something, "Null object not expected.");
        for (num = 0; num < delta2.array.Length; num++)
        {
            UUnitAssert.Equals(something.array[num], delta2.array[num], string.Concat(new object[] { "Array values at index [", num, "] are not equivalent: ", something.array[num], ", ", delta2.array[num] }));
        }
        UUnitAssert.True(object.ReferenceEquals(objA, delta.array), "Fail");
        UUnitAssert.True(object.ReferenceEquals(objA, something.array), "Fail");
        UUnitAssert.True(object.ReferenceEquals(delta, something), "Fail");
    }

    [UUnitTestMethod]
    public void TestRealCombatVars()
    {
        CombatTestHelper.SetUp();
        SkillData.ConstructCommonUnittestData(new string[0]);
        CombatTestHelper.MakeCombatData();
        CombatTestHelper.MakeKeywordData();
        CombatTestHelper.MakeWeaponData();
        CombatTestHelper.MakeArmorData();
        CombatTestHelper.MakeNonAttackData();
        CombatTestHelper.MakeOffensiveData();
        CombatTestHelper.MakeClassData();
        CombatTestHelper.SetupCombatCore();
        CombatVars vars = CombatTestHelper.SetupCombatVars("Player1", 1, "Passive Tester");
        byte[] serializedPlayer = DataUtilities.SerializeObjectToNetwork(0, vars, null);
        object obj2 = DataUtilities.DeserializeObjectFromNetwork(serializedPlayer, typeof(CombatVars), 0, null);
        byte[] second = DataUtilities.SerializeObjectToNetwork(0, obj2, null);
        CombatVars baseObj = (CombatVars) obj2;
        CombatVars vars3 = new CombatVars();
        UUnitAssert.True(serializedPlayer.SequenceEqual<byte>(second), "Fail");
        UUnitAssert.True(baseObj.DataEquals(vars, 0), "Fail");
        vars.inCombat = !vars.inCombat;
        serializedPlayer = DataUtilities.SerializeObjectToNetwork(0, vars, baseObj);
        obj2 = DataUtilities.DeserializeObjectFromNetwork(serializedPlayer, typeof(CombatVars), 0, baseObj);
        CombatVars nullBase = null;
        serializedPlayer = DataUtilities.SerializeObjectToNetwork(0, vars, vars3);
        UUnitAssert.Raises(() => DataUtilities.DeserializeObjectFromNetwork(serializedPlayer, typeof(CombatVars), 0, nullBase), typeof(NullReferenceException), new object[0]);
        UUnitAssert.Raises(() => DataUtilities.DeserializeObjectFromNetwork(serializedPlayer, typeof(CombatVars), 0, null), typeof(NullReferenceException), new object[0]);
        CombatClassVars combatClass = vars.combatClass;
        UUnitAssert.NotNull(combatClass, "Null object not expected.");
        vars.combatClass = null;
        serializedPlayer = DataUtilities.SerializeObjectToNetwork(0, vars, null);
        CombatVars vars5 = (CombatVars) DataUtilities.DeserializeObjectFromNetwork(serializedPlayer, typeof(CombatVars), 0, null);
        UUnitAssert.Null(vars5.combatClass, "Expected null object.");
        CombatVars target = new CombatVars();
        vars5.DataCopyTo(ref target, 0);
        vars.combatClass = combatClass;
        vars.inCombat = !vars.inCombat;
        serializedPlayer = DataUtilities.SerializeObjectToNetwork(0, vars, target);
        CombatVars objA = (CombatVars) DataUtilities.DeserializeObjectFromNetwork(serializedPlayer, typeof(CombatVars), 0, target);
        UUnitAssert.False(objA.inCombat == vars5.inCombat, "Fail");
        UUnitAssert.True(object.ReferenceEquals(objA, target), "Fail");
        UUnitAssert.True(objA.inCombat == vars.inCombat, "Fail");
        UUnitAssert.NotNull(objA.combatClass, "Null object not expected.");
        UUnitAssert.True(objA.DataEquals(vars, 0), "Fail");
        CombatTestHelper.ClearAllCombatStaticData();
    }

    [UUnitTestMethod]
    public void ValidateDirectGetAndSet()
    {
        GFTestClass target = new GFTestClass(5, "hello");
        GFTestSubStruct struct2 = new GFTestSubStruct(20, "howwego");
        GFTestSubClass class3 = new GFTestSubClass(15, "whatitdo");
        FieldInfo field = typeof(GFTestClass).GetField("id", BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance);
        FieldInfo fld = typeof(GFTestClass).GetField("text", BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance);
        FieldInfo info3 = typeof(GFTestClass).GetField("str", BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance);
        FieldInfo info4 = typeof(GFTestClass).GetField("cls", BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance);
        DataSerializer.GetValueDirectDelegate<int> cachedGetValueDirectDelegate = DataSerializer.GetCachedGetValueDirectDelegate<int>(field);
        DataSerializer.GetValueDirectDelegate<string> delegate3 = DataSerializer.GetCachedGetValueDirectDelegate<string>(fld);
        DataSerializer.GetValueDirectDelegate<object> delegate4 = DataSerializer.GetCachedGetValueDirectDelegate<object>(info3);
        DataSerializer.GetValueDirectDelegate<object> delegate5 = DataSerializer.GetCachedGetValueDirectDelegate<object>(info4);
        DataSerializer.SetValueDirectDelegate<int> cachedSetValueDirectDelegate = DataSerializer.GetCachedSetValueDirectDelegate<int>(field);
        DataSerializer.SetValueDirectDelegate<string> delegate7 = DataSerializer.GetCachedSetValueDirectDelegate<string>(fld);
        DataSerializer.SetValueDirectDelegate<object> delegate8 = DataSerializer.GetCachedSetValueDirectDelegate<object>(info3);
        DataSerializer.SetValueDirectDelegate<object> delegate9 = DataSerializer.GetCachedSetValueDirectDelegate<object>(info4);
        int wanted = cachedGetValueDirectDelegate(target);
        string str = delegate3(target);
        GFTestSubStruct objA = (GFTestSubStruct) delegate4(target);
        GFTestSubClass class4 = (GFTestSubClass) delegate5(target);
        UUnitAssert.Equals(wanted, target.id, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(str, target.text, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.False(object.ReferenceEquals(objA, target.str), "Fail");
        UUnitAssert.Equals(objA.id, target.str.id, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(objA.text, target.str.text, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(class4.id, target.cls.id, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(class4.text, target.cls.text, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.True(object.ReferenceEquals(class4, target.cls), "Fail");
        int num2 = 100;
        string str2 = "thisismynewvalue";
        GFTestSubStruct struct4 = new GFTestSubStruct(150, "livingontheedge");
        GFTestSubClass class5 = new GFTestSubClass(200, "butnowheretogo");
        object obj2 = target;
        cachedSetValueDirectDelegate(ref obj2, num2);
        delegate7(ref obj2, str2);
        delegate8(ref obj2, struct4);
        delegate9(ref obj2, class5);
        int got = cachedGetValueDirectDelegate(target);
        string str3 = delegate3(target);
        GFTestSubStruct objB = (GFTestSubStruct) delegate4(target);
        GFTestSubClass class6 = (GFTestSubClass) delegate5(target);
        UUnitAssert.Equals(num2, got, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(str2, str3, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(struct4.id, objB.id, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(struct4.text, objB.text, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.False(object.ReferenceEquals(struct4, objB), "Fail");
        UUnitAssert.Equals(class5.id, class6.id, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(class5.text, class6.text, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.True(object.ReferenceEquals(class5, class6), "Fail");
    }

    [UUnitTestMethod]
    public void ValidateDirectGetAndSetForStructParent()
    {
        GFTestSubStruct target = new GFTestSubStruct(20, "howwego");
        FieldInfo field = typeof(GFTestSubStruct).GetField("id", BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance);
        FieldInfo fld = typeof(GFTestSubStruct).GetField("text", BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance);
        DataSerializer.GetValueDirectDelegate<int> cachedGetValueDirectDelegate = DataSerializer.GetCachedGetValueDirectDelegate<int>(field);
        DataSerializer.GetValueDirectDelegate<string> delegate3 = DataSerializer.GetCachedGetValueDirectDelegate<string>(fld);
        DataSerializer.SetValueDirectDelegate<int> cachedSetValueDirectDelegate = DataSerializer.GetCachedSetValueDirectDelegate<int>(field);
        DataSerializer.SetValueDirectDelegate<string> delegate5 = DataSerializer.GetCachedSetValueDirectDelegate<string>(fld);
        int wanted = cachedGetValueDirectDelegate(target);
        string str = delegate3(target);
        UUnitAssert.Equals(wanted, target.id, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(str, target.text, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        int num2 = 100;
        string str2 = "thisismynewvalue";
        object obj2 = target;
        cachedSetValueDirectDelegate(ref obj2, num2);
        delegate5(ref obj2, str2);
        int got = cachedGetValueDirectDelegate(obj2);
        string str3 = delegate3(obj2);
        UUnitAssert.Equals(num2, got, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(str2, str3, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
    }

    [UUnitTestMethod]
    public void ValidString()
    {
        string got = "test string";
        GFStringTest test = new GFStringTest {
            str = got
        };
        byte[] bytes = DataUtilities.SerializeObjectToDisk(test);
        object obj2 = DataUtilities.DeserializeObjectFromDisk(bytes, typeof(GFStringTest));
        byte[] second = DataUtilities.SerializeObjectToDisk(obj2);
        UUnitAssert.True(bytes.SequenceEqual<byte>(second), "Fail");
        GFStringTest test2 = (GFStringTest) obj2;
        UUnitAssert.Equals(test2.str, test.str, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.Equals(test2.str, got, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
    }
}

