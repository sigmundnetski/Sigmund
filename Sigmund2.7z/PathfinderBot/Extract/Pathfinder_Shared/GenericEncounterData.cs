﻿using System;
using System.IO;

[NoFinalOutput]
public class GenericEncounterData : DataClass
{
    public static int encounterColIndex;
    public string encounterName;
    public string fileName;
    public int phase;
    public static int phaseColIndex;
    public float weight;
    public static int weightColIndex;

    protected static T ParseEncounter<T>(int rowIndex, ref T output) where T: GenericEncounterData
    {
        string str;
        ((T) output).fileName = Path.GetFileNameWithoutExtension(DataClass.filename);
        if (!DataClass.TryGetCellValue(1, rowIndex, out str))
        {
            return default(T);
        }
        ((T) output).phase = 0;
        if (phaseColIndex != 0)
        {
            DataClass.GetCellValue(phaseColIndex, rowIndex, out ((T) output).phase);
            T local1 = (T) output;
            local1.phase--;
        }
        DataClass.GetLCaseCellValue(encounterColIndex, rowIndex, out ((T) output).encounterName);
        DataClass.GetCellValue(weightColIndex, rowIndex, out ((T) output).weight);
        ((T) output).name = ((T) output).fileName + ((T) output).phase + ((T) output).encounterName;
        return output;
    }

    public override DataClass ParseRecord(int rowIndex)
    {
        phaseColIndex = 0;
        encounterColIndex = 1;
        weightColIndex = 2;
        GenericEncounterData output = new GenericEncounterData();
        return ParseEncounter<GenericEncounterData>(rowIndex, ref output);
    }
}

