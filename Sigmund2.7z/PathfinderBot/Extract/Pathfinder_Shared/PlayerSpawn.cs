﻿using System;
using UnityEngine;

public class PlayerSpawn : MonoBehaviour
{
    [NonSerialized, HideInInspector]
    public PlayerSpawnPoint runtimeDetails;
    public PlayerSpawnPoint.PlayerSpawnType spawnType;

    public void RegisterSpawnPoint()
    {
        if (this.runtimeDetails != null)
        {
            throw new Exception("NpcSpawnPoints should only be registered once, and always from their correct/final position:" + base.gameObject.name);
        }
        this.runtimeDetails = new PlayerSpawnPoint(base.transform.position, this.spawnType);
        if (!PlayerSpawnPoint.RegisterPlayerSpawnPoint(this.runtimeDetails))
        {
            this.runtimeDetails = null;
        }
    }

    private void Start()
    {
        if (PlayerSpawnPoint.RegisterPlayerSpawnPoint != null)
        {
            this.RegisterSpawnPoint();
        }
    }
}

