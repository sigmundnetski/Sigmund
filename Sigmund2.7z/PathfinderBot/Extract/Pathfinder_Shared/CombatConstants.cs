﻿using System;
using System.Collections.Generic;

public static class CombatConstants
{
    public static Dictionary<string, AoE> aoeNames;
    public static Dictionary<string, AttackMod> attackModNames;
    public static Dictionary<string, AttackType> attackNames;
    public static Dictionary<string, AttackState> attackStateNames;
    public static Dictionary<string, Buff> buffNames;
    public static Dictionary<string, string> classNames;
    public static Dictionary<string, DefenseType> defenseNames;
    public static Dictionary<string, DefenseType> defenseTargetNames;
    public static Dictionary<string, Distance> distanceNames;
    public static Dictionary<string, Instant> instantNames;
    public static Dictionary<string, RecoveryType> recoveryNames;
    public static Dictionary<string, ResistanceType> resistanceNames;
    public static Dictionary<string, ResistanceType> resistanceTargetNames;
    public static Dictionary<string, Stack> stackNames;
    public static Dictionary<string, State> stateNames;
    public static Dictionary<string, Target> targetNames;

    static CombatConstants()
    {
        Dictionary<string, string> dictionary = new Dictionary<string, string>();
        dictionary.Add("bleeding", "BleedingDebuff");
        dictionary.Add("burning", "BurningDebuff");
        dictionary.Add("drained", "DrainedDebuff");
        dictionary.Add("razed", "RazedDebuff");
        dictionary.Add("frightened", "FrightenedDebuff");
        dictionary.Add("oblivious", "ObliviousDebuff");
        dictionary.Add("slowed", "SlowedDebuff");
        dictionary.Add("open", "OpenDebuff");
        dictionary.Add("unguarded", "UnguardedDebuff");
        dictionary.Add("opportunity", "TimedStateBuff");
        dictionary.Add("distressed", "TimedStateBuff");
        dictionary.Add("shaken", "TimedStateBuff");
        dictionary.Add("dazed", "TimedStateBuff");
        dictionary.Add("unbalanced", "TimedStateBuff");
        dictionary.Add("flat-footed", "TimedStateBuff");
        dictionary.Add("stealthed", "StealthedState");
        dictionary.Add("defending", "DefendingBuff");
        dictionary.Add("replying", "ReplyingBuff");
        dictionary.Add("avoiding", "AvoidingDodgingBuff");
        dictionary.Add("dodging", "AvoidingDodgingBuff");
        dictionary.Add("parrying", "ParryingBuff");
        dictionary.Add("riposting", "RipostingBuff");
        dictionary.Add("revealed", "RevealedDebuff");
        dictionary.Add("shrug off", "ShrugOffBuff");
        dictionary.Add("mind blank", "StackedStateBuff");
        dictionary.Add("interrupt", "InterruptDebuff");
        dictionary.Add("fatigue", "FatigueDebuff");
        dictionary.Add("tiring", "FatigueDebuff");
        dictionary.Add("in combat", "InCombatState");
        dictionary.Add("removes open", "BuffExpirerBuff");
        dictionary.Add("freedom", "StackedStateBuff");
        dictionary.Add("slow", "SlowDebuff");
        dictionary.Add("knockdown", "KnockdownDebuff");
        dictionary.Add("gather", "GatherChannel");
        dictionary.Add("loothusk", "LootHuskChannel");
        dictionary.Add("aiming", "AimingStrikingBuff");
        dictionary.Add("striking", "AimingStrikingBuff");
        dictionary.Add("alert", "AlertAwareBuff");
        dictionary.Add("aware", "AlertAwareBuff");
        dictionary.Add("afflicted", "AfflictedDebuff");
        dictionary.Add("exhausted", "ExhaustedDebuff");
        dictionary.Add("disrupted", "DisruptedState");
        dictionary.Add("knockback", "ForcedMoveBuff");
        dictionary.Add("evade", "ForcedMoveBuff");
        dictionary.Add("physical attuned", "AttunedResistantBuff");
        dictionary.Add("fire attuned", "AttunedResistantBuff");
        dictionary.Add("cold attuned", "AttunedResistantBuff");
        dictionary.Add("electric attuned", "AttunedResistantBuff");
        dictionary.Add("sonic attuned", "AttunedResistantBuff");
        dictionary.Add("acid attuned", "AttunedResistantBuff");
        dictionary.Add("negative attuned", "AttunedResistantBuff");
        dictionary.Add("holy attuned", "AttunedResistantBuff");
        dictionary.Add("force attuned", "AttunedResistantBuff");
        dictionary.Add("psychic attuned", "AttunedResistantBuff");
        dictionary.Add("critical attuned", "AttunedResistantBuff");
        dictionary.Add("physical resistant", "AttunedResistantBuff");
        dictionary.Add("fire resistant", "AttunedResistantBuff");
        dictionary.Add("cold resistant", "AttunedResistantBuff");
        dictionary.Add("electric resistant", "AttunedResistantBuff");
        dictionary.Add("sonic resistant", "AttunedResistantBuff");
        dictionary.Add("acid resistant", "AttunedResistantBuff");
        dictionary.Add("negative resistant", "AttunedResistantBuff");
        dictionary.Add("holy resistant", "AttunedResistantBuff");
        dictionary.Add("force resistant", "AttunedResistantBuff");
        dictionary.Add("psychic resistant", "AttunedResistantBuff");
        dictionary.Add("critical resistant", "AttunedResistantBuff");
        dictionary.Add("quickened", "QuickenedHastedBuff");
        dictionary.Add("hasted", "QuickenedHastedBuff");
        dictionary.Add("strengthened", "StrengthenedMightyBuff");
        dictionary.Add("mighty", "StrengthenedMightyBuff");
        dictionary.Add("favored", "FavoredEmpoweredBuff");
        dictionary.Add("empowered", "FavoredEmpoweredBuff");
        dictionary.Add("fast healing", "FastHealingRegeneratingBuff");
        dictionary.Add("regenerating", "FastHealingRegeneratingBuff");
        dictionary.Add("enduring", "EnduringTenaciousBuff");
        dictionary.Add("tenacious", "EnduringTenaciousBuff");
        dictionary.Add("immobilize", "ImmobilizeDebuff");
        dictionary.Add("stun", "StunDebuff");
        dictionary.Add("charge", "ChargeUtilityFeat");
        classNames = dictionary;
        Dictionary<string, Buff> dictionary2 = new Dictionary<string, Buff>();
        dictionary2.Add("open", Buff.OPEN);
        dictionary2.Add("unguarded", Buff.UNGUARDED);
        dictionary2.Add("defending", Buff.DEFENDING);
        dictionary2.Add("replying", Buff.REPLYING);
        dictionary2.Add("avoiding", Buff.AVOIDING);
        dictionary2.Add("dodging", Buff.DODGING);
        dictionary2.Add("parrying", Buff.PARRYING);
        dictionary2.Add("riposting", Buff.RIPOSTING);
        dictionary2.Add("revealed", Buff.REVEALED);
        dictionary2.Add("slow", Buff.SLOW);
        dictionary2.Add("knockdown", Buff.KNOCKDOWN);
        dictionary2.Add("gather", Buff.GATHER);
        dictionary2.Add("loothusk", Buff.LOOTHUSK);
        dictionary2.Add("aiming", Buff.AIMING);
        dictionary2.Add("striking", Buff.STRIKING);
        dictionary2.Add("alert", Buff.ALERT);
        dictionary2.Add("aware", Buff.AWARE);
        dictionary2.Add("physical attuned", Buff.ATTUNED_PHYSICAL);
        dictionary2.Add("fire attuned", Buff.ATTUNED_FIRE);
        dictionary2.Add("cold attuned", Buff.ATTUNED_COLD);
        dictionary2.Add("electric attuned", Buff.ATTUNED_ELECTRIC);
        dictionary2.Add("sonic attuned", Buff.ATTUNED_SONIC);
        dictionary2.Add("acid attuned", Buff.ATTUNED_ACID);
        dictionary2.Add("negative attuned", Buff.ATTUNED_NEGATIVE);
        dictionary2.Add("holy attuned", Buff.ATTUNED_HOLY);
        dictionary2.Add("force attuned", Buff.ATTUNED_FORCE);
        dictionary2.Add("psychic attuned", Buff.ATTUNED_PSYCHIC);
        dictionary2.Add("critical attuned", Buff.ATTUNED_CRITICAL);
        dictionary2.Add("physical resistant", Buff.RESISTANT_PHYSICAL);
        dictionary2.Add("fire resistant", Buff.RESISTANT_FIRE);
        dictionary2.Add("cold resistant", Buff.RESISTANT_COLD);
        dictionary2.Add("electric resistant", Buff.RESISTANT_ELECTRIC);
        dictionary2.Add("sonic resistant", Buff.RESISTANT_SONIC);
        dictionary2.Add("acid resistant", Buff.RESISTANT_ACID);
        dictionary2.Add("negative resistant", Buff.RESISTANT_NEGATIVE);
        dictionary2.Add("holy resistant", Buff.RESISTANT_HOLY);
        dictionary2.Add("force resistant", Buff.RESISTANT_FORCE);
        dictionary2.Add("psychic resistant", Buff.RESISTANT_PSYCHIC);
        dictionary2.Add("critical resistant", Buff.RESISTANT_CRITICAL);
        dictionary2.Add("quickened", Buff.QUICKENED);
        dictionary2.Add("hasted", Buff.HASTED);
        dictionary2.Add("strengthened", Buff.STRENGTHENED);
        dictionary2.Add("mighty", Buff.MIGHTY);
        dictionary2.Add("favored", Buff.FAVORED);
        dictionary2.Add("empowered", Buff.EMPOWERED);
        dictionary2.Add("fast healing", Buff.FAST_HEALING);
        dictionary2.Add("regenerating", Buff.REGENERATING);
        dictionary2.Add("enduring", Buff.ENDURING);
        dictionary2.Add("tenacious", Buff.TENACIOUS);
        dictionary2.Add("immobilize", Buff.IMMOBILIZE);
        dictionary2.Add("stun", Buff.STUN);
        dictionary2.Add("dazzled", Buff.DAZZLED);
        buffNames = dictionary2;
        Dictionary<string, Target> dictionary3 = new Dictionary<string, Target>();
        dictionary3.Add("target", Target.TARGET);
        dictionary3.Add("self", Target.SELF);
        dictionary3.Add("attacker", Target.SELF);
        dictionary3.Add("all targets", Target.ALL);
        dictionary3.Add("all", Target.ALL);
        targetNames = dictionary3;
        Dictionary<string, State> dictionary4 = new Dictionary<string, State>();
        dictionary4.Add("opportunity", State.OPPORTUNITY);
        dictionary4.Add("distressed", State.DISTRESSED);
        dictionary4.Add("shaken", State.SHAKEN);
        dictionary4.Add("in combat", State.IN_COMBAT);
        dictionary4.Add("dazed", State.DAZED);
        dictionary4.Add("unbalanced", State.UNBALANCED);
        dictionary4.Add("stealthed", State.STEALTHED);
        dictionary4.Add("flat-footed", State.FLAT_FOOTED);
        dictionary4.Add("untargeted", State.UNTARGETED);
        dictionary4.Add("disrupted", State.DISRUPTED);
        stateNames = dictionary4;
        Dictionary<string, Stack> dictionary5 = new Dictionary<string, Stack>();
        dictionary5.Add("bleeding", Stack.BLEEDING);
        dictionary5.Add("frightened", Stack.FRIGHTENED);
        dictionary5.Add("oblivious", Stack.OBLIVIOUS);
        dictionary5.Add("slowed", Stack.SLOWED);
        dictionary5.Add("mind blank", Stack.MIND_BLANK);
        dictionary5.Add("fatigue", Stack.FATIGUE);
        dictionary5.Add("tiring", Stack.FATIGUE);
        dictionary5.Add("freedom", Stack.FREEDOM);
        dictionary5.Add("heal", Stack.HEAL);
        dictionary5.Add("afflicted", Stack.AFFLICTED);
        dictionary5.Add("exhausted", Stack.EXHAUSTED);
        dictionary5.Add("burning", Stack.BURNING);
        dictionary5.Add("drained", Stack.DRAINED);
        dictionary5.Add("razed", Stack.RAZED);
        dictionary5.Add("acid", Stack.ACID);
        stackNames = dictionary5;
        Dictionary<string, AttackMod> dictionary6 = new Dictionary<string, AttackMod>();
        dictionary6.Add("precise", AttackMod.PRECISE);
        dictionary6.Add("penetrating", AttackMod.PENETRATING);
        dictionary6.Add("provokes opportunity", AttackMod.PROVOKES_OPPORTUNITY);
        dictionary6.Add("improved critical", AttackMod.IMPROVED_CRITICAL);
        dictionary6.Add("reduced range", AttackMod.REDUCED_RANGE);
        dictionary6.Add("long range", AttackMod.LONG_RANGE);
        dictionary6.Add("stationary", AttackMod.STATIONARY);
        dictionary6.Add("base damage", AttackMod.BASE_DAMAGE);
        dictionary6.Add("sneak attack", AttackMod.SNEAK_ATTACK);
        dictionary6.Add("dispelling", AttackMod.DISPELLING);
        dictionary6.Add("attack speed afflicted", AttackMod.ATTACK_SPEED_AFFLICTED);
        dictionary6.Add("beneficial", AttackMod.BENEFICIAL);
        dictionary6.Add("causes interrupt", AttackMod.CAUSES_INTERRUPT);
        attackModNames = dictionary6;
        Dictionary<string, AttackState> dictionary7 = new Dictionary<string, AttackState>();
        dictionary7.Add("critical hit", AttackState.CRITICAL_HIT);
        dictionary7.Add("non critical hit", AttackState.NON_CRITICAL_HIT);
        attackStateNames = dictionary7;
        Dictionary<string, Instant> dictionary8 = new Dictionary<string, Instant>();
        dictionary8.Add("shrug off", Instant.SHRUG_OFF);
        dictionary8.Add("interrupt", Instant.INTERRUPT);
        dictionary8.Add("removes open", Instant.REMOVES_OPEN);
        instantNames = dictionary8;
        Dictionary<string, Distance> dictionary9 = new Dictionary<string, Distance>();
        dictionary9.Add("charge", Distance.CHARGE);
        dictionary9.Add("knockback", Distance.KNOCKBACK);
        dictionary9.Add("evade", Distance.EVADE);
        distanceNames = dictionary9;
        Dictionary<string, AoE> dictionary10 = new Dictionary<string, AoE>();
        dictionary10.Add("splash", AoE.SPLASH);
        dictionary10.Add("burst", AoE.BURST);
        dictionary10.Add("area", AoE.AREA);
        dictionary10.Add("streak", AoE.STREAK);
        dictionary10.Add("short blast melee", AoE.SHORT_BLAST_MELEE);
        dictionary10.Add("short blast", AoE.SHORT_BLAST);
        dictionary10.Add("long blast melee", AoE.LONG_BLAST_MELEE);
        dictionary10.Add("long blast", AoE.LONG_BLAST);
        aoeNames = dictionary10;
        Dictionary<string, RecoveryType> dictionary11 = new Dictionary<string, RecoveryType>();
        dictionary11.Add("bleeding recovery bonus", RecoveryType.Bleeding);
        dictionary11.Add("frightened recovery bonus", RecoveryType.Frightened);
        dictionary11.Add("oblivious recovery bonus", RecoveryType.Oblivious);
        dictionary11.Add("slowed recovery bonus", RecoveryType.Slowed);
        dictionary11.Add("deafened recovery bonus", RecoveryType.Deafened);
        dictionary11.Add("drained recovery bonus", RecoveryType.Drained);
        dictionary11.Add("razed recovery bonus", RecoveryType.Razed);
        dictionary11.Add("afflicted recovery bonus", RecoveryType.Afflicted);
        dictionary11.Add("frozen recovery bonus", RecoveryType.Frozen);
        dictionary11.Add("shocked recovery bonus", RecoveryType.Shocked);
        dictionary11.Add("burning recovery bonus", RecoveryType.Burning);
        dictionary11.Add("corroded recovery bonus", RecoveryType.Corroded);
        dictionary11.Add("fatigued recovery bonus", RecoveryType.Fatigued);
        dictionary11.Add("freedom recovery bonus", RecoveryType.Freedom);
        dictionary11.Add("mind blank recovery bonus", RecoveryType.MindBlank);
        dictionary11.Add("exhausted recovery bonus", RecoveryType.Exhausted);
        recoveryNames = dictionary11;
        Dictionary<string, DefenseType> dictionary12 = new Dictionary<string, DefenseType>();
        dictionary12.Add("base defense bonus", DefenseType.Base);
        dictionary12.Add("reflex defense bonus", DefenseType.Reflex);
        dictionary12.Add("fortitude defense bonus", DefenseType.Fortitude);
        dictionary12.Add("will defense bonus", DefenseType.Will);
        defenseNames = dictionary12;
        Dictionary<string, AttackType> dictionary13 = new Dictionary<string, AttackType>();
        dictionary13.Add("base attack bonus", AttackType.Base);
        dictionary13.Add("heavy melee attack bonus", AttackType.HeavyMelee);
        dictionary13.Add("light melee attack bonus", AttackType.LightMelee);
        dictionary13.Add("ranged attack bonus", AttackType.Ranged);
        dictionary13.Add("divine attack bonus", AttackType.Divine);
        dictionary13.Add("arcane attack bonus", AttackType.Arcane);
        attackNames = dictionary13;
        Dictionary<string, DefenseType> dictionary14 = new Dictionary<string, DefenseType>();
        dictionary14.Add("targets reflex", DefenseType.Reflex);
        dictionary14.Add("targets fortitude", DefenseType.Fortitude);
        dictionary14.Add("targets will", DefenseType.Will);
        defenseTargetNames = dictionary14;
        Dictionary<string, ResistanceType> dictionary15 = new Dictionary<string, ResistanceType>();
        dictionary15.Add("physical damage", ResistanceType.Physical);
        dictionary15.Add("fire damage", ResistanceType.Fire);
        dictionary15.Add("cold damage", ResistanceType.Cold);
        dictionary15.Add("electric damage", ResistanceType.Electric);
        dictionary15.Add("sonic damage", ResistanceType.Sonic);
        dictionary15.Add("acid damage", ResistanceType.Acid);
        dictionary15.Add("negative damage", ResistanceType.Negative);
        dictionary15.Add("holy damage", ResistanceType.Holy);
        dictionary15.Add("force damage", ResistanceType.Force);
        dictionary15.Add("psychic damage", ResistanceType.Psychic);
        resistanceTargetNames = dictionary15;
        Dictionary<string, ResistanceType> dictionary16 = new Dictionary<string, ResistanceType>();
        dictionary16.Add("physical resistance", ResistanceType.Physical);
        dictionary16.Add("fire resistance", ResistanceType.Fire);
        dictionary16.Add("cold resistance", ResistanceType.Cold);
        dictionary16.Add("electric resistance", ResistanceType.Electric);
        dictionary16.Add("sonic resistance", ResistanceType.Sonic);
        dictionary16.Add("acid resistance", ResistanceType.Acid);
        dictionary16.Add("negative resistance", ResistanceType.Negative);
        dictionary16.Add("holy resistance", ResistanceType.Holy);
        dictionary16.Add("force resistance", ResistanceType.Force);
        dictionary16.Add("psychic resistance", ResistanceType.Psychic);
        dictionary16.Add("all resistance", ResistanceType.PhysicalAndAllEnergies);
        dictionary16.Add("energy resistance", ResistanceType.AllEnergies);
        dictionary16.Add("all resistances", ResistanceType.PhysicalAndAllEnergies);
        dictionary16.Add("energy resistances", ResistanceType.AllEnergies);
        resistanceNames = dictionary16;
    }

    public enum AoE : byte
    {
        AREA = 2,
        BURST = 1,
        LONG_BLAST = 7,
        LONG_BLAST_MELEE = 6,
        SHORT_BLAST = 5,
        SHORT_BLAST_MELEE = 4,
        SPLASH = 0,
        STREAK = 3
    }

    public enum AttackMod : byte
    {
        ATTACK_SPEED_AFFLICTED = 10,
        BASE_DAMAGE = 7,
        BENEFICIAL = 11,
        CAUSES_INTERRUPT = 12,
        DISPELLING = 9,
        IMPROVED_CRITICAL = 3,
        LONG_RANGE = 5,
        PENETRATING = 0,
        PRECISE = 1,
        PROVOKES_OPPORTUNITY = 2,
        REDUCED_RANGE = 4,
        SNEAK_ATTACK = 8,
        STATIONARY = 6
    }

    public enum AttackState : byte
    {
        CRITICAL_HIT = 1,
        NON_CRITICAL_HIT = 2,
        NONE = 0
    }

    public enum Buff : byte
    {
        AIMING = 11,
        ALERT = 13,
        ATTUNED_ACID = 0x16,
        ATTUNED_COLD = 0x13,
        ATTUNED_CRITICAL = 0x1b,
        ATTUNED_ELECTRIC = 20,
        ATTUNED_FIRE = 0x12,
        ATTUNED_FORCE = 0x19,
        ATTUNED_HOLY = 0x18,
        ATTUNED_NEGATIVE = 0x17,
        ATTUNED_PHYSICAL = 0x11,
        ATTUNED_PSYCHIC = 0x1a,
        ATTUNED_SONIC = 0x15,
        AVOIDING = 4,
        AWARE = 14,
        DAZZLED = 0x33,
        DEFENDING = 2,
        DODGING = 5,
        EMPOWERED = 0x2c,
        ENDURING = 0x2f,
        FAST_HEALING = 0x2d,
        FAVORED = 0x2b,
        GATHER = 15,
        HASTED = 40,
        IMMOBILIZE = 0x31,
        KNOCKDOWN = 10,
        LOOTHUSK = 0x10,
        MIGHTY = 0x2a,
        OPEN = 0,
        PARRYING = 6,
        QUICKENED = 0x27,
        REGENERATING = 0x2e,
        REPLYING = 3,
        RESISTANT_ACID = 0x21,
        RESISTANT_COLD = 30,
        RESISTANT_CRITICAL = 0x26,
        RESISTANT_ELECTRIC = 0x1f,
        RESISTANT_FIRE = 0x1d,
        RESISTANT_FORCE = 0x24,
        RESISTANT_HOLY = 0x23,
        RESISTANT_NEGATIVE = 0x22,
        RESISTANT_PHYSICAL = 0x1c,
        RESISTANT_PSYCHIC = 0x25,
        RESISTANT_SONIC = 0x20,
        REVEALED = 8,
        RIPOSTING = 7,
        SLOW = 9,
        STRENGTHENED = 0x29,
        STRIKING = 12,
        STUN = 50,
        TENACIOUS = 0x30,
        UNGUARDED = 1
    }

    public enum Distance : byte
    {
        CHARGE = 0,
        EVADE = 2,
        KNOCKBACK = 1
    }

    public enum Instant : byte
    {
        INTERRUPT = 1,
        REMOVES_OPEN = 2,
        SHRUG_OFF = 0
    }

    public enum Stack : byte
    {
        ACID = 13,
        AFFLICTED = 8,
        BLEEDING = 0,
        BURNING = 10,
        DRAINED = 11,
        EXHAUSTED = 9,
        FATIGUE = 2,
        FREEDOM = 3,
        FRIGHTENED = 5,
        HEAL = 4,
        MIND_BLANK = 1,
        OBLIVIOUS = 6,
        RAZED = 12,
        SLOWED = 7
    }

    public enum State : byte
    {
        DAZED = 4,
        DISRUPTED = 9,
        DISTRESSED = 1,
        FLAT_FOOTED = 7,
        IN_COMBAT = 3,
        OPPORTUNITY = 0,
        SHAKEN = 2,
        STEALTHED = 6,
        UNBALANCED = 5,
        UNTARGETED = 8
    }

    public enum Target : byte
    {
        ALL = 2,
        SELF = 1,
        TARGET = 0
    }
}

