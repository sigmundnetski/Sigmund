﻿using System;

public class RunTimeMaterialInfo
{
    public bool constructed = false;
    public MaterialInfo constructionData;

    public RunTimeMaterialInfo(MaterialInfo info)
    {
        this.constructionData = info;
    }
}

