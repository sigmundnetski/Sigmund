﻿using System;
using System.Collections.Generic;

public class CombatModifier : IDataCopyable<CombatModifier>
{
    public CombatConstants.AoE areaOfEffect;
    public AttackType attack;
    public CombatConstants.AttackMod attackMod;
    public uint attackModAmount;
    public CombatConstants.Buff buff;
    public uint chance;
    public string className;
    public CombatModifierCondition[] conditions;
    public DefenseType defense;
    public CombatConstants.Distance distanceEffect;
    public float distanceMeters;
    private const float EPSILON = 0.0001f;
    public CombatConstants.Instant instant;
    public float percentage;
    public RecoveryType recovery;
    public ResistanceType resistance;
    public int skillId;
    public CombatConstants.Stack stack;
    public uint stackAmount;
    public int statAmount;
    public CombatConstants.State state;
    public CombatConstants.Target target;
    public uint tickDuration;
    public CombatModifierType type;

    public void DataCopyTo(ref CombatModifier target, byte syncTargetLevel)
    {
        target.attackModAmount = this.attackModAmount;
        target.chance = this.chance;
        target.className = this.className;
        target.distanceMeters = this.distanceMeters;
        target.percentage = this.percentage;
        target.skillId = this.skillId;
        target.stackAmount = this.stackAmount;
        target.statAmount = this.statAmount;
        target.tickDuration = this.tickDuration;
        target.areaOfEffect = this.areaOfEffect;
        target.attack = this.attack;
        target.attackMod = this.attackMod;
        target.buff = this.buff;
        target.defense = this.defense;
        target.distanceEffect = this.distanceEffect;
        target.instant = this.instant;
        target.recovery = this.recovery;
        target.resistance = this.resistance;
        target.stack = this.stack;
        target.state = this.state;
        target.target = this.target;
        target.type = this.type;
        SparseArray.DeepCopyTo<CombatModifierCondition>(this.conditions, ref target.conditions, syncTargetLevel, null);
    }

    public bool DataEquals(CombatModifier other, byte syncTargetLevel)
    {
        if (object.ReferenceEquals(this, this.target))
        {
            return true;
        }
        if (object.ReferenceEquals(this.target, null))
        {
            return false;
        }
        return (((((((other.attackModAmount == this.attackModAmount) && (other.chance == this.chance)) && ((other.className == this.className) && (other.distanceMeters == this.distanceMeters))) && (((other.percentage == this.percentage) && (other.skillId == this.skillId)) && ((other.stackAmount == this.stackAmount) && (other.statAmount == this.statAmount)))) && ((((other.tickDuration == this.tickDuration) && (other.areaOfEffect == this.areaOfEffect)) && ((other.attack == this.attack) && (other.attackMod == this.attackMod))) && (((other.buff == this.buff) && (other.defense == this.defense)) && ((other.distanceEffect == this.distanceEffect) && (other.instant == this.instant))))) && ((((other.recovery == this.recovery) && (other.resistance == this.resistance)) && ((other.stack == this.stack) && (other.state == this.state))) && ((other.target == this.target) && (other.type == this.type)))) && SparseArray.DeepEqualsWithIndex<CombatModifierCondition>(other.conditions, this.conditions, syncTargetLevel));
    }

    public bool IsBuff()
    {
        return !string.IsNullOrEmpty(this.className);
    }

    public bool ModTypeEquals(CombatModifier other)
    {
        return ((((((this.type == other.type) && (this.buff == other.buff)) && ((Math.Abs((float) (this.percentage - other.percentage)) < 0.0001f) && (this.stack == other.stack))) && (((this.state == other.state) && (this.instant == other.instant)) && ((this.attackMod == other.attackMod) && (this.distanceEffect == other.distanceEffect)))) && ((((this.areaOfEffect == other.areaOfEffect) && (this.recovery == other.recovery)) && ((this.defense == other.defense) && (this.attack == other.attack))) && (this.skillId == other.skillId))) && (this.resistance == other.resistance));
    }

    public static CombatModifier[] Parse(string source)
    {
        List<GSStatement> list = GoblinSpec.Parse(source);
        List<CombatModifier> list2 = new List<CombatModifier>();
        foreach (GSStatement statement in list)
        {
            if (CombatConstants.buffNames.ContainsKey(statement.statement))
            {
                list2.Add(ParseBuff(statement));
            }
            else if (CombatConstants.stackNames.ContainsKey(statement.statement))
            {
                list2.Add(ParseStack(statement));
            }
            else if (CombatConstants.attackModNames.ContainsKey(statement.statement))
            {
                list2.Add(ParseAttackModifier(statement));
            }
            else if (CombatConstants.stateNames.ContainsKey(statement.statement))
            {
                list2.Add(ParseState(statement));
            }
            else if (CombatConstants.instantNames.ContainsKey(statement.statement))
            {
                list2.Add(ParseInstantEffect(statement));
            }
            else if (CombatConstants.distanceNames.ContainsKey(statement.statement))
            {
                list2.Add(ParseDistanceEffect(statement));
            }
            else if (CombatConstants.aoeNames.ContainsKey(statement.statement))
            {
                list2.Add(ParseAreaOfEffect(statement));
            }
            else if (CombatConstants.recoveryNames.ContainsKey(statement.statement))
            {
                list2.Add(ParseStat(CombatModifierType.RECOVERY, statement));
            }
            else if (CombatConstants.defenseNames.ContainsKey(statement.statement))
            {
                list2.Add(ParseStat(CombatModifierType.DEFENSE, statement));
            }
            else if (CombatConstants.attackNames.ContainsKey(statement.statement))
            {
                list2.Add(ParseStat(CombatModifierType.ATTACK_BONUS, statement));
            }
            else if (SkillData.skillByName.ContainsKey(statement.statement))
            {
                list2.Add(ParseStat(CombatModifierType.SKILL, statement));
            }
            else if (statement.statement == "hit points")
            {
                list2.Add(ParseStat(CombatModifierType.HITPOINTS, statement));
            }
            else if (statement.statement == "encumbrance")
            {
                list2.Add(ParseStat(CombatModifierType.MAX_ENCUMBRANCE, statement));
            }
            else if (statement.statement == "power")
            {
                list2.Add(ParseStat(CombatModifierType.POWER, statement));
            }
            else if (CombatConstants.defenseTargetNames.ContainsKey(statement.statement))
            {
                list2.Add(ParseDefenseTarget(statement));
            }
            else if (CombatConstants.resistanceTargetNames.ContainsKey(statement.statement))
            {
                list2.Add(ParseResistanceTarget(statement));
            }
            else if (CombatConstants.resistanceNames.ContainsKey(statement.statement))
            {
                list2.Add(ParseStat(CombatModifierType.RESISTANCE, statement));
            }
            else if (statement.statement == "speed")
            {
                list2.Add(ParseStat(CombatModifierType.SPEED, statement));
            }
            else
            {
                if (statement.statement != "regeneration")
                {
                    throw new ParseException("Unknown combat modifier: " + statement.statement);
                }
                list2.Add(ParseStat(CombatModifierType.REGENERATION, statement));
            }
        }
        return list2.ToArray();
    }

    public static CombatModifier ParseAreaOfEffect(GSStatement statement)
    {
        CombatModifier modifier = new CombatModifier {
            type = CombatModifierType.AOE,
            areaOfEffect = CombatConstants.aoeNames[statement.statement],
            chance = ParsePercentChance(statement),
            target = ParseTarget(statement),
            conditions = ParseConditions(statement),
            className = string.Empty
        };
        if (modifier.conditions != null)
        {
            throw new ParseException("Conditionals are unsupported for AoEs: " + statement.statement);
        }
        if (statement.parameters.Count > 0)
        {
            throw new ParseException("Unknown parameter for AoE: " + statement.statement);
        }
        return modifier;
    }

    public static CombatModifier ParseAttackModifier(GSStatement statement)
    {
        CombatModifier modifier = new CombatModifier {
            type = CombatModifierType.ATTACK_MODIFIER,
            attackMod = CombatConstants.attackModNames[statement.statement],
            chance = ParsePercentChance(statement),
            target = ParseTarget(statement),
            attackModAmount = ParseUIntParameter(statement),
            conditions = ParseConditions(statement)
        };
        if (statement.parameters.Count > 0)
        {
            throw new ParseException("Unknown parameter for attack mod: " + statement.statement);
        }
        return modifier;
    }

    public static CombatModifier ParseBuff(GSStatement statement)
    {
        CombatModifier modifier = new CombatModifier {
            type = CombatModifierType.BUFF,
            buff = CombatConstants.buffNames[statement.statement],
            target = ParseTarget(statement),
            percentage = ParsePercentage(statement),
            chance = ParsePercentChance(statement),
            tickDuration = ParseTime(statement),
            conditions = ParseConditions(statement)
        };
        CombatConstants.classNames.TryGetValue(statement.statement, out modifier.className);
        if (modifier.tickDuration == 0)
        {
            throw new ParseException("Combat buff requires a time limit: " + statement.statement);
        }
        if (statement.parameters.Count > 0)
        {
            throw new ParseException("Unknown parameter for buff: " + statement.statement);
        }
        return modifier;
    }

    public static byte ParseByteParameter(GSStatement statement)
    {
        return (byte) ParseIntParameter(statement);
    }

    public static CombatModifierCondition[] ParseConditions(GSStatement statement)
    {
        List<CombatModifierCondition> list = new List<CombatModifierCondition>();
        foreach (GSQualifier qualifier in statement.qualifiers)
        {
            if (((qualifier.type != GSQualifierType.CONDITION) && (qualifier.type != GSQualifierType.EQUIVALENCE)) && (qualifier.type != GSQualifierType.NONEQUIVALENCE))
            {
                throw new ParseException("Extra combat qualifier: " + statement.statement);
            }
            CombatModifierCondition item = new CombatModifierCondition {
                shouldHave = (qualifier.type == GSQualifierType.NONEQUIVALENCE) ? false : true
            };
            if (CombatConstants.stateNames.ContainsKey(qualifier.condition))
            {
                item.type = CombatModifierType.STATE;
                item.state = CombatConstants.stateNames[qualifier.condition];
            }
            else if (CombatConstants.buffNames.ContainsKey(qualifier.condition))
            {
                item.type = CombatModifierType.BUFF;
                item.buff = CombatConstants.buffNames[qualifier.condition];
            }
            else if (CombatConstants.stackNames.ContainsKey(qualifier.condition))
            {
                item.type = CombatModifierType.STACK;
                item.stack = CombatConstants.stackNames[qualifier.condition];
            }
            else if (WeaponProficiencyData.profsByName.ContainsKey(qualifier.condition))
            {
                item.type = CombatModifierType.WEAPON;
                item.weaponProficiencyId = WeaponProficiencyData.profsByName[qualifier.condition].id;
            }
            else if (CombatConstants.attackStateNames.ContainsKey(qualifier.condition))
            {
                item.type = CombatModifierType.ATTACK_STATE;
                item.attackState = CombatConstants.attackStateNames[qualifier.condition];
            }
            else
            {
                if (qualifier.condition != "keyword")
                {
                    throw new ParseException("Unknown combat condtion: " + qualifier.condition);
                }
                item.type = CombatModifierType.KEYWORD;
            }
            if ((qualifier.type == GSQualifierType.EQUIVALENCE) || (qualifier.type == GSQualifierType.NONEQUIVALENCE))
            {
                if (!CombatConstants.targetNames.ContainsKey(qualifier.target))
                {
                    throw new ParseException("Unknown combat target: " + qualifier.target);
                }
                item.target = CombatConstants.targetNames[qualifier.target];
            }
            list.Add(item);
        }
        if (list.Count > 0)
        {
            return list.ToArray();
        }
        return null;
    }

    public static CombatModifier ParseDefenseTarget(GSStatement statement)
    {
        CombatModifier modifier = new CombatModifier {
            type = CombatModifierType.DEFENSE_TARGET,
            defense = CombatConstants.defenseTargetNames[statement.statement]
        };
        if (statement.qualifiers.Count > 0)
        {
            throw new ParseException("Defense targets do not support qualifiers: " + statement.statement);
        }
        if (statement.parameters.Count > 0)
        {
            throw new ParseException("Defense targets do not support parameters: " + statement.statement);
        }
        return modifier;
    }

    public static CombatModifier ParseDistanceEffect(GSStatement statement)
    {
        CombatModifier modifier = new CombatModifier {
            type = CombatModifierType.DISTANCE,
            distanceEffect = CombatConstants.distanceNames[statement.statement],
            chance = ParsePercentChance(statement),
            target = ParseTarget(statement),
            distanceMeters = ParseMeters(statement),
            conditions = ParseConditions(statement)
        };
        CombatConstants.classNames.TryGetValue(statement.statement, out modifier.className);
        if (modifier.distanceMeters == 0f)
        {
            throw new ParseException("Combat buff requires a distance: " + statement.statement);
        }
        if (statement.parameters.Count > 0)
        {
            throw new ParseException("Unknown parameter for buff: " + statement.statement);
        }
        return modifier;
    }

    public static CombatModifier ParseInstantEffect(GSStatement statement)
    {
        CombatModifier modifier = new CombatModifier {
            type = CombatModifierType.INSTANT,
            instant = CombatConstants.instantNames[statement.statement],
            chance = ParsePercentChance(statement),
            target = ParseTarget(statement),
            conditions = ParseConditions(statement)
        };
        CombatConstants.classNames.TryGetValue(statement.statement, out modifier.className);
        if (statement.parameters.Count > 0)
        {
            throw new ParseException("Unknown parameter for instant effect: " + statement.statement);
        }
        return modifier;
    }

    public static int ParseIntParameter(GSStatement statement)
    {
        foreach (GSParam param in statement.parameters)
        {
            if (param.unit == GSParamUnit.NONE)
            {
                int num = param.value;
                statement.parameters.Remove(param);
                return num;
            }
        }
        return 0;
    }

    public static float ParseMeters(GSStatement statement)
    {
        foreach (GSParam param in statement.parameters)
        {
            if (param.unit == GSParamUnit.METER)
            {
                float num = param.value;
                statement.parameters.Remove(param);
                return num;
            }
        }
        return 0f;
    }

    public static float ParsePercentage(GSStatement statement)
    {
        foreach (GSParam param in statement.parameters)
        {
            if (param.unit == GSParamUnit.PERCENTAGE)
            {
                float num = ((float) param.value) / 100f;
                statement.parameters.Remove(param);
                return num;
            }
        }
        return 0f;
    }

    public static uint ParsePercentChance(GSStatement statement)
    {
        foreach (GSParam param in statement.parameters)
        {
            if (param.unit == GSParamUnit.PERCENTAGE_CHANCE)
            {
                uint num = (uint) param.value;
                statement.parameters.Remove(param);
                return num;
            }
        }
        return 100;
    }

    public static CombatModifier ParseResistanceTarget(GSStatement statement)
    {
        CombatModifier modifier = new CombatModifier {
            type = CombatModifierType.RESISTANCE_TARGET,
            resistance = CombatConstants.resistanceTargetNames[statement.statement]
        };
        if (statement.qualifiers.Count > 0)
        {
            throw new ParseException("Damage types do not support qualifiers: " + statement.statement);
        }
        if (statement.parameters.Count > 0)
        {
            throw new ParseException("Damage types do not support parameters: " + statement.statement);
        }
        return modifier;
    }

    public static CombatModifier ParseStack(GSStatement statement)
    {
        CombatModifier modifier = new CombatModifier {
            type = CombatModifierType.STACK,
            stack = CombatConstants.stackNames[statement.statement],
            target = ParseTarget(statement),
            chance = ParsePercentChance(statement),
            stackAmount = ParseUIntParameter(statement),
            conditions = ParseConditions(statement)
        };
        CombatConstants.classNames.TryGetValue(statement.statement, out modifier.className);
        if (modifier.stackAmount == 0)
        {
            throw new ParseException("Combat stack requires a stack number: " + statement.statement);
        }
        if (statement.parameters.Count > 0)
        {
            throw new ParseException("Unknown parameter for stack: " + statement.statement);
        }
        return modifier;
    }

    public static CombatModifier ParseStat(CombatModifierType modType, GSStatement statement)
    {
        CombatModifier modifier = new CombatModifier {
            type = modType
        };
        if (modifier.type == CombatModifierType.RECOVERY)
        {
            modifier.recovery = CombatConstants.recoveryNames[statement.statement];
        }
        else if (modifier.type == CombatModifierType.DEFENSE)
        {
            modifier.defense = CombatConstants.defenseNames[statement.statement];
        }
        else if (modifier.type == CombatModifierType.ATTACK_BONUS)
        {
            modifier.attack = CombatConstants.attackNames[statement.statement];
        }
        else if (modifier.type == CombatModifierType.SKILL)
        {
            modifier.skillId = SkillData.skillByName[statement.statement].id;
        }
        if (modifier.type == CombatModifierType.RESISTANCE)
        {
            modifier.resistance = CombatConstants.resistanceNames[statement.statement];
        }
        modifier.target = ParseTarget(statement);
        modifier.chance = ParsePercentChance(statement);
        modifier.statAmount = ParseIntParameter(statement);
        modifier.conditions = ParseConditions(statement);
        modifier.percentage = ParsePercentage(statement);
        if ((modifier.statAmount == 0) && (modifier.percentage == 0f))
        {
            throw new ParseException(string.Concat(new object[] { "Combat ", modType, " requires a non-zero number: ", statement.statement }));
        }
        if (statement.parameters.Count > 0)
        {
            throw new ParseException(string.Concat(new object[] { "Unknown parameter for ", modType, ": ", statement.statement }));
        }
        return modifier;
    }

    public static CombatModifier ParseState(GSStatement statement)
    {
        CombatModifier modifier = new CombatModifier {
            type = CombatModifierType.STATE,
            state = CombatConstants.stateNames[statement.statement],
            target = ParseTarget(statement),
            chance = ParsePercentChance(statement),
            tickDuration = ParseTime(statement),
            conditions = ParseConditions(statement)
        };
        CombatConstants.classNames.TryGetValue(statement.statement, out modifier.className);
        if (modifier.tickDuration == 0)
        {
            throw new ParseException("Combat buff requires a time limit: " + statement.statement);
        }
        if (statement.parameters.Count > 0)
        {
            throw new ParseException("Unknown parameter for buff: " + statement.statement);
        }
        return modifier;
    }

    public static CombatConstants.Target ParseTarget(GSStatement statement)
    {
        foreach (GSQualifier qualifier in statement.qualifiers)
        {
            if (qualifier.type == GSQualifierType.TARGET)
            {
                if (!CombatConstants.targetNames.ContainsKey(qualifier.target))
                {
                    throw new ParseException("Unknown target type: " + qualifier.target);
                }
                CombatConstants.Target target = CombatConstants.targetNames[qualifier.target];
                statement.qualifiers.Remove(qualifier);
                return target;
            }
        }
        return CombatConstants.Target.TARGET;
    }

    public static uint ParseTime(GSStatement statement)
    {
        foreach (GSParam param in statement.parameters)
        {
            uint num;
            if (param.unit == GSParamUnit.ROUND)
            {
                num = (uint) (param.value * CombatData.singleton.roundTimeInTicks);
                statement.parameters.Remove(param);
                return num;
            }
            if (param.unit == GSParamUnit.SECOND)
            {
                num = (uint) (param.value * 10);
                statement.parameters.Remove(param);
                return num;
            }
        }
        return 0;
    }

    public static uint ParseUIntParameter(GSStatement statement)
    {
        return (uint) ParseIntParameter(statement);
    }

    public static ushort ParseUShortParameter(GSStatement statement)
    {
        return (ushort) ParseIntParameter(statement);
    }

    public override string ToString()
    {
        object obj2;
        string str = string.Empty;
        switch (this.type)
        {
            case CombatModifierType.BUFF:
                obj2 = str;
                str = string.Concat(new object[] { obj2, "Buff ", this.buff, " duration (ticks) ", this.tickDuration, " % ", this.percentage });
                break;

            case CombatModifierType.STACK:
                obj2 = str;
                str = string.Concat(new object[] { obj2, "Stack ", this.stack, " stacks ", this.stackAmount });
                break;

            case CombatModifierType.ATTACK_MODIFIER:
                obj2 = str;
                str = string.Concat(new object[] { obj2, "Attack Mod ", this.attackMod, " amount ", this.attackModAmount });
                break;

            case CombatModifierType.STATE:
                str = str + "State " + this.state;
                break;

            case CombatModifierType.INSTANT:
                str = str + "Instant " + this.instant;
                break;

            case CombatModifierType.DISTANCE:
                obj2 = str;
                str = string.Concat(new object[] { obj2, "Distance ", this.distanceEffect, " size ", this.distanceMeters });
                break;

            case CombatModifierType.AOE:
                str = str + "AoE " + this.areaOfEffect;
                break;

            case CombatModifierType.RECOVERY:
                obj2 = str;
                str = string.Concat(new object[] { obj2, "Recovery ", this.recovery, " amount ", this.statAmount });
                break;

            case CombatModifierType.DEFENSE:
                obj2 = str;
                str = string.Concat(new object[] { obj2, "Defense ", this.defense, " amount ", this.statAmount });
                break;

            default:
                obj2 = str;
                str = string.Concat(new object[] { obj2, "<UPDATE [", this.type, "] ToString()!>" });
                break;
        }
        return string.Concat(new object[] { str, " target ", this.target, " chance ", this.chance, " className '", this.className, "'" });
    }
}

