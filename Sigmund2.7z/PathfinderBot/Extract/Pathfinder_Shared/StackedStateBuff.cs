﻿using System;

public class StackedStateBuff : CombatStackBuff
{
    public StackedStateBuff() : base("Stacked State", Combat.Channel.State, Combat.EffectType.Beneficial)
    {
    }

    public static StackedStateBuff Create()
    {
        return new StackedStateBuff();
    }

    public override string GetLogString(CombatModifier mod, CombatEffect effect, int defenseBonus)
    {
        int num;
        float num2;
        base.GetStacks(mod, effect, defenseBonus, out num, out num2);
        return GUtil.GetQuickText().Append(this.GetName(mod.stack)).Append(" ").Append(num).ToString();
    }

    private string GetName(CombatConstants.Stack stack)
    {
        switch (stack)
        {
            case CombatConstants.Stack.MIND_BLANK:
                return "Mind Blank";

            case CombatConstants.Stack.FREEDOM:
                return "Freedom";
        }
        return base.name;
    }

    public override CombatBuffVars Initialize(uint combatTick, CombatModifier mod, CombatVars target, int additionalDefense)
    {
        CombatBuffVars vars = base.Initialize(combatTick, mod, target, additionalDefense);
        vars.basicName = this.GetName(mod.stack);
        vars.name = vars.basicName;
        if (mod.stack == CombatConstants.Stack.MIND_BLANK)
        {
            vars.channel = Combat.Channel.Morale;
            vars.recoveryBonusType = RecoveryType.MindBlank;
        }
        if (mod.stack == CombatConstants.Stack.FREEDOM)
        {
            vars.channel = Combat.Channel.Morale;
            vars.recoveryBonusType = RecoveryType.Freedom;
        }
        return vars;
    }

    public override void RecalculationPhase(CombatBuffVars buff, uint combatTick)
    {
    }

    public override void ResolutionPhase(CombatBuffVars buff, uint combatTick)
    {
    }
}

