﻿using GNetwork;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

public abstract class DataSerializer
{
    [ThreadStatic]
    private static System.Type[] getParams;
    [ThreadStatic]
    private static Dictionary<FieldInfo, Delegate> memberGetDelegates;
    [ThreadStatic]
    private static Dictionary<FieldInfo, Delegate> memberSetDelegates;
    protected bool processDelta = false;
    [ThreadStatic]
    private static System.Type[] setParams;
    [ThreadStatic]
    private static Dictionary<System.Type, DispatchSwitch> switchByType;
    protected byte targetLevel = 0;

    protected DataSerializer()
    {
        if (switchByType == null)
        {
            switchByType = new Dictionary<System.Type, DispatchSwitch>();
        }
        if (memberGetDelegates == null)
        {
            memberGetDelegates = new Dictionary<FieldInfo, Delegate>();
        }
        if (memberSetDelegates == null)
        {
            memberSetDelegates = new Dictionary<FieldInfo, Delegate>();
        }
        if (getParams == null)
        {
            getParams = new System.Type[] { typeof(object) };
        }
        if (setParams == null)
        {
            System.Type[] typeArray = new System.Type[2];
            typeArray[0] = typeof(object).MakeByRefType();
            setParams = typeArray;
        }
    }

    private static GetValueDirectDelegate<MemberType> CreateGetValueDirectDelegate<MemberType>(FieldInfo fld)
    {
        DynamicMethod method = new DynamicMethod("GetValueDirect", typeof(MemberType), getParams, fld.DeclaringType);
        ILGenerator iLGenerator = method.GetILGenerator();
        iLGenerator.Emit(OpCodes.Ldarg_0);
        if (fld.DeclaringType.IsValueType)
        {
            iLGenerator.Emit(OpCodes.Unbox, fld.DeclaringType);
        }
        else
        {
            iLGenerator.Emit(OpCodes.Castclass, fld.DeclaringType);
        }
        iLGenerator.Emit(OpCodes.Ldfld, fld);
        if (fld.FieldType.IsValueType && (typeof(MemberType) == typeof(object)))
        {
            iLGenerator.Emit(OpCodes.Box, fld.FieldType);
        }
        iLGenerator.Emit(OpCodes.Ret);
        return (GetValueDirectDelegate<MemberType>) method.CreateDelegate(typeof(GetValueDirectDelegate<MemberType>));
    }

    private static SetValueDirectDelegate<MemberType> CreateSetValueDirectDelegate<MemberType>(FieldInfo fld)
    {
        setParams[1] = typeof(MemberType);
        DynamicMethod method = new DynamicMethod("SetValueDirect", typeof(void), setParams, fld.DeclaringType);
        ILGenerator iLGenerator = method.GetILGenerator();
        iLGenerator.Emit(OpCodes.Ldarg_0);
        iLGenerator.Emit(OpCodes.Ldind_Ref);
        if (fld.DeclaringType.IsValueType)
        {
            iLGenerator.Emit(OpCodes.Unbox, fld.DeclaringType);
        }
        else
        {
            iLGenerator.Emit(OpCodes.Castclass, fld.DeclaringType);
        }
        iLGenerator.Emit(OpCodes.Ldarg_1);
        if (fld.FieldType.IsValueType && (typeof(MemberType) == typeof(object)))
        {
            iLGenerator.Emit(OpCodes.Unbox_Any, fld.FieldType);
        }
        iLGenerator.Emit(OpCodes.Stfld, fld);
        iLGenerator.Emit(OpCodes.Ret);
        return (SetValueDirectDelegate<MemberType>) method.CreateDelegate(typeof(SetValueDirectDelegate<MemberType>));
    }

    public object Deserialize(IBitBufferRead buffer, System.Type type, byte _targetLevel, object baseObj = null)
    {
        if ((buffer == null) || (buffer.lengthBits == 0))
        {
            return baseObj;
        }
        this.targetLevel = _targetLevel;
        byte defaultLevel = DataSerializerUtils.GetDefaultLevel(type);
        this.processDelta = buffer.PopBool();
        if (this.processDelta && (baseObj == null))
        {
            throw new NullReferenceException(string.Concat(new object[] { "Error attempting to deserialize a delta buffer with no base object: ", type.ToString(), " - ", _targetLevel }));
        }
        return this.ReadClass(buffer, null, type, defaultLevel, ref baseObj);
    }

    public static GetValueDirectDelegate<MemberType> GetCachedGetValueDirectDelegate<MemberType>(FieldInfo fld)
    {
        Delegate delegate2 = null;
        if (!memberGetDelegates.TryGetValue(fld, out delegate2))
        {
            delegate2 = CreateGetValueDirectDelegate<MemberType>(fld);
            memberGetDelegates[fld] = delegate2;
        }
        return (GetValueDirectDelegate<MemberType>) delegate2;
    }

    public static SetValueDirectDelegate<MemberType> GetCachedSetValueDirectDelegate<MemberType>(FieldInfo fld)
    {
        Delegate delegate2 = null;
        if (!memberSetDelegates.TryGetValue(fld, out delegate2))
        {
            delegate2 = CreateSetValueDirectDelegate<MemberType>(fld);
            memberSetDelegates[fld] = delegate2;
        }
        return (SetValueDirectDelegate<MemberType>) delegate2;
    }

    private static DispatchSwitch GetTypeSwitch(System.Type type)
    {
        DispatchSwitch aRRAY;
        if (!switchByType.TryGetValue(type, out aRRAY))
        {
            if (BitBuffer.IsContainedType(type))
            {
                aRRAY = DispatchSwitch.BBUFF_CONTAINED;
            }
            else if (BitBuffer.IsContainedDeltaType(type))
            {
                aRRAY = DispatchSwitch.BBUFF_DELTA;
            }
            else
            {
                if (type.IsPrimitive)
                {
                    throw new NotSupportedException("The primitive data type [" + type + "] is not supported in DataSerializer");
                }
                if (type.IsEnum && (Enum.GetUnderlyingType(type) == typeof(byte)))
                {
                    aRRAY = DispatchSwitch.BYTE_ENUM;
                }
                else if (type.IsEnum && (Enum.GetUnderlyingType(type) == typeof(ushort)))
                {
                    aRRAY = DispatchSwitch.USHORT_ENUM;
                }
                else
                {
                    if ((type.IsEnum && (Enum.GetUnderlyingType(type) != typeof(byte))) && (Enum.GetUnderlyingType(type) != typeof(ushort)))
                    {
                        throw new NotSupportedException("Error attempting to serialize an enum that is not declared as a byte or ushort: " + type);
                    }
                    if (type.IsArray)
                    {
                        aRRAY = DispatchSwitch.ARRAY;
                    }
                    else if (SparseArray.IndexOf<System.Type>(type.GetInterfaces(), x => x == typeof(IDictionary)) != -1)
                    {
                        aRRAY = DispatchSwitch.DICTIONARY;
                    }
                    else if (SparseArray.IndexOf<System.Type>(type.GetInterfaces(), x => x == typeof(IEnumerable)) != -1)
                    {
                        aRRAY = DispatchSwitch.ENUMERABLE;
                    }
                    else
                    {
                        aRRAY = DispatchSwitch.CLASS;
                    }
                }
            }
            switchByType[type] = aRRAY;
        }
        return aRRAY;
    }

    protected abstract Array ReadArray(IBitBufferRead buffer, FieldInfo field, System.Type type, byte defaultLevel, ref object baseObj);
    protected abstract object ReadClass(IBitBufferRead buffer, FieldInfo field, System.Type type, byte defaultLevel, ref object baseObj);
    protected virtual object ReadDictionary(IBitBufferRead buffer, FieldInfo field, System.Type type, byte defaultLevel, ref object baseObj)
    {
        throw new NotImplementedException("Not Implemented for type: " + base.GetType());
    }

    protected object ReadDispatch(IBitBufferRead buffer, FieldInfo field, System.Type type, byte defaultLevel, ref object baseObj)
    {
        object obj2 = null;
        switch (GetTypeSwitch(type))
        {
            case DispatchSwitch.BBUFF_CONTAINED:
                try
                {
                    obj2 = buffer.PopByType(type);
                }
                catch (Exception)
                {
                    GLog.LogError(new object[] { "SERIALIZE: Error when trying to unpack bit-buffer contained type:", type });
                    throw;
                }
                return obj2;

            case DispatchSwitch.BBUFF_DELTA:
                try
                {
                    obj2 = buffer.PopDeltaByType(type, baseObj);
                }
                catch (Exception)
                {
                    GLog.LogError(new object[] { "SERIALIZE: Error when trying to unpack bit-buffer contained type:", type });
                    throw;
                }
                return obj2;

            case DispatchSwitch.BYTE_ENUM:
                return buffer.PopByte();

            case DispatchSwitch.USHORT_ENUM:
                return buffer.PopUShort();

            case DispatchSwitch.ARRAY:
                try
                {
                    obj2 = this.ReadArray(buffer, field, type, defaultLevel, ref baseObj);
                }
                catch (Exception)
                {
                    GLog.LogError(new object[] { "SERIALIZE: Error when trying to unpack array:", type });
                    throw;
                }
                return obj2;

            case DispatchSwitch.DICTIONARY:
                try
                {
                    obj2 = this.ReadDictionary(buffer, field, type, defaultLevel, ref baseObj);
                }
                catch (Exception)
                {
                    GLog.LogError(new object[] { "SERIALIZE: Error when trying to unpack dictionary:", type });
                    throw;
                }
                return obj2;

            case DispatchSwitch.ENUMERABLE:
                try
                {
                    obj2 = this.ReadEnumerable(buffer, field, type, defaultLevel, ref baseObj);
                }
                catch (Exception)
                {
                    GLog.LogError(new object[] { "SERIALIZE: Error when trying to unpack enumerable:", type });
                    throw;
                }
                return obj2;

            case DispatchSwitch.CLASS:
                try
                {
                    obj2 = this.ReadClass(buffer, field, type, defaultLevel, ref baseObj);
                }
                catch (Exception)
                {
                    GLog.LogError(new object[] { "SERIALIZE: Error when trying to unpack class:", type });
                    throw;
                }
                return obj2;
        }
        return obj2;
    }

    protected virtual object ReadEnumerable(IBitBufferRead buffer, FieldInfo field, System.Type type, byte defaultLevel, ref object baseObj)
    {
        throw new NotImplementedException("Not Implemented for type: " + base.GetType());
    }

    public int Serialize(IBitBufferWrite buffer, byte _targetLevel, object obj, object baseObj = null)
    {
        if ((obj == null) || obj.GetType().IsPrimitive)
        {
            return 0;
        }
        this.targetLevel = _targetLevel;
        this.processDelta = baseObj != null;
        System.Type type = obj.GetType();
        byte defaultLevel = DataSerializerUtils.GetDefaultLevel(type);
        if (this.processDelta && DataSerializerUtils.IsEqual(obj, baseObj, type, _targetLevel))
        {
            return 0;
        }
        buffer.PushBool(this.processDelta);
        this.WriteClass(buffer, null, type, defaultLevel, obj, baseObj);
        return buffer.lengthBits;
    }

    protected void WriteArray(IBitBufferWrite buffer, FieldInfo field, System.Type type, byte defaultLevel, Array obj, Array baseObj)
    {
        buffer.PushBool(obj != null);
        if (obj != null)
        {
            int arrayRank = type.GetArrayRank();
            buffer.PushInt(arrayRank);
            for (int i = 0; i < arrayRank; i++)
            {
                buffer.PushInt(obj.GetLength(i));
            }
            if ((arrayRank != 1) || !CheapHacks.WriteSimpleArray(this, buffer, field, type, defaultLevel, this.targetLevel, obj, baseObj))
            {
                System.Type elementType = type.GetElementType();
                for (int[] numArray = DataSerializerUtils.FirstIndex(obj); numArray != null; numArray = DataSerializerUtils.NextIndex(obj, numArray))
                {
                    this.WriteCplxArrayIndex(buffer, field, elementType, defaultLevel, obj.GetValue(numArray), null, baseObj, numArray);
                }
            }
        }
    }

    protected abstract void WriteClass(IBitBufferWrite buffer, FieldInfo field, System.Type type, byte defaultLevel, object obj, object baseObj);
    public virtual void WriteCplxArrayIndex(IBitBufferWrite buffer, FieldInfo field, System.Type et, byte defaultLevel, object currentValue, object baseValue, Array baseObj, int[] index)
    {
        this.WriteDispatch(buffer, field, et, defaultLevel, currentValue, baseValue);
    }

    protected virtual void WriteDictionary(IBitBufferWrite buffer, FieldInfo field, byte defaultLevel, IDictionary obj, IDictionary baseObj)
    {
        throw new NotImplementedException("Not Implemented for type: " + base.GetType());
    }

    protected void WriteDispatch(IBitBufferWrite buffer, FieldInfo field, System.Type type, byte defaultLevel, object obj, object baseObj)
    {
        switch (GetTypeSwitch(type))
        {
            case DispatchSwitch.BBUFF_CONTAINED:
                buffer.PushByType(type, obj);
                break;

            case DispatchSwitch.BBUFF_DELTA:
                buffer.PushDeltaByType(type, obj, baseObj);
                break;

            case DispatchSwitch.BYTE_ENUM:
                buffer.PushByte((byte) obj);
                break;

            case DispatchSwitch.USHORT_ENUM:
                buffer.PushUShort((ushort) obj);
                break;

            case DispatchSwitch.ARRAY:
                this.WriteArray(buffer, field, type, defaultLevel, (Array) obj, (Array) baseObj);
                break;

            case DispatchSwitch.DICTIONARY:
                this.WriteDictionary(buffer, field, defaultLevel, (IDictionary) obj, (IDictionary) baseObj);
                break;

            case DispatchSwitch.ENUMERABLE:
                this.WriteEnumerable(buffer, field, defaultLevel, (IEnumerable) obj, (IEnumerable) baseObj);
                break;

            case DispatchSwitch.CLASS:
                this.WriteClass(buffer, field, type, defaultLevel, obj, baseObj);
                break;
        }
    }

    protected virtual void WriteEnumerable(IBitBufferWrite buffer, FieldInfo field, byte defaultLevel, IEnumerable obj, IEnumerable baseObj)
    {
        throw new NotImplementedException(string.Concat(new object[] { "Not Implemented for type: ", base.GetType(), ",", obj, ",", baseObj }));
    }

    private enum DispatchSwitch : byte
    {
        ARRAY = 4,
        BBUFF_CONTAINED = 0,
        BBUFF_DELTA = 1,
        BYTE_ENUM = 2,
        CLASS = 7,
        DICTIONARY = 5,
        ENUMERABLE = 6,
        USHORT_ENUM = 3
    }

    public delegate MemberType GetValueDirectDelegate<MemberType>(object target);

    public delegate void SetValueDirectDelegate<MemberType>(ref object target, MemberType value);
}

