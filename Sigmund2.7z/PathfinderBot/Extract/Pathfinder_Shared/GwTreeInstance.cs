﻿using System;
using UnityEngine;

public class GwTreeInstance
{
    public Color color;
    public float heightScale;
    public Color lightmapColor;
    public Vector3 pos;
    public int prototypeIndex;
    public float widthScale;

    public static GwTreeInstance FromTreeInstance(TreeInstance inst)
    {
        return new GwTreeInstance { color = inst.color, lightmapColor = inst.lightmapColor, heightScale = inst.heightScale, widthScale = inst.widthScale, pos = inst.position, prototypeIndex = inst.prototypeIndex };
    }

    public static TreeInstance ToTreeInstance(GwTreeInstance oldInst)
    {
        return new TreeInstance { color = oldInst.color, lightmapColor = oldInst.lightmapColor, heightScale = oldInst.heightScale, widthScale = oldInst.widthScale, position = oldInst.pos, prototypeIndex = oldInst.prototypeIndex };
    }
}

