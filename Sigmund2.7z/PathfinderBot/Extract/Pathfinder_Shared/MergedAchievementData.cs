﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;

[StrongDependency(typeof(InteractionAchievementData)), StrongDependency(typeof(WeaponKillAchievementData)), NoExcelData, StrongDependency(typeof(LocationAchievementData)), StrongDependency(typeof(MetaAchievementData)), StrongDependency(typeof(CraftingAchievementData)), StrongDependency(typeof(NpcKillAchievementData)), StrongDependency(typeof(PlayerKillAchievementData)), StrongDependency(typeof(FeatAchievementData))]
public class MergedAchievementData : DataClass
{
    public GenericAchievementData[] _allAchievements = new GenericAchievementData[0];
    public static Dictionary<int, GenericAchievementData[]> achievementsByPageId = new Dictionary<int, GenericAchievementData[]>();
    public static Dictionary<string, GenericAchievementData[]> achievementsByTypeName = new Dictionary<string, GenericAchievementData[]>();
    private static readonly System.Type[] allAchievementTypes = new System.Type[] { typeof(CraftingAchievementData), typeof(InteractionAchievementData), typeof(LocationAchievementData), typeof(MetaAchievementData), typeof(NpcKillAchievementData), typeof(PlayerKillAchievementData), typeof(FeatAchievementData), typeof(WeaponKillAchievementData) };
    public static GenericAchievementData[] allMergedAchievements;
    public static HashSet<int> allSlotIds = new HashSet<int>();
    public static Dictionary<int, GenericAchievementData> dataById = new Dictionary<int, GenericAchievementData>();
    public static Dictionary<string, GenericAchievementData[]> dataBySlotName = new Dictionary<string, GenericAchievementData[]>();
    private static GenericAchievementData[] tempAchievements = new GenericAchievementData[0x10];
    private static Dictionary<int, GenericAchievementData> tempBySlot = new Dictionary<int, GenericAchievementData>();
    private static HashSet<int> tempSlotIds = new HashSet<int>();

    public static GenericAchievementData[] GetAllAchievements()
    {
        return allMergedAchievements;
    }

    public static GenericAchievementData[] GetFinishedAchievements(AdvancementVars advVars, IEnumerable<GenericAchievementData> achievementList)
    {
        SparseArray.Clear<GenericAchievementData>(ref tempAchievements);
        tempSlotIds.Clear();
        tempBySlot.Clear();
        foreach (GenericAchievementData data2 in achievementList)
        {
            GenericAchievementData data;
            if (advVars.HasAchievement(data2) && (!tempBySlot.TryGetValue(data2.slotId, out data) || (data2.level > data.level)))
            {
                tempBySlot[data2.slotId] = data2;
            }
        }
        uint probableIndex = 0;
        foreach (KeyValuePair<int, GenericAchievementData> pair in tempBySlot)
        {
            probableIndex = SparseArray.Add<GenericAchievementData>(ref tempAchievements, pair.Value, probableIndex);
        }
        return tempAchievements;
    }

    public static byte GetMaxLevel(int slotId)
    {
        byte level = 0;
        for (int i = 0; i < allMergedAchievements.Length; i++)
        {
            if ((allMergedAchievements[i].slotId == slotId) && (allMergedAchievements[i].level > level))
            {
                level = allMergedAchievements[i].level;
            }
        }
        return level;
    }

    public static GenericAchievementData[] GetNewAchievements(AdvancementVars advVars, IEnumerable<GenericAchievementData> achievementList)
    {
        SparseArray.Clear<GenericAchievementData>(ref tempAchievements);
        tempSlotIds.Clear();
        tempBySlot.Clear();
        foreach (GenericAchievementData data in achievementList)
        {
            if (!((data.level != 1) || advVars.HasAchievement(data)))
            {
                SparseArray.Add<GenericAchievementData>(ref tempAchievements, data);
            }
        }
        return tempAchievements;
    }

    public static GenericAchievementData[] GetNextAchievements(AdvancementVars advVars, IEnumerable<GenericAchievementData> achievementList, int minLevel = 0)
    {
        SparseArray.Clear<GenericAchievementData>(ref tempAchievements);
        tempSlotIds.Clear();
        tempBySlot.Clear();
        foreach (GenericAchievementData data2 in achievementList)
        {
            GenericAchievementData data;
            if (!(advVars.HasAchievement(data2) || (tempBySlot.TryGetValue(data2.slotId, out data) && (data2.level >= data.level))))
            {
                tempBySlot[data2.slotId] = data2;
            }
        }
        uint probableIndex = 0;
        foreach (KeyValuePair<int, GenericAchievementData> pair in tempBySlot)
        {
            probableIndex = SparseArray.Add<GenericAchievementData>(ref tempAchievements, pair.Value, probableIndex);
        }
        return tempAchievements;
    }

    public override List<DataClass> MergeData()
    {
        MergedAchievementData output = new MergedAchievementData();
        IEnumerable<GenericAchievementData> first = Enumerable.Empty<GenericAchievementData>();
        foreach (System.Type type in allAchievementTypes)
        {
            first = first.Concat<GenericAchievementData>(from each in DataClass.GetData(type) select (GenericAchievementData) each);
        }
        output._allAchievements = first.ToArray<GenericAchievementData>();
        Dictionary<int, bool> cachedResults = new Dictionary<int, bool>();
        HashSet<int> invalidSlotIds = new HashSet<int>(from each in output._allAchievements
            where !ValidateLevelSequence(ref cachedResults, each.slotId, output._allAchievements)
            select each.slotId);
        using (HashSet<int>.Enumerator enumerator = invalidSlotIds.GetEnumerator())
        {
            while (enumerator.MoveNext())
            {
                Func<GenericAchievementData, bool> func = null;
                int eachSlotId = enumerator.Current;
                if (func == null)
                {
                    func = each => each.slotId == eachSlotId;
                }
                IEnumerable<string> items = from each in Enumerable.Where<GenericAchievementData>(output._allAchievements, func)
                    orderby each.level
                    select each.slotName + each.level;
                DataClass.OutputErrorMessage("Achievement levels not sequential: " + GUtil.PrettyPrint(items, ", ", ""));
            }
        }
        output._allAchievements = (from each in output._allAchievements
            where !invalidSlotIds.Contains(each.slotId)
            select each).ToArray<GenericAchievementData>();
        return new List<DataClass> { output };
    }

    public static void OnLoad(List<DataClass> objects)
    {
        if (objects.Count != 1)
        {
            GLog.LogError(new object[] { "MergedAchievementData should never have more than 1 item." });
        }
        else
        {
            allMergedAchievements = ((MergedAchievementData) objects[0])._allAchievements;
            AdvancementIndexedDataClass.AssignPageNumbers(allMergedAchievements);
            HashSet<int> set = new HashSet<int>();
            HashSet<System.Type> set2 = new HashSet<System.Type>();
            HashSet<string> set3 = new HashSet<string>();
            for (int i = 0; i < allMergedAchievements.Length; i++)
            {
                set.Add(allMergedAchievements[i].pageId);
                set2.Add(allMergedAchievements[i].GetType());
                set3.Add(allMergedAchievements[i].slotName);
                dataById[allMergedAchievements[i].id] = allMergedAchievements[i];
                allSlotIds.Add(allMergedAchievements[i].slotId);
            }
            using (HashSet<int>.Enumerator enumerator = set.GetEnumerator())
            {
                while (enumerator.MoveNext())
                {
                    int eachPageId = enumerator.Current;
                    achievementsByPageId[eachPageId] = (from each in allMergedAchievements
                        where each.pageId == eachPageId
                        select each).ToArray<GenericAchievementData>();
                }
            }
            using (HashSet<System.Type>.Enumerator enumerator2 = set2.GetEnumerator())
            {
                while (enumerator2.MoveNext())
                {
                    System.Type eachType = enumerator2.Current;
                    achievementsByTypeName[eachType.Name] = (from each in allMergedAchievements
                        where each.GetType() == eachType
                        select each).ToArray<GenericAchievementData>();
                }
            }
            using (HashSet<string>.Enumerator enumerator3 = set3.GetEnumerator())
            {
                while (enumerator3.MoveNext())
                {
                    string eachSlotName = enumerator3.Current;
                    dataBySlotName[eachSlotName] = (from each in allMergedAchievements
                        where each.slotName == eachSlotName
                        orderby each.level
                        select each).ToArray<GenericAchievementData>();
                }
            }
        }
    }

    public static bool TryGet(string slotName, byte level, out GenericAchievementData output)
    {
        GenericAchievementData[] dataArray;
        byte index = (byte) (level - 1);
        output = null;
        if (!dataBySlotName.TryGetValue(slotName, out dataArray))
        {
            return false;
        }
        if ((dataArray.Length <= index) || (dataArray[index].level != level))
        {
            return false;
        }
        output = dataArray[index];
        return true;
    }

    private static bool ValidateLevelSequence(ref Dictionary<int, bool> cachedResults, int eachSlotId, GenericAchievementData[] allAchievements)
    {
        if (cachedResults.ContainsKey(eachSlotId))
        {
            return cachedResults[eachSlotId];
        }
        bool flag = true;
        int num = 1;
        GenericAchievementData data = null;
        foreach (GenericAchievementData data2 in from each in allAchievements
            where each.slotId == eachSlotId
            orderby each.level
            select each)
        {
            if (num != data2.level)
            {
                flag = false;
                break;
            }
            if (!((data == null) || data2.requiredAchievementIds.Contains<int>(data.id)))
            {
                Array.Resize<int>(ref data2.requiredAchievementIds, data2.requiredAchievementIds.Length + 1);
                data2.requiredAchievementIds[data2.requiredAchievementIds.Length - 1] = data.id;
            }
            data = data2;
            num++;
        }
        cachedResults[eachSlotId] = flag;
        return flag;
    }
}

