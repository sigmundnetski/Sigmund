﻿using System;
using System.Collections.Generic;

[StrongDependency(typeof(HexTerrainData)), StrongDependency(typeof(HexTypeData))]
public class HexData : DataClass
{
    private static readonly string[] _mandatoryColumns = new string[] { "x-coord", "z-coord", "hextype", "terrain", "settlement map", "tower" };
    public static Dictionary<ushort, HexData> dataByMapId = new Dictionary<ushort, HexData>();
    public bool hasTower;
    public int hexTypeId = 0;
    public ushort mapId = 0;
    public string mapTexture = null;
    public int terrainDataId = 0;

    public static void ConstructCommonUnittestData()
    {
        if (HexTypeData.typeByName.Count == 0)
        {
            UUnitAssert.Fail("HexTypeData must be built before HexData");
        }
        List<DataClass> objects = new List<DataClass> {
            MakeUnittestInstance("Monster", TerrainUtils.GetMapIdFromHex(-10, 0), HexTypeData.typeByName["monster"].id),
            MakeUnittestInstance("Settlement", TerrainUtils.GetMapIdFromHex(-9, -2), HexTypeData.typeByName["settlement"].id),
            MakeUnittestInstance("Wild_1", TerrainUtils.GetMapIdFromHex(-8, -1), HexTypeData.typeByName["wild"].id),
            MakeUnittestInstance("Wild_2", TerrainUtils.GetMapIdFromHex(-8, -2), HexTypeData.typeByName["wild"].id),
            MakeUnittestInstance("Wild_3", TerrainUtils.GetMapIdFromHex(-9, -1), HexTypeData.typeByName["wild"].id),
            MakeUnittestInstance("Wild_4", TerrainUtils.GetMapIdFromHex(-9, -3), HexTypeData.typeByName["wild"].id),
            MakeUnittestInstance("Wild_5", TerrainUtils.GetMapIdFromHex(-10, -1), HexTypeData.typeByName["wild"].id),
            MakeUnittestInstance("Wild_6", TerrainUtils.GetMapIdFromHex(-10, -2), HexTypeData.typeByName["wild"].id)
        };
        OnLoad(objects);
    }

    public static HexTypeData GetHexType(ushort mapId)
    {
        HexData data;
        HexTypeData data2;
        if (dataByMapId.TryGetValue(mapId, out data) && HexTypeData.typeById.TryGetValue(data.hexTypeId, out data2))
        {
            return data2;
        }
        return HexTypeData.defaultHexType;
    }

    public static HexData MakeUnittestInstance(string _name, ushort _mapId, int _hexTypeId)
    {
        return new HexData { name = _name.ToLower(), id = DataClass.GenerateId(_name), mapId = _mapId, hexTypeId = _hexTypeId, mapTexture = null };
    }

    public static void OnLoad(List<DataClass> objects)
    {
        foreach (HexData data in objects)
        {
            dataByMapId[data.mapId] = data;
        }
    }

    public override DataClass ParseRecord(int index)
    {
        int num;
        int num2;
        if (!(DataClass.TryGetCellValue(DataClass.columnNamesToIndex["x-coord"], index, out num) && DataClass.TryGetCellValue(DataClass.columnNamesToIndex["z-coord"], index, out num2)))
        {
            return null;
        }
        IntVec2 hexCoords = new IntVec2(num, num2);
        HexData data = new HexData {
            mapId = TerrainUtils.GetMapIdFromHex(hexCoords),
            name = hexCoords.ToString()
        };
        DataClass.GetIdFromForeignName<HexTypeData>(DataClass.columnNamesToIndex["hextype"], index, out data.hexTypeId);
        DataClass.GetIdFromForeignName<HexTerrainData>(DataClass.columnNamesToIndex["terrain"], index, out data.terrainDataId);
        if (!DataClass.TryGetCellValue(DataClass.columnNamesToIndex["settlement map"], index, out data.mapTexture))
        {
            data.mapTexture = null;
        }
        DataClass.TryGetCellValue(DataClass.columnNamesToIndex["tower"], index, out data.hasTower);
        return data;
    }

    protected override IEnumerable<string> GetMandatoryColumns
    {
        get
        {
            return _mandatoryColumns;
        }
    }
}

