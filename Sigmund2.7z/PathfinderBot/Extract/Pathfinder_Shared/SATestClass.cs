﻿using System;

internal class SATestClass : IDataCopyable<SATestClass>
{
    public int value;

    public SATestClass()
    {
    }

    public SATestClass(int value_)
    {
        this.value = value_;
    }

    public void DataCopyTo(ref SATestClass target, byte syncTargetLevel)
    {
        target.value = this.value;
    }

    public bool DataEquals(SATestClass target, byte syncTargetLevel)
    {
        if (object.ReferenceEquals(this, target))
        {
            return true;
        }
        if (object.ReferenceEquals(target, null))
        {
            return false;
        }
        bool flag = true;
        return (flag && (this.value == target.value));
    }

    public override bool Equals(object target)
    {
        return this.DataEquals(target as SATestClass, 0xff);
    }

    public override int GetHashCode()
    {
        return this.value.GetHashCode();
    }
}

