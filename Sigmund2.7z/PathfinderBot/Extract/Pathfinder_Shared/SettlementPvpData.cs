﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

public class SettlementPvpData : DataClass
{
    private static readonly string[] _mandatoryColumns = new string[] { "key", "value", "units" };
    public TimeSpan defaultPvpStart = TimeSpan.Zero;
    public TimeSpan noPvpEnd = TimeSpan.Zero;
    public TimeSpan noPvpStart = TimeSpan.Zero;

    public static void OnLoad(List<DataClass> objects)
    {
        singleton = (SettlementPvpData) objects[0];
    }

    public static void OnUnload()
    {
        singleton = null;
    }

    public override void ParseRecord(ref DataClass obj, int index)
    {
        SettlementPvpData data = (SettlementPvpData) obj;
        if (data == null)
        {
            data = new SettlementPvpData();
        }
        string output = string.Empty;
        if (DataClass.TryGetLCaseCellValue(DataClass.columnNamesToIndex["key"], index, out output))
        {
            string str2 = output;
            if (str2 != null)
            {
                if (!(str2 == "no pvp start"))
                {
                    if (str2 == "no pvp end")
                    {
                        DataClass.GetTimeValue(DataClass.columnNamesToIndex["value"], index, DataClass.columnNamesToIndex["units"], index, out data.noPvpEnd);
                    }
                    else if (str2 == "default pvp window start")
                    {
                        DataClass.GetTimeValue(DataClass.columnNamesToIndex["value"], index, DataClass.columnNamesToIndex["units"], index, out data.defaultPvpStart);
                    }
                }
                else
                {
                    DataClass.GetTimeValue(DataClass.columnNamesToIndex["value"], index, DataClass.columnNamesToIndex["units"], index, out data.noPvpStart);
                }
            }
            obj = data;
        }
    }

    public override List<DataClass> ParseSheet()
    {
        List<DataClass> list = new List<DataClass>();
        DataClass class2 = null;
        for (int i = 4; i <= DataClass.data.GetLength(0); i++)
        {
            this.ParseRecord(ref class2, i);
        }
        if (class2 != null)
        {
            list.Add(class2);
        }
        return list;
    }

    public static void SetupUnittestData(TimeSpan noPvpStart_, TimeSpan noPvpEnd_, TimeSpan defaultPvpStart_)
    {
        singleton = new SettlementPvpData();
        singleton.noPvpStart = noPvpStart_;
        singleton.noPvpEnd = noPvpEnd_;
        singleton.defaultPvpStart = defaultPvpStart_;
    }

    protected override IEnumerable<string> GetMandatoryColumns
    {
        get
        {
            return _mandatoryColumns;
        }
    }

    public static SettlementPvpData singleton
    {
        [CompilerGenerated]
        get
        {
            return <singleton>k__BackingField;
        }
        [CompilerGenerated]
        protected set
        {
            <singleton>k__BackingField = value;
        }
    }
}

