﻿using System;

internal class CombatPassiveTest : UUnitTestCase
{
    protected override void SetUp()
    {
        CombatTestHelper.SetUp();
        CombatTestHelper.MakeCombatData();
        CombatTestHelper.AddRefreshFeat(new RefreshFeatData("not passive", 1, 0f, 0, 0f, "Heal +100 to Self", "desc", "rDesc", 3));
        CombatTestHelper.AddFeatureFeat(new FeatureFeatData("first passive", 1, "Base Damage +5, Improved Critical +10", "desc"));
        CombatTestHelper.AddFeatureFeat(new FeatureFeatData("second passive", 1, "Precise +5", "desc"));
        CombatTestHelper.LoadNonAttackFeats();
    }

    protected override void TearDown()
    {
        CombatTestHelper.ClearAllCombatStaticData();
    }

    [UUnitTestMethod]
    public void TestActivate()
    {
        CombatPassive passive = new CombatPassive();
        NonAttackFeatData featByName = NonAttackFeatData.GetFeatByName("first passive 1");
        UUnitAssert.False(passive.IsActive(featByName.id), "Fail");
        passive.Activate(featByName.id);
        UUnitAssert.True(passive.IsActive(featByName.id), "Fail");
        featByName = NonAttackFeatData.GetFeatByName("second passive 1");
        UUnitAssert.False(passive.IsActive(featByName.id), "Fail");
        passive.Activate(featByName.id);
        UUnitAssert.True(passive.IsActive(featByName.id), "Fail");
        NonAttackFeatData data2 = NonAttackFeatData.GetFeatByName("not passive 1");
        UUnitAssert.False(passive.IsActive(data2.id), "Fail");
        passive.Activate(data2.id);
        UUnitAssert.False(passive.IsActive(data2.id), "Fail");
    }

    [UUnitTestMethod]
    public void TestDeactivate()
    {
        CombatPassive passive = new CombatPassive();
        NonAttackFeatData featByName = NonAttackFeatData.GetFeatByName("first passive 1");
        NonAttackFeatData data2 = NonAttackFeatData.GetFeatByName("second passive 1");
        passive.Activate(featByName.id);
        passive.Activate(data2.id);
        UUnitAssert.True(passive.IsActive(featByName.id), "Fail");
        UUnitAssert.True(passive.IsActive(data2.id), "Fail");
        passive.Deactivate(featByName.id);
        UUnitAssert.False(passive.IsActive(featByName.id), "Fail");
        UUnitAssert.True(passive.IsActive(data2.id), "Fail");
    }

    [UUnitTestMethod]
    public void TestIterate()
    {
        CombatPassive passive = new CombatPassive();
        NonAttackFeatData featByName = NonAttackFeatData.GetFeatByName("first passive 1");
        NonAttackFeatData data2 = NonAttackFeatData.GetFeatByName("second passive 1");
        passive.Activate(featByName.id);
        passive.Activate(data2.id);
        int wanted = 0;
        passive.StartIteration();
        while (passive.MoveNextMod())
        {
            wanted++;
            CombatModifier modifier = passive.CurrentMod();
            UUnitAssert.Equals(modifier.type, CombatModifierType.ATTACK_MODIFIER, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
            UUnitAssert.True(((modifier.attackMod == CombatConstants.AttackMod.PRECISE) || (modifier.attackMod == CombatConstants.AttackMod.IMPROVED_CRITICAL)) || (modifier.attackMod == CombatConstants.AttackMod.BASE_DAMAGE), "Expected Precise, Improved Critical, or Base Damage mod. Got " + modifier.attackMod);
        }
        UUnitAssert.Equals(wanted, 3, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
    }
}

