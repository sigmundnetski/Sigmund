﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;

[LooseDependency(typeof(GatheringNodeData)), LooseDependency(typeof(HexData)), LooseDependency(typeof(HexTypeData)), LooseDependency(typeof(CraftingItemData)), LooseDependency(typeof(ItemDatabase))]
public class ResourceByHexData : DataClass
{
    public ushort[] initItemRatings;
    public ushort mapId;
    public int[] rawNameIds;
    public static Dictionary<ushort, ResourceByHexData> resourcesByMapId = new Dictionary<ushort, ResourceByHexData>();

    public static void ConstructCommonUnittestData(ushort mapId)
    {
        ResourceByHexData data;
        if (CraftingItemData.rawMaterialsByNameId.Count == 0)
        {
            UUnitAssert.Fail("CraftingItemData must be constructed before ResourceByHexData");
        }
        data = new ResourceByHexData {
            name = mapId.ToString(),
            id = DataClass.GenerateId(data.name),
            mapId = mapId,
            rawNameIds = CraftingItemData.rawMaterialsByNameId.Keys.ToArray<int>(),
            initItemRatings = new ushort[data.rawNameIds.Length]
        };
        for (int i = 0; i < data.initItemRatings.Length; i++)
        {
            data.initItemRatings[i] = 0x3e8;
        }
        resourcesByMapId[data.mapId] = data;
    }

    private void GetFirstDataCell(out int firstColIndex, out int firstRowIndex)
    {
        string str;
        DataClass.GetLCaseCellValue(2, 2, out str);
        DataClass.SplitCellReference(str, out firstColIndex, out firstRowIndex);
    }

    private static void GetResourcesInHex(int firstRow, int colIndex, ushort mapId, int[] rawNameIdsOnPage, ref List<int> usedRawNameIds, ref List<ushort> ratings)
    {
        HexData data;
        HexTypeData data2;
        for (int i = firstRow; (i <= DataClass.MAX_ROW) && ((i - firstRow) < rawNameIdsOnPage.Length); i++)
        {
            ushort num;
            if (DataClass.GetCellValue(colIndex, i, out num) && (num != 0))
            {
                usedRawNameIds.Add(rawNameIdsOnPage[i - firstRow]);
                ratings.Add(num);
            }
        }
        ushort maxResourceNodes = 0;
        if (HexData.dataByMapId.TryGetValue(mapId, out data) && HexTypeData.typeById.TryGetValue(data.hexTypeId, out data2))
        {
            maxResourceNodes = data2.maxResourceNodes;
        }
        if ((maxResourceNodes > 0) && (usedRawNameIds.Count == 0))
        {
            DataClass.OutputErrorMessage(colIndex, firstRow, "No resources defined in hex: " + TerrainUtils.GetHexFromMapId(mapId));
        }
        else if ((maxResourceNodes == 0) && (usedRawNameIds.Count > 0))
        {
            DataClass.OutputErrorMessage(colIndex, firstRow, "Hex has resources, but no nodes: " + TerrainUtils.GetHexFromMapId(mapId));
        }
    }

    public static void OnLoad(List<DataClass> objects)
    {
        foreach (ResourceByHexData data in objects)
        {
            resourcesByMapId[data.mapId] = data;
        }
    }

    private int[] ParseItemsOnSheet(int firstRow)
    {
        List<int> list = new List<int>();
        for (int i = firstRow; i <= DataClass.MAX_ROW; i++)
        {
            string str;
            if (!(DataClass.TryGetLCaseCellValue(1, i, out str) && !string.IsNullOrEmpty(str)))
            {
                return list.ToArray();
            }
            int key = DataClass.GenerateId(str);
            if (CraftingItemData.rawMaterialsByNameId.ContainsKey(key))
            {
                list.Add(key);
            }
            else
            {
                DataClass.OutputErrorMessage(1, i, "Resource item not found: " + str);
            }
        }
        return list.ToArray();
    }

    private void ParseMapIdsOnSheet(int firstCol, ref List<ushort> mapIdList, ref List<int> validColumns)
    {
        for (int i = firstCol; i < DataClass.MAX_COL; i++)
        {
            int num;
            int num2;
            if (!(DataClass.TryGetCellValue(i, 2, out num) && DataClass.TryGetCellValue(i, 3, out num2)))
            {
                break;
            }
            mapIdList.Add(TerrainUtils.GetMapIdFromHex(num, num2));
            validColumns.Add(i);
        }
    }

    public override List<DataClass> ParseSheet()
    {
        int num;
        int num2;
        List<DataClass> list = new List<DataClass>();
        this.GetFirstDataCell(out num, out num2);
        int[] rawNameIdsOnPage = this.ParseItemsOnSheet(num2);
        List<int> validColumns = new List<int>();
        List<ushort> mapIdList = new List<ushort>();
        this.ParseMapIdsOnSheet(num, ref mapIdList, ref validColumns);
        List<int> usedRawNameIds = new List<int>();
        List<ushort> ratings = new List<ushort>();
        for (int i = 0; i < mapIdList.Count; i++)
        {
            ushort mapId = mapIdList[i];
            int colIndex = validColumns[i];
            ResourceByHexData item = new ResourceByHexData {
                name = mapId.ToString("x")
            };
            usedRawNameIds.Clear();
            ratings.Clear();
            GetResourcesInHex(num2, colIndex, mapId, rawNameIdsOnPage, ref usedRawNameIds, ref ratings);
            item.rawNameIds = usedRawNameIds.ToArray();
            item.initItemRatings = ratings.ToArray();
            item.mapId = mapId;
            list.Add(item);
        }
        return list;
    }
}

