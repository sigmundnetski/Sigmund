﻿using System;
using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Sequential)]
public struct GRoute
{
    public readonly uint id;
    public readonly RouteType type;
    public GRoute(RouteType aType, uint aId)
    {
        this.type = aType;
        this.id = aId;
    }

    public override string ToString()
    {
        return string.Concat(new object[] { "GRoute ", this.type, " ", this.id });
    }
    public enum RouteType : byte
    {
        AUTHORITY_SERVER = 3,
        CONNECTION_BY_PLAYER = 7,
        CONNECTION_SERVER = 1,
        LAUNCHER = 5,
        MAP_BY_PLAYER = 8,
        MAP_SERVER = 2,
        MAX_BASIC_ROUTE = 6,
        NONE = 0,
        NUM_BITS = 4,
        PLAYER = 6,
        ROUTER = 4
    }
}

