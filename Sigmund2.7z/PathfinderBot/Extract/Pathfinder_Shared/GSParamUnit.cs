﻿using System;

public enum GSParamUnit
{
    NONE,
    PERCENTAGE,
    SECOND,
    ROUND,
    METER,
    PERCENTAGE_CHANCE
}

