﻿using System;
using System.Runtime.CompilerServices;
using UnityEngine;

[RequireComponent(typeof(Collider))]
public class Door : MonoBehaviour
{
    public static DoorDelegate AddDoor;
    [NonSerialized]
    public ActiveDoor runtimeDetails = null;
    public string staticDetails = "";

    public ActiveDoor MakeRuntime()
    {
        if (this.runtimeDetails == null)
        {
            this.runtimeDetails = new ActiveDoor(base.transform.position);
        }
        else
        {
            this.runtimeDetails.position = base.transform.position;
            this.runtimeDetails.linkedFacility = null;
        }
        return this.runtimeDetails;
    }

    private void Start()
    {
        if (AddDoor != null)
        {
            AddDoor(this.MakeRuntime());
        }
    }

    public class ActiveDoor
    {
        private static uint _makeDoorId = 0;
        public readonly uint doorId;
        public Facility.ActiveFacility linkedFacility = null;
        public Vector3 position;

        public ActiveDoor(Vector3 _pos)
        {
            _makeDoorId++;
            this.doorId = _makeDoorId;
            this.position = _pos;
            this.linkedFacility = null;
        }

        public override string ToString()
        {
            return string.Concat(new object[] { "<Door: ", this.position, " linked:", this.linkedFacility != null, ">" });
        }
    }

    public delegate void DoorDelegate(Door.ActiveDoor doorPoint);
}

