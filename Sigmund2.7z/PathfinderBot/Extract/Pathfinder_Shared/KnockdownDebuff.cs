﻿using System;

public class KnockdownDebuff : CombatTimedBuff
{
    private const string FREEDOM_MOD = "Freedom +17 to Self";
    private static CombatModifier[] freedomCombatMod = CombatModifier.Parse("Freedom +17 to Self");
    private const uint KNOCKDOWN_FAILURE_PERCENTAGE = 30;
    private const int NON_MELEE_DEFENSE_BONUS = 20;
    private const string SLOW_MOD = "Slow 70% (1 round) to Self";
    private static CombatModifier[] slowCombatMod = CombatModifier.Parse("Slow 70% (1 round) to Self");

    public KnockdownDebuff() : base("Knockdown", Combat.Channel.Torment, Combat.EffectType.Detrimental)
    {
    }

    public static KnockdownDebuff Create()
    {
        return new KnockdownDebuff();
    }

    public override CombatBuffVars Initialize(uint combatTick, CombatModifier mod, CombatVars target, int additionalDefense)
    {
        CombatBuffVars stack = CombatBuff.GetStack(target, CombatConstants.Stack.FREEDOM);
        int stacks = 0;
        if (stack != null)
        {
            stacks = stack.stacks;
        }
        CombatBuffVars vars2 = base.Initialize(combatTick, mod, target, stacks);
        vars2.effectApplied = false;
        return vars2;
    }

    public override void RecalculationPhase(CombatBuffVars buff, uint combatTick)
    {
        if ((CombatVars.RestrictionType.NoAction | CombatVars.RestrictionType.NoMovement) > buff.owner.tempRestrictionType)
        {
            buff.owner.tempRestrictionType = CombatVars.RestrictionType.NoAction | CombatVars.RestrictionType.NoMovement;
        }
        if (20 > buff.owner.tempRangedDefenseBonus)
        {
            buff.owner.tempRangedDefenseBonus = 20;
        }
    }

    public override void ResolutionPhase(CombatBuffVars buff, uint combatTick)
    {
        if ((!buff.effectApplied && (combatTick < buff.expirationTick)) && (CombatCore.restrictMovement != null))
        {
            CombatCore.restrictMovement(buff.owner, CombatConstants.Buff.KNOCKDOWN, CombatVars.RestrictionType.NoAction | CombatVars.RestrictionType.NoMovement, CombatCore.SecondsFromTicks(buff.expirationTick - buff.startTick));
            buff.effectApplied = true;
        }
    }

    public override void UpdateBuff(CombatBuffVars buff, uint combatTick, CombatModifier mod, CombatEffect effect)
    {
        uint expirationTick = buff.expirationTick;
        base.UpdateBuff(buff, combatTick, mod, effect);
        if (buff.expirationTick > expirationTick)
        {
            CombatEffect effect2;
            if (buff.successPercentage <= 30)
            {
                buff.displayOnClient = false;
                base.Expire(buff, combatTick);
                slowCombatMod[0].tickDuration = mod.tickDuration;
                effect2 = new CombatEffect(slowCombatMod, buff.owner, buff.owner, CombatEffect.TargetType.ATTACKER, Combat.EffectType.Neutral);
                buff.owner.combatEffects.Enqueue(effect2);
            }
            else
            {
                effect2 = new CombatEffect(freedomCombatMod, buff.owner, buff.owner, CombatEffect.TargetType.ATTACKER, Combat.EffectType.Neutral);
                buff.owner.combatEffects.Enqueue(effect2);
            }
        }
    }
}

