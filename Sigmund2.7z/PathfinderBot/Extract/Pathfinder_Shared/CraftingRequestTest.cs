﻿using System;

internal class CraftingRequestTest : UUnitTestCase
{
    private CraftingRequest craftingRequest;
    private FeatAdvancementData featAdvData;
    private AchievementFlagData flagData;
    private Entity playerEntity;
    private BaseRecipeData recipeData;

    protected override void SetUp()
    {
        AdvancementDataUnittestHelper.CleanAllData();
        this.flagData = AdvancementDataUnittestHelper.MakeFlag("testFlagPage", 1, "testFlagSlot");
        this.featAdvData = AdvancementDataUnittestHelper.MakeFeatAdvancement("testAdvPage", 1, "testAdvSlot", 100, new int[0], new int[0], new int[0], 0, new int[0], 0f, new int[0], 1f);
        AdvancementDataUnittestHelper.SimulateOnLoadForData();
        this.recipeData = new BaseRecipeData();
        this.recipeData.id = 0x4d2;
        BaseRecipeData.recipeById[this.recipeData.id] = this.recipeData;
        this.recipeData.advFlagId = 0;
        this.recipeData.featAdvancementId = this.featAdvData.id;
        this.recipeData.inputQtys = new uint[0];
        this.recipeData.inputItemIds = new int[0];
        this.recipeData.inputStockIds = new int[0];
        this.craftingRequest = new CraftingRequest();
        EntityCore.UnitTest_Reinitialize(0x8080);
        this.playerEntity = EntityCore.RequestNewEntity();
        this.playerEntity.createType = GConst.CreateType.PLAYER;
        this.playerEntity.playerRecord = new PlayerRecord();
        this.playerEntity.playerRecord.playerId = 12;
        this.playerEntity.advancementVars = new AdvancementVars();
        this.playerEntity.advancementVars.UpdateToStaticData();
        this.playerEntity.gear = new PlayerGear(this.playerEntity.playerRecord);
        this.playerEntity.Initialize();
    }

    protected override void TearDown()
    {
        EntityCore.UnitTest_Reinitialize(0);
        AdvancementDataUnittestHelper.CleanAllData();
        BaseRecipeData.recipeById.Clear();
    }

    [UUnitTestMethod]
    private void ValidateFullRequest()
    {
        int num = 0x15b3;
        UUnitAssert.Equals(CraftingRequest.Why.RECIPE_DNE, this.craftingRequest.Validate(this.playerEntity), "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.False(this.recipeData.Validate() == BaseRecipeData.ValidState.VALID, "Fail");
        this.recipeData.UnittestSetData(num, num, this.featAdvData.id, 10, -1, 1.0);
        this.craftingRequest.SetRecipe(this.recipeData.id);
        UUnitAssert.True(this.recipeData.Validate() == BaseRecipeData.ValidState.VALID, "Fail");
        this.playerEntity.advancementVars.SetFeatLevel(this.featAdvData, 9);
        UUnitAssert.Equals(CraftingRequest.Why.RECIPE_DIFFICULT, this.craftingRequest.Validate(this.playerEntity), "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        this.playerEntity.advancementVars.SetFeatLevel(this.featAdvData, 10);
        UUnitAssert.Equals(CraftingRequest.Why.INPUT_QTY, this.craftingRequest.Validate(this.playerEntity), "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        this.craftingRequest.AddInput(0, new InventoryItem(num, 1, 1, 1));
        UUnitAssert.Equals(CraftingRequest.Why.NOT_IN_INVENTORY, this.craftingRequest.Validate(this.playerEntity), "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        this.playerEntity.playerRecord.AddWithAutoStack(new InventoryItem(num, 1, 1, 1));
        UUnitAssert.Equals(CraftingRequest.Why.VALID, this.craftingRequest.Validate(this.playerEntity), "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        this.recipeData.advFlagId = this.flagData.id;
        UUnitAssert.Equals(CraftingRequest.Why.RECIPE_UNLEARNED, this.craftingRequest.Validate(this.playerEntity), "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        this.playerEntity.advancementVars.SetFlag(this.flagData);
        UUnitAssert.Equals(CraftingRequest.Why.VALID, this.craftingRequest.Validate(this.playerEntity), "Expected equivalent inputs: \"{0}\" != \"{1}\"");
    }

    [UUnitTestMethod]
    private void ValidateGuiRecipeList()
    {
        UUnitAssert.False(this.recipeData.Validate() == BaseRecipeData.ValidState.VALID, "Fail");
        this.recipeData.UnittestSetData(0xd05, 0xd05, this.featAdvData.id, 10, -1, 1.0);
        this.craftingRequest.SetRecipe(this.recipeData.id);
        UUnitAssert.True(this.recipeData.Validate() == BaseRecipeData.ValidState.VALID, "Fail");
        this.playerEntity.advancementVars.SetFeatLevel(this.featAdvData, 9);
        UUnitAssert.Equals(CraftingRequest.Why.RECIPE_DIFFICULT, CraftingRequest.Validate(this.recipeData, this.playerEntity, null), "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        this.playerEntity.advancementVars.SetFeatLevel(this.featAdvData, 10);
        UUnitAssert.Equals(CraftingRequest.Why.VALID, CraftingRequest.Validate(this.recipeData, this.playerEntity, null), "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        this.recipeData.advFlagId = this.flagData.id;
        UUnitAssert.Equals(CraftingRequest.Why.RECIPE_UNLEARNED, CraftingRequest.Validate(this.recipeData, this.playerEntity, null), "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        this.playerEntity.advancementVars.SetFlag(this.flagData);
        UUnitAssert.Equals(CraftingRequest.Why.VALID, CraftingRequest.Validate(this.recipeData, this.playerEntity, null), "Expected equivalent inputs: \"{0}\" != \"{1}\"");
    }
}

