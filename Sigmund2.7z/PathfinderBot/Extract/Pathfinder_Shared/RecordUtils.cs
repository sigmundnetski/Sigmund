﻿using System;

public static class RecordUtils
{
    private static byte[] tempByte = new byte[1];
    private static double[] tempDouble = new double[1];
    private static float[] tempFloat = new float[1];
    private static int[] tempInt = new int[1];
    private static long[] tempLong = new long[1];
    private static short[] tempShort = new short[1];
    private static uint[] tempUInt = new uint[1];
    private static ulong[] tempULong = new ulong[1];
    private static ushort[] tempUShort = new ushort[1];

    public static int ByteArrayHash(byte[] items)
    {
        int num = 0;
        if (items != null)
        {
            num += items.Length;
            for (int i = 0; i < items.Length; i++)
            {
                num += items[i] * GConst.aBunchOfPrimes[i % GConst.aBunchOfPrimes.Length];
            }
        }
        return num;
    }

    public static bool GetBool(byte[] bytes, int shift)
    {
        byte num = bytes[shift / 8];
        return (((num >> (shift % 8)) % 2) == 1);
    }

    public static bool GetBool(int[] ints, int shift)
    {
        int num = ints[shift / 0x20];
        return (((num >> (shift % 0x20)) % 2) == 1);
    }

    public static byte GetByte(byte[] bytes, int shift)
    {
        return bytes[shift];
    }

    public static byte GetByte(int[] ints, int index)
    {
        Buffer.BlockCopy(ints, index * 4, tempByte, 0, 1);
        return tempByte[0];
    }

    public static double GetDouble(byte[] bytes, int shift)
    {
        Buffer.BlockCopy(bytes, shift, tempDouble, 0, 8);
        return tempDouble[0];
    }

    public static double GetDouble(int[] ints, int index)
    {
        Buffer.BlockCopy(ints, index * 4, tempDouble, 0, 8);
        return tempDouble[0];
    }

    public static float GetFloat(byte[] bytes, int shift)
    {
        Buffer.BlockCopy(bytes, shift, tempFloat, 0, 4);
        return tempFloat[0];
    }

    public static float GetFloat(int[] ints, int index)
    {
        Buffer.BlockCopy(ints, index * 4, tempFloat, 0, 4);
        return tempFloat[0];
    }

    public static int GetInt(byte[] bytes, int shift)
    {
        Buffer.BlockCopy(bytes, shift, tempInt, 0, 4);
        return tempInt[0];
    }

    public static int GetInt(int[] ints, int index)
    {
        Buffer.BlockCopy(ints, index * 4, tempInt, 0, 4);
        return tempInt[0];
    }

    public static long GetLong(byte[] bytes, int shift)
    {
        Buffer.BlockCopy(bytes, shift, tempLong, 0, 8);
        return tempLong[0];
    }

    public static long GetLong(int[] ints, int index)
    {
        Buffer.BlockCopy(ints, index * 4, tempLong, 0, 8);
        return tempLong[0];
    }

    public static short GetShort(byte[] bytes, int shift)
    {
        Buffer.BlockCopy(bytes, shift, tempShort, 0, 2);
        return tempShort[0];
    }

    public static short GetShort(int[] ints, int index)
    {
        Buffer.BlockCopy(ints, index * 4, tempShort, 0, 2);
        return tempShort[0];
    }

    public static uint GetUInt(byte[] bytes, int shift)
    {
        Buffer.BlockCopy(bytes, shift, tempUInt, 0, 4);
        return tempUInt[0];
    }

    public static uint GetUInt(int[] ints, int index)
    {
        Buffer.BlockCopy(ints, index * 4, tempUInt, 0, 4);
        return tempUInt[0];
    }

    public static ulong GetULong(byte[] bytes, int shift)
    {
        Buffer.BlockCopy(bytes, shift, tempULong, 0, 8);
        return tempULong[0];
    }

    public static ulong GetULong(int[] ints, int index)
    {
        Buffer.BlockCopy(ints, index * 4, tempULong, 0, 8);
        return tempULong[0];
    }

    public static ushort GetUShort(byte[] bytes, int shift)
    {
        Buffer.BlockCopy(bytes, shift, tempUShort, 0, 2);
        return tempUShort[0];
    }

    public static ushort GetUShort(int[] ints, int index)
    {
        Buffer.BlockCopy(ints, index * 4, tempUShort, 0, 2);
        return tempUShort[0];
    }

    public static int IntArrayHash(int[] items)
    {
        int num = 0;
        if (items != null)
        {
            num += items.Length;
            for (int i = 0; i < items.Length; i++)
            {
                num += items[i] * GConst.aBunchOfPrimes[i % GConst.aBunchOfPrimes.Length];
            }
        }
        return num;
    }

    public static void SetBool(byte[] bytes, bool value, int shift)
    {
        int index = shift / 8;
        shift = shift % 8;
        byte num2 = bytes[index];
        byte num3 = (byte) ~(((int) 1) << shift);
        byte num4 = (byte) (((value != null) ? 1 : 0) << shift);
        bytes[index] = (byte) ((num2 & num3) | num4);
    }

    public static void SetBool(int[] ints, bool value, int shift)
    {
        int index = shift / 0x20;
        shift = shift % 0x20;
        int num2 = ints[index];
        int num3 = ~(((int) 1) << shift);
        int num4 = ((value != null) ? 1 : 0) << shift;
        ints[index] = (num2 & num3) | num4;
    }

    public static void SetByte(byte[] bytes, byte value, int shift)
    {
        bytes[shift] = value;
    }

    public static void SetByte(int[] ints, byte value, int index)
    {
        tempByte[0] = value;
        Buffer.BlockCopy(tempByte, 0, ints, index * 4, 1);
    }

    public static void SetDouble(byte[] bytes, double value, int shift)
    {
        tempDouble[0] = value;
        Buffer.BlockCopy(tempDouble, 0, bytes, shift, 8);
    }

    public static void SetDouble(int[] ints, double value, int index)
    {
        tempDouble[0] = value;
        Buffer.BlockCopy(tempDouble, 0, ints, index * 4, 8);
    }

    public static void SetFloat(byte[] bytes, float value, int shift)
    {
        tempFloat[0] = value;
        Buffer.BlockCopy(tempFloat, 0, bytes, shift, 4);
    }

    public static void SetFloat(int[] ints, float value, int index)
    {
        tempFloat[0] = value;
        Buffer.BlockCopy(tempFloat, 0, ints, index * 4, 4);
    }

    public static void SetInt(byte[] bytes, int value, int shift)
    {
        tempInt[0] = value;
        Buffer.BlockCopy(tempInt, 0, bytes, shift, 4);
    }

    public static void SetInt(int[] ints, int value, int index)
    {
        tempInt[0] = value;
        Buffer.BlockCopy(tempInt, 0, ints, index * 4, 4);
    }

    public static void SetLong(byte[] bytes, long value, int shift)
    {
        tempLong[0] = value;
        Buffer.BlockCopy(tempLong, 0, bytes, shift, 8);
    }

    public static void SetLong(int[] ints, long value, int index)
    {
        tempLong[0] = value;
        Buffer.BlockCopy(tempLong, 0, ints, index * 4, 8);
    }

    public static void SetShort(byte[] bytes, short value, int shift)
    {
        tempShort[0] = value;
        Buffer.BlockCopy(tempShort, 0, bytes, shift, 2);
    }

    public static void SetShort(int[] ints, short value, int index)
    {
        tempShort[0] = value;
        Buffer.BlockCopy(tempShort, 0, ints, index * 4, 2);
    }

    public static void SetUInt(byte[] bytes, uint value, int shift)
    {
        tempUInt[0] = value;
        Buffer.BlockCopy(tempUInt, 0, bytes, shift, 4);
    }

    public static void SetUInt(int[] ints, uint value, int index)
    {
        tempUInt[0] = value;
        Buffer.BlockCopy(tempUInt, 0, ints, index * 4, 4);
    }

    public static void SetULong(byte[] bytes, ulong value, int shift)
    {
        tempULong[0] = value;
        Buffer.BlockCopy(tempULong, 0, bytes, shift, 8);
    }

    public static void SetULong(int[] ints, ulong value, int index)
    {
        tempULong[0] = value;
        Buffer.BlockCopy(tempULong, 0, ints, index * 4, 8);
    }

    public static void SetUShort(byte[] bytes, ushort value, int shift)
    {
        tempUShort[0] = value;
        Buffer.BlockCopy(tempUShort, 0, bytes, shift, 2);
    }

    public static void SetUShort(int[] ints, ushort value, int index)
    {
        tempUShort[0] = value;
        Buffer.BlockCopy(tempUShort, 0, ints, index * 4, 2);
    }
}

