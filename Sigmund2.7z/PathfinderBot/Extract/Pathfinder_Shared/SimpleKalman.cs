﻿using System;
using System.Runtime.InteropServices;

public class SimpleKalman
{
    private double Pk;
    private double R;
    private double Xk;
    private double Zk;

    public SimpleKalman(double setR = 0.1)
    {
        this.Xk = double.MinValue;
        this.Pk = 1.0;
        this.R = setR;
    }

    public SimpleKalman(double expectedEstimate, double setR = 0.1)
    {
        this.Xk = double.MinValue;
        this.Pk = 1.0;
        this.Xk = expectedEstimate;
        this.R = setR;
    }

    public void Next(double newValue)
    {
        if (this.Xk == double.MinValue)
        {
            this.Xk = newValue;
        }
        this.Zk = newValue;
        double num = this.Pk / (this.Pk + this.R);
        this.Xk += num * (this.Zk - this.Xk);
        this.Pk = (1.0 - num) * this.Pk;
    }

    public double Predict()
    {
        return this.Xk;
    }

    public void Reset(double setR = 0.1)
    {
        this.Zk = 0.0;
        this.Xk = double.MinValue;
        this.Pk = 0.0;
        this.R = setR;
    }
}

