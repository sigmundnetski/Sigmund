﻿using System;
using System.Collections.Generic;
using System.Linq;

internal class SparseArrayTest : UUnitTestCase
{
    private SATestStruct INVALID_STRUCT = new SATestStruct(0);

    [UUnitTestMethod]
    public void OrderedAdd()
    {
        int[] numArray2 = new int[4];
        numArray2[3] = 5;
        int[] values = numArray2;
        int num = 1;
        SparseArray.OrderedAdd<int>(ref values, 6, SparseArray.INVALID_ID, 0);
        UUnitAssert.Equals(++num, SparseArray.Count<int>(values, SparseArray.INVALID_ID), "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.SequenceEqual<int>(new int[] { 5, 6 }, SparseArray.Iterate<int>(values, SparseArray.INVALID_ID), "Expected equivalent lists:\n{0}\n!=\n{1}");
        SparseArray.OrderedAdd<int>(ref values, 7, SparseArray.INVALID_ID, 0);
        UUnitAssert.Equals(++num, SparseArray.Count<int>(values, SparseArray.INVALID_ID), "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.SequenceEqual<int>(new int[] { 5, 6, 7 }, SparseArray.Iterate<int>(values, SparseArray.INVALID_ID), "Expected equivalent lists:\n{0}\n!=\n{1}");
        SparseArray.OrderedAdd<int>(ref values, 8, SparseArray.INVALID_ID, 0);
        UUnitAssert.Equals(++num, SparseArray.Count<int>(values, SparseArray.INVALID_ID), "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.SequenceEqual<int>(new int[] { 5, 6, 7, 8 }, SparseArray.Iterate<int>(values, SparseArray.INVALID_ID), "Expected equivalent lists:\n{0}\n!=\n{1}");
        SparseArray.OrderedAdd<int>(ref values, 9, SparseArray.INVALID_ID, 0);
        UUnitAssert.Equals(++num, SparseArray.Count<int>(values, SparseArray.INVALID_ID), "Expected equivalent inputs: \"{0}\" != \"{1}\"");
        UUnitAssert.SequenceEqual<int>(new int[] { 5, 6, 7, 8, 9 }, SparseArray.Iterate<int>(values, SparseArray.INVALID_ID), "Expected equivalent lists:\n{0}\n!=\n{1}");
    }

    [UUnitTestMethod]
    public void TestAddClass()
    {
        SATestClass[] values = new SATestClass[3];
        UUnitAssert.True(SparseArray.Count<SATestClass>(values) == 0, string.Concat(new object[] { "Empty array should have count of ", 0, ". Got ", SparseArray.Count<SATestClass>(values) }));
        uint probableIndex = 0;
        probableIndex = SparseArray.Add<SATestClass>(ref values, new SATestClass(1), probableIndex);
        probableIndex = SparseArray.Add<SATestClass>(ref values, new SATestClass(2), probableIndex);
        probableIndex = SparseArray.Add<SATestClass>(ref values, new SATestClass(3), probableIndex);
        UUnitAssert.True(SparseArray.Count<SATestClass>(values) == 3, string.Concat(new object[] { "Array should have count of ", 3, ". Got ", SparseArray.Count<SATestClass>(values) }));
        int[] numArray = new int[] { 1, 2, 3 };
        int index = 0;
        foreach (SATestClass class2 in values)
        {
            UUnitAssert.True(class2 != null, "Nothing should be null.");
            UUnitAssert.True(class2.value == numArray[index], string.Concat(new object[] { "foreach failed on element #", index, ". Expected ", numArray[index], " got ", class2.value }));
            index++;
        }
        UUnitAssert.True(values.Length == 3, string.Concat(new object[] { "Array should be ", 3, " length. Got ", values.Length }));
        probableIndex = SparseArray.Add<SATestClass>(ref values, new SATestClass(4), probableIndex);
        UUnitAssert.True(values.Length == 6, string.Concat(new object[] { "Array should be ", 6, " length. Got ", values.Length }));
        probableIndex = SparseArray.Add<SATestClass>(ref values, new SATestClass(5), probableIndex);
        probableIndex = SparseArray.Add<SATestClass>(ref values, new SATestClass(6), probableIndex);
        values[2] = null;
        UUnitAssert.True(SparseArray.Count<SATestClass>(values) == 5, string.Concat(new object[] { "Array should have count of ", 5, ". Got ", SparseArray.Count<SATestClass>(values) }));
        probableIndex = SparseArray.Add<SATestClass>(ref values, new SATestClass(0x2a), probableIndex);
        UUnitAssert.True(values.Length == 6, string.Concat(new object[] { "Array should be ", 6, " length. Got ", values.Length }));
        numArray = new int[] { 1, 2, 0x2a, 4, 5, 6 };
        index = 0;
        foreach (SATestClass class2 in values)
        {
            UUnitAssert.True(class2 != null, "Nothing should be null.");
            UUnitAssert.True(class2.value == numArray[index], string.Concat(new object[] { "foreach failed on element #", index, ". Expected ", numArray[index], " got ", class2.value }));
            index++;
        }
    }

    [UUnitTestMethod]
    public void TestAddInt()
    {
        int[] values = new int[3];
        int INVALID = 0;
        int num = SparseArray.Count<int>(values, aa => aa == 0);
        UUnitAssert.True(num == 0, string.Concat(new object[] { "Empty array should have count of ", 0, ". Got ", num }));
        uint probableIndex = 0;
        probableIndex = SparseArray.Add<int>(ref values, 1, probableIndex, a => a == INVALID, INVALID);
        probableIndex = SparseArray.Add<int>(ref values, 2, probableIndex, b => b == INVALID, INVALID);
        probableIndex = SparseArray.Add<int>(ref values, 3, probableIndex, c => c == INVALID, INVALID);
        num = SparseArray.Count<int>(values, d => d == INVALID);
        UUnitAssert.True(num == 3, string.Concat(new object[] { "Array should have count of ", 3, ". Got ", num }));
        int[] numArray2 = new int[] { 1, 2, 3 };
        int index = 0;
        foreach (int num4 in values)
        {
            UUnitAssert.True(num4 == numArray2[index], string.Concat(new object[] { "foreach failed on element #", index, ". Expected ", numArray2[index], " got ", num4 }));
            index++;
        }
        UUnitAssert.True(values.Length == 3, string.Concat(new object[] { "Array should be ", 3, " length. Got ", values.Length }));
        probableIndex = SparseArray.Add<int>(ref values, 4, probableIndex, e => e == INVALID, INVALID);
        UUnitAssert.True(values.Length == 6, string.Concat(new object[] { "Array should be ", 6, " length. Got ", values.Length }));
        probableIndex = SparseArray.Add<int>(ref values, 5, probableIndex, e => e == INVALID, INVALID);
        probableIndex = SparseArray.Add<int>(ref values, 6, probableIndex, e => e == INVALID, INVALID);
        values[2] = INVALID;
        num = SparseArray.Count<int>(values, f => f == INVALID);
        UUnitAssert.True(num == 5, string.Concat(new object[] { "Array should have count of ", 5, ". Got ", num }));
        probableIndex = SparseArray.Add<int>(ref values, 0x2a, probableIndex, g => g == INVALID, INVALID);
        UUnitAssert.True(values.Length == 6, string.Concat(new object[] { "Array should be ", 6, " length. Got ", values.Length }));
        numArray2 = new int[] { 1, 2, 0x2a, 4, 5, 6 };
        index = 0;
        foreach (int num4 in values)
        {
            UUnitAssert.True(num4 == numArray2[index], string.Concat(new object[] { "foreach failed on element #", index, ". Expected ", numArray2[index], " got ", num4 }));
            index++;
        }
    }

    [UUnitTestMethod]
    public void TestAddStruct()
    {
        SATestStruct[] values = new SATestStruct[3];
        int num = SparseArray.Count<SATestStruct>(values, aa => aa.value == 0);
        UUnitAssert.True(num == 0, string.Concat(new object[] { "Empty array should have count of ", 0, ". Got ", num }));
        uint probableIndex = 0;
        probableIndex = SparseArray.Add<SATestStruct>(ref values, new SATestStruct(1), probableIndex, a => a.value == 0, this.INVALID_STRUCT);
        probableIndex = SparseArray.Add<SATestStruct>(ref values, new SATestStruct(2), probableIndex, b => b.value == 0, this.INVALID_STRUCT);
        probableIndex = SparseArray.Add<SATestStruct>(ref values, new SATestStruct(3), probableIndex, c => c.value == 0, this.INVALID_STRUCT);
        num = SparseArray.Count<SATestStruct>(values, d => d.value == 0);
        UUnitAssert.True(num == 3, string.Concat(new object[] { "Array should have count of ", 3, ". Got ", num }));
        int[] numArray = new int[] { 1, 2, 3 };
        int index = 0;
        foreach (SATestStruct struct2 in values)
        {
            UUnitAssert.True(struct2.value == numArray[index], string.Concat(new object[] { "foreach failed on element #", index, ". Expected ", numArray[index], " got ", struct2.value }));
            index++;
        }
        UUnitAssert.True(values.Length == 3, string.Concat(new object[] { "Array should be ", 3, " length. Got ", values.Length }));
        probableIndex = SparseArray.Add<SATestStruct>(ref values, new SATestStruct(4), probableIndex, e => e.value == 0, this.INVALID_STRUCT);
        UUnitAssert.True(values.Length == 6, string.Concat(new object[] { "Array should be ", 6, " length. Got ", values.Length }));
        probableIndex = SparseArray.Add<SATestStruct>(ref values, new SATestStruct(5), probableIndex, e => e.value == 0, this.INVALID_STRUCT);
        probableIndex = SparseArray.Add<SATestStruct>(ref values, new SATestStruct(6), probableIndex, e => e.value == 0, this.INVALID_STRUCT);
        values[2] = new SATestStruct(0);
        num = SparseArray.Count<SATestStruct>(values, f => f.value == 0);
        UUnitAssert.True(num == 5, string.Concat(new object[] { "Array should have count of ", 5, ". Got ", num }));
        probableIndex = SparseArray.Add<SATestStruct>(ref values, new SATestStruct(0x2a), probableIndex, g => g.value == 0, this.INVALID_STRUCT);
        UUnitAssert.True(values.Length == 6, string.Concat(new object[] { "Array should be ", 6, " length. Got ", values.Length }));
        numArray = new int[] { 1, 2, 0x2a, 4, 5, 6 };
        index = 0;
        foreach (SATestStruct struct2 in values)
        {
            UUnitAssert.True(struct2.value == numArray[index], string.Concat(new object[] { "foreach failed on element #", index, ". Expected ", numArray[index], " got ", struct2.value }));
            index++;
        }
    }

    [UUnitTestMethod]
    public void TestClearInt()
    {
        int[] values = new int[3];
        int INVALID = 0;
        int num = SparseArray.Count<int>(values, aa => aa == INVALID);
        uint probableIndex = 0;
        probableIndex = SparseArray.Add<int>(ref values, 1, probableIndex, a => a == INVALID, INVALID);
        probableIndex = SparseArray.Add<int>(ref values, 2, probableIndex, b => b == INVALID, INVALID);
        probableIndex = SparseArray.Add<int>(ref values, 3, probableIndex, c => c == INVALID, INVALID);
        num = SparseArray.Count<int>(values, d => d == INVALID);
        UUnitAssert.True(num == 3, string.Concat(new object[] { "Array should have count of ", 3, ". Got ", num }));
        SparseArray.Clear<int>(ref values, INVALID);
        probableIndex = 0;
        num = SparseArray.Count<int>(values, d => d == INVALID);
        UUnitAssert.True(num == 0, string.Concat(new object[] { "Array should have count of ", 0, ". Got ", num }));
    }

    [UUnitTestMethod]
    public void TestClearStruct()
    {
        SATestStruct[] values = new SATestStruct[3];
        int num = SparseArray.Count<SATestStruct>(values, aa => aa.value == 0);
        uint probableIndex = 0;
        probableIndex = SparseArray.Add<SATestStruct>(ref values, new SATestStruct(1), probableIndex, a => a.value == 0, this.INVALID_STRUCT);
        probableIndex = SparseArray.Add<SATestStruct>(ref values, new SATestStruct(2), probableIndex, b => b.value == 0, this.INVALID_STRUCT);
        probableIndex = SparseArray.Add<SATestStruct>(ref values, new SATestStruct(3), probableIndex, c => c.value == 0, this.INVALID_STRUCT);
        num = SparseArray.Count<SATestStruct>(values, d => d.value == 0);
        UUnitAssert.True(num == 3, string.Concat(new object[] { "Array should have count of ", 3, ". Got ", num }));
        SparseArray.Clear<SATestStruct>(ref values, new SATestStruct(0));
        probableIndex = 0;
        num = SparseArray.Count<SATestStruct>(values, d => d.value == 0);
        UUnitAssert.True(num == 0, string.Concat(new object[] { "Array should have count of ", 0, ". Got ", num }));
    }

    [UUnitTestMethod]
    public void TestDeepCopyClass()
    {
        SATestClass[] values = new SATestClass[3];
        uint probableIndex = 0;
        probableIndex = SparseArray.Add<SATestClass>(ref values, new SATestClass(1), probableIndex);
        probableIndex = SparseArray.Add<SATestClass>(ref values, new SATestClass(2), probableIndex);
        SATestClass[] target = new SATestClass[values.Length];
        SparseArray.DeepCopyTo<SATestClass>(values, ref target, 0xff, null);
        UUnitAssert.True(values.Length == target.Length, "Fail");
        UUnitAssert.True(SparseArray.DeepEqualsIgnoreIndex<SATestClass>(values, target, 0xff), "Fail");
        values[1].value = 0x2a;
        UUnitAssert.True(values.Length == target.Length, "Fail");
        UUnitAssert.False(SparseArray.DeepEqualsIgnoreIndex<SATestClass>(values, target, 0xff), "Fail");
    }

    [UUnitTestMethod]
    public void TestDeepEqualsIgnoreIndexClass()
    {
        SATestClass[] classArray5 = new SATestClass[11];
        classArray5[1] = new SATestClass(1);
        classArray5[3] = new SATestClass(2);
        classArray5[5] = new SATestClass(3);
        classArray5[7] = new SATestClass(4);
        classArray5[9] = new SATestClass(5);
        SATestClass[] source = classArray5;
        classArray5 = new SATestClass[14];
        classArray5[5] = new SATestClass(1);
        classArray5[6] = new SATestClass(2);
        classArray5[7] = new SATestClass(3);
        classArray5[8] = new SATestClass(4);
        classArray5[9] = new SATestClass(5);
        SATestClass[] target = classArray5;
        SATestClass[] classArray3 = new SATestClass[] { new SATestClass(1), new SATestClass(2), new SATestClass(3), new SATestClass(4), new SATestClass(5) };
        SATestClass[] classArray4 = new SATestClass[] { new SATestClass(5), new SATestClass(4), new SATestClass(3), new SATestClass(2), new SATestClass(1) };
        UUnitAssert.True(SparseArray.DeepEqualsIgnoreIndex<SATestClass>(source, target, 0xff), "Fail");
        UUnitAssert.True(SparseArray.DeepEqualsIgnoreIndex<SATestClass>(source, classArray3, 0xff), "Fail");
        UUnitAssert.True(SparseArray.DeepEqualsIgnoreIndex<SATestClass>(target, classArray3, 0xff), "Fail");
        UUnitAssert.False(SparseArray.DeepEqualsIgnoreIndex<SATestClass>(source, classArray4, 0xff), "Fail");
        UUnitAssert.False(SparseArray.DeepEqualsIgnoreIndex<SATestClass>(target, classArray4, 0xff), "Fail");
        UUnitAssert.False(SparseArray.DeepEqualsIgnoreIndex<SATestClass>(classArray3, classArray4, 0xff), "Fail");
    }

    [UUnitTestMethod]
    public void TestDeepEqualsIgnoreIndexStruct()
    {
        Predicate<SATestStruct> emptyMatch = a => a.value == 0;
        SATestStruct struct2 = new SATestStruct(1);
        SATestStruct struct3 = new SATestStruct(2);
        SATestStruct struct4 = new SATestStruct(3);
        SATestStruct struct5 = new SATestStruct(4);
        SATestStruct struct6 = new SATestStruct(5);
        SATestStruct[] structArray5 = new SATestStruct[] { this.INVALID_STRUCT, struct2, this.INVALID_STRUCT, struct3, this.INVALID_STRUCT, struct4, this.INVALID_STRUCT, struct5, this.INVALID_STRUCT, struct6, this.INVALID_STRUCT };
        SATestStruct[] source = structArray5;
        structArray5 = new SATestStruct[] { this.INVALID_STRUCT, this.INVALID_STRUCT, this.INVALID_STRUCT, this.INVALID_STRUCT, this.INVALID_STRUCT, struct2, struct3, struct4, struct5, struct6, this.INVALID_STRUCT, this.INVALID_STRUCT, this.INVALID_STRUCT, this.INVALID_STRUCT };
        SATestStruct[] target = structArray5;
        structArray5 = new SATestStruct[] { struct2, struct3, struct4, struct5, struct6 };
        SATestStruct[] structArray3 = structArray5;
        structArray5 = new SATestStruct[] { struct6, struct5, struct4, struct3, struct2 };
        SATestStruct[] structArray4 = structArray5;
        UUnitAssert.True(SparseArray.DeepEqualsIgnoreIndex<SATestStruct>(source, target, 0xff, emptyMatch), "Fail");
        UUnitAssert.True(SparseArray.DeepEqualsIgnoreIndex<SATestStruct>(source, structArray3, 0xff, emptyMatch), "Fail");
        UUnitAssert.True(SparseArray.DeepEqualsIgnoreIndex<SATestStruct>(target, structArray3, 0xff, emptyMatch), "Fail");
        UUnitAssert.False(SparseArray.DeepEqualsIgnoreIndex<SATestStruct>(source, structArray4, 0xff, emptyMatch), "Fail");
        UUnitAssert.False(SparseArray.DeepEqualsIgnoreIndex<SATestStruct>(target, structArray4, 0xff, emptyMatch), "Fail");
        UUnitAssert.False(SparseArray.DeepEqualsIgnoreIndex<SATestStruct>(structArray3, structArray4, 0xff, emptyMatch), "Fail");
    }

    [UUnitTestMethod]
    public void TestExpandArrayDouble()
    {
        int[] values = new int[] { -1 };
        int num = SparseArray.Count<int>(values, aa => aa == -1);
        UUnitAssert.True(num == 0, string.Concat(new object[] { "Empty array should have count of ", 0, ". Got ", num }));
        SparseArray.Add<int>(ref values, 1, a => a == -1, -1);
        SparseArray.Add<int>(ref values, 2, b => b == -1, -1);
        UUnitAssert.True(values.Length == 2, "Array should have resized.");
        num = SparseArray.Count<int>(values, d => d == -1);
        UUnitAssert.True(num == 2, string.Concat(new object[] { "Array should have count of ", 2, ". Got ", num }));
    }

    [UUnitTestMethod]
    public void TestExpandArrayWithIndex()
    {
        int[] values = new int[] { -1 };
        int num = SparseArray.Count<int>(values, aa => aa == -1);
        UUnitAssert.True(num == 0, string.Concat(new object[] { "Empty array should have count of ", 0, ". Got ", num }));
        uint probableIndex = 0;
        probableIndex = SparseArray.Add<int>(ref values, 1, probableIndex, a => a == -1, -1);
        probableIndex = SparseArray.Add<int>(ref values, 2, probableIndex, b => b == -1, -1);
        UUnitAssert.True(values.Length == 2, "Array should have resized.");
        num = SparseArray.Count<int>(values, d => d == -1);
        UUnitAssert.True(num == 2, string.Concat(new object[] { "Array should have count of ", 2, ". Got ", num }));
    }

    [UUnitTestMethod]
    public void TestExtendClass()
    {
        SATestClass[] classArray3 = new SATestClass[11];
        classArray3[1] = new SATestClass(1);
        classArray3[3] = new SATestClass(2);
        classArray3[5] = new SATestClass(3);
        classArray3[7] = new SATestClass(4);
        classArray3[9] = new SATestClass(5);
        SATestClass[] values = classArray3;
        List<SATestClass> newItems = new List<SATestClass> {
            new SATestClass(6),
            new SATestClass(7),
            new SATestClass(8),
            new SATestClass(9),
            new SATestClass(10)
        };
        classArray3 = new SATestClass[11];
        classArray3[0] = new SATestClass(6);
        classArray3[1] = new SATestClass(1);
        classArray3[2] = new SATestClass(7);
        classArray3[3] = new SATestClass(2);
        classArray3[4] = new SATestClass(8);
        classArray3[5] = new SATestClass(3);
        classArray3[6] = new SATestClass(9);
        classArray3[7] = new SATestClass(4);
        classArray3[8] = new SATestClass(10);
        classArray3[9] = new SATestClass(5);
        SATestClass[] target = classArray3;
        SparseArray.Extend<SATestClass>(ref values, newItems);
        UUnitAssert.True(SparseArray.DeepEqualsIgnoreIndex<SATestClass>(values, target, 0xff), "Fail");
    }

    [UUnitTestMethod]
    public void TestFindClass()
    {
        SATestClass[] values = new SATestClass[10];
        SATestClass class2 = new SATestClass(3);
        SATestClass class3 = new SATestClass(0x2a);
        uint probableIndex = 0;
        probableIndex = SparseArray.Add<SATestClass>(ref values, new SATestClass(1), probableIndex) + 3;
        probableIndex = SparseArray.Add<SATestClass>(ref values, new SATestClass(2), probableIndex);
        probableIndex = SparseArray.Add<SATestClass>(ref values, class2, probableIndex);
        probableIndex = SparseArray.Add<SATestClass>(ref values, new SATestClass(4), probableIndex);
        SATestClass target = SparseArray.Find<SATestClass>(values, i => i.value == 3);
        UUnitAssert.True(class2.DataEquals(target, 0xff), "Fail");
        SATestClass class5 = SparseArray.Find<SATestClass>(values, i => i.value == 0x2a);
        UUnitAssert.False(class3.DataEquals(class5, 0xff), "Fail");
    }

    [UUnitTestMethod]
    public void TestFindInt()
    {
        int[] values = new int[10];
        int INVALID = 0;
        int num = 3;
        int num2 = 0x2a;
        int notFound = INVALID;
        Predicate<int> emptyMatch = a => a == INVALID;
        uint probableIndex = 0;
        probableIndex = SparseArray.Add<int>(ref values, 1, probableIndex, emptyMatch, INVALID) + 3;
        probableIndex = SparseArray.Add<int>(ref values, 2, probableIndex, emptyMatch, INVALID);
        probableIndex = SparseArray.Add<int>(ref values, num, probableIndex, emptyMatch, INVALID);
        probableIndex = SparseArray.Add<int>(ref values, 4, probableIndex, emptyMatch, INVALID);
        int num5 = SparseArray.Find<int>(values, i => i == 3, emptyMatch, notFound);
        UUnitAssert.True(num.Equals(num5), "Fail");
        int num6 = SparseArray.Find<int>(values, i => i == 0x2a, emptyMatch, notFound);
        UUnitAssert.False(num2.Equals(num6), "Fail");
        UUnitAssert.True(notFound.Equals(num6), "Fail");
    }

    [UUnitTestMethod]
    public void TestFindStruct()
    {
        SATestStruct[] values = new SATestStruct[10];
        SATestStruct struct2 = new SATestStruct(3);
        SATestStruct struct3 = new SATestStruct(0x2a);
        SATestStruct notFound = new SATestStruct(0);
        Predicate<SATestStruct> emptyMatch = a => a.value == 0;
        uint probableIndex = 0;
        probableIndex = SparseArray.Add<SATestStruct>(ref values, new SATestStruct(1), probableIndex, emptyMatch, this.INVALID_STRUCT) + 3;
        probableIndex = SparseArray.Add<SATestStruct>(ref values, new SATestStruct(2), probableIndex, emptyMatch, this.INVALID_STRUCT);
        probableIndex = SparseArray.Add<SATestStruct>(ref values, struct2, probableIndex, emptyMatch, this.INVALID_STRUCT);
        probableIndex = SparseArray.Add<SATestStruct>(ref values, new SATestStruct(4), probableIndex, emptyMatch, this.INVALID_STRUCT);
        SATestStruct struct5 = SparseArray.Find<SATestStruct>(values, i => i.value == 3, emptyMatch, notFound);
        UUnitAssert.True(struct2.Equals(struct5), "Fail");
        SATestStruct struct6 = SparseArray.Find<SATestStruct>(values, i => i.value == 0x2a, emptyMatch, notFound);
        UUnitAssert.False(struct3.Equals(struct6), "Fail");
        UUnitAssert.True(notFound.Equals(struct6), "Fail");
    }

    [UUnitTestMethod]
    public void TestIterateClass()
    {
        Predicate<SATestClass> emptyMatch = a => a == null;
        SATestClass[] first = new SATestClass[] { new SATestClass(1), new SATestClass(2), new SATestClass(3), new SATestClass(4), new SATestClass(5) };
        SATestClass[] classArray2 = new SATestClass[] { new SATestClass(5), new SATestClass(4), new SATestClass(3), new SATestClass(2), new SATestClass(1) };
        SATestClass[] classArray5 = new SATestClass[11];
        classArray5[1] = new SATestClass(1);
        classArray5[3] = new SATestClass(2);
        classArray5[5] = new SATestClass(3);
        classArray5[7] = new SATestClass(4);
        classArray5[9] = new SATestClass(5);
        SATestClass[] values = classArray5;
        classArray5 = new SATestClass[14];
        classArray5[5] = new SATestClass(5);
        classArray5[6] = new SATestClass(4);
        classArray5[7] = new SATestClass(3);
        classArray5[8] = new SATestClass(2);
        classArray5[9] = new SATestClass(1);
        SATestClass[] classArray4 = classArray5;
        UUnitAssert.True(first.SequenceEqual<SATestClass>(SparseArray.Iterate<SATestClass>(values, emptyMatch)), "Fail");
        UUnitAssert.False(first.SequenceEqual<SATestClass>(SparseArray.Iterate<SATestClass>(classArray4, emptyMatch)), "Fail");
        UUnitAssert.False(classArray2.SequenceEqual<SATestClass>(SparseArray.Iterate<SATestClass>(values, emptyMatch)), "Fail");
        UUnitAssert.True(classArray2.SequenceEqual<SATestClass>(SparseArray.Iterate<SATestClass>(classArray4, emptyMatch)), "Fail");
    }

    [UUnitTestMethod]
    public void TestIterateInt()
    {
        int INVALID = 0;
        Predicate<int> emptyMatch = a => a == INVALID;
        int[] first = new int[] { 1, 2, 3, 4, 5 };
        int[] numArray2 = new int[] { 5, 4, 3, 2, 1 };
        int[] numArray5 = new int[] { 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0 };
        numArray5[0] = INVALID;
        numArray5[2] = INVALID;
        numArray5[4] = INVALID;
        numArray5[6] = INVALID;
        numArray5[8] = INVALID;
        numArray5[10] = INVALID;
        int[] values = numArray5;
        numArray5 = new int[] { 0, 0, 0, 0, 0, 5, 4, 3, 2, 1, 0, 0, 0, 0 };
        numArray5[0] = INVALID;
        numArray5[1] = INVALID;
        numArray5[2] = INVALID;
        numArray5[3] = INVALID;
        numArray5[4] = INVALID;
        numArray5[10] = INVALID;
        numArray5[11] = INVALID;
        numArray5[12] = INVALID;
        numArray5[13] = INVALID;
        int[] numArray4 = numArray5;
        UUnitAssert.True(first.SequenceEqual<int>(SparseArray.Iterate<int>(values, emptyMatch)), "Fail");
        UUnitAssert.False(first.SequenceEqual<int>(SparseArray.Iterate<int>(numArray4, emptyMatch)), "Fail");
        UUnitAssert.False(numArray2.SequenceEqual<int>(SparseArray.Iterate<int>(values, emptyMatch)), "Fail");
        UUnitAssert.True(numArray2.SequenceEqual<int>(SparseArray.Iterate<int>(numArray4, emptyMatch)), "Fail");
    }
}

