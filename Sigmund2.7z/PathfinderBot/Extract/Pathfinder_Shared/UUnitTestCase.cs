﻿using System;
using System.Reflection;

public class UUnitTestCase
{
    public const ushort TEST_MAP_ID = 0x8080;
    private string testMethodName;

    public UUnitTestCase()
    {
    }

    public UUnitTestCase(string testMethodName)
    {
        this.testMethodName = testMethodName;
    }

    protected static void LoadRealStaticData()
    {
        ItemDatabase.UnittestTearDown();
        StaticDataService.SyncStart(false);
        StaticDataService.SyncFixedUpdate();
    }

    public void Run(ref UUnitTestResult testResult)
    {
        Exception exception;
        MethodInfo method = base.GetType().GetMethod(this.testMethodName, BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance);
        try
        {
            testResult.SetupStarted(method.DeclaringType.Name);
            this.SetUp();
            testResult.SetupCompleted();
        }
        catch (Exception exception1)
        {
            exception = exception1;
            testResult.TestFailed(string.Concat(new object[] { "\n(Setup - Exception:) ", exception, "\n(Stack:) ", exception.StackTrace }));
            return;
        }
        try
        {
            bool trackMemory = false;
            foreach (Attribute attribute in method.GetCustomAttributes(false))
            {
                if (((attribute != null) && (attribute.GetType() == typeof(UUnitProfileMethod))) && ((UBaseAttribute) attribute).active)
                {
                    trackMemory = true;
                }
            }
            testResult.TestStarted(this.FullName, this.testMethodName, trackMemory);
            method.Invoke(this, null);
            testResult.TestCompleted();
        }
        catch (TargetInvocationException exception2)
        {
            if (exception2.InnerException is UUnitAssertException)
            {
                testResult.TestFailed("\n(Fail Message:) " + ((UUnitAssertException) exception2.InnerException).message + "\n(Stack:) " + exception2.InnerException.StackTrace);
            }
            else
            {
                testResult.TestFailed("\n(Inner Exception:) " + exception2.InnerException);
            }
        }
        catch (Exception exception4)
        {
            exception = exception4;
            testResult.TestFailed(string.Concat(new object[] { "\n(Exception:) ", exception, "\n(Stack:) ", exception.StackTrace }));
        }
        finally
        {
            try
            {
                testResult.TeardownStarted(method.DeclaringType.Name);
                this.TearDown();
                testResult.TeardownCompleted();
            }
            catch (Exception exception5)
            {
                exception = exception5;
                testResult.TestFailed(string.Concat(new object[] { "\n(TearDown - Exception:) ", exception, "\n(Stack:) ", exception.StackTrace }));
            }
        }
    }

    public void SetTest(string testMethodName)
    {
        this.testMethodName = testMethodName;
    }

    protected virtual void SetUp()
    {
    }

    protected virtual void TearDown()
    {
    }

    public string FullName
    {
        get
        {
            MethodInfo method = base.GetType().GetMethod(this.testMethodName, BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance);
            if (method.DeclaringType != null)
            {
                return (method.DeclaringType.Name + "::" + this.testMethodName);
            }
            return ("::" + this.testMethodName);
        }
    }
}

