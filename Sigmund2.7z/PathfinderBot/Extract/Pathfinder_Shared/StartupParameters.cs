﻿using System;
using System.Collections.Generic;
using System.Diagnostics;

public static class StartupParameters
{
    private static Dictionary<string, MethodBase> callingMethods = new Dictionary<string, MethodBase>();
    private static Dictionary<string, string> inputParameters = new Dictionary<string, string>();

    static StartupParameters()
    {
        inputParameters = ParseParameters(Environment.GetCommandLineArgs());
    }

    public static Dictionary<string, string> ParseParameters(string[] args)
    {
        Dictionary<string, string> dictionary = new Dictionary<string, string>();
        string key = string.Empty;
        for (int i = 1; i < args.Length; i++)
        {
            bool flag = false;
            string s = args[i];
            if (s.StartsWith("--") || s.StartsWith("//"))
            {
                s = s.Substring(1);
            }
            else
            {
                int num2;
                flag = (s.StartsWith("-") || s.StartsWith("/")) && !int.TryParse(s, out num2);
            }
            if (flag)
            {
                key = s.Substring(1).ToLower();
                if (!dictionary.ContainsKey(key))
                {
                    dictionary[key] = string.Empty;
                }
            }
            else if (dictionary.ContainsKey(key))
            {
                if (dictionary[key] == string.Empty)
                {
                    dictionary[key] = s;
                }
                else
                {
                    dictionary[key] = dictionary[key] + " " + s;
                }
            }
        }
        return dictionary;
    }

    public static string RemoveParameterToProcess(string key)
    {
        string str = key.ToLower();
        if (callingMethods.ContainsKey(str))
        {
            throw new InvalidOperationException(string.Concat(new object[] { "The argument [", key, "] has already been processed by: ", callingMethods[str].DeclaringType, ".", callingMethods[str].Name }));
        }
        if (inputParameters.ContainsKey(str))
        {
            StackTrace trace = new StackTrace();
            callingMethods.Add(str, trace.GetFrame(1).GetMethod());
            string str2 = inputParameters[str];
            inputParameters.Remove(str);
            return str2;
        }
        return null;
    }
}

