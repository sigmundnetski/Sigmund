﻿using System;

public class BundleFailureException : Exception
{
    public BundleFailureException(string msg) : base(msg)
    {
    }
}

