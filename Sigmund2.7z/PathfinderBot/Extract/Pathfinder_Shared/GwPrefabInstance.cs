﻿using System;
using System.Runtime.InteropServices;
using UnityEngine;

public class GwPrefabInstance
{
    public Vector3 position;
    public string prefabName;
    public Quaternion rotation;
    public Vector3 scale;

    public static GwPrefabInstance FromPrefabInstance(PrefabInstance inst, bool validateHierarchy = false)
    {
        if (validateHierarchy)
        {
            Transform parent = inst.transform.parent;
            if ((parent == null) || ((parent != null) && (parent.GetComponent<TerrainDecorations>() == null)))
            {
                throw new InvalidObjectDepthException("Manually placed PrefabInstances must have their immediate parent be a TerrainDecorations object.");
            }
            if (inst.transform.childCount > 0)
            {
                throw new InvalidObjectDepthException("Manually placed PrefabInstances must not have any children.");
            }
        }
        GwPrefabInstance instance = new GwPrefabInstance();
        if (inst.prefab != null)
        {
            instance.prefabName = inst.prefab.name;
        }
        else if (!string.IsNullOrEmpty(inst.prefabName))
        {
            instance.prefabName = inst.prefabName;
        }
        instance.position = inst.transform.localPosition;
        instance.rotation = inst.transform.localRotation;
        instance.scale = inst.transform.localScale;
        return instance;
    }

    public static PrefabInstance ToPrefabInstance(GwPrefabInstance oldInst, Transform parent = null)
    {
        if (oldInst == null)
        {
            return null;
        }
        PrefabInstance instance = new GameObject(oldInst.prefabName) { transform = { parent = parent, localPosition = oldInst.position, localRotation = oldInst.rotation, localScale = oldInst.scale } }.AddComponent<PrefabInstance>();
        instance.prefabName = oldInst.prefabName;
        return instance;
    }
}

