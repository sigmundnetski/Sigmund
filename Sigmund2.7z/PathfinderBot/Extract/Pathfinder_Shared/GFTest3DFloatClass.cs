﻿using System;

internal class GFTest3DFloatClass
{
    public float[,,] data;
}

