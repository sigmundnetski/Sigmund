﻿using System;
using System.Collections.Generic;

[LooseDependency(typeof(GatheringNodeData))]
public class HexTerrainData : DataClass
{
    private static readonly string[] _mandatoryColumns = new string[] { "terrain", "display name", "mineral", "plant", "essence", "junk", "isdefault", "terrain challenge rating" };
    public static readonly string[] COMMON_UNITTEST_NAMES = new string[] { "Croplands", "Coastlands", "Highlands", "Mountains", "Wetlands", "Woodlands" };
    public static HexTerrainData defaultTerrain;
    public string displayName;
    private bool isDefault;
    public Dictionary<int, byte> nodeRatios;
    public static Dictionary<int, HexTerrainData> terrainById = new Dictionary<int, HexTerrainData>();
    public int terrainChallengeRating;

    public static void ConstructUnittestData(IEnumerable<string> _names)
    {
        if (GatheringNodeData.nodeById.Count == 0)
        {
            UUnitAssert.Fail("GatheringNodeData must be built before the HexData");
        }
        List<DataClass> objects = new List<DataClass>();
        if (object.ReferenceEquals(_names, null))
        {
            _names = COMMON_UNITTEST_NAMES;
        }
        bool flag = true;
        foreach (string str in _names)
        {
            HexTerrainData item = new HexTerrainData {
                id = DataClass.GenerateId(str),
                name = str.ToLower(),
                displayName = str,
                nodeRatios = new Dictionary<int, byte>()
            };
            foreach (KeyValuePair<int, GatheringNodeData> pair in GatheringNodeData.nodeById)
            {
                item.nodeRatios[pair.Key] = (byte) (100 / GatheringNodeData.nodeById.Count);
            }
            item.isDefault = flag;
            objects.Add(item);
            flag = false;
        }
        OnLoad(objects);
    }

    public static void OnLoad(List<DataClass> objects)
    {
        defaultTerrain = null;
        foreach (HexTerrainData data in objects)
        {
            terrainById[data.id] = data;
            if (data.isDefault && object.ReferenceEquals(defaultTerrain, null))
            {
                defaultTerrain = data;
            }
            else if (data.isDefault)
            {
                GLog.LogWarning(new object[] { "Multiple TerrainType defaults not allowed: ", defaultTerrain.name, data.name });
            }
        }
        if (object.ReferenceEquals(defaultTerrain, null))
        {
            GLog.LogWarning(new object[] { "TerrainType default is required." });
        }
    }

    private static void ParseGatheringRatios(int rowIndex, HexTerrainData output)
    {
        output.nodeRatios = new Dictionary<int, byte>();
        int num = -1;
        int num2 = 0;
        foreach (KeyValuePair<string, GatheringNodeData> pair in GatheringNodeData.nodeByName)
        {
            if (DataClass.columnNamesToIndex.TryGetValue(pair.Key, out num))
            {
                byte num3;
                DataClass.GetCellValue(num, rowIndex, out num3);
                output.nodeRatios[pair.Value.id] = num3;
                num2 += num3;
            }
            else
            {
                GLog.LogWarning(new object[] { "HexData must have columns for each GatheringNode.  Missing:", pair.Key });
            }
        }
        if ((num != -1) && (num2 != 100))
        {
            DataClass.OutputErrorMessage(num, rowIndex, "The node percentages do not sum to 100 for: " + output.name);
        }
    }

    public override DataClass ParseRecord(int rowIndex)
    {
        string str;
        if (!DataClass.TryGetLCaseCellValue(DataClass.columnNamesToIndex["terrain"], rowIndex, out str))
        {
            return null;
        }
        HexTerrainData output = new HexTerrainData {
            name = str
        };
        DataClass.GetCellValue(DataClass.columnNamesToIndex["display name"], rowIndex, out output.displayName);
        DataClass.GetCellValue(DataClass.columnNamesToIndex["isdefault"], rowIndex, out output.isDefault);
        DataClass.GetCellValue(DataClass.columnNamesToIndex["terrain challenge rating"], rowIndex, out output.terrainChallengeRating);
        ParseGatheringRatios(rowIndex, output);
        return output;
    }

    protected override IEnumerable<string> GetMandatoryColumns
    {
        get
        {
            return _mandatoryColumns;
        }
    }
}

