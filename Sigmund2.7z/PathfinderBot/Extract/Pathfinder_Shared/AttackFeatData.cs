﻿using System;
using System.Runtime.InteropServices;

[LooseDependency(typeof(KeywordData)), LooseDependency(typeof(WeaponProficiencyData)), LooseDependency(typeof(WeaponCategoryData)), LooseDependency(typeof(CombatData)), NoFinalOutput, LooseDependency(typeof(FeatAdvancementData)), LooseDependency(typeof(RoleData)), LooseDependency(typeof(AnimationData))]
public class AttackFeatData : OffensiveFeatData
{
    private const int NUM_FEAT_LEVELS = 6;

    public AttackFeatData()
    {
        base.Init(6);
        base.type = Combat.FeatType.Attack;
        base.generalType = Combat.FeatType.Offensive;
        base.keywordType = KeywordData.GearType.WEAPON;
    }

    public AttackFeatData(string name_, float damageFactor_, float range_, float durationValidation_, float durationInterruption_, float durationFollowThrough_, int stamina_, int weaponCategoryId_, string effects_, float cooldown = 0f, string keywords0 = "", string keywords1 = "", string keywords2 = "", string keywords3 = "", string keywords4 = "", string keywords5 = "") : base(name_, 6)
    {
        base.type = Combat.FeatType.Attack;
        base.generalType = Combat.FeatType.Offensive;
        base.keywordType = KeywordData.GearType.WEAPON;
        base.displayName = name_;
        base.damageFactor = damageFactor_;
        base.range = range_;
        base.durationValidation = durationValidation_;
        base.durationInterruption = durationInterruption_;
        base.durationFollowThrough = durationFollowThrough_;
        base.speed = (durationValidation_ + durationInterruption_) + durationFollowThrough_;
        base.stamina = stamina_;
        base.animationId = 0;
        base.effects = effects_;
        base.restrictions = string.Empty;
        base.other = string.Empty;
        base.rooted = false;
        base.weaponCategoryId = weaponCategoryId_;
        base.durationCooldown = cooldown;
        base.ProcessCombatModifiers();
        base.provokeOpportunity = CombatModifier.Parse("Opportunity (1 second) to Self");
        base.keywordIds[0] = base.ParseKeywords(keywords0);
        base.keywordIds[1] = base.ParseKeywords(keywords0 + ", " + keywords1);
        base.keywordIds[2] = base.ParseKeywords(keywords0 + ", " + keywords1 + ", " + keywords2);
        base.keywordIds[3] = base.ParseKeywords(keywords0 + ", " + keywords1 + ", " + keywords2 + ", " + keywords3);
        base.keywordIds[4] = base.ParseKeywords(keywords0 + ", " + keywords1 + ", " + keywords2 + ", " + keywords3 + ", " + keywords4);
        base.keywordIds[5] = base.ParseKeywords(keywords0 + ", " + keywords1 + ", " + keywords2 + ", " + keywords3 + ", " + keywords4 + ", " + keywords5);
        base.ParseEffectType(base.attackMods);
        base.power = 0;
        base.expendableLevel = 0;
        base.endOfCombatCooldown = false;
    }

    public override DataClass ParseRecord(int index)
    {
        string str;
        OffensiveFeatData data = new AttackFeatData();
        if (!base.ParseRecord(index, ref data, out str))
        {
            return null;
        }
        return data;
    }
}

