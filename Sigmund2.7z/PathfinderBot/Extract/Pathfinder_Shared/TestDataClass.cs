﻿using System;

internal class TestDataClass : DataClass
{
    public bool testBool;
    public float testFloat;
    public int testInt;
    public string[] testStrings;

    public TestDataClass()
    {
        this.testInt = 0;
        this.testFloat = 0f;
        this.testBool = false;
        this.testStrings = null;
    }

    public TestDataClass(string tName, int tInt, float tFloat, bool tBool, string[] tStrings) : base(tName)
    {
        this.testInt = tInt;
        this.testFloat = tFloat;
        this.testBool = tBool;
        this.testStrings = tStrings;
    }
}

