﻿using System;
using System.Collections.Generic;
using UnityEngine;

public class QualitySettingsData : DataClass
{
    protected static readonly string[] _mandatoryColumns = new string[] { "quality level", "panic threshold", "calm threshold", "max mip level", "intermediate mip level", "default mip level", "max mip distance", "intermediate mip start", "intermediate mip end", "default mip distance", "max distance variation", "min distance variation", "increasing multiplier", "decreasing multiplier" };
    public float decreasingMultiplier;
    public float increasingMultiplier;
    public float maxSqrdistanceDefaultMip;
    public float maxSqrdistanceIntermediateMipEnd;
    public float maxSqrdistanceIntermediateMipStart;
    public float maxSqrdistanceMaxMip;
    public float minSqrdistanceDefaultMip;
    public float minSqrdistanceIntermediateMipEnd;
    public float minSqrdistanceIntermediateMipStart;
    public float minSqrdistanceMaxMip;
    public int mipDefaultLevel;
    public int mipIntermediateLevel;
    public int mipMaxLevel;
    public Platform platform;
    public static Dictionary<int, QualitySettingsData> qualitiesById = new Dictionary<int, QualitySettingsData>();
    public static Dictionary<string, QualitySettingsData> qualitiesByName = new Dictionary<string, QualitySettingsData>();
    public string qualityLevel;
    public float sqrdistanceDefaultMip;
    public float sqrdistanceIntermediateMipEnd;
    public float sqrdistanceIntermediateMipStart;
    public float sqrdistanceMaxMip;
    public int thresholdCalm;
    public int thresholdPanic;

    private static Platform GetUnityPlatform()
    {
        if (((Application.platform == RuntimePlatform.WindowsEditor) || (Application.platform == RuntimePlatform.WindowsPlayer)) || (Application.platform == RuntimePlatform.WindowsWebPlayer))
        {
            return Platform.Windows;
        }
        if ((((Application.platform == RuntimePlatform.OSXDashboardPlayer) || (Application.platform == RuntimePlatform.OSXEditor)) || (Application.platform == RuntimePlatform.OSXPlayer)) || (Application.platform == RuntimePlatform.OSXWebPlayer))
        {
            return Platform.Mac;
        }
        return Platform.None;
    }

    public static void OnLoad(List<DataClass> objects)
    {
        qualitiesById.Clear();
        qualitiesByName.Clear();
        Platform none = Platform.None;
        if (GUtil.inUnity)
        {
            none = GetUnityPlatform();
        }
        foreach (QualitySettingsData data in objects)
        {
            if ((none == Platform.None) || (data.platform == none))
            {
                qualitiesById[data.id] = data;
                qualitiesByName[data.qualityLevel] = data;
            }
        }
    }

    public override DataClass ParseRecord(int index)
    {
        int column = -1;
        float output = 0f;
        QualitySettingsData data = new QualitySettingsData();
        string str = null;
        if (!DataClass.TryGetLCaseCellValue(DataClass.columnNamesToIndex["quality level"], index, out str))
        {
            return null;
        }
        DataClass.TryGetEnumCellValue<Platform>(DataClass.columnNamesToIndex["platform"], index, Platform.None, out data.platform);
        data.name = data.platform + "_" + str;
        data.qualityLevel = str.ToLower();
        DataClass.GetCellValue(DataClass.columnNamesToIndex["panic threshold"], index, out data.thresholdPanic);
        DataClass.GetCellValue(DataClass.columnNamesToIndex["calm threshold"], index, out data.thresholdCalm);
        if (data.thresholdPanic <= data.thresholdCalm)
        {
            DataClass.OutputErrorMessage(DataClass.columnNamesToIndex["panic threshold"], index, "Error parsing quality setting: " + data.qualityLevel + " - Panic Threshold must be greater than Calm Threshold.");
            return null;
        }
        DataClass.GetCellValue(DataClass.columnNamesToIndex["max mip level"], index, out data.mipMaxLevel);
        DataClass.GetCellValue(DataClass.columnNamesToIndex["intermediate mip level"], index, out data.mipIntermediateLevel);
        if (data.mipMaxLevel >= data.mipIntermediateLevel)
        {
            DataClass.OutputErrorMessage(DataClass.columnNamesToIndex["max mip level"], index, "Error parsing quality setting: " + data.qualityLevel + " - Max Mip Level must be less than Intermediate Mip Level.");
            return null;
        }
        DataClass.GetCellValue(DataClass.columnNamesToIndex["default mip level"], index, out data.mipDefaultLevel);
        if (data.mipIntermediateLevel >= data.mipDefaultLevel)
        {
            DataClass.OutputErrorMessage(DataClass.columnNamesToIndex["intermediate mip level"], index, "Error parsing quality setting: " + data.qualityLevel + " - Intermediate Mip Level must be less than Default Mip Level.");
            return null;
        }
        DataClass.GetCellValue(DataClass.columnNamesToIndex["max mip distance"], index, out output);
        data.sqrdistanceMaxMip = output * output;
        DataClass.GetCellValue(DataClass.columnNamesToIndex["intermediate mip start"], index, out output);
        data.sqrdistanceIntermediateMipStart = output * output;
        if (data.sqrdistanceMaxMip >= data.sqrdistanceIntermediateMipStart)
        {
            DataClass.OutputErrorMessage(DataClass.columnNamesToIndex["max mip distance"], index, "Error parsing quality setting: " + data.qualityLevel + " - Max Mip Distance must be less than Intermediate Mip Start.");
            return null;
        }
        DataClass.GetCellValue(DataClass.columnNamesToIndex["intermediate mip end"], index, out output);
        data.sqrdistanceIntermediateMipEnd = output * output;
        if (data.sqrdistanceIntermediateMipStart >= data.sqrdistanceIntermediateMipEnd)
        {
            DataClass.OutputErrorMessage(DataClass.columnNamesToIndex["intermediate mip start"], index, "Error parsing quality setting: " + data.qualityLevel + " - Intermediate Mip Start must be less than Intermediate Mip End.");
            return null;
        }
        DataClass.GetCellValue(DataClass.columnNamesToIndex["default mip distance"], index, out output);
        data.sqrdistanceDefaultMip = output * output;
        if (data.sqrdistanceIntermediateMipEnd >= data.sqrdistanceDefaultMip)
        {
            DataClass.OutputErrorMessage(DataClass.columnNamesToIndex["intermediate mip end"], index, "Error parsing quality setting: " + data.qualityLevel + " - Intermediate Mip End must be less than Default Mip Distance.");
            return null;
        }
        float num3 = 1f;
        DataClass.GetCellValue(DataClass.columnNamesToIndex["max distance variation"], index, out num3);
        data.maxSqrdistanceMaxMip = data.sqrdistanceMaxMip * num3;
        data.maxSqrdistanceIntermediateMipStart = data.sqrdistanceIntermediateMipStart * num3;
        data.maxSqrdistanceIntermediateMipEnd = data.sqrdistanceIntermediateMipEnd * num3;
        data.maxSqrdistanceDefaultMip = data.sqrdistanceDefaultMip * num3;
        DataClass.GetCellValue(DataClass.columnNamesToIndex["min distance variation"], index, out num3);
        data.minSqrdistanceMaxMip = data.sqrdistanceMaxMip * num3;
        data.minSqrdistanceIntermediateMipStart = data.sqrdistanceIntermediateMipStart * num3;
        data.minSqrdistanceIntermediateMipEnd = data.sqrdistanceIntermediateMipEnd * num3;
        data.minSqrdistanceDefaultMip = data.sqrdistanceDefaultMip * num3;
        column = DataClass.columnNamesToIndex["increasing multiplier"];
        DataClass.GetCellValue(column, index, out data.increasingMultiplier);
        if (data.increasingMultiplier <= 1f)
        {
            DataClass.OutputErrorMessage(column, index, "Error parsing quality setting: " + data.qualityLevel + " - Increasing Multiplier must be > 1.");
            return null;
        }
        column = DataClass.columnNamesToIndex["decreasing multiplier"];
        DataClass.GetCellValue(column, index, out data.decreasingMultiplier);
        if (data.decreasingMultiplier >= 1f)
        {
            DataClass.OutputErrorMessage(column, index, "Error parsing quality setting: " + data.qualityLevel + " - Decreasing Multiplier must be < 1.");
            return null;
        }
        return data;
    }

    protected override IEnumerable<string> GetMandatoryColumns
    {
        get
        {
            return _mandatoryColumns;
        }
    }

    public enum Platform : byte
    {
        Mac = 2,
        None = 0,
        Windows = 1
    }
}

