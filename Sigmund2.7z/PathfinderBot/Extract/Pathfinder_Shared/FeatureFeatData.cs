﻿using System;
using System.Collections.Generic;

[LooseDependency(typeof(CombatData)), LooseDependency(typeof(KeywordData)), NoFinalOutput]
public class FeatureFeatData : NonAttackFeatData
{
    public FeatureFeatData()
    {
        base.type = Combat.FeatType.Feature;
        base.generalType = Combat.FeatType.Passive;
    }

    public FeatureFeatData(string name_, byte level_, string effects_, string keywords_) : base(name_, level_, effects_)
    {
        base.type = Combat.FeatType.Feature;
        base.generalType = Combat.FeatType.Passive;
        base.roleId = 0;
        base.usableInStealth = false;
        base.keywordIds = this.ParseKeywords(keywords_);
    }

    protected int[] ParseKeywords(string allKeywords)
    {
        string[] strArray = allKeywords.Split(new char[] { ',' });
        List<int> list = new List<int>();
        foreach (string str in strArray)
        {
            string str2 = str.Trim();
            if (!string.IsNullOrEmpty(str2))
            {
                int id = KeywordData.GetId(str2, KeywordData.GearType.IMPLEMENT);
                if (id == 0)
                {
                    return null;
                }
                list.Add(id);
            }
        }
        if (list.Count > 0)
        {
            return list.ToArray();
        }
        return new int[0];
    }

    public override DataClass ParseRecord(int index)
    {
        string str;
        NonAttackFeatData data = new FeatureFeatData();
        data = (NonAttackFeatData) base.GenericParse(data, index);
        DataClass.GetCellValue(DataClass.columnNamesToIndex["keywords"], index, out str);
        data.keywordIds = this.ParseKeywords(str);
        return data;
    }
}

