﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;

public class CombatClassVars : IDataCopyable<CombatClassVars>
{
    public int armorFeatId;
    public NonWeaponVars armorItem;
    public CombatAttackBonus attackBonus;
    public AttackFeatVars[] attackFeatSets;
    public byte attackTier;
    public int baseDamage;
    public int[] bootAdvancedKeywordCache;
    public NonWeaponVars bootItem;
    public string combatAnimSetName;
    public int combatClassId;
    [DataRestrict]
    public CombatClassData data;
    public CombatDefense defense;
    public int drawAnimNumber;
    public int effectDefense;
    public int effectPower;
    public AttackFeatVars[] expendableFeatSets;
    public byte fallbackAttackLevel;
    public int featureFeatId;
    public int[] gearBasicKeywordCache;
    public int[] gloveAdvancedKeywordCache;
    public NonWeaponVars gloveItem;
    public int hitPoints;
    public string idleAnimSetName;
    private static readonly int[] IMPLEMENT_SLOT_INDEXES = new int[] { 13, 14 };
    public WeaponVars[] implementItemSets;
    public string mainhandModelName;
    public int maxEncumbrance;
    public float moveSpeed;
    public string offhandModelName;
    public int[] passiveFeatIds;
    public int power;
    public CombatRecovery recovery;
    public int[] refreshFeatIds;
    public int regenPercent;
    public CombatResistance resistance;
    public const int SECONDARY_ATTACK_START = 3;
    public Skills skills;
    public int speedPercent;
    public int[] upgradeFeatIds;
    public AttackFeatVars[] utilityFeats;
    private static readonly int[] WEAPON_SLOT_INDEXES = new int[] { 9, 10, 11, 12 };
    public WeaponVars[] weaponItemSets;

    public CombatClassVars()
    {
        this.recovery = new CombatRecovery();
        this.defense = new CombatDefense();
        this.resistance = new CombatResistance();
        this.attackBonus = new CombatAttackBonus();
        this.skills = new Skills();
        this.data = null;
        this.combatClassId = 0;
        this.weaponItemSets = new WeaponVars[4];
        this.attackFeatSets = new AttackFeatVars[12];
        this.implementItemSets = new WeaponVars[2];
        this.expendableFeatSets = new AttackFeatVars[12];
        this.featureFeatId = 0;
        this.passiveFeatIds = null;
        this.refreshFeatIds = null;
        this.upgradeFeatIds = null;
        this.gearBasicKeywordCache = null;
        this.gloveAdvancedKeywordCache = null;
        this.bootAdvancedKeywordCache = null;
        this.gloveItem = new NonWeaponVars(0, 0, 0);
        this.bootItem = new NonWeaponVars(0, 0, 0);
        this.utilityFeats = null;
    }

    public CombatClassVars(CombatClassData sourceData)
    {
        this.recovery = new CombatRecovery();
        this.defense = new CombatDefense();
        this.resistance = new CombatResistance();
        this.attackBonus = new CombatAttackBonus();
        this.skills = new Skills();
        this.data = sourceData;
        this.combatClassId = sourceData.id;
        this.LoadBasicValuesFromData();
        this.LoadOffensiveFeats(this.data.GetAttackFeatIds(), this.data.GetAttackFeatLevels(), this.data.GetExpendableFeatIds(), this.data.GetExpendableFeatLevels(), this.data.GetUtilityFeatIds(), this.data.GetUtilityFeatLevels());
        this.LoadNpcNonAttackFeats(this.data);
        this.LoadStaticWeapons(this.data);
        this.fallbackAttackLevel = 6;
        this.gearBasicKeywordCache = null;
        this.gloveAdvancedKeywordCache = null;
        this.bootAdvancedKeywordCache = null;
        this.gloveItem = new NonWeaponVars(0, 0, 0);
        this.bootItem = new NonWeaponVars(0, 0, 0);
    }

    private void AddGearToCache(BasicItemData item)
    {
        GearItemData data = item as GearItemData;
        if ((data != null) && (data.keywordIds != null))
        {
            this.AddKeywordsToCache(data.slot, data.keywordIds);
        }
    }

    private void AddKeywordsToCache(BasicItemData.ItemSlot slot, int[] keywordIds)
    {
        for (int i = 0; i < keywordIds.Length; i++)
        {
            KeywordData.KeywordType type = KeywordData.GetType(KeywordData.GearType.GEAR, keywordIds[i]);
            if (type == KeywordData.KeywordType.BASIC)
            {
                SparseArray.Add<int>(ref this.gearBasicKeywordCache, keywordIds[i], x => x == 0, 0);
            }
            else if ((type == KeywordData.KeywordType.ADVANCED) && (slot == BasicItemData.ItemSlot.HANDS))
            {
                SparseArray.Add<int>(ref this.gloveAdvancedKeywordCache, keywordIds[i], x => x == 0, 0);
            }
            else if ((type == KeywordData.KeywordType.ADVANCED) && (slot == BasicItemData.ItemSlot.FEET))
            {
                SparseArray.Add<int>(ref this.bootAdvancedKeywordCache, keywordIds[i], x => x == 0, 0);
            }
        }
    }

    public void AddWeaponToCache(BasicItemData item, byte upgrade)
    {
        CombatWeapon weapon = item as CombatWeapon;
        if ((weapon != null) && ((weapon.slot == BasicItemData.ItemSlot.HANDS) || (weapon.slot == BasicItemData.ItemSlot.FEET)))
        {
            if (weapon.slot == BasicItemData.ItemSlot.HANDS)
            {
                this.gloveItem = new NonWeaponVars(item.id, upgrade, 0);
            }
            if (weapon.slot == BasicItemData.ItemSlot.FEET)
            {
                this.bootItem = new NonWeaponVars(item.id, upgrade, 0);
            }
            int[] keywordIds = weapon.GetKeywordIds(4);
            this.AddKeywordsToCache(weapon.slot, keywordIds);
        }
    }

    private void ClearGearCache()
    {
        if ((this.gearBasicKeywordCache == null) || (this.gearBasicKeywordCache.Length == 0))
        {
            this.gearBasicKeywordCache = new int[10];
        }
        if ((this.gloveAdvancedKeywordCache == null) || (this.gloveAdvancedKeywordCache.Length == 0))
        {
            this.gloveAdvancedKeywordCache = new int[2];
        }
        if ((this.bootAdvancedKeywordCache == null) || (this.bootAdvancedKeywordCache.Length == 0))
        {
            this.bootAdvancedKeywordCache = new int[2];
        }
        SparseArray.Clear<int>(ref this.gearBasicKeywordCache, 0);
        SparseArray.Clear<int>(ref this.gloveAdvancedKeywordCache, 0);
        SparseArray.Clear<int>(ref this.bootAdvancedKeywordCache, 0);
        this.gloveItem = new NonWeaponVars(0, 0, 0);
        this.bootItem = new NonWeaponVars(0, 0, 0);
    }

    public void DataCopyTo(ref CombatClassVars target, byte syncTargetLevel)
    {
        if (target == null)
        {
            target = new CombatClassVars();
        }
        target.hitPoints = this.hitPoints;
        target.maxEncumbrance = this.maxEncumbrance;
        target.power = this.power;
        target.speedPercent = this.speedPercent;
        target.regenPercent = this.regenPercent;
        target.armorFeatId = this.armorFeatId;
        target.attackTier = this.attackTier;
        target.baseDamage = this.baseDamage;
        target.fallbackAttackLevel = this.fallbackAttackLevel;
        target.effectPower = this.effectPower;
        target.effectDefense = this.effectDefense;
        target.featureFeatId = this.featureFeatId;
        target.moveSpeed = this.moveSpeed;
        target.idleAnimSetName = this.idleAnimSetName;
        target.combatAnimSetName = this.combatAnimSetName;
        target.drawAnimNumber = this.drawAnimNumber;
        target.mainhandModelName = this.mainhandModelName;
        target.offhandModelName = this.offhandModelName;
        target.combatClassId = this.combatClassId;
        DataSerializerUtils.DataCopyField<CombatRecovery>(this.recovery, ref target.recovery, syncTargetLevel);
        DataSerializerUtils.DataCopyField<CombatDefense>(this.defense, ref target.defense, syncTargetLevel);
        DataSerializerUtils.DataCopyField<CombatResistance>(this.resistance, ref target.resistance, syncTargetLevel);
        DataSerializerUtils.DataCopyField<CombatAttackBonus>(this.attackBonus, ref target.attackBonus, syncTargetLevel);
        DataSerializerUtils.DataCopyField<Skills>(this.skills, ref target.skills, syncTargetLevel);
        target.armorItem = this.armorItem;
        DataSerializerUtils.DataCopyField<WeaponVars>(this.weaponItemSets, ref target.weaponItemSets);
        DataSerializerUtils.DataCopyField<AttackFeatVars>(this.attackFeatSets, ref target.attackFeatSets);
        DataSerializerUtils.DataCopyField<WeaponVars>(this.implementItemSets, ref target.implementItemSets);
        DataSerializerUtils.DataCopyField<AttackFeatVars>(this.expendableFeatSets, ref target.expendableFeatSets);
        DataSerializerUtils.DataCopyField<AttackFeatVars>(this.utilityFeats, ref target.utilityFeats);
        DataSerializerUtils.DataCopyField<int>(this.gearBasicKeywordCache, ref target.gearBasicKeywordCache);
        DataSerializerUtils.DataCopyField<int>(this.gloveAdvancedKeywordCache, ref target.gloveAdvancedKeywordCache);
        DataSerializerUtils.DataCopyField<int>(this.bootAdvancedKeywordCache, ref target.bootAdvancedKeywordCache);
        target.gloveItem = this.gloveItem;
        target.bootItem = this.bootItem;
        DataSerializerUtils.DataCopyField<int>(this.passiveFeatIds, ref target.passiveFeatIds);
        DataSerializerUtils.DataCopyField<int>(this.refreshFeatIds, ref target.refreshFeatIds);
        DataSerializerUtils.DataCopyField<int>(this.upgradeFeatIds, ref target.upgradeFeatIds);
    }

    public bool DataEquals(CombatClassVars target, byte syncTargetLevel)
    {
        bool flag = true;
        return ((((((((((((((((((((((((((((((((((((((flag && (target.hitPoints == this.hitPoints)) && (target.maxEncumbrance == this.maxEncumbrance)) && (target.power == this.power)) && (target.speedPercent == this.speedPercent)) && (target.regenPercent == this.regenPercent)) && (target.armorFeatId == this.armorFeatId)) && (target.attackTier == this.attackTier)) && (target.baseDamage == this.baseDamage)) && (target.fallbackAttackLevel == this.fallbackAttackLevel)) && (target.effectPower == this.effectPower)) && (target.effectDefense == this.effectDefense)) && (target.featureFeatId == this.featureFeatId)) && (target.moveSpeed == this.moveSpeed)) && (target.idleAnimSetName == this.idleAnimSetName)) && (target.combatAnimSetName == this.combatAnimSetName)) && (target.drawAnimNumber == this.drawAnimNumber)) && (target.mainhandModelName == this.mainhandModelName)) && (target.offhandModelName == this.offhandModelName)) && (target.combatClassId == this.combatClassId)) && DataSerializerUtils.DataEquals<CombatRecovery>(target.recovery, this.recovery, syncTargetLevel)) && DataSerializerUtils.DataEquals<CombatDefense>(target.defense, this.defense, syncTargetLevel)) && DataSerializerUtils.DataEquals<CombatResistance>(target.resistance, this.resistance, syncTargetLevel)) && DataSerializerUtils.DataEquals<CombatAttackBonus>(target.attackBonus, this.attackBonus, syncTargetLevel)) && DataSerializerUtils.DataEquals<Skills>(target.skills, this.skills, syncTargetLevel)) && target.armorItem.DataEquals(this.armorItem, syncTargetLevel)) && SparseArray.DeepEqualsWithIndex<WeaponVars>(target.weaponItemSets, this.weaponItemSets, syncTargetLevel, WeaponVars.EMPTY_MATCH)) && SparseArray.DeepEqualsWithIndex<AttackFeatVars>(target.attackFeatSets, this.attackFeatSets, syncTargetLevel, AttackFeatVars.EMPTY_MATCH)) && SparseArray.DeepEqualsWithIndex<WeaponVars>(target.implementItemSets, this.implementItemSets, syncTargetLevel, WeaponVars.EMPTY_MATCH)) && SparseArray.DeepEqualsWithIndex<AttackFeatVars>(target.expendableFeatSets, this.expendableFeatSets, syncTargetLevel, AttackFeatVars.EMPTY_MATCH)) && SparseArray.DeepEqualsWithIndex<AttackFeatVars>(target.utilityFeats, this.utilityFeats, syncTargetLevel, AttackFeatVars.EMPTY_MATCH)) && SparseArray.DeepEqualsWithIndex<int>(target.gearBasicKeywordCache, this.gearBasicKeywordCache)) && SparseArray.DeepEqualsWithIndex<int>(target.gloveAdvancedKeywordCache, this.gloveAdvancedKeywordCache)) && SparseArray.DeepEqualsWithIndex<int>(target.bootAdvancedKeywordCache, this.bootAdvancedKeywordCache)) && target.gloveItem.DataEquals(this.gloveItem, syncTargetLevel)) && target.bootItem.DataEquals(this.bootItem, syncTargetLevel)) && SparseArray.DeepEqualsWithIndex<int>(target.passiveFeatIds, this.passiveFeatIds)) && SparseArray.DeepEqualsWithIndex<int>(target.refreshFeatIds, this.refreshFeatIds)) && SparseArray.DeepEqualsWithIndex<int>(target.upgradeFeatIds, this.upgradeFeatIds));
    }

    private void FindArmorFeat()
    {
        bool flag = false;
        for (int i = 0; i < this.passiveFeatIds.Length; i++)
        {
            NonAttackFeatData featById = NonAttackFeatData.GetFeatById(this.passiveFeatIds[i]);
            if ((featById != null) && (featById.type == Combat.FeatType.Armor))
            {
                this.armorFeatId = this.passiveFeatIds[i];
                flag = true;
                break;
            }
        }
        if (!flag)
        {
            this.armorFeatId = 0;
        }
    }

    private void FindFeatureFeat()
    {
        bool flag = false;
        for (int i = 0; i < this.passiveFeatIds.Length; i++)
        {
            NonAttackFeatData featById = NonAttackFeatData.GetFeatById(this.passiveFeatIds[i]);
            if ((featById != null) && (featById.type == Combat.FeatType.Feature))
            {
                this.featureFeatId = this.passiveFeatIds[i];
                flag = true;
                break;
            }
        }
        if (!flag)
        {
            this.featureFeatId = 0;
        }
    }

    public void FixupFeats()
    {
        CombatWeapon weaponById = CombatWeapon.GetWeaponById(this.GetWeaponId(0, LogicalHand.MAIN_HAND));
        CombatWeapon weapon2 = CombatWeapon.GetWeaponById(this.GetWeaponId(0, LogicalHand.OFF_HAND));
        CombatWeapon weapon3 = CombatWeapon.GetWeaponById(this.GetWeaponId(1, LogicalHand.MAIN_HAND));
        CombatWeapon weapon4 = CombatWeapon.GetWeaponById(this.GetWeaponId(1, LogicalHand.OFF_HAND));
        for (int i = 0; i < this.attackFeatSets.Length; i++)
        {
            if (!AttackFeatVars.EMPTY_MATCH(this.attackFeatSets[i]))
            {
                OffensiveFeatData attackById = OffensiveFeatData.GetAttackById(this.attackFeatSets[i].id);
                if (attackById != null)
                {
                    int num2 = 0;
                    int num3 = 0;
                    if (this.attackFeatSets[i].weaponSet == 0)
                    {
                        num2 = (weaponById != null) ? weaponById.weaponCategoryId : 0;
                        num3 = (weapon2 != null) ? weapon2.weaponCategoryId : 0;
                    }
                    else
                    {
                        num2 = (weapon3 != null) ? weapon3.weaponCategoryId : 0;
                        num3 = (weapon4 != null) ? weapon4.weaponCategoryId : 0;
                    }
                    if ((attackById.weaponCategoryId != num2) && (attackById.weaponCategoryId != num3))
                    {
                        this.attackFeatSets[i] = AttackFeatVars.EMPTY;
                    }
                }
            }
        }
    }

    public CombatArmor GetArmor()
    {
        if (this.armorItem.id == 0)
        {
            return null;
        }
        return CombatArmor.GetArmorById(this.armorItem.id);
    }

    public byte GetArmorUpgrade()
    {
        return this.armorItem.upgrade;
    }

    public AttackFeatVars GetAttackFeat(int attackId)
    {
        return (from each in this.attackFeatSets
            where each.id == attackId
            select each).FirstOrDefault<AttackFeatVars>();
    }

    public AttackFeatVars GetAttackFeat(uint weaponSet, LogicalHand hand)
    {
        return (from each in this.attackFeatSets
            where (each.weaponSet == weaponSet) && (each.hotbarIndex == hand)
            select each).FirstOrDefault<AttackFeatVars>();
    }

    public byte GetAttackLevel(OffensiveFeatData attack)
    {
        AttackFeatVars[] attackFeatSets = null;
        switch (attack.type)
        {
            case Combat.FeatType.Attack:
                attackFeatSets = this.attackFeatSets;
                break;

            case Combat.FeatType.Expendable:
                attackFeatSets = this.expendableFeatSets;
                break;

            case Combat.FeatType.Utility:
                attackFeatSets = this.utilityFeats;
                break;
        }
        IEnumerable<byte> source = from each in attackFeatSets
            where each.id == attack.id
            select each.level;
        if (source.Count<byte>() > 0)
        {
            return source.First<byte>();
        }
        if (!((attack.form == FeatData.FeatForm.Wondrous) || CombatCore.debugMode))
        {
            GLog.LogError(new object[] { "Attack not present:", attack.type, attack.id, "Options:", from each in attackFeatSets select each.id, "Falling back to level:", this.fallbackAttackLevel });
        }
        return this.fallbackAttackLevel;
    }

    public int GetImplementId(uint weaponSet)
    {
        return (from each in this.implementItemSets
            where each.weaponSet == weaponSet
            select each).FirstOrDefault<WeaponVars>().id;
    }

    public byte GetImplementUpgrade(uint weaponSet)
    {
        return (from each in this.implementItemSets
            where each.weaponSet == weaponSet
            select each).FirstOrDefault<WeaponVars>().upgrade;
    }

    public void GetWeapon(OffensiveFeatData attack, uint weaponSetNumber, out CombatWeapon weapon, out byte weaponUpgrade)
    {
        if (attack.form == FeatData.FeatForm.Wondrous)
        {
            weapon = CombatCore.wondrousWeapon;
            weaponUpgrade = 0;
        }
        else if (attack.type == Combat.FeatType.Utility)
        {
            weapon = CombatWeapon.GetWeaponById(this.bootItem.id);
            if ((weapon != null) && (attack.weaponCategoryId == weapon.weaponCategoryId))
            {
                weaponUpgrade = this.bootItem.upgrade;
            }
            else
            {
                weapon = CombatWeapon.GetWeaponById(this.gloveItem.id);
                if ((weapon != null) && (attack.weaponCategoryId == weapon.weaponCategoryId))
                {
                    weaponUpgrade = this.gloveItem.upgrade;
                }
                else
                {
                    weapon = null;
                    weaponUpgrade = 0;
                }
            }
        }
        else
        {
            WeaponVars[] varsArray = (attack.type == Combat.FeatType.Expendable) ? this.implementItemSets : this.weaponItemSets;
            for (int i = 0; i < varsArray.Length; i++)
            {
                if ((varsArray[i].id != 0) && (varsArray[i].weaponSet == weaponSetNumber))
                {
                    weapon = CombatWeapon.GetWeaponById(varsArray[i].id);
                    weaponUpgrade = varsArray[i].upgrade;
                    if (weapon.weaponCategoryId == attack.weaponCategoryId)
                    {
                        return;
                    }
                }
            }
            weapon = null;
            weaponUpgrade = 0;
        }
    }

    public int GetWeaponId(uint weaponSet, LogicalHand hand)
    {
        int id = 0;
        for (int i = 0; i < this.weaponItemSets.Length; i++)
        {
            if ((this.weaponItemSets[i].weaponSet == weaponSet) && (this.weaponItemSets[i].handIndex == hand))
            {
                id = this.weaponItemSets[i].id;
            }
        }
        return id;
    }

    public byte GetWeaponUpgrade(uint weaponSet, LogicalHand hand)
    {
        return (from each in this.weaponItemSets
            where (each.weaponSet == weaponSet) && (each.handIndex == hand)
            select each).FirstOrDefault<WeaponVars>().upgrade;
    }

    private void LoadBasicValuesFromData()
    {
        this.hitPoints = this.data.hitPoints;
        this.maxEncumbrance = CombatData.singleton.maxEncumbrance;
        for (int i = 0; i < this.recovery.recovery.Length; i++)
        {
            this.recovery.recovery[i] = this.data.recovery;
        }
        Array.Copy(this.data.defense.defense, this.defense.defense, this.data.defense.defense.Length);
        Array.Copy(this.data.resistance.resistance, this.resistance.resistance, this.data.resistance.resistance.Length);
        Array.Copy(this.data.attackBonus.attackBonus, this.attackBonus.attackBonus, this.data.attackBonus.attackBonus.Length);
        this.weaponItemSets = new WeaponVars[4];
        this.attackFeatSets = new AttackFeatVars[12];
        this.implementItemSets = new WeaponVars[2];
        this.expendableFeatSets = new AttackFeatVars[12];
        this.utilityFeats = new AttackFeatVars[2];
        this.armorItem = new NonWeaponVars(this.data.armorId, this.data.armorUpgrade, 1);
        this.passiveFeatIds = this.data.GetPassiveFeatIds();
        this.refreshFeatIds = this.data.GetRefreshFeatIds();
        this.upgradeFeatIds = this.data.GetUpgradeFeatIds();
        Array.Copy(this.data.skills.skills, this.skills.skills, this.data.skills.skills.Length);
        this.FindFeatureFeat();
        this.FindArmorFeat();
        this.attackTier = this.data.attackTier;
        this.baseDamage = this.data.baseDamage;
        this.moveSpeed = this.data.moveSpeed;
        this.effectPower = this.data.effectPower;
        this.effectDefense = this.data.effectDefense;
        this.idleAnimSetName = this.data.idleAnimSetName;
        this.combatAnimSetName = this.data.combatAnimSetName;
        this.drawAnimNumber = this.data.drawAnimNumber;
        this.mainhandModelName = this.data.mainhandModelName;
        this.offhandModelName = this.data.offhandModelName;
    }

    public void LoadInventoryStats(InventoryItem[] bodySlots, AdvancementVars advancementVars)
    {
        for (int i = 0; i < WEAPON_SLOT_INDEXES.Length; i++)
        {
            this.weaponItemSets[i] = new WeaponVars((bodySlots != null) ? bodySlots[WEAPON_SLOT_INDEXES[i]].staticItemId : 0, (bodySlots != null) ? bodySlots[WEAPON_SLOT_INDEXES[i]].upgrade : ((byte) 0), (uint) (i / 2), i % 2);
        }
        for (uint j = 0; j < IMPLEMENT_SLOT_INDEXES.Length; j++)
        {
            this.implementItemSets[j] = new WeaponVars((bodySlots != null) ? bodySlots[IMPLEMENT_SLOT_INDEXES[j]].staticItemId : 0, (bodySlots != null) ? bodySlots[IMPLEMENT_SLOT_INDEXES[j]].upgrade : ((byte) 0), j, 0);
        }
        if (bodySlots != null)
        {
            this.UpdateArmor(bodySlots[0].staticItemId, bodySlots[0].upgrade, advancementVars);
            this.UpdateGearCache(bodySlots);
        }
    }

    public void LoadNpcNonAttackFeats(CombatClassData data)
    {
        this.passiveFeatIds = data.GetPassiveFeatIds();
        this.refreshFeatIds = data.GetRefreshFeatIds();
        this.upgradeFeatIds = data.GetUpgradeFeatIds();
        if (this.refreshFeatIds.Length != 2)
        {
            Array.Resize<int>(ref this.refreshFeatIds, 2);
        }
        this.FindFeatureFeat();
        this.FindArmorFeat();
    }

    public void LoadOffensiveFeats(int[] attackFeatIds, int[] expendableFeatIds, int[] utilityFeatIds, AdvancementVars advancementVars)
    {
        int num;
        for (num = 0; num < this.attackFeatSets.Length; num++)
        {
            this.attackFeatSets[num] = new AttackFeatVars(attackFeatIds[num], advancementVars.GetFeatLevelByFeatId(attackFeatIds[num]), (uint) (num / 6), num % 6);
        }
        for (num = 0; num < this.expendableFeatSets.Length; num++)
        {
            this.expendableFeatSets[num] = new AttackFeatVars(expendableFeatIds[num], advancementVars.GetFeatLevelByFeatId(expendableFeatIds[num]), (uint) (num / 6), num % 6);
        }
        for (num = 0; num < this.utilityFeats.Length; num++)
        {
            this.utilityFeats[num] = new AttackFeatVars(utilityFeatIds[num], advancementVars.GetFeatLevelByFeatId(utilityFeatIds[num]), 0, num % 2);
        }
    }

    public void LoadOffensiveFeats(int[] attackFeatIds, byte[] attackFeatLevels, int[] expendableFeatIds, byte[] expendableFeatLevels, int[] utilityFeatIds, byte[] utilityFeatLevels)
    {
        int num;
        for (num = 0; num < this.attackFeatSets.Length; num++)
        {
            this.attackFeatSets[num] = new AttackFeatVars(attackFeatIds[num], attackFeatLevels[num], (uint) (num / 6), num % 6);
        }
        for (num = 0; num < this.expendableFeatSets.Length; num++)
        {
            this.expendableFeatSets[num] = new AttackFeatVars(expendableFeatIds[num], expendableFeatLevels[num], (uint) (num / 6), num % 6);
        }
        for (num = 0; num < this.utilityFeats.Length; num++)
        {
            this.utilityFeats[num] = new AttackFeatVars(utilityFeatIds[num], utilityFeatLevels[num], 0, num % 2);
        }
    }

    public void LoadPlayerNonAttackFeats(int[] passiveFeatIds_, int[] refreshFeatIds_, AdvancementVars advancementVars)
    {
        NonAttackFeatData.AdjustForLevel(ref passiveFeatIds_, advancementVars);
        NonAttackFeatData.AdjustForLevel(ref refreshFeatIds_, advancementVars);
        this.passiveFeatIds = passiveFeatIds_;
        this.refreshFeatIds = refreshFeatIds_;
        this.upgradeFeatIds = advancementVars.BuildUpgradeFeatIds();
        if (this.refreshFeatIds.Length != 2)
        {
            Array.Resize<int>(ref this.refreshFeatIds, 2);
        }
        this.FindFeatureFeat();
        this.FindArmorFeat();
    }

    public void LoadStaticWeapons(CombatClassData data)
    {
        for (int i = 0; i < this.weaponItemSets.Length; i++)
        {
            this.weaponItemSets[i] = new WeaponVars(data.weaponIds[i], data.weaponUpgrades[i], (uint) (i / 2), i % 2);
        }
        for (uint j = 0; j < this.implementItemSets.Length; j++)
        {
            this.implementItemSets[j] = new WeaponVars(data.implementIds[j], data.implementUpgrades[j], j, 0);
        }
    }

    public void RecalculateUpgrades(CombatVars combatVars)
    {
        int num;
        int num2;
        this.hitPoints = 0;
        this.maxEncumbrance = 0;
        this.power = 0;
        this.speedPercent = 0;
        this.regenPercent = 0;
        this.recovery.Clear();
        this.defense.Clear();
        this.resistance.Clear();
        this.attackBonus.Clear();
        this.skills.Clear();
        NonAttackFeatData data = null;
        for (num = 0; num < this.upgradeFeatIds.Length; num++)
        {
            if (this.upgradeFeatIds[num] != 0)
            {
                NonAttackFeatData featById = NonAttackFeatData.GetFeatById(this.upgradeFeatIds[num]);
                if (featById != null)
                {
                    if (featById.channel == Combat.Channel.Racial)
                    {
                        data = featById;
                    }
                    else if (featById.combatMods != null)
                    {
                        num2 = 0;
                        while (num2 < featById.combatMods.Length)
                        {
                            CombatCore.RecalculateStats(0, featById.combatMods[num2], combatVars, Combat.Channel.Upgrade, 0, 0);
                            num2++;
                        }
                    }
                }
            }
        }
        if (data != null)
        {
            for (num2 = 0; num2 < data.combatMods.Length; num2++)
            {
                CombatCore.RecalculateStats(0, data.combatMods[num2], combatVars, Combat.Channel.Racial, 0, 0);
            }
        }
        this.hitPoints += this.data.hitPoints;
        this.maxEncumbrance += CombatData.singleton.maxEncumbrance;
        for (num = 0; num < this.recovery.recovery.Length; num++)
        {
            this.recovery.recovery[num] += this.data.recovery;
        }
        for (num = 0; num < this.defense.defense.Length; num++)
        {
            this.defense.defense[num] += this.data.defense.defense[num];
        }
        for (num = 0; num < this.resistance.resistance.Length; num++)
        {
            this.resistance.resistance[num] += this.data.resistance.resistance[num];
        }
        for (num = 0; num < this.attackBonus.attackBonus.Length; num++)
        {
            this.attackBonus.attackBonus[num] += this.data.attackBonus.attackBonus[num];
        }
    }

    public void ReloadFeatLevels(CombatVars combatVars, AdvancementVars advancementVars)
    {
        int[] attackFeatIds = (from each in this.attackFeatSets select each.id).ToArray<int>();
        int[] expendableFeatIds = (from each in this.expendableFeatSets select each.id).ToArray<int>();
        int[] utilityFeatIds = (from each in this.utilityFeats select each.id).ToArray<int>();
        this.LoadOffensiveFeats(attackFeatIds, expendableFeatIds, utilityFeatIds, advancementVars);
        this.LoadPlayerNonAttackFeats(this.passiveFeatIds, this.refreshFeatIds, advancementVars);
        this.UpdateArmor(this.armorItem.id, this.armorItem.upgrade, advancementVars);
        combatVars.RecalculatePassives();
        this.RecalculateUpgrades(combatVars);
    }

    public void SetAttackFeat(AttackFeatVars newAttack)
    {
        this.attackFeatSets[(int) ((IntPtr) ((newAttack.weaponSet * 6) + newAttack.hotbarIndex))] = newAttack;
    }

    public void SetExpendable(AttackFeatVars newExpendable)
    {
        this.expendableFeatSets[(int) ((IntPtr) ((newExpendable.weaponSet * 6) + newExpendable.hotbarIndex))] = newExpendable;
    }

    public void SetImplement(WeaponVars newImplement)
    {
        this.implementItemSets[newImplement.weaponSet] = newImplement;
    }

    public void SetNonAttackFeat(Combat.FeatType featType, int newFeatId, int index)
    {
        if (featType == Combat.FeatType.Refresh)
        {
            this.refreshFeatIds[index % 2] = newFeatId;
        }
    }

    public void SetPassiveFeat(int oldFeatId, int newFeatId)
    {
        NonAttackFeatData featById = NonAttackFeatData.GetFeatById(newFeatId);
        NonAttackFeatData data2 = (oldFeatId == 0) ? null : NonAttackFeatData.GetFeatById(oldFeatId);
        int index = -1;
        List<NonAttackFeatData> list = new List<NonAttackFeatData>();
        for (int i = 0; i < this.passiveFeatIds.Length; i++)
        {
            if (this.passiveFeatIds[i] != 0)
            {
                if ((data2 != null) && (this.passiveFeatIds[i] == data2.id))
                {
                    index = i;
                }
                if (this.passiveFeatIds[i] == featById.id)
                {
                    this.passiveFeatIds[i] = 0;
                }
                else
                {
                    NonAttackFeatData item = NonAttackFeatData.GetFeatById(this.passiveFeatIds[i]);
                    if (item.type == featById.type)
                    {
                        list.Add(item);
                    }
                }
            }
        }
        if (index > -1)
        {
            this.passiveFeatIds[index] = featById.id;
        }
        else
        {
            SparseArray.Add<int>(ref this.passiveFeatIds, featById.id, SparseArray.INVALID_ID, 0);
        }
        this.FindArmorFeat();
        this.FindFeatureFeat();
    }

    public void SetUtility(AttackFeatVars newUtility)
    {
        this.utilityFeats[newUtility.hotbarIndex] = newUtility;
    }

    public void SetWeapon(WeaponVars newWeapon)
    {
        this.weaponItemSets[(int) ((IntPtr) ((newWeapon.weaponSet * 2) + newWeapon.handIndex))] = newWeapon;
    }

    public void TemporaryPlayerLoad(CombatClassData sourceData)
    {
        this.data = sourceData;
        this.combatClassId = sourceData.id;
        this.LoadBasicValuesFromData();
        this.fallbackAttackLevel = 0;
    }

    public void UnsetPassiveFeat(int oldFeatId)
    {
        for (int i = 0; i < this.passiveFeatIds.Length; i++)
        {
            if (this.passiveFeatIds[i] == oldFeatId)
            {
                this.passiveFeatIds[i] = 0;
            }
        }
        this.FindArmorFeat();
        this.FindFeatureFeat();
    }

    public void UpdateArmor(int armorId, byte upgrade, AdvancementVars advancementVars)
    {
        byte featLevelByFeatAdvancementId = 0;
        CombatArmor item = ItemDatabase.GetItem(armorId) as CombatArmor;
        if (item != null)
        {
            featLevelByFeatAdvancementId = advancementVars.GetFeatLevelByFeatAdvancementId(item.proficiencyAdvId);
        }
        this.armorItem = new NonWeaponVars(armorId, upgrade, featLevelByFeatAdvancementId);
    }

    private void UpdateExpendables(int id, byte upgrade, uint weaponSet)
    {
        CombatWeapon weaponById = CombatWeapon.GetWeaponById(id);
        if ((weaponById == null) || (weaponById.VerifyExpendables(this.expendableFeatSets, weaponSet, upgrade) != CombatWeapon.ExpendableVerification.VALID))
        {
            AttackFeatVars[] expendableFeatSets = this.expendableFeatSets;
            for (int i = 0; i < this.expendableFeatSets.Length; i++)
            {
                if (this.expendableFeatSets[i].weaponSet == weaponSet)
                {
                    this.expendableFeatSets[i] = new AttackFeatVars(0, 0, this.expendableFeatSets[i].weaponSet, this.expendableFeatSets[i].hotbarIndex);
                }
            }
        }
    }

    public void UpdateGearCache(InventoryItem[] equippedItems)
    {
        this.ClearGearCache();
        for (int i = 0; i < equippedItems.Length; i++)
        {
            if (!InventoryItem.EMPTY_MATCH(equippedItems[i]))
            {
                BasicItemData item = ItemDatabase.GetItem(equippedItems[i].staticItemId);
                this.AddGearToCache(item);
                this.AddWeaponToCache(item, equippedItems[i].upgrade);
            }
        }
    }

    public void UpdateWeapons(Entity entity, InventoryItem[] equippedItems, CombatWeapon weapon)
    {
        if (weapon.type == CombatWeapon.WeaponType.WEAPON)
        {
            this.VerifyWeapon(entity, equippedItems, weapon, 9, 0, 0);
            this.VerifyWeapon(entity, equippedItems, weapon, 10, 0, 1);
            this.VerifyWeapon(entity, equippedItems, weapon, 11, 1, 0);
            this.VerifyWeapon(entity, equippedItems, weapon, 12, 1, 1);
        }
        else if (weapon.type == CombatWeapon.WeaponType.IMPLEMENT)
        {
            int index = 13;
            uint num2 = 0;
            if (this.WeaponChanged(this.implementItemSets[num2], equippedItems[index]))
            {
                this.SetImplement(new WeaponVars(equippedItems[index].staticItemId, equippedItems[index].upgrade, num2, 0));
                this.UpdateExpendables(equippedItems[index].staticItemId, equippedItems[index].upgrade, num2);
            }
            index = 14;
            num2 = 1;
            if (this.WeaponChanged(this.implementItemSets[num2], equippedItems[index]))
            {
                this.SetImplement(new WeaponVars(equippedItems[index].staticItemId, equippedItems[index].upgrade, num2, 0));
                this.UpdateExpendables(equippedItems[index].staticItemId, equippedItems[index].upgrade, num2);
            }
        }
    }

    private void VerifyWeapon(Entity entity, InventoryItem[] equippedItems, CombatWeapon weapon, int slot, uint weaponSet, int handIndex)
    {
        int index = ((int) (weaponSet * 2)) + handIndex;
        if (this.WeaponChanged(this.weaponItemSets[index], equippedItems[slot]))
        {
            if (equippedItems[slot].staticItemId != 0)
            {
                FeatSelection.SetWeapon(entity, new WeaponVars(equippedItems[slot].staticItemId, equippedItems[slot].upgrade, weaponSet, handIndex));
            }
            else
            {
                FeatSelection.UnsetWeapon(entity, weapon, weaponSet, handIndex);
            }
        }
    }

    private bool WeaponChanged(WeaponVars combat, InventoryItem item)
    {
        return ((combat.id != item.staticItemId) || (combat.upgrade != item.upgrade));
    }

    public enum LogicalHand
    {
        MAIN_HAND,
        OFF_HAND
    }
}

