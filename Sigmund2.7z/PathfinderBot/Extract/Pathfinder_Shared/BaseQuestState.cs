﻿using System;
using System.Collections.Generic;

public class BaseQuestState : DataClass
{
    public int actorId = 0;
    public bool autoDisplayBlob = false;
    public int blobId = 0;
    public int[] dependentQuests = null;
    public string description = "";
    public bool despawn = false;
    public Dictionary<int, string> flavorTexts = new Dictionary<int, string>();
    public EscalationConst.Flow flow = (EscalationConst.Flow.INCOMPLETE | EscalationConst.Flow.NEXT | EscalationConst.Flow.SUCCESS);
    public int goal = 1;
    public string hudText = "";
    public int incrementEvent = 0;
    public int[] interactKeywordIds = null;
    public int locationId = 0;
    public string responseText = null;
    public int rewardTableId = 0;
    public EscalationConst.StateType stateType = EscalationConst.StateType.INVALID;
    public EventTimeLimit timeLimit = null;
    public int triggerKeywordId = 0;

    private void _ParseInteractOptions(ref int rowIndex)
    {
        string str;
        DataClass.GetLCaseCellValue(2, rowIndex, out str);
        if (str == "despawn")
        {
            this.despawn = true;
        }
        else
        {
            DataClass.OutputErrorMessage(2, rowIndex, "Please move your \"InteractKeywords\" to a separate line: " + str);
        }
    }

    public string GetFlavorText(Entity entity)
    {
        if ((entity.npcQuestVars != null) && (this.flavorTexts.Count != 0))
        {
            foreach (KeyValuePair<int, string> pair in this.flavorTexts)
            {
                if (entity.npcQuestVars.IsActor(pair.Key))
                {
                    return pair.Value;
                }
            }
        }
        return null;
    }

    public bool MatchesEntity(Entity entity)
    {
        return (((entity == null) && (this.actorId == 0)) || (((entity != null) && (entity.npcQuestVars != null)) && entity.npcQuestVars.IsActor(this.actorId)));
    }

    public void ParseStateDetails(ref int curRow, ref QuestData eachQuest, int actorCol, int goalCol, int responseCol, int hudTextCol, int descriptionCol, int locationNameCol, int triggerKeywordCol)
    {
        if (actorCol != -1)
        {
            DataClass.GetLCaseCellValue(actorCol, curRow, out this.name);
            if (eachQuest.eventQuest)
            {
                this.actorId = DataClass.GenerateId(base.name);
            }
            else
            {
                DataClass.GetIdFromForeignName<GlobalActorData>(actorCol, curRow, out this.actorId);
            }
        }
        else
        {
            base.name = this.stateType.ToString();
        }
        if (goalCol != -1)
        {
            DataClass.GetCellValue(goalCol, curRow, out this.goal);
        }
        if (responseCol != -1)
        {
            DataClass.GetCellValue(responseCol, curRow, out this.responseText);
        }
        if (locationNameCol != -1)
        {
            DataClass.GetIdFromForeignName<LocationTriggerData>(locationNameCol, curRow, out this.locationId);
        }
        if (triggerKeywordCol != -1)
        {
            DataClass.GetIdFromForeignName<InteractKeywordData>(triggerKeywordCol, curRow, out this.triggerKeywordId);
        }
        DataClass.GetCellValue(hudTextCol, curRow, out this.hudText);
        if (string.IsNullOrEmpty(this.hudText))
        {
            DataClass.OutputErrorMessage(hudTextCol, curRow, "State has no hud text: " + this.ToString());
        }
        DataClass.GetCellValue(descriptionCol, curRow, out this.description);
        if (this.actorId != 0)
        {
            eachQuest.allActorIds.Add(this.actorId);
        }
        eachQuest.states.Add(this);
        curRow++;
    }

    public void ParseStateOptions(ref int rowIndex)
    {
        if (this.stateType == EscalationConst.StateType.Interact)
        {
            this._ParseInteractOptions(ref rowIndex);
        }
    }

    public override string ToString()
    {
        return string.Concat(new object[] { "<State ", this.stateType, " ", base.name, " ", this.goal, " times with hud text: ", this.hudText });
    }
}

