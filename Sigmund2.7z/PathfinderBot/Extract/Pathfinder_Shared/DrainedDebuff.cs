﻿using System;

public class DrainedDebuff : CombatStackBuff
{
    public DrainedDebuff() : base("Drained", Combat.Channel.Weakness, Combat.EffectType.Detrimental)
    {
        base.recoveryBonusType = RecoveryType.Drained;
    }

    public static DrainedDebuff Create()
    {
        return new DrainedDebuff();
    }

    public override CombatBuffVars Initialize(uint combatTick, CombatModifier mod, CombatVars target, int additionalDefense)
    {
        int resistanceBonus = target.GetResistanceBonus(ResistanceType.Physical);
        return base.Initialize(combatTick, mod, target, resistanceBonus);
    }

    public override void RecalculationPhase(CombatBuffVars buff, uint combatTick)
    {
        int num = -CombatCore.RoundToInt(buff.stacks * 0.5f);
        int specific = buff.owner.tempDefenses.Channel(base.channel).GetSpecific(DefenseType.Base);
        if (num < specific)
        {
            buff.owner.tempDefenses.Channel(base.channel).SetSpecific(DefenseType.Base, num);
        }
        specific = buff.owner.tempAttackBonuses.Channel(base.channel).GetSpecific(AttackType.Base);
        if (num < specific)
        {
            buff.owner.tempAttackBonuses.Channel(base.channel).SetSpecific(AttackType.Base, num);
        }
    }
}

