﻿using GNetwork;
using GSerialize;
using Newtonsoft.Json;
using System;
using System.Runtime.InteropServices;

[DataContract]
public class SettlementRecord : IDataCopyable<SettlementRecord>, IDBRecord<uint>
{
    [JsonIgnore, DataRestrict]
    private SettlementData _settlementData;
    [JsonIgnore]
    public int allySettlementCount;
    [DataMember]
    public uint[] allySettlementIds;
    [DataMember, DataRestrict]
    public bool deleted;
    [DataMember]
    public ulong[] invitedCompanyIds;
    [DataMember]
    public uint[] invitedSettlementIds;
    [DataMember]
    public ushort mapId;
    [JsonIgnore]
    public int memberCompanyCount;
    [DataMember]
    public ulong[] memberCompanyIds;
    [DataMember]
    public ulong ownerCompanyId;
    [DataMember]
    public uint pvpWindowBegin;
    [DataMember]
    public uint pvpWindowDuration;
    [DataMember(Name="id", EmitDefaultValue=false)]
    public uint settlementId;
    [DataMember]
    public string settlementName;
    [DataMember]
    public int staticDataId;
    [DataMember]
    public uint towersOwned;

    public SettlementRecord()
    {
        this.staticDataId = 0;
        this.settlementName = string.Empty;
        this.towersOwned = 0;
        this.mapId = 0;
    }

    public SettlementRecord(string displayName_, int staticDataId_, ushort mapId_)
    {
        this.staticDataId = staticDataId_;
        this.settlementName = displayName_;
        this.towersOwned = 0;
        this.mapId = mapId_;
    }

    public void AddAlly(uint settlementId)
    {
        if (this.allySettlementIds == null)
        {
            this.allySettlementIds = new uint[] { settlementId };
        }
        else
        {
            for (int j = 0; j < this.allySettlementIds.Length; j++)
            {
                if (this.allySettlementIds[j] == settlementId)
                {
                    return;
                }
            }
            SparseArray.OrderedAdd<uint>(ref this.allySettlementIds, settlementId, i => i == 0, 0);
            this.allySettlementCount = this.CountAllies();
        }
    }

    public void AddAllyInvite(uint settlementId)
    {
        if ((this.allySettlementIds == null) || !SparseArray.Contains<uint>(this.allySettlementIds, settlementId))
        {
            if (this.invitedSettlementIds == null)
            {
                this.invitedSettlementIds = new uint[] { settlementId };
            }
            else if (!SparseArray.Contains<uint>(this.invitedSettlementIds, settlementId))
            {
                SparseArray.OrderedAdd<uint>(ref this.invitedSettlementIds, settlementId, i => i == 0, 0);
            }
        }
    }

    public void AddCompany(ulong companyId, bool isOwner = false)
    {
        if (isOwner)
        {
            this.ownerCompanyId = companyId;
        }
        if (this.memberCompanyIds == null)
        {
            this.memberCompanyIds = new ulong[] { companyId };
        }
        else
        {
            for (int j = 0; j < this.memberCompanyIds.Length; j++)
            {
                if (this.memberCompanyIds[j] == companyId)
                {
                    return;
                }
            }
            SparseArray.OrderedAdd<ulong>(ref this.memberCompanyIds, companyId, i => i == 0L, 0L);
            this.memberCompanyCount = this.CountCompanies();
        }
    }

    public void AddInvite(ulong companyId)
    {
        if ((this.memberCompanyIds == null) || !SparseArray.Contains<ulong>(this.memberCompanyIds, companyId))
        {
            if (this.invitedCompanyIds == null)
            {
                this.invitedCompanyIds = new ulong[] { companyId };
            }
            else if (!SparseArray.Contains<ulong>(this.invitedCompanyIds, companyId))
            {
                SparseArray.OrderedAdd<ulong>(ref this.invitedCompanyIds, companyId, i => i == 0L, 0L);
            }
        }
    }

    public int CountAllies()
    {
        return SparseArray.Count<uint>(this.allySettlementIds, GroupConst.EMPTY_SETTLEMENT);
    }

    public int CountCompanies()
    {
        return SparseArray.Count<ulong>(this.memberCompanyIds, GroupConst.EMPTY_COMPANY);
    }

    public void DataCopyTo(ref SettlementRecord target, byte syncTargetLevel)
    {
        if (SocietySync.SyncToAll(syncTargetLevel))
        {
            target.settlementId = this.settlementId;
            target.staticDataId = this.staticDataId;
            target.settlementName = this.settlementName;
            target.mapId = this.mapId;
            target.pvpWindowBegin = this.pvpWindowBegin;
            target.pvpWindowDuration = this.pvpWindowDuration;
            target.towersOwned = this.towersOwned;
            target.memberCompanyCount = this.memberCompanyCount;
            target.allySettlementCount = this.allySettlementCount;
        }
        if (SocietySync.SyncToAll(syncTargetLevel))
        {
            target.ownerCompanyId = this.ownerCompanyId;
            DataSerializerUtils.DataCopyField<ulong>(this.memberCompanyIds, ref target.memberCompanyIds);
            DataSerializerUtils.DataCopyField<ulong>(this.invitedCompanyIds, ref target.invitedCompanyIds);
            DataSerializerUtils.DataCopyField<uint>(this.allySettlementIds, ref target.allySettlementIds);
            DataSerializerUtils.DataCopyField<uint>(this.invitedSettlementIds, ref target.invitedSettlementIds);
        }
    }

    public bool DataEquals(SettlementRecord target, byte syncTargetLevel)
    {
        if (object.ReferenceEquals(target, null))
        {
            return false;
        }
        bool flag = true;
        if (SocietySync.SyncToAll(syncTargetLevel))
        {
            flag = ((((((((flag && (target.settlementId == this.settlementId)) && (target.staticDataId == this.staticDataId)) && (target.settlementName == this.settlementName)) && (target.mapId == this.mapId)) && (target.pvpWindowBegin == this.pvpWindowBegin)) && (target.pvpWindowDuration == this.pvpWindowDuration)) && (target.towersOwned == this.towersOwned)) && (target.memberCompanyCount == this.memberCompanyCount)) && (target.allySettlementCount == this.allySettlementCount);
        }
        if (SocietySync.SyncToAll(syncTargetLevel))
        {
            flag = ((((flag && (target.ownerCompanyId == this.ownerCompanyId)) && SparseArray.DeepEqualsWithIndex<ulong>(this.memberCompanyIds, target.memberCompanyIds)) && SparseArray.DeepEqualsWithIndex<ulong>(this.invitedCompanyIds, target.invitedCompanyIds)) && SparseArray.DeepEqualsWithIndex<uint>(this.allySettlementIds, target.allySettlementIds)) && SparseArray.DeepEqualsWithIndex<uint>(this.invitedSettlementIds, target.invitedSettlementIds);
        }
        return flag;
    }

    public uint GetDBKey()
    {
        return this.settlementId;
    }

    public byte MaxTrainerLevel()
    {
        if (this.settlementData == null)
        {
            return 1;
        }
        float num = this.settlementData.baseTrainerLevel + (this.settlementData.trainerLevelPerTower * this.towersOwned);
        return Math.Max((byte) num, 1);
    }

    public void OnDBLoad()
    {
    }

    public void OnDBUnload()
    {
    }

    public void OnDBWrite()
    {
    }

    public static SettlementRecord PopFromBuffer(IBitBufferRead buffer)
    {
        SettlementRecord record = new SettlementRecord {
            settlementId = buffer.PopUInt(),
            staticDataId = buffer.PopInt(),
            settlementName = buffer.PopString(),
            mapId = buffer.PopUShort(),
            pvpWindowBegin = buffer.PopUInt(),
            pvpWindowDuration = buffer.PopUInt(),
            towersOwned = buffer.PopUInt(),
            ownerCompanyId = buffer.PopULong(),
            memberCompanyIds = new ulong[0],
            invitedCompanyIds = new ulong[0],
            allySettlementIds = new uint[0],
            invitedSettlementIds = new uint[0]
        };
        buffer.PopULongArrayDelta(ref record.memberCompanyIds);
        buffer.PopULongArrayDelta(ref record.invitedCompanyIds);
        buffer.PopUIntArrayDelta(ref record.allySettlementIds);
        buffer.PopUIntArrayDelta(ref record.invitedSettlementIds);
        return record;
    }

    public static void PushToBuffer(IBitBufferWrite buffer, SettlementRecord settlement)
    {
        buffer.PushUInt(settlement.settlementId);
        buffer.PushInt(settlement.staticDataId);
        buffer.PushString(settlement.settlementName);
        buffer.PushUShort(settlement.mapId);
        buffer.PushUInt(settlement.pvpWindowBegin);
        buffer.PushUInt(settlement.pvpWindowDuration);
        buffer.PushUInt(settlement.towersOwned);
        buffer.PushULong(settlement.ownerCompanyId);
        buffer.PushULongArrayDelta(settlement.memberCompanyIds, null);
        buffer.PushULongArrayDelta(settlement.invitedCompanyIds, null);
        buffer.PushUIntArrayDelta(settlement.allySettlementIds, null);
        buffer.PushUIntArrayDelta(settlement.invitedSettlementIds, null);
    }

    public void RemoveAlly(uint settlementId)
    {
        if (this.allySettlementIds != null)
        {
            for (int i = 0; i < this.allySettlementIds.Length; i++)
            {
                if (this.allySettlementIds[i] == settlementId)
                {
                    this.allySettlementIds[i] = 0;
                    break;
                }
            }
            this.allySettlementCount = this.CountAllies();
        }
    }

    public void RemoveAllyInvite(uint settlementId)
    {
        if (this.invitedSettlementIds != null)
        {
            for (int i = 0; i < this.invitedSettlementIds.Length; i++)
            {
                if (this.invitedSettlementIds[i] == settlementId)
                {
                    this.invitedSettlementIds[i] = 0;
                    break;
                }
            }
        }
    }

    public void RemoveCompany(ulong companyId)
    {
        if (this.memberCompanyIds != null)
        {
            int num;
            for (num = 0; num < this.memberCompanyIds.Length; num++)
            {
                if (this.memberCompanyIds[num] == companyId)
                {
                    this.memberCompanyIds[num] = 0L;
                    break;
                }
            }
            if (this.ownerCompanyId == companyId)
            {
                this.ownerCompanyId = 0L;
                for (num = 0; num < this.memberCompanyIds.Length; num++)
                {
                    if (this.memberCompanyIds[num] != 0L)
                    {
                        this.ownerCompanyId = this.memberCompanyIds[num];
                        break;
                    }
                }
            }
            this.memberCompanyCount = this.CountCompanies();
        }
    }

    public void RemoveInvite(ulong companyId)
    {
        if (this.invitedCompanyIds != null)
        {
            for (int i = 0; i < this.invitedCompanyIds.Length; i++)
            {
                if (this.invitedCompanyIds[i] == companyId)
                {
                    this.invitedCompanyIds[i] = 0L;
                    break;
                }
            }
        }
    }

    public override string ToString()
    {
        return string.Concat(new object[] { "<Settlement:", this.settlementName, ", Lv:", this.MaxTrainerLevel(), ">" });
    }

    [DataRestrict, JsonIgnore]
    public SettlementData settlementData
    {
        get
        {
            if ((this._settlementData == null) || (this._settlementData.id != this.staticDataId))
            {
                SettlementData.settlementsByDataId.TryGetValue(this.staticDataId, out this._settlementData);
            }
            return this._settlementData;
        }
    }
}

