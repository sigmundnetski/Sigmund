﻿using System;

public class DataTableOfContents : TableOfContents
{
    public SourceFileData[] sourceFiles;

    public DataTableOfContents()
    {
        base.type = null;
        base.typeHash = string.Empty;
        this.sourceFiles = null;
    }

    public DataTableOfContents(string inType, uint[] inOffsets, SourceFileData[] iSourceFiles) : base(inType, inOffsets)
    {
        this.sourceFiles = iSourceFiles;
    }
}

