﻿using GNetwork;
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

public class ItemOffer : IComparable<ItemOffer>
{
    public Item.Container container;
    public ulong curPrice;
    private const float DEFAULT_DURATION = 2f;
    public DateTime endDate;
    public ulong endPrice;
    public InventoryItem item;
    public uint linkId;
    public OfferType offerType;
    public DateTime startDate;
    public ulong startPrice;

    private ItemOffer()
    {
    }

    public ItemOffer(Item.Container container_, uint linkId_, OfferType offerType_, InventoryItem item_, ulong startPrice_, ulong endPrice_)
    {
        DateTime utcNow = DateTime.UtcNow;
        this.Init(container_, linkId_, offerType_, item_, startPrice_, endPrice_, utcNow, utcNow.AddDays(2.0));
    }

    public ItemOffer(Item.Container container_, uint linkId_, OfferType offerType_, InventoryItem item_, ulong startPrice_, ulong endPrice_, DateTime startDate_, DateTime endDate_)
    {
        this.Init(container_, linkId_, offerType_, item_, startPrice_, endPrice_, startDate_, endDate_);
    }

    public int CompareTo(ItemOffer rhs)
    {
        if (this.curPrice < rhs.curPrice)
        {
            return -1;
        }
        if (this.curPrice > rhs.curPrice)
        {
            return 1;
        }
        if (this.startDate < rhs.startDate)
        {
            return -1;
        }
        if (this.startDate > rhs.startDate)
        {
            return 1;
        }
        return 0;
    }

    private void Init(Item.Container container_, uint linkId_, OfferType offerType_, InventoryItem item_, ulong startPrice_, ulong endPrice_, DateTime startDate_, DateTime endDate_)
    {
        this.linkId = linkId_;
        this.container = container_;
        this.offerType = offerType_;
        item_.DataCopyTo(ref this.item, 0xff);
        this.startPrice = startPrice_;
        this.endPrice = endPrice_;
        this.startDate = startDate_;
        this.endDate = endDate_;
        this.curPrice = startPrice_;
    }

    public static ItemOffer[] PopArrayFromBuffer(IBitBufferRead buffer)
    {
        int num = buffer.PopInt();
        ItemOffer[] offerArray = new ItemOffer[num];
        for (int i = 0; i < num; i++)
        {
            if (buffer.PopBool())
            {
                offerArray[i] = PopFromBuffer(buffer);
            }
            else
            {
                offerArray[i] = null;
            }
        }
        return offerArray;
    }

    public static ItemOffer PopFromBuffer(IBitBufferRead buffer)
    {
        ItemOffer offer = new ItemOffer {
            curPrice = buffer.PopULong(),
            startDate = DateTime.FromBinary(buffer.PopLong()),
            endDate = DateTime.FromBinary(buffer.PopLong()),
            startPrice = buffer.PopULong(),
            endPrice = buffer.PopULong(),
            offerType = (OfferType) buffer.PopByte(),
            container = (Item.Container) buffer.PopByte()
        };
        offer.item.Read(buffer, ref offer.item);
        return offer;
    }

    public static void PushArrayToBuffer(IBitBufferWrite buffer, ItemOffer[] offers)
    {
        buffer.PushInt(offers.Length);
        for (int i = 0; i < offers.Length; i++)
        {
            bool flag = offers[i] != null;
            buffer.PushBool(flag);
            if (flag)
            {
                PushToBuffer(buffer, offers[i]);
            }
        }
    }

    public static void PushArrayToBuffer(IBitBufferWrite buffer, IList<ItemOffer> offers, int limit = 0)
    {
        int count = offers.Count;
        if ((limit > 0) && (limit < count))
        {
            count = limit;
        }
        buffer.PushInt(count);
        for (int i = 0; i < count; i++)
        {
            bool flag = offers[i] != null;
            buffer.PushBool(flag);
            if (flag)
            {
                PushToBuffer(buffer, offers[i]);
            }
        }
    }

    public static void PushToBuffer(IBitBufferWrite buffer, ItemOffer offer)
    {
        buffer.PushULong(offer.curPrice);
        buffer.PushLong(offer.startDate.ToBinary());
        buffer.PushLong(offer.endDate.ToBinary());
        buffer.PushULong(offer.startPrice);
        buffer.PushULong(offer.endPrice);
        buffer.PushByte((byte) offer.offerType);
        buffer.PushByte((byte) offer.container);
        offer.item.Write(buffer, InventoryItem.EMPTY);
    }

    public override string ToString()
    {
        return string.Format("{0}(Item:{1}+{2},{3}  Container:{4},{5}  Price:{6},{7},{8}  Dates:{9},{10}", new object[] { this.offerType, this.item.staticItemId, this.item.upgrade, this.item.GetDisplayName(true), this.container, this.linkId, this.startPrice, this.curPrice, this.endPrice, this.startDate, this.endDate });
    }

    public enum OfferType : byte
    {
        BID = 1,
        OFFER = 0
    }
}

