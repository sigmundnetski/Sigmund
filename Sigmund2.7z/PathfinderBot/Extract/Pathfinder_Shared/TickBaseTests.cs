﻿using System;

internal class TickBaseTests : UUnitTestCase
{
    [UUnitTestMethod]
    public void MultipleTicks()
    {
        TestTick tick2;
        TestTick tick = new TestTick();
        tick.FixedUpdate();
        try
        {
            tick2 = new TestTick();
            UUnitAssert.Fail("SecondTick should throw an exception.  Failing to do so means that the tick systems aren't exclusive/synchronized, and therefore not safe.");
        }
        catch (TickException)
        {
        }
        tick.StopTicking();
        tick2 = new TestTick();
        tick2.FixedUpdate();
        try
        {
            tick.FixedUpdate();
            UUnitAssert.Fail("firstTick should throw an exception.  Failing to do so means that the tick systems aren't exclusive/synchronized, and therefore not safe.");
        }
        catch (TickException)
        {
        }
        tick2.StopTicking();
    }
}

