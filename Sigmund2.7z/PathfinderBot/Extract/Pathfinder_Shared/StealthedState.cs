﻿using System;

public class StealthedState : TimedStateBuff
{
    public StealthedState() : base("Stealthed", Combat.Channel.State, Combat.EffectType.Beneficial)
    {
    }

    public static StealthedState Create()
    {
        return new StealthedState();
    }

    public override void Expire(CombatBuffVars buff, uint combatTick)
    {
        buff.owner.StealthMode(false);
    }

    public override bool Expired(CombatBuffVars buff, uint combatTick)
    {
        return !buff.owner.stealthMode;
    }

    public override CombatBuffVars Initialize(uint combatTick, CombatModifier mod, CombatVars target, int additionalDefense)
    {
        CombatBuffVars vars = base.Initialize(combatTick, mod, target, additionalDefense);
        vars.displayOnClient = false;
        return vars;
    }

    public override void TimePhase(CombatBuffVars buff, uint combatTick)
    {
        if (buff.owner.movementType == CombatVars.MovementType.RUN)
        {
            this.Expire(buff, combatTick);
        }
        if (buff.expirationTick <= combatTick)
        {
            buff.expirationTick = combatTick + CombatData.singleton.roundTimeInTicks;
        }
    }

    public override void UpdateBuff(CombatBuffVars buff, uint combatTick, CombatModifier mod, CombatEffect effect)
    {
        base.UpdateBuff(buff, combatTick, mod, effect);
    }
}

