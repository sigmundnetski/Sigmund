﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using UnityEngine;

public class EntityCore
{
    private static uint _makeUniqueId = 0;
    private static Entity[] entities = new Entity[0xfa0];
    public static ushort MAP_ID = 0;
    private const ulong MAP_MASK = 0xffff00000000L;
    private const int MAP_MASK_SHIFT = 0x20;
    public const ushort MAX_ENTITIES = 0xfa0;
    private const float MAX_VERTICAL_DROP = 30f;
    private static Dictionary<uint, Entity> playerEntities = new Dictionary<uint, Entity>();
    private static ushort previousSlot = 0;
    private const ulong SLOT_MASK = 18446462598732840960L;
    private const int SLOT_MASK_SHIFT = 0x30;
    private static Dictionary<ForeignEntityId, ushort> slotIdLookup = new Dictionary<ForeignEntityId, ushort>();
    private const ulong TRUE_UNIQUE_MASK = 0xffffffffffffL;
    private const ulong UNIQUE_MASK = 0xffffffffL;
    private const int UNIQUE_MASK_SHIFT = 0;
    private static Queue<ushort> waitingToBeReclaimed = new Queue<ushort>();

    public static void DisableEntityCore()
    {
        entities = null;
        playerEntities = null;
        slotIdLookup = null;
        waitingToBeReclaimed = null;
    }

    public static float EntityDistance(EntityId lhsId, EntityId rhsId)
    {
        GameObject gameObjectByEntityId = GetGameObjectByEntityId(ref lhsId);
        GameObject obj3 = GetGameObjectByEntityId(ref rhsId);
        if ((gameObjectByEntityId == null) || (obj3 == null))
        {
            return -1f;
        }
        Transform transform = gameObjectByEntityId.transform;
        Transform transform2 = obj3.transform;
        Vector3 vector = transform.position - transform2.position;
        return vector.magnitude;
    }

    private static ushort FindNextSlot()
    {
        ushort previousSlot = EntityCore.previousSlot;
        while ((entities[previousSlot] != null) && (entities[previousSlot].isValid != Entity.EntityStatus.INVALID))
        {
            previousSlot = (ushort) (previousSlot + 1);
            if (previousSlot == 0xfa0)
            {
                previousSlot = 0;
            }
            if (previousSlot == EntityCore.previousSlot)
            {
                previousSlot = 0xfa0;
                break;
            }
        }
        EntityCore.previousSlot = (ushort) (previousSlot % 0xfa0);
        return previousSlot;
    }

    public static IEnumerable<Entity> GetAllAiEntities()
    {
        return (from entity in entities
            where ((entity != null) && (entity.isValid == Entity.EntityStatus.VALID)) && (entity.aiVars != null)
            select entity);
    }

    public static IEnumerable<Entity> GetAllEntities(bool includeGhosts = true)
    {
        return (from entity in entities
            where ((entity != null) && (entity.isValid == Entity.EntityStatus.VALID)) && (includeGhosts || (entity.ownerMapId == MAP_ID))
            select entity);
    }

    public static IEnumerable<KeyValuePair<ForeignEntityId, Entity>> GetAllEntitiesAsKvp(bool includeGhosts = true)
    {
        return (from entity in entities
            where ((entity != null) && (entity.isValid == Entity.EntityStatus.VALID)) && (includeGhosts || (entity.ownerMapId == MAP_ID))
            select new KeyValuePair<ForeignEntityId, Entity>(GetForeignId(entity.entityId), entity));
    }

    public static IEnumerable<Entity> GetAllNonPlayerEntities(bool includeGhosts = true)
    {
        return (from entity in entities
            where (((entity != null) && (entity.isValid == Entity.EntityStatus.VALID)) && (entity.playerId == 0)) && (includeGhosts || (entity.ownerMapId == MAP_ID))
            select entity);
    }

    public static IEnumerable<Entity> GetAllPlayerEntities(bool includeGhosts = true)
    {
        return (from entity in playerEntities
            where includeGhosts || (entity.Value.ownerMapId == MAP_ID)
            select entity.Value);
    }

    public static float GetDistanceSq(GameObject lhs, GameObject rhs)
    {
        Vector3 vector = lhs.transform.position - rhs.transform.position;
        return (((vector.x * vector.x) + (vector.y * vector.y)) + (vector.z * vector.z));
    }

    public static float GetDistanceSq(Vector3 lhs, Vector3 rhs)
    {
        Vector3 vector = lhs - rhs;
        return (((vector.x * vector.x) + (vector.y * vector.y)) + (vector.z * vector.z));
    }

    public static Entity GetEntity(EntityId entityId)
    {
        if (entityId == EntityId.INVALID_ID)
        {
            return null;
        }
        ushort slotFromId = GetSlotFromId(entityId);
        if (((entities[slotFromId] != null) && (entities[slotFromId].isValid == Entity.EntityStatus.VALID)) && Match(entities[slotFromId].entityId, entityId))
        {
            return entities[slotFromId];
        }
        return GetEntity(GetForeignId(entityId));
    }

    public static Entity GetEntity(ref EntityId entityId)
    {
        if (entityId == EntityId.INVALID_ID)
        {
            return null;
        }
        ushort slotFromId = GetSlotFromId(entityId);
        if (((entities[slotFromId] != null) && (entities[slotFromId].isValid == Entity.EntityStatus.VALID)) && Match(entities[slotFromId].entityId, entityId))
        {
            return entities[slotFromId];
        }
        return GetEntity(GetForeignId(entityId));
    }

    public static Entity GetEntity(ForeignEntityId entityId)
    {
        ushort num;
        if ((entityId != ForeignEntityId.INVALID_ID) && (((slotIdLookup.TryGetValue(entityId, out num) && (entities[num].isValid == Entity.EntityStatus.VALID)) && (entities[num] != null)) && Match(entities[num].entityId, (EntityId) entityId)))
        {
            return entities[num];
        }
        return null;
    }

    public static Entity GetEntity(GameObject go)
    {
        EntityVars component = null;
        if (go != null)
        {
            component = go.GetComponent<EntityVars>();
        }
        if (component == null)
        {
            return null;
        }
        return GetEntity(ref component.entityId);
    }

    public static Entity GetEntity(Transform trns)
    {
        EntityVars component = null;
        if (trns != null)
        {
            component = trns.GetComponent<EntityVars>();
        }
        if (component == null)
        {
            return null;
        }
        return GetEntity(ref component.entityId);
    }

    public static Entity GetEntityByPlayerId(uint playerId)
    {
        Entity entity;
        playerEntities.TryGetValue(playerId, out entity);
        return entity;
    }

    public static EntityId GetEntityId(ForeignEntityId entityId)
    {
        Entity entity = GetEntity(entityId);
        if (entity != null)
        {
            return entity.entityId;
        }
        return (EntityId) entityId;
    }

    public static EntityId GetEntityId(GameObject go)
    {
        EntityVars component = null;
        if (go != null)
        {
            component = go.GetComponent<EntityVars>();
        }
        if (component == null)
        {
            return EntityId.INVALID_ID;
        }
        Entity entity = GetEntity(ref component.entityId);
        if (entity == null)
        {
            return EntityId.INVALID_ID;
        }
        return entity.entityId;
    }

    public static Vector3 GetEntityPosition(EntityId entityId)
    {
        GameObject gameObjectByEntityId = GetGameObjectByEntityId(ref entityId);
        if (gameObjectByEntityId == null)
        {
            return new Vector3(float.NaN, float.NaN, float.NaN);
        }
        return gameObjectByEntityId.transform.position;
    }

    public static void GetFilteredEntities(Predicate<Entity> filter, ref Entity[] output, bool includeGhosts = true)
    {
        SparseArray.Clear<Entity>(ref output);
        uint probableIndex = 0;
        for (int i = 0; i < entities.Length; i++)
        {
            if ((((entities[i] != null) && (entities[i].isValid == Entity.EntityStatus.VALID)) && (includeGhosts || (entities[i].ownerMapId == MAP_ID))) && filter(entities[i]))
            {
                probableIndex = SparseArray.Add<Entity>(ref output, entities[i], probableIndex);
            }
        }
    }

    public static ForeignEntityId GetForeignId(EntityId entityId)
    {
        return (((ForeignEntityId) entityId) & ((ForeignEntityId) 0xffffffffffffL));
    }

    public static GameObject GetGameObjectByEntityId(ref EntityId entityId)
    {
        GameObject gameObject = null;
        Entity entity = GetEntity(ref entityId);
        if (entity != null)
        {
            gameObject = entity.gameObject;
        }
        return gameObject;
    }

    public static float GetHorizontalDistanceSq(Vector3 lhs, Vector3 rhs)
    {
        Vector3 vector = lhs - rhs;
        return ((vector.x * vector.x) + (vector.z * vector.z));
    }

    internal static ushort GetMapFromId(EntityId entityId)
    {
        return (ushort) ((entityId & 0xffff00000000L) >> 0x20);
    }

    public static int GetNpcCount()
    {
        int num = 0;
        for (int i = 0; i < entities.Length; i++)
        {
            if (((entities[i] != null) && (entities[i].isValid == Entity.EntityStatus.VALID)) && (entities[i].playerVars == null))
            {
                num++;
            }
        }
        return num;
    }

    public static int GetPlayerCount(bool includeGhosts = true)
    {
        return GetAllPlayerEntities(includeGhosts).Count<Entity>();
    }

    public static GameObject GetPlayerGameObject(uint playerId)
    {
        Entity entity;
        playerEntities.TryGetValue(playerId, out entity);
        return ((entity != null) ? entity.gameObject : null);
    }

    public static ushort GetSlotFromId(EntityId entityId)
    {
        return (ushort) ((entityId & -281474976710656L) >> 0x30);
    }

    public static ushort GetSlotId(Entity entity)
    {
        ushort index = (ushort) ((entity.entityId & -281474976710656L) >> 0x30);
        if ((entities[index] == null) || !Match(entities[index].entityId, entity.entityId))
        {
            slotIdLookup.TryGetValue(GetForeignId(entity.entityId), out index);
        }
        return index;
    }

    internal static uint GetUniquenessBitsFromId(EntityId entityId)
    {
        return (uint) (entityId & ((EntityId) 0xffffffffL));
    }

    private static uint MakeUniqueId()
    {
        _makeUniqueId++;
        return _makeUniqueId;
    }

    public static bool Match(EntityId entityIdA, EntityId entityIdB)
    {
        return ((entityIdA & ((EntityId) 0xffffffffffffL)) == (entityIdB & ((EntityId) 0xffffffffffffL)));
    }

    public static void MoveToLayer(Transform root, int layer)
    {
        Stack<Transform> stack = new Stack<Transform>();
        stack.Push(root);
        while (stack.Count != 0)
        {
            Transform transform = stack.Pop();
            transform.gameObject.layer = layer;
            foreach (Transform transform2 in transform)
            {
                stack.Push(transform2);
            }
        }
    }

    public static void RegisterEntity(Entity entity)
    {
        ushort slotFromId = GetSlotFromId(entity.entityId);
        if (!object.ReferenceEquals(GetEntity(ref entity.entityId), entity))
        {
            slotFromId = FindNextSlot();
            if (slotFromId == 0xffff)
            {
                return;
            }
        }
        entities[slotFromId] = entity;
        slotIdLookup.Add(GetForeignId(entity.entityId), slotFromId);
        if (entity.createType == GConst.CreateType.PLAYER)
        {
            uint num2 = (entity.playerRecord != null) ? entity.playerRecord.playerId : entity.playerId;
            if (num2 == 0)
            {
                throw new Exception("PlayerId cannot be 0");
            }
            entity.playerId = num2;
            playerEntities[num2] = entity;
        }
    }

    public static Entity RequestNewEntity()
    {
        ushort index = FindNextSlot();
        if (index == 0xfa0)
        {
            return null;
        }
        if (entities[index] == null)
        {
            entities[index] = new Entity();
        }
        entities[index].ownerMapId = MAP_ID;
        entities[index].ownerSequence = 1;
        uint num2 = MakeUniqueId();
        Entity entity = entities[index];
        entity.entityId = (((EntityId) (index << 0x30)) | ((EntityId) (MAP_ID << 0x20))) | ((EntityId) num2);
        return entity;
    }

    public static Vector3 SnapToGround(Vector3 input)
    {
        RaycastHit hit;
        Vector3 origin = input + new Vector3(0f, 30f, 0f);
        if (Physics.Raycast(origin, Vector3.down, out hit, 60f, ((int) 1) << LayerMask.NameToLayer("Default")))
        {
            input = hit.point;
        }
        return input;
    }

    public static bool SyncFixedUpdate()
    {
        while (waitingToBeReclaimed.Count > 0)
        {
            ushort index = waitingToBeReclaimed.Dequeue();
            if (entities[index].isValid == Entity.EntityStatus.LIMBO)
            {
                entities[index].isValid = Entity.EntityStatus.INVALID;
                previousSlot = Math.Min(previousSlot, index);
            }
        }
        if (!IsClient)
        {
            foreach (Entity entity in GetAllEntities(false))
            {
                entity.UpdatePositionFromGameObject();
            }
        }
        return true;
    }

    public static bool TryParseEntityId(string str, out EntityId entityId)
    {
        ulong num;
        entityId = EntityId.INVALID_ID;
        if (ulong.TryParse(str, out num))
        {
            entityId = (EntityId) num;
        }
        return (entityId != EntityId.INVALID_ID);
    }

    public static void UnitTest_Reinitialize(ushort testMapId)
    {
        MAP_ID = testMapId;
        SparseArray.Clear<Entity>(ref entities);
        playerEntities.Clear();
        slotIdLookup.Clear();
        waitingToBeReclaimed.Clear();
        previousSlot = 0;
    }

    public static void UnregisterEntity(Entity entity)
    {
        Entity entity2;
        ushort slotId = GetSlotId(entity);
        if (!object.ReferenceEquals(entity, entities[slotId]))
        {
            throw new Exception("Trying to unregister entity that doesn't exist");
        }
        waitingToBeReclaimed.Enqueue(slotId);
        slotIdLookup.Remove(GetForeignId(entity.entityId));
        if (((entity.createType == GConst.CreateType.PLAYER) && playerEntities.TryGetValue(entity.playerId, out entity2)) && object.ReferenceEquals(entity2, entity))
        {
            playerEntities.Remove(entity.playerId);
        }
    }

    public static bool IsClient
    {
        get
        {
            return (MAP_ID == 0);
        }
    }
}

