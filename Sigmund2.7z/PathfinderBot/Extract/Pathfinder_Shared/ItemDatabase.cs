﻿using System;
using System.Collections.Generic;
using System.Linq;

[StrongDependency(typeof(GearItemData)), StrongDependency(typeof(TreasureBoxItemData)), StrongDependency(typeof(CombatArmor)), StrongDependency(typeof(SpoilsItemData)), NoExcelData, StrongDependency(typeof(CraftRecipeItemData)), StrongDependency(typeof(CurrencyItemData)), StrongDependency(typeof(ExpendableRecipeItemData)), StrongDependency(typeof(CraftingItemData)), StrongDependency(typeof(CombatWeapon)), StrongDependency(typeof(WondrousItemData))]
public class ItemDatabase : DataClass
{
    public CombatArmor[] allArmorData;
    public CraftingItemData[] allCraftingData;
    public CraftRecipeItemData[] allCraftRecipeData;
    public CurrencyItemData[] allCurrencyData;
    public ExpendableRecipeItemData[] allExpendableRecipeData;
    public GearItemData[] allGearData;
    public SpoilsItemData[] allSpoilsData;
    public TreasureBoxItemData[] allTreasureBoxData;
    public CombatWeapon[] allWeaponData;
    public WondrousItemData[] allWondrousData;
    public static Dictionary<int, BasicItemData> itemById = new Dictionary<int, BasicItemData>();
    public static Dictionary<string, BasicItemData> itemByName = new Dictionary<string, BasicItemData>();
    public static Dictionary<string, BasicItemData> itemByRedeemName = new Dictionary<string, BasicItemData>();

    public static IEnumerable<T> GetAll<T>() where T: BasicItemData
    {
        return (from eachPair in itemById
            where eachPair.Value is T
            select (T) eachPair.Value);
    }

    public static BasicItemData GetItem(int staticItemId)
    {
        BasicItemData data = null;
        if (!((staticItemId == 0) || itemById.TryGetValue(staticItemId, out data)))
        {
            GLog.LogWarning(new object[] { "Cannot Fetch Item:", staticItemId });
        }
        return data;
    }

    internal static void Index(BasicItemData each)
    {
        itemById[each.id] = each;
        itemByName[each.name.ToLower()] = each;
        if (!string.IsNullOrEmpty(each.redeemName))
        {
            itemByRedeemName[each.redeemName] = each;
        }
    }

    public override List<DataClass> MergeData()
    {
        IEnumerable<DataClass> enumerable = DataClass.GetData(typeof(CombatArmor));
        IEnumerable<DataClass> enumerable2 = DataClass.GetData(typeof(CombatWeapon));
        IEnumerable<DataClass> enumerable3 = DataClass.GetData(typeof(CraftingItemData));
        IEnumerable<DataClass> enumerable4 = DataClass.GetData(typeof(CraftRecipeItemData));
        IEnumerable<DataClass> enumerable5 = DataClass.GetData(typeof(CurrencyItemData));
        IEnumerable<DataClass> enumerable6 = DataClass.GetData(typeof(ExpendableRecipeItemData));
        IEnumerable<DataClass> enumerable7 = DataClass.GetData(typeof(GearItemData));
        IEnumerable<DataClass> enumerable8 = DataClass.GetData(typeof(SpoilsItemData));
        IEnumerable<DataClass> enumerable9 = DataClass.GetData(typeof(TreasureBoxItemData));
        IEnumerable<DataClass> enumerable10 = DataClass.GetData(typeof(WondrousItemData));
        foreach (CombatArmor armor in enumerable)
        {
            Index(armor);
        }
        foreach (CombatWeapon weapon in enumerable2)
        {
            Index(weapon);
        }
        foreach (CraftingItemData data in enumerable3)
        {
            Index(data);
        }
        foreach (CraftRecipeItemData data2 in enumerable4)
        {
            Index(data2);
        }
        foreach (CurrencyItemData data3 in enumerable5)
        {
            Index(data3);
        }
        foreach (ExpendableRecipeItemData data4 in enumerable6)
        {
            Index(data4);
        }
        foreach (GearItemData data5 in enumerable7)
        {
            Index(data5);
        }
        foreach (SpoilsItemData data6 in enumerable8)
        {
            Index(data6);
        }
        foreach (TreasureBoxItemData data7 in enumerable9)
        {
            Index(data7);
        }
        foreach (WondrousItemData data8 in enumerable10)
        {
            Index(data8);
        }
        ItemDatabase database = new ItemDatabase {
            allArmorData = (from each in enumerable select (CombatArmor) each).ToArray<CombatArmor>(),
            allWeaponData = (from each in enumerable2 select (CombatWeapon) each).ToArray<CombatWeapon>(),
            allCraftingData = (from each in enumerable3 select (CraftingItemData) each).ToArray<CraftingItemData>(),
            allCraftRecipeData = (from each in enumerable4 select (CraftRecipeItemData) each).ToArray<CraftRecipeItemData>(),
            allCurrencyData = (from each in enumerable5 select (CurrencyItemData) each).ToArray<CurrencyItemData>(),
            allExpendableRecipeData = (from each in enumerable6 select (ExpendableRecipeItemData) each).ToArray<ExpendableRecipeItemData>(),
            allGearData = (from each in enumerable7 select (GearItemData) each).ToArray<GearItemData>(),
            allSpoilsData = (from each in enumerable8 select (SpoilsItemData) each).ToArray<SpoilsItemData>(),
            allTreasureBoxData = (from each in enumerable9 select (TreasureBoxItemData) each).ToArray<TreasureBoxItemData>(),
            allWondrousData = (from each in enumerable10 select (WondrousItemData) each).ToArray<WondrousItemData>()
        };
        return new List<DataClass> { database };
    }

    public static void OnLoad(List<DataClass> objects)
    {
        ItemDatabase database = (ItemDatabase) objects.First<DataClass>();
        foreach (CombatArmor armor in database.allArmorData)
        {
            Index(armor);
        }
        foreach (CombatWeapon weapon in database.allWeaponData)
        {
            Index(weapon);
        }
        foreach (CraftingItemData data in database.allCraftingData)
        {
            Index(data);
        }
        CraftingItemData.IndexCraftingMaterials(database.allCraftingData);
        foreach (CraftRecipeItemData data2 in database.allCraftRecipeData)
        {
            Index(data2);
        }
        foreach (CurrencyItemData data3 in database.allCurrencyData)
        {
            Index(data3);
        }
        CurrencyItemData.IndexCurrency(database.allCurrencyData);
        foreach (ExpendableRecipeItemData data4 in database.allExpendableRecipeData)
        {
            Index(data4);
        }
        foreach (GearItemData data5 in database.allGearData)
        {
            Index(data5);
        }
        foreach (SpoilsItemData data6 in database.allSpoilsData)
        {
            Index(data6);
        }
        foreach (TreasureBoxItemData data7 in database.allTreasureBoxData)
        {
            Index(data7);
        }
        foreach (WondrousItemData data8 in database.allWondrousData)
        {
            Index(data8);
        }
    }

    public static void UnittestSetUp(params BasicItemData[] items)
    {
        foreach (BasicItemData data in items)
        {
            Index(data);
        }
    }

    public static void UnittestTearDown()
    {
        itemById.Clear();
        itemByName.Clear();
        itemByRedeemName.Clear();
    }
}

