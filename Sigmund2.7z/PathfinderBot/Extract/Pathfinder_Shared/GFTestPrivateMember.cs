﻿using System;

internal class GFTestPrivateMember
{
    private int id;

    public int Id
    {
        get
        {
            return this.id;
        }
        set
        {
            this.id = value;
        }
    }
}

