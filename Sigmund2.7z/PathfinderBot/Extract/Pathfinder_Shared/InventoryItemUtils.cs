﻿using GNetwork;
using System;
using System.Collections.Generic;

public static class InventoryItemUtils
{
    private static uint[] _testQtys = new uint[0x20];
    public const int DEFAULT_INVENTORY_SIZE = 0x10;

    private static bool _InventoryContains(ref uint[] testQtys, InventoryItem[] _inventory, InventoryItem[] testItems)
    {
        Predicate<InventoryItem> match = null;
        for (int i = 0; i < testItems.Length; i++)
        {
            if (!InventoryItem.EMPTY_MATCH(testItems[i]))
            {
                if (match == null)
                {
                    match = each => testItems[i].Stackable(each);
                }
                int index = SparseArray.IndexOf<InventoryItem>(_inventory, match);
                if (index == -1)
                {
                    return false;
                }
                testQtys[index] += testItems[i].quantity;
            }
        }
        for (int j = 0; j < _inventory.Length; j++)
        {
            if ((testQtys[j] > 0) && (testQtys[j] > _inventory[j].quantity))
            {
                return false;
            }
        }
        return true;
    }

    public static void AddWithAutoStack(ref InventoryItem[] _inventory, InventoryItem newItem)
    {
        if (_inventory == null)
        {
            _inventory = new InventoryItem[0x10];
        }
        if (!TryStackItem(_inventory, newItem))
        {
            SparseArray.Add<InventoryItem>(ref _inventory, newItem, InventoryItem.EMPTY_MATCH, InventoryItem.EMPTY);
        }
    }

    public static void AddWithAutoStack(ref InventoryItem[] _inventory, IEnumerable<InventoryItem> newItems)
    {
        if (_inventory == null)
        {
            _inventory = new InventoryItem[0x10];
        }
        uint probableIndex = 0;
        if (newItems != null)
        {
            foreach (InventoryItem item in newItems)
            {
                if (!(InventoryItem.EMPTY_MATCH(item) || TryStackItem(_inventory, item)))
                {
                    probableIndex = SparseArray.Add<InventoryItem>(ref _inventory, item, probableIndex, InventoryItem.EMPTY_MATCH, InventoryItem.EMPTY);
                }
            }
        }
    }

    public static float CalclulateEncumbrance(InventoryItem[] items)
    {
        float num = 0f;
        if (items != null)
        {
            for (int i = 0; i < items.Length; i++)
            {
                if (!InventoryItem.EMPTY_MATCH(items[i]))
                {
                    num += items[i].GetEncumbrance();
                }
            }
        }
        return num;
    }

    public static void CopyAll(InventoryItem[] source, ref InventoryItem[] destination)
    {
        if (source != null)
        {
            SparseArray.EnsureCapacity<InventoryItem>(ref destination, SparseArray.Count<InventoryItem>(source, InventoryItem.EMPTY_MATCH));
            foreach (InventoryItem item in source)
            {
                if (!InventoryItem.EMPTY_MATCH(item))
                {
                    AddWithAutoStack(ref destination, item);
                }
            }
        }
    }

    public static InventoryItem ExtractItem(InventoryItem[] items, InventoryItem goal)
    {
        int index = -1;
        for (int i = 0; i < items.Length; i++)
        {
            if (items[i].Stackable(goal) && (items[i].quantity >= goal.quantity))
            {
                index = i;
            }
        }
        return ExtractItem(items, index, goal.quantity);
    }

    public static InventoryItem ExtractItem(InventoryItem[] items, int index, uint quantity)
    {
        if ((index < 0) || (index >= items.Length))
        {
            return InventoryItem.EMPTY;
        }
        if (items[index].quantity <= quantity)
        {
            InventoryItem item = items[index];
            items[index] = InventoryItem.EMPTY;
            return item;
        }
        items[index].quantity -= quantity;
        return InventoryItem.ChangeQuantity(items[index], quantity);
    }

    public static InventoryItem ExtractItemUpToQuantity(InventoryItem[] items, InventoryItem goal)
    {
        if (items == null)
        {
            return InventoryItem.EMPTY;
        }
        int index = -1;
        for (int i = 0; i < items.Length; i++)
        {
            if (items[i].Stackable(goal))
            {
                index = i;
            }
        }
        return ExtractItem(items, index, goal.quantity);
    }

    public static InventoryItem ExtractItemUpToQuantity(InventoryItem[] items, InventoryItem goal, uint quantity)
    {
        if (items == null)
        {
            return InventoryItem.EMPTY;
        }
        int index = -1;
        for (int i = 0; i < items.Length; i++)
        {
            if (items[i].Stackable(goal))
            {
                index = i;
            }
        }
        return ExtractItem(items, index, quantity);
    }

    public static uint GetSpecificCount(InventoryItem[] _inventory, int staticItemId)
    {
        uint num = 0;
        if (_inventory != null)
        {
            for (int i = 0; i < _inventory.Length; i++)
            {
                if (_inventory[i].staticItemId == staticItemId)
                {
                    num += _inventory[i].quantity;
                }
            }
        }
        return num;
    }

    public static bool InventoryContains(InventoryItem[] _inventory, InventoryItem[] testItems)
    {
        SparseArray.EnsureCapacity<uint>(ref _testQtys, _inventory.Length);
        SparseArray.Clear<uint>(ref _testQtys, 0);
        return _InventoryContains(ref _testQtys, _inventory, testItems);
    }

    public static bool InventoryContains(InventoryItem[] _inventory, InventoryItem[][] testItems)
    {
        if (_inventory == null)
        {
            return false;
        }
        SparseArray.EnsureCapacity<uint>(ref _testQtys, _inventory.Length);
        SparseArray.Clear<uint>(ref _testQtys, 0);
        for (int i = 0; i < testItems.Length; i++)
        {
            if (!_InventoryContains(ref _testQtys, _inventory, testItems[i]))
            {
                return false;
            }
        }
        return true;
    }

    public static int InventoryHash(InventoryItem[] items)
    {
        int num = 0;
        if (items != null)
        {
            num += items.Length;
            for (int i = 0; i < items.Length; i++)
            {
                num += items[i].staticItemId * GConst.aBunchOfPrimes[i % GConst.aBunchOfPrimes.Length];
                num += (int) items[i].quantity;
                num += items[i].upgrade;
                num += items[i].durability;
                num += items[i].materialColorId;
                num += items[i].userColorId1;
                num += items[i].userColorId2;
            }
        }
        return num;
    }

    public static InventoryItem[] PopArrayFromBuffer(IBitBufferRead buffer)
    {
        if (!buffer.PopBool())
        {
            return null;
        }
        int num = buffer.PopInt();
        InventoryItem[] itemArray = new InventoryItem[num];
        for (int i = 0; i < num; i++)
        {
            if (buffer.PopBool())
            {
                itemArray[i].Read(buffer, ref itemArray[i]);
            }
            else
            {
                itemArray[i] = InventoryItem.EMPTY;
            }
        }
        return itemArray;
    }

    public static bool PopArrayFromBuffer(IBitBufferRead buffer, ref InventoryItem[] emptyContainer)
    {
        SparseArray.Clear<InventoryItem>(ref emptyContainer, InventoryItem.EMPTY);
        if (!buffer.PopBool())
        {
            return false;
        }
        int size = buffer.PopInt();
        SparseArray.EnsureCapacity<InventoryItem>(ref emptyContainer, size);
        for (int i = 0; i < size; i++)
        {
            if (buffer.PopBool())
            {
                emptyContainer[i].Read(buffer, ref emptyContainer[i]);
            }
            else
            {
                emptyContainer[i] = InventoryItem.EMPTY;
            }
        }
        return true;
    }

    public static void PushToBuffer(IBitBufferWrite buffer, InventoryItem[] items)
    {
        buffer.PushBool(items != null);
        if (items != null)
        {
            buffer.PushInt(items.Length);
            for (int i = 0; i < items.Length; i++)
            {
                bool flag = !InventoryItem.EMPTY_MATCH(items[i]);
                buffer.PushBool(flag);
                if (flag)
                {
                    items[i].Write(buffer, InventoryItem.EMPTY);
                }
            }
        }
    }

    public static uint TotalItemCount(InventoryItem[] _inventory)
    {
        uint num = 0;
        if (_inventory != null)
        {
            for (int i = 0; i < _inventory.Length; i++)
            {
                num += _inventory[i].quantity;
            }
        }
        return num;
    }

    public static bool TransferItem(InventoryItem[] source, ref InventoryItem[] destination, InventoryItem moveItem)
    {
        moveItem = ExtractItem(source, moveItem);
        if (InventoryItem.EMPTY_MATCH(moveItem))
        {
            return false;
        }
        AddWithAutoStack(ref destination, moveItem);
        return true;
    }

    public static bool TransferItemUpToQuantity(InventoryItem[] source, ref InventoryItem[] destination, InventoryItem moveItem)
    {
        moveItem = ExtractItemUpToQuantity(source, moveItem);
        if (InventoryItem.EMPTY_MATCH(moveItem))
        {
            return false;
        }
        AddWithAutoStack(ref destination, moveItem);
        return true;
    }

    public static bool TryStackItem(InventoryItem[] _inventory, InventoryItem newItem)
    {
        for (int i = 0; i < _inventory.Length; i++)
        {
            if (_inventory[i].Stackable(newItem))
            {
                _inventory[i] = InventoryItem.ChangeQuantity(_inventory[i], _inventory[i].quantity + newItem.quantity);
                return true;
            }
        }
        return false;
    }
}

