﻿using System;

public interface IDataCopyable<T>
{
    void DataCopyTo(ref T target, byte syncTargetLevel);
    bool DataEquals(T target, byte syncTargetLevel);
}

