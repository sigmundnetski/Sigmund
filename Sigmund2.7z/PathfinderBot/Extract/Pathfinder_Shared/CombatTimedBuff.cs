﻿using System;
using System.Runtime.InteropServices;

public abstract class CombatTimedBuff : CombatBuff
{
    public CombatTimedBuff(string name_, Combat.Channel channel_, Combat.EffectType effectType_) : base(name_, channel_, effectType_)
    {
    }

    public override void Expire(CombatBuffVars buff, uint combatTick)
    {
        buff.expirationTick = combatTick;
    }

    public override bool Expired(CombatBuffVars buff, uint combatTick)
    {
        return (combatTick >= buff.expirationTick);
    }

    protected virtual void GetDuration(CombatModifier mod, CombatEffect effect, int defenseBonus, out uint duration, out float successModifier)
    {
        int marginOfSuccess = effect.attackMarginOfSuccess - defenseBonus;
        successModifier = ((float) effect.effectModifier) / 100f;
        if (base.effectType == Combat.EffectType.Detrimental)
        {
            successModifier *= CombatCore.GetPartialMultiplier(marginOfSuccess);
        }
        duration = (uint) CombatCore.RoundToInt(mod.tickDuration * successModifier);
    }

    public override string GetLogString(CombatModifier mod, CombatEffect effect, int defenseBonus)
    {
        uint num;
        float num2;
        this.GetDuration(mod, effect, defenseBonus, out num, out num2);
        return GUtil.GetQuickText().Append(base.name).Append(" (").Append(CombatCore.SecondsFromTicks(num)).Append(" seconds)").ToString();
    }

    public override CombatBuffVars Initialize(uint combatTick, CombatModifier mod, CombatVars target, int additionalDefense)
    {
        CombatBuffVars vars = base.Initialize(combatTick, mod, target, additionalDefense);
        vars.expirationTick = 0;
        return vars;
    }

    public override void ResolutionPhase(CombatBuffVars buff, uint combatTick)
    {
    }

    public override void TimePhase(CombatBuffVars buff, uint combatTick)
    {
    }

    public override void UpdateBuff(CombatBuffVars buff, uint combatTick, CombatModifier mod, CombatEffect effect)
    {
        uint num;
        float num2;
        buff.applierEntityId = (effect.source == null) ? EntityId.INVALID_ID : effect.source.entityId;
        buff.updatedTick = combatTick;
        this.GetDuration(mod, effect, buff.defenseBonus, out num, out num2);
        buff.successPercentage = (uint) CombatCore.RoundToInt(num2 * 100f);
        num += combatTick;
        if (num > buff.expirationTick)
        {
            buff.expirationTick = num;
        }
    }
}

