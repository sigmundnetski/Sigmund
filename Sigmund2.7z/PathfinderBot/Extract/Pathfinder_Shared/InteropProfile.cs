﻿using System;
using System.Runtime.InteropServices;

internal class InteropProfile : UUnitTestCase
{
    private static IntPtr arrayPointer;
    private static bool dllFound = false;
    private static int length = 0x7d0;
    private static Position[] newArray;
    private static int NUM_RUNS = 0x3e8;

    [DllImport("UnitTestPlugin")]
    private static extern void AllocateUnmanagedArray();
    [DllImport("UnitTestPlugin")]
    private static extern void ReleaseUnmanagedArray();
    [DllImport("UnitTestPlugin")]
    private static extern IntPtr ReturnPreallocatedUnmanagedArray(IntPtr array, int length);
    [DllImport("UnitTestPlugin")]
    private static extern IntPtr ReturnUnmanagedArray(ref int length);
    protected override void SetUp()
    {
        newArray = new Position[length];
        for (int i = 0; i < newArray.Length; i++)
        {
            newArray[i].posX = 100f;
            newArray[i].posY = 200f;
            newArray[i].posZ = 300f;
            newArray[i].fwdX = 400f;
            newArray[i].fwdY = 500f;
            newArray[i].fwdZ = 600f;
            newArray[i].fwdW = 700f;
        }
        arrayPointer = Marshal.AllocCoTaskMem(length * Marshal.SizeOf(typeof(Position)));
        try
        {
            AllocateUnmanagedArray();
            dllFound = true;
        }
        catch (DllNotFoundException)
        {
        }
    }

    protected override void TearDown()
    {
        Marshal.FreeCoTaskMem(arrayPointer);
        if (dllFound)
        {
            ReleaseUnmanagedArray();
        }
        dllFound = false;
    }

    [UUnitProfileMethod]
    public void TestManagedArray()
    {
        if (!dllFound)
        {
            throw new DllNotFoundException("Unable to find UnitTestPlugin.dll");
        }
        for (int i = 0; i < NUM_RUNS; i++)
        {
            UseManagedArray(newArray, newArray.Length);
            for (int j = 0; j < newArray.Length; j++)
            {
                Position position = newArray[j];
                UUnitAssert.Equals(position.posX, 5f, 0.0001f, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
                UUnitAssert.Equals(position.posY, 10f, 0.0001f, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
                UUnitAssert.Equals(position.posZ, 15f, 0.0001f, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
            }
        }
    }

    [UUnitProfileMethod]
    public void TestUnmanagedArray()
    {
        if (!dllFound)
        {
            throw new DllNotFoundException("Unable to find UnitTestPlugin.dll");
        }
        for (int i = 0; i < NUM_RUNS; i++)
        {
            int length = 0;
            IntPtr ptr = ReturnUnmanagedArray(ref length);
            for (int j = 0; j < length; j++)
            {
                Position position = (Position) Marshal.PtrToStructure(ptr, typeof(Position));
                UUnitAssert.Equals(position.posX, 5f, 0.0001f, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
                UUnitAssert.Equals(position.posY, 10f, 0.0001f, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
                UUnitAssert.Equals(position.posZ, 15f, 0.0001f, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
                ptr = new IntPtr(ptr.ToInt64() + Marshal.SizeOf(typeof(Position)));
            }
        }
    }

    [UUnitProfileMethod]
    public void TestUnmanagedArrayAllocedInManaged()
    {
        if (!dllFound)
        {
            throw new DllNotFoundException("Unable to find UnitTestPlugin.dll");
        }
        for (int i = 0; i < NUM_RUNS; i++)
        {
            IntPtr ptr = ReturnPreallocatedUnmanagedArray(arrayPointer, length);
            for (int j = 0; j < length; j++)
            {
                Position position = (Position) Marshal.PtrToStructure(ptr, typeof(Position));
                UUnitAssert.Equals(position.posX, 5f, 0.0001f, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
                UUnitAssert.Equals(position.posY, 10f, 0.0001f, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
                UUnitAssert.Equals(position.posZ, 15f, 0.0001f, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
                ptr = new IntPtr(ptr.ToInt64() + Marshal.SizeOf(typeof(Position)));
            }
        }
    }

    [UUnitProfileMethod]
    public unsafe void TestUnsafeArray()
    {
        if (!dllFound)
        {
            throw new DllNotFoundException("Unable to find UnitTestPlugin.dll");
        }
        for (int i = 0; i < NUM_RUNS; i++)
        {
            fixed (Position* positionRef = newArray)
            {
                UseUnsafeArray(positionRef, newArray.Length);
                for (int j = 0; j < newArray.Length; j++)
                {
                    Position position = positionRef[j];
                    UUnitAssert.Equals(position.posX, 5f, 0.0001f, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
                    UUnitAssert.Equals(position.posY, 10f, 0.0001f, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
                    UUnitAssert.Equals(position.posZ, 15f, 0.0001f, "Expected equivalent inputs: \"{0}\" != \"{1}\"");
                }
            }
        }
    }

    [DllImport("UnitTestPlugin")]
    private static extern void UseManagedArray([In, Out] Position[] array, int length);
    [DllImport("UnitTestPlugin")]
    private static extern unsafe void UseUnsafeArray([In, Out] Position* array, int length);

    [StructLayout(LayoutKind.Sequential)]
    private struct Position
    {
        public float posX;
        public float posY;
        public float posZ;
        public float fwdX;
        public float fwdY;
        public float fwdZ;
        public float fwdW;
    }
}

