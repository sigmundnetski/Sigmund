﻿using System;
using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Sequential)]
public struct GSParam
{
    public int value;
    public GSParamUnit unit;
    public GSParam(int aValue, GSParamUnit aUnit)
    {
        this.value = aValue;
        this.unit = aUnit;
    }
}

