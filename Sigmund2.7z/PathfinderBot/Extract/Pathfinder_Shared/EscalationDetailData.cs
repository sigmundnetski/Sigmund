﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;

[NoFinalOutput, LooseDependency(typeof(EventData))]
public class EscalationDetailData : DataClass
{
    public string displayName;
    public EscalationConst.EncounterDensityOptions encounterDensity;
    public TimeSpan failBossDelay;
    public int failBossEventId;
    public double failBossStrength;
    public string failShout;
    public TimeSpan fallowDuration;
    public int infectedEventDensity;
    public double infectionRate;
    public double infectionStrength;
    public double invasionChance;
    public int maxClaimableHexes;
    public int maxInstances;
    public double maxStrength;
    public int[] phaseChallengeRating;
    public string[] phaseDisplayBlurb;
    public string[] phaseDisplayName;
    public double[] phaseStrengths;
    public TimeSpan rampUpDuration;
    public double rampUpMinStrength;
    public int sourceEventDensity;
    public double sourceStrengthGrowth;
    public string successShout;
    public int winBossEventId;
    public double winBossStrength;

    private static EscalationDetailData ParseAllDetailsFromPage()
    {
        int row = 4;
        EscalationDetailData data = new EscalationDetailData {
            name = Path.GetFileNameWithoutExtension(DataClass.filename),
            displayName = Path.GetFileNameWithoutExtension(DataClass.filename)
        };
        while (row <= DataClass.MAX_ROW)
        {
            string str;
            List<double> list;
            double num2;
            int num3;
            List<int> list2;
            int num4;
            List<string> list3;
            string str2;
            List<string> list4;
            string str3;
            DataClass.GetLCaseCellValue(1, row, out str);
            switch (str)
            {
                case "encounter density":
                    DataClass.GetEnumCellValue<EscalationConst.EncounterDensityOptions>(2, row, EscalationConst.EncounterDensityOptions.MEDIUM, out data.encounterDensity);
                    goto Label_049C;

                case "source event density":
                    DataClass.GetCellValue(2, row, out data.sourceEventDensity);
                    goto Label_049C;

                case "infected event density":
                    DataClass.GetCellValue(2, row, out data.infectedEventDensity);
                    goto Label_049C;

                case "source strength winboss":
                    DataClass.GetCellValue(2, row, out data.winBossStrength);
                    goto Label_049C;

                case "source strength failboss":
                    DataClass.GetCellValue(2, row, out data.failBossStrength);
                    goto Label_049C;

                case "infection strength":
                    DataClass.GetCellValue(2, row, out data.infectionStrength);
                    goto Label_049C;

                case "max strength":
                    DataClass.GetCellValue(2, row, out data.maxStrength);
                    goto Label_049C;

                case "max hexes":
                    DataClass.GetCellValue(2, row, out data.maxClaimableHexes);
                    goto Label_049C;

                case "source strength growth":
                    DataClass.GetCellValue(2, row, out data.sourceStrengthGrowth);
                    goto Label_049C;

                case "infection rate":
                    ParsePercent(2, row, out data.infectionRate);
                    goto Label_049C;

                case "invasion chance":
                    ParsePercent(2, row, out data.invasionChance);
                    goto Label_049C;

                case "rampup min strength":
                    DataClass.GetCellValue(2, row, out data.rampUpMinStrength);
                    goto Label_049C;

                case "rampup duration":
                    DataClass.GetTimeValue(2, row, 3, row, out data.rampUpDuration);
                    goto Label_049C;

                case "max instances":
                    DataClass.GetCellValue(2, row, out data.maxInstances);
                    goto Label_049C;

                case "fallow time":
                    DataClass.GetTimeValue(2, row, 3, row, out data.fallowDuration);
                    goto Label_049C;

                case "phases":
                    list = new List<double>();
                    num3 = 2;
                    goto Label_035B;

                case "phase challenge rating":
                    list2 = new List<int>();
                    num3 = 2;
                    goto Label_0398;

                case "phase name":
                    list3 = new List<string>();
                    num3 = 2;
                    goto Label_03D6;

                case "phase blurb":
                    list4 = new List<string>();
                    num3 = 2;
                    goto Label_0414;

                case "winboss event":
                    DataClass.GetIdFromForeignName<EventData>(2, row, out data.winBossEventId);
                    goto Label_049C;

                case "success shout":
                    DataClass.GetCellValue(2, row, out data.successShout);
                    goto Label_049C;

                case "failboss event":
                    DataClass.GetIdFromForeignName<EventData>(2, row, out data.failBossEventId);
                    goto Label_049C;

                case "failure shout":
                    DataClass.GetCellValue(2, row, out data.failShout);
                    goto Label_049C;

                case "failboss delay":
                    DataClass.GetTimeValue(2, row, 3, row, out data.failBossDelay);
                    goto Label_049C;

                case "":
                    goto Label_049C;

                default:
                    DataClass.OutputErrorMessage(1, row, "Unknown escalation keyword ignored:" + str);
                    goto Label_049C;
            }
        Label_034C:
            list.Add(num2);
            num3++;
        Label_035B:
            if (DataClass.TryGetCellValue(num3, row, out num2))
            {
                goto Label_034C;
            }
            data.phaseStrengths = list.ToArray();
            goto Label_049C;
        Label_0388:
            list2.Add(num4);
            num3++;
        Label_0398:
            if (DataClass.TryGetCellValue(num3, row, out num4))
            {
                goto Label_0388;
            }
            data.phaseChallengeRating = list2.ToArray();
            goto Label_049C;
        Label_03C6:
            list3.Add(str2);
            num3++;
        Label_03D6:
            if (DataClass.TryGetCellValue(num3, row, out str2))
            {
                goto Label_03C6;
            }
            data.phaseDisplayName = list3.ToArray();
            goto Label_049C;
        Label_0404:
            list4.Add(str3);
            num3++;
        Label_0414:
            if (DataClass.TryGetCellValue(num3, row, out str3))
            {
                goto Label_0404;
            }
            data.phaseDisplayBlurb = list4.ToArray();
        Label_049C:
            row++;
        }
        if (!data.Validate(true))
        {
            return null;
        }
        return data;
    }

    private static bool ParsePercent(int colIndex, int rowIndex, out double output)
    {
        bool flag = DataClass.GetCellValue(colIndex, rowIndex, out output);
        if (flag)
        {
            if (output > 100.0)
            {
                DataClass.OutputErrorMessage(colIndex, rowIndex, "Expected value is too high for percent:" + ((double) output));
            }
            else if (output > 1.0)
            {
                output /= 100.0;
            }
            else if (output < 0.0)
            {
                DataClass.OutputErrorMessage(colIndex, rowIndex, "Expected value should not be negative:" + ((double) output));
            }
        }
        return flag;
    }

    public override List<DataClass> ParseSheet()
    {
        List<DataClass> list = new List<DataClass>();
        EscalationDetailData item = ParseAllDetailsFromPage();
        if (item != null)
        {
            list.Add(item);
        }
        return list;
    }

    public bool Validate(bool logErrors)
    {
        List<string> list = new List<string>();
        List<double> second = new List<double>(this.phaseStrengths);
        second.Sort();
        if (!this.phaseStrengths.SequenceEqual<double>(second))
        {
            list.Add("The phase strengths must be listed in order.");
        }
        if (!(this.maxStrength == this.phaseStrengths[this.phaseStrengths.Length - 1]))
        {
            list.Add("The highest phase strength and the max strength must match.");
        }
        if (this.rampUpMinStrength <= this.winBossStrength)
        {
            list.Add("RampUp str must be greater than WinBoss str, or players win during RampUp.");
        }
        if (((this.winBossEventId == this.failBossEventId) && (this.winBossEventId != 0)) && (this.failBossEventId != 0))
        {
            list.Add("The win and fail bosses must be valid and different (for now).");
        }
        if (this.failBossStrength >= this.maxStrength)
        {
            list.Add("The fail-boss strength must be lower, or it cannot spawn.");
        }
        if ((0.0 >= this.invasionChance) || (this.invasionChance > 1.0))
        {
            list.Add("Invasion Chance out of bounds.");
        }
        if ((0.0 >= this.infectionRate) || (this.infectionRate > 1.0))
        {
            list.Add("Infection Rate out of bounds.");
        }
        if ((this.phaseChallengeRating == null) || (this.phaseStrengths.Length != this.phaseChallengeRating.Length))
        {
            list.Add("Each phase must have a Phase Challenge Rating.");
        }
        if ((this.phaseDisplayName == null) || (this.phaseStrengths.Length != this.phaseDisplayName.Length))
        {
            list.Add("Each phase must have a Phase Name.");
        }
        if ((this.phaseDisplayBlurb == null) || (this.phaseStrengths.Length != this.phaseDisplayBlurb.Length))
        {
            list.Add("Each phase must have a Phase Blurb.");
        }
        if ((list.Count > 0) && logErrors)
        {
            list.Insert(0, "Validation errors in Escalation Details: " + base.name);
            DataClass.OutputErrorMessage(string.Join("\n  * ", list.ToArray()));
        }
        return (list.Count == 0);
    }
}

