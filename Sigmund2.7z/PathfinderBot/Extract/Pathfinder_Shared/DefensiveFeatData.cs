﻿using System;

[LooseDependency(typeof(CombatData)), NoFinalOutput]
public class DefensiveFeatData : NonAttackFeatData
{
    public DefensiveFeatData()
    {
        base.type = Combat.FeatType.Defensive;
        base.generalType = Combat.FeatType.Passive;
    }

    public DefensiveFeatData(string name_, byte level_, string effects_, string description_) : base(name_, level_, effects_)
    {
        base.type = Combat.FeatType.Defensive;
        base.generalType = Combat.FeatType.Passive;
        base.roleId = 0;
        base.description = description_;
        base.usableInStealth = false;
    }

    public override DataClass ParseRecord(int index)
    {
        NonAttackFeatData data = new DefensiveFeatData();
        return base.GenericParse(data, index);
    }
}

