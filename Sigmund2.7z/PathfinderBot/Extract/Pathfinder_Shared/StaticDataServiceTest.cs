﻿using System;
using System.Collections.Generic;

internal class StaticDataServiceTest : UUnitTestCase
{
    [UUnitSystemTestMethod]
    private void AllDatafiles()
    {
        Dictionary<string, string> loadList = new Dictionary<string, string>();
        StaticDataService.SetInitialLoadList(loadList);
        List<string> items = new List<string>();
        foreach (string str in loadList.Keys)
        {
            if (null == System.Type.GetType(str))
            {
                items.Add(str);
            }
        }
        if (items.Count != 0)
        {
            UUnitAssert.Fail("These types are defined in data, but not in code: " + GUtil.PrettyPrint(items, ", ", "[]"));
        }
    }
}

