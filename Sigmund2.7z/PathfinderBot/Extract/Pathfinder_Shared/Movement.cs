﻿using GNetwork;
using System;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour
{
    public float averageClientTimeDelta;
    public float averageServerTimeDelta = 0f;
    private int countClientTimeDelta = 0;
    private int countServerTimeDelta = 0;
    public List<TimeVelNode> deltaQueue = new List<TimeVelNode>();
    private TimeVelNode newestNode;
    public Vector3 orientedVelocity = new Vector3(0f, 0f, 0f);
    public Vector3 worldVelocity = new Vector3(0f, 0f, 0f);

    public void AssignNewestToTransform()
    {
        if (base.transform.position != this.newestNode.position)
        {
            base.transform.position = this.newestNode.position;
        }
        if (base.transform.rotation != this.newestNode.rotation)
        {
            base.transform.rotation = this.newestNode.rotation;
        }
    }

    public void ClearOldNodes(float oldestTimestamp)
    {
        if (this.deltaQueue.Count != 0)
        {
            int count = this.deltaQueue.Count;
            while ((this.deltaQueue.Count > 0) && (oldestTimestamp > this.deltaQueue[0].timestamp))
            {
                this.deltaQueue.RemoveAt(0);
            }
        }
    }

    private void GenerateOrientedVelocity()
    {
        TimeVelNode node = (this.deltaQueue.Count > 0) ? this.deltaQueue[0] : null;
        if (((node != null) && (this.newestNode != null)) && (node.timestamp < this.newestNode.timestamp))
        {
            float num = 1f / (this.newestNode.timestamp - node.timestamp);
            float f = node.rotation.eulerAngles.y * 0.01745329f;
            float num3 = ((this.newestNode.rotation.eulerAngles.y - node.rotation.eulerAngles.y) * 0.01745329f) * num;
            float num4 = this.worldVelocity.y * num;
            float num5 = num * ((this.worldVelocity.x * Mathf.Sin(f)) + (this.worldVelocity.z * Mathf.Cos(f)));
            this.orientedVelocity.Set(num3, num4, num5);
        }
    }

    private void GenerateWorldVelocity()
    {
        TimeVelNode node = (this.deltaQueue.Count > 0) ? this.deltaQueue[0] : null;
        if (((node != null) && (this.newestNode != null)) && (node.timestamp < this.newestNode.timestamp))
        {
            this.worldVelocity = this.newestNode.position - node.position;
            float x = 1f / (this.newestNode.timestamp - node.timestamp);
            this.worldVelocity.Scale(new Vector3(x, x, x));
        }
    }

    public void PopFromBuffer(IBitBufferRead buffer, ushort srcMapId)
    {
        int num = buffer.PopInt();
        for (int i = 0; i < num; i++)
        {
            float timestamp = buffer.PopFloat();
            Vector3 pos = TerrainService.TranslateServerToLocal(srcMapId, buffer.PopVector3());
            Quaternion rot = buffer.PopQuaternion();
            MovementType type = (MovementType) buffer.PopByte();
            this.PushTimeStamp(timestamp, pos, rot, type);
        }
    }

    public static void PopOffOfBuffer(IBitBufferRead buffer)
    {
        int num = buffer.PopInt();
        for (int i = 0; i < num; i++)
        {
            buffer.PopFloat();
            buffer.PopVector3();
            buffer.PopQuaternion();
            buffer.PopByte();
        }
    }

    public void PushTimeStamp(float timestamp, Vector3 pos, Quaternion rot, MovementType type)
    {
        this.QueueNode(new TimeVelNode(timestamp, pos, rot, type));
        this.UpdateServerTimeDelta(timestamp);
        this.GenerateWorldVelocity();
        this.GenerateOrientedVelocity();
    }

    public void PushToBuffer(IBitBufferWrite buffer)
    {
        buffer.PushInt(this.deltaQueue.Count);
        for (int i = 0; i < this.deltaQueue.Count; i++)
        {
            buffer.PushFloat(this.deltaQueue[i].timestamp);
            buffer.PushVector3(this.deltaQueue[i].position);
            buffer.PushQuaternion(this.deltaQueue[i].rotation);
            buffer.PushByte((byte) this.deltaQueue[i].type);
        }
    }

    private void QueueNode(TimeVelNode newNode)
    {
        this.newestNode = newNode;
        this.deltaQueue.Add(newNode);
    }

    public void ResetQueue()
    {
        this.deltaQueue.Clear();
    }

    public void UpdateClientTimeDelta(float timestamp)
    {
        this.countClientTimeDelta++;
        if (this.countClientTimeDelta < 10)
        {
            this.averageClientTimeDelta = Time.time - timestamp;
        }
        else
        {
            this.averageClientTimeDelta = ((9f * this.averageClientTimeDelta) / 10f) + ((Time.time - timestamp) / 10f);
        }
    }

    private void UpdateServerTimeDelta(float timestamp)
    {
        this.countServerTimeDelta++;
        if (this.countServerTimeDelta < 10)
        {
            this.averageServerTimeDelta = Time.time - timestamp;
        }
        else
        {
            this.averageServerTimeDelta = ((9f * this.averageServerTimeDelta) / 10f) + ((Time.time - timestamp) / 10f);
        }
    }

    public enum MovementType : byte
    {
        ChargeEnd = 5,
        ChargeStart = 4,
        EvadeEnd = 7,
        EvadeStart = 6,
        JumpEnd = 3,
        JumpStart = 2,
        KnockbackEnd = 9,
        KnockbackStart = 8,
        MoveChanged = 1,
        None = 11,
        Standard = 0,
        Teleport = 10
    }

    public class TimeVelNode
    {
        public Vector3 position;
        public Quaternion rotation;
        public float timestamp;
        public Movement.MovementType type;
        public bool used;

        public TimeVelNode(float setTimestamp, Vector3 setPos, Quaternion setRot, Movement.MovementType setType)
        {
            this.timestamp = setTimestamp;
            this.position = setPos;
            this.rotation = setRot;
            this.type = setType;
            this.used = false;
        }
    }
}

