﻿using System;
using System.Collections.Generic;
using System.Linq;

public class SkillData : DataClass
{
    private static readonly string[] _mandatoryColumns = new string[] { "skill name", "display name", "code name" };
    public CodeSkillName codeName;
    public string displayName;
    public const int MAX_SKILL = 300;
    public const int MIN_SKILL = 10;
    public static Dictionary<int, SkillData> skillById = new Dictionary<int, SkillData>();
    public static SkillData[] skillByIndex = new SkillData[0];
    public static Dictionary<string, SkillData> skillByName = new Dictionary<string, SkillData>();
    [DataRestrict]
    public int skillIndex;
    public static Dictionary<CodeSkillName, int> skillIndexByCodeName = new Dictionary<CodeSkillName, int>();

    public static void ConstructCommonUnittestData(params string[] extraSkillNames)
    {
        SkillData data;
        List<DataClass> objects = new List<DataClass>();
        foreach (CodeSkillName name in Enum.GetValues(typeof(CodeSkillName)))
        {
            if (name != CodeSkillName.INVALID)
            {
                data = new SkillData {
                    displayName = name.ToString(),
                    name = data.displayName.ToLower(),
                    id = DataClass.GenerateId(data.name),
                    codeName = name
                };
                objects.Add(data);
            }
        }
        foreach (string str in extraSkillNames)
        {
            data = new SkillData {
                displayName = str,
                name = data.displayName.ToLower(),
                id = DataClass.GenerateId(data.name),
                codeName = CodeSkillName.INVALID
            };
            objects.Add(data);
        }
        OnLoad(objects);
    }

    public static void OnLoad(List<DataClass> objects)
    {
        skillByIndex = (from each in objects select (SkillData) each).ToArray<SkillData>();
        for (int i = 0; i < skillByIndex.Length; i++)
        {
            skillByIndex[i].skillIndex = i;
            skillById[skillByIndex[i].id] = skillByIndex[i];
            skillByName[skillByIndex[i].name] = skillByIndex[i];
            if (skillByIndex[i].codeName != CodeSkillName.INVALID)
            {
                skillIndexByCodeName[skillByIndex[i].codeName] = i;
            }
        }
        foreach (CodeSkillName name in Enum.GetValues(typeof(CodeSkillName)))
        {
            if (!((name == CodeSkillName.INVALID) || skillIndexByCodeName.ContainsKey(name)))
            {
                GLog.LogWarning(new object[] { name, "was not defined in SkillData Excel Files." });
            }
        }
    }

    public override DataClass ParseRecord(int rowIndex)
    {
        string str;
        if (!DataClass.TryGetLCaseCellValue(DataClass.columnNamesToIndex["skill name"], rowIndex, out str))
        {
            return null;
        }
        SkillData data = new SkillData {
            name = str
        };
        DataClass.GetCellValue(DataClass.columnNamesToIndex["display name"], rowIndex, out data.displayName);
        DataClass.TryGetEnumCellValue<CodeSkillName>(DataClass.columnNamesToIndex["code name"], rowIndex, CodeSkillName.INVALID, out data.codeName);
        return data;
    }

    protected override IEnumerable<string> GetMandatoryColumns
    {
        get
        {
            return _mandatoryColumns;
        }
    }

    public enum CodeSkillName : byte
    {
        INVALID = 0,
        Perception = 1,
        SenseMotive = 2,
        Stealth = 3
    }
}

