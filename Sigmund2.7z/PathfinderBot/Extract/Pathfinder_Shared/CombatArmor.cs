﻿using System;
using System.Collections.Generic;

[StrongDependency(typeof(ItemCategoryData)), StrongDependency(typeof(ArmorKeywordData)), StrongDependency(typeof(ArmorQualityData)), NoExcelData, StrongDependency(typeof(BasicArmorData)), LooseDependency(typeof(KeywordData))]
public class CombatArmor : BasicItemData
{
    public static Dictionary<int, CombatArmor> armorsById = new Dictionary<int, CombatArmor>();
    public static Dictionary<string, CombatArmor> armorsByName = new Dictionary<string, CombatArmor>();
    public int baseCritResistance;
    public int baseEnergyResistance;
    public int basePhysicalResistance;
    public float encumbranceMultiplier;
    public int energyResistancePerKeyword;
    public int[][] keywordIds;
    public int keywordSetId;
    private const int NUM_KEYWORDS_U1 = 1;
    private const int NUM_KEYWORDS_U2 = 2;
    private const int NUM_KEYWORDS_U3 = 3;
    private const int NUM_UPGRADE_LEVELS = 4;
    public int physicalResistancePerKeyword;
    public int proficiencyAdvId;
    public int reflexPenalty;
    public float speedPenalty;
    public int spellPenalty;

    public CombatArmor()
    {
        base.id = 0;
        base.displayName = string.Empty;
        this.keywordIds = new int[4][];
        this.keywordSetId = 0;
    }

    public CombatArmor(int id_)
    {
        base.id = id_;
        base.displayName = string.Empty;
        this.keywordIds = new int[4][];
        this.keywordSetId = 0;
    }

    public static int ArmorIdFromName(string name)
    {
        return armorsByName[name.ToLower()].id;
    }

    public bool Equippable(Entity entity)
    {
        if (entity.advancementVars.GetFeatLevelByFeatAdvancementId(this.proficiencyAdvId) == 0)
        {
            return false;
        }
        return true;
    }

    public byte GetActiveTier(byte proficiencyLevel)
    {
        return Math.Min(base.tier, proficiencyLevel);
    }

    public static CombatArmor GetArmorById(int id)
    {
        return armorsById[id];
    }

    public static CombatArmor GetArmorByName(string name)
    {
        return armorsByName[name.ToLower()];
    }

    public int GetDefense(byte proficiencyLevel)
    {
        switch (this.GetActiveTier(proficiencyLevel))
        {
            case 1:
                return CombatData.singleton.armorDefenseTier1;

            case 2:
                return CombatData.singleton.armorDefenseTier2;

            case 3:
                return CombatData.singleton.armorDefenseTier3;
        }
        return 0;
    }

    public int GetEffectDefense(int armorFeatId, byte upgrade)
    {
        if (armorFeatId == 0)
        {
            return 0;
        }
        NonAttackFeatData featById = NonAttackFeatData.GetFeatById(armorFeatId);
        int[] keywordIds = this.GetKeywordIds(upgrade);
        int num = 0;
        int num2 = 0;
        for (int i = 0; i < featById.keywordIds.Length; i++)
        {
            bool flag = false;
            for (int j = 0; j < keywordIds.Length; j++)
            {
                if (featById.keywordIds[i] == keywordIds[j])
                {
                    flag = true;
                    break;
                }
            }
            if (flag)
            {
                switch (KeywordData.GetType(KeywordData.GearType.ARMOR, featById.keywordIds[i]))
                {
                    case KeywordData.KeywordType.ADVANCED:
                        num2++;
                        break;

                    case KeywordData.KeywordType.BASIC:
                        num++;
                        break;
                }
            }
        }
        return (num + (num2 * CombatData.singleton.advancedKeywordMultiplier));
    }

    public int[] GetKeywordIds(byte upgrade)
    {
        int length = this.keywordIds.GetLength(0);
        if (upgrade >= length)
        {
            return this.keywordIds[length - 1];
        }
        return this.keywordIds[upgrade];
    }

    public override List<DataClass> MergeData()
    {
        BasicArmorData current;
        List<DataClass> list = new List<DataClass>();
        Dictionary<string, BasicArmorData> dictionary = new Dictionary<string, BasicArmorData>();
        using (IEnumerator<DataClass> enumerator = DataClass.GetData(typeof(BasicArmorData)).GetEnumerator())
        {
            while (enumerator.MoveNext())
            {
                current = (BasicArmorData) enumerator.Current;
                dictionary[current.name] = current;
            }
        }
        foreach (ArmorQualityData data2 in DataClass.GetData(typeof(ArmorQualityData)))
        {
            current = dictionary[data2.armorBaseType];
            ArmorKeywordData data3 = ArmorKeywordData.keywordSetsById[data2.keywordSetId];
            CombatArmor item = new CombatArmor(data2.id) {
                name = data2.name,
                displayName = data2.displayName,
                keywordSetId = data2.keywordSetId,
                tier = data2.tier,
                physicalResistancePerKeyword = current.physicalResistancePerKeyword,
                energyResistancePerKeyword = current.energyResistancePerKeyword,
                basePhysicalResistance = current.basePhysicalResistance,
                baseEnergyResistance = current.baseEnergyResistance,
                baseCritResistance = current.baseCritResistance,
                spellPenalty = current.spellPenalty,
                speedPenalty = current.speedPenalty,
                encumbranceMultiplier = current.encumbranceMultiplier,
                reflexPenalty = current.reflexPenalty,
                categoryId = current.categoryId,
                upgradable = data2.upgradable,
                proficiencyAdvId = current.proficiencyAdvId,
                icon = data2.icon,
                slot = data2.slot,
                encumbrance = data2.encumbrance,
                description = data2.description,
                durability = data2.durability,
                baseQuality = data2.baseQuality,
                model = data2.model
            };
            item.keywordIds[0] = new int[1 + data2.keywordIds.Length];
            item.keywordIds[1] = new int[2 + data2.keywordIds.Length];
            item.keywordIds[2] = new int[3 + data2.keywordIds.Length];
            item.keywordIds[3] = new int[4 + data2.keywordIds.Length];
            item.keywordIds[0][0] = current.keywordId;
            Array.Copy(data2.keywordIds, 0, item.keywordIds[0], 1, data2.keywordIds.Length);
            item.keywordIds[1][0] = current.keywordId;
            Array.Copy(data3.keywordIds, 0, item.keywordIds[1], 1, 1);
            Array.Copy(data2.keywordIds, 0, item.keywordIds[1], 2, data2.keywordIds.Length);
            item.keywordIds[2][0] = current.keywordId;
            Array.Copy(data3.keywordIds, 0, item.keywordIds[2], 1, 2);
            Array.Copy(data2.keywordIds, 0, item.keywordIds[2], 3, data2.keywordIds.Length);
            item.keywordIds[3][0] = current.keywordId;
            Array.Copy(data3.keywordIds, 0, item.keywordIds[3], 1, 3);
            Array.Copy(data2.keywordIds, 0, item.keywordIds[3], 4, data2.keywordIds.Length);
            list.Add(item);
        }
        return list;
    }

    public static void OnLoad(List<DataClass> objects)
    {
        armorsByName.Clear();
        armorsById.Clear();
        foreach (CombatArmor armor in objects)
        {
            armorsByName[armor.name] = armor;
            armorsById[armor.id] = armor;
        }
    }

    public void RecalculationPhase(uint combatTick, CombatVars owner)
    {
        if (owner.combatClass.armorFeatId != 0)
        {
            int num3;
            NonAttackFeatData featById = NonAttackFeatData.GetFeatById(owner.combatClass.armorFeatId);
            int[] keywordIds = this.GetKeywordIds(owner.combatClass.armorItem.upgrade);
            int numBasicKeywords = 0;
            int numAdvancedKeywords = 0;
            for (num3 = 0; num3 < featById.keywordIds.Length; num3++)
            {
                bool flag = false;
                for (int i = 0; i < keywordIds.Length; i++)
                {
                    if (featById.keywordIds[num3] == keywordIds[i])
                    {
                        flag = true;
                        break;
                    }
                }
                if (flag)
                {
                    switch (KeywordData.GetType(KeywordData.GearType.ARMOR, featById.keywordIds[num3]))
                    {
                        case KeywordData.KeywordType.ADVANCED:
                            numAdvancedKeywords++;
                            break;

                        case KeywordData.KeywordType.BASIC:
                            numBasicKeywords++;
                            break;
                    }
                }
            }
            int num5 = (featById.keywordMods == null) ? 0 : featById.keywordMods.Length;
            for (num3 = 0; num3 < num5; num3++)
            {
                CombatCore.RecalculateStats(combatTick, featById.keywordMods[num3], owner, Combat.Channel.Armor, numBasicKeywords, numAdvancedKeywords);
            }
            int num6 = numBasicKeywords + (numAdvancedKeywords * CombatData.singleton.advancedKeywordMultiplier);
            int num7 = this.basePhysicalResistance + (this.physicalResistancePerKeyword * num6);
            int baseCritResistance = this.baseCritResistance;
            int num9 = this.baseEnergyResistance + (this.energyResistancePerKeyword * num6);
            CombatResistance resistance = owner.tempResistances.Channel(Combat.Channel.Armor);
            resistance.Set(ResistanceType.Physical, num7);
            resistance.Set(ResistanceType.Critical, baseCritResistance);
            for (num3 = 1; num3 < 10; num3++)
            {
                resistance.resistance[num3] = num9;
            }
        }
    }
}

