﻿using System;

internal class GFTestInteractState : GFTestBaseState
{
    public bool despawn;
    public string responseText;
}

