﻿using System;
using System.Collections.Generic;
using System.Linq;

[NoFinalOutput, StrongDependency(typeof(CategoryData)), StrongDependency(typeof(AchievementFlagData)), StrongDependency(typeof(InteractKeywordData)), StrongDependency(typeof(AchievementCounterData))]
public class InteractionAchievementData : GenericAchievementData
{
    private static readonly string[] _mandatoryColumns = new string[] { "counter (or flag)", "counter value", "interaction keyword" };
    public int interactKeywordId;

    protected override void ParseCustomDetails(int rowIndex, ref AdvancementIndexedDataClass _output)
    {
        base.ParseCustomDetails(rowIndex, ref _output);
        InteractionAchievementData data = (InteractionAchievementData) _output;
        bool flag = data.TryParseAsSingleCounter(DataClass.columnNamesToIndex["counter (or flag)"], rowIndex);
        bool flag2 = flag && data.TryParseAsSingleCounterValue(DataClass.columnNamesToIndex["counter value"], rowIndex);
        bool flag3 = !flag && data.TryParseAsSingleFlag(DataClass.columnNamesToIndex["counter (or flag)"], rowIndex);
        if ((data.linkedCounterIds.Length == 0) && (data.linkedFlagIds.Length == 0))
        {
            DataClass.OutputErrorMessage(DataClass.columnNamesToIndex["counter (or flag)"], rowIndex, "Invalid Counter or Flag.");
        }
        if (!(!flag || flag2))
        {
            DataClass.OutputErrorMessage(DataClass.columnNamesToIndex["counter value"], rowIndex, "Counter value out of bounds (1-8000).");
        }
        DataClass.GetIdFromForeignName<InteractKeywordData>(DataClass.columnNamesToIndex["interaction keyword"], rowIndex, out data.interactKeywordId);
    }

    protected override IEnumerable<string> GetMandatoryColumns
    {
        get
        {
            return base.GetMandatoryColumns.Concat<string>(_mandatoryColumns);
        }
    }
}

