﻿using System;
using System.Runtime.InteropServices;
using UnityEngine;

public class NpcSpawnPoint : MonoBehaviour
{
    [NonSerialized, HideInInspector]
    public ActiveSpawnPoint runtimeDetails = null;
    public string staticDetails;

    public static void ExtractFromStaticDetails(string staticDetails, out EscalationConst.EnemyTag enemyTag, out string customDefnName, out TimeSpan respawnDelay)
    {
        customDefnName = "";
        enemyTag = EscalationConst.EnemyTag.WEAK;
        respawnDelay = TimeSpan.Zero;
        if (!string.IsNullOrEmpty(staticDetails))
        {
            string[] strArray = staticDetails.Split(new char[] { ',' });
            foreach (string str in strArray)
            {
                if (str.StartsWith("customName:"))
                {
                    customDefnName = str.Replace("customName:", "");
                }
                else if (str.StartsWith("delay:"))
                {
                    int num;
                    int.TryParse(str.Replace("delay:", ""), out num);
                    respawnDelay = TimeSpan.FromSeconds((double) num);
                }
                else if (GUtil.TryParseEnum<EscalationConst.EnemyTag>(str, enemyTag, out enemyTag))
                {
                }
            }
        }
    }

    public void RegisterSpawnPoint()
    {
        string str;
        EscalationConst.EnemyTag tag;
        TimeSpan span;
        if (this.runtimeDetails != null)
        {
            throw new Exception("NpcSpawnPoints should only be registered once, and always from their correct/final position:" + base.gameObject.name);
        }
        ExtractFromStaticDetails(this.staticDetails, out tag, out str, out span);
        this.runtimeDetails = new ActiveSpawnPoint(GConst.CreateType.NPC, tag, str, base.gameObject.name, span, this, base.transform.position, base.transform.rotation);
        if (!ActiveSpawnPoint.AddSpawnPoint(this.runtimeDetails))
        {
            this.runtimeDetails = null;
        }
    }

    private void Start()
    {
        MeshRenderer component = base.GetComponent<MeshRenderer>();
        if (component != 0)
        {
            UnityEngine.Object.Destroy(component);
        }
        MeshFilter filter = base.GetComponent<MeshFilter>();
        if (filter != 0)
        {
            UnityEngine.Object.Destroy(filter);
        }
        if (ActiveSpawnPoint.AddSpawnPoint != null)
        {
            this.RegisterSpawnPoint();
        }
    }
}

