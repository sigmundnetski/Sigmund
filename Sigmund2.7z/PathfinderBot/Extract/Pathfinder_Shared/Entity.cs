﻿using System;
using System.Runtime.InteropServices;
using UnityEngine;

public class Entity : IDataCopyable<Entity>
{
    [DataRestrict]
    private EntityDefnData _entityDefn;
    private int _entityDefnId;
    [DataSyncTo(2)]
    public AdvancementVars advancementVars;
    [DataRestrict]
    public object aiVars;
    [DataSyncTo(2)]
    public CapturePointVars capturePointVars;
    public static EntityDataCallback cleanupCallback = null;
    public CombatVars combat;
    [DataRestrict]
    public EntityGridInfo combatGridInfo;
    public GConst.CreateType createType;
    public bool dead;
    [DataRestrict]
    public EntityId debugTarget;
    [DataRestrict]
    public DateTime despawnTime;
    public EntityId entityId;
    public string entityName;
    [DataSyncTo(2)]
    public EscalationVars escalationVars;
    public EntityFlags flags;
    [DataRestrict]
    public GameObject gameObject;
    public PlayerGear gear;
    public HuskVars huskVars;
    public static EntityDataCallback initializeCallback = null;
    [DataRestrict]
    public EntityStatus isValid = EntityStatus.INVALID;
    public MapPlace[] localMapPlaces;
    [DataRestrict]
    public NpcQuestVars npcQuestVars;
    public ushort ownerMapId;
    public uint ownerSequence;
    [DataRestrict]
    public uint partyId;
    public PhysiqueRecord physique;
    public uint playerId;
    [DataSyncTo(2)]
    public PlayerRecord playerRecord;
    [DataRestrict]
    public object playerVars;
    private Vector3 position;
    public PvpVars pvp;
    public Quaternion rotation;
    [DataRestrict]
    public ActiveSpawnPoint spawnPoint;
    [DataRestrict]
    public EntityGridInfo visGridInfo;

    public Entity()
    {
        this.Reset();
    }

    public void AssignEntityType(EntityDefnData setEntityType)
    {
        this._entityDefn = setEntityType;
        this._entityDefnId = setEntityType.id;
    }

    public void ClaimOwnership(uint prevOwnerSequence)
    {
        this.position = TerrainUtils.TranslateMapToMap(this.position, this.ownerMapId, EntityCore.MAP_ID);
        this.ownerMapId = EntityCore.MAP_ID;
        if (this.ownerSequence != prevOwnerSequence)
        {
            GLog.LogWarning(new object[] { this, "owner sequence not sequential:", this.ownerSequence, "!=", prevOwnerSequence });
        }
        this.ownerSequence = prevOwnerSequence + 1;
    }

    public void CleanUp()
    {
        EntityCore.UnregisterEntity(this);
        this.isValid = EntityStatus.LIMBO;
        if (cleanupCallback != null)
        {
            cleanupCallback(this);
        }
        if (this.combat != null)
        {
            this.combat.UnregisterFromCombatCore();
        }
        this.Reset();
    }

    public void DataCopyTo(ref Entity target, byte syncTargetLevel)
    {
        if (EntityDataHelpers.SyncToAll(syncTargetLevel))
        {
            target.entityId = this.entityId;
            target.playerId = this.playerId;
            target._entityDefnId = this._entityDefnId;
            target.entityName = this.entityName;
            target.createType = this.createType;
            target.flags = this.flags;
            target.ownerMapId = this.ownerMapId;
            target.position = this.position;
            target.dead = this.dead;
            target.ownerSequence = this.ownerSequence;
            DataSerializerUtils.DataCopyField<CombatVars>(this.combat, ref target.combat, syncTargetLevel);
            SparseArray.DeepCopyTo<MapPlace>(this.localMapPlaces, ref target.localMapPlaces, syncTargetLevel, null);
            DataSerializerUtils.DataCopyField<PvpVars>(this.pvp, ref target.pvp, syncTargetLevel);
            DataSerializerUtils.DataCopyField<PlayerGear>(this.gear, ref target.gear, syncTargetLevel);
            DataSerializerUtils.DataCopyField<PhysiqueRecord>(this.physique, ref target.physique, syncTargetLevel);
            DataSerializerUtils.DataCopyField<HuskVars>(this.huskVars, ref target.huskVars, syncTargetLevel);
        }
        if (EntityDataHelpers.SyncToOwner(syncTargetLevel))
        {
            DataSerializerUtils.DataCopyField<PlayerRecord>(this.playerRecord, ref target.playerRecord, syncTargetLevel);
            DataSerializerUtils.DataCopyField<AdvancementVars>(this.advancementVars, ref target.advancementVars, syncTargetLevel);
            DataSerializerUtils.DataCopyField<EscalationVars>(this.escalationVars, ref target.escalationVars, syncTargetLevel);
            DataSerializerUtils.DataCopyField<CapturePointVars>(this.capturePointVars, ref target.capturePointVars, syncTargetLevel);
        }
    }

    public bool DataEquals(Entity target, byte syncTargetLevel)
    {
        if (object.ReferenceEquals(this, target))
        {
            return true;
        }
        if (object.ReferenceEquals(target, null))
        {
            return false;
        }
        bool flag = true;
        if (EntityDataHelpers.SyncToAll(syncTargetLevel))
        {
            flag = (((((((((((((((flag && (this.entityId == target.entityId)) && (this.playerId == target.playerId)) && (this._entityDefnId == target._entityDefnId)) && (this.entityName == target.entityName)) && (this.createType == target.createType)) && (this.flags == target.flags)) && (this.ownerMapId == target.ownerMapId)) && (Vector3.Magnitude(this.position - target.position) < 1f)) && (this.dead == target.dead)) && (this.ownerSequence == target.ownerSequence)) && DataSerializerUtils.DataEquals<CombatVars>(this.combat, target.combat, syncTargetLevel)) && SparseArray.DeepEqualsWithIndex<MapPlace>(this.localMapPlaces, target.localMapPlaces, syncTargetLevel)) && DataSerializerUtils.DataEquals<PvpVars>(this.pvp, target.pvp, syncTargetLevel)) && DataSerializerUtils.DataEquals<PlayerGear>(this.gear, target.gear, syncTargetLevel)) && DataSerializerUtils.DataEquals<PhysiqueRecord>(this.physique, target.physique, syncTargetLevel)) && DataSerializerUtils.DataEquals<HuskVars>(this.huskVars, target.huskVars, syncTargetLevel);
        }
        if (EntityDataHelpers.SyncToOwner(syncTargetLevel))
        {
            flag = (((flag && DataSerializerUtils.DataEquals<PlayerRecord>(this.playerRecord, target.playerRecord, syncTargetLevel)) && DataSerializerUtils.DataEquals<AdvancementVars>(this.advancementVars, target.advancementVars, syncTargetLevel)) && DataSerializerUtils.DataEquals<EscalationVars>(this.escalationVars, target.escalationVars, syncTargetLevel)) && DataSerializerUtils.DataEquals<CapturePointVars>(this.capturePointVars, target.capturePointVars, syncTargetLevel);
        }
        return flag;
    }

    public void ForcePosition(Vector3 newPos, Quaternion newRot)
    {
        if (EntityCore.MAP_ID != this.ownerMapId)
        {
            throw new Exception("This server cannot control the position of a ghost");
        }
        this.position = newPos;
        this.rotation = newRot;
    }

    public Vector3 GetLocalPosition()
    {
        if (this.ownerMapId == EntityCore.MAP_ID)
        {
            return this.position;
        }
        return TerrainService.TranslateServerToLocal(this.ownerMapId, this.position);
    }

    private bool GetUnityPositionAndRotation(out Vector3 _pos, out Quaternion _rot)
    {
        _pos = this.position;
        _rot = this.rotation;
        bool flag = !this.gameObject.Equals(null);
        if (flag)
        {
            _pos = this.gameObject.transform.position;
            _rot = this.gameObject.transform.rotation;
        }
        return flag;
    }

    public void Initialize()
    {
        this.isValid = EntityStatus.VALID;
        if (initializeCallback != null)
        {
            initializeCallback(this);
        }
        if (this.combat != null)
        {
            this.combat.RegisterWithCombatCore();
        }
        EntityCore.RegisterEntity(this);
    }

    public void RelinquishOwnership()
    {
        this.position = TerrainUtils.TranslateMapToMap(this.position, this.ownerMapId, 0);
        this.ownerMapId = 0;
    }

    private void Reset()
    {
        this.entityId = EntityId.INVALID_ID;
        this.playerId = 0;
        this._entityDefnId = 0;
        this._entityDefn = null;
        this.entityName = string.Empty;
        this.createType = GConst.CreateType.TEST_EMPTY_ENTITY;
        this.flags = 0;
        this.combat = null;
        this.gear = null;
        this.localMapPlaces = null;
        this.partyId = 0;
        this.ownerMapId = 0;
        this.ownerSequence = 1;
        this.position = GConst.VECTOR3_INVALID;
        this.rotation = Quaternion.identity;
        this.dead = false;
        this.despawnTime = DateTime.MaxValue;
        this.advancementVars = null;
        this.aiVars = null;
        this.capturePointVars = null;
        this.escalationVars = null;
        this.npcQuestVars = null;
        this.playerRecord = null;
        this.playerVars = null;
        this.pvp = null;
        this.huskVars = null;
        this.gameObject = null;
    }

    public void SetPosition(Vector3 newPos)
    {
        if (EntityCore.MAP_ID != this.ownerMapId)
        {
            throw new Exception("This server cannot control the position of a ghost");
        }
        this.position = newPos;
        if (!((this.ownerMapId != EntityCore.MAP_ID) || TerrainUtils.IsWithinHex(this.position, false)))
        {
            GLog.LogError(new object[] { "SetPosition: Setting an entity position outside of the hex", this.position });
        }
    }

    public override string ToString()
    {
        if (this.isValid == EntityStatus.INVALID)
        {
            return "<Empty Entity>";
        }
        return string.Concat(new object[] { "<Entity: ", this.EntityName, " ", this.isValid, " on: ", this.ownerMapId, " Id: ", this.entityId.ToString("x"), ">" });
    }

    public void UpdatePositionFromGameObject()
    {
        if (this.ownerMapId != EntityCore.MAP_ID)
        {
            GLog.LogError(new object[] { "UpdatePosition: Should not be called for ghosts." });
        }
        if (!object.ReferenceEquals(this.gameObject, null))
        {
            if (!this.GetUnityPositionAndRotation(out this.position, out this.rotation))
            {
                GLog.LogWarning(new object[] { "Entity gameObject has been destroyed, but Entity still exists." });
            }
            if (!((this.ownerMapId != EntityCore.MAP_ID) || TerrainUtils.IsWithinHex(this.position, false)))
            {
                GLog.LogWarning(new object[] { "UpdatePosition: Setting an entity position outside of the hex", this.EntityName, this.position, this.ownerMapId, EntityCore.MAP_ID });
            }
        }
    }

    public EntityDefnData entityDefn
    {
        get
        {
            if (object.ReferenceEquals(this._entityDefn, null))
            {
                this._entityDefn = EntityDefnData.defnById[this._entityDefnId];
            }
            return this._entityDefn;
        }
    }

    public int entityDefnId
    {
        get
        {
            return this._entityDefnId;
        }
    }

    public string EntityName
    {
        get
        {
            return ((((byte) (this.flags & EntityFlags.GmSuit)) == 2) ? ("[GM] " + this.entityName) : this.entityName);
        }
    }

    public enum EntityStatus : byte
    {
        INVALID = 0,
        LIMBO = 1,
        VALID = 2
    }
}

