﻿using System;

public class CSharpProfileAccessors : UUnitTestCase
{
    private const int CLASS_TEST_RUNS = 0x186a0;
    private CSharpProfileTestClass classTestObject;

    protected override void SetUp()
    {
        this.classTestObject = new CSharpProfileTestClass(1);
    }

    [UUnitProfileMethod]
    public void TestClassMemberVariablePublic()
    {
        for (int i = 0; i < 0x186a0; i++)
        {
            bool flag = this.classTestObject._publicMemberInt == -1;
        }
    }

    [UUnitProfileMethod]
    public void TestClassMethodPrivate()
    {
        for (int i = 0; i < 0x186a0; i++)
        {
            bool flag = this.classTestObject.GetPrivateMemberInt() == -1;
        }
    }

    [UUnitProfileMethod]
    public void TestClassMethodPublic()
    {
        for (int i = 0; i < 0x186a0; i++)
        {
            bool flag = this.classTestObject.GetPublicMemberInt() == -1;
        }
    }

    [UUnitProfileMethod]
    public void TestClassPropertyPrivate()
    {
        for (int i = 0; i < 0x186a0; i++)
        {
            bool flag = this.classTestObject.PrivateMemberInt == -1;
        }
    }

    [UUnitProfileMethod]
    public void TestClassPropertyPropertyPrivate()
    {
        for (int i = 0; i < 0x186a0; i++)
        {
            bool flag = this.classTestObject.PrivatePropertyMemberInt == -1;
        }
    }

    [UUnitProfileMethod]
    public void TestClassPropertyPropertyPublic()
    {
        for (int i = 0; i < 0x186a0; i++)
        {
            bool flag = this.classTestObject.PublicPropertyMemberInt == -1;
        }
    }

    [UUnitProfileMethod]
    public void TestClassPropertyPublic()
    {
        for (int i = 0; i < 0x186a0; i++)
        {
            bool flag = this.classTestObject.PublicMemberInt == -1;
        }
    }

    [UUnitProfileMethod]
    public void TestClassReadOnlyMemberVariablePublic()
    {
        for (int i = 0; i < 0x186a0; i++)
        {
            bool flag = this.classTestObject._publicReadOnlyMemberInt == -1;
        }
    }

    private class CSharpProfileTestClass
    {
        private int _privateMemberInt;
        public int _publicMemberInt;
        public readonly int _publicReadOnlyMemberInt;

        public CSharpProfileTestClass()
        {
            this._publicReadOnlyMemberInt = 1;
            this._privateMemberInt = 1;
            this._publicMemberInt = 1;
        }

        public CSharpProfileTestClass(int input)
        {
            this._privateMemberInt = input;
            this._publicMemberInt = input;
        }

        public int GetPrivateMemberInt()
        {
            return this._privateMemberInt;
        }

        public int GetPublicMemberInt()
        {
            return this._publicMemberInt;
        }

        public int PrivateMemberInt
        {
            get
            {
                return this._privateMemberInt;
            }
        }

        public int PrivatePropertyMemberInt
        {
            get
            {
                return this.PrivateMemberInt;
            }
        }

        public int PublicMemberInt
        {
            get
            {
                return this._publicMemberInt;
            }
        }

        public int PublicPropertyMemberInt
        {
            get
            {
                return this.PublicMemberInt;
            }
        }
    }
}

