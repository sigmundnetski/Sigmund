﻿using System;
using System.Runtime.InteropServices;

public class EscalationVars : IDataCopyable<EscalationVars>
{
    public int escalationId = 0;
    public ActiveEventInfo[] events = new ActiveEventInfo[4];
    public int hexCR = 0;
    public float normalizedStrength = 0f;
    public int phase = -1;
    public double strength = 0.0;

    public void DataCopyTo(ref EscalationVars target, byte syncTargetLevel)
    {
        target.escalationId = this.escalationId;
        target.normalizedStrength = this.normalizedStrength;
        target.strength = this.strength;
        target.phase = this.phase;
        target.hexCR = this.hexCR;
        SparseArray.DeepCopyTo<ActiveEventInfo>(this.events, ref target.events, syncTargetLevel, null);
    }

    public bool DataEquals(EscalationVars target, byte syncTargetLevel)
    {
        if (object.ReferenceEquals(target, null))
        {
            return false;
        }
        bool flag = true;
        flag &= target.escalationId == this.escalationId;
        flag &= target.normalizedStrength == this.normalizedStrength;
        flag &= target.strength == this.strength;
        flag &= target.phase == this.phase;
        return ((flag & (target.hexCR == this.hexCR)) && SparseArray.DeepEqualsWithIndex<ActiveEventInfo>(this.events, target.events, syncTargetLevel));
    }

    public void GetCounter(int eventId, ushort mapId, int questid, out int current, out int max)
    {
        current = max = 0;
        ActiveEventInfo info = SparseArray.Find<ActiveEventInfo>(this.events, a => (a.eventId == eventId) && (a.mapId == mapId));
        if (info != null)
        {
            info.GetCounter(questid, out current, out max);
        }
    }

    public ActiveEventInfo GetEvent(int eventId)
    {
        return SparseArray.Find<ActiveEventInfo>(this.events, a => a.eventId == eventId);
    }

    public ActiveEventInfo GetEvent(int eventId, ushort mapId)
    {
        return SparseArray.Find<ActiveEventInfo>(this.events, a => (a.eventId == eventId) && (a.mapId == mapId));
    }

    public int GetQuestHashCode()
    {
        int num = ((this.escalationId + this.phase) + this.events.Length) + SparseArray.Count<ActiveEventInfo>(this.events);
        foreach (ActiveEventInfo info in SparseArray.Iterate<ActiveEventInfo>(this.events))
        {
            num += info.GetQuestHashCode();
        }
        return (num + ((int) Math.Floor(this.strength)));
    }

    public void RemoveCounter(int eventId, ushort mapId, int questId)
    {
        ActiveEventInfo info = this.GetEvent(eventId, mapId);
        if (info != null)
        {
            info.RemoveCounter(questId);
        }
    }

    public void RemoveEvent(int eventId, ushort mapId)
    {
        int index = SparseArray.IndexOf<ActiveEventInfo>(this.events, a => (a.eventId == eventId) && (a.mapId == mapId));
        if (index > -1)
        {
            this.events[index] = null;
        }
    }

    public void SetCounter(int eventId, ushort mapId, int questId, int current, int max)
    {
        ActiveEventInfo info = this.GetEvent(eventId, mapId);
        if (info == null)
        {
            info = new ActiveEventInfo();
            SparseArray.Add<ActiveEventInfo>(ref this.events, info);
        }
        info.SetCounter(questId, current, max);
    }

    public ActiveEventInfo SetEvent(int eventId, ushort mapId, EscalationConst.Flow curStatus)
    {
        ActiveEventInfo info = this.GetEvent(eventId, mapId);
        if (info == null)
        {
            info = new ActiveEventInfo();
            SparseArray.Add<ActiveEventInfo>(ref this.events, info);
        }
        info.SetInfo(eventId, mapId, curStatus);
        return info;
    }

    public override string ToString()
    {
        if (this.events != null)
        {
            return string.Concat(new object[] { "<EscVars ", this.escalationId, " ", this.strength, " ", GUtil.PrettyPrint(from each in this.events
                where each != null
                select each.eventId.ToString() + " " + each.eventStatus, ", ", "[]"), ">" });
        }
        return ("<EscVars " + this.escalationId + ">");
    }
}

