﻿using System;
using System.Collections.Generic;

public interface IPackageReader : IDisposable
{
    IEnumerable<SourceFileData> GetSourceFiles();
    void LoadAllObjects();
    void LoadTableOfContents();
    void LoadVersion();
}

