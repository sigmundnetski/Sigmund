from role import Role
from csv_parser import *
from utilities import *
from wb import wb
import os #seems needed here. why?

def parse_abilities(min_scores):
	ms = min_scores.split()
	abilities = []
	for ab in ms:
		for fa in find_abilities(ab):
			abilities.append(fa)
	numbers = []
	m = min_scores.split()
	for n in m:
		try:
			n = n.replace('.', '')
			numbers.append(int(n))
		except:
			continue
	if(abilities==[]):
		return []
	if(len(numbers)==len(abilities)):
		return [ [abilities[i], numbers[i]] for i in range(len(abilities)) ]
	if(len(numbers)==1 and len(abilities)==2):
		return [ [abilities[i], numbers[0]] for i in range(len(abilities)) ] 
	if(len(numbers)==2 and len(abilities)==3):
		return [ [abilities[0], numbers[0]],  [abilities[1], numbers[1]], [abilities[2], numbers[1]] ]

role_list = []

def role_read():
	list_of_roles, labels, found_name_row, name_row_number  = [], [], False, 0
	sheet = wb.sheet_by_name('Feat Achievements')
	for rownum in range(sheet.nrows):
		row = sheet.row_values(rownum)
		prerequisites = []
		if(not found_name_row):
			for entry_num in range(len(row)):
				labels.append(row[entry_num]) 
				if('Name' in row[entry_num]):
					name_row_number, found_name_row = entry_num, True
			if(not found_name_row):
				labels = [] #reset the labels as we were getting the wrong row in this case
			continue
		if(row[name_row_number]=='' and found_name_row):
			continue
		for entry_num in range(len(row)):
			if(entry_num==name_row_number):
				role_name = row[entry_num].split()[0]
				this_role, found_role = None, False
				for role in role_list:
					if(role.name==role_name):
						this_role, found_role = role, True
				if(not found_role):
					this_role = Role(role_name)
					role_list.append(this_role)		
			if('Feat Req List' in labels[entry_num]):
				this_role.add_prerequisites(parse(row[entry_num],0))
			if('Description' in labels[entry_num]):
				rowsplit = row[entry_num].split(',')
				to_use = rowsplit[0]
				for ab_name in ab_names:
					if(len(rowsplit)>1):
						if ab_name in rowsplit[1]:
							to_use = ' and '.join([rowsplit[0],rowsplit[1]])
				this_role.add_scores(parse_abilities(to_use))

role_read()
