import tkinter as tk
from message_window import Make_Message_Window

#http://paizo.com/threads/rzs2rhs3?Recipes-droped-ingroup-appear-to-be-broken#11

class Create_Loot_Tab:
	def __init__(self, tab):
		t = tab
		tk.Label(t, text='Number of party members').grid(row=0,column=0,sticky="NEWS")
		self.n_party = tk.IntVar()
		self.n_party.set(1)
		tk.OptionMenu(t, self.n_party, *[i for i in range(1,7)]).grid(row=0,column=1,sticky="NEWS")
		tk.Label(t, text='Applicable knowledge skill').grid(row=1,column=0,sticky="NEWS")
		self.knowledge = tk.IntVar()
		self.knowledge.set(10)
		tk.OptionMenu(t, self.knowledge, *[i for i in range(10,305,5)]).grid(row=1,column=1,sticky="NEWS")
		tk.Button(t, text='Average Loot', command=self.printout).grid(row=1,column=2,sticky="NEWS")
		tk.Label(t, text='(assumes same knowledge skill for all members)').grid(row=1,column=3,sticky="NEWS")
		tk.Label(t, text='New Knowledge skill').grid(row=2,column=0,sticky="NEWS")
		self.new_knowledge = tk.IntVar()
		self.new_knowledge.set(10)
		self.ratio = tk.DoubleVar()
		self.find_ratio()
		tk.OptionMenu(t, self.new_knowledge, *[i for i in range(10,305,5)]).grid(row=2,column=1,sticky="NEWS")	
		tk.Button(t, text='Ratio of loot (new/old)', command=self.find_ratio).grid(row=2,column=2,sticky="NEWS")
		tk.Entry(t, textvariable=self.ratio).grid(row=2,column=3,sticky="NEWS")
	def find_ratio(self): 
		old = 1.0+(self.knowledge.get()/600)
		new = 1.0+(self.new_knowledge.get()/600)
		self.ratio.set(new/old)
		self.ratio.set(round(self.ratio.get()*10000)/10000)
	def loot_results(self):
		column_entries = []
		for n in range(2,102,2):
			odds = n/self.n_party.get()*(0.95+0.05*self.n_party.get())*(1.0+(self.knowledge.get()/600))
			n_odds = round(1000*self.n_party.get()*min(odds,100.0))/1000
			odds = min(round(1000*odds)/1000,100.0)
			column_entries.append([n,odds,n_odds])
		return column_entries
	def printout(self):
		mw = Make_Message_Window()
		title = 'Average Loot'
		column_names = [ 'Base Loot Chance (%)', 'Average Per Person (%)', 'Average Party Total (%)' ]
		column_entries = self.loot_results()
		widths = [ 10, 10, 10 ]
		mw.update_columns(title, column_names, column_entries, widths)
		mw.new_window()
