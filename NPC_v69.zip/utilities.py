ab_names = ['Strength','Dexterity','Constitution','Intelligence','Wisdom','Personality']

def find_abilities(a,names=False): 
	ab = []
	for i in range(len(ab_names)):
		if(ab_names[i] in a or ab_names[i].lower() in a):
			if(names):
				ab.append(ab_names[i])
			else:
				ab.append(i)
	return ab
