class Logic_Handler:
	def __init__(self):
		self.zeros = []
		self.ones = []
		self.haves = []
	def reset(self):
		self.zeros = []
		self.ones = []
	def ones_and_zeros(self,requirements):
		self.reset()
		for requirement in requirements:
			if(requirement[2]==0):
				self.zeros.append(requirement)
			if(requirement[2]==1):
				self.ones.append(requirement)
		#print('000', self.zeros)
		#print('111', self.ones)
	def find_prerequisite(self,requirement):
		#print(requirement, 'A')
		for have in self.haves:
			#print(have[1], 'B') #is looking at feat type, not feat_name
			if(have[1]==requirement[0]):
				#print(have[1], 'C')
				if(have[2]<requirement[1]):
					return False
				return True
		return False
	def handle(self, requirements, haves): 
		self.haves = haves
		self.ones_and_zeros(requirements)
		result = True
		for zero in self.zeros:
			result = result and self.find_prerequisite(zero)
			#print(result, zero)
			if(result==False):
				return result
		#print('A', self.zeros)
		if(len(self.ones)>0):
			for one in self.ones:
				if(self.find_prerequisite(one)):
					return True
			return False
		return True
