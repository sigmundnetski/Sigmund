import tkinter as tk
from itertools import product
from os import path, getcwd, listdir

class Create_Threading_Tab:
	def __init__(self,tab):
		t = tab
		tk.Label(t,text='Threads available').grid(row=0,column=1,sticky="NEWS")
		self.available_threads = tk.IntVar()
		tk.Entry(t,textvariable=self.available_threads).grid(row=0,column=2,sticky="NEWS")
		tk.Label(t,text='Relative repair cost').grid(row=0,column=3,sticky="NEWS")
		self.relative_repair_cost = tk.DoubleVar()
		tk.Entry(t,textvariable=self.relative_repair_cost).grid(row=0,column=4,sticky="NEWS")
		titles = ['Item', 'Threads Needed', 'Value(full durability)', 'Current Durability', 'Max Durability']
		self.lt = len(titles) #TEMP?
		items = ['Head','Neck','Back','Waist','Finger #1','Finger #2','Hands','Wondrous #1','Wondrous #2','Feet','Implement #1','Implement #2','Offhand #1','Offhand #2','Weapon #1','Weapon #2']
		self.n_items = len(items)
		for i in range(len(titles)):
			tk.Label(t, text='%s' %(titles[i])).grid(row=1, column=i,sticky="NEWS")
		self.threading_input = [ [tk.IntVar() for j in range(len(titles)-1)] for i in range(self.n_items) ]
		for i in range(self.n_items):
			tk.Label(t, text='%s' %items[i]).grid(row=i+2, column=0,sticky="NEWS")
			for j in range(len(titles)-1):
				tk.Entry(t,textvariable=self.threading_input[i][j]).grid(row=i+2,column=j+1,sticky="NEWS")
		tk.Button(t, text='Store threading info', command=self.Store_Threading_Info).grid(row=self.n_items+2,column=1,sticky="NEWS")
		tk.Button(t, text='Recall threading info', command=self.Recall_Threading_Info).grid(row=self.n_items+2, column=2,sticky="NEWS")
		tk.Button(t, text='Minimize pvp losses', fg='red', command=self.Run_Pvp_Threading).grid(row=self.n_items+2,column=3,sticky="NEWS")
		tk.Button(t, text='Minimize pve losses', fg='blue', command=self.Run_Pve_Threading).grid(row=self.n_items+2,column=4,sticky="NEWS")
		tk.Label(t, text='May take a few seconds!').grid(row=self.n_items+2,column=5,sticky="NEWS")
		tk.Label(t,text='Should you thread?').grid(row=1,column=len(titles),sticky="NEWS")
		self.thread_or_not = [ tk.StringVar() for i in range(len(items)) ]
		thread_or_not_entry = [ tk.Entry(t,textvariable=self.thread_or_not[i]).grid(row=i+2,column=len(titles),sticky="NEWS") for i in range(self.n_items) ]
		tk.Label(t,text='Loss on death').grid(row=self.n_items+3,column=1,sticky="NEWS")
		self.value_loss = tk.DoubleVar()
		tk.Entry(t,textvariable=self.value_loss).grid(row=self.n_items+3,column=2,sticky="NEWS")
		tk.Label(t,text='Threads left over').grid(row=self.n_items+3,column=3,sticky="NEWS")
		self.left_over_threads = tk.IntVar()
		tk.Entry(t,textvariable=self.left_over_threads).grid(row=self.n_items+3,column=4,sticky="NEWS")
		self.Set_Default_Threading_Values()
		tk.Button(t,text='Reset',command=self.Set_Default_Threading_Values).grid(row=0,column=5,sticky="NEWS")
		tk.Label(t,text='Import Threading').grid(row=self.n_items+4,column=0,sticky="NEWS")
		self.import_threading_name = tk.StringVar()
		import_threadings_list = self.Find_Threadings()
		self.import_threading_name.set(import_threadings_list[0])
		self.import_option_menu = tk.OptionMenu(t, self.import_threading_name, *import_threadings_list)
		self.import_option_menu.grid(row=self.n_items+4,column=1,sticky="NEWS")
		tk.Button(t,text='Refresh List',command=self.Refresh_Threadings_List).grid(row=self.n_items+5,column=1,sticky="NEWS")
		tk.Button(t,text='Import',command=self.Import_Threading).grid(row=self.n_items+4,column=2,sticky="NEWS")
		tk.Label(t,text='Export Threading').grid(row=self.n_items+4,column=3,sticky="NEWS")
		self.export_threading_name = tk.StringVar()
		self.Set_Default_Threading_Export_Name()
		tk.Entry(t,textvariable=self.export_threading_name).grid(row=self.n_items+4,column=4,sticky="NEWS")
		tk.Button(t,text='Export',command=self.Export_Threading).grid(row=self.n_items+4,column=5,sticky="NEWS")

	def Set_Default_Threading_Export_Name(self):
		self.export_threading_name.set('my_threading')

	def Set_Default_Threading_Values(self):
		self.available_threads.set(0)
		self.relative_repair_cost.set(1.0)
		for i in range(self.n_items):
			self.threading_input[i][self.lt-5].set(0)
			self.threading_input[i][self.lt-4].set(0)
			self.threading_input[i][self.lt-3].set(0)
			self.threading_input[i][self.lt-2].set(20) #-2 for last one
		for i in range(self.n_items):
			self.thread_or_not[i].set('Maybe')

	def Update_Threading_Info(self): 
		self.max_threads = self.available_threads.get()
		self.relative_cost = self.relative_repair_cost.get()
		self.threads = [ self.threading_input[i][0].get() for i in range(self.n_items) ] 
		self.item_value = [ self.threading_input[i][1].get() for i in range(self.n_items) ] 
		self.durability = [ self.threading_input[i][2].get() for i in range(self.n_items) ] 
		self.max_durability = [ self.threading_input[i][3].get() for i in range(self.n_items) ]
		self.viable_states = []
		for state in product(range(2), repeat=self.n_items):
			if(self.Viable_Threading_State(state)==1):
				self.viable_states.append(state) 

	def Viable_Threading_State(self,test_state): 
		threads_used = int(0)
		for m in range(0,len(test_state)):
			threads_used += test_state[m]*self.threads[m]
		if( threads_used > self.max_threads ):
			return 0
		else:
			return 1

	def Left_Over_Threads(self,test_state):
		threads_used = int(0)
		for m in range(0,len(test_state)):
			threads_used += test_state[m]*self.threads[m]
		self.left_over_threads.set(self.max_threads-threads_used)

	def Run_Pvp_Threading(self):
		self.Update_Threading_Info()
		mls_loss = float(sum(self.item_value))
		mls = -1
		for i in range(0,len(self.viable_states)):
			state_loss = float(0.0)
			for j in range(0,len(self.viable_states[i])):
				if(self.viable_states[i][j]==0): #unthreaded
					state_loss += self.item_value[j]*self.durability[j]/self.max_durability[j] #all destroyed
				if(self.viable_states[i][j]==1): #threaded
					state_loss += self.relative_cost*self.item_value[j]/self.max_durability[j]
			if(state_loss < mls_loss):
				mls_loss = state_loss
				mls = i
			else:
				continue
		self.value_loss.set(mls_loss)
		for i in range(0,len(self.viable_states[mls])):
			if(self.viable_states[mls][i]==1):
				self.thread_or_not[i].set('Yes')
			else:
				self.thread_or_not[i].set('No')
		self.Left_Over_Threads(self.viable_states[mls])

	def Run_Pve_Threading(self):
		self.Update_Threading_Info()
		mls_loss = float(sum(self.item_value))
		mls = -1
		for i in range(0,len(self.viable_states)):
			state_loss = float(0.0)
			for j in range(0,len(self.viable_states[i])):
				if(self.viable_states[i][j]==0): #unthreaded
					state_loss += 0.25*self.item_value[j]*self.durability[j]/self.max_durability[j] #25% destroyed
					#state_loss += 0.75*self.relative_cost*self.item_value[j]/self.max_durability[j] #damaged
				if(self.viable_states[i][j]==1): #threaded
					state_loss += self.relative_cost*self.item_value[j]/self.max_durability[j]
			if(state_loss < mls_loss):
				mls_loss = state_loss
				mls = i
			else:
				continue
		self.value_loss.set(mls_loss)
		for i in range(0,len(self.viable_states[mls])):
			if(self.viable_states[mls][i]==1):
				self.thread_or_not[i].set('Yes')
			else:
				self.thread_or_not[i].set('No')
		self.Left_Over_Threads(self.viable_states[mls])

	def Store_Threading_Info(self):
		self.max_threads_stored = self.available_threads.get()
		self.relative_cost_stored = self.relative_repair_cost.get()
		self.threads_stored = [ self.threading_input[i][0].get() for i in range(self.n_items) ] 
		self.item_value_stored = [ self.threading_input[i][1].get() for i in range(self.n_items) ] 
		self.durability_stored = [ self.threading_input[i][2].get() for i in range(self.n_items) ] 
		self.max_durability_stored = [ self.threading_input[i][3].get() for i in range(self.n_items) ]
		self.have_stored_threading_info=True

	def Find_Threadings(self):
		threadings_directory = path.join(getcwd(),'threadings')
		threadings_list = []
		for x in listdir(threadings_directory):
			threadings_list.append(x)
		if(len(threadings_list)==0):
			threadings_list.append('None')
		return sorted(threadings_list)

	def Refresh_Threadings_List(self):
		new_threadings = self.Find_Threadings()
		self.import_threading_name.set(new_threadings[0])
		self.import_option_menu['menu'].delete(0, 'end')
		for name in new_threadings:
			self.import_option_menu['menu'].add_command(label=name, command=tk._setit(self.import_threading_name, name))

	def Export_Threading(self):
		x = self.export_threading_name.get()
		if(x==''):
			self.Set_Default_Threading_Export_Name()
			x = self.export_threading_name.get()
		fout = open(path.join(getcwd(), path.join('threadings', '%s.txt' %x)),'w')
		fout.write('%s\n' %str(self.available_threads.get()))
		fout.write('%s\n' %str(self.relative_repair_cost.get()))
		for i in range(self.n_items):
			fout.write(' '.join([ str(self.threading_input[i][j].get()) for j in range(4) ]))
			fout.write('\n')

	def Import_Threading(self):
		file_name = path.join(path.join(getcwd(),'threadings'), self.import_threading_name.get())
		fin = open(file_name,'r')
		threading = [ x.replace('\n','') for x in fin ]	
		self.available_threads.set(int(threading[0]))
		self.relative_repair_cost.set(float(threading[1]))
		self.relative_repair_cost.set(round(1000*self.relative_repair_cost.get())/1000)
		for j in range(self.n_items): 
			row = threading[j+2].split()
			for i in range(4):
				self.threading_input[j][i].set(int(row[i]))
		for i in range(self.n_items):			
			self.thread_or_not[i].set('Maybe')

	def Recall_Threading_Info(self):
		if(self.have_stored_threading_info==False):
			return 0
		self.available_threads.set(self.max_threads_stored)
		self.relative_repair_cost.set(self.relative_cost_stored)
		for i in range(len(self.threads_stored)): 
			self.threading_input[i][0].set(self.threads_stored[i])
			self.threading_input[i][1].set(self.item_value_stored[i])
			self.threading_input[i][2].set(self.durability_stored[i])
			self.threading_input[i][3].set(self.max_durability_stored[i])
			self.thread_or_not[i].set('Maybe')
		return 1
