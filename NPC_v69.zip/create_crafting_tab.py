import tkinter as tk
from recipe_reader import *
from message_window import Make_Message_Window
from re import split
from xlrd import open_workbook
from os import path, getcwd, listdir
from openpyxl import Workbook
from random import shuffle

def Find_Skill_Bonus(skill, tier):
	if(tier==1):
		return(0.8*skill/300)
	if(tier==2):
		skill = max(skill-80,0)
		return(0.8*skill/220)
	if(tier==3):
		skill = max(skill-140,0)
		return(0.8*skill/160)
	return 0.0

def Find_Recipe(recipe_name):
	for recipe in recipe_list:
		if(recipe.name==recipe_name):
			return recipe
	return None

def Find_Recipes(string, tier, rarity):
	result = []
	for recipe in recipe_list:
		if(string==recipe.type and tier==recipe.tier and rarity==recipe.rarity):
			result.append(recipe)
	return result

def Create_Recipe_Printout_Button(tab,variable):
	cmd = lambda z=variable: Find_Recipe(z.get()).printout()
	but = tk.Button(tab, text='Info', command=cmd)
	return but

def Find_Trainable_Recipes(profession, level, rarity):
	result = []
	for recipe in recipe_list:
		if(profession==recipe.profession and recipe.level<=level):
			for i in range(1,4): #refining
				x = '+%s' %i
				if(x in recipe.name):
					if(rarity=='Uncommon'):
						result.append(recipe)
						break
					if(rarity=='Common'):
						break
				else:
					if(i==3):
						if('+0' in recipe.name and rarity=='Common'): #get +0 refining for free
							result.append(recipe)
						if('+0' not in recipe.name and recipe.rarity==rarity): #crafting case
							result.append(recipe)
	return result

def Print_Trained_Recipes(trained,rarity): #rarity = Common/Uncommon
	result = []
	found_professions = []
	for feat in trained: 
		if(feat[0]!='Skills'):	
			continue
		for profession in profession_list:
			if(profession==feat[1]):
				found_professions.append(profession)
				result += Find_Trainable_Recipes(profession, feat[2], rarity)
	for profession in profession_list:
		if(profession not in found_professions):
			result += Find_Trainable_Recipes(profession, 0, rarity)
	mw = Make_Message_Window()
	if(rarity=='Common'):
		title = 'Free Recipes'
	if(rarity=='Uncommon'):
		title = 'Trainable Recipes'
	column_names = [ 'Recipe', 'Profession', 'Achievement Type', 'Level', 'Tier' ]
	column_entries = [ ]
	width = 10
	for recipe in result:
		column_entries.append([recipe.name, recipe.profession, recipe.rarity, recipe.level, recipe.tier])
		width = max(width,len(recipe.name))
	if(column_entries==[]):
		column_entries = [['None', 'None', 'None', 0, 0]]
	column_entries = sorted(column_entries, key=lambda entry: entry[1])
	widths = [ width, 15, 15, 10, 10 ]
	mw.update_columns(title, column_names, column_entries, widths)
	mw.new_window()	

class Create_Crafting_Tab:
	def __init__(self,tab):
		t = tab
		self.list_of_recipes = [[[ sorted([recipe.name for recipe in Find_Recipes(recipe_types[i],tier,rarity)]) for i in range(len(recipe_types)) ] for tier in [1,2,3]] for rarity in ['Common','Uncommon'] ]
		self.recipe_variables = [[[ tk.StringVar() for i in range(len(recipe_types)) ] for tier in [1,2,3]] for rarity in ['Common','Uncommon'] ]
		for j, rarity in enumerate(['Common','Uncommon']):
			for tier in [1,2,3]:
				for rt in range(len(self.list_of_recipes)):
					r, c = j+2*(tier-1), 3*rt
					self.recipe_variables[j][tier-1][rt].set(self.list_of_recipes[j][tier-1][rt][0])
					tk.OptionMenu(t, self.recipe_variables[j][tier-1][rt], *self.list_of_recipes[j][tier-1][rt]).grid(row=r,column=c,sticky="NEWS")
					tk.Label(t, text='Tier %s %s %s' %(tier, rarity, recipe_types[rt]),relief='sunken').grid(row=r,column=c+1,sticky="NEWS")
					Create_Recipe_Printout_Button(t,self.recipe_variables[j][tier-1][rt]).grid(row=r,column=c+2,sticky="NEWS")
		self.component_variable = tk.StringVar()
		self.component_variable.set(components[0])
		self.component_lookup_option_menu = tk.OptionMenu(t, self.component_variable, *components)
		self.component_lookup_option_menu.grid(row=0,column=6,sticky="NEWS")
		tk.Button(t, text='Find Recipes w/ Component', command=self.Find_Recipe_With_Component).grid(row=0,column=7,sticky="NEWS")

		self.n_inputs = 10
		self.have_components = [ tk.StringVar() for i in range(self.n_inputs) ]
		self.have_component_numbers = [ tk.IntVar() for i in range(self.n_inputs) ]
		self.what_can_i_option_menus = []
		for i in range(self.n_inputs):
			self.have_components[i].set(components[0])
			self.have_component_numbers[i].set(0)
			self.what_can_i_option_menus.append(tk.OptionMenu(t, self.have_components[i], *components))
			self.what_can_i_option_menus[i].grid(row=i+1,column=6,sticky="NEWS")
			tk.Entry(t, textvariable=self.have_component_numbers[i]).grid(row=i+1,column=7,sticky="NEWS")
		tk.Button(t, text='What can I craft?', command=self.What_Can_I_Craft).grid(row=self.n_inputs+1,column=6,columnspan=2,sticky="NEWS")

		self.base_time = tk.IntVar()
		self.base_time.set(10)	
		tk.Label(t, text='Base time (s)').grid(row=self.n_inputs+2,column=6,sticky="NEWS")
		tk.Entry(t, textvariable=self.base_time).grid(row=self.n_inputs+2,column=7,sticky="NEWS")	
		self.quality = tk.IntVar()
		self.quality.set(10)
		tk.Label(t, text='Quality (+0 for crafting)').grid(row=self.n_inputs+3,column=6,sticky="NEWS")
		tk.Entry(t, textvariable=self.quality).grid(row=self.n_inputs+3,column=7,sticky="NEWS")		
		self.skill = tk.IntVar()
		self.skill.set(10)
		tk.Label(t, text='Skill').grid(row=self.n_inputs+4,column=6,sticky="NEWS")
		tk.Entry(t, textvariable=self.skill).grid(row=self.n_inputs+4,column=7,sticky="NEWS")
		self.facility = tk.IntVar()
		self.facility.set(10)
		tk.Label(t, text='Facility').grid(row=self.n_inputs+5,column=6,sticky="NEWS")
		tk.Entry(t, textvariable=self.facility).grid(row=self.n_inputs+5,column=7,sticky="NEWS")
		self.item_plus = tk.IntVar()
		self.item_plus.set(0)
		tk.Label(t, text='Item plus (crafting only)').grid(row=self.n_inputs+6,column=6,sticky="NEWS")
		tk.Entry(t, textvariable=self.item_plus).grid(row=self.n_inputs+6,column=7,sticky="NEWS")
		self.crafting_time = tk.StringVar()
		self.crafting_time.set('0.0')
		tk.Label(t, text='Crafting time').grid(row=self.n_inputs+7,column=6,sticky="NEWS")
		tk.Entry(t, textvariable=self.crafting_time).grid(row=self.n_inputs+7,column=7,sticky="NEWS")
		tk.Button(t, text='Find crafting time', command=self.Find_Crafting_Time).grid(row=self.n_inputs+8,column=6,columnspan=2,sticky="NEWS")

		self.search_string = tk.StringVar()
		self.search_string.set('Search recipes here. Commas treated as OR')
		e = tk.Entry(t, textvariable=self.search_string)
		e.grid(row=6,column=0,columnspan=4,sticky="NEWS")
		tk.Button(t, text='Find', command=self.Find).grid(row=6,column=4,sticky="NEWS")
		e.bind('<Key>',self.key)

		recipe_names = sorted([ r.name for r in recipe_list ])
		self.chosen_recipe = tk.StringVar()
		self.chosen_recipe.set(recipe_names[0])
		self.recipe_option_menu = tk.OptionMenu(t, self.chosen_recipe, *recipe_names)
		self.recipe_option_menu.grid(row=7,column=0,sticky="NEWS")
		tk.Button(t, text='Copy Down', command=self.Copy_Down).grid(row=8,column=0,sticky="NEWS")

		tk.Label(t, text='Recipe Tier', relief='sunken').grid(row=7,column=1,sticky="NEWS")
		self.recipe_tier = tk.IntVar()
		self.recipe_tier.set(1)
		tk.Entry(t, textvariable=self.recipe_tier).grid(row=7,column=2,sticky="NEWS")

		tk.Label(t, text='Crafting Bonus', relief='sunken').grid(row=7,column=3,columnspan=2,sticky="NEWS")
		tk.Label(t, text='Number Required',relief='sunken').grid(row=9,column=0,sticky="NEWS")
		self.component_needs = [ tk.IntVar() for i in range(4) ]
		self.component_inputs = [ [tk.IntVar() for j in range(6)] for i in range(4) ]
		needs = [4,2,2,0]
		self.component_names = [tk.StringVar() for i in range(4)]
		for compnum in range(4):
			self.component_names[compnum].set('Component #%s' %(compnum+1))
			self.component_needs[compnum].set(needs[compnum])
			tk.Entry(t, textvariable=self.component_names[compnum]).grid(row=8,column=compnum+1,sticky="NEWS")
			tk.Entry(t, textvariable=self.component_needs[compnum]).grid(row=9,column=compnum+1,sticky="NEWS")
			for bonus in range(6):
				self.component_inputs[compnum][bonus].set(0)
				tk.Label(t, text='+%s' %bonus,relief='sunken').grid(row=10+bonus,column=0,sticky="NEWS")
				tk.Entry(t, textvariable=self.component_inputs[compnum][bonus]).grid(row=10+bonus,column=compnum+1,sticky="NEWS")
		self.final_bonus = tk.DoubleVar()
		self.final_bonus.set(0.0)
		tk.Button(t, text='Find Bonus', command=self.Find_Bonus).grid(row=16,column=0,sticky="NEWS")	
		tk.Entry(t, textvariable=self.final_bonus).grid(row=16,column=1,sticky="NEWS")
		self.int_final_bonus = tk.IntVar()
		self.int_final_bonus.set(int(self.final_bonus.get()))
		tk.Label(t, text='Actual Bonus').grid(row=17,column=0,sticky="NEWS")
		tk.Entry(t, textvariable=self.int_final_bonus).grid(row=17,column=1,sticky="NEWS")

		workbooks = self.Find_Workbooks()
		self.import_name = tk.StringVar()
		if(len(workbooks)>0):
			self.import_name.set(workbooks[0])
		self.import_option_menu = tk.OptionMenu(t, self.import_name, *workbooks)
		self.import_option_menu.grid(row=18,column=2,sticky="NEWS") #crashes if directory is empty
		tk.Button(t, text='Import Prices', command=self.Import_Costs).grid(row=18,column=3,sticky="NEWS")
		tk.Button(t, text='Refresh list', command=self.Refresh_Import_List).grid(row=18,column=4,sticky="NEWS")
		self.final_cost = tk.IntVar()
		self.final_cost.set(0)
		self.refined_costs = []
		self.finished_costs = []
		tk.Label(t, text='Total Cost').grid(row=18,column=0,sticky="NEWS")
		tk.Entry(t, textvariable=self.final_cost).grid(row=18,column=1,sticky="NEWS")
		self.sell_price = tk.IntVar()
		self.sell_price.set(0)
		tk.Label(t, text='Sell Price').grid(row=19,column=0,sticky="NEWS")
		tk.Entry(t, textvariable=self.sell_price).grid(row=19,column=1,sticky="NEWS")
		tk.Label(t, text='Note', relief='sunken').grid(row=16,column=2,sticky="NEWS")
		self.error_message = tk.StringVar()
		self.error_message.set('')
		tk.Entry(t, textvariable=self.error_message).grid(row=16,column=3,columnspan=2,sticky="NEWS")
		self.new_workbook_name = tk.StringVar()
		self.Set_Default_Fresh_Name()
		tk.Entry(t, textvariable=self.new_workbook_name).grid(row=19,column=2,sticky="NEWS")
		tk.Button(t, text='New Price File', command=self.Create_Fresh_Workbook).grid(row=19,column=3,sticky="NEWS")
		tk.Button(t, text='Find lowest cost for this bonus', command=self.Minimize_Cost).grid(row=17,column=2,columnspan=2,sticky="NEWS")
		tk.Label(t, text='Find best items to craft').grid(row=20,column=0,columnspan=2,sticky="NEWS")
		tk.Button(t, text='Find Best', command=self.Maximal_Profits).grid(row=20,column=2,sticky="NEWS")

		tk.Label(t, text='Skill/Bonus/Facility').grid(row=0,column=9,columnspan=3,sticky="NEWS")
		self.include_professions = [ tk.IntVar() for prof in profession_list ]
		self.checks = [ tk.Checkbutton(t, text=profession_list[i], variable=self.include_professions[i]).grid(row=i+1,column=8,sticky="NEWS") for i in range(len(profession_list)) ]
		self.profession_levels = [ tk.IntVar() for prof in profession_list ]
		self.skill_levels = [ tk.IntVar() for prof in profession_list ]
		self.facility_levels = [ tk.IntVar() for prof in profession_list ]
		for i in range(len(profession_list)):
			self.include_professions[i].set(1)
			self.profession_levels[i].set(5)
			self.skill_levels[i].set(50)
			self.facility_levels[i].set(50)
		self.e1 = [ tk.Entry(t, textvariable=self.profession_levels[i],width=4).grid(row=i+1,column=9,sticky="NEWS") for i in range(len(profession_list)) ]
		self.e2 = [ tk.Entry(t, textvariable=self.skill_levels[i],width=5).grid(row=i+1,column=10,sticky="NEWS") for i in range(len(profession_list)) ]
		self.e3 = [ tk.Entry(t, textvariable=self.facility_levels[i],width=5).grid(row=i+1,column=11,sticky="NEWS") for i in range(len(profession_list)) ]
		tk.Button(t, text='Minimize All', command=self.minimize_all).grid(row=len(profession_list)+1,column=8,columnspan=4,sticky="NEWS")
		tk.Button(t, text='Maximize All', command=self.maximize_all).grid(row=len(profession_list)+2,column=8,columnspan=4,sticky="NEWS")
		tk.Button(t, text='Pare Down Lists', command=self.pare_down).grid(row=len(profession_list)+3,column=8,columnspan=4,sticky="NEWS")
		self.allow_zeros = tk.IntVar()
		self.allow_zeros.set(0)
		tk.Checkbutton(t, text='Include level 0 recipes', variable=self.allow_zeros).grid(row=len(profession_list)+4,column=8,columnspan=2,sticky="NEWS")

	def key(self,event):
		if(event.keysym=='Return'):
			self.Find()

	def minimize_all(self):
		for i in range(len(profession_list)):
			self.include_professions[i].set(0)
			self.profession_levels[i].set(0)
			self.skill_levels[i].set(10)
			self.facility_levels[i].set(10)

	def maximize_all(self):
		for i in range(len(profession_list)):
			self.include_professions[i].set(1)
			self.profession_levels[i].set(20)
			self.skill_levels[i].set(300)
			self.facility_levels[i].set(300)

	def pare_down(self):
		chosen_professions = [ prof for prof in profession_list if self.include_professions[profession_list.index(prof)].get()==1]
		allowed_components = []
		recipe_names = []
		crafting_names = []
		for recipe in recipe_list:
			if(recipe.profession in chosen_professions and recipe.level<=self.profession_levels[profession_list.index(recipe.profession)].get()):
				recipe_names.append(recipe.name)
				if(recipe.type=='Crafting'):
					crafting_names.append(recipe.name)
				for component in recipe.components:
					if(component==''):
						continue
					allowed_components.append(component)
			if(self.allow_zeros.get()==1):
				if(recipe.name not in recipe_names and recipe.level==0):
					recipe_names.append(recipe.name)
					if(recipe.type=='Crafting'):
						crafting_names.append(recipe.name)
					for component in recipe.components:
						if(component==''):
							continue
						allowed_components.append(component)
		if(len(recipe_names)==0):
			return
		crafting_names = sorted(crafting_names)
		recipe_names = sorted(recipe_names)
		allowed_components = sorted(list(set(allowed_components)))
		if(len(crafting_names)>0):
			self.chosen_recipe.set(crafting_names[0])
			self.recipe_option_menu['menu'].delete(0, 'end')
			for name in crafting_names:
				self.recipe_option_menu['menu'].add_command(label=name, command=tk._setit(self.chosen_recipe,name))
		self.component_lookup_option_menu['menu'].delete(0, 'end')
		self.component_variable.set(allowed_components[0])
		for i in range(self.n_inputs):
			self.have_components[i].set(allowed_components[0])
			self.what_can_i_option_menus[i]['menu'].delete(0,'end')
		for comp in allowed_components:
			self.component_lookup_option_menu['menu'].add_command(label=comp, command=tk._setit(self.component_variable,comp))
			for i in range(self.n_inputs):
				self.what_can_i_option_menus[i]['menu'].add_command(label=comp, command=tk._setit(self.have_components[i],comp))

	def Find_Crafting_Time(self):
		b = self.base_time.get()
		q = self.quality.get()
		s = self.skill.get()
		f = self.facility.get()
		i = self.item_plus.get()#not used yet. seems to be q = q+k*i, eg. k=18 q=10, k=16 q=20, k=14 q=30, k=12 q=40, k=4 q=80, gives k=0 at q=100.
		#5*k+q%100=100
		q = q+i*(100-q%100)/5
		if(s*f==0):
			self.crafting_time.set('Dividing by 0')
			return
		total_seconds = (b*q*q)/(s*f)
		hours = int(total_seconds/3600)
		minutes = int((total_seconds/60)%60)
		seconds = int(total_seconds%60)
		self.crafting_time.set('%s h/%s m/%s s' %(hours,minutes,seconds))		

	def What_Can_I_Craft(self):
		chosen_professions = [ prof for prof in profession_list if self.include_professions[profession_list.index(prof)].get()==1]
		have_components = [ self.have_components[i].get() for i in range(self.n_inputs) if self.have_component_numbers[i].get()>0 ]
		have_component_numbers = [ self.have_component_numbers[i].get() for i in range(self.n_inputs) if self.have_component_numbers[i].get()>0 ]
		junk = []
		results = []
		for recipe in recipe_list:
			if(recipe.level>0):
				if(recipe.profession not in chosen_professions):
					continue
				if(recipe.level>self.profession_levels[profession_list.index(recipe.profession)].get()):
					continue
			if(recipe.level==0):
				if(self.allow_zeros.get()==0):#so only want allowed professions
					if(recipe.profession not in chosen_professions):
						continue
			ratio = 10000
			qualifies = True
			for component in recipe.components:
				if(component==''):
					continue
				if(component not in have_components):
					qualifies = False
				else:
					need = recipe.component_numbers[recipe.components.index(component)]
					have = have_component_numbers[have_components.index(component)]
					ratio = min(ratio,int(have/need))
					if(need>have):
						qualifies = False
			if(qualifies):
				results.append([recipe,ratio])
		mw = Make_Message_Window()
		title = 'Craftable with: '
		column_entries = []
		proto_entries = []
		width = 10
		for r in results:
			to_include = [r[0].name,r[0].profession,r[0].level,r[1]]
			for component in have_components:
				if(component in r[0].components):
					to_include.append(r[0].component_numbers[r[0].components.index(component)])
				else:
					to_include.append(0)
			proto_entries.append(to_include)
			width = max(width,len(r[0].name))
		if(len(results)==0):
			column_entries = [['None','None',0,0]]
		else:
			column_entries = [ [entry for entry in column] for column in proto_entries ]
		column_names = [ 'Recipe', 'Profession', 'Skill', 'Max Number Craftable' ]
		widths = [ width, 25, 10, 10] 
		n_pops = 0
		for i, component in enumerate(have_components):
			if(len(results)==0):
				column_entries[0].append(0)
			if(sum([proto_entries[j][i+4] for j in range(len(proto_entries))])==0):
				for row in range(len(column_entries)):
					column_entries[row].pop(i+4-n_pops)
				n_pops += 1
				continue
			title += '%s, ' %component
			column_names.append(component)
			widths.append(10)
		title = title[:-2]
		column_entries = sorted(column_entries, key=lambda entry: entry[0])
		mw.update_columns(title, column_names, column_entries, widths)
		mw.new_window()

	def Find_Bonus(self):
		self.error_message.set('')
		totals = []
		sum_tiers = 0
		for compnum in range(4):
			if(self.component_needs[compnum].get()==0):
				continue
			component_tier = 3 #hack: find all recipes with component and take minimum tier
			for recipe in recipe_list:
				if self.component_names[compnum].get() in recipe.components:
					component_tier = min(component_tier, recipe.tier)
					if(component_tier==1):
						break
			totals.append(0)
			haves = 0
			for bonus in range(6):
				totals[compnum] += self.component_inputs[compnum][bonus].get()*bonus
				haves += self.component_inputs[compnum][bonus].get()
			totals[compnum] = component_tier*totals[compnum]/self.component_needs[compnum].get()
			sum_tiers += component_tier
			if(haves!=self.component_needs[compnum].get()):
				self.error_message.set('Incorrect number of %s' %self.component_names[compnum].get())
		if(len(totals)==0):
			self.final_bonus.set(0.0)
			return
		bonus = 0.0
		try:
			index = profession_list.index(Find_Recipe(self.chosen_recipe.get()).profession)
			bonus = Find_Skill_Bonus(self.skill_levels[index].get(), self.recipe_tier.get())
		except:
			pass
		if(sum_tiers==0):
			return
		self.final_bonus.set(sum(totals)/sum_tiers)#len(totals))
		self.final_bonus.set(self.final_bonus.get()+bonus)
		self.final_bonus.set(round(100*self.final_bonus.get())/100)
		self.int_final_bonus.set(int(self.final_bonus.get()))
		self.Calculate_Cost()
		self.sell_price.set(self.Find_Finished_Cost(self.chosen_recipe.get(), self.int_final_bonus.get()))
		return

	def Copy_Down(self):
		recipe = Find_Recipe(self.chosen_recipe.get())
		self.recipe_tier.set(recipe.tier)
		numbers = [ n for n in recipe.component_numbers ]
		for n in range(4):
			try:
				self.component_needs[n].set(numbers[n])
				self.component_names[n].set(recipe.components[n])
			except:
				self.component_needs[n].set(0)
				self.component_names[n].set('N/A')
		if(recipe.quality>0):
			self.quality.set(recipe.quality)
			self.base_time.set(recipe.base_time)
			index = profession_list.index(recipe.profession)
			self.skill.set(self.skill_levels[index].get())
			self.facility.set(self.facility_levels[index].get())
			self.Find_Crafting_Time()

	def Find_Recipe_With_Component(self):
		chosen_professions = [ prof for prof in profession_list if self.include_professions[profession_list.index(prof)].get()==1]
		result = []
		for recipe in recipe_list:
			if(recipe.level>0):
				if(recipe.profession not in chosen_professions):
					continue
				if(recipe.level>self.profession_levels[profession_list.index(recipe.profession)].get()):
					continue
			if(recipe.level==0):
				if(self.allow_zeros.get()==0):#so only want allowed professions
					if(recipe.profession not in chosen_professions):
						continue
			if(self.component_variable.get() in recipe.components):
				result.append(recipe.name)
		result = sorted(result)
		mw = Make_Message_Window()
		title = 'Component: %s' %self.component_variable.get()
		column_names = [ 'Recipe', 'Profession', 'Level', 'Tier', 'Rarity', 'Quantity' ]
		column_entries = [ ]
		width = 10
		for recipe_name in result:
			recipe = Find_Recipe(recipe_name)
			quantity = recipe.component_numbers[recipe.components.index(self.component_variable.get())]
			column_entries.append([recipe.name, recipe.profession, recipe.level, recipe.tier, recipe.rarity, quantity])
			width = max(width,len(recipe.name))
		if(len(result)==0):
			column_entries = [['None','None',0,0,'None',0]]
		column_entries = sorted(column_entries, key=lambda entry: entry[0])
		widths = [ width, 15, 10, 10, 10, 10 ]
		mw.update_columns(title, column_names, column_entries, widths)
		mw.new_window()

	def Find(self):
		searches = [s.lstrip().rstrip().lower() for s in self.search_string.get().split(',')]
		lower_recipe_names = [ recipe.name.lower() for recipe in recipe_list ]
		recipe_names = [ recipe.name for recipe in recipe_list ]
		result = []
		for search in searches:
			for name in lower_recipe_names:
				if(search in name):
					index = lower_recipe_names.index(name)
					result.append(recipe_names[index])
		if(len(result)==1):
			Find_Recipe(result[0]).printout()
			return
		mw = Make_Message_Window()
		title = 'Search Results: %s' %self.search_string.get()
		column_names = [ 'Recipe', 'Profession', 'Level', 'Tier', 'Rarity' ]
		column_entries = [ ]
		width = 10
		for recipe_name in result:
			recipe = Find_Recipe(recipe_name)
			column_entries.append([recipe.name, recipe.profession, recipe.level, recipe.tier, recipe.rarity])
			width = max(width,len(recipe.name))
		if(len(result)==0):
			column_entries = [['None','None',0,0,'None']]
		column_entries = sorted(column_entries, key=lambda entry: entry[0])
		widths = [ width, 15, 10, 10, 10 ]
		mw.update_columns(title, column_names, column_entries, widths)
		mw.new_window()

	def Find_Workbooks(self):
		return sorted(listdir(path.join(getcwd(),'local_prices')))

	def Set_Costs(self,workbook,sheet_name,outvariable):
		sheet = workbook.sheet_by_name(sheet_name)
		for rownum in range(sheet.nrows):
			row = sheet.row_values(rownum)
			try:
				outvariable.append([row[0],int(row[1])])
			except:
				continue

	def Refresh_Import_List(self):
		new_imports = self.Find_Workbooks()
		self.import_name.set(new_imports[0])
		self.import_option_menu['menu'].delete(0, 'end')
		for name in new_imports:
			self.import_option_menu['menu'].add_command(label=name, command=tk._setit(self.import_name, name))

	def Import_Costs(self):
		work_book = open_workbook(path.join(path.join(getcwd(),'local_prices'), self.import_name.get()))
		self.refined_costs = []
		self.finished_costs = []
		self.Set_Costs(work_book,'Refined Component Costs',self.refined_costs)
		self.Set_Costs(work_book,'Finished Product Prices',self.finished_costs)	

	def Find_Price(self, name, bonus, price_list):
		name = '%s +%s' %(name, bonus)
		cost = 12345678906
		for x in price_list:
			if name==x[0]:
				cost = int(x[1])
		if(cost==12345678906):			
			self.error_message.set('Price not found for %s' %name)
		return cost

	def Find_Refined_Cost(self, component, bonus):
		return self.Find_Price(component, bonus, self.refined_costs)

	def Find_Finished_Cost(self, finished, bonus):
		return self.Find_Price(finished, bonus, self.finished_costs)

	def Calculate_Cost(self,want_return=False):
		total = 0
		for compnum in range(4):
			if(self.component_needs[compnum].get()==0):
				continue 
			for bonus in range(6):
				number = self.component_inputs[compnum][bonus].get()
				if(number>0):
					total += number*self.Find_Refined_Cost(self.component_names[compnum].get(),bonus)
		if(not want_return):
			self.final_cost.set(total)
		else: 
			return total

	def Set_Default_Fresh_Name(self):
		self.new_workbook_name.set('New_Local_Prices')

	def Create_Fresh_Workbook(self): #want to pare down to just those that the player can do!
		chosen_professions = [ prof for prof in profession_list if self.include_professions[profession_list.index(prof)].get()==1]
		if(len(chosen_professions)==0):
			self.error_message.set('You need to pick crafting professions')
			return
		fresh = Workbook()
		bad_sheet = fresh.get_sheet_by_name('Sheet')
		fresh.remove_sheet(bad_sheet)
		ws = fresh.create_sheet()
		ws.title = 'Refined Component Costs'
		ws.cell(row=1,column=1).value = 'Component'
		ws.cell(row=1,column=2).value = 'Cost'
		crafting_components = []
		names = []
		for recipe in recipe_list:
			if(recipe.type=='Crafting'):
				if(recipe.profession in chosen_professions and recipe.level<=self.profession_levels[profession_list.index(recipe.profession)].get()):
					names.append(recipe.name)
					for component in recipe.components:
						if(component==''):
							continue
						crafting_components.append(component)
		crafting_components = sorted(list(set(crafting_components)))
		names = sorted(names)
		for r, comp in enumerate(crafting_components):
			for bonus in range(6):
				row = 6*r+bonus+2
				ws.cell(row=row,column=1).value = '%s +%s' %(comp, bonus)
				#ws.cell(row=row,column=2).value = 10#TEMP
		ws = fresh.create_sheet()
		ws.title = 'Finished Product Prices'
		ws.cell(row=1,column=1).value = 'Finished Item'
		ws.cell(row=1,column=2).value = 'Price'
		for r, name in enumerate(names):
			for bonus in range(6):
				row = 6*r+bonus+2
				ws.cell(row=row,column=1).value = '%s +%s' %(name, bonus)
		if(self.new_workbook_name.get()==''):
			self.Set_Default_Fresh_Name()
		fresh.save('%s.xlsx' %path.join(path.join(getcwd(),'local_prices'),self.new_workbook_name.get()))

	def Minimize_Cost(self):
		bonus = self.int_final_bonus.get()
		self.needs = []
		for compnum in range(4):
			if 'Component' in self.component_names[compnum].get():
				return
			for b in range(6):
				self.component_inputs[compnum][b].set(0)
			self.needs.append(self.component_needs[compnum].get())
			self.component_inputs[compnum][bonus].set(self.needs[compnum])
		if(bonus in [0,5]):
			self.Find_Bonus()
			return
		while 0 in self.needs:
			self.needs.pop(self.needs.index(0)) #get rid of all 0s
		self.costs = [ [self.Find_Refined_Cost(self.component_names[compnum].get(),bonus) for bonus in range(6)] for compnum in range(len(self.needs)) ]
		self.Recursive(bonus,0,self.Calculate_Cost(True))

	def Recursive(self,bonus,failures,current_cost):
		l1 = list(range(len(self.needs)))
		l2 = list(range(len(self.needs)))
		shuffle(l1) #so that don't get stuck in the loop indefinitely
		shuffle(l2)
		for c1 in l1: #ups
			for c2 in l2: #downs
				for b1 in [b for b in range(6) if self.component_inputs[c1][b].get()!=0]:
					if(b1==5):
						continue
					for b2 in [b for b in range(6) if self.component_inputs[c2][b].get()!=0]:
						if(b2==0):
							continue
						for u,d in [(1,1)]:#, (1,2), (1,3), (1,4), (2,2), (2,3)]: #all possible up/downs. recursion depth issues adding all
							if(u+b1>5 or b2-d<0):
								continue
							#print(b1, u, b2, d)
							up = (self.costs[c1][b1+u]-self.costs[c1][b1])*self.needs[c1] #change in price times number of units
							down = (self.costs[c2][b2]-self.costs[c2][b2-d])*self.needs[c2]
							if(down>up):
								ratio = float(self.needs[c1]*u/self.needs[c2]*d)
								if(ratio>1.0):
									n1, n2 = int(ratio)+1, 1 #number up, number down
									if(ratio.is_integer()):
										n1 -= 1
								else: 
									ratio = 1.0/ratio
									n1, n2 = 1, int(ratio)+1
									if(ratio.is_integer()):
										n2 -= 1
								if(n1>self.component_inputs[c1][b1].get() or n2>self.component_inputs[c2][b2].get()): 
									continue
								i11 = self.component_inputs[c1][b1]
								i12 = self.component_inputs[c1][b1+u]
								i21 = self.component_inputs[c2][b2]
								i22 = self.component_inputs[c2][b2-d]
								i11.set(i11.get()-n1)
								i12.set(i12.get()+n1)
								i21.set(i21.get()-n2)
								i22.set(i22.get()+n2)
								new_cost = self.Calculate_Cost(True)
								totals = [ 0 for i in range(len(self.needs))]
								for compnum in range(len(self.needs)):
									for bon in range(6):
										totals[compnum] += self.component_inputs[compnum][bon].get()*bon
									totals[compnum] = totals[compnum]/self.component_needs[compnum].get()
								fbonus = sum(totals)/len(totals)
								if(fbonus<bonus or new_cost>current_cost):
									failures += 1
									i11.set(i11.get()+n1)
									i12.set(i12.get()-n1)
									i21.set(i21.get()+n2)
									i22.set(i22.get()-n2)
									if(failures>10):
										self.Find_Bonus()
								else:
									print('improvement')
									failures = 0
									self.Recursive(bonus,failures,new_cost)
		self.Find_Bonus()		

	def Maximal_Profits(self):
		chosen_professions = [ prof for prof in profession_list if self.include_professions[profession_list.index(prof)].get()==1]
		results = []
		for recipe in recipe_list:
			if(recipe.level>0):
				if(recipe.profession not in chosen_professions):
					continue
				if(recipe.level>self.profession_levels[profession_list.index(recipe.profession)].get()):
					continue
			if(recipe.level==0):
				if(self.allow_zeros.get()==0):#so only want allowed professions
					if(recipe.profession not in chosen_professions):
						continue
			if(recipe.type=='Crafting'):
				results.append(recipe)
		width = 10
		column_entries = []
		for recipe in results:
			self.chosen_recipe.set(recipe.name)
			self.Copy_Down()
			width = max(width,len(recipe.name))
			for bonus in range(6):
				self.int_final_bonus.set(bonus)
				self.Minimize_Cost()
				self.item_plus.set(bonus)
				time = 0
				time_tuple = '0 h/0 m/0 s'
				if(recipe.quality>0):
					self.item_plus.set(bonus)
					self.Find_Crafting_Time()
					time_tuple = self.crafting_time.get().split('/')
					hours = int(time_tuple[0].split()[0])
					minutes = int(time_tuple[0].split()[0])
					seconds = int(time_tuple[0].split()[0])
					time = hours+(minutes/60)+(seconds/3600)
					time_tuple = '/'.join(time_tuple)
				name = recipe.name
				cost = self.final_cost.get()
				price = self.sell_price.get()
				profit = price-cost
				profit_p = 0
				if(cost!=0):
					profit_p = round(1000*profit/cost*100)/1000
				pph = 0
				if(time!=0):
					pph = round(100*profit/time)/100
				c0 = '/'.join([str(self.component_inputs[0][b].get()) for b in range(6)])
				c1 = '/'.join([str(self.component_inputs[1][b].get()) for b in range(6)])
				c2 = '/'.join([str(self.component_inputs[2][b].get()) for b in range(6)])
				c3 = '/'.join([str(self.component_inputs[3][b].get()) for b in range(6)])
				column_entries.append([name,bonus,pph,profit,profit_p,time_tuple,price,cost,c0,c1,c2,c3])
		mw = Make_Message_Window()
		title = 'Crafting Profits'
		column_names = ['Recipe','Bonus','Profit per hour','Profit','Profit(%)','Crafting Time','Sell Price','Lowest Cost','Component #1','Component #2','Component #3','Component #4'] 
		if(column_entries==[]):
			column_entries = [['None', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]]
		column_entries = sorted(column_entries, key=lambda entry: entry[2], reverse=True)
		widths = [ width, 10, 10, 10, 10, 15, 10, 10, 10, 10, 10, 10 ]
		mw.update_columns(title, column_names, column_entries, widths)
		mw.new_window()

#BELOW IS FOR LATER VERSIONS FOR TRACKING LEARNED RECIPES

	#def Import_Learned_Recipes(self):
	#def Add_To_Learned_Recipes(self,recipe_name):
	#def Undo_Last_Learned(self):
	#def Export_Learned_Recipes(self):
	#def Find_Trainable_Recipes(self):
