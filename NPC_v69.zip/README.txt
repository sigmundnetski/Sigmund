ABOUT:
======
*Made by 'Nightdrifter'.
*These calculators are an evolving project. New versions will be posted on paizo and goblinworks forums under the threads "Simple PFO Calculators" and "PFO Calculators" respectively. Each new version is usually a minor improvement upon the previous one. Links are to my google docs.
*Design goals: 
1) No (or at least minimal) hard-coded data to allow for quick updating when new dev information is available. This should also allow members of the community to take over updating the data files so that I can focus on the coding.
2) Anything beyond default Python modules will be made installable with a simple script.
3) Relatively little computational power needed so that they can be run at the same time as PFO.
*Feature requests will be considered. It depends on how easy the feature is to implement and how heavy it would be computation-wise.

REQUIRED TO RUN:
================
*Windows only. It should be relatively easy to make a Linux version if there's interest. See pdf for how to get Mac working.
*Python 3. Python 2 has different module names and slightly different functionality and so will not work.
*Python's xlrd and openpyxl modules. Just double clink install_extra_python_modules.py once python is installed.

HOW TO USE:
===========
*Double click on NPC.pyw.
*Note that any changes made to input files will only take effect upon reopening the calculators.

NOTES:
======
*The first time use the calculators it will compile the code. It will take a few seconds depending on your computer. Other times should be faster. This will create a __pycache__ folder with files in it similar in name to many of the .py files. Don't delete or move this folder or it will need to recompile.
*It will take a few seconds to load each time you open the calculators. This is because they have to read in the input each time. Hard-coding of data would make this much faster, but greatly complicate updating for new dev data.
*Keep the folders where they are relative to eachother!

INPUT/OUTPUT:
=============
*racial_feats folder (lists of free feats based on race)
*ignored_feats text file (feats to ignore in training)
*local_prices folder (local market prices)
*saved_files folder (output of saving message windows)
*threading folder (input/output of gear threading)
*training_plans folder (input/output for training plans)

Thms:
=====
*When two attacks do similar damage against 0 resistance, choose the one with a lower damage factor. That is, if they have a different number of matched keywords and damage factors and yet do comparable damage against 0 resistance then the one with fewer matches and higher damage factor will drop off in damage faster than the other as the target's resistance increases.
*Use biggest cc first as the diminishing returns are essentially percentage based.
*Ignoring penetrating/precise/different resistance/different defense the attack more damaging/stamina efficient against r1 with also be against r2.

BUGS:
=====
*Reputation scaling is out of date: https://goblinworks.com/blog/closing-the-gap-to-early-enrollment/
*prerequisites of requirements not included in role xp. complicated to add.
*penetrating conversions
*different map system for the map I used for hex numbers
*Account for relevant resistance in secondary effect duration?

NEED FROM DEVS:
===============
-exact die used in crits (d1000, d10000?)
-do states (eg. dazed) scale with effect power/reduced effect?
-bleeds etc still reduce defences? inconsistent in combat guide
-effect power on stacking?
-regen?
-wearables
-fighter feature matching
-settlement
-faction/alignment
-raw counts as...
-razed recovery
-feat role counts as
-resistance on non-dot secondaries?
-new threat
-stealth change?
-sprinting/movement changes
-new encumbrance
-loot table
-formation
-sads

SURVEY:
=======
-speed of running the app
-os used
-download each update or not
-how much play
-most used tab (first 3?)
-requests
for each tab+mw:
-understandable
-useful
-aesthetics/layout

V69 CHANGELOG:
============
*Added a gear tab. This allows you to mock equip various pieces of gear and determine which keywords apply to your utilities. You can also search for gear based on their keywords. This tab is a work in progress and will [i]hopefully[/i] (time frame tbd) eventually become a mock paperdoll for determining your stats.
*Adjusted crafting bonus calculation on the crafting tab based on [url=https://goblinworks.com/forum/topic/1338/]info from Stephen[/url]. Since the tier of a given component isn't available in the spreadsheets I find that tier by looking at the lowest tier recipe that the given component appears in. Eg. tier 3 components only appear in tier 3 recipes while tier 1 components can appear in any tier of recipe.

-refining bonus: https://goblinworks.com/forum/topic/67/?page=3
-zipping macro (to keep my stuff private)
-% of max dmg on convert stats tab
-Kyrana off by 1 hour (should be 2 hours). Check Vio?
-automatic update of trained feats/needed achievements windows?
-chance of being interrupted based on cast time, enemy cast time, interrupt chance

set utility dropdown (default=all to 6, but training tab can pass)
move matching from wiki to gear tab? gear on wiki tab?
net effect power for utilities based on armor matching
need utility->gear search

mouseovers like from calendar for everything eventually to explain it all?

-threat scaling to advanced tab
-Stephen updated weapon -> type matches (see posts)
-encumbrance (need equations)
-correct the calc for non-zero duration of secondary effects? should take into account likelihoods? or odds*non-zero=avg?

Longer:
=======
-drop-down menu on cc duration and have message window showing chances/durations for given rounds (taking into account recovery) with options at top (#stacks/round, etc.)
****bug: multiple ors in opportunist!

1) ****green damage
2) need 6 examples
3) ****add effect power/protection for convert stats dots
4) import attack/expendable to convert stats. -how to pass from wiki/training to rotation/convert? v67?
5) dots in average damage on convert stats. (put above recovery. should already have gridding correct for this). dots to be converted is extra dot
6) one dot profile to under the other distributions
****) Decius request

1) improve cost minimization algorithm: implemented, but commented out due to recursion depth issues
2) add expendables and offhand weapons to rotation tab
3) unknown keyword scaling -> skills (loop over profession_list). option to show on armor matches
4) pass trained armor feats to crafting tab as well. needs to access keyword matching!
5) when lose threat if not indefinite

-optionmenus for default crit resistance, common r, common b on convert tab (maybe containing a string with Tier/KW)
-encumbrance from blog:https://goblinworks.com/blog/some-good-reason-for-your-little-black-backpack/
-scrolling doesnt work on more than 1 window
-extra for specific attack types (eg. enchanter), extra dmg on crit (eg. evoker), etc.
-more debug mode printouts when not finding something reading in!!
-recipe lookup like rotation tabs choosing to save a lot of space
-remove attack lookup on wiki tab, except utilities
-cc tab?
-anywhere appropriate for base crit resistance?
-deal with protection domain via max(naked,effects)?
-with scaling of scrolling on advanced tab (changes a global variable defined in message_window)
-Account for relevant resistance in secondary effect duration? can't remember if just dots or not
-roles for trained feats. via linked_feat and in some cases harder (eg. expendables-> implement->role)
-add fighter features to base damage in weapon->attack searches. PARTIALLY DONE
-facility imports?
-refining tab (move all refining stuff off crafting tab to there). what known refining recipe is a given raw best used in, taking into account random improvements
-read in 'if target has' to see how dps changes. then make dps lists with all effects active. listed in keyword match searches with 2 extra columns.
-travel tab: based on encumbrance, two different price lists, and item weights, best load to carry and profit per time
-get small amount added to average bonus based on skill. what is the scaling??
-reinstall modules script in case goes wrong
-need way to update price files as players level up
-Request: Merge training plans. Option 1: both from scratch, so need to eliminate commonalities somehow. Option 2: plan 2 on top of plan 1. Need to check for race every time.
-somehow keep track of learned recipes: import input list. add to it, undo last. save. find missing based on professions.
-effect class to be used by rotation
-rotation just N passes of MC, plot: total dmg, stamina, cc effects
-crafting algorithms: for refining need component information ("Counts as").  
-random improvements for refining.
-finish linked feats. bonuses, points
-for rotations can safely use trained feats; Train All as default?, or only restrict when importing training
-make hp conversion consistent with others
-hard-code a list of effects in the combat guide and put on rotation tab
***dots monte carlo (a-d, rec, n_attacks*n_stacks)
-a-d to matches, penetrating, precise
-worthwhile expendables (better than attacks) by max damage or stamina efficiency
-wiki and searches each in own file, change attack input to customize individual levels
-for loop searches, do without calling create message window, just need to use the column_names/entries;merge_csv as prototype of an option to run over all cases on that matching tab
-role logic
-more towards rotations (interpretting effects)
-towards mockdoll (ability to select from trained) (how to deal with non-stacking? need to know channels)
-counter rotations on rotation tab: stunning, exhausting etc.

UPCOMING FEATURES:
==================
*threat calculator (goes with rotations)
*training message windows to display all feat info (shift down).
*dots conversion (recovery dependent, enemy hp dependent due to dot scaling)
*backwards stat conversion as a doublecheck?
*hex counting on travel tab
*sprinting on travel tab (dev input/empirical)
*penetrating conversion
*Request: Distribution of damage after N hits (grab from gridiron).
*Change defaults in reputation tab to reflect the new reputation scaling (needs dev input).

MEDIUM TERM FEATURES:
=====================
*achievements in wiki sorted by type (with 'misc' for specific ones?). is in game.
*easier to search wiki (more like full spreadsheets and sorting buttons)
*loot table info on loot tab (needs dev input)
*other encumbrance. needs dev info.
*mock paperdoll popup window called on training tab (pass trained). need to inherit from weapon_reader and armor_reader. select from trained feats (needs to parse passives files in more detail)
*convert rotation code to tkinter. have cookie cutter enemies and ability to edit them. have exhaustion also for anti drain builds.
*add equipment to wiki tab (when dev info available) and search both ways
*want to maximize wins/cost = sum_n w^n = 1/(1-w). compare 1/(c-cw) < 1/(c'-c'w')=1/(c'-c'(1+z)w)=1/(c'-c'w-c'wz') where w'=(1+z)w
=> c'(1-w')<c(1-w)=c'l'<cl, so if average loss is less.
*modified compare_stats.py
*Simple stealth calculator. Would be nice to include sample pics of distances to let users gauge distance.

LONGER TERM FEATURES:
=====================
*formation combat calculator
*faction/alignment calculator (put on reputation tab)
*SAD calculator
*market calculator (trading). soonish?
*crafting tab (features as yet undetermined). random improvements, queues.
*settlement DI tab (features as yet undermined). WTB Tork.
*player input to log info on NPC stats
*Mac and Linux versions
*Self updating?

FEATURE REQUEST LIST:
=====================
*Fastest way to train a given skill to a given level. Note: would love to have this, but is non-trivial!

BEHIND THE SCENES (SHORT TERM):
===============================
*compileall to distribute compiled code as protection. disable older links when confirmed working for users. http://effbot.org/zone/python-compile.htm. compiling may allow more modules that users don't have to install. http://www.expandrive.com/packing-it-all-in-distributing-python-with-an-app
*role logic (to deal with the eventual 'OR' logic for roles) (logic handler, parser, main window?, xp calc to deal with ors. assume all same or average?)
*map and check if all imports are needed

BEHING THE SCENES (LONG TERM):
==============================
*logging: https://docs.python.org/3/howto/logging.html when distributing as app.
*make increases and score prereqs like feat/achievement prerequisites (more generalized)
*code cleanup: classes for most tabs (possible exception of training due to various imports) and lambda functions for redundant commands. message window 2->1 classes. 

PRIVATE FEATURES:
=================
*input via try statements, code to be in a separate folder
*win chance calculator (needs redoing due to 0.063 change) 
*NightSight. Loop over attacks and expendables to find known damage factors and only run over those