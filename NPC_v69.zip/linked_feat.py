from feat_reader import feat_list
from attack_reader import attack_list
from expendable_reader import expendable_list
from passive_reader import passive_list

unlinked_feats = []
linked_feats = []

class Linked_Feat:
	def __init__(self, feat):
		self.name = feat.name
		self.type = feat.feat_type
		self.feat = feat
		self.wiki = None
	def link_wiki(self, wiki_feat):
		self.wiki = wiki_feat
	def printout(self):
		if(self.wiki==None):
			self.feat.printout()
			return
		self.feat.printout(False) #doesn't include shift down, so that needs to be done first
		if self.type in ['Armor', 'Defensive', 'Feature', 'Reactive', 'Skills']:
			new_column_names, new_column_entries, new_widths = ['Effects', 'Keywords'], [], []
			for level in range(len(self.wiki.effects)):
				new_column_entries.append([self.wiki.effects[level], self.wiki.keywords[level]])
			new_widths = [ max([len(x)+5 for x in self.wiki.effects]), max([len(x)+5 for x in self.wiki.keywords]) ]
			self.feat.mw.add_to_columns(new_column_names,new_column_entries,new_widths)
		if self.type in ['Attacks', 'Cantrips', 'Orisons', 'Utility']:
			new_column_names, new_column_entries, new_widths = ['Keywords'], [], []
			for level in range(len(self.wiki.keywords)):
				new_column_entries.append([', '.join(self.wiki.keywords[:level+1])])
			new_widths = [ len(', '.join(self.wiki.keywords[:level+1]))-10 ]
			self.feat.mw.add_to_columns(new_column_names,new_column_entries,new_widths)
		self.feat.new_window()
		return

def Find_Linked_Feat(string):
	for lfeat in linked_feats:
		if(lfeat.name==string):
			return lfeat
	return None

def find_list(feat_type):
	if(feat_type in ['Armor', 'Defensive', 'Feature', 'Reactive', 'Skills']):
		return passive_list
	if(feat_type in ['Attacks', 'Cantrips', 'Orisons', 'Utility']):
		return attack_list
	if(feat_type in ['Expendables']):
		return expendable_list

for feat in feat_list:
	l = Linked_Feat(feat)
	linked_feats.append(l)
	if(feat.feat_type in ['Bonuses', 'Points', 'Proficiencies']):
		continue
	for wiki in find_list(feat.feat_type):
		if(feat.name==wiki.name):
			l.link_wiki(wiki)
			break
	if(l.wiki==None):
		unlinked_feats.append(l)

#loop over feat_list and use Find_Attack etc to try linking if not None.
#have specific classes inheriting from linked feat? or create 3 similar ones?
