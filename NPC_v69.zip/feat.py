from message_window import Make_Message_Window

class Feat:
	def __init__(self,feat_type,name,xp_scaling,min_score,min_score_type,increase,increase_type,prerequisites,achievements,roles): 
		self.ab_short_names = ['Str','Dex','Con','Int','Wis','Per']
		self.feat_type = feat_type
		self.name = name
		self.xp_scaling = xp_scaling #array
		self.min_score = min_score #array
		self.min_score_type = min_score_type #eventually want to generalize like prerequisites in case of different minimums and OR options
		self.min_score_type_names = [ self.ab_short_names[i] for i in self.min_score_type ]
		self.increase = increase #array
		self.increase_type = increase_type
		self.increase_type_names = [ self.ab_short_names[i] for i in self.increase_type ]
		self.prerequisites = prerequisites #array with each entry being a list for that level; that list: (feat name, feat level), needs OR options
		self.achievements = achievements #same format
		self.roles = roles #same format
		self.current_level = 0
		self.set_next_xp()
		self.set_hourly_xp(100) #default
	def set_next_xp(self):
		try:
			self.next_xp = self.xp_scaling[self.current_level+1]
		except:
			self.next_xp = 0
	def set_hourly_xp(self,rate): #NEEDS TO BE CALLED IN XP/ADVANCED TABS
		self.hourly_xp = rate
	def levelup(self):
		self.current_level += 1
		self.set_next_xp()
	def reset(self):
		self.current_level = 0
		self.set_next_xp()
	def shorten(self,scores):
		score_names = ''
		for score in scores:
			score_names += '/%s' %score
		return score_names[1:]
	def sep(self,a,b):
		if(a>0 and b>0):
			return ' or'
		else:
			return ','
	def separator(self,reqlist,i):
		if(len(reqlist)==0):
			return ''
		try:
			return self.sep(reqlist[i][2],reqlist[i+1][2])
		except:
			return ','
	def xp_to_time(self,xp):
		days = int(xp/(24*self.hourly_xp)) #full days
		hours = int((xp/self.hourly_xp)%24) #full hours mod 24
		minutes = int((60*xp/self.hourly_xp)%60)
		seconds = int((3600*xp/self.hourly_xp)%60)
		return '%s d/%s h/%s m/%s s' %(days, hours, minutes, seconds) 
	def new_window(self):
		self.mw.new_window()
	def printout(self, nw=True):
		self.mw = Make_Message_Window()
		title = '%s: %s' %(self.feat_type, self.name)
		column_names = [ 'Level', 'XP cost', 'Cumulative Cost', 'Minimum %s' %self.shorten(self.min_score_type_names), 'Increase to %s' %self.shorten(self.increase_type_names), 'Cumulative Increase', 'Prerequisites', 'Time to Train', 'Cumulative Time']
		column_entries = [ ]
		width = 10
		increase = 0
		cum_xp = 0
		for level in range(len(self.xp_scaling)):
			printout_string = ''
			for i, x in enumerate(self.achievements[level]):
				s = self.separator(self.achievements[level],i)
				printout_string += '%s=%s%s ' %(x[0],x[1],s)
			for i, y in enumerate(self.prerequisites[level]):
				s = self.separator(self.prerequisites[level],i)
				printout_string += '%s=%s%s ' %(y[0],y[1],s) 
			for i, z in enumerate(self.roles[level]):
				s = self.separator(self.roles[level],i)
				printout_string += '%s=%s%s ' %(z[0],z[1],s)
			printout_string = printout_string[:-2] #cut off last comma and space
			t1 = self.xp_to_time(self.xp_scaling[level])
			t2 = self.xp_to_time(sum(self.xp_scaling[:(level+1)]))
			increase += self.increase[level]
			increase = round(10000*increase)/10000 
			cum_xp += self.xp_scaling[level]
			column_entries.append([level+1,self.xp_scaling[level],cum_xp,self.min_score[level],self.increase[level],increase,printout_string,t1,t2])
			width = max(width,len(printout_string)+5)
		widths = [7,10,10,10,10,10,width,16,16]
		self.mw.update_columns(title, column_names, column_entries, widths)
		if(nw):
			self.new_window()
