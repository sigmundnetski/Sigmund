import tkinter as tk
from math import sqrt
from os import path, getcwd, listdir

penalty_base = [ sqrt(-rb)*0.063 for rb in range(-250,0) ]
likelihood = [ [] for i in range(3) ]
likelihood[0] = [ ((201-R)**3-(200-R)**3)/8000000 for R in range(1,201) ]
likelihood[1] = [ (6*(R-1)*(200-R)+598)/8000000 for R in range(1,201) ]
likelihood[2] = [ (R**3-(R-1)**3)/8000000 for R in range(1,201) ]

def onemp(amd,cramcre=0): #place these in message_window and inherit them?
	if(amd>0 or amd==0):
		if(amd+cramcre>0):
			return 1.0, 1.0, sqrt(amd+cramcre) # [ 1-p, is full hit?, sqrt margin of success ]
		else:
			return 1.0, 1.0, -1
	if(amd<-250):
		return 0.0, 0.0, -1
	else:
		return 1.0-penalty_base[250+amd], 0.0, -1

def damage(atier, f, bmr, amd, dtier):
	result = 0.0
	if(bmr<0):
		return result
	for roll in range(1,201):
		result += likelihood[atier-1][roll-1]*f*bmr*onemp(amd+roll-50*dtier)[0]
	return result

class Message_Window(tk.Frame): 
	def __init__(self,root,column_names,column_entries,widths,title,special='None'):
		self.library = None
		tk.Frame.__init__(self,root)
		self.column_names = [ name for name in column_names ]
		self.column_entries = [[entry for entry in column] for column in column_entries]
		self.widths = [ w for w in widths ]
		self.title = title
		self.canvas = tk.Canvas(root, borderwidth=0)
		self.frame = tk.Frame(self.canvas)
		self.vscrollbar = tk.Scrollbar(root, orient='vertical', command=self.canvas.yview)
		self.hscrollbar = tk.Scrollbar(root, orient='horizontal', command=self.canvas.xview)
		self.canvas.configure(yscrollcommand=self.vscrollbar.set)
		self.canvas.configure(xscrollcommand=self.hscrollbar.set)
		self.vscrollbar.pack(side='right', fill='y')
		self.hscrollbar.pack(side='bottom', fill='y')
		self.canvas.pack(side='left', fill='both', expand=True)
		self.canvas.create_window((4,4), window=self.frame, anchor="nw")
		self.frame.bind('<Configure>', self.OnFrameConfigure)
		self.canvas.bind_all('<MouseWheel>', self.mousewheel)
		self.canvas.bind_all('<Right>',self.right)
		self.canvas.bind_all('<Left>',self.left)
		self.canvas.bind_all('<Up>',self.up)
		self.canvas.bind_all('<Down>',self.down)
		self.shift = 0
		self.add_special(special)
		self.make_lookup()
		self.make_save_buttons()
		self.make_sorting_buttons()
		self.fill()
		self.n_pops = 0
	def add_library(self, library):
		self.library = library
	def search_library(self, string):
		if(self.library==None):
			return None
		for item in self.library:
			if(string==item.name):
				return item
		return None
	def button_scroll(self,axis,direction):
		if(axis=='x'):
			try:
				self.canvas.xview_scroll(direction, 'units')
			except:
				pass
		elif(axis=='y'):
			try:
				self.canvas.yview_scroll(direction, 'units')
			except:
				pass
	def down(self,event):
		self.button_scroll('y',1)
	def up(self,event):
		self.button_scroll('y',-1)
	def right(self,event):
		self.button_scroll('x',1)
	def left(self,event):
		self.button_scroll('x',-1)
	def mousewheel(self, event):
		try:
			self.canvas.yview_scroll(round(-1*(event.delta/120)), 'units')
		except:
			pass
	def strip_for_saving(self):
		for column in range(len(self.column_names)):
			if(self.checks[column].get()==0):
				self.column_names.pop(column-self.n_pops)
				self.widths.pop(column-self.n_pops)
				for row in range(len(self.column_entries)):
					self.column_entries[row].pop(column-self.n_pops) #messed up with shifts?
				self.n_pops += 1
			self.name_labels[column].destroy()
			self.check_buttons[column].destroy()
			self.true_sorting_buttons[column].destroy()
			self.false_sorting_buttons[column].destroy()
			for row in range(len(self.column_entries)):
				self.entry_labels[row][column].destroy()
		for button in self.save_buttons:
			button.destroy()
		self.n_pops = 0 #in case of multiple sets of deletes
		self.make_save_buttons()
		self.make_sorting_buttons()
		self.fill()
	def make_save_buttons(self):
		self.save_buttons = []
		self.save_buttons.append(tk.Button(self.frame, text='Save as text file', command=self.save_as_text))
		self.save_buttons[0].grid(row=len(self.column_entries)+4+self.shift,column=0,sticky="NEWS")
		self.save_buttons.append(tk.Button(self.frame, text='Save as csv file', command=self.save_as_csv))
		self.save_buttons[1].grid(row=len(self.column_entries)+5+self.shift,column=0,sticky="NEWS")
		self.save_buttons.append(tk.Button(self.frame, text='Remove unwanted columns', command=self.pare_down))
		self.save_buttons[2].grid(row=len(self.column_entries)+6+self.shift,column=0,sticky="NEWS")
		self.save_buttons.append(tk.Button(self.frame, text='Restore all', command=self.restore))
		self.save_buttons[3].grid(row=len(self.column_entries)+7+self.shift,column=0,sticky="NEWS")
	def make_sorting_buttons(self):
		self.true_sorting_buttons = []
		self.false_sorting_buttons = []
		for i in range(len(self.column_names)):
			self.true_sorting_buttons.append(self.Create_Resorting_Button(i,True))
			self.true_sorting_buttons[i].grid(row=self.shift,column=i,sticky="NEWS")
			self.false_sorting_buttons.append(self.Create_Resorting_Button(i,False))
			self.false_sorting_buttons[i].grid(row=1+self.shift,column=i,sticky="NEWS")
	def get_filename(self,title,extension):
		filename = '%s.%s' %(title,extension)
		saved = path.join(getcwd(), path.join('saved_files'))
		n = 0
		while(filename in listdir(saved)):
			filename = '%s-%s.%s' %(title,n,extension)
			n += 1
		return filename
	def save(self, joiner, extension):
		self.strip_for_saving()
		filename = self.get_filename(self.title.replace(': ','-').replace(' ', '_'),extension)
		fout = open(path.join(getcwd(), path.join( 'saved_files', '%s' %filename )),'w')
		fout.write(joiner.join(self.column_names))
		fout.write('\n')
		fout.write('\n'.join([joiner.join([str(entry) for entry in column_entry]) for column_entry in self.column_entries])) 
	def save_as_text(self):
		self.save(' || ', 'txt')
	def save_as_csv(self):
		self.save(';', 'csv')
	def pare_down(self):
		self.strip_for_saving()
	def fill(self):
		self.name_labels = [tk.Label(self.frame,text=self.column_names[i],font=('Helvetica',10)) for i in range(len(self.column_names))]
		for i in range(len(self.column_names)):
			self.name_labels[i].grid(row=self.shift+2,column=i,sticky="NEWS")
		self.entry_labels = []
		for i in range(len(self.column_entries)):
			self.entry_labels.append([])
			for j in range(len(self.column_entries[i])): 
				self.entry_labels[i].append(tk.Label(self.frame,text=self.column_entries[i][j],relief='sunken',width=self.widths[j]))
				self.entry_labels[i][j].grid(row=i+3+self.shift,column=j,sticky="NEWS")
		self.checks = [ tk.IntVar() for i in range(len(self.column_names)) ]
		self.check_buttons = [tk.Checkbutton(self.frame, text='keep', variable=self.checks[i]) for i in range(len(self.column_names))]
		for i in range(len(self.column_names)):
			self.checks[i].set(1)
			self.check_buttons[i].grid(row=len(self.column_entries)+3+self.shift,column=i,sticky="NEWS")
	def OnFrameConfigure(self, event):
		self.canvas.configure(scrollregion=self.canvas.bbox("all"))
	def resort(self,column,reverse=True):
		self.column_entries = sorted(self.column_entries, key=lambda entry: entry[column], reverse=reverse)
		new_column = self.Lookup.index(self.column_names[column])
		self.lookup = sorted(self.lookup, key=lambda entry: entry[new_column], reverse=reverse)#NOT SAME COLUMN WHEN PARED DOWN!
		self.fill()
	def Create_Resorting_Button(self,column,reverse):
		cmd = lambda c=column, r=reverse: self.resort(c,r)
		text = 'Sort'
		if(reverse):
			text += ' (Reverse)'
		but = tk.Button(self.frame, text=text, command=cmd)
		return but
	def add_special(self,special):
		if(special=='None'):
			return
		self.defenses = ['Fortitude','Reflex','Will']
		self.dot_types = ['Afflicted','Bleeding','Burning']
		if('Armor' in special):
			self.naked_resistances = [ tk.IntVar() for i in range(2) ] #can only specify energy/physical
			for i in range(2):
				self.naked_resistances[i].set(0)
			self.naked_defenses = [ tk.IntVar() for i in range(3) ]
			for i in range(3):
				self.naked_defenses[i].set(0)
			self.naked_hp = tk.IntVar()
			self.naked_hp.set(400)
			self.naked_recovery = tk.IntVar() #should all be the same
			self.naked_recovery.set(10)
			self.attack_bonus = tk.IntVar()
			self.attack_bonus.set(0)
			self.base_damage = tk.IntVar()
			self.base_damage.set(45)
			tk.Label(self.frame,text='Naked Resistances',relief='sunken').grid(row=0,column=0,columnspan=2,sticky="NEWS")
			tk.Label(self.frame,text='Physical',relief='sunken').grid(row=1,column=0,sticky="NEWS")
			tk.Entry(self.frame,textvariable=self.naked_resistances[0]).grid(row=1,column=1,sticky="NEWS")
			tk.Label(self.frame,text='Energy',relief='sunken').grid(row=2,column=0,sticky="NEWS")
			tk.Entry(self.frame,textvariable=self.naked_resistances[1]).grid(row=2,column=1,sticky="NEWS")
			tk.Label(self.frame,text='Naked Defenses',relief='sunken').grid(row=3,column=0,columnspan=2,sticky="NEWS")
			tk.Label(self.frame,text=self.defenses[0],relief='sunken').grid(row=4,column=0,sticky="NEWS")
			tk.Entry(self.frame,textvariable=self.naked_defenses[0]).grid(row=4,column=1,sticky="NEWS")
			tk.Label(self.frame,text=self.defenses[1],relief='sunken').grid(row=5,column=0,sticky="NEWS")
			tk.Entry(self.frame,textvariable=self.naked_defenses[1]).grid(row=5,column=1,sticky="NEWS")
			tk.Label(self.frame,text=self.defenses[2],relief='sunken').grid(row=6,column=0,sticky="NEWS")
			tk.Entry(self.frame,textvariable=self.naked_defenses[2]).grid(row=6,column=1,sticky="NEWS")
			tk.Label(self.frame,text='Other',relief='sunken').grid(row=0,column=2,columnspan=2,sticky="NEWS")
			tk.Label(self.frame,text='Naked HP',relief='sunken').grid(row=1,column=2,sticky="NEWS")
			tk.Entry(self.frame,textvariable=self.naked_hp).grid(row=1,column=3,sticky="NEWS")
			tk.Label(self.frame,text='Naked Recovery',relief='sunken').grid(row=2,column=2,sticky="NEWS")
			self.recovery = tk.IntVar()
			self.recovery.set(10)
			tk.Entry(self.frame,textvariable=self.recovery).grid(row=2,column=3,sticky="NEWS")
			tk.Label(self.frame,text='Attacker Stats',relief='sunken').grid(row=3,column=2,columnspan=2,sticky="NEWS")
			tk.Label(self.frame,text='Attack Bonus',relief='sunken').grid(row=4,column=2,sticky="NEWS")
			tk.Entry(self.frame,textvariable=self.attack_bonus).grid(row=4,column=3,sticky="NEWS")
			tk.Label(self.frame,text='Base Damage',relief='sunken').grid(row=5,column=2,sticky="NEWS")
			tk.Entry(self.frame,textvariable=self.base_damage).grid(row=5,column=3,sticky="NEWS")
			tk.Label(self.frame,text='Dot stack',relief='sunken').grid(row=6,column=2,sticky="NEWS")
			self.stack = tk.IntVar()
			self.stack.set(0)
			tk.Entry(self.frame,textvariable=self.stack).grid(row=6,column=3,sticky="NEWS")
			self.shift = 7
			self.column_names += ['Physical Hits to Kill', 'Energy Hits to Kill']
			self.widths += [10,10]
			for column in range(len(self.column_entries)):
				self.column_entries[column] += [0,0]
			tk.Button(self.frame,text='Calculate',command=self.factor_points,fg='blue').grid(row=0,column=7,rowspan=7,sticky="NEWS")
			tk.Label(self.frame, text='Attack Tier',relief='sunken').grid(row=1,column=4,sticky="NEWS")
			self.attack_tier = tk.IntVar()
			self.attack_tier.set(1)
			tk.OptionMenu(self.frame, self.attack_tier, *[1,2,3]).grid(row=2,column=4,sticky="NEWS")
			attack_types = ['Attacks Fortitude','Attacks Reflex','Attacks Will']
			self.attack_type = tk.IntVar()
			self.attack_type.set(1)
			for i in range(len(attack_types)):
				tk.Radiobutton(self.frame, text=attack_types[i], variable=self.attack_type, value=i).grid(row=3+i,column=4,sticky="NEWS")
			self.penetrating = tk.IntVar()
			self.penetrating.set(0)
			tk.Checkbutton(self.frame, text='Penetrating (physical only)', variable=self.penetrating).grid(row=6,column=4,sticky="NEWS")
			tk.Label(self.frame,text='Attacker Matched Keywords', relief='sunken').grid(row=0,column=4,sticky="NEWS")
			self.effect_power = tk.IntVar()
			self.effect_power.set(1)
			tk.Entry(self.frame,textvariable=self.effect_power).grid(row=0,column=5,sticky="NEWS")
			tk.Label(self.frame,text='Damage Factor',relief='sunken').grid(row=1,column=5,sticky="NEWS")
			self.damage_factor = tk.DoubleVar()
			self.damage_factor.set(1.4)
			tk.Entry(self.frame,textvariable=self.damage_factor).grid(row=2,column=5,sticky="NEWS")
			self.chosen_dot = tk.IntVar()
			self.chosen_dot.set(-1)
			if('Rec' in special):
				tk.Label(self.frame,text='Dot type',relief='sunken').grid(row=3,column=5,sticky="NEWS")
				self.chosen_dot.set(0)
				for i in range(len(self.dot_types)):
					tk.Radiobutton(self.frame, text=self.dot_types[i], variable=self.chosen_dot, value=i).grid(row=4+i,column=5,sticky="NEWS")
			tk.Button(self.frame, text='Select Example', command=self.select_example_attacker,fg='blue').grid(row=6,column=6,sticky="NEWS")
			self.examples = [['Low T1',0,45,1,1], ['High T1',20,55,1,3], ['Low T2',25,65,2,5], ['High T2',45,80,2,8], ['Low T3',55,85,3,9], ['High T3',70,100,3,12]]
			self.example_attacker = tk.IntVar()
			self.example_attacker.set(0)
			for i in range(len(self.examples)):
				tk.Radiobutton(self.frame, text=self.examples[i][0], variable=self.example_attacker, value=i).grid(row=i,column=6,sticky="NEWS")
		if('Attack' in special or 'Expendable' in special):
			tk.Label(self.frame, text='Target Resistances', relief='sunken').grid(row=0,column=0,columnspan=4,sticky="NEWS")
			self.resistance_types = ['Physical','Fire','Acid','Sonic','Holy','Psychic','Cold','Electric','Force','Negative']
			self.resistances = [ tk.IntVar() for x in self.resistance_types ]
			for i, x in enumerate(self.resistances):
				x.set(0)
				tk.Label(self.frame, text=self.resistance_types[i],relief='sunken').grid(row=(i%5)+1,column=2*int(i/5),sticky="NEWS")
				tk.Entry(self.frame, textvariable=self.resistances[i]).grid(row=(i%5)+1,column=2*int(i/5)+1,sticky="NEWS")
			self.my_defenses = [ tk.IntVar() for x in self.defenses ]
			for i, x in enumerate(self.my_defenses):
				x.set(50)
				tk.Label(self.frame, text='Target %s' %self.defenses[i], relief='sunken').grid(row=i,column=4,sticky="NEWS")
				tk.Entry(self.frame, textvariable=self.my_defenses[i]).grid(row=i,column=5,sticky="NEWS")
			self.my_recoveries = [ tk.IntVar() for x in self.dot_types ]
			for i, x in enumerate(self.my_recoveries):
				x.set(10)
				tk.Label(self.frame, text='Target %s Recovery' %self.dot_types[i], relief='sunken').grid(row=i+3,column=4,sticky="NEWS")	
				tk.Entry(self.frame, textvariable=self.my_recoveries[i]).grid(row=i+3,column=5,sticky="NEWS")
			self.effect_protection = tk.IntVar()
			self.effect_protection.set(1)
			tk.Label(self.frame, text='Target matched armor keywords', relief='sunken').grid(row=0,column=6,sticky="NEWS")
			tk.Entry(self.frame, textvariable=self.effect_protection).grid(row=0,column=7,sticky="NEWS")
			tk.Label(self.frame, text='Target hp', relief='sunken').grid(row=1,column=6,sticky="NEWS")
			self.my_hp = tk.IntVar()
			self.my_hp.set(400)
			tk.Entry(self.frame, textvariable=self.my_hp).grid(row=1,column=7,sticky="NEWS")
			self.extra_base = tk.IntVar()
			self.extra_base.set(0)
			tk.Label(self.frame, text='Extra Base Damage', relief='sunken').grid(row=2,column=6,sticky="NEWS")
			tk.Entry(self.frame, textvariable=self.extra_base).grid(row=2,column=7,sticky="NEWS")
			self.my_attack_bonus = tk.IntVar()
			self.my_attack_bonus.set(0)
			tk.Label(self.frame, text='Attack Bonus', relief='sunken').grid(row=3,column=6,sticky="NEWS")
			tk.Entry(self.frame, textvariable=self.my_attack_bonus).grid(row=3,column=7,sticky="NEWS")
			self.column_names += ['Average Damage', 'Max Damage', 'Stamina Efficiency']
			self.widths += [10,10,10]
			for column in range(len(self.column_entries)):
				self.column_entries[column] += [0,0,0]
			if(special=='Expendable'):
				self.column_names += ['Power Efficiency']
				self.widths += [10]
				for column in range(len(self.column_entries)):
					self.column_entries[column] += [0]
				self.my_tier = tk.IntVar()
				self.my_tier.set(1)
				tk.Label(self.frame, text='Implement Tier', relief='sunken').grid(row=4,column=6,sticky="NEWS")
				tk.OptionMenu(self.frame, self.my_tier, *[1,2,3]).grid(row=4,column=7,sticky="NEWS")
			self.green = tk.IntVar()
			self.green.set(0)
			tk.Checkbutton(self.frame, text='Green Damage', variable=self.green).grid(row=5,column=6,columnspan=2,sticky="NEWS")
			self.shift = 7
			tk.Button(self.frame, text='Calculate', command=self.dps, fg='blue').grid(row=0,column=8,rowspan=7,sticky="NEWS")
	def dps(self): #also do for green damage
		hp = self.my_hp.get()
		try:
			avg_index = self.column_names.index('Average Damage')
		except:
			avg_index = -1
		try:
			max_index = self.column_names.index('Max Damage')
		except:
			max_index = -1
		try:
			staeff_index = self.column_names.index('Stamina Efficiency')
		except:
			staeff_index = -1
		try:
			poweff_index = self.column_names.index('Power Efficiency')
		except:
			poweff_index = -1
		avg_lookup = self.Lookup.index('Average Damage')
		max_lookup = self.Lookup.index('Max Damage')
		staeff_lookup = self.Lookup.index('Stamina Efficiency')
		try:
			poweff_lookup = self.Lookup.index('Power Efficiency')
		except:
			poweff_lookup = -1
		for i in range(len(self.column_entries)):
			tgt_def = self.lookup_entry(i, 'Target Defense')
			tgt_res = self.lookup_entry(i, 'Relevant Resistance')
			if(tgt_res=='Not Found' or tgt_res=='None (Beneficial)'):
				tgt_res = 'Physical'
			res = self.resistances[self.resistance_types.index(tgt_res)].get()
			amd = self.my_attack_bonus.get()-self.my_defenses[self.defenses.index(tgt_def)].get()
			try:
				libitem = self.search_library(self.lookup_entry(i, 'Attack'))
				matches = self.lookup_entry(i,'Number of Matched Keywords (major x4)')
				base = 40+5*matches
				tier = self.lookup_entry(i, 'Roll Tier')
			except:
				libitem = self.search_library(self.lookup_entry(i, 'Expendable'))
				matches = self.lookup_entry(i,'Number of Matched Keywords')
				base = 40+7*matches
				tier = self.my_tier.get()
			amd += libitem.precise #precise
			factor = self.lookup_entry(i, 'Damage Factor')
			bmr = max(0, libitem.extra_base+self.extra_base.get()+base-res) #extra base
			if(libitem.penetrating): #penetrating, Searing Armor is non-physical penetrating
				bmr += 0.1*res
			avg_dmg = damage(tier, factor, bmr, amd, 0) 
			max_dmg = round(factor*bmr)
			for j, dot in enumerate([libitem.afflicted, libitem.bleeding, libitem.burning]): #dots
				if(dot<=0 or hp<=0):
					continue
				rec = self.my_recoveries[j].get()
				if(rec<=0):
					continue
				pmp = max(1.0+0.1*(matches-self.effect_protection.get()),0.0) #effect power minus effect protection
				avg_dmg += self.do_dotting( round(dot*pmp*damage(tier, 1.0, 1, amd-res, 0)) , rec, hp)
				max_dmg += self.do_dotting(round(dot*pmp), rec, hp)
			if(avg_index>=0):
				self.column_entries[i][avg_index] = round(100*avg_dmg)/100
				self.lookup[i][avg_lookup] = round(100*avg_dmg)/100
			if(max_index>=0):
				self.column_entries[i][max_index] = max_dmg
				self.lookup[i][max_lookup] = max_dmg
			stamina = self.lookup_entry(i, 'Stamina Cost')
			if(staeff_index>=0 and stamina>0):
				self.column_entries[i][staeff_index] = round(1000*avg_dmg/stamina)/1000
				self.lookup[i][staeff_lookup] = round(1000*avg_dmg/stamina)/1000
			try:
				power = self.lookup_entry(i, 'Power Cost')
			except:
				power = 0
			if(poweff_index>=0 and power>0):
				self.column_entries[i][poweff_index] = round(1000*avg_dmg/power)/1000
				self.lookup[i][poweff_lookup] = round(1000*avg_dmg/power)/1000
		self.make_save_buttons()
		self.make_sorting_buttons()
		self.fill()
	def do_dotting(self, avg_dot, rec, hp):
		max_rounds = int(avg_dot/rec)+2
		x = round(avg_dot*0.001*hp)
		if(x<=0):
			return 0.0
		for rd in range(max_rounds):
			avg_dot -= rec
			if(avg_dot>0):
				x += round(avg_dot*0.001*hp)
			else:
				break
		return x
	def select_example_attacker(self):
		x = self.example_attacker.get()
		self.attack_bonus.set(self.examples[x][1])
		self.base_damage.set(self.examples[x][2])
		self.attack_tier.set(self.examples[x][3])
		self.effect_power.set(self.examples[x][4])
	def factor_points(self):
		index_to_fill = -1
		defense_columns = ['Extra Fort', 'Extra Ref', 'Extra Will']
		def_index = self.attack_type.get()
		base_def = self.naked_defenses[def_index].get()
		length = len(self.column_entries)
		try: #feat->gear
			if(def_index!=1):#not reflex
				defenses = [50*self.lookup_entry(row,'Tier')+base_def+self.lookup_entry(row,defense_columns[def_index]) for row in range(length)]
			else:
				defenses = [self.armor_penalty(row)+50*self.lookup_entry(row,'Tier')+base_def+self.lookup_entry(row,defense_columns[def_index]) for row in range(length)]
		except: #gear->feat
			tier = self.title.count('major')+1
			if(def_index!=1):
				defenses = [50*tier+base_def+self.lookup_entry(row,defense_columns[def_index]) for row in range(length)]
			else:
				tp = self.title_penalty()
				defenses = [tp+50*tier+base_def+self.lookup_entry(row,defense_columns[def_index]) for row in range(length)]
		hp = [self.lookup_entry(row,'Extra hp')+self.naked_hp.get() for row in range(len(self.column_entries))]
		if('Physical Hits to Kill' in self.column_names): #in case deleted those columns, in which case no point
			index_to_fill = self.column_names.index('Physical Hits to Kill')
			lookup_index = self.Lookup.index('Physical Hits to Kill')
			resistances = [self.lookup_entry(row,'Physical Resistance')+self.naked_resistances[0].get() for row in range(length)]
			if(self.penetrating.get()==1):
				self.calculate_fp(index_to_fill,resistances,defenses,hp,lookup_index,True)
			else:
				self.calculate_fp(index_to_fill,resistances,defenses,hp,lookup_index)
		if('Energy Hits to Kill' in self.column_names):
			index_to_fill = self.column_names.index('Energy Hits to Kill')
			lookup_index = self.Lookup.index('Energy Hits to Kill')
			resistances = [self.lookup_entry(row,'Energy Resistance')+self.naked_resistances[1].get() for row in range(length)]
			self.calculate_fp(index_to_fill,resistances,defenses,hp,lookup_index)
		if(index_to_fill!=-1):
			self.make_save_buttons()
			self.make_sorting_buttons()
			self.fill()
	def armor_penalty(self,row):
		x = self.lookup_entry(row,'Type')
		if x in ['Clothing','Light']:
			return 0
		if x=='Medium':
			return -10
		if x=='Heavy':
			return -20
	def title_penalty(self):
		if('Clothing' in self.title or 'Light' in self.title):
			return 0
		if('Medium' in self.title):
			return -10
		if('Heavy' in self.title):
			return -20
	def calculate_fp(self,index_to_fill,resistances,defenses,hp,lookup_index,pen=False):
		atier = self.attack_tier.get()
		stack = min(self.stack.get(),100)
		rec = self.recovery.get()
		if(self.chosen_dot.get()>=0):
			dot_type = self.dot_types[self.chosen_dot.get()]
		else:
			dot_type = 'None'
		for i in range(len(self.column_entries)):
			bmr = self.base_damage.get()-resistances[i]
			if(bmr>0 and pen):
				bmr = bmr+resistances[i]*0.1
			if(bmr<=0 and pen):
				bmr = 0.1*resistances[i]
			amd = self.attack_bonus.get()-defenses[i]
			dmg = damage(atier, self.damage_factor.get(), bmr, amd, 0) #0 should work fine as a hack when not adjusting amd
			if(stack>0):
				effect_protect = self.lookup_entry(i, 'Number of Matched Keywords (major x4)')
				pmp = max(1.0+0.1*(self.effect_power.get()-effect_protect),0.0) #effect power minus effect protection
				new_stack = round( pmp*stack*damage(atier, 1.0, 1, amd-resistances[i], 0) )
				Rec = rec
				if(dot_type!='None'):
					Rec += self.lookup_entry(i,dot_type+' Rec.')
				max_rounds = int(new_stack/Rec)+2
				profile = [round(new_stack*0.001*hp[i])]
				for rd in range(max_rounds):
					new_stack -= Rec
					profile.append(round(new_stack*0.001*hp[i]))
				dmg += sum([ x for x in profile if x>0])
			if(dmg>0.0):
				x = round(100*hp[i]/dmg)/100
			else:
				x = float('inf')
			self.column_entries[i][index_to_fill] = x
			self.lookup[i][lookup_index] = x
	def make_lookup(self):
		self.Lookup = [name for name in self.column_names]
		self.lookup = [[entry for entry in column] for column in self.column_entries]
		self.wookup = [width for width in self.widths]
	def lookup_entry(self,row,name):
		return self.lookup[row][self.Lookup.index(name)]
	def restore(self):
		self.column_names = [name for name in self.Lookup]
		self.widths = [width for width in self.wookup]
		self.column_entries = [[entry for entry in column] for column in self.lookup]
		self.make_save_buttons()
		self.make_sorting_buttons()
		self.fill()

class Make_Message_Window:
	def __init__(self): 
		self.column_names = []
		self.column_entries = []
		self.library = None
	def update_columns(self,title,column_names,column_entries,widths):
		self.title = title
		self.column_names = [ name for name in column_names ]
		self.column_entries = [[entry for entry in column] for column in column_entries]
		self.widths = [ w for w in widths ]
	def add_to_columns(self,new_column_names,new_column_entries,new_widths): 
		if(len(self.column_entries)>len(new_column_entries)): #note: artifact keyword
			return
		self.column_names += [ name for name in new_column_names ]
		self.widths += [ w for w in new_widths ]
		for i in range(len(self.column_entries)):
			self.column_entries[i] += [ entry for entry in new_column_entries[i] ]
	#def add_shift_columns(self, shift_column_names, shift_column_entries): #not passed on or used yet
	#	self.shift_column_names = shift_column_names
	#	self.shift_column_entries = shift_column_entries
	#	self.shift = len(self.shift_column_entries)
	def add_library(self, library):
		self.library = library
	def new_window(self,special='None'): 
		root = tk.Toplevel() 
		root.title(self.title)
		root.iconbitmap(r'%s' %path.join(getcwd(),'NPC.ico'))
		self.root = root
		self.mw = Message_Window(self.root,self.column_names,self.column_entries,self.widths,self.title,special)
		self.mw.add_library(self.library)
		self.mw.pack(side="top", fill="both", expand=True)
