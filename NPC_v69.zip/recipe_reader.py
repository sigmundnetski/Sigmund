from message_window import Make_Message_Window
from re import split
from wb import wb
from armor_reader import armor_list
from weapon_reader import weapon_list
#import gear_reader as well

recipe_list = []
recipe_titles = ['Recipe Name','Skill','Rank','Tier','Component 1','Number','Component 2','Number','Component 3','Number','Component 4','Number','Achievement Type','Base Crafting Seconds','Last Updated']
recipe_types = ['Crafting', 'Refining']
components = []
profession_list = []

class Recipe:
	def __init__(self,parsed,i):
		self.name = parsed[1]
		self.type = recipe_types[i]
		self.profession = parsed[2]
		self.level = int(parsed[3])
		self.tier = int(parsed[4])
		self.rarity = parsed[13]
		self.base_time = int(parsed[14])
		self.components = [parsed[5],parsed[7],parsed[9],parsed[11]]
		self.component_numbers = [ int(parsed[i]) for i in [6,8,10,12] if parsed[i].isdigit() ]
		self.attributes = parsed
		self.quality = 0
	def set_quality(self,quality):
		self.quality = quality
	def printout(self):
		mw = Make_Message_Window()
		title = 'Recipe: %s' %self.name
		column_names = [ 'Attribute', 'Details' ]
		column_entries = [ ]
		width = 10
		for i in range(1,len(self.attributes)):
			column_entries.append([recipe_titles[i-1],self.attributes[i]])
			width = max(width,len(self.attributes[i])+5)
		widths = [ 20, width ]
		mw.update_columns(title, column_names, column_entries, widths)
		mw.new_window()

def find_quality(recipe_name):
	if('+' in recipe_name): #refining
		return 0
	for armor in armor_list:
		if armor.name==recipe_name:
			return armor.quality
	for weapon in weapon_list:
		if weapon.name==recipe_name:
			return weapon.quality
	return 0

def recipe_read():
	for i, sheet_name in enumerate(['Recipes (Crafting)','Recipes (Refining)']):
		sheet = wb.sheet_by_name(sheet_name)
		for rownum in range(sheet.nrows):
			row = sheet.row_values(rownum)[-1].split('|')
			if(len(row)<2 or row[0]=='Template'):
				continue
			r = Recipe(row,i)
			recipe_list.append(r)
			profession_list.append(row[2])
			for j in [5,7,9,11]:
				if(row[j]==''):
					continue
				components.append(row[j])
			r.set_quality(find_quality(r.name))

recipe_read()
components = sorted(list(set(components)))
profession_list = sorted(list(set(profession_list)))
