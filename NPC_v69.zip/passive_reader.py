from message_window import Make_Message_Window
from wb import wb
from weapon_reader import Find_Weapon_Type

passive_list = []
passive_names = []
passive_types = []
passive_titles = [ 'Passive Feat Type', 'Feat Name', 'Role', 'Effect', 'Keywords', 'Keyword Effect', 'Last Updated' ]

class Passive:
	def __init__(self,parsed): 
		self.type = parsed[1]
		self.name = ' '.join(parsed[2].split()[:-1])
		self.attributes = [ parsed[0], parsed[1], self.name, parsed[3], parsed[4], parsed[5], parsed[6], parsed[7] ] #0 is needed somewhere else (other code)??
		self.effects = [ parsed[4] ] #list of effects descriptions
		self.keywords = [ parsed[5] ] #list of lists of keywords
		self.role = parsed[3]
		self.keyword_effect = parsed[6]
	def add_level(self, effect, keywords):
		self.effects.append(effect)
		self.keywords.append(keywords)
	def get_associated_weapon(self):#INCOMPLETE
		if(self.type!='Feature'):
			return
		self.associated_weapon = 'None'
		effects = self.effects[-1].split(',')
		for effect in effects:
			if 'Base Damage' not in effect:
				continue
			self.associated_weapon = Find_Weapon_Type(effect.split()[-1].lstrip().rstrip())#only finds a few. might as well have new version
			#print(self.name, self.associated_weapon)
	def get_armor_effect(self,level):#INCOMPLETE
		if(self.type!='Armor'):
			return
		self.extra_physical = 0
		self.extra_energy = 0
		self.extra_defense = 0
		effects = self.effects[level-1].split(',')
		for effect in effects:
			effect = effect.split('+')
			if(len(effect)!=2):
				print('Bad Effect: %s' %effect)
				continue
			try:
				number = int(effect[1].split()[0])
			except:
				continue
			eff = effect[0].lstrip().rstrip()
			if(eff=='Physical Resistance'):
				self.extra_physical = number
			if(eff=='Energy Resistances'):
				self.extra_energy = number
			if(eff=='Base Defense Bonus'):
				self.extra_defense = number
			if(eff=='All Resistances'):
				self.extra_physical = number
				self.extra_energy = number
	def armor_scaling(self):
		if(self.type!='Armor'):
			return
		self.hp_per_keyword = 0
		self.fort_per_keyword = 0
		self.ref_per_keyword = 0
		self.will_per_keyword = 0
		self.power_per_keyword = 0
		self.afflicted_recovery_per_keyword = 0
		self.bleeding_recovery_per_keyword = 0
		self.burning_recovery_per_keyword = 0
		self.drained_recovery_per_keyword = 0
		self.exhausted_recovery_per_keyword = 0
		self.frightened_recovery_per_keyword = 0
		self.oblivious_recovery_per_keyword = 0
		self.razed_recovery_per_keyword = 0
		self.slowed_recovery_per_keyword = 0
		effects = self.keyword_effect.split(',')
		for effect in effects:
			found = False
			effect = effect.split('+')
			if(len(effect)!=2):
				print('Bad Scaling: %s' %effect)
				continue
			number = int(effect[1].split()[0])
			eff = effect[0].lstrip().rstrip()
			if(eff=='Hit Points'):
				self.hp_per_keyword, found = number, True
			if(eff=='Power'):
				self.power_per_keyword, found = number, True
			if(eff=='Fortitude Defense Bonus'):
				self.fort_per_keyword, found = number, True
			if(eff=='Reflex Defense Bonus'):
				self.ref_per_keyword, found = number, True
			if(eff=='Will Defense Bonus'):
				self.will_per_keyword, found = number, True
			if(eff=='Afflicted Recovery Bonus'):
				self.afflicted_recovery_per_keyword, found = number, True
			if(eff=='Bleeding Recovery Bonus'):
				self.bleeding_recovery_per_keyword, found = number, True
			if(eff=='Burning Recovery Bonus'):
				self.burning_recovery_per_keyword, found = number, True
			if(eff=='Drained Recovery Bonus'):
				self.drained_recovery_per_keyword, found = number, True
			if(eff=='Exhausted Recovery Bonus'):
				self.exhausted_recovery_per_keyword, found = number, True
			if(eff=='Frightened Recovery Bonus'):
				self.frightened_recovery_per_keyword, found = number, True
			if(eff=='Oblivious Recovery Bonus'):
				self.oblivious_recovery_per_keyword, found = number, True
			if(eff=='Razed Recovery Bonus'):
				self.razed_recovery_per_keyword, found = number, True
			if(eff=='Slowed Recovery Bonus'):
				self.slowed_recovery_per_keyword, found = number, True
			if(not found):
				print('Unknown keyword scaling: %s' %effect)
		#print(self.name, self.exhausted_recovery_per_keyword)
		#print(self.name, self.hp_per_keyword, self.fort_per_keyword, self.ref_per_keyword, self.will_per_keyword, self.power_per_keyword)
	def printout(self):
		self.passive_titles = [ 'Passive Feat Type', 'Feat Name', 'Role' ]
		attributes = [ self.attributes[1], self.attributes[2], self.attributes[3] ]
		for j in range(len(self.effects)):
			self.passive_titles.append('Effects Level %s' %(j+1))
			attributes.append(self.effects[j])
		for j in range(len(self.keywords)):
			self.passive_titles.append('Keywords Level %s' %(j+1))
			attributes.append(self.keywords[j])
		self.passive_titles.append('Keyword Effect')
		attributes.append(self.attributes[6])
		self.passive_titles.append('Last Updated')
		attributes.append(self.attributes[7])
		mw = Make_Message_Window()
		title = 'Passive: %s' %self.name
		column_names = [ 'Attribute', 'Details' ]
		column_entries = [ ]
		width = 10
		for i in range(len(attributes)):
			column_entries.append([self.passive_titles[i],attributes[i]])
			width = max(width,len(attributes[i])-10, int(0.95*len(attributes[i])))
		widths = [ 18, width ]
		mw.update_columns(title, column_names, column_entries, widths)
		mw.new_window()

def passive_read():
	for passive_type in ['Defensive','Reactive','Feature','Armor','Upgrade']:
		sheet = wb.sheet_by_name('%s (Passive)' %passive_type)
		for rownum in range(sheet.nrows):
			row = sheet.row_values(rownum)[-1].split('|')
			if(row[0]=='Template' or len(row)<2):
				continue
			this_passive, found_passive = None, False
			#for entry_num in range(len(row)):#legacy?
			#	for x in [ '{', '}', '"' ]:
			#		if x in row[entry_num]:
			#			row[entry_num] = row[entry_num].replace(x,'')
			#	parsed.append(row[entry_num])
			for passive in passive_list:
				if(passive.name==' '.join(row[2].split()[:-1])):
					this_passive, found_passive = passive, True
					this_passive.add_level(row[4], row[5])
			if(not found_passive):
				p = Passive(row)
				passive_list.append(p)
				passive_names.append(p.name)
			if(row[1] not in passive_types): #reactive now merged into defensive?
				passive_types.append(row[1])

passive_read()
passive_types = sorted(passive_types)
for p in passive_list:
	if(p.type=='Armor'):
		p.armor_scaling()
	if(p.type=='Feature'):
		p.get_associated_weapon()
